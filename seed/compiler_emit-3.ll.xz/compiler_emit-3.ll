; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/cabi:Way" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [1 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 56
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l12
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l15
  br label %bb6
bb6:
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = icmp eq i64 %t26, %t27
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2femit_2etbaaTree, !tbaa !27
  %t4 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 7
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t1, 1
  %t8 = extractvalue { i64, ptr } %t1, 0
  %t9 = extractvalue { i64, ptr } { i64 40, ptr @.d0 }, 1
  %t10 = extractvalue { i64, ptr } { i64 40, ptr @.d0 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %t5, 1
  %t14 = extractvalue { i64, ptr } %t5, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 3, ptr @.d1 }, 1
  %t17 = extractvalue { i64, ptr } { i64 3, ptr @.d1 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t7, i64 %t8)
  %t20 = getelementptr i8, ptr %t19, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t9, i64 %t10)
  %t21 = getelementptr i8, ptr %t20, i64 %t10
  call void @olang_textcopy(ptr %t21, ptr %t13, i64 %t14)
  %t22 = getelementptr i8, ptr %t21, i64 %t14
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t19, 1
  store { i64, ptr } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/cabi:Way"
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l54 = alloca i1
  %l61 = alloca %"compiler/cabi:Way"
  %l63 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l91 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i32, ptr %l15
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = getelementptr %"compiler/cabi:Regs", ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = sub i64 %t25, 2
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = getelementptr %"compiler/cabi:Regs", ptr %t29, i32 0, i32 0
  store i64 %t27, ptr %t30, !tbaa !24
  store { i64, ptr } { i64 8, ptr @.d2 }, ptr %l21, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l27
  br label %bb6
bb6:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb7, label %bb8
bb7:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l31
  br label %bb9
bb8:
  %t58 = load i32, ptr %l4, !tbaa !23
  store i32 %t58, ptr %l28, !tbaa !23
  br label %bb10
bb9:
  %t60 = load i32, ptr %l31, !tbaa !23
  store i32 %t60, ptr %l28, !tbaa !23
  br label %bb10
bb10:
  %t61 = load i32, ptr %l28, !tbaa !23
  store i32 %t61, ptr %l5, !tbaa !23
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t63 = load i32, ptr %l4, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l35
  br label %bb11
bb11:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb16
bb13:
  %t68 = load ptr, ptr %l3, !tbaa !29
  store ptr %t68, ptr %l37, !tbaa !29
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l40
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i32, ptr %l40, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t76, ptr %l41
  br label %bb15
bb15:
  %t77 = load i32, ptr %l41
  %t79 = trunc i64 19 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l36, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l36, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l44, !tbaa !29
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = getelementptr %"compiler/cabi:Regs", ptr %t84, i32 0, i32 0
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = sub i64 %t86, 1
  %t90 = load ptr, ptr %l44, !tbaa !29
  %t91 = getelementptr %"compiler/cabi:Regs", ptr %t90, i32 0, i32 0
  store i64 %t88, ptr %t91, !tbaa !24
  store { i64, ptr } { i64 3, ptr @.d3 }, ptr %l47, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t92, ptr %l48, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l49, !tbaa !24
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = mul i64 %t95, 1
  %t97 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l50, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  %t106 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t107 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l54
  br label %bb20
bb20:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/emit:Emitter", ptr %t116, i32 0, i32 3
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/emit:Emitter", ptr %t120, i32 0, i32 44
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t124 = load i32, ptr %l1, !tbaa !23
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t130 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t119, { i64, ptr } %t123, i32 %t124, ptr %t125)
  store %"compiler/cabi:Way" %t130, ptr %l61
  br label %bb21
bb21:
  %t131 = load %"compiler/cabi:Way", ptr %l61
  store %"compiler/cabi:Way" %t131, ptr %l6
  %t132 = getelementptr %"compiler/cabi:Way", ptr %l6, i32 0, i32 0
  %t133 = load i32, ptr %t132
  store i32 %t133, ptr %l7
  %t135 = load i32, ptr %l7
  %t137 = trunc i64 0 to i32
  %t138 = icmp eq i32 %t135, %t137
  br i1 %t138, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb30
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s3, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l68
  br label %bb25
bb25:
  %t145 = getelementptr %"compiler/cabi:Way", ptr %l6, i32 0, i32 4
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t146, { i64, ptr } { i64 0, ptr @.d4 })
  store i1 %t148, ptr %l70
  br label %bb26
bb26:
  %t149 = load i1, ptr %l70, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = getelementptr %"compiler/cabi:Way", ptr %l6, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t154 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t157 = extractvalue { i64, ptr } %t153, 1
  %t158 = extractvalue { i64, ptr } %t153, 0
  %t159 = add i64 %t155, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t154, i64 %t155)
  %t161 = getelementptr i8, ptr %t160, i64 %t155
  call void @olang_textcopy(ptr %t161, ptr %t157, i64 %t158)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l72, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr @.d6 }, ptr %l72, !tbaa !27
  br label %bb29
bb29:
  %t172 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t173, i64 %t174)
  %t180 = getelementptr i8, ptr %t179, i64 %t174
  call void @olang_textcopy(ptr %t180, ptr %t176, i64 %t177)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t179, 1
  store { i64, ptr } %t182, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb30:
  %t184 = load i32, ptr %l7
  %t186 = trunc i64 1 to i32
  %t187 = icmp eq i32 %t184, %t186
  br i1 %t187, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t190 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %v2, ptr %l6)
  store { i64, ptr } %t190, ptr %l80
  br label %bb34
bb34:
  %t191 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t191, ptr %l63, !tbaa !27
  br label %bb47
bb35:
  %t192 = load i32, ptr %l7
  %t194 = trunc i64 2 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb42
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l1, !tbaa !23
  %t201 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s7, ptr %t197, i32 %t198)
  store { i64, ptr } %t201, ptr %l85
  br label %bb39
bb39:
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t203 = load i32, ptr %l1, !tbaa !23
  %t206 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t202, i32 %t203)
  store i64 %t206, ptr %l88
  br label %bb40
bb40:
  %t207 = load i64, ptr %l88, !tbaa !24
  %t208 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t207, i64 8)
  store i64 %t208, ptr %l89
  br label %bb41
bb41:
  %t209 = extractvalue { i64, ptr } { i64 10, ptr @.d7 }, 1
  %t210 = extractvalue { i64, ptr } { i64 10, ptr @.d7 }, 0
  %t211 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 8, ptr @.d8 }, 1
  %t216 = extractvalue { i64, ptr } { i64 8, ptr @.d8 }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load i64, ptr %l89, !tbaa !24
  %t219 = call i64 @__olang_fmt_i64(ptr null, i64 %t218)
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t209, i64 %t210)
  %t222 = getelementptr i8, ptr %t221, i64 %t210
  call void @olang_textcopy(ptr %t222, ptr %t212, i64 %t213)
  %t223 = getelementptr i8, ptr %t222, i64 %t213
  call void @olang_textcopy(ptr %t223, ptr %t215, i64 %t216)
  %t224 = getelementptr i8, ptr %t223, i64 %t216
  %t225 = call i64 @__olang_fmt_i64(ptr %t224, i64 %t218)
  %t226 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t221, 1
  store { i64, ptr } %t227, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 3, ptr @.d9 }, ptr %l91, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t229, ptr %l63, !tbaa !27
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_2854570d7fadf599_61afc1034d008305)
  unreachable
bb47:
  %t231 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l93, !tbaa !24
  %t233 = load i64, ptr %l93, !tbaa !24
  %t234 = mul i64 %t233, 1
  %t235 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t234)
  %t236 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  store { i64, ptr } %t237, ptr %l94, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = load i64, ptr %l93, !tbaa !24
  %t243 = mul i64 %t242, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t239, ptr %t241, i64 %t243, i1 false)
  %t244 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t244, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t245 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t245, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l14 = alloca ptr
  %l25 = alloca i32
  %l29 = alloca %"compiler/mir:Fn"
  %rv = alloca i32
  %t56 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  store i32 %t25, ptr %l5, !tbaa !23
  br label %bb16
bb5:
  %t27 = load { i64, [1 x i64] }, ptr %l1
  %t29 = extractvalue { i64, [1 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 2
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t32 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3
  %t36 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t37 = getelementptr { i32, i32 }, ptr %t36, i32 0, i32 1
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/emit:Emitter", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i32, ptr %l3
  %t45 = load i32, ptr %l4, !tbaa !23
  %t49 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t43, i32 %t44, i32 %t45)
  store i32 %t49, ptr %l25
  br label %bb9
bb9:
  %t50 = load i32, ptr %l25, !tbaa !23
  store i32 %t50, ptr %l5, !tbaa !23
  br label %bb16
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:Emitter", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load { i64, [1 x i64] }, ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t56, ptr %v0, ptr %v0, ptr %t54, { i64, [1 x i64] } %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t56, i64 192, i1 false)
  br label %bb14
bb14:
  %t59 = getelementptr %"compiler/mir:Fn", ptr %l29, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  store i32 %t60, ptr %l5, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8ec8751bbb52a5fd_3161bca6b1c44ba9)
  unreachable
bb16:
  %t62 = load i32, ptr %l5, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 53
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 53
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store i64 %t16, ptr %l13
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t20 = load i64, ptr %l13, !tbaa !24
  store i64 %t20, ptr %l9, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l9, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l16
  br label %bb9
bb9:
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/emit:Emitter", ptr %t26, i32 0, i32 53
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t28, i64 %t29, i64 %t30)
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l27
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb13, label %ok.47
ok.47:
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  br label %bb17
bb13:
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d8b0748be4d5a5b9_c527c32a89be493d)
  unreachable
bb16:
  store { i64, ptr } { i64 1, ptr @.d10 }, ptr %l30, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l25, !tbaa !27
  br label %bb17
bb17:
  %t63 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t63, ptr %l4, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l33, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l36
  br label %bb18
bb18:
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t71 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t69)
  store { i64, ptr } %t71, ptr %l38
  br label %bb19
bb19:
  %t72 = extractvalue { i64, ptr } { i64 19, ptr @.d11 }, 1
  %t73 = extractvalue { i64, ptr } { i64 19, ptr @.d11 }, 0
  %t74 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 15, ptr @.d12 }, 1
  %t79 = extractvalue { i64, ptr } { i64 15, ptr @.d12 }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = add i64 %t80, %t83
  %t85 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 1
  %t86 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 0
  %t87 = add i64 %t84, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t72, i64 %t73)
  %t89 = getelementptr i8, ptr %t88, i64 %t73
  call void @olang_textcopy(ptr %t89, ptr %t75, i64 %t76)
  %t90 = getelementptr i8, ptr %t89, i64 %t76
  call void @olang_textcopy(ptr %t90, ptr %t78, i64 %t79)
  %t91 = getelementptr i8, ptr %t90, i64 %t79
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t85, i64 %t86)
  %t93 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t88, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t102 = load ptr, ptr %l33, !tbaa !29
  %t103 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t102, i64 %t103, { i64, ptr } %t101)
  br label %bb20
bb20:
  %t105 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgVoidPtr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 52
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 52
  store i64 %t12, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/emit:Emitter", ptr %t16, i32 0, i32 52
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t15, i64 %t19, { i64, ptr } { i64 66, ptr @.d14 })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 52
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr @.d15 }, ptr %l14, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l17, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l20
  br label %bb8
bb8:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l32 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l51 = alloca { i64, ptr }
  %l58 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l17
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l23
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l22
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t16, ptr %l19, !tbaa !27
  br label %bb8
bb4:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb8:
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb11:
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l32, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i64, ptr %t39, i64 %t36
  %t41 = load i64, ptr %t40, !tbaa !34
  store i64 %t41, ptr %l8, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:Emitter", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 35
  store ptr %t48, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t50 = load ptr, ptr %l9, !tbaa !29
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, { i64, ptr } } %t54, 1
  %t56 = extractvalue { i32, { i64, ptr } } %t54, 0
  store i32 %t56, ptr %l42
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb15, label %ok.58
ok.58:
  store { i64, ptr } %t55, ptr %l41
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t59, ptr %l38, !tbaa !27
  br label %bb19
bb15:
  %t60 = load i32, ptr %l42, !tbaa !23
  %t61 = ashr i32 %t60, 16
  %t63 = icmp eq i32 %t61, 1
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_aa3eb0efeafaca9c_7799b263c8155fc0)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb19:
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t65, ptr %l11, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t70 = load i64, ptr %l13, !tbaa !24
  %t71 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb22:
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t78, ptr %l51, !tbaa !27
  %t79 = load i64, ptr %l13, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i64, ptr %t82, i64 %t79
  %t84 = load i64, ptr %t83, !tbaa !34
  store i64 %t84, ptr %l14, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/lower:Lowerer", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t91, i64 %t92)
  store ptr %t95, ptr %l58
  br label %bb24
bb24:
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Body", ptr %t96, i32 0, i32 1
  %t99 = load { i64, [2 x i64] }, ptr %t98
  store { i64, [2 x i64] } %t99, ptr %l15
  %t101 = load { i64, [2 x i64] }, ptr %l15
  %t103 = extractvalue { i64, [2 x i64] } %t101, 0
  %t104 = icmp eq i64 %t103, 6
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t107 = getelementptr { i64, i32 }, ptr %t106, i32 0, i32 0
  %t108 = load i64, ptr %t107
  store i64 %t108, ptr %l16, !tbaa !24
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t110 = load i64, ptr %l16, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp eq i64 %t110, %t111
  br i1 %t114, label %bb28, label %bb29
bb28:
  %t116 = load ptr, ptr %lp2
  %t117 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t116, i64 %t117)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_eb6d9c3809493fd7_39d95642e792ba3b)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l13, !tbaa !24
  br label %bb20
bb39:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l12, !tbaa !24
  %t128 = add i64 %t124, %t125
  store i64 %t128, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  br label %bb13
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb9
bb43:
  %t134 = load i64, ptr %l4, !tbaa !24
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  br label %bb2
bb45:
  %t140 = load ptr, ptr %lp2
  %t141 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t140
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupRank(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 67
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t4, i64 %a1)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store i64 %t12, ptr %l8
  br label %bb2
bb2:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i8
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l48 = alloca i32
  %l52 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l111 = alloca i64
  %l114 = alloca i64
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l163 = alloca i1
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t6, i32 %t7)
  br label %bb1
bb1:
  %t10 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t10, ptr %l30
  br label %bb2
bb2:
  %t11 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t11, ptr %l8
  store ptr %l8, ptr %l31, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 7, ptr @.d16 })
  store i1 %t14, ptr %l33
  br label %bb3
bb3:
  %t15 = load i1, ptr %l33, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 8, ptr @.d17 }, ptr %l34, !tbaa !27
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 7, ptr @.d18 }, 1
  %t18 = extractvalue { i64, ptr } { i64 7, ptr @.d18 }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t39, i32 %t40)
  store { i64, ptr } %t43, ptr %l40
  br label %bb7
bb7:
  %t45 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 2, ptr @.d20 }, 1
  %t53 = extractvalue { i64, ptr } { i64 2, ptr @.d20 }, 0
  %t54 = add i64 %t51, %t53
  %t56 = extractvalue { i64, ptr } %a3, 1
  %t57 = extractvalue { i64, ptr } %a3, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t62, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t76, { i64, ptr } %t75)
  br label %bb8
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br i1 %a5, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l8, { i64, ptr } { i64 8, ptr @.d22 })
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l48
  br label %bb13
bb13:
  %t86 = load i32, ptr %l48, !tbaa !23
  store i32 %t86, ptr %l10, !tbaa !23
  %t87 = load i32, ptr %l10, !tbaa !23
  %t88 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t91 = icmp ne i32 %t87, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load i32, ptr %l10, !tbaa !23
  %t94 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t97 = icmp ne i32 %t93, %t94
  store i1 %t97, ptr %l52, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb16
bb16:
  %t99 = load i1, ptr %l52, !tbaa !21
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t100 = load ptr, ptr %l7, !tbaa !29
  %t101 = load i32, ptr %l10, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l59
  br label %bb19
bb18:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  %t105 = load i1, ptr %l59, !tbaa !21
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load i1, ptr %l9, !tbaa !21
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb23, label %bb24
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l8, { i64, ptr } { i64 2, ptr @.d23 })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l8, { i64, ptr } { i64 8, ptr @.d24 })
  br label %bb27
bb27:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  store i64 0, ptr %l11, !tbaa !24
  store i64 %a4, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb34
bb31:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l13, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l71, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l71, !tbaa !24
  store i64 %t141, ptr %l68, !tbaa !24
  br label %bb34
bb34:
  %t142 = load i64, ptr %l68, !tbaa !24
  store i64 %t142, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb37:
  br label %bb38
bb38:
  %t151 = load i64, ptr %l11, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l16, !tbaa !24
  %t161 = load i1, ptr %l9, !tbaa !21
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l8, { i64, ptr } { i64 2, ptr @.d25 })
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb42
bb42:
  %t166 = load i64, ptr %l16, !tbaa !24
  %t167 = extractvalue { i64, ptr } { i64 6, ptr @.d26 }, 1
  %t168 = extractvalue { i64, ptr } { i64 6, ptr @.d26 }, 0
  %t170 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t167, i64 %t168)
  %t173 = getelementptr i8, ptr %t172, i64 %t168
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t166)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l8, { i64, ptr } %t183)
  br label %bb43
bb43:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t186 = load i64, ptr %l15, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l15, !tbaa !24
  br label %bb35
bb45:
  %t190 = load ptr, ptr %l7, !tbaa !29
  store ptr %t190, ptr %l98, !tbaa !29
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t192 = load i32, ptr %l2, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l101
  br label %bb46
bb46:
  %t196 = load ptr, ptr %l98, !tbaa !29
  %t197 = load i32, ptr %l101, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t196, i32 %t197)
  store { i64, ptr } %t198, ptr %l102
  br label %bb47
bb47:
  %t199 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t199, ptr %l17, !tbaa !27
  %t200 = load ptr, ptr %l7, !tbaa !29
  %t201 = load i32, ptr %l2, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t200, i32 %t201)
  store { i64, ptr } %t204, ptr %l105
  br label %bb48
bb48:
  %t205 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t205, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t210 = load i64, ptr %l20, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t214 = icmp sgt i64 %t210, %t211
  br i1 %t214, label %bb49, label %bb50
bb49:
  %t216 = load i64, ptr %l21, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb54
bb51:
  %t220 = load i64, ptr %l20, !tbaa !24
  %t221 = load i64, ptr %l19, !tbaa !24
  %t224 = sub i64 %t220, %t221
  %t225 = load i64, ptr %l21, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t230 = sub i64 %t228, 1
  %t231 = load i64, ptr %l21, !tbaa !24
  %t234 = sdiv i64 %t230, %t231
  store i64 %t234, ptr %l114, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb53
bb53:
  %t236 = load i64, ptr %l114, !tbaa !24
  store i64 %t236, ptr %l111, !tbaa !24
  br label %bb54
bb54:
  %t237 = load i64, ptr %l111, !tbaa !24
  store i64 %t237, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t238 = load i64, ptr %l23, !tbaa !24
  %t239 = load i64, ptr %l22, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb57:
  br label %bb58
bb58:
  %t246 = load i64, ptr %l19, !tbaa !24
  %t247 = load i64, ptr %l23, !tbaa !24
  %t248 = load i64, ptr %l21, !tbaa !24
  %t251 = mul i64 %t247, %t248
  %t254 = add i64 %t246, %t251
  store i64 %t254, ptr %l24, !tbaa !24
  %t256 = load i1, ptr %l9, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s13
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l8, { i64, ptr } { i64 2, ptr @.d27 })
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  store i1 false, ptr %l9, !tbaa !21
  %t261 = load i64, ptr %l24, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i8, ptr %t264, i64 %t261
  %t266 = load i8, ptr %t265, !tbaa !32
  store i8 %t266, ptr %l25, !tbaa !22
  %t268 = load i8, ptr %l25, !tbaa !22
  %t270 = icmp eq i8 %t268, 109
  br i1 %t270, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb67
bb65:
  store %olang.scope zeroinitializer, ptr %s14
  %t272 = load i64, ptr %l24, !tbaa !24
  %t273 = extractvalue { i64, ptr } { i64 6, ptr @.d28 }, 1
  %t274 = extractvalue { i64, ptr } { i64 6, ptr @.d28 }, 0
  %t276 = call i64 @__olang_fmt_i64(ptr null, i64 %t272)
  %t277 = add i64 %t274, %t276
  %t278 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t277)
  call void @olang_textcopy(ptr %t278, ptr %t273, i64 %t274)
  %t279 = getelementptr i8, ptr %t278, i64 %t274
  %t280 = call i64 @__olang_fmt_i64(ptr %t279, i64 %t272)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t278, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = extractvalue { i64, ptr } %t282, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l8, { i64, ptr } %t289)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb67:
  %t292 = load i8, ptr %l25, !tbaa !22
  %t294 = icmp eq i8 %t292, 115
  br i1 %t294, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb72
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t296 = load i64, ptr %l24, !tbaa !24
  %t297 = load i64, ptr %l24, !tbaa !24
  %t298 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t299 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t301 = call i64 @__olang_fmt_i64(ptr null, i64 %t296)
  %t302 = add i64 %t299, %t301
  %t303 = extractvalue { i64, ptr } { i64 9, ptr @.d30 }, 1
  %t304 = extractvalue { i64, ptr } { i64 9, ptr @.d30 }, 0
  %t305 = add i64 %t302, %t304
  %t307 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t308 = add i64 %t305, %t307
  %t309 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 1
  %t310 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t298, i64 %t299)
  %t313 = getelementptr i8, ptr %t312, i64 %t299
  %t314 = call i64 @__olang_fmt_i64(ptr %t313, i64 %t296)
  %t315 = getelementptr i8, ptr %t313, i64 %t301
  call void @olang_textcopy(ptr %t315, ptr %t303, i64 %t304)
  %t316 = getelementptr i8, ptr %t315, i64 %t304
  %t317 = call i64 @__olang_fmt_i64(ptr %t316, i64 %t297)
  %t318 = getelementptr i8, ptr %t316, i64 %t307
  call void @olang_textcopy(ptr %t318, ptr %t309, i64 %t310)
  %t319 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t312, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l8, { i64, ptr } %t327)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s16)
  br label %bb79
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb78
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l8, ptr %l150, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t331, ptr %l152, !tbaa !27
  %t332 = load i64, ptr %l24, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i32, ptr %t335, i64 %t332
  %t337 = load i32, ptr %t336, !tbaa !33
  %t340 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s18, ptr %t330, i32 %t337)
  store { i64, ptr } %t340, ptr %l155
  br label %bb76
bb76:
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t345 = extractvalue { i64, ptr } { i64 3, ptr @.d32 }, 1
  %t346 = extractvalue { i64, ptr } { i64 3, ptr @.d32 }, 0
  %t347 = add i64 %t344, %t346
  %t349 = call i64 @__olang_fmt_i64(ptr null, i64 %t341)
  %t350 = add i64 %t347, %t349
  %t351 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t350)
  call void @olang_textcopy(ptr %t351, ptr %t343, i64 %t344)
  %t352 = getelementptr i8, ptr %t351, i64 %t344
  call void @olang_textcopy(ptr %t352, ptr %t345, i64 %t346)
  %t353 = getelementptr i8, ptr %t352, i64 %t346
  %t354 = call i64 @__olang_fmt_i64(ptr %t353, i64 %t341)
  %t355 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t351, 1
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t359 = extractvalue { i64, ptr } %t356, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  %t364 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t364, { i64, ptr } %t363)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s18)
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_32ecc2f0b2e54909_486ad1b7ea10ca75)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb80:
  %t366 = load i64, ptr %l23, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l23, !tbaa !24
  br label %bb55
bb81:
  store ptr %l8, ptr %l161, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t370, { i64, ptr } { i64 7, ptr @.d33 })
  store i1 %t372, ptr %l163
  br label %bb82
bb82:
  %t373 = load i1, ptr %l163, !tbaa !21
  br i1 %t373, label %bb83, label %bb84
bb83:
  store { i64, ptr } { i64 2, ptr @.d34 }, ptr %l164, !tbaa !27
  br label %bb85
bb84:
  store { i64, ptr } { i64 7, ptr @.d35 }, ptr %l164, !tbaa !27
  br label %bb85
bb85:
  %t374 = load ptr, ptr %l161, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l164, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t374, { i64, ptr } %t375)
  br label %bb86
bb86:
  %t377 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l8)
  store { i64, ptr } %t377, ptr %l166
  br label %bb87
bb87:
  %t378 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t378, ptr %l167, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  store i64 %t380, ptr %l168, !tbaa !24
  %t381 = load i64, ptr %l168, !tbaa !24
  %t382 = mul i64 %t381, 1
  %t383 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t382)
  %t384 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  store { i64, ptr } %t385, ptr %l169, !tbaa !27
  %t386 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = load i64, ptr %l168, !tbaa !24
  %t391 = mul i64 %t390, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t387, ptr %t389, i64 %t391, i1 false)
  %t392 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t392, ptr %l167, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t393 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t393, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l4 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  %t29 = extractvalue { i64, [2 x i64] } %t25, 0
  %t30 = icmp eq i64 %t29, 6
  br i1 %t30, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_616c6f643d0ce9fd_dfe523617d4699c1)
  unreachable
bb13:
  %t32 = load i1, ptr %l16, !tbaa !21
  store i1 %t32, ptr %l4, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b37ed008d0080fcc_cc9019489ebc5a30)
  unreachable
bb19:
  %t33 = load i1, ptr %l4, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l69 = alloca i32
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 0
  store i64 %t10, ptr %l18, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l19, !tbaa !24
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sle i64 0, %t15
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb3:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb5:
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = getelementptr i8, ptr %t23, i64 0
  %t26 = sub i64 %t24, 0
  %t27 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = load ptr, ptr @__olang_prog_scope
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %t31, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t30)
  store i1 %t34, ptr %l26
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e68028fa4f0f457e_ac0c180900ac4e62)
  unreachable
bb7:
  %t35 = load i1, ptr %l26, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr @.d36 })
  store i1 %t40, ptr %l30
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l30, !tbaa !21
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l31, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l35, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t53 = load i64, ptr %l34, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb16:
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l35, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb18:
  %t60 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l34, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  store i1 true, ptr %l5, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df)
  unreachable
bb20:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %t69, ptr %v1, ptr @G_2ecompiler_2femit_2emathExact, { i64, ptr } %t68)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l44
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb22, label %ok.76
ok.76:
  store i64 %t73, ptr %l43
  br label %bb21
bb21:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l40, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store { i64, ptr } { i64 0, ptr @.d37 }, ptr %l45, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  %t82 = mul i64 %t81, 1
  %t83 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t92, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb24:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load ptr, ptr %l3, !tbaa !29
  store ptr %t95, ptr %l49, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l52
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i32, ptr %l52, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t101, i32 %t102)
  store { i64, ptr } %t103, ptr %l53
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i1, ptr %l5, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  store i32 13, ptr %l55
  br label %bb29
bb28:
  store i32 14, ptr %l55
  br label %bb29
bb29:
  %t109 = load i32, ptr %l55
  store i32 %t109, ptr %l8
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp ne i64 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb31:
  %t118 = load ptr, ptr %l3, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t120 = load i32, ptr %l2, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t119, i32 %t120)
  store i32 %t123, ptr %l66
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = load i32, ptr %l66, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l67
  br label %bb33
bb33:
  %t127 = load i32, ptr %l8
  store i32 %t127, ptr %l69
  %t130 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l67, ptr %l69)
  store i1 %t130, ptr %l71
  br label %bb34
bb34:
  %t131 = load i1, ptr %l71, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l62, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr @.d38 }, ptr %l73, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t135, ptr %l74, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l75, !tbaa !24
  %t138 = load i64, ptr %l75, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l76, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l75, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t149, ptr %l74, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t150 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l11, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb41:
  br label %bb42
bb42:
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %l84, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t173, i32 %t171)
  store i32 %t177, ptr %l89
  br label %bb43
bb43:
  %t178 = load i32, ptr %l8
  store i32 %t178, ptr %l91
  %t181 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l89, ptr %l91)
  store i1 %t181, ptr %l93
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 0, ptr @.d39 }, ptr %l95, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t185, ptr %l96, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l97, !tbaa !24
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = mul i64 %t188, 1
  %t190 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t189)
  %t191 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l98, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l97, !tbaa !24
  %t198 = mul i64 %t197, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  %t199 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t199, ptr %l96, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t200 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t200, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l10, !tbaa !24
  br label %bb39
bb49:
  %t205 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t205, ptr %l101, !tbaa !27
  %t206 = load i1, ptr %l5, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  store { i64, ptr } { i64 2, ptr @.d40 }, ptr %l103, !tbaa !27
  br label %bb52
bb51:
  store { i64, ptr } { i64 2, ptr @.d41 }, ptr %l103, !tbaa !27
  br label %bb52
bb52:
  %t208 = extractvalue { i64, ptr } { i64 5, ptr @.d42 }, 1
  %t209 = extractvalue { i64, ptr } { i64 5, ptr @.d42 }, 0
  %t210 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 2, ptr @.d43 }, 1
  %t215 = extractvalue { i64, ptr } { i64 2, ptr @.d43 }, 0
  %t216 = add i64 %t213, %t215
  %t217 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t208, i64 %t209)
  %t222 = getelementptr i8, ptr %t221, i64 %t209
  call void @olang_textcopy(ptr %t222, ptr %t211, i64 %t212)
  %t223 = getelementptr i8, ptr %t222, i64 %t212
  call void @olang_textcopy(ptr %t223, ptr %t214, i64 %t215)
  %t224 = getelementptr i8, ptr %t223, i64 %t215
  call void @olang_textcopy(ptr %t224, ptr %t218, i64 %t219)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t221, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l2 = alloca i32
  %l9 = alloca i64
  %rv = alloca i64
  %t7 = alloca { i64, [5 x i64] }, align 8
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i32, ptr %l2, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [5 x i64] }, ptr %t7, i32 0, i32 0
  store i64 0, ptr %t8
  %t10 = insertvalue { { i64, [1 x i64] }, i32 } undef, { i64, [1 x i64] } %a1, 0
  %t12 = insertvalue { { i64, [1 x i64] }, i32 } %t10, i32 %t6, 1
  %t13 = getelementptr { i64, [5 x i64] }, ptr %t7, i32 0, i32 1
  store { { i64, [1 x i64] }, i32 } %t12, ptr %t13
  %t14 = load { i64, [5 x i64] }, ptr %t7
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t4, { i64, [5 x i64] } %t14, i32 %t15)
  store i64 %t19, ptr %l9
  br label %bb1
bb1:
  %t20 = load i64, ptr %l9, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:fnEm", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l11
  br label %bb2
bb2:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [1 x i64] }, ptr %l1
  %t5 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t1, { i64, [1 x i64] } %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr @.d44 })
  store i1 %t9, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t20 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v2, ptr %v3, ptr %t14, { i64, ptr } %t15, i64 %t16)
  store { i64, ptr } %t20, ptr %l15
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 21, ptr @.d45 })
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load { i64, [1 x i64] }, ptr %l1
  %t32 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s0, ptr %t28, { i64, [1 x i64] } %t29)
  store { i64, ptr } %t32, ptr %l21
  br label %bb11
bb11:
  store { i64, ptr } %a2, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp sgt i64 %t34, 8
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  br label %bb14
bb13:
  store i64 8, ptr %l25, !tbaa !24
  br label %bb14
bb14:
  %t40 = extractvalue { i64, ptr } { i64 36, ptr @.d46 }, 1
  %t41 = extractvalue { i64, ptr } { i64 36, ptr @.d46 }, 0
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 6, ptr @.d47 }, 1
  %t47 = extractvalue { i64, ptr } { i64 6, ptr @.d47 }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 6, ptr @.d48 }, 1
  %t54 = extractvalue { i64, ptr } { i64 6, ptr @.d48 }, 0
  %t55 = add i64 %t52, %t54
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t40, i64 %t41)
  %t63 = getelementptr i8, ptr %t62, i64 %t41
  call void @olang_textcopy(ptr %t63, ptr %t43, i64 %t44)
  %t64 = getelementptr i8, ptr %t63, i64 %t44
  call void @olang_textcopy(ptr %t64, ptr %t46, i64 %t47)
  %t65 = getelementptr i8, ptr %t64, i64 %t47
  call void @olang_textcopy(ptr %t65, ptr %t50, i64 %t51)
  %t66 = getelementptr i8, ptr %t65, i64 %t51
  call void @olang_textcopy(ptr %t66, ptr %t53, i64 %t54)
  %t67 = getelementptr i8, ptr %t66, i64 %t54
  %t68 = call i64 @__olang_fmt_i64(ptr %t67, i64 %t56)
  %t69 = getelementptr i8, ptr %t67, i64 %t57
  call void @olang_textcopy(ptr %t69, ptr %t59, i64 %t60)
  %t70 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t62, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load ptr, ptr %l18, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t79, { i64, ptr } %t78)
  store { i64, ptr } %t81, ptr %l29
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i32
  %lp7 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb2
bb2:
  %t20 = load i1, ptr %l16, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb5
bb4:
  %t26 = load i32, ptr %l4, !tbaa !23
  store i32 %t26, ptr %l17, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr %l20, !tbaa !23
  store i32 %t28, ptr %l17, !tbaa !23
  br label %bb6
bb6:
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t30, i32 %t29)
  store i32 %t34, ptr %l24
  br label %bb7
bb7:
  %t35 = load i32, ptr %l24, !tbaa !23
  store i32 %t35, ptr %l6, !tbaa !23
  %t36 = load i32, ptr %l6, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l31
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t47 = load i1, ptr %l31, !tbaa !21
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l34
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t54 = load i1, ptr %l34, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l36, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t62, i32 %t63)
  store i64 %t66, ptr %l39
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = call i64 @__olang_fmt_i64(ptr null, i64 %t67)
  %t69 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t68)
  %t70 = call i64 @__olang_fmt_i64(ptr %t69, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t73, 0
  %t76 = insertvalue { { i64, ptr }, { i64, ptr } } %t74, { i64, ptr } %t72, 1
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, { i64, ptr } } %t76, ptr %rv
  br label %ret
bb18:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v2, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l45
  br label %bb19
bb19:
  %t84 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l42, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v2, ptr %v2, ptr %t91, { i64, ptr } %t90, i64 0)
  store { i64, ptr } %t93, ptr %l47
  br label %bb20
bb20:
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t94, ptr %lp7
  %t95 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t96 = load ptr, ptr %lp7
  store { i64, ptr } %t95, ptr %t96, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l48, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l6, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l51
  br label %bb21
bb21:
  %t103 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t111 = load ptr, ptr %lp7
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t113 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %v1, ptr %v2, ptr %s1, ptr %t113, { i64, ptr } %t109, { i64, ptr } %t110, { i64, ptr } %t112, { i64, ptr } { i64 0, ptr @.d50 })
  br label %bb22
bb22:
  %t117 = load ptr, ptr %lp7
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l55, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l6, !tbaa !23
  %t123 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t123, ptr %l58
  br label %bb23
bb23:
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = call i64 @__olang_fmt_i64(ptr null, i64 %t124)
  %t126 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t125)
  %t127 = call i64 @__olang_fmt_i64(ptr %t126, i64 %t124)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t130 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t131 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t130, 0
  %t133 = insertvalue { { i64, ptr }, { i64, ptr } } %t131, { i64, ptr } %t129, 1
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, { i64, ptr } } %t133, ptr %rv
  br label %ret
bb24:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t137 = extractvalue { i64, ptr } { i64 26, ptr @.d51 }, 1
  %t138 = extractvalue { i64, ptr } { i64 26, ptr @.d51 }, 0
  %t140 = extractvalue { i64, ptr } %t136, 1
  %t141 = extractvalue { i64, ptr } %t136, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 3, ptr @.d52 }, 1
  %t144 = extractvalue { i64, ptr } { i64 3, ptr @.d52 }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = getelementptr i8, ptr %t147, i64 %t141
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t160 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t135, { i64, ptr } %t157)
  store { i64, ptr } %t160, ptr %l65
  br label %bb25
bb25:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t163 = extractvalue { i64, ptr } { i64 26, ptr @.d53 }, 1
  %t164 = extractvalue { i64, ptr } { i64 26, ptr @.d53 }, 0
  %t166 = extractvalue { i64, ptr } %t162, 1
  %t167 = extractvalue { i64, ptr } %t162, 0
  %t168 = add i64 %t164, %t167
  %t169 = extractvalue { i64, ptr } { i64 3, ptr @.d54 }, 1
  %t170 = extractvalue { i64, ptr } { i64 3, ptr @.d54 }, 0
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t166, i64 %t167)
  %t174 = getelementptr i8, ptr %t173, i64 %t167
  call void @olang_textcopy(ptr %t174, ptr %t169, i64 %t170)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t186 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t161, { i64, ptr } %t183)
  store { i64, ptr } %t186, ptr %l70
  br label %bb26
bb26:
  %t187 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t188 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t187, 0
  %t189 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t190 = insertvalue { { i64, ptr }, { i64, ptr } } %t188, { i64, ptr } %t189, 1
  store { { i64, ptr }, { i64, ptr } } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l6 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l3
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l4, !tbaa !23
  %t17 = icmp eq i32 %t13, %a2
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d06aa239b7550a75_e0c8a30cfe0955c1)
  unreachable
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 13
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 13
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } { i64 29, ptr @.d55 })
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:fnEm", ptr %t13, i32 0, i32 4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 47, ptr @.d56 })
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:fnEm", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t20, { i64, ptr } { i64 21, ptr @.d57 })
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 19, ptr @.d58 })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecCall(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Call" %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Call"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i1
  %l8 = alloca %"compiler/cabi:Regs"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/cabi:Way"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca %"compiler/cabi:Way"
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { { i64, ptr }, i32 }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l56 = alloca i32
  %l57 = alloca %"std/prelude/text:StringBuilder"
  %l58 = alloca %"compiler/cabi:Regs"
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"compiler/cabi:Way"
  %l71 = alloca i1
  %l79 = alloca i1
  %l85 = alloca %"compiler/cabi:Way"
  %l90 = alloca { i64, ptr }
  %l92 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l100 = alloca i64
  %l106 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca { i64, ptr }
  %l116 = alloca i64
  %l119 = alloca i64
  %l143 = alloca { i64, [4 x i64] }
  %l144 = alloca { i64, ptr }
  %l149 = alloca i32
  %l152 = alloca i32
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l169 = alloca i1
  %l170 = alloca i32
  %l173 = alloca i32
  %l177 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l182 = alloca i32
  %l183 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l202 = alloca i1
  %l209 = alloca %"compiler/cabi:Way"
  %l213 = alloca ptr
  %l216 = alloca { i64, ptr }
  %l218 = alloca i1
  %l220 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l236 = alloca i64
  %l239 = alloca { i64, ptr }
  %l245 = alloca i64
  %l249 = alloca i64
  %l252 = alloca i64
  %l275 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l283 = alloca i64
  %l285 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l291 = alloca i64
  %l294 = alloca { i64, ptr }
  %l295 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l322 = alloca i64
  %l323 = alloca i64
  %l329 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l344 = alloca { i64, ptr }
  %l345 = alloca i64
  %l346 = alloca { i64, ptr }
  %l349 = alloca i1
  %l351 = alloca i1
  %l355 = alloca i64
  %l357 = alloca i64
  %l358 = alloca i64
  %l363 = alloca { i64, ptr }
  %l365 = alloca i64
  %l367 = alloca i64
  %l368 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l371 = alloca i64
  %l372 = alloca { i64, ptr }
  %l374 = alloca i1
  %l375 = alloca ptr
  %l376 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l381 = alloca ptr
  %l382 = alloca { i64, ptr }
  %l383 = alloca { i64, ptr }
  %l385 = alloca { i64, ptr }
  %l388 = alloca { i64, ptr }
  %l390 = alloca i64
  %l397 = alloca i1
  %l403 = alloca { { i64, ptr }, i32 }
  %l404 = alloca { i64, ptr }
  %l405 = alloca i64
  %l406 = alloca { i64, ptr }
  %l411 = alloca ptr
  %l414 = alloca { i64, ptr }
  %l420 = alloca ptr
  %l424 = alloca i64
  %l427 = alloca { i64, ptr }
  %l429 = alloca i64
  %l433 = alloca i64
  %l436 = alloca i64
  %l455 = alloca i64
  %l457 = alloca { i64, ptr }
  %l465 = alloca { i64, ptr }
  %l468 = alloca i64
  %l470 = alloca { i64, ptr }
  %l472 = alloca ptr
  %l473 = alloca { i64, ptr }
  %l476 = alloca i64
  %l479 = alloca { i64, ptr }
  %l480 = alloca ptr
  %l483 = alloca { i64, ptr }
  %l488 = alloca ptr
  %l489 = alloca { i64, ptr }
  %l490 = alloca { i64, ptr }
  %l493 = alloca i64
  %l494 = alloca ptr
  %l495 = alloca { i64, ptr }
  %l496 = alloca { i64, ptr }
  %l499 = alloca i64
  %l500 = alloca ptr
  %l502 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s36 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/mir:Call" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l56
  br label %bb1
bb1:
  %t14 = load i32, ptr %l56, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t15, ptr %l57
  br label %bb2
bb2:
  %t16 = load %"std/prelude/text:StringBuilder", ptr %l57
  store %"std/prelude/text:StringBuilder" %t16, ptr %l6
  store i1 true, ptr %l7, !tbaa !21
  %t17 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t17, ptr %l58
  br label %bb3
bb3:
  %t18 = load %"compiler/cabi:Regs", ptr %l58
  store %"compiler/cabi:Regs" %t18, ptr %l8
  store { i64, ptr } { i64 0, ptr @.d59 }, ptr %l59, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t19, ptr %l60, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l61, !tbaa !24
  %t22 = load i64, ptr %l61, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l62, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l61, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  store i32 0, ptr %l63
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l64
  br label %bb4
bb4:
  %t35 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l65
  br label %bb5
bb5:
  %t36 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l66
  br label %bb6
bb6:
  %t37 = load i32, ptr %l63
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  %t41 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, i32 %t37, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, { i64, ptr } { i64 0, ptr @.d60 })
  store %"compiler/cabi:Way" %t41, ptr %l67
  br label %bb7
bb7:
  %t42 = load %"compiler/cabi:Way", ptr %l67
  store %"compiler/cabi:Way" %t42, ptr %l10
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t47 = icmp ne i32 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load i32, ptr %l5, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t53 = icmp ne i32 %t49, %t50
  store i1 %t53, ptr %l71, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l71, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/emit:fnEm", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/emit:Emitter", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l5, !tbaa !23
  %t66 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l79
  br label %bb13
bb12:
  br label %bb25
bb13:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/emit:fnEm", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/emit:Emitter", ptr %t71, i32 0, i32 44
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load i32, ptr %l5, !tbaa !23
  %t79 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t67, { i64, ptr } %t74, i32 %t75)
  store %"compiler/cabi:Way" %t79, ptr %l85
  br label %bb14
bb14:
  %t80 = load %"compiler/cabi:Way", ptr %l85
  store %"compiler/cabi:Way" %t80, ptr %l10
  %t81 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 0
  %t82 = load i32, ptr %t81
  %t84 = trunc i64 4 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l5, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s0, ptr %t87, i32 %t88)
  store { i64, ptr } %t91, ptr %l90
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t92 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t94 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l92, !tbaa !24
  %t97 = load i64, ptr %l92, !tbaa !24
  %t98 = icmp eq i64 %t93, %t97
  br i1 %t98, label %bb18, label %bb19
bb18:
  %t100 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l92, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  br label %bb20
bb19:
  %t106 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t106, ptr %l9, !tbaa !27
  br label %bb20
bb20:
  store ptr %l6, ptr %l94, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l5, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l97
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t112, i32 %t113)
  store i64 %t116, ptr %l100
  br label %bb22
bb22:
  %t117 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 9, ptr @.d61 }, 1
  %t119 = extractvalue { i64, ptr } { i64 9, ptr @.d61 }, 0
  %t120 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 8, ptr @.d62 }, 1
  %t125 = extractvalue { i64, ptr } { i64 8, ptr @.d62 }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load i64, ptr %l100, !tbaa !24
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t127)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 0
  %t132 = add i64 %t129, %t131
  %t134 = extractvalue { i64, ptr } %t117, 1
  %t135 = extractvalue { i64, ptr } %t117, 0
  %t136 = add i64 %t132, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t118, i64 %t119)
  %t138 = getelementptr i8, ptr %t137, i64 %t119
  call void @olang_textcopy(ptr %t138, ptr %t121, i64 %t122)
  %t139 = getelementptr i8, ptr %t138, i64 %t122
  call void @olang_textcopy(ptr %t139, ptr %t124, i64 %t125)
  %t140 = getelementptr i8, ptr %t139, i64 %t125
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t127)
  %t142 = getelementptr i8, ptr %t140, i64 %t128
  call void @olang_textcopy(ptr %t142, ptr %t130, i64 %t131)
  %t143 = getelementptr i8, ptr %t142, i64 %t131
  call void @olang_textcopy(ptr %t143, ptr %t134, i64 %t135)
  %t144 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t137, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t153, { i64, ptr } %t152)
  br label %bb23
bb23:
  store i1 false, ptr %l7, !tbaa !21
  %t155 = getelementptr %"compiler/cabi:Regs", ptr %l8, i32 0, i32 0
  %t156 = load i64, ptr %t155, !tbaa !24
  %t158 = sub i64 %t156, 1
  %t160 = getelementptr %"compiler/cabi:Regs", ptr %l8, i32 0, i32 0
  store i64 %t158, ptr %t160, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t161 = load ptr, ptr %l4, !tbaa !29
  store ptr %t161, ptr %l106, !tbaa !29
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t163 = load i32, ptr %l3, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l109
  br label %bb26
bb26:
  %t167 = load ptr, ptr %l106, !tbaa !29
  %t168 = load i32, ptr %l109, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t169, ptr %l110
  br label %bb27
bb27:
  %t170 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t170, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t175 = load i64, ptr %l13, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp sgt i64 %t175, %t176
  br i1 %t179, label %bb28, label %bb29
bb28:
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb33
bb30:
  %t185 = load i64, ptr %l13, !tbaa !24
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = sub i64 %t185, %t186
  %t190 = load i64, ptr %l14, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t195 = sub i64 %t193, 1
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = sdiv i64 %t195, %t196
  store i64 %t199, ptr %l119, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb32
bb32:
  %t201 = load i64, ptr %l119, !tbaa !24
  store i64 %t201, ptr %l116, !tbaa !24
  br label %bb33
bb33:
  %t202 = load i64, ptr %l116, !tbaa !24
  store i64 %t202, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t203 = load i64, ptr %l16, !tbaa !24
  %t204 = load i64, ptr %l15, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb135
bb36:
  br label %bb37
bb37:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t213 = load i64, ptr %l14, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l17, !tbaa !24
  %t221 = load i1, ptr %l7, !tbaa !21
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l6, { i64, ptr } { i64 2, ptr @.d64 })
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  store i1 false, ptr %l7, !tbaa !21
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 1
  %t228 = load %"compiler/mir:Range", ptr %t227
  %t229 = load i64, ptr %l17, !tbaa !24
  %t233 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t226, %"compiler/mir:Range" %t228, i64 %t229)
  store { i64, [4 x i64] } %t233, ptr %l143
  br label %bb42
bb42:
  %t234 = load { i64, [4 x i64] }, ptr %l143
  store { i64, [4 x i64] } %t234, ptr %l18
  %t235 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t235, ptr %l144, !tbaa !27
  %t236 = load i64, ptr %l17, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i32, ptr %t239, i64 %t236
  %t241 = load i32, ptr %t240, !tbaa !33
  store i32 %t241, ptr %l19, !tbaa !23
  %t243 = load ptr, ptr %l4, !tbaa !29
  %t244 = load i32, ptr %l19, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l149
  br label %bb43
bb43:
  %t248 = load i32, ptr %l149, !tbaa !23
  store i32 %t248, ptr %l20, !tbaa !23
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t250 = load i32, ptr %l20, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t253, ptr %l152
  br label %bb44
bb44:
  %t254 = load i32, ptr %l152
  %t256 = trunc i64 21 to i32
  %t257 = icmp eq i32 %t254, %t256
  br i1 %t257, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t259 = getelementptr %"compiler/cabi:Regs", ptr %l8, i32 0, i32 0
  %t260 = load i64, ptr %t259, !tbaa !24
  %t262 = sub i64 %t260, 2
  %t264 = getelementptr %"compiler/cabi:Regs", ptr %l8, i32 0, i32 0
  store i64 %t262, ptr %t264, !tbaa !24
  store ptr %l6, ptr %l157, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l158, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load { i64, [4 x i64] }, ptr %l18
  %t268 = load i32, ptr %l19, !tbaa !23
  %t272 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s7, ptr %t266, { i64, [4 x i64] } %t267, i32 %t268)
  store { i64, ptr } %t272, ptr %l162
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t273 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  %t280 = load i32, ptr %l19, !tbaa !23
  %t281 = load ptr, ptr %l158, !tbaa !29
  %t284 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s7, ptr %s7, ptr %t281, { i64, ptr } %t279, i32 %t280)
  store { i64, ptr } %t284, ptr %l165
  br label %bb48
bb48:
  %t285 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 0
  %t287 = extractvalue { i64, ptr } %t285, 1
  %t288 = mul i64 %t286, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t288)
  call void @llvm.memcpy.p0.p0.i64(ptr %t289, ptr %t287, i64 %t288, i1 false)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  %t292 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t292, { i64, ptr } %t291)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  br label %bb134
bb50:
  %t294 = load ptr, ptr %l4, !tbaa !29
  %t295 = load i32, ptr %l20, !tbaa !23
  %t298 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l169
  br label %bb51
bb51:
  %t299 = load i1, ptr %l169, !tbaa !21
  br i1 %t299, label %bb52, label %bb53
bb52:
  %t300 = load ptr, ptr %l4, !tbaa !29
  %t301 = load i32, ptr %l20, !tbaa !23
  %t304 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t300, i32 %t301)
  store i32 %t304, ptr %l173
  br label %bb54
bb53:
  %t305 = load i32, ptr %l20, !tbaa !23
  store i32 %t305, ptr %l170, !tbaa !23
  br label %bb55
bb54:
  %t307 = load i32, ptr %l173, !tbaa !23
  store i32 %t307, ptr %l170, !tbaa !23
  br label %bb55
bb55:
  %t308 = load i32, ptr %l170, !tbaa !23
  store i32 %t308, ptr %l21, !tbaa !23
  %t309 = load ptr, ptr %l4, !tbaa !29
  %t310 = load i32, ptr %l20, !tbaa !23
  %t313 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t309, i32 %t310)
  store i1 %t313, ptr %l177
  br label %bb56
bb56:
  %t314 = load i1, ptr %l177, !tbaa !21
  br i1 %t314, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb61
bb58:
  %t315 = load ptr, ptr %l4, !tbaa !29
  store ptr %t315, ptr %l179, !tbaa !29
  %t316 = load ptr, ptr %l4, !tbaa !29
  %t317 = load i32, ptr %l21, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l182
  br label %bb59
bb59:
  %t321 = load ptr, ptr %l179, !tbaa !29
  %t322 = load i32, ptr %l182, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t321, i32 %t322)
  store i32 %t323, ptr %l183
  br label %bb60
bb60:
  %t324 = load i32, ptr %l183
  %t326 = trunc i64 19 to i32
  %t327 = icmp eq i32 %t324, %t326
  store i1 %t327, ptr %l178, !tbaa !21
  br label %bb61
bb61:
  %t329 = load i1, ptr %l178, !tbaa !21
  br i1 %t329, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t330 = getelementptr %"compiler/cabi:Regs", ptr %l8, i32 0, i32 0
  %t331 = load i64, ptr %t330, !tbaa !24
  %t333 = sub i64 %t331, 1
  %t335 = getelementptr %"compiler/cabi:Regs", ptr %l8, i32 0, i32 0
  store i64 %t333, ptr %t335, !tbaa !24
  store ptr %l6, ptr %l188, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l189, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load { i64, [4 x i64] }, ptr %l18
  %t339 = load i32, ptr %l19, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s8, ptr %t337, { i64, [4 x i64] } %t338, i32 %t339)
  store { i64, ptr } %t343, ptr %l193
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t344 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t351 = load i32, ptr %l19, !tbaa !23
  %t352 = load ptr, ptr %l189, !tbaa !29
  %t355 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %s8, ptr %s8, ptr %t352, { i64, ptr } %t350, i32 %t351)
  store { i64, ptr } %t355, ptr %l196
  br label %bb65
bb65:
  %t356 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  %t358 = extractvalue { i64, ptr } %t356, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  %t363 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t363, { i64, ptr } %t362)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  br label %bb134
bb67:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/emit:fnEm", ptr %t365, i32 0, i32 0
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = getelementptr %"compiler/emit:Emitter", ptr %t368, i32 0, i32 0
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t372 = load i32, ptr %l19, !tbaa !23
  %t375 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t371, i32 %t372)
  store i1 %t375, ptr %l202
  br label %bb68
bb68:
  %t376 = load ptr, ptr %l4, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/emit:fnEm", ptr %t377, i32 0, i32 0
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/emit:Emitter", ptr %t380, i32 0, i32 44
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t384 = load i32, ptr %l19, !tbaa !23
  %t389 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %s0, ptr %s5, ptr %t376, { i64, ptr } %t383, i32 %t384, ptr %l8)
  store %"compiler/cabi:Way" %t389, ptr %l209
  br label %bb69
bb69:
  %t390 = load %"compiler/cabi:Way", ptr %l209
  store %"compiler/cabi:Way" %t390, ptr %l22
  %t391 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 0
  %t392 = load i32, ptr %t391
  store i32 %t392, ptr %l23
  %t394 = load i32, ptr %l23
  %t396 = trunc i64 0 to i32
  %t397 = icmp eq i32 %t394, %t396
  br i1 %t397, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb80
bb72:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l6, ptr %l213, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load i32, ptr %l19, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s9, ptr %t399, i32 %t400)
  store { i64, ptr } %t403, ptr %l216
  br label %bb73
bb73:
  %t404 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 4
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  %t407 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s9, { i64, ptr } %t405, { i64, ptr } { i64 0, ptr @.d65 })
  store i1 %t407, ptr %l218
  br label %bb74
bb74:
  %t408 = load i1, ptr %l218, !tbaa !21
  %t409 = xor i1 %t408, true
  br i1 %t409, label %bb75, label %bb76
bb75:
  %t411 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 4
  %t412 = load { i64, ptr }, ptr %t411, !tbaa !27
  %t413 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 1
  %t414 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 0
  %t416 = extractvalue { i64, ptr } %t412, 1
  %t417 = extractvalue { i64, ptr } %t412, 0
  %t418 = add i64 %t414, %t417
  %t419 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t418)
  call void @olang_textcopy(ptr %t419, ptr %t413, i64 %t414)
  %t420 = getelementptr i8, ptr %t419, i64 %t414
  call void @olang_textcopy(ptr %t420, ptr %t416, i64 %t417)
  %t421 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t419, 1
  %t424 = extractvalue { i64, ptr } %t422, 0
  %t425 = extractvalue { i64, ptr } %t422, 1
  %t426 = mul i64 %t424, 1
  %t427 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t426)
  call void @llvm.memcpy.p0.p0.i64(ptr %t427, ptr %t425, i64 %t426, i1 false)
  %t428 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  store { i64, ptr } %t429, ptr %l220, !tbaa !27
  br label %bb77
bb76:
  store { i64, ptr } { i64 0, ptr @.d67 }, ptr %l220, !tbaa !27
  br label %bb77
bb77:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load { i64, [4 x i64] }, ptr %l18
  %t433 = load i32, ptr %l19, !tbaa !23
  %t437 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s9, ptr %t431, { i64, [4 x i64] } %t432, i32 %t433)
  store { i64, ptr } %t437, ptr %l227
  br label %bb78
bb78:
  %t438 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = add i64 %t440, %t443
  %t445 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t446 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t447 = add i64 %t444, %t446
  %t448 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t448, 1
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t451 = add i64 %t447, %t450
  %t452 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t451)
  call void @olang_textcopy(ptr %t452, ptr %t439, i64 %t440)
  %t453 = getelementptr i8, ptr %t452, i64 %t440
  call void @olang_textcopy(ptr %t453, ptr %t442, i64 %t443)
  %t454 = getelementptr i8, ptr %t453, i64 %t443
  call void @olang_textcopy(ptr %t454, ptr %t445, i64 %t446)
  %t455 = getelementptr i8, ptr %t454, i64 %t446
  call void @olang_textcopy(ptr %t455, ptr %t449, i64 %t450)
  %t456 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t452, 1
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t460 = extractvalue { i64, ptr } %t457, 1
  %t461 = mul i64 %t459, 1
  %t462 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t462, ptr %t460, i64 %t461, i1 false)
  %t463 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  %t465 = load ptr, ptr %l213, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t465, { i64, ptr } %t464)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s9)
  br label %bb133
bb80:
  %t467 = load i32, ptr %l23
  %t469 = trunc i64 1 to i32
  %t470 = icmp eq i32 %t467, %t469
  br i1 %t470, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb115
bb83:
  store %olang.scope zeroinitializer, ptr %s12
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l232, !tbaa !29
  %t473 = load ptr, ptr %l4, !tbaa !29
  %t474 = load i32, ptr %l19, !tbaa !23
  %t478 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s5, ptr %t473, ptr %l22, i32 %t474)
  store i64 %t478, ptr %l236
  br label %bb84
bb84:
  %t479 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t480 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  %t481 = load i64, ptr %l236, !tbaa !24
  %t482 = call i64 @__olang_fmt_i64(ptr null, i64 %t481)
  %t483 = add i64 %t480, %t482
  %t484 = extractvalue { i64, ptr } { i64 6, ptr @.d70 }, 1
  %t485 = extractvalue { i64, ptr } { i64 6, ptr @.d70 }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t479, i64 %t480)
  %t488 = getelementptr i8, ptr %t487, i64 %t480
  %t489 = call i64 @__olang_fmt_i64(ptr %t488, i64 %t481)
  %t490 = getelementptr i8, ptr %t488, i64 %t482
  call void @olang_textcopy(ptr %t490, ptr %t484, i64 %t485)
  %t491 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t487, 1
  %t494 = extractvalue { i64, ptr } %t492, 0
  %t495 = extractvalue { i64, ptr } %t492, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  %t500 = load ptr, ptr %l232, !tbaa !29
  %t502 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s12, ptr %s12, ptr %t500, { i64, ptr } %t499, i64 8)
  store { i64, ptr } %t502, ptr %l239
  br label %bb85
bb85:
  %t503 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t503, ptr %l24, !tbaa !27
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t506 = load i32, ptr %l19, !tbaa !23
  %t507 = load { i64, [4 x i64] }, ptr %l18
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s12, ptr %s12, ptr %t504, { i64, ptr } %t505, i32 %t506, { i64, [4 x i64] } %t507, { i64, ptr } { i64 0, ptr @.d71 })
  br label %bb86
bb86:
  store i64 0, ptr %l25, !tbaa !24
  %t512 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 1
  %t514 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s5, ptr %t512)
  store i64 %t514, ptr %l245
  br label %bb87
bb87:
  %t515 = load i64, ptr %l245, !tbaa !24
  store i64 %t515, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t516 = load i64, ptr %l26, !tbaa !24
  %t517 = load i64, ptr %l25, !tbaa !24
  %t520 = icmp sgt i64 %t516, %t517
  br i1 %t520, label %bb88, label %bb89
bb88:
  %t522 = load i64, ptr %l27, !tbaa !24
  %t524 = icmp sgt i64 %t522, 0
  br i1 %t524, label %bb90, label %bb91
bb89:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb93
bb90:
  %t526 = load i64, ptr %l26, !tbaa !24
  %t527 = load i64, ptr %l25, !tbaa !24
  %t530 = sub i64 %t526, %t527
  %t531 = load i64, ptr %l27, !tbaa !24
  %t534 = add i64 %t530, %t531
  %t536 = sub i64 %t534, 1
  %t537 = load i64, ptr %l27, !tbaa !24
  %t540 = sdiv i64 %t536, %t537
  store i64 %t540, ptr %l252, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l252, !tbaa !24
  br label %bb92
bb92:
  %t542 = load i64, ptr %l252, !tbaa !24
  store i64 %t542, ptr %l249, !tbaa !24
  br label %bb93
bb93:
  %t543 = load i64, ptr %l249, !tbaa !24
  store i64 %t543, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s15
  %t544 = load i64, ptr %l29, !tbaa !24
  %t545 = load i64, ptr %l28, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb114
bb96:
  br label %bb97
bb97:
  %t552 = load i64, ptr %l25, !tbaa !24
  %t553 = load i64, ptr %l29, !tbaa !24
  %t554 = load i64, ptr %l27, !tbaa !24
  %t557 = mul i64 %t553, %t554
  %t560 = add i64 %t552, %t557
  store i64 %t560, ptr %l30, !tbaa !24
  %t562 = load i64, ptr %l30, !tbaa !24
  %t564 = icmp sgt i64 %t562, 0
  br i1 %t564, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s16
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l6, { i64, ptr } { i64 2, ptr @.d72 })
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s16)
  br label %bb101
bb101:
  %t567 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 1
  %t568 = load i64, ptr %l30, !tbaa !24
  %t571 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s5, ptr %s15, ptr %t567, i64 %t568)
  store { i64, ptr } %t571, ptr %l275
  br label %bb102
bb102:
  %t572 = load { i64, ptr }, ptr %l275, !tbaa !27
  store { i64, ptr } { i64 14, ptr @.d73 }, ptr %l277, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d74 }, ptr %l278, !tbaa !27
  %t574 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t576 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s15, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t572, { i64, ptr } %t574, { i64, ptr } %t575)
  store { i64, ptr } %t576, ptr %l279
  br label %bb103
bb103:
  %t577 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t577, ptr %l31, !tbaa !27
  %t579 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 2
  %t580 = load i64, ptr %l30, !tbaa !24
  %t583 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t579, i64 %t580)
  store i64 %t583, ptr %l283
  br label %bb104
bb104:
  %t584 = load i64, ptr %l283, !tbaa !24
  %t585 = icmp eq i64 %t584, 0
  br i1 %t585, label %bb105, label %bb106
bb105:
  %t587 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t587, ptr %l285, !tbaa !27
  br label %bb109
bb106:
  %t589 = load ptr, ptr %l0, !tbaa !29
  store ptr %t589, ptr %l287, !tbaa !29
  %t590 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t590, ptr %l288, !tbaa !27
  %t591 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 2
  %t592 = load i64, ptr %l30, !tbaa !24
  %t595 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t591, i64 %t592)
  store i64 %t595, ptr %l291
  br label %bb107
bb107:
  %t596 = extractvalue { i64, ptr } { i64 22, ptr @.d75 }, 1
  %t597 = extractvalue { i64, ptr } { i64 22, ptr @.d75 }, 0
  %t598 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = add i64 %t597, %t600
  %t602 = extractvalue { i64, ptr } { i64 6, ptr @.d76 }, 1
  %t603 = extractvalue { i64, ptr } { i64 6, ptr @.d76 }, 0
  %t604 = add i64 %t601, %t603
  %t605 = load i64, ptr %l291, !tbaa !24
  %t606 = call i64 @__olang_fmt_i64(ptr null, i64 %t605)
  %t607 = add i64 %t604, %t606
  %t608 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t607)
  call void @olang_textcopy(ptr %t608, ptr %t596, i64 %t597)
  %t609 = getelementptr i8, ptr %t608, i64 %t597
  call void @olang_textcopy(ptr %t609, ptr %t599, i64 %t600)
  %t610 = getelementptr i8, ptr %t609, i64 %t600
  call void @olang_textcopy(ptr %t610, ptr %t602, i64 %t603)
  %t611 = getelementptr i8, ptr %t610, i64 %t603
  %t612 = call i64 @__olang_fmt_i64(ptr %t611, i64 %t605)
  %t613 = insertvalue { i64, ptr } undef, i64 %t607, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t608, 1
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t617 = extractvalue { i64, ptr } %t614, 1
  %t618 = mul i64 %t616, 1
  %t619 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t618)
  call void @llvm.memcpy.p0.p0.i64(ptr %t619, ptr %t617, i64 %t618, i1 false)
  %t620 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t619, 1
  %t622 = load ptr, ptr %l287, !tbaa !29
  %t624 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %s15, ptr %t622, { i64, ptr } %t621)
  store { i64, ptr } %t624, ptr %l294
  br label %bb108
bb108:
  %t625 = load { i64, ptr }, ptr %l294, !tbaa !27
  store { i64, ptr } %t625, ptr %l285, !tbaa !27
  br label %bb109
bb109:
  %t626 = load { i64, ptr }, ptr %l285, !tbaa !27
  store { i64, ptr } %t626, ptr %l32, !tbaa !27
  store ptr %l6, ptr %l295, !tbaa !29
  %t627 = getelementptr %"compiler/cabi:Way", ptr %l22, i32 0, i32 1
  %t628 = load i64, ptr %l30, !tbaa !24
  %t631 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s5, ptr %s15, ptr %t627, i64 %t628)
  store { i64, ptr } %t631, ptr %l298
  br label %bb110
bb110:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t633 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t634 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t638 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s15, ptr %s15, ptr %s15, ptr %s15, ptr %t632, { i64, ptr } %t633, { i64, ptr } %t634, { i64, ptr } { i64 0, ptr @.d77 })
  store { i64, ptr } %t638, ptr %l302
  br label %bb111
bb111:
  %t639 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t640 = extractvalue { i64, ptr } %t639, 1
  %t641 = extractvalue { i64, ptr } %t639, 0
  %t642 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t643 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  %t644 = add i64 %t641, %t643
  %t645 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t645, 1
  %t647 = extractvalue { i64, ptr } %t645, 0
  %t648 = add i64 %t644, %t647
  %t649 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t648)
  call void @olang_textcopy(ptr %t649, ptr %t640, i64 %t641)
  %t650 = getelementptr i8, ptr %t649, i64 %t641
  call void @olang_textcopy(ptr %t650, ptr %t642, i64 %t643)
  %t651 = getelementptr i8, ptr %t650, i64 %t643
  call void @olang_textcopy(ptr %t651, ptr %t646, i64 %t647)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t649, 1
  %t655 = extractvalue { i64, ptr } %t653, 0
  %t656 = extractvalue { i64, ptr } %t653, 1
  %t657 = mul i64 %t655, 1
  %t658 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t657)
  call void @llvm.memcpy.p0.p0.i64(ptr %t658, ptr %t656, i64 %t657, i1 false)
  %t659 = insertvalue { i64, ptr } undef, i64 %t655, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t658, 1
  %t661 = load ptr, ptr %l295, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t661, { i64, ptr } %t660)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s15)
  br label %bb113
bb113:
  %t663 = load i64, ptr %l29, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l29, !tbaa !24
  br label %bb94
bb114:
  call void @__olang_scope_close(ptr %s12)
  br label %bb133
bb115:
  %t667 = load i32, ptr %l23
  %t669 = trunc i64 2 to i32
  %t670 = icmp eq i32 %t667, %t669
  br i1 %t670, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb125
bb118:
  store %olang.scope zeroinitializer, ptr %s20
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = load i32, ptr %l19, !tbaa !23
  %t676 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s20, ptr %t672, i32 %t673)
  store { i64, ptr } %t676, ptr %l311
  br label %bb119
bb119:
  %t677 = load { i64, ptr }, ptr %l311, !tbaa !27
  store { i64, ptr } %t677, ptr %l33, !tbaa !27
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t679 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t680 = load i32, ptr %l19, !tbaa !23
  %t681 = load { i64, [4 x i64] }, ptr %l18
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s20, ptr %s20, ptr %t678, { i64, ptr } %t679, i32 %t680, { i64, [4 x i64] } %t681, { i64, ptr } { i64 0, ptr @.d79 })
  br label %bb120
bb120:
  store ptr %l6, ptr %l316, !tbaa !29
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load i32, ptr %l19, !tbaa !23
  %t690 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s20, ptr %t686, i32 %t687)
  store { i64, ptr } %t690, ptr %l319
  br label %bb121
bb121:
  %t691 = load ptr, ptr %l4, !tbaa !29
  %t692 = load i32, ptr %l19, !tbaa !23
  %t695 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t691, i32 %t692)
  store i64 %t695, ptr %l322
  br label %bb122
bb122:
  %t696 = load i64, ptr %l322, !tbaa !24
  %t697 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t696, i64 8)
  store i64 %t697, ptr %l323
  br label %bb123
bb123:
  %t698 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t699 = extractvalue { i64, ptr } { i64 10, ptr @.d80 }, 1
  %t700 = extractvalue { i64, ptr } { i64 10, ptr @.d80 }, 0
  %t701 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 1
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t704 = add i64 %t700, %t703
  %t705 = extractvalue { i64, ptr } { i64 8, ptr @.d81 }, 1
  %t706 = extractvalue { i64, ptr } { i64 8, ptr @.d81 }, 0
  %t707 = add i64 %t704, %t706
  %t708 = load i64, ptr %l323, !tbaa !24
  %t709 = call i64 @__olang_fmt_i64(ptr null, i64 %t708)
  %t710 = add i64 %t707, %t709
  %t711 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t712 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  %t713 = add i64 %t710, %t712
  %t715 = extractvalue { i64, ptr } %t698, 1
  %t716 = extractvalue { i64, ptr } %t698, 0
  %t717 = add i64 %t713, %t716
  %t718 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t717)
  call void @olang_textcopy(ptr %t718, ptr %t699, i64 %t700)
  %t719 = getelementptr i8, ptr %t718, i64 %t700
  call void @olang_textcopy(ptr %t719, ptr %t702, i64 %t703)
  %t720 = getelementptr i8, ptr %t719, i64 %t703
  call void @olang_textcopy(ptr %t720, ptr %t705, i64 %t706)
  %t721 = getelementptr i8, ptr %t720, i64 %t706
  %t722 = call i64 @__olang_fmt_i64(ptr %t721, i64 %t708)
  %t723 = getelementptr i8, ptr %t721, i64 %t709
  call void @olang_textcopy(ptr %t723, ptr %t711, i64 %t712)
  %t724 = getelementptr i8, ptr %t723, i64 %t712
  call void @olang_textcopy(ptr %t724, ptr %t715, i64 %t716)
  %t725 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t726 = insertvalue { i64, ptr } %t725, ptr %t718, 1
  %t728 = extractvalue { i64, ptr } %t726, 0
  %t729 = extractvalue { i64, ptr } %t726, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  %t734 = load ptr, ptr %l316, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t734, { i64, ptr } %t733)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s20)
  br label %bb133
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb132
bb128:
  store %olang.scope zeroinitializer, ptr %s22
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t737 = load i32, ptr %l19, !tbaa !23
  %t740 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s22, ptr %t736, i32 %t737)
  store { i64, ptr } %t740, ptr %l329
  br label %bb129
bb129:
  %t741 = load { i64, ptr }, ptr %l329, !tbaa !27
  store { i64, ptr } %t741, ptr %l34, !tbaa !27
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t744 = load i32, ptr %l19, !tbaa !23
  %t745 = load { i64, [4 x i64] }, ptr %l18
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s22, ptr %s22, ptr %t742, { i64, ptr } %t743, i32 %t744, { i64, [4 x i64] } %t745, { i64, ptr } { i64 0, ptr @.d83 })
  br label %bb130
bb130:
  %t750 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t751 = extractvalue { i64, ptr } { i64 4, ptr @.d84 }, 1
  %t752 = extractvalue { i64, ptr } { i64 4, ptr @.d84 }, 0
  %t754 = extractvalue { i64, ptr } %t750, 1
  %t755 = extractvalue { i64, ptr } %t750, 0
  %t756 = add i64 %t752, %t755
  %t757 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t756)
  call void @olang_textcopy(ptr %t757, ptr %t751, i64 %t752)
  %t758 = getelementptr i8, ptr %t757, i64 %t752
  call void @olang_textcopy(ptr %t758, ptr %t754, i64 %t755)
  %t759 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t760 = insertvalue { i64, ptr } %t759, ptr %t757, 1
  %t762 = extractvalue { i64, ptr } %t760, 0
  %t763 = extractvalue { i64, ptr } %t760, 1
  %t764 = mul i64 %t762, 1
  %t765 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t764)
  call void @llvm.memcpy.p0.p0.i64(ptr %t765, ptr %t763, i64 %t764, i1 false)
  %t766 = insertvalue { i64, ptr } undef, i64 %t762, 0
  %t767 = insertvalue { i64, ptr } %t766, ptr %t765, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l6, { i64, ptr } %t767)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s22)
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_11f14fa65e4040d5_e8173accb9b141e1)
  unreachable
bb133:
  call void @__olang_scope_close(ptr %s5)
  br label %bb134
bb134:
  %t770 = load i64, ptr %l16, !tbaa !24
  %t772 = add i64 %t770, 1
  store i64 %t772, ptr %l16, !tbaa !24
  br label %bb34
bb135:
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t776 = getelementptr %"compiler/emit:fnEm", ptr %t774, i32 0, i32 0
  %t777 = load ptr, ptr %t776, !tbaa !29
  %t778 = load i32, ptr %l3, !tbaa !23
  %t781 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %s0, ptr %t777, i32 %t778)
  store { i64, ptr } %t781, ptr %l343
  br label %bb136
bb136:
  %t782 = load { i64, ptr }, ptr %l343, !tbaa !27
  store { i64, ptr } %t782, ptr %l35, !tbaa !27
  %t783 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t783, ptr %l344, !tbaa !27
  %t784 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t785 = extractvalue { i64, ptr } %t784, 0
  store i64 %t785, ptr %l345, !tbaa !24
  %t786 = load i64, ptr %l345, !tbaa !24
  %t787 = mul i64 %t786, 1
  %t788 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t787)
  %t789 = insertvalue { i64, ptr } undef, i64 %t786, 0
  %t790 = insertvalue { i64, ptr } %t789, ptr %t788, 1
  store { i64, ptr } %t790, ptr %l346, !tbaa !27
  %t791 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t792 = load ptr, ptr %t791, !tbaa !27
  %t793 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !27
  %t795 = load i64, ptr %l345, !tbaa !24
  %t796 = mul i64 %t795, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t792, ptr %t794, i64 %t796, i1 false)
  %t797 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t797, ptr %l36, !tbaa !27
  %t798 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 0
  %t799 = load i32, ptr %t798
  %t801 = trunc i64 0 to i32
  %t802 = icmp eq i32 %t799, %t801
  br i1 %t802, label %bb137, label %bb138
bb137:
  %t804 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 4
  %t805 = load { i64, ptr }, ptr %t804, !tbaa !27
  %t807 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t805, { i64, ptr } { i64 0, ptr @.d85 })
  store i1 %t807, ptr %l351
  br label %bb139
bb138:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb140
bb139:
  %t808 = load i1, ptr %l351, !tbaa !21
  %t809 = xor i1 %t808, true
  store i1 %t809, ptr %l349, !tbaa !21
  br label %bb140
bb140:
  %t811 = load i1, ptr %l349, !tbaa !21
  br i1 %t811, label %bb141, label %bb142
bb141:
  %t812 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 4
  %t813 = load { i64, ptr }, ptr %t812, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t817 = add i64 %t815, 1
  store i64 %t817, ptr %l355, !tbaa !24
  %t818 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t820 = extractvalue { i64, ptr } %t818, 0
  store i64 %t820, ptr %l357, !tbaa !24
  %t821 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t822 = extractvalue { i64, ptr } %t821, 0
  store i64 %t822, ptr %l358, !tbaa !24
  %t823 = load i64, ptr %l355, !tbaa !24
  %t824 = icmp sge i64 %t823, 0
  br i1 %t824, label %bb143, label %bb144
bb142:
  br label %bb152
bb143:
  %t826 = load i64, ptr %l355, !tbaa !24
  %t827 = load i64, ptr %l357, !tbaa !24
  %t828 = icmp sle i64 %t826, %t827
  br i1 %t828, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_c1b63f01de4704cb_7c986704c53dd4e7)
  unreachable
bb145:
  %t830 = load i64, ptr %l357, !tbaa !24
  %t831 = load i64, ptr %l358, !tbaa !24
  %t832 = icmp sle i64 %t830, %t831
  br i1 %t832, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_c1b63f01de4704cb_7c986704c53dd4e7)
  unreachable
bb147:
  %t834 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t835 = load ptr, ptr %t834, !tbaa !27
  %t836 = load i64, ptr %l355, !tbaa !24
  %t837 = load i64, ptr %l357, !tbaa !24
  %t838 = getelementptr i8, ptr %t835, i64 %t836
  %t839 = sub i64 %t837, %t836
  %t840 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t841 = insertvalue { i64, ptr } %t840, ptr %t838, 1
  store { i64, ptr } %t841, ptr %l363, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t843, 0
  %t845 = load { i64, ptr }, ptr %l363, !tbaa !27
  %t846 = extractvalue { i64, ptr } %t845, 0
  store i64 %t846, ptr %l365, !tbaa !24
  %t848 = load i64, ptr %l365, !tbaa !24
  %t849 = icmp eq i64 %t844, %t848
  br i1 %t849, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_c1b63f01de4704cb_7c986704c53dd4e7)
  unreachable
bb149:
  %t851 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t852 = load ptr, ptr %t851, !tbaa !27
  %t853 = getelementptr { i64, ptr }, ptr %l363, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !27
  %t855 = load i64, ptr %l365, !tbaa !24
  %t856 = mul i64 %t855, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t852, ptr %t854, i64 %t856, i1 false)
  br label %bb151
bb150:
  %t857 = load { i64, ptr }, ptr %l363, !tbaa !27
  %t858 = extractvalue { i64, ptr } %t857, 0
  store i64 %t858, ptr %l367, !tbaa !24
  %t859 = load i64, ptr %l367, !tbaa !24
  %t860 = mul i64 %t859, 1
  %t861 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t860)
  %t862 = insertvalue { i64, ptr } undef, i64 %t859, 0
  %t863 = insertvalue { i64, ptr } %t862, ptr %t861, 1
  store { i64, ptr } %t863, ptr %l368, !tbaa !27
  %t864 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t865 = load ptr, ptr %t864, !tbaa !27
  %t866 = getelementptr { i64, ptr }, ptr %l363, i32 0, i32 1
  %t867 = load ptr, ptr %t866, !tbaa !27
  %t868 = load i64, ptr %l367, !tbaa !24
  %t869 = mul i64 %t868, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t865, ptr %t867, i64 %t869, i1 false)
  %t870 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t870, ptr %l36, !tbaa !27
  br label %bb151
bb151:
  br label %bb152
bb152:
  store { i64, ptr } { i64 0, ptr @.d86 }, ptr %l369, !tbaa !27
  %t871 = load { i64, ptr }, ptr %l369, !tbaa !27
  store { i64, ptr } %t871, ptr %l370, !tbaa !27
  %t872 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t872, 0
  store i64 %t873, ptr %l371, !tbaa !24
  %t874 = load i64, ptr %l371, !tbaa !24
  %t875 = mul i64 %t874, 1
  %t876 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t875)
  %t877 = insertvalue { i64, ptr } undef, i64 %t874, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  store { i64, ptr } %t878, ptr %l372, !tbaa !27
  %t879 = getelementptr { i64, ptr }, ptr %l372, i32 0, i32 1
  %t880 = load ptr, ptr %t879, !tbaa !27
  %t881 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t882 = load ptr, ptr %t881, !tbaa !27
  %t883 = load i64, ptr %l371, !tbaa !24
  %t884 = mul i64 %t883, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t880, ptr %t882, i64 %t884, i1 false)
  %t885 = load { i64, ptr }, ptr %l372, !tbaa !27
  store { i64, ptr } %t885, ptr %l37, !tbaa !27
  %t886 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t888 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t886, { i64, ptr } { i64 4, ptr @.d87 })
  store i1 %t888, ptr %l374
  br label %bb153
bb153:
  %t889 = load i1, ptr %l374, !tbaa !21
  br i1 %t889, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s26
  %t890 = load ptr, ptr %l0, !tbaa !29
  store ptr %t890, ptr %l375, !tbaa !29
  %t891 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t891, ptr %l376, !tbaa !27
  %t893 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s26, ptr %l6)
  store { i64, ptr } %t893, ptr %l378
  br label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s28
  %t894 = load ptr, ptr %l0, !tbaa !29
  store ptr %t894, ptr %l381, !tbaa !29
  %t895 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t895, ptr %l382, !tbaa !27
  %t896 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t896, ptr %l383, !tbaa !27
  %t898 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s28, ptr %l6)
  store { i64, ptr } %t898, ptr %l385
  br label %bb158
bb156:
  %t899 = extractvalue { i64, ptr } { i64 10, ptr @.d88 }, 1
  %t900 = extractvalue { i64, ptr } { i64 10, ptr @.d88 }, 0
  %t901 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t902 = extractvalue { i64, ptr } %t901, 1
  %t903 = extractvalue { i64, ptr } %t901, 0
  %t904 = add i64 %t900, %t903
  %t905 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 1
  %t906 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 0
  %t907 = add i64 %t904, %t906
  %t908 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t909 = extractvalue { i64, ptr } %t908, 1
  %t910 = extractvalue { i64, ptr } %t908, 0
  %t911 = add i64 %t907, %t910
  %t912 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 1
  %t913 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 0
  %t914 = add i64 %t911, %t913
  %t915 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t914)
  call void @olang_textcopy(ptr %t915, ptr %t899, i64 %t900)
  %t916 = getelementptr i8, ptr %t915, i64 %t900
  call void @olang_textcopy(ptr %t916, ptr %t902, i64 %t903)
  %t917 = getelementptr i8, ptr %t916, i64 %t903
  call void @olang_textcopy(ptr %t917, ptr %t905, i64 %t906)
  %t918 = getelementptr i8, ptr %t917, i64 %t906
  call void @olang_textcopy(ptr %t918, ptr %t909, i64 %t910)
  %t919 = getelementptr i8, ptr %t918, i64 %t910
  call void @olang_textcopy(ptr %t919, ptr %t912, i64 %t913)
  %t920 = insertvalue { i64, ptr } undef, i64 %t914, 0
  %t921 = insertvalue { i64, ptr } %t920, ptr %t915, 1
  %t923 = extractvalue { i64, ptr } %t921, 0
  %t924 = extractvalue { i64, ptr } %t921, 1
  %t925 = mul i64 %t923, 1
  %t926 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t925)
  call void @llvm.memcpy.p0.p0.i64(ptr %t926, ptr %t924, i64 %t925, i1 false)
  %t927 = insertvalue { i64, ptr } undef, i64 %t923, 0
  %t928 = insertvalue { i64, ptr } %t927, ptr %t926, 1
  %t929 = load ptr, ptr %l375, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s26, ptr %t929, { i64, ptr } %t928)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s26)
  br label %bb163
bb158:
  %t931 = extractvalue { i64, ptr } { i64 5, ptr @.d91 }, 1
  %t932 = extractvalue { i64, ptr } { i64 5, ptr @.d91 }, 0
  %t933 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t934 = extractvalue { i64, ptr } %t933, 1
  %t935 = extractvalue { i64, ptr } %t933, 0
  %t936 = add i64 %t932, %t935
  %t937 = extractvalue { i64, ptr } { i64 1, ptr @.d92 }, 1
  %t938 = extractvalue { i64, ptr } { i64 1, ptr @.d92 }, 0
  %t939 = add i64 %t936, %t938
  %t940 = load { i64, ptr }, ptr %l383, !tbaa !27
  %t941 = extractvalue { i64, ptr } %t940, 1
  %t942 = extractvalue { i64, ptr } %t940, 0
  %t943 = add i64 %t939, %t942
  %t944 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t945 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  %t946 = add i64 %t943, %t945
  %t947 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t948 = extractvalue { i64, ptr } %t947, 1
  %t949 = extractvalue { i64, ptr } %t947, 0
  %t950 = add i64 %t946, %t949
  %t951 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 1
  %t952 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 0
  %t953 = add i64 %t950, %t952
  %t954 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t953)
  call void @olang_textcopy(ptr %t954, ptr %t931, i64 %t932)
  %t955 = getelementptr i8, ptr %t954, i64 %t932
  call void @olang_textcopy(ptr %t955, ptr %t934, i64 %t935)
  %t956 = getelementptr i8, ptr %t955, i64 %t935
  call void @olang_textcopy(ptr %t956, ptr %t937, i64 %t938)
  %t957 = getelementptr i8, ptr %t956, i64 %t938
  call void @olang_textcopy(ptr %t957, ptr %t941, i64 %t942)
  %t958 = getelementptr i8, ptr %t957, i64 %t942
  call void @olang_textcopy(ptr %t958, ptr %t944, i64 %t945)
  %t959 = getelementptr i8, ptr %t958, i64 %t945
  call void @olang_textcopy(ptr %t959, ptr %t948, i64 %t949)
  %t960 = getelementptr i8, ptr %t959, i64 %t949
  call void @olang_textcopy(ptr %t960, ptr %t951, i64 %t952)
  %t961 = insertvalue { i64, ptr } undef, i64 %t953, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t954, 1
  %t964 = extractvalue { i64, ptr } %t962, 0
  %t965 = extractvalue { i64, ptr } %t962, 1
  %t966 = mul i64 %t964, 1
  %t967 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t966)
  call void @llvm.memcpy.p0.p0.i64(ptr %t967, ptr %t965, i64 %t966, i1 false)
  %t968 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t967, 1
  %t970 = load ptr, ptr %l381, !tbaa !29
  %t972 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t970, { i64, ptr } %t969)
  store { i64, ptr } %t972, ptr %l388
  br label %bb159
bb159:
  %t973 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t974 = extractvalue { i64, ptr } %t973, 0
  %t975 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t976 = extractvalue { i64, ptr } %t975, 0
  store i64 %t976, ptr %l390, !tbaa !24
  %t978 = load i64, ptr %l390, !tbaa !24
  %t979 = icmp eq i64 %t974, %t978
  br i1 %t979, label %bb160, label %bb161
bb160:
  %t981 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t982 = load ptr, ptr %t981, !tbaa !27
  %t983 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t984 = load ptr, ptr %t983, !tbaa !27
  %t985 = load i64, ptr %l390, !tbaa !24
  %t986 = mul i64 %t985, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t982, ptr %t984, i64 %t986, i1 false)
  br label %bb162
bb161:
  %t987 = load { i64, ptr }, ptr %l388, !tbaa !27
  store { i64, ptr } %t987, ptr %l37, !tbaa !27
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s28)
  br label %bb163
bb163:
  %t988 = load i32, ptr %l5, !tbaa !23
  %t989 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t992 = icmp eq i32 %t988, %t989
  br i1 %t992, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s30
  %t994 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s30, ptr %t994, { i64, ptr } { i64 11, ptr @.d95 })
  br label %bb166
bb165:
  br label %bb167
bb166:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb167:
  %t996 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 4
  %t997 = load i1, ptr %t996, !tbaa !21
  br i1 %t997, label %bb168, label %bb169
bb168:
  %t999 = load i32, ptr %l5, !tbaa !23
  %t1000 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1003 = icmp ne i32 %t999, %t1000
  store i1 %t1003, ptr %l397, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb170
bb170:
  %t1005 = load i1, ptr %l397, !tbaa !21
  br i1 %t1005, label %bb171, label %bb172
bb171:
  store %olang.scope zeroinitializer, ptr %s31
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 3
  %t1008 = load %"compiler/mir:Place", ptr %t1007
  %t1011 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s31, ptr %t1006, %"compiler/mir:Place" %t1008)
  store { { i64, ptr }, i32 } %t1011, ptr %l403
  br label %bb173
bb172:
  br label %bb221
bb173:
  %t1012 = load { { i64, ptr }, i32 }, ptr %l403
  store { { i64, ptr }, i32 } %t1012, ptr %l38
  %t1013 = getelementptr { { i64, ptr }, i32 }, ptr %l38, i32 0, i32 0
  %t1014 = load { i64, ptr }, ptr %t1013, !tbaa !27
  store { i64, ptr } %t1014, ptr %l404, !tbaa !27
  %t1015 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t1016 = extractvalue { i64, ptr } %t1015, 0
  store i64 %t1016, ptr %l405, !tbaa !24
  %t1017 = load i64, ptr %l405, !tbaa !24
  %t1018 = mul i64 %t1017, 1
  %t1019 = call ptr @__olang_scope_alloc_zeroed(ptr %s31, i64 %t1018)
  %t1020 = insertvalue { i64, ptr } undef, i64 %t1017, 0
  %t1021 = insertvalue { i64, ptr } %t1020, ptr %t1019, 1
  store { i64, ptr } %t1021, ptr %l406, !tbaa !27
  %t1022 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t1023 = load ptr, ptr %t1022, !tbaa !27
  %t1024 = getelementptr { i64, ptr }, ptr %l404, i32 0, i32 1
  %t1025 = load ptr, ptr %t1024, !tbaa !27
  %t1026 = load i64, ptr %l405, !tbaa !24
  %t1027 = mul i64 %t1026, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1023, ptr %t1025, i64 %t1027, i1 false)
  %t1028 = load { i64, ptr }, ptr %l406, !tbaa !27
  store { i64, ptr } %t1028, ptr %l39, !tbaa !27
  %t1029 = getelementptr { { i64, ptr }, i32 }, ptr %l38, i32 0, i32 1
  %t1030 = load i32, ptr %t1029, !tbaa !23
  store i32 %t1030, ptr %l40, !tbaa !23
  %t1032 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 0
  %t1033 = load i32, ptr %t1032
  store i32 %t1033, ptr %l41
  %t1035 = load i32, ptr %l41
  %t1037 = trunc i64 0 to i32
  %t1038 = icmp eq i32 %t1035, %t1037
  br i1 %t1038, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb179
bb176:
  store %olang.scope zeroinitializer, ptr %s32
  %t1040 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1040, ptr %l411, !tbaa !29
  %t1041 = load ptr, ptr %l0, !tbaa !29
  %t1042 = load i32, ptr %l40, !tbaa !23
  %t1045 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s32, ptr %t1041, i32 %t1042)
  store { i64, ptr } %t1045, ptr %l414
  br label %bb177
bb177:
  %t1046 = load { i64, ptr }, ptr %l414, !tbaa !27
  %t1047 = extractvalue { i64, ptr } %t1046, 0
  %t1048 = extractvalue { i64, ptr } %t1046, 1
  %t1049 = mul i64 %t1047, 1
  %t1050 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1049)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1050, ptr %t1048, i64 %t1049, i1 false)
  %t1051 = insertvalue { i64, ptr } undef, i64 %t1047, 0
  %t1052 = insertvalue { i64, ptr } %t1051, ptr %t1050, 1
  %t1053 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1054 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1055 = load ptr, ptr %l411, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s32, ptr %s0, ptr %s31, ptr %s32, ptr %t1055, { i64, ptr } %t1052, { i64, ptr } %t1053, { i64, ptr } %t1054, { i64, ptr } { i64 0, ptr @.d96 })
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s32)
  br label %bb220
bb179:
  %t1059 = load i32, ptr %l41
  %t1061 = trunc i64 1 to i32
  %t1062 = icmp eq i32 %t1059, %t1061
  br i1 %t1062, label %bb180, label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb213
bb182:
  store %olang.scope zeroinitializer, ptr %s33
  %t1064 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1064, ptr %l420, !tbaa !29
  %t1065 = load ptr, ptr %l4, !tbaa !29
  %t1066 = load i32, ptr %l5, !tbaa !23
  %t1070 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s0, ptr %t1065, ptr %l10, i32 %t1066)
  store i64 %t1070, ptr %l424
  br label %bb183
bb183:
  %t1071 = extractvalue { i64, ptr } { i64 1, ptr @.d97 }, 1
  %t1072 = extractvalue { i64, ptr } { i64 1, ptr @.d97 }, 0
  %t1073 = load i64, ptr %l424, !tbaa !24
  %t1074 = call i64 @__olang_fmt_i64(ptr null, i64 %t1073)
  %t1075 = add i64 %t1072, %t1074
  %t1076 = extractvalue { i64, ptr } { i64 6, ptr @.d98 }, 1
  %t1077 = extractvalue { i64, ptr } { i64 6, ptr @.d98 }, 0
  %t1078 = add i64 %t1075, %t1077
  %t1079 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1078)
  call void @olang_textcopy(ptr %t1079, ptr %t1071, i64 %t1072)
  %t1080 = getelementptr i8, ptr %t1079, i64 %t1072
  %t1081 = call i64 @__olang_fmt_i64(ptr %t1080, i64 %t1073)
  %t1082 = getelementptr i8, ptr %t1080, i64 %t1074
  call void @olang_textcopy(ptr %t1082, ptr %t1076, i64 %t1077)
  %t1083 = insertvalue { i64, ptr } undef, i64 %t1078, 0
  %t1084 = insertvalue { i64, ptr } %t1083, ptr %t1079, 1
  %t1086 = extractvalue { i64, ptr } %t1084, 0
  %t1087 = extractvalue { i64, ptr } %t1084, 1
  %t1088 = mul i64 %t1086, 1
  %t1089 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1088)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1089, ptr %t1087, i64 %t1088, i1 false)
  %t1090 = insertvalue { i64, ptr } undef, i64 %t1086, 0
  %t1091 = insertvalue { i64, ptr } %t1090, ptr %t1089, 1
  %t1092 = load ptr, ptr %l420, !tbaa !29
  %t1094 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s33, ptr %s33, ptr %t1092, { i64, ptr } %t1091, i64 8)
  store { i64, ptr } %t1094, ptr %l427
  br label %bb184
bb184:
  %t1095 = load { i64, ptr }, ptr %l427, !tbaa !27
  store { i64, ptr } %t1095, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t1096 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 1
  %t1098 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t1096)
  store i64 %t1098, ptr %l429
  br label %bb185
bb185:
  %t1099 = load i64, ptr %l429, !tbaa !24
  store i64 %t1099, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t1100 = load i64, ptr %l44, !tbaa !24
  %t1101 = load i64, ptr %l43, !tbaa !24
  %t1104 = icmp sgt i64 %t1100, %t1101
  br i1 %t1104, label %bb186, label %bb187
bb186:
  %t1106 = load i64, ptr %l45, !tbaa !24
  %t1108 = icmp sgt i64 %t1106, 0
  br i1 %t1108, label %bb188, label %bb189
bb187:
  store i64 0, ptr %l433, !tbaa !24
  br label %bb191
bb188:
  %t1110 = load i64, ptr %l44, !tbaa !24
  %t1111 = load i64, ptr %l43, !tbaa !24
  %t1114 = sub i64 %t1110, %t1111
  %t1115 = load i64, ptr %l45, !tbaa !24
  %t1118 = add i64 %t1114, %t1115
  %t1120 = sub i64 %t1118, 1
  %t1121 = load i64, ptr %l45, !tbaa !24
  %t1124 = sdiv i64 %t1120, %t1121
  store i64 %t1124, ptr %l436, !tbaa !24
  br label %bb190
bb189:
  store i64 0, ptr %l436, !tbaa !24
  br label %bb190
bb190:
  %t1126 = load i64, ptr %l436, !tbaa !24
  store i64 %t1126, ptr %l433, !tbaa !24
  br label %bb191
bb191:
  %t1127 = load i64, ptr %l433, !tbaa !24
  store i64 %t1127, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s36
  %t1128 = load i64, ptr %l47, !tbaa !24
  %t1129 = load i64, ptr %l46, !tbaa !24
  %t1132 = icmp slt i64 %t1128, %t1129
  %t1134 = xor i1 %t1132, true
  br i1 %t1134, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s36)
  br label %bb210
bb194:
  br label %bb195
bb195:
  %t1136 = load i64, ptr %l43, !tbaa !24
  %t1137 = load i64, ptr %l47, !tbaa !24
  %t1138 = load i64, ptr %l45, !tbaa !24
  %t1141 = mul i64 %t1137, %t1138
  %t1144 = add i64 %t1136, %t1141
  store i64 %t1144, ptr %l48, !tbaa !24
  %t1146 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 1
  %t1148 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t1146)
  store i64 %t1148, ptr %l455
  br label %bb196
bb196:
  %t1149 = load i64, ptr %l455, !tbaa !24
  %t1150 = icmp eq i64 %t1149, 1
  br i1 %t1150, label %bb197, label %bb198
bb197:
  %t1152 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t1152, ptr %l457, !tbaa !27
  br label %bb200
bb198:
  %t1154 = load ptr, ptr %l0, !tbaa !29
  %t1155 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1156 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1157 = load i64, ptr %l48, !tbaa !24
  %t1158 = extractvalue { i64, ptr } { i64 13, ptr @.d99 }, 1
  %t1159 = extractvalue { i64, ptr } { i64 13, ptr @.d99 }, 0
  %t1161 = extractvalue { i64, ptr } %t1155, 1
  %t1162 = extractvalue { i64, ptr } %t1155, 0
  %t1163 = add i64 %t1159, %t1162
  %t1164 = extractvalue { i64, ptr } { i64 1, ptr @.d100 }, 1
  %t1165 = extractvalue { i64, ptr } { i64 1, ptr @.d100 }, 0
  %t1166 = add i64 %t1163, %t1165
  %t1168 = extractvalue { i64, ptr } %t1156, 1
  %t1169 = extractvalue { i64, ptr } %t1156, 0
  %t1170 = add i64 %t1166, %t1169
  %t1171 = extractvalue { i64, ptr } { i64 2, ptr @.d101 }, 1
  %t1172 = extractvalue { i64, ptr } { i64 2, ptr @.d101 }, 0
  %t1173 = add i64 %t1170, %t1172
  %t1175 = call i64 @__olang_fmt_i64(ptr null, i64 %t1157)
  %t1176 = add i64 %t1173, %t1175
  %t1177 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1176)
  call void @olang_textcopy(ptr %t1177, ptr %t1158, i64 %t1159)
  %t1178 = getelementptr i8, ptr %t1177, i64 %t1159
  call void @olang_textcopy(ptr %t1178, ptr %t1161, i64 %t1162)
  %t1179 = getelementptr i8, ptr %t1178, i64 %t1162
  call void @olang_textcopy(ptr %t1179, ptr %t1164, i64 %t1165)
  %t1180 = getelementptr i8, ptr %t1179, i64 %t1165
  call void @olang_textcopy(ptr %t1180, ptr %t1168, i64 %t1169)
  %t1181 = getelementptr i8, ptr %t1180, i64 %t1169
  call void @olang_textcopy(ptr %t1181, ptr %t1171, i64 %t1172)
  %t1182 = getelementptr i8, ptr %t1181, i64 %t1172
  %t1183 = call i64 @__olang_fmt_i64(ptr %t1182, i64 %t1157)
  %t1184 = insertvalue { i64, ptr } undef, i64 %t1176, 0
  %t1185 = insertvalue { i64, ptr } %t1184, ptr %t1177, 1
  %t1187 = extractvalue { i64, ptr } %t1185, 0
  %t1188 = extractvalue { i64, ptr } %t1185, 1
  %t1189 = mul i64 %t1187, 1
  %t1190 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1190, ptr %t1188, i64 %t1189, i1 false)
  %t1191 = insertvalue { i64, ptr } undef, i64 %t1187, 0
  %t1192 = insertvalue { i64, ptr } %t1191, ptr %t1190, 1
  %t1195 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s36, ptr %s36, ptr %t1154, { i64, ptr } %t1192)
  store { i64, ptr } %t1195, ptr %l465
  br label %bb199
bb199:
  %t1196 = load { i64, ptr }, ptr %l465, !tbaa !27
  store { i64, ptr } %t1196, ptr %l457, !tbaa !27
  br label %bb200
bb200:
  %t1197 = load { i64, ptr }, ptr %l457, !tbaa !27
  store { i64, ptr } %t1197, ptr %l49, !tbaa !27
  %t1198 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 2
  %t1199 = load i64, ptr %l48, !tbaa !24
  %t1202 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t1198, i64 %t1199)
  store i64 %t1202, ptr %l468
  br label %bb201
bb201:
  %t1203 = load i64, ptr %l468, !tbaa !24
  %t1204 = icmp eq i64 %t1203, 0
  br i1 %t1204, label %bb202, label %bb203
bb202:
  %t1206 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t1206, ptr %l470, !tbaa !27
  br label %bb206
bb203:
  %t1208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1208, ptr %l472, !tbaa !29
  %t1209 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t1209, ptr %l473, !tbaa !27
  %t1210 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 2
  %t1211 = load i64, ptr %l48, !tbaa !24
  %t1214 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t1210, i64 %t1211)
  store i64 %t1214, ptr %l476
  br label %bb204
bb204:
  %t1215 = extractvalue { i64, ptr } { i64 22, ptr @.d102 }, 1
  %t1216 = extractvalue { i64, ptr } { i64 22, ptr @.d102 }, 0
  %t1217 = load { i64, ptr }, ptr %l473, !tbaa !27
  %t1218 = extractvalue { i64, ptr } %t1217, 1
  %t1219 = extractvalue { i64, ptr } %t1217, 0
  %t1220 = add i64 %t1216, %t1219
  %t1221 = extractvalue { i64, ptr } { i64 6, ptr @.d103 }, 1
  %t1222 = extractvalue { i64, ptr } { i64 6, ptr @.d103 }, 0
  %t1223 = add i64 %t1220, %t1222
  %t1224 = load i64, ptr %l476, !tbaa !24
  %t1225 = call i64 @__olang_fmt_i64(ptr null, i64 %t1224)
  %t1226 = add i64 %t1223, %t1225
  %t1227 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1226)
  call void @olang_textcopy(ptr %t1227, ptr %t1215, i64 %t1216)
  %t1228 = getelementptr i8, ptr %t1227, i64 %t1216
  call void @olang_textcopy(ptr %t1228, ptr %t1218, i64 %t1219)
  %t1229 = getelementptr i8, ptr %t1228, i64 %t1219
  call void @olang_textcopy(ptr %t1229, ptr %t1221, i64 %t1222)
  %t1230 = getelementptr i8, ptr %t1229, i64 %t1222
  %t1231 = call i64 @__olang_fmt_i64(ptr %t1230, i64 %t1224)
  %t1232 = insertvalue { i64, ptr } undef, i64 %t1226, 0
  %t1233 = insertvalue { i64, ptr } %t1232, ptr %t1227, 1
  %t1235 = extractvalue { i64, ptr } %t1233, 0
  %t1236 = extractvalue { i64, ptr } %t1233, 1
  %t1237 = mul i64 %t1235, 1
  %t1238 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1238, ptr %t1236, i64 %t1237, i1 false)
  %t1239 = insertvalue { i64, ptr } undef, i64 %t1235, 0
  %t1240 = insertvalue { i64, ptr } %t1239, ptr %t1238, 1
  %t1241 = load ptr, ptr %l472, !tbaa !29
  %t1243 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s36, ptr %s36, ptr %t1241, { i64, ptr } %t1240)
  store { i64, ptr } %t1243, ptr %l479
  br label %bb205
bb205:
  %t1244 = load { i64, ptr }, ptr %l479, !tbaa !27
  store { i64, ptr } %t1244, ptr %l470, !tbaa !27
  br label %bb206
bb206:
  %t1245 = load { i64, ptr }, ptr %l470, !tbaa !27
  store { i64, ptr } %t1245, ptr %l50, !tbaa !27
  %t1246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1246, ptr %l480, !tbaa !29
  %t1247 = getelementptr %"compiler/cabi:Way", ptr %l10, i32 0, i32 1
  %t1248 = load i64, ptr %l48, !tbaa !24
  %t1251 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t1247, i64 %t1248)
  store { i64, ptr } %t1251, ptr %l483
  br label %bb207
bb207:
  %t1252 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1253 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1254 = load ptr, ptr %l480, !tbaa !29
  %t1255 = load { i64, ptr }, ptr %l483, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s36, ptr %s36, ptr %s36, ptr %t1254, { i64, ptr } %t1255, { i64, ptr } %t1252, { i64, ptr } %t1253, { i64, ptr } { i64 0, ptr @.d104 })
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s36)
  br label %bb209
bb209:
  %t1258 = load i64, ptr %l47, !tbaa !24
  %t1260 = add i64 %t1258, 1
  store i64 %t1260, ptr %l47, !tbaa !24
  br label %bb192
bb210:
  %t1262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1262, ptr %l488, !tbaa !29
  %t1263 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t1263, ptr %l489, !tbaa !27
  %t1264 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t1264, ptr %l490, !tbaa !27
  %t1265 = load ptr, ptr %l0, !tbaa !29
  %t1266 = load i32, ptr %l5, !tbaa !23
  %t1269 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1265, i32 %t1266)
  store i64 %t1269, ptr %l493
  br label %bb211
bb211:
  %t1270 = load ptr, ptr %l488, !tbaa !29
  %t1271 = load { i64, ptr }, ptr %l489, !tbaa !27
  %t1272 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t1273 = load i64, ptr %l493, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s31, ptr %s33, ptr %t1270, { i64, ptr } %t1271, { i64, ptr } %t1272, i64 %t1273)
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s33)
  br label %bb220
bb213:
  br i1 true, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb219
bb216:
  %t1274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1274, ptr %l494, !tbaa !29
  %t1275 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t1275, ptr %l495, !tbaa !27
  %t1276 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t1276, ptr %l496, !tbaa !27
  %t1277 = load ptr, ptr %l0, !tbaa !29
  %t1278 = load i32, ptr %l5, !tbaa !23
  %t1281 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1277, i32 %t1278)
  store i64 %t1281, ptr %l499
  br label %bb217
bb217:
  %t1282 = load ptr, ptr %l494, !tbaa !29
  %t1283 = load { i64, ptr }, ptr %l495, !tbaa !27
  %t1284 = load { i64, ptr }, ptr %l496, !tbaa !27
  %t1285 = load i64, ptr %l499, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s31, ptr %s0, ptr %t1282, { i64, ptr } %t1283, { i64, ptr } %t1284, i64 %t1285)
  br label %bb218
bb218:
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @olang_loc_abf674e0f035191f_fe40c9b44f4d0b8b)
  unreachable
bb220:
  call void @__olang_scope_close(ptr %s31)
  br label %bb221
bb221:
  %t1286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1286, ptr %l500, !tbaa !29
  %t1287 = getelementptr %"compiler/mir:Call", ptr %l1, i32 0, i32 5
  %t1288 = load i32, ptr %t1287, !tbaa !23
  %t1290 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %t1288)
  store { i64, ptr } %t1290, ptr %l502
  br label %bb222
bb222:
  %t1291 = extractvalue { i64, ptr } { i64 10, ptr @.d105 }, 1
  %t1292 = extractvalue { i64, ptr } { i64 10, ptr @.d105 }, 0
  %t1293 = load { i64, ptr }, ptr %l502, !tbaa !27
  %t1294 = extractvalue { i64, ptr } %t1293, 1
  %t1295 = extractvalue { i64, ptr } %t1293, 0
  %t1296 = add i64 %t1292, %t1295
  %t1297 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1296)
  call void @olang_textcopy(ptr %t1297, ptr %t1291, i64 %t1292)
  %t1298 = getelementptr i8, ptr %t1297, i64 %t1292
  call void @olang_textcopy(ptr %t1298, ptr %t1294, i64 %t1295)
  %t1299 = insertvalue { i64, ptr } undef, i64 %t1296, 0
  %t1300 = insertvalue { i64, ptr } %t1299, ptr %t1297, 1
  %t1302 = extractvalue { i64, ptr } %t1300, 0
  %t1303 = extractvalue { i64, ptr } %t1300, 1
  %t1304 = mul i64 %t1302, 1
  %t1305 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1305, ptr %t1303, i64 %t1304, i1 false)
  %t1306 = insertvalue { i64, ptr } undef, i64 %t1302, 0
  %t1307 = insertvalue { i64, ptr } %t1306, ptr %t1305, 1
  %t1308 = load ptr, ptr %l500, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1308, { i64, ptr } %t1307)
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load i32, ptr %l8
  %t16 = trunc i64 24 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb4
bb3:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l17
  br label %bb5
bb4:
  %t29 = load i32, ptr %l14, !tbaa !23
  store i32 %t29, ptr %l11, !tbaa !23
  br label %bb6
bb5:
  %t30 = load i32, ptr %l17, !tbaa !23
  store i32 %t30, ptr %l11, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l11, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eclosure(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/mir:Range" %a4, %"compiler/mir:Range" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, [1 x i64] }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca %"std/prelude/text:StringBuilder"
  %l67 = alloca i32
  %l70 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l98 = alloca { i64, [4 x i64] }
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l150 = alloca i64
  %l156 = alloca i32
  %l159 = alloca i32
  %l181 = alloca { i64, [4 x i64] }
  %l184 = alloca i32
  %l191 = alloca { i64, ptr }
  %l194 = alloca i1
  %l199 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l216 = alloca i64
  %l219 = alloca i64
  %l237 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i64
  %l240 = alloca { i64, ptr }
  %l252 = alloca { i64, [1 x i64] }
  %l253 = alloca i1
  %l260 = alloca { i64, ptr }
  %l262 = alloca i64
  %l265 = alloca i1
  %l273 = alloca ptr
  %l274 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store %"compiler/mir:Range" %a4, ptr %l4
  store %"compiler/mir:Range" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load { i64, [1 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t4, { i64, [1 x i64] } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/emit:fnEm", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t12 = load { i64, [1 x i64] }, ptr %l1
  %t17 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeFor(ptr %v0, ptr %s0, ptr %t11, { i64, [1 x i64] } %t12, i32 %a2)
  store { i64, ptr } %t17, ptr %l50
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 4, ptr @.d106 }, ptr %l51, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t19, ptr %l52, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l53, !tbaa !24
  %t22 = load i64, ptr %l53, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l54, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l53, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t33, ptr %l7, !tbaa !27
  %t34 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = icmp sgt i32 %t35, 0
  br i1 %t37, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load { i64, [1 x i64] }, ptr %l1
  %t46 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %t42, { i64, [1 x i64] } %t43)
  store i64 %t46, ptr %l60
  br label %bb5
bb4:
  br label %bb112
bb5:
  %t47 = load i64, ptr %l60, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  %t48 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t48, ptr %l61
  br label %bb6
bb6:
  %t49 = load %"std/prelude/text:StringBuilder", ptr %l61
  store %"std/prelude/text:StringBuilder" %t49, ptr %l9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s1, ptr %l9, { i64, ptr } { i64 2, ptr @.d107 })
  br label %bb7
bb7:
  store i32 0, ptr %l10, !tbaa !23
  %t51 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t54 = load i32, ptr %l11, !tbaa !23
  %t55 = load i32, ptr %l10, !tbaa !23
  %t58 = icmp sgt i32 %t54, %t55
  br i1 %t58, label %bb8, label %bb9
bb8:
  %t60 = load i32, ptr %l12, !tbaa !23
  %t62 = icmp sgt i32 %t60, 0
  br i1 %t62, label %bb10, label %bb11
bb9:
  store i32 0, ptr %l67, !tbaa !23
  br label %bb13
bb10:
  %t64 = load i32, ptr %l11, !tbaa !23
  %t65 = load i32, ptr %l10, !tbaa !23
  %t68 = sub i32 %t64, %t65
  %t69 = load i32, ptr %l12, !tbaa !23
  %t72 = add i32 %t68, %t69
  %t74 = sub i32 %t72, 1
  %t75 = load i32, ptr %l12, !tbaa !23
  %t78 = sdiv i32 %t74, %t75
  store i32 %t78, ptr %l70, !tbaa !23
  br label %bb12
bb11:
  store i32 0, ptr %l70, !tbaa !23
  br label %bb12
bb12:
  %t80 = load i32, ptr %l70, !tbaa !23
  store i32 %t80, ptr %l67, !tbaa !23
  br label %bb13
bb13:
  %t81 = load i32, ptr %l67, !tbaa !23
  store i32 %t81, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load i32, ptr %l14, !tbaa !23
  %t83 = load i32, ptr %l13, !tbaa !23
  %t86 = icmp slt i32 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t90 = load i32, ptr %l10, !tbaa !23
  %t91 = load i32, ptr %l14, !tbaa !23
  %t92 = load i32, ptr %l12, !tbaa !23
  %t95 = mul i32 %t91, %t92
  %t98 = add i32 %t90, %t95
  store i32 %t98, ptr %l15, !tbaa !23
  %t100 = load i32, ptr %l15, !tbaa !23
  %t102 = icmp sgt i32 %t100, 0
  br i1 %t102, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s4, ptr %l9, { i64, ptr } { i64 2, ptr @.d108 })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  store ptr %l9, ptr %l91, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l92, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l93, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/mir:Range", ptr %l4
  %t109 = load i32, ptr %l15, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t115 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t107, %"compiler/mir:Range" %t108, i64 %t111)
  store { i64, [4 x i64] } %t115, ptr %l98
  br label %bb22
bb22:
  %t116 = load ptr, ptr %l93, !tbaa !29
  %t117 = load { i64, [4 x i64] }, ptr %l98
  %t118 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t116, { i64, [4 x i64] } %t117)
  store i32 %t118, ptr %l99
  br label %bb23
bb23:
  %t119 = load ptr, ptr %l92, !tbaa !29
  %t120 = load i32, ptr %l99, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t121, ptr %l100
  br label %bb24
bb24:
  %t122 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  %t124 = extractvalue { i64, ptr } %t122, 1
  %t125 = mul i64 %t123, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t124, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s3, ptr %t129, { i64, ptr } %t128)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t131 = load i32, ptr %l14, !tbaa !23
  %t133 = add i32 %t131, 1
  store i32 %t133, ptr %l14, !tbaa !23
  br label %bb14
bb27:
  store i64 0, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  store i64 %t135, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t137 = load i64, ptr %l17, !tbaa !24
  %t138 = load i64, ptr %l16, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb28, label %bb29
bb28:
  %t143 = load i64, ptr %l18, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb33
bb30:
  %t147 = load i64, ptr %l17, !tbaa !24
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l18, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l18, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l111, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb32
bb32:
  %t163 = load i64, ptr %l111, !tbaa !24
  store i64 %t163, ptr %l108, !tbaa !24
  br label %bb33
bb33:
  %t164 = load i64, ptr %l108, !tbaa !24
  store i64 %t164, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load i64, ptr %l20, !tbaa !24
  %t166 = load i64, ptr %l19, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t173 = load i64, ptr %l16, !tbaa !24
  %t174 = load i64, ptr %l20, !tbaa !24
  %t175 = load i64, ptr %l18, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l21, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s7, ptr %l9, { i64, ptr } { i64 5, ptr @.d109 })
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb39:
  %t184 = load i64, ptr %l20, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l20, !tbaa !24
  br label %bb34
bb40:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s1, ptr %l9, { i64, ptr } { i64 2, ptr @.d110 })
  br label %bb41
bb41:
  %t190 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %s1, ptr %l9)
  store { i64, ptr } %t190, ptr %l134
  br label %bb42
bb42:
  %t191 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t191, ptr %l22, !tbaa !27
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l135, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t195 = extractvalue { i64, ptr } { i64 14, ptr @.d111 }, 1
  %t196 = extractvalue { i64, ptr } { i64 14, ptr @.d111 }, 0
  %t198 = extractvalue { i64, ptr } %t194, 1
  %t199 = extractvalue { i64, ptr } %t194, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 17, ptr @.d112 }, 1
  %t202 = extractvalue { i64, ptr } { i64 17, ptr @.d112 }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t195, i64 %t196)
  %t205 = getelementptr i8, ptr %t204, i64 %t196
  call void @olang_textcopy(ptr %t205, ptr %t198, i64 %t199)
  %t206 = getelementptr i8, ptr %t205, i64 %t199
  call void @olang_textcopy(ptr %t206, ptr %t201, i64 %t202)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t204, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = extractvalue { i64, ptr } %t208, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t218 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t193, { i64, ptr } %t215)
  store { i64, ptr } %t218, ptr %l140
  br label %bb43
bb43:
  %t219 = extractvalue { i64, ptr } { i64 13, ptr @.d113 }, 1
  %t220 = extractvalue { i64, ptr } { i64 13, ptr @.d113 }, 0
  %t221 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 7, ptr @.d114 }, 1
  %t226 = extractvalue { i64, ptr } { i64 7, ptr @.d114 }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t222, i64 %t223)
  %t230 = getelementptr i8, ptr %t229, i64 %t223
  call void @olang_textcopy(ptr %t230, ptr %t225, i64 %t226)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t228, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t240 = load ptr, ptr %l135, !tbaa !29
  %t242 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t240, { i64, ptr } %t239)
  store { i64, ptr } %t242, ptr %l143
  br label %bb44
bb44:
  %t243 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t252 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %s1, ptr %s1, ptr %s0, ptr %t244, { i64, [1 x i64] } %a3, { i64, ptr } %t243, i64 8, { i64, ptr } %t247)
  store { i64, ptr } %t252, ptr %l148
  br label %bb45
bb45:
  %t253 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t255 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 0
  store i64 %t256, ptr %l150, !tbaa !24
  %t258 = load i64, ptr %l150, !tbaa !24
  %t259 = icmp eq i64 %t254, %t258
  br i1 %t259, label %bb46, label %bb47
bb46:
  %t261 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l150, !tbaa !24
  %t266 = mul i64 %t265, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %t264, i64 %t266, i1 false)
  br label %bb48
bb47:
  %t267 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t267, ptr %l7, !tbaa !27
  br label %bb48
bb48:
  store i32 0, ptr %l24, !tbaa !23
  %t268 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t269 = load i32, ptr %t268, !tbaa !23
  store i32 %t269, ptr %l25, !tbaa !23
  store i32 1, ptr %l26, !tbaa !23
  %t271 = load i32, ptr %l25, !tbaa !23
  %t272 = load i32, ptr %l24, !tbaa !23
  %t275 = icmp sgt i32 %t271, %t272
  br i1 %t275, label %bb49, label %bb50
bb49:
  %t277 = load i32, ptr %l26, !tbaa !23
  %t279 = icmp sgt i32 %t277, 0
  br i1 %t279, label %bb51, label %bb52
bb50:
  store i32 0, ptr %l156, !tbaa !23
  br label %bb54
bb51:
  %t281 = load i32, ptr %l25, !tbaa !23
  %t282 = load i32, ptr %l24, !tbaa !23
  %t285 = sub i32 %t281, %t282
  %t286 = load i32, ptr %l26, !tbaa !23
  %t289 = add i32 %t285, %t286
  %t291 = sub i32 %t289, 1
  %t292 = load i32, ptr %l26, !tbaa !23
  %t295 = sdiv i32 %t291, %t292
  store i32 %t295, ptr %l159, !tbaa !23
  br label %bb53
bb52:
  store i32 0, ptr %l159, !tbaa !23
  br label %bb53
bb53:
  %t297 = load i32, ptr %l159, !tbaa !23
  store i32 %t297, ptr %l156, !tbaa !23
  br label %bb54
bb54:
  %t298 = load i32, ptr %l156, !tbaa !23
  store i32 %t298, ptr %l27, !tbaa !23
  store i32 0, ptr %l28, !tbaa !23
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t299 = load i32, ptr %l28, !tbaa !23
  %t300 = load i32, ptr %l27, !tbaa !23
  %t303 = icmp slt i32 %t299, %t300
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb71
bb57:
  br label %bb58
bb58:
  %t307 = load i32, ptr %l24, !tbaa !23
  %t308 = load i32, ptr %l28, !tbaa !23
  %t309 = load i32, ptr %l26, !tbaa !23
  %t312 = mul i32 %t308, %t309
  %t315 = add i32 %t307, %t312
  store i32 %t315, ptr %l29, !tbaa !23
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load %"compiler/mir:Range", ptr %l4
  %t319 = load i32, ptr %l29, !tbaa !23
  %t321 = sext i32 %t319 to i64
  %t325 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t317, %"compiler/mir:Range" %t318, i64 %t321)
  store { i64, [4 x i64] } %t325, ptr %l181
  br label %bb59
bb59:
  %t326 = load { i64, [4 x i64] }, ptr %l181
  store { i64, [4 x i64] } %t326, ptr %l30
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load { i64, [4 x i64] }, ptr %l30
  %t331 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t327, { i64, [4 x i64] } %t328)
  store i32 %t331, ptr %l184
  br label %bb60
bb60:
  %t332 = load i32, ptr %l184, !tbaa !23
  store i32 %t332, ptr %l31, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t336 = load i32, ptr %l29, !tbaa !23
  %t337 = extractvalue { i64, ptr } { i64 14, ptr @.d115 }, 1
  %t338 = extractvalue { i64, ptr } { i64 14, ptr @.d115 }, 0
  %t340 = extractvalue { i64, ptr } %t334, 1
  %t341 = extractvalue { i64, ptr } %t334, 0
  %t342 = add i64 %t338, %t341
  %t343 = extractvalue { i64, ptr } { i64 6, ptr @.d116 }, 1
  %t344 = extractvalue { i64, ptr } { i64 6, ptr @.d116 }, 0
  %t345 = add i64 %t342, %t344
  %t347 = extractvalue { i64, ptr } %t335, 1
  %t348 = extractvalue { i64, ptr } %t335, 0
  %t349 = add i64 %t345, %t348
  %t350 = extractvalue { i64, ptr } { i64 13, ptr @.d117 }, 1
  %t351 = extractvalue { i64, ptr } { i64 13, ptr @.d117 }, 0
  %t352 = add i64 %t349, %t351
  %t354 = sext i32 %t336 to i64
  %t355 = call i64 @__olang_fmt_i64(ptr null, i64 %t354)
  %t356 = add i64 %t352, %t355
  %t357 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t356)
  call void @olang_textcopy(ptr %t357, ptr %t337, i64 %t338)
  %t358 = getelementptr i8, ptr %t357, i64 %t338
  call void @olang_textcopy(ptr %t358, ptr %t340, i64 %t341)
  %t359 = getelementptr i8, ptr %t358, i64 %t341
  call void @olang_textcopy(ptr %t359, ptr %t343, i64 %t344)
  %t360 = getelementptr i8, ptr %t359, i64 %t344
  call void @olang_textcopy(ptr %t360, ptr %t347, i64 %t348)
  %t361 = getelementptr i8, ptr %t360, i64 %t348
  call void @olang_textcopy(ptr %t361, ptr %t350, i64 %t351)
  %t362 = getelementptr i8, ptr %t361, i64 %t351
  %t363 = call i64 @__olang_fmt_i64(ptr %t362, i64 %t354)
  %t364 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t357, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  %t375 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s12, ptr %s12, ptr %t333, { i64, ptr } %t372)
  store { i64, ptr } %t375, ptr %l191
  br label %bb61
bb61:
  %t376 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t376, ptr %l32, !tbaa !27
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i32, ptr %l31, !tbaa !23
  %t381 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t377, i32 %t378)
  store i1 %t381, ptr %l194
  br label %bb62
bb62:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t385 = load i32, ptr %l31, !tbaa !23
  %t386 = load { i64, [4 x i64] }, ptr %l30
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s12, ptr %s14, ptr %t383, { i64, ptr } %t384, i32 %t385, { i64, [4 x i64] } %t386, { i64, ptr } { i64 0, ptr @.d71 })
  br label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l199, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load i32, ptr %l31, !tbaa !23
  %t396 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s15, ptr %t392, i32 %t393)
  store { i64, ptr } %t396, ptr %l202
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb66:
  %t397 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 0
  %t399 = extractvalue { i64, ptr } %t397, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  store { i64, ptr } %t403, ptr %l203, !tbaa !27
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, [4 x i64] }, ptr %l30
  %t406 = load i32, ptr %l31, !tbaa !23
  %t410 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s15, ptr %t404, { i64, [4 x i64] } %t405, i32 %t406)
  store { i64, ptr } %t410, ptr %l207
  br label %bb67
bb67:
  %t411 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 0
  %t413 = extractvalue { i64, ptr } %t411, 1
  %t414 = mul i64 %t412, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  %t418 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t419 = load ptr, ptr %l199, !tbaa !29
  %t420 = load { i64, ptr }, ptr %l203, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s15, ptr %s12, ptr %s15, ptr %t419, { i64, ptr } %t420, { i64, ptr } %t417, { i64, ptr } %t418, { i64, ptr } { i64 11, ptr @.d118 })
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s12)
  br label %bb70
bb70:
  %t423 = load i32, ptr %l28, !tbaa !23
  %t425 = add i32 %t423, 1
  store i32 %t425, ptr %l28, !tbaa !23
  br label %bb55
bb71:
  store i64 0, ptr %l33, !tbaa !24
  %t427 = load i64, ptr %l8, !tbaa !24
  store i64 %t427, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t429 = load i64, ptr %l34, !tbaa !24
  %t430 = load i64, ptr %l33, !tbaa !24
  %t433 = icmp sgt i64 %t429, %t430
  br i1 %t433, label %bb72, label %bb73
bb72:
  %t435 = load i64, ptr %l35, !tbaa !24
  %t437 = icmp sgt i64 %t435, 0
  br i1 %t437, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb77
bb74:
  %t439 = load i64, ptr %l34, !tbaa !24
  %t440 = load i64, ptr %l33, !tbaa !24
  %t443 = sub i64 %t439, %t440
  %t444 = load i64, ptr %l35, !tbaa !24
  %t447 = add i64 %t443, %t444
  %t449 = sub i64 %t447, 1
  %t450 = load i64, ptr %l35, !tbaa !24
  %t453 = sdiv i64 %t449, %t450
  store i64 %t453, ptr %l219, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb76
bb76:
  %t455 = load i64, ptr %l219, !tbaa !24
  store i64 %t455, ptr %l216, !tbaa !24
  br label %bb77
bb77:
  %t456 = load i64, ptr %l216, !tbaa !24
  store i64 %t456, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  %t457 = load i64, ptr %l37, !tbaa !24
  %t458 = load i64, ptr %l36, !tbaa !24
  %t461 = icmp slt i64 %t457, %t458
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s18)
  br label %bb111
bb80:
  br label %bb81
bb81:
  %t465 = load i64, ptr %l33, !tbaa !24
  %t466 = load i64, ptr %l37, !tbaa !24
  %t467 = load i64, ptr %l35, !tbaa !24
  %t470 = mul i64 %t466, %t467
  %t473 = add i64 %t465, %t470
  store i64 %t473, ptr %l38, !tbaa !24
  store { i64, ptr } { i64 4, ptr @.d119 }, ptr %l237, !tbaa !27
  %t475 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t475, ptr %l238, !tbaa !27
  %t476 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  store i64 %t477, ptr %l239, !tbaa !24
  %t478 = load i64, ptr %l239, !tbaa !24
  %t479 = mul i64 %t478, 1
  %t480 = call ptr @__olang_scope_alloc_zeroed(ptr %s18, i64 %t479)
  %t481 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  store { i64, ptr } %t482, ptr %l240, !tbaa !27
  %t483 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !27
  %t485 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = load i64, ptr %l239, !tbaa !24
  %t488 = mul i64 %t487, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t484, ptr %t486, i64 %t488, i1 false)
  %t489 = load { i64, ptr }, ptr %l240, !tbaa !27
  store { i64, ptr } %t489, ptr %l39, !tbaa !27
  %t490 = load i64, ptr %l38, !tbaa !24
  %t491 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t492 = load i32, ptr %t491, !tbaa !23
  %t494 = sext i32 %t492 to i64
  %t497 = icmp slt i64 %t490, %t494
  br i1 %t497, label %bb82, label %bb83
bb82:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/emit:fnEm", ptr %t499, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !29
  %t504 = getelementptr %"compiler/mir:Fn", ptr %t502, i32 0, i32 12
  %t505 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 0
  %t506 = load i32, ptr %t505, !tbaa !23
  %t508 = sext i32 %t506 to i64
  %t509 = load i64, ptr %l38, !tbaa !24
  %t512 = add i64 %t508, %t509
  %t515 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t504, i64 %t512)
  store { i64, [1 x i64] } %t515, ptr %l252
  br label %bb84
bb83:
  br label %bb101
bb84:
  %t516 = load { i64, [1 x i64] }, ptr %l252
  store { i64, [1 x i64] } %t516, ptr %l40
  %t517 = load { i64, [1 x i64] }, ptr %l40
  %t519 = extractvalue { i64, [1 x i64] } %t517, 0
  %t520 = icmp eq i64 %t519, 2
  br i1 %t520, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store i1 true, ptr %l253, !tbaa !21
  br label %bb93
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  store i1 false, ptr %l253, !tbaa !21
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_4c53df269225a815_e91774848fc42cb1)
  unreachable
bb93:
  %t522 = load i1, ptr %l253, !tbaa !21
  %t525 = xor i1 %t522, true
  br i1 %t525, label %bb94, label %bb95
bb94:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load { i64, [1 x i64] }, ptr %l40
  %t531 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s18, ptr %t527, { i64, [1 x i64] } %t528)
  store { i64, ptr } %t531, ptr %l260
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t532 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  %t534 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 0
  store i64 %t535, ptr %l262, !tbaa !24
  %t537 = load i64, ptr %l262, !tbaa !24
  %t538 = icmp eq i64 %t533, %t537
  br i1 %t538, label %bb97, label %bb98
bb97:
  %t540 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = load i64, ptr %l262, !tbaa !24
  %t545 = mul i64 %t544, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t541, ptr %t543, i64 %t545, i1 false)
  br label %bb99
bb98:
  %t546 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t546, ptr %l39, !tbaa !27
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t547 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t549 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %s18, { i64, ptr } %t547, { i64, ptr } { i64 4, ptr @.d120 })
  store i1 %t549, ptr %l265
  br label %bb102
bb102:
  %t550 = load i1, ptr %l265, !tbaa !21
  %t551 = xor i1 %t550, true
  br i1 %t551, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s23
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/emit:fnEm", ptr %t553, i32 0, i32 0
  %t556 = load ptr, ptr %t555, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s23, ptr %t556, { i64, ptr } { i64 20, ptr @.d121 })
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t560 = extractvalue { i64, ptr } { i64 36, ptr @.d122 }, 1
  %t561 = extractvalue { i64, ptr } { i64 36, ptr @.d122 }, 0
  %t563 = extractvalue { i64, ptr } %t559, 1
  %t564 = extractvalue { i64, ptr } %t559, 0
  %t565 = add i64 %t561, %t564
  %t566 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 1
  %t567 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 0
  %t568 = add i64 %t565, %t567
  %t569 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t568)
  call void @olang_textcopy(ptr %t569, ptr %t560, i64 %t561)
  %t570 = getelementptr i8, ptr %t569, i64 %t561
  call void @olang_textcopy(ptr %t570, ptr %t563, i64 %t564)
  %t571 = getelementptr i8, ptr %t570, i64 %t564
  call void @olang_textcopy(ptr %t571, ptr %t566, i64 %t567)
  %t572 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t569, 1
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t576 = extractvalue { i64, ptr } %t573, 1
  %t577 = mul i64 %t575, 1
  %t578 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t576, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s23, ptr %t558, { i64, ptr } %t580)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s23)
  br label %bb107
bb107:
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l273, !tbaa !29
  %t584 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t584, ptr %l274, !tbaa !27
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t587 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t588 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t589 = load i32, ptr %t588, !tbaa !23
  %t591 = sext i32 %t589 to i64
  %t592 = load i64, ptr %l38, !tbaa !24
  %t595 = add i64 %t591, %t592
  %t596 = extractvalue { i64, ptr } { i64 14, ptr @.d124 }, 1
  %t597 = extractvalue { i64, ptr } { i64 14, ptr @.d124 }, 0
  %t599 = extractvalue { i64, ptr } %t586, 1
  %t600 = extractvalue { i64, ptr } %t586, 0
  %t601 = add i64 %t597, %t600
  %t602 = extractvalue { i64, ptr } { i64 6, ptr @.d125 }, 1
  %t603 = extractvalue { i64, ptr } { i64 6, ptr @.d125 }, 0
  %t604 = add i64 %t601, %t603
  %t606 = extractvalue { i64, ptr } %t587, 1
  %t607 = extractvalue { i64, ptr } %t587, 0
  %t608 = add i64 %t604, %t607
  %t609 = extractvalue { i64, ptr } { i64 13, ptr @.d126 }, 1
  %t610 = extractvalue { i64, ptr } { i64 13, ptr @.d126 }, 0
  %t611 = add i64 %t608, %t610
  %t613 = call i64 @__olang_fmt_i64(ptr null, i64 %t595)
  %t614 = add i64 %t611, %t613
  %t615 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t614)
  call void @olang_textcopy(ptr %t615, ptr %t596, i64 %t597)
  %t616 = getelementptr i8, ptr %t615, i64 %t597
  call void @olang_textcopy(ptr %t616, ptr %t599, i64 %t600)
  %t617 = getelementptr i8, ptr %t616, i64 %t600
  call void @olang_textcopy(ptr %t617, ptr %t602, i64 %t603)
  %t618 = getelementptr i8, ptr %t617, i64 %t603
  call void @olang_textcopy(ptr %t618, ptr %t606, i64 %t607)
  %t619 = getelementptr i8, ptr %t618, i64 %t607
  call void @olang_textcopy(ptr %t619, ptr %t609, i64 %t610)
  %t620 = getelementptr i8, ptr %t619, i64 %t610
  %t621 = call i64 @__olang_fmt_i64(ptr %t620, i64 %t595)
  %t622 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t615, 1
  %t625 = extractvalue { i64, ptr } %t623, 0
  %t626 = extractvalue { i64, ptr } %t623, 1
  %t627 = mul i64 %t625, 1
  %t628 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t627)
  call void @llvm.memcpy.p0.p0.i64(ptr %t628, ptr %t626, i64 %t627, i1 false)
  %t629 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t630 = insertvalue { i64, ptr } %t629, ptr %t628, 1
  %t633 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s18, ptr %s18, ptr %t585, { i64, ptr } %t630)
  store { i64, ptr } %t633, ptr %l284
  br label %bb108
bb108:
  %t634 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t635 = extractvalue { i64, ptr } %t634, 0
  %t636 = extractvalue { i64, ptr } %t634, 1
  %t637 = mul i64 %t635, 1
  %t638 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t637)
  call void @llvm.memcpy.p0.p0.i64(ptr %t638, ptr %t636, i64 %t637, i1 false)
  %t639 = insertvalue { i64, ptr } undef, i64 %t635, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t638, 1
  %t641 = load ptr, ptr %l273, !tbaa !29
  %t642 = load { i64, ptr }, ptr %l274, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s18, ptr %s18, ptr %s18, ptr %s18, ptr %t641, { i64, ptr } { i64 3, ptr @.d127 }, { i64, ptr } %t642, { i64, ptr } %t640, { i64, ptr } { i64 11, ptr @.d128 })
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s18)
  br label %bb110
bb110:
  %t644 = load i64, ptr %l37, !tbaa !24
  %t646 = add i64 %t644, 1
  store i64 %t646, ptr %l37, !tbaa !24
  br label %bb78
bb111:
  call void @__olang_scope_close(ptr %s1)
  br label %bb112
bb112:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t650 = extractvalue { i64, ptr } { i64 37, ptr @.d129 }, 1
  %t651 = extractvalue { i64, ptr } { i64 37, ptr @.d129 }, 0
  %t653 = extractvalue { i64, ptr } %t649, 1
  %t654 = extractvalue { i64, ptr } %t649, 0
  %t655 = add i64 %t651, %t654
  %t656 = extractvalue { i64, ptr } { i64 3, ptr @.d130 }, 1
  %t657 = extractvalue { i64, ptr } { i64 3, ptr @.d130 }, 0
  %t658 = add i64 %t655, %t657
  %t659 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t650, i64 %t651)
  %t660 = getelementptr i8, ptr %t659, i64 %t651
  call void @olang_textcopy(ptr %t660, ptr %t653, i64 %t654)
  %t661 = getelementptr i8, ptr %t660, i64 %t654
  call void @olang_textcopy(ptr %t661, ptr %t656, i64 %t657)
  %t662 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t659, 1
  %t665 = extractvalue { i64, ptr } %t663, 0
  %t666 = extractvalue { i64, ptr } %t663, 1
  %t667 = mul i64 %t665, 1
  %t668 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t667)
  call void @llvm.memcpy.p0.p0.i64(ptr %t668, ptr %t666, i64 %t667, i1 false)
  %t669 = insertvalue { i64, ptr } undef, i64 %t665, 0
  %t670 = insertvalue { i64, ptr } %t669, ptr %t668, 1
  %t673 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t648, { i64, ptr } %t670)
  store { i64, ptr } %t673, ptr %l292
  br label %bb113
bb113:
  %t674 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t678 = extractvalue { i64, ptr } { i64 25, ptr @.d131 }, 1
  %t679 = extractvalue { i64, ptr } { i64 25, ptr @.d131 }, 0
  %t681 = extractvalue { i64, ptr } %t674, 1
  %t682 = extractvalue { i64, ptr } %t674, 0
  %t683 = add i64 %t679, %t682
  %t684 = extractvalue { i64, ptr } { i64 6, ptr @.d132 }, 1
  %t685 = extractvalue { i64, ptr } { i64 6, ptr @.d132 }, 0
  %t686 = add i64 %t683, %t685
  %t688 = extractvalue { i64, ptr } %t677, 1
  %t689 = extractvalue { i64, ptr } %t677, 0
  %t690 = add i64 %t686, %t689
  %t691 = extractvalue { i64, ptr } { i64 3, ptr @.d133 }, 1
  %t692 = extractvalue { i64, ptr } { i64 3, ptr @.d133 }, 0
  %t693 = add i64 %t690, %t692
  %t694 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t693)
  call void @olang_textcopy(ptr %t694, ptr %t678, i64 %t679)
  %t695 = getelementptr i8, ptr %t694, i64 %t679
  call void @olang_textcopy(ptr %t695, ptr %t681, i64 %t682)
  %t696 = getelementptr i8, ptr %t695, i64 %t682
  call void @olang_textcopy(ptr %t696, ptr %t684, i64 %t685)
  %t697 = getelementptr i8, ptr %t696, i64 %t685
  call void @olang_textcopy(ptr %t697, ptr %t688, i64 %t689)
  %t698 = getelementptr i8, ptr %t697, i64 %t689
  call void @olang_textcopy(ptr %t698, ptr %t691, i64 %t692)
  %t699 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t694, 1
  %t702 = extractvalue { i64, ptr } %t700, 0
  %t703 = extractvalue { i64, ptr } %t700, 1
  %t704 = mul i64 %t702, 1
  %t705 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t704)
  call void @llvm.memcpy.p0.p0.i64(ptr %t705, ptr %t703, i64 %t704, i1 false)
  %t706 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  %t710 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t675, { i64, ptr } %t707)
  store { i64, ptr } %t710, ptr %l298
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s0)
  %t711 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t711, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i8
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i64
  %l32 = alloca { i64, [1 x i64] }
  %l36 = alloca %"std/prelude/text:StringBuilder"
  %l41 = alloca i32
  %l44 = alloca i32
  %l70 = alloca i8
  %l74 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i8
  %l87 = alloca i64
  %l88 = alloca i32
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca %"std/prelude/text:StringBuilder"
  %l120 = alloca i32
  %l123 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca i32
  %l159 = alloca i32
  %l160 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l173 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 19
  %t17 = sext i32 %a2 to i64
  %t20 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t14, i64 %t17)
  store { i64, [1 x i64] } %t20, ptr %l32
  br label %bb1
bb1:
  %t21 = load { i64, [1 x i64] }, ptr %l32
  store { i64, [1 x i64] } %t21, ptr %l4
  %t22 = load { i64, [1 x i64] }, ptr %l4
  %t24 = extractvalue { i64, [1 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 1
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t28 = getelementptr { %"compiler/mir:Range" }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/mir:Range", ptr %t28
  store %"compiler/mir:Range" %t29, ptr %l5
  br label %bb4
bb3:
  br label %bb40
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t31, ptr %l36
  br label %bb5
bb5:
  %t32 = load %"std/prelude/text:StringBuilder", ptr %l36
  store %"std/prelude/text:StringBuilder" %t32, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t33 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l8, !tbaa !23
  store i32 1, ptr %l9, !tbaa !23
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = load i32, ptr %l7, !tbaa !23
  %t40 = icmp sgt i32 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load i32, ptr %l9, !tbaa !23
  %t44 = icmp sgt i32 %t42, 0
  br i1 %t44, label %bb8, label %bb9
bb7:
  store i32 0, ptr %l41, !tbaa !23
  br label %bb11
bb8:
  %t46 = load i32, ptr %l8, !tbaa !23
  %t47 = load i32, ptr %l7, !tbaa !23
  %t50 = sub i32 %t46, %t47
  %t51 = load i32, ptr %l9, !tbaa !23
  %t54 = add i32 %t50, %t51
  %t56 = sub i32 %t54, 1
  %t57 = load i32, ptr %l9, !tbaa !23
  %t60 = sdiv i32 %t56, %t57
  store i32 %t60, ptr %l44, !tbaa !23
  br label %bb10
bb9:
  store i32 0, ptr %l44, !tbaa !23
  br label %bb10
bb10:
  %t62 = load i32, ptr %l44, !tbaa !23
  store i32 %t62, ptr %l41, !tbaa !23
  br label %bb11
bb11:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  store i32 0, ptr %l11, !tbaa !23
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load i32, ptr %l11, !tbaa !23
  %t65 = load i32, ptr %l10, !tbaa !23
  %t68 = icmp slt i32 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb14:
  br label %bb15
bb15:
  %t72 = load i32, ptr %l7, !tbaa !23
  %t73 = load i32, ptr %l11, !tbaa !23
  %t74 = load i32, ptr %l9, !tbaa !23
  %t77 = mul i32 %t73, %t74
  %t80 = add i32 %t72, %t77
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:fnEm", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/mir:Fn", ptr %t85, i32 0, i32 21
  %t88 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t91 = sext i32 %t89 to i64
  %t94 = sext i32 %t80 to i64
  %t97 = add i64 %t91, %t94
  %t100 = call i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t87, i64 %t97)
  store i8 %t100, ptr %l70
  br label %bb16
bb16:
  %t101 = load i8, ptr %l70, !tbaa !22
  store i8 %t101, ptr %l13, !tbaa !22
  %t102 = load i8, ptr %l13, !tbaa !22
  %t105 = icmp eq i8 %t102, 34
  br i1 %t105, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb19
bb18:
  %t107 = load i8, ptr %l13, !tbaa !22
  %t110 = icmp eq i8 %t107, 92
  store i1 %t110, ptr %l74, !tbaa !21
  br label %bb19
bb19:
  %t112 = load i1, ptr %l74, !tbaa !21
  br i1 %t112, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb22
bb21:
  %t113 = load i8, ptr %l13, !tbaa !22
  %t115 = icmp ult i8 %t113, 32
  store i1 %t115, ptr %l78, !tbaa !21
  br label %bb22
bb22:
  %t117 = load i1, ptr %l78, !tbaa !21
  br i1 %t117, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb25
bb24:
  %t118 = load i8, ptr %l13, !tbaa !22
  %t120 = icmp ugt i8 %t118, 126
  store i1 %t120, ptr %l81, !tbaa !21
  br label %bb25
bb25:
  %t122 = load i1, ptr %l81, !tbaa !21
  br i1 %t122, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l6, i8 92)
  br label %bb28
bb27:
  %t124 = load i8, ptr %l13, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l6, i8 %t124)
  br label %bb35
bb28:
  store ptr %l6, ptr %l85, !tbaa !29
  %t128 = load i8, ptr %l13, !tbaa !22
  store i8 %t128, ptr %l86, !tbaa !22
  %t129 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 16)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l88
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb30, label %ok.133
ok.133:
  store i64 %t130, ptr %l87
  br label %bb29
bb29:
  %t134 = load i8, ptr %l86, !tbaa !22
  %t135 = load i64, ptr %l87, !tbaa !24
  %t136 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s4, i8 %t134, i64 %t135)
  store { i64, ptr } %t136, ptr %l89
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_617f1f302e56ab61_28fb076f83c3eed5)
  unreachable
bb31:
  %t137 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s4, ptr %s4, { i64, ptr } %t143, i64 2, i8 48)
  store { i64, ptr } %t145, ptr %l91
  br label %bb32
bb32:
  %t146 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %s4, ptr %s4, { i64, ptr } %t152)
  store { i64, ptr } %t154, ptr %l93
  br label %bb33
bb33:
  %t155 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s1, ptr %s4, ptr %t162, { i64, ptr } %t161)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  %t164 = load i32, ptr %l11, !tbaa !23
  %t166 = add i32 %t164, 1
  store i32 %t166, ptr %l11, !tbaa !23
  br label %bb12
bb38:
  %t168 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t169 = load i32, ptr %t168, !tbaa !23
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d134 }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d134 }, 0
  %t173 = sext i32 %t169 to i64
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 6, ptr @.d135 }, 1
  %t177 = extractvalue { i64, ptr } { i64 6, ptr @.d135 }, 0
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t170, i64 %t171)
  %t180 = getelementptr i8, ptr %t179, i64 %t171
  %t181 = call i64 @__olang_fmt_i64(ptr %t180, i64 %t173)
  %t182 = getelementptr i8, ptr %t180, i64 %t174
  call void @olang_textcopy(ptr %t182, ptr %t176, i64 %t177)
  %t183 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t179, 1
  store { i64, ptr } %t184, ptr %l101, !tbaa !27
  %t186 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %s1, ptr %l6)
  store { i64, ptr } %t186, ptr %l103
  br label %bb39
bb39:
  %t187 = extractvalue { i64, ptr } { i64 2, ptr @.d136 }, 1
  %t188 = extractvalue { i64, ptr } { i64 2, ptr @.d136 }, 0
  %t189 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 1
  %t194 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t187, i64 %t188)
  %t197 = getelementptr i8, ptr %t196, i64 %t188
  call void @olang_textcopy(ptr %t197, ptr %t190, i64 %t191)
  %t198 = getelementptr i8, ptr %t197, i64 %t191
  call void @olang_textcopy(ptr %t198, ptr %t193, i64 %t194)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t196, 1
  %t201 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t202 = load i32, ptr %t201, !tbaa !23
  %t204 = sext i32 %t202 to i64
  %t205 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t206 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } undef, { i64, ptr } %t205, 0
  %t208 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t206, { i64, ptr } %t200, 1
  %t210 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t208, i64 %t204, 2
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, { i64, ptr }, i64 } %t210, ptr %rv
  br label %ret
bb40:
  %t212 = load { i64, [1 x i64] }, ptr %l4
  %t214 = extractvalue { i64, [1 x i64] } %t212, 0
  %t215 = icmp eq i64 %t214, 2
  br i1 %t215, label %bb41, label %bb42
bb41:
  %t217 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t218 = getelementptr { %"compiler/mir:Range" }, ptr %t217, i32 0, i32 0
  %t219 = load %"compiler/mir:Range", ptr %t218
  store %"compiler/mir:Range" %t219, ptr %l14
  br label %bb43
bb42:
  br label %bb69
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l1, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s9, ptr %t221, i32 %t222)
  store { i64, ptr } %t225, ptr %l113
  br label %bb44
bb44:
  %t226 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t226, ptr %l15, !tbaa !27
  %t227 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t227, ptr %l114
  br label %bb45
bb45:
  %t228 = load %"std/prelude/text:StringBuilder", ptr %l114
  store %"std/prelude/text:StringBuilder" %t228, ptr %l16
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %l16, i8 91)
  br label %bb46
bb46:
  store i32 0, ptr %l17, !tbaa !23
  %t230 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l18, !tbaa !23
  store i32 1, ptr %l19, !tbaa !23
  %t233 = load i32, ptr %l18, !tbaa !23
  %t234 = load i32, ptr %l17, !tbaa !23
  %t237 = icmp sgt i32 %t233, %t234
  br i1 %t237, label %bb47, label %bb48
bb47:
  %t239 = load i32, ptr %l19, !tbaa !23
  %t241 = icmp sgt i32 %t239, 0
  br i1 %t241, label %bb49, label %bb50
bb48:
  store i32 0, ptr %l120, !tbaa !23
  br label %bb52
bb49:
  %t243 = load i32, ptr %l18, !tbaa !23
  %t244 = load i32, ptr %l17, !tbaa !23
  %t247 = sub i32 %t243, %t244
  %t248 = load i32, ptr %l19, !tbaa !23
  %t251 = add i32 %t247, %t248
  %t253 = sub i32 %t251, 1
  %t254 = load i32, ptr %l19, !tbaa !23
  %t257 = sdiv i32 %t253, %t254
  store i32 %t257, ptr %l123, !tbaa !23
  br label %bb51
bb50:
  store i32 0, ptr %l123, !tbaa !23
  br label %bb51
bb51:
  %t259 = load i32, ptr %l123, !tbaa !23
  store i32 %t259, ptr %l120, !tbaa !23
  br label %bb52
bb52:
  %t260 = load i32, ptr %l120, !tbaa !23
  store i32 %t260, ptr %l20, !tbaa !23
  store i32 0, ptr %l21, !tbaa !23
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t261 = load i32, ptr %l21, !tbaa !23
  %t262 = load i32, ptr %l20, !tbaa !23
  %t265 = icmp slt i32 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb55:
  br label %bb56
bb56:
  %t269 = load i32, ptr %l17, !tbaa !23
  %t270 = load i32, ptr %l21, !tbaa !23
  %t271 = load i32, ptr %l19, !tbaa !23
  %t274 = mul i32 %t270, %t271
  %t277 = add i32 %t269, %t274
  store i32 %t277, ptr %l22, !tbaa !23
  %t279 = load i32, ptr %l22, !tbaa !23
  %t281 = icmp sgt i32 %t279, 0
  br i1 %t281, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s12, ptr %l16, { i64, ptr } { i64 2, ptr @.d138 })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s12)
  br label %bb60
bb60:
  %t284 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = extractvalue { i64, ptr } %t284, 0
  %t288 = extractvalue { i64, ptr } { i64 1, ptr @.d139 }, 1
  %t289 = extractvalue { i64, ptr } { i64 1, ptr @.d139 }, 0
  %t290 = add i64 %t287, %t289
  %t291 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t290)
  call void @olang_textcopy(ptr %t291, ptr %t286, i64 %t287)
  %t292 = getelementptr i8, ptr %t291, i64 %t287
  call void @olang_textcopy(ptr %t292, ptr %t288, i64 %t289)
  %t293 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t291, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = extractvalue { i64, ptr } %t294, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s11, ptr %l16, { i64, ptr } %t301)
  br label %bb61
bb61:
  store ptr %l16, ptr %l148, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l149, !tbaa !29
  %t305 = load i32, ptr %l1, !tbaa !23
  store i32 %t305, ptr %l150, !tbaa !23
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/emit:fnEm", ptr %t306, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = getelementptr %"compiler/mir:Fn", ptr %t309, i32 0, i32 20
  %t312 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 0
  %t313 = load i32, ptr %t312, !tbaa !23
  %t315 = sext i32 %t313 to i64
  %t316 = load i32, ptr %l22, !tbaa !23
  %t318 = sext i32 %t316 to i64
  %t321 = add i64 %t315, %t318
  %t324 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t311, i64 %t321)
  store i32 %t324, ptr %l159
  br label %bb62
bb62:
  %t325 = load ptr, ptr %l149, !tbaa !29
  %t326 = load i32, ptr %l150, !tbaa !23
  %t327 = load i32, ptr %l159, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %s11, ptr %t325, i32 %t326, i32 %t327)
  store { i64, ptr } %t328, ptr %l160
  br label %bb63
bb63:
  %t329 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t336 = load ptr, ptr %l148, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s11, ptr %t336, { i64, ptr } %t335)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t338 = load i32, ptr %l21, !tbaa !23
  %t340 = add i32 %t338, 1
  store i32 %t340, ptr %l21, !tbaa !23
  br label %bb53
bb66:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %l16, i8 93)
  br label %bb67
bb67:
  %t343 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t344 = load i32, ptr %t343, !tbaa !23
  %t345 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t346 = extractvalue { i64, ptr } { i64 1, ptr @.d140 }, 1
  %t347 = extractvalue { i64, ptr } { i64 1, ptr @.d140 }, 0
  %t349 = sext i32 %t344 to i64
  %t350 = call i64 @__olang_fmt_i64(ptr null, i64 %t349)
  %t351 = add i64 %t347, %t350
  %t352 = extractvalue { i64, ptr } { i64 3, ptr @.d141 }, 1
  %t353 = extractvalue { i64, ptr } { i64 3, ptr @.d141 }, 0
  %t354 = add i64 %t351, %t353
  %t356 = extractvalue { i64, ptr } %t345, 1
  %t357 = extractvalue { i64, ptr } %t345, 0
  %t358 = add i64 %t354, %t357
  %t359 = extractvalue { i64, ptr } { i64 1, ptr @.d142 }, 1
  %t360 = extractvalue { i64, ptr } { i64 1, ptr @.d142 }, 0
  %t361 = add i64 %t358, %t360
  %t362 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t346, i64 %t347)
  %t363 = getelementptr i8, ptr %t362, i64 %t347
  %t364 = call i64 @__olang_fmt_i64(ptr %t363, i64 %t349)
  %t365 = getelementptr i8, ptr %t363, i64 %t350
  call void @olang_textcopy(ptr %t365, ptr %t352, i64 %t353)
  %t366 = getelementptr i8, ptr %t365, i64 %t353
  call void @olang_textcopy(ptr %t366, ptr %t356, i64 %t357)
  %t367 = getelementptr i8, ptr %t366, i64 %t357
  call void @olang_textcopy(ptr %t367, ptr %t359, i64 %t360)
  %t368 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t362, 1
  store { i64, ptr } %t369, ptr %l167, !tbaa !27
  %t371 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %v1, ptr %l16)
  store { i64, ptr } %t371, ptr %l169
  br label %bb68
bb68:
  %t372 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t373 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t374 = load i32, ptr %t373, !tbaa !23
  %t376 = sext i32 %t374 to i64
  %t377 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t378 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } undef, { i64, ptr } %t377, 0
  %t380 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t378, { i64, ptr } %t372, 1
  %t382 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t380, i64 %t376, 2
  store { { i64, ptr }, { i64, ptr }, i64 } %t382, ptr %l173
  %t383 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l173, i32 0, i32 1
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l174, !tbaa !27
  %t385 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 0
  store i64 %t386, ptr %l175, !tbaa !24
  %t387 = load i64, ptr %l175, !tbaa !24
  %t388 = mul i64 %t387, 1
  %t389 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  store { i64, ptr } %t391, ptr %l176, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = load i64, ptr %l175, !tbaa !24
  %t397 = mul i64 %t396, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t393, ptr %t395, i64 %t397, i1 false)
  %t398 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t399 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l173, i32 0, i32 1
  store { i64, ptr } %t398, ptr %t399, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  %t400 = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %l173
  store { { i64, ptr }, { i64, ptr }, i64 } %t400, ptr %rv
  br label %ret
bb69:
  %t401 = load { i64, [1 x i64] }, ptr %l4
  %t403 = extractvalue { i64, [1 x i64] } %t401, 0
  %t404 = icmp eq i64 %t403, 0
  br i1 %t404, label %bb70, label %bb71
bb70:
  %t406 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t407 = getelementptr { i64 }, ptr %t406, i32 0, i32 0
  %t408 = load i64, ptr %t407
  store i64 %t408, ptr %l23, !tbaa !24
  br label %bb72
bb71:
  br label %bb75
bb72:
  store %olang.scope zeroinitializer, ptr %s16
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i32, ptr %l1, !tbaa !23
  %t414 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s16, ptr %t410, i32 %t411)
  store { i64, ptr } %t414, ptr %l182
  br label %bb73
bb73:
  %t415 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t417)
  call void @olang_textcopy(ptr %t418, ptr %t416, i64 %t417)
  %t419 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t418, 1
  store { i64, ptr } %t420, ptr %l183, !tbaa !27
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/emit:fnEm", ptr %t421, i32 0, i32 0
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t425 = load i32, ptr %l1, !tbaa !23
  %t426 = load i64, ptr %l23, !tbaa !24
  %t430 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %t424, i32 %t425, i64 %t426)
  store { i64, ptr } %t430, ptr %l188
  br label %bb74
bb74:
  %t431 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t432 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } undef, { i64, ptr } %t431, 0
  %t433 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t434 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t432, { i64, ptr } %t433, 1
  %t435 = insertvalue { { i64, ptr }, { i64, ptr }, i64 } %t434, i64 1, 2
  call void @__olang_scope_close(ptr %s16)
  store { { i64, ptr }, { i64, ptr }, i64 } %t435, ptr %rv
  br label %ret
bb75:
  call void @__olang_check_failed(ptr @olang_loc_abe6dc85fcec15d0_e43a59b757d9d4e4)
  unreachable
ret:
  %rr = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t10, i32 %a3)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l16, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i32, ptr %l17, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } { i64 26, ptr @.d143 }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr @.d143 }, 0
  %t24 = extractvalue { i64, ptr } %t20, 1
  %t25 = extractvalue { i64, ptr } %t20, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 3, ptr @.d144 }, 1
  %t28 = extractvalue { i64, ptr } { i64 3, ptr @.d144 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t32, ptr %t27, i64 %t28)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } %t41)
  store { i64, ptr } %t44, ptr %l22
  br label %bb3
bb3:
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 26, ptr @.d145 }, 1
  %t49 = extractvalue { i64, ptr } { i64 26, ptr @.d145 }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 3, ptr @.d146 }, 1
  %t55 = extractvalue { i64, ptr } { i64 3, ptr @.d146 }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l27
  br label %bb4
bb4:
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l28, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l29, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l32
  br label %bb5
bb5:
  %t80 = extractvalue { i64, ptr } { i64 8, ptr @.d147 }, 1
  %t81 = extractvalue { i64, ptr } { i64 8, ptr @.d147 }, 0
  %t82 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 2, ptr @.d148 }, 1
  %t87 = extractvalue { i64, ptr } { i64 2, ptr @.d148 }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load i64, ptr %l32, !tbaa !24
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t80, i64 %t81)
  %t93 = getelementptr i8, ptr %t92, i64 %t81
  call void @olang_textcopy(ptr %t93, ptr %t83, i64 %t84)
  %t94 = getelementptr i8, ptr %t93, i64 %t84
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t89)
  %t97 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t92, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l28, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t106, { i64, ptr } %t105)
  store { i64, ptr } %t108, ptr %l35
  br label %bb6
bb6:
  %t109 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t113, { i64, ptr } { i64 19, ptr @.d149 })
  br label %bb7
bb7:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 34, ptr @.d150 }, 1
  %t119 = extractvalue { i64, ptr } { i64 34, ptr @.d150 }, 0
  %t121 = extractvalue { i64, ptr } %a1, 1
  %t122 = extractvalue { i64, ptr } %a1, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 6, ptr @.d151 }, 1
  %t125 = extractvalue { i64, ptr } { i64 6, ptr @.d151 }, 0
  %t126 = add i64 %t123, %t125
  %t128 = extractvalue { i64, ptr } %t117, 1
  %t129 = extractvalue { i64, ptr } %t117, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d152 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d152 }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t118, i64 %t119)
  %t135 = getelementptr i8, ptr %t134, i64 %t119
  call void @olang_textcopy(ptr %t135, ptr %t121, i64 %t122)
  %t136 = getelementptr i8, ptr %t135, i64 %t122
  call void @olang_textcopy(ptr %t136, ptr %t124, i64 %t125)
  %t137 = getelementptr i8, ptr %t136, i64 %t125
  call void @olang_textcopy(ptr %t137, ptr %t128, i64 %t129)
  %t138 = getelementptr i8, ptr %t137, i64 %t129
  call void @olang_textcopy(ptr %t138, ptr %t131, i64 %t132)
  %t139 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t134, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t150 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t115, { i64, ptr } %t147)
  store { i64, ptr } %t150, ptr %l43
  br label %bb8
bb8:
  %t151 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/emit:fnEm", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t155, { i64, ptr } { i64 21, ptr @.d153 }, { i64, ptr } { i64 46, ptr @.d154 })
  br label %bb9
bb9:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 37, ptr @.d155 }, 1
  %t162 = extractvalue { i64, ptr } { i64 37, ptr @.d155 }, 0
  %t164 = extractvalue { i64, ptr } %t158, 1
  %t165 = extractvalue { i64, ptr } %t158, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 6, ptr @.d156 }, 1
  %t168 = extractvalue { i64, ptr } { i64 6, ptr @.d156 }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t159, 1
  %t172 = extractvalue { i64, ptr } %t159, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 6, ptr @.d157 }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr @.d157 }, 0
  %t176 = add i64 %t173, %t175
  %t178 = extractvalue { i64, ptr } %t160, 1
  %t179 = extractvalue { i64, ptr } %t160, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 11, ptr @.d158 }, 1
  %t182 = extractvalue { i64, ptr } { i64 11, ptr @.d158 }, 0
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t161, i64 %t162)
  %t185 = getelementptr i8, ptr %t184, i64 %t162
  call void @olang_textcopy(ptr %t185, ptr %t164, i64 %t165)
  %t186 = getelementptr i8, ptr %t185, i64 %t165
  call void @olang_textcopy(ptr %t186, ptr %t167, i64 %t168)
  %t187 = getelementptr i8, ptr %t186, i64 %t168
  call void @olang_textcopy(ptr %t187, ptr %t171, i64 %t172)
  %t188 = getelementptr i8, ptr %t187, i64 %t172
  call void @olang_textcopy(ptr %t188, ptr %t174, i64 %t175)
  %t189 = getelementptr i8, ptr %t188, i64 %t175
  call void @olang_textcopy(ptr %t189, ptr %t178, i64 %t179)
  %t190 = getelementptr i8, ptr %t189, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t184, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t199)
  br label %bb10
bb10:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t202, { i64, ptr } %t203, { i64, ptr } %t204)
  store { i64, ptr } %t208, ptr %l55
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t209 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr @.d159 }, ptr %l4, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/emit:fnEm", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:fnEm", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/mir:Fn", ptr %t42, i32 0, i32 3
  %t45 = getelementptr %"compiler/source:Span", ptr %t44, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t52 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t31, i64 %t38, i64 %t48)
  store i64 %t52, ptr %l19
  br label %bb4
bb4:
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t54 = load i64, ptr %l19, !tbaa !24
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %t53, i64 %t54)
  store { i64, ptr } %t55, ptr %l20
  br label %bb5
bb5:
  %t56 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 19
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/emit:fnEm", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l13
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l2, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/emit:fnEm", ptr %t25, i32 0, i32 19
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t27, i64 %t28, i64 %t29)
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t33, i32 0, i32 20
  %t36 = load i64, ptr %l2, !tbaa !24
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/emit:fnEm", ptr %t38, i32 0, i32 17
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = extractvalue { i64, ptr } { i64 1, ptr @.d160 }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d160 }, 0
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t46 = add i64 %t43, %t45
  %t47 = extractvalue { i64, ptr } { i64 21, ptr @.d161 }, 1
  %t48 = extractvalue { i64, ptr } { i64 21, ptr @.d161 }, 0
  %t49 = add i64 %t46, %t48
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t37)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 21, ptr @.d162 }, 1
  %t54 = extractvalue { i64, ptr } { i64 21, ptr @.d162 }, 0
  %t55 = add i64 %t52, %t54
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t41)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 2, ptr @.d163 }, 1
  %t60 = extractvalue { i64, ptr } { i64 2, ptr @.d163 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t42, i64 %t43)
  %t63 = getelementptr i8, ptr %t62, i64 %t43
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t36)
  %t65 = getelementptr i8, ptr %t63, i64 %t45
  call void @olang_textcopy(ptr %t65, ptr %t47, i64 %t48)
  %t66 = getelementptr i8, ptr %t65, i64 %t48
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t37)
  %t68 = getelementptr i8, ptr %t66, i64 %t51
  call void @olang_textcopy(ptr %t68, ptr %t53, i64 %t54)
  %t69 = getelementptr i8, ptr %t68, i64 %t54
  %t70 = call i64 @__olang_fmt_i64(ptr %t69, i64 %t41)
  %t71 = getelementptr i8, ptr %t69, i64 %t57
  call void @olang_textcopy(ptr %t71, ptr %t59, i64 %t60)
  %t72 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t62, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } %t73, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t35, { i64, ptr } %t80)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = extractvalue { i64, ptr } { i64 8, ptr @.d164 }, 1
  %t85 = extractvalue { i64, ptr } { i64 8, ptr @.d164 }, 0
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = getelementptr i8, ptr %t89, i64 %t85
  %t91 = call i64 @__olang_fmt_i64(ptr %t90, i64 %t83)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t89, 1
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i32
  %l42 = alloca { i64, [1 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  store i32 %t3, ptr %l3, !tbaa !23
  store i32 1, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sgt i32 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = icmp sgt i32 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l13, !tbaa !23
  br label %bb6
bb3:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = sub i32 %t15, %t16
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = add i32 %t19, %t20
  %t25 = sub i32 %t23, 1
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = sdiv i32 %t25, %t26
  store i32 %t29, ptr %l16, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l16, !tbaa !23
  br label %bb5
bb5:
  %t31 = load i32, ptr %l16, !tbaa !23
  store i32 %t31, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l13, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  store i32 0, ptr %l6, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i32, ptr %l6, !tbaa !23
  %t34 = load i32, ptr %l5, !tbaa !23
  %t37 = icmp slt i32 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load i32, ptr %l6, !tbaa !23
  %t43 = load i32, ptr %l4, !tbaa !23
  %t46 = mul i32 %t42, %t43
  %t49 = add i32 %t41, %t46
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/mir:Fn", ptr %t54, i32 0, i32 10
  %t57 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t58 = getelementptr %"compiler/mir:Range", ptr %t57, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t64 = sext i32 %t49 to i64
  %t67 = add i64 %t61, %t64
  %t70 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t56, i64 %t67)
  store { i64, [1 x i64] } %t70, ptr %l42
  br label %bb11
bb11:
  %t71 = load { i64, [1 x i64] }, ptr %l42
  %t74 = extractvalue { i64, [1 x i64] } %t71, 0
  %t75 = icmp eq i64 %t74, 3
  br i1 %t75, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e9e71ccb75095175_3df52a9a91674c89)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t80 = add i32 %t78, 1
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb7
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { { i64, ptr }, i32 }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { { i64, ptr }, i32 }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, [4 x i64] }
  %l47 = alloca %"compiler/mir:Place"
  %l48 = alloca i32
  %l49 = alloca { { i64, ptr }, i32 }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { { i64, ptr }, i32 }
  %l52 = alloca { i64, ptr }
  %l62 = alloca i32
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i32
  %l80 = alloca i64
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i64
  %l100 = alloca i64
  %l121 = alloca { i64, [4 x i64] }
  %l122 = alloca ptr
  %l125 = alloca { i64, [4 x i64] }
  %l127 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca { i64, [4 x i64] }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { { i64, ptr }, i32 }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l212 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l217 = alloca i64
  %l220 = alloca i64
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l243 = alloca { i64, [4 x i64] }
  %l245 = alloca { i64, ptr }
  %l251 = alloca { { i64, ptr }, i32 }
  %l252 = alloca { i64, ptr }
  %l253 = alloca i64
  %l254 = alloca { i64, ptr }
  %l259 = alloca i64
  %l262 = alloca i64
  %l286 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l305 = alloca i32
  %l306 = alloca i32
  %l310 = alloca i1
  %l314 = alloca i1
  %l319 = alloca ptr
  %l322 = alloca i32
  %l323 = alloca i32
  %l326 = alloca i1
  %l327 = alloca ptr
  %l330 = alloca i32
  %l331 = alloca i1
  %l336 = alloca i64
  %l338 = alloca i1
  %l341 = alloca i32
  %l347 = alloca { { i64, ptr }, i32 }
  %l348 = alloca { i64, ptr }
  %l349 = alloca i64
  %l350 = alloca { i64, ptr }
  %l353 = alloca { { i64, ptr }, i32 }
  %l354 = alloca { i64, ptr }
  %l355 = alloca i64
  %l356 = alloca { i64, ptr }
  %l359 = alloca ptr
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l364 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 6
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  %t18 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t19 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t18, i32 0, i32 2
  %t20 = load %"compiler/mir:Range", ptr %t19
  store %"compiler/mir:Range" %t20, ptr %l6
  br label %bb3
bb2:
  br label %bb98
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l5, !tbaa !23
  %t26 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l62
  br label %bb4
bb4:
  %t27 = load i32, ptr %l62, !tbaa !23
  store i32 %t27, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb8
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l7, !tbaa !23
  %t38 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l69
  br label %bb7
bb7:
  %t39 = load i1, ptr %l69, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l66, !tbaa !21
  br label %bb8
bb8:
  %t42 = load i1, ptr %l66, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb12
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l74
  br label %bb11
bb11:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l74, !tbaa !23
  %t51 = icmp eq i32 %t49, %t48
  store i1 %t51, ptr %l71, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l71, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l80
  br label %bb16
bb16:
  %t60 = load i64, ptr %l80, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sle i64 %t61, 16
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l86
  br label %bb20
bb20:
  %t71 = load i32, ptr %l86, !tbaa !23
  store i32 %t71, ptr %l9, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l9, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l89
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s1, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l92
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t83, ptr %l11, !tbaa !27
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t86 = load i64, ptr %l14, !tbaa !24
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb28
bb25:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l15, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l100, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l100, !tbaa !24
  store i64 %t112, ptr %l97, !tbaa !24
  br label %bb28
bb28:
  %t113 = load i64, ptr %l97, !tbaa !24
  store i64 %t113, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t114 = load i64, ptr %l17, !tbaa !24
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l17, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/mir:Range", ptr %l6
  %t138 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t132, %"compiler/mir:Range" %t133, i64 %t130)
  store { i64, [4 x i64] } %t138, ptr %l121
  br label %bb33
bb33:
  store ptr %l121, ptr %l122, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/mir:Range", ptr %l6
  %t143 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t139, %"compiler/mir:Range" %t140, i64 0)
  store { i64, [4 x i64] } %t143, ptr %l125
  br label %bb34
bb34:
  %t144 = load ptr, ptr %l122, !tbaa !29
  %t146 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %t144, ptr %l125)
  store i1 %t146, ptr %l127
  br label %bb35
bb35:
  %t147 = load i1, ptr %l127, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb36, label %bb37
bb36:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb38
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l17, !tbaa !24
  br label %bb29
bb40:
  %t154 = load i1, ptr %l12, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l132, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/mir:Range", ptr %l6
  %t161 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t157, %"compiler/mir:Range" %t158, i64 0)
  store { i64, [4 x i64] } %t161, ptr %l135
  br label %bb43
bb42:
  br label %bb65
bb43:
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l132, !tbaa !29
  %t164 = load { i64, [4 x i64] }, ptr %l135
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s8, ptr %t163, { i64, [4 x i64] } %t164, i32 %t162)
  store { i64, ptr } %t166, ptr %l137
  br label %bb44
bb44:
  %t167 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t167, ptr %l19, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load %"compiler/mir:Place", ptr %l1
  %t172 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s8, ptr %t168, %"compiler/mir:Place" %t169)
  store { { i64, ptr }, i32 } %t172, ptr %l140
  br label %bb45
bb45:
  %t173 = load { { i64, ptr }, i32 }, ptr %l140
  store { { i64, ptr }, i32 } %t173, ptr %l20
  %t174 = getelementptr { { i64, ptr }, i32 }, ptr %l20, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l141, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  store i64 %t177, ptr %l142, !tbaa !24
  %t178 = load i64, ptr %l142, !tbaa !24
  %t179 = mul i64 %t178, 1
  %t180 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l143, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = load i64, ptr %l142, !tbaa !24
  %t188 = mul i64 %t187, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %t186, i64 %t188, i1 false)
  %t189 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t189, ptr %l21, !tbaa !27
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t190, { i64, ptr } { i64 4, ptr @.d165 })
  store { i64, ptr } %t192, ptr %l145
  br label %bb46
bb46:
  %t193 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t193, ptr %l22, !tbaa !27
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t194, { i64, ptr } { i64 4, ptr @.d166 })
  store { i64, ptr } %t196, ptr %l147
  br label %bb47
bb47:
  %t197 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t197, ptr %l23, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t198, { i64, ptr } { i64 4, ptr @.d167 })
  store { i64, ptr } %t200, ptr %l149
  br label %bb48
bb48:
  %t201 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t201, ptr %l24, !tbaa !27
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s8, ptr %s8, ptr %t202, { i64, ptr } { i64 4, ptr @.d168 })
  store { i64, ptr } %t204, ptr %l151
  br label %bb49
bb49:
  %t205 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t205, ptr %l25, !tbaa !27
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t208 = extractvalue { i64, ptr } { i64 10, ptr @.d169 }, 1
  %t209 = extractvalue { i64, ptr } { i64 10, ptr @.d169 }, 0
  %t211 = extractvalue { i64, ptr } %t207, 1
  %t212 = extractvalue { i64, ptr } %t207, 0
  %t213 = add i64 %t209, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t208, i64 %t209)
  %t215 = getelementptr i8, ptr %t214, i64 %t209
  call void @olang_textcopy(ptr %t215, ptr %t211, i64 %t212)
  %t216 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t214, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } %t217, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t206, { i64, ptr } %t224)
  br label %bb50
bb50:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t227, { i64, ptr } %t228)
  br label %bb51
bb51:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t233 = extractvalue { i64, ptr } { i64 10, ptr @.d170 }, 1
  %t234 = extractvalue { i64, ptr } { i64 10, ptr @.d170 }, 0
  %t236 = extractvalue { i64, ptr } %t232, 1
  %t237 = extractvalue { i64, ptr } %t232, 0
  %t238 = add i64 %t234, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t233, i64 %t234)
  %t240 = getelementptr i8, ptr %t239, i64 %t234
  call void @olang_textcopy(ptr %t240, ptr %t236, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t231, { i64, ptr } %t249)
  br label %bb52
bb52:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t252, { i64, ptr } %t253)
  br label %bb53
bb53:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t256)
  store { i64, ptr } %t258, ptr %l165
  br label %bb54
bb54:
  %t259 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t259, ptr %l26, !tbaa !27
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s8, ptr %t260)
  store { i64, ptr } %t262, ptr %l167
  br label %bb55
bb55:
  %t263 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t263, ptr %l27, !tbaa !27
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t265, 1
  %t271 = extractvalue { i64, ptr } %t265, 0
  %t272 = extractvalue { i64, ptr } { i64 17, ptr @.d171 }, 1
  %t273 = extractvalue { i64, ptr } { i64 17, ptr @.d171 }, 0
  %t274 = add i64 %t271, %t273
  %t276 = extractvalue { i64, ptr } %t266, 1
  %t277 = extractvalue { i64, ptr } %t266, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 6, ptr @.d172 }, 1
  %t280 = extractvalue { i64, ptr } { i64 6, ptr @.d172 }, 0
  %t281 = add i64 %t278, %t280
  %t283 = extractvalue { i64, ptr } %t267, 1
  %t284 = extractvalue { i64, ptr } %t267, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 3, ptr @.d173 }, 1
  %t287 = extractvalue { i64, ptr } { i64 3, ptr @.d173 }, 0
  %t288 = add i64 %t285, %t287
  %t290 = extractvalue { i64, ptr } %t268, 1
  %t291 = extractvalue { i64, ptr } %t268, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 2, ptr @.d174 }, 1
  %t294 = extractvalue { i64, ptr } { i64 2, ptr @.d174 }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t270, i64 %t271)
  %t297 = getelementptr i8, ptr %t296, i64 %t271
  call void @olang_textcopy(ptr %t297, ptr %t272, i64 %t273)
  %t298 = getelementptr i8, ptr %t297, i64 %t273
  call void @olang_textcopy(ptr %t298, ptr %t276, i64 %t277)
  %t299 = getelementptr i8, ptr %t298, i64 %t277
  call void @olang_textcopy(ptr %t299, ptr %t279, i64 %t280)
  %t300 = getelementptr i8, ptr %t299, i64 %t280
  call void @olang_textcopy(ptr %t300, ptr %t283, i64 %t284)
  %t301 = getelementptr i8, ptr %t300, i64 %t284
  call void @olang_textcopy(ptr %t301, ptr %t286, i64 %t287)
  %t302 = getelementptr i8, ptr %t301, i64 %t287
  call void @olang_textcopy(ptr %t302, ptr %t290, i64 %t291)
  %t303 = getelementptr i8, ptr %t302, i64 %t291
  call void @olang_textcopy(ptr %t303, ptr %t293, i64 %t294)
  %t304 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t296, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } %t305, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t264, { i64, ptr } %t312)
  br label %bb56
bb56:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t317 = load i64, ptr %l8, !tbaa !24
  %t318 = extractvalue { i64, ptr } { i64 13, ptr @.d175 }, 1
  %t319 = extractvalue { i64, ptr } { i64 13, ptr @.d175 }, 0
  %t321 = extractvalue { i64, ptr } %t316, 1
  %t322 = extractvalue { i64, ptr } %t316, 0
  %t323 = add i64 %t319, %t322
  %t324 = extractvalue { i64, ptr } { i64 2, ptr @.d176 }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr @.d176 }, 0
  %t326 = add i64 %t323, %t325
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t317)
  %t329 = add i64 %t326, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t318, i64 %t319)
  %t331 = getelementptr i8, ptr %t330, i64 %t319
  call void @olang_textcopy(ptr %t331, ptr %t321, i64 %t322)
  %t332 = getelementptr i8, ptr %t331, i64 %t322
  call void @olang_textcopy(ptr %t332, ptr %t324, i64 %t325)
  %t333 = getelementptr i8, ptr %t332, i64 %t325
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t317)
  %t335 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t330, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t346 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t315, { i64, ptr } %t343)
  store { i64, ptr } %t346, ptr %l180
  br label %bb57
bb57:
  %t347 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t352 = extractvalue { i64, ptr } { i64 6, ptr @.d177 }, 1
  %t353 = extractvalue { i64, ptr } { i64 6, ptr @.d177 }, 0
  %t355 = extractvalue { i64, ptr } %t347, 1
  %t356 = extractvalue { i64, ptr } %t347, 0
  %t357 = add i64 %t353, %t356
  %t358 = extractvalue { i64, ptr } { i64 9, ptr @.d178 }, 1
  %t359 = extractvalue { i64, ptr } { i64 9, ptr @.d178 }, 0
  %t360 = add i64 %t357, %t359
  %t362 = extractvalue { i64, ptr } %t350, 1
  %t363 = extractvalue { i64, ptr } %t350, 0
  %t364 = add i64 %t360, %t363
  %t365 = extractvalue { i64, ptr } { i64 9, ptr @.d179 }, 1
  %t366 = extractvalue { i64, ptr } { i64 9, ptr @.d179 }, 0
  %t367 = add i64 %t364, %t366
  %t369 = extractvalue { i64, ptr } %t351, 1
  %t370 = extractvalue { i64, ptr } %t351, 0
  %t371 = add i64 %t367, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t352, i64 %t353)
  %t373 = getelementptr i8, ptr %t372, i64 %t353
  call void @olang_textcopy(ptr %t373, ptr %t355, i64 %t356)
  %t374 = getelementptr i8, ptr %t373, i64 %t356
  call void @olang_textcopy(ptr %t374, ptr %t358, i64 %t359)
  %t375 = getelementptr i8, ptr %t374, i64 %t359
  call void @olang_textcopy(ptr %t375, ptr %t362, i64 %t363)
  %t376 = getelementptr i8, ptr %t375, i64 %t363
  call void @olang_textcopy(ptr %t376, ptr %t365, i64 %t366)
  %t377 = getelementptr i8, ptr %t376, i64 %t366
  call void @olang_textcopy(ptr %t377, ptr %t369, i64 %t370)
  %t378 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t372, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = extractvalue { i64, ptr } %t379, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t348, { i64, ptr } %t386)
  br label %bb58
bb58:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t389, { i64, ptr } %t390)
  br label %bb59
bb59:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t396 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t397 = extractvalue { i64, ptr } { i64 14, ptr @.d180 }, 1
  %t398 = extractvalue { i64, ptr } { i64 14, ptr @.d180 }, 0
  %t400 = extractvalue { i64, ptr } %t394, 1
  %t401 = extractvalue { i64, ptr } %t394, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 6, ptr @.d181 }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr @.d181 }, 0
  %t405 = add i64 %t402, %t404
  %t407 = extractvalue { i64, ptr } %t395, 1
  %t408 = extractvalue { i64, ptr } %t395, 0
  %t409 = add i64 %t405, %t408
  %t410 = extractvalue { i64, ptr } { i64 13, ptr @.d182 }, 1
  %t411 = extractvalue { i64, ptr } { i64 13, ptr @.d182 }, 0
  %t412 = add i64 %t409, %t411
  %t414 = extractvalue { i64, ptr } %t396, 1
  %t415 = extractvalue { i64, ptr } %t396, 0
  %t416 = add i64 %t412, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t397, i64 %t398)
  %t418 = getelementptr i8, ptr %t417, i64 %t398
  call void @olang_textcopy(ptr %t418, ptr %t400, i64 %t401)
  %t419 = getelementptr i8, ptr %t418, i64 %t401
  call void @olang_textcopy(ptr %t419, ptr %t403, i64 %t404)
  %t420 = getelementptr i8, ptr %t419, i64 %t404
  call void @olang_textcopy(ptr %t420, ptr %t407, i64 %t408)
  %t421 = getelementptr i8, ptr %t420, i64 %t408
  call void @olang_textcopy(ptr %t421, ptr %t410, i64 %t411)
  %t422 = getelementptr i8, ptr %t421, i64 %t411
  call void @olang_textcopy(ptr %t422, ptr %t414, i64 %t415)
  %t423 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t417, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = extractvalue { i64, ptr } %t424, 1
  %t428 = mul i64 %t426, 1
  %t429 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t428)
  call void @llvm.memcpy.p0.p0.i64(ptr %t429, ptr %t427, i64 %t428, i1 false)
  %t430 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t429, 1
  %t434 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %s8, ptr %t393, { i64, ptr } %t431)
  store { i64, ptr } %t434, ptr %l195
  br label %bb60
bb60:
  %t435 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s8, ptr %s8, ptr %s8, ptr %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t435, { i64, ptr } { i64 0, ptr @.d183 })
  br label %bb61
bb61:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t445, 1
  %t449 = extractvalue { i64, ptr } %t445, 0
  %t450 = extractvalue { i64, ptr } { i64 11, ptr @.d184 }, 1
  %t451 = extractvalue { i64, ptr } { i64 11, ptr @.d184 }, 0
  %t452 = add i64 %t449, %t451
  %t454 = extractvalue { i64, ptr } %t446, 1
  %t455 = extractvalue { i64, ptr } %t446, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 3, ptr @.d185 }, 1
  %t458 = extractvalue { i64, ptr } { i64 3, ptr @.d185 }, 0
  %t459 = add i64 %t456, %t458
  %t460 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t459)
  call void @olang_textcopy(ptr %t460, ptr %t448, i64 %t449)
  %t461 = getelementptr i8, ptr %t460, i64 %t449
  call void @olang_textcopy(ptr %t461, ptr %t450, i64 %t451)
  %t462 = getelementptr i8, ptr %t461, i64 %t451
  call void @olang_textcopy(ptr %t462, ptr %t454, i64 %t455)
  %t463 = getelementptr i8, ptr %t462, i64 %t455
  call void @olang_textcopy(ptr %t463, ptr %t457, i64 %t458)
  %t464 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t460, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = extractvalue { i64, ptr } %t465, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t444, { i64, ptr } %t472)
  br label %bb62
bb62:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t477 = extractvalue { i64, ptr } { i64 10, ptr @.d186 }, 1
  %t478 = extractvalue { i64, ptr } { i64 10, ptr @.d186 }, 0
  %t480 = extractvalue { i64, ptr } %t476, 1
  %t481 = extractvalue { i64, ptr } %t476, 0
  %t482 = add i64 %t478, %t481
  %t483 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t482)
  call void @olang_textcopy(ptr %t483, ptr %t477, i64 %t478)
  %t484 = getelementptr i8, ptr %t483, i64 %t478
  call void @olang_textcopy(ptr %t484, ptr %t480, i64 %t481)
  %t485 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t483, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t475, { i64, ptr } %t493)
  br label %bb63
bb63:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s8, ptr %t496, { i64, ptr } %t497)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb65:
  %t501 = load ptr, ptr @__olang_prog_scope
  %t502 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t501)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t502, ptr %l212
  br label %bb66
bb66:
  %t503 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l212
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t503, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t504 = load i64, ptr %l8, !tbaa !24
  store i64 %t504, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t506 = load i64, ptr %l32, !tbaa !24
  %t507 = load i64, ptr %l31, !tbaa !24
  %t510 = icmp sgt i64 %t506, %t507
  br i1 %t510, label %bb67, label %bb68
bb67:
  %t512 = load i64, ptr %l33, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l217, !tbaa !24
  br label %bb72
bb69:
  %t516 = load i64, ptr %l32, !tbaa !24
  %t517 = load i64, ptr %l31, !tbaa !24
  %t520 = sub i64 %t516, %t517
  %t521 = load i64, ptr %l33, !tbaa !24
  %t524 = add i64 %t520, %t521
  %t526 = sub i64 %t524, 1
  %t527 = load i64, ptr %l33, !tbaa !24
  %t530 = sdiv i64 %t526, %t527
  store i64 %t530, ptr %l220, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb71
bb71:
  %t532 = load i64, ptr %l220, !tbaa !24
  store i64 %t532, ptr %l217, !tbaa !24
  br label %bb72
bb72:
  %t533 = load i64, ptr %l217, !tbaa !24
  store i64 %t533, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s18
  %t534 = load i64, ptr %l35, !tbaa !24
  %t535 = load i64, ptr %l34, !tbaa !24
  %t538 = icmp slt i64 %t534, %t535
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s18)
  br label %bb81
bb75:
  br label %bb76
bb76:
  %t542 = load i64, ptr %l31, !tbaa !24
  %t543 = load i64, ptr %l35, !tbaa !24
  %t544 = load i64, ptr %l33, !tbaa !24
  %t547 = mul i64 %t543, %t544
  %t550 = add i64 %t542, %t547
  store ptr %l30, ptr %l238, !tbaa !29
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l239, !tbaa !29
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load %"compiler/mir:Range", ptr %l6
  %t559 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t553, %"compiler/mir:Range" %t554, i64 %t550)
  store { i64, [4 x i64] } %t559, ptr %l243
  br label %bb77
bb77:
  %t560 = load i32, ptr %l9, !tbaa !23
  %t561 = load ptr, ptr %l239, !tbaa !29
  %t562 = load { i64, [4 x i64] }, ptr %l243
  %t564 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s1, ptr %t561, { i64, [4 x i64] } %t562, i32 %t560)
  store { i64, ptr } %t564, ptr %l245
  br label %bb78
bb78:
  %t565 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  %t567 = extractvalue { i64, ptr } %t565, 1
  %t568 = mul i64 %t566, 1
  %t569 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t568)
  call void @llvm.memcpy.p0.p0.i64(ptr %t569, ptr %t567, i64 %t568, i1 false)
  %t570 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  %t572 = load ptr, ptr %l238, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s1, ptr %s1, ptr %t572, { i64, ptr } %t571)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s18)
  br label %bb80
bb80:
  %t574 = load i64, ptr %l35, !tbaa !24
  %t576 = add i64 %t574, 1
  store i64 %t576, ptr %l35, !tbaa !24
  br label %bb73
bb81:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load %"compiler/mir:Place", ptr %l1
  %t582 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t578, %"compiler/mir:Place" %t579)
  store { { i64, ptr }, i32 } %t582, ptr %l251
  br label %bb82
bb82:
  %t583 = load { { i64, ptr }, i32 }, ptr %l251
  store { { i64, ptr }, i32 } %t583, ptr %l37
  %t584 = getelementptr { { i64, ptr }, i32 }, ptr %l37, i32 0, i32 0
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l252, !tbaa !27
  %t586 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t586, 0
  store i64 %t587, ptr %l253, !tbaa !24
  %t588 = load i64, ptr %l253, !tbaa !24
  %t589 = mul i64 %t588, 1
  %t590 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t589)
  %t591 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  store { i64, ptr } %t592, ptr %l254, !tbaa !27
  %t593 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t596 = load ptr, ptr %t595, !tbaa !27
  %t597 = load i64, ptr %l253, !tbaa !24
  %t598 = mul i64 %t597, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t594, ptr %t596, i64 %t598, i1 false)
  %t599 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t599, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t600 = load i64, ptr %l8, !tbaa !24
  store i64 %t600, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t602 = load i64, ptr %l40, !tbaa !24
  %t603 = load i64, ptr %l39, !tbaa !24
  %t606 = icmp sgt i64 %t602, %t603
  br i1 %t606, label %bb83, label %bb84
bb83:
  %t608 = load i64, ptr %l41, !tbaa !24
  %t610 = icmp sgt i64 %t608, 0
  br i1 %t610, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l259, !tbaa !24
  br label %bb88
bb85:
  %t612 = load i64, ptr %l40, !tbaa !24
  %t613 = load i64, ptr %l39, !tbaa !24
  %t616 = sub i64 %t612, %t613
  %t617 = load i64, ptr %l41, !tbaa !24
  %t620 = add i64 %t616, %t617
  %t622 = sub i64 %t620, 1
  %t623 = load i64, ptr %l41, !tbaa !24
  %t626 = sdiv i64 %t622, %t623
  store i64 %t626, ptr %l262, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb87
bb87:
  %t628 = load i64, ptr %l262, !tbaa !24
  store i64 %t628, ptr %l259, !tbaa !24
  br label %bb88
bb88:
  %t629 = load i64, ptr %l259, !tbaa !24
  store i64 %t629, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s21
  %t630 = load i64, ptr %l43, !tbaa !24
  %t631 = load i64, ptr %l42, !tbaa !24
  %t634 = icmp slt i64 %t630, %t631
  %t636 = xor i1 %t634, true
  br i1 %t636, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s21)
  br label %bb97
bb91:
  br label %bb92
bb92:
  %t638 = load i64, ptr %l39, !tbaa !24
  %t639 = load i64, ptr %l43, !tbaa !24
  %t640 = load i64, ptr %l41, !tbaa !24
  %t643 = mul i64 %t639, %t640
  %t646 = add i64 %t638, %t643
  store i64 %t646, ptr %l44, !tbaa !24
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t650 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t651 = load i64, ptr %l44, !tbaa !24
  %t652 = extractvalue { i64, ptr } { i64 14, ptr @.d187 }, 1
  %t653 = extractvalue { i64, ptr } { i64 14, ptr @.d187 }, 0
  %t655 = extractvalue { i64, ptr } %t649, 1
  %t656 = extractvalue { i64, ptr } %t649, 0
  %t657 = add i64 %t653, %t656
  %t658 = extractvalue { i64, ptr } { i64 6, ptr @.d188 }, 1
  %t659 = extractvalue { i64, ptr } { i64 6, ptr @.d188 }, 0
  %t660 = add i64 %t657, %t659
  %t662 = extractvalue { i64, ptr } %t650, 1
  %t663 = extractvalue { i64, ptr } %t650, 0
  %t664 = add i64 %t660, %t663
  %t665 = extractvalue { i64, ptr } { i64 13, ptr @.d189 }, 1
  %t666 = extractvalue { i64, ptr } { i64 13, ptr @.d189 }, 0
  %t667 = add i64 %t664, %t666
  %t669 = call i64 @__olang_fmt_i64(ptr null, i64 %t651)
  %t670 = add i64 %t667, %t669
  %t671 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t670)
  call void @olang_textcopy(ptr %t671, ptr %t652, i64 %t653)
  %t672 = getelementptr i8, ptr %t671, i64 %t653
  call void @olang_textcopy(ptr %t672, ptr %t655, i64 %t656)
  %t673 = getelementptr i8, ptr %t672, i64 %t656
  call void @olang_textcopy(ptr %t673, ptr %t658, i64 %t659)
  %t674 = getelementptr i8, ptr %t673, i64 %t659
  call void @olang_textcopy(ptr %t674, ptr %t662, i64 %t663)
  %t675 = getelementptr i8, ptr %t674, i64 %t663
  call void @olang_textcopy(ptr %t675, ptr %t665, i64 %t666)
  %t676 = getelementptr i8, ptr %t675, i64 %t666
  %t677 = call i64 @__olang_fmt_i64(ptr %t676, i64 %t651)
  %t678 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t671, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = extractvalue { i64, ptr } %t679, 1
  %t683 = mul i64 %t681, 1
  %t684 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t683)
  call void @llvm.memcpy.p0.p0.i64(ptr %t684, ptr %t682, i64 %t683, i1 false)
  %t685 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  %t689 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t648, { i64, ptr } %t686)
  store { i64, ptr } %t689, ptr %l286
  br label %bb93
bb93:
  %t690 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t690, ptr %l45, !tbaa !27
  %t691 = load ptr, ptr %l0, !tbaa !29
  store ptr %t691, ptr %l287, !tbaa !29
  %t692 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t692, ptr %l288, !tbaa !27
  %t693 = load i64, ptr %l44, !tbaa !24
  %t696 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s1, ptr %s1, ptr %l30, i64 %t693)
  store { i64, ptr } %t696, ptr %l291
  br label %bb94
bb94:
  %t697 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t698 = load ptr, ptr %l287, !tbaa !29
  %t699 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t700 = load { i64, ptr }, ptr %l291, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s21, ptr %s21, ptr %t698, { i64, ptr } %t699, { i64, ptr } %t700, { i64, ptr } %t697, { i64, ptr } { i64 0, ptr @.d190 })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s21)
  br label %bb96
bb96:
  %t702 = load i64, ptr %l43, !tbaa !24
  %t704 = add i64 %t702, 1
  store i64 %t704, ptr %l43, !tbaa !24
  br label %bb89
bb97:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb98:
  %t707 = load { i64, [15 x i64] }, ptr %l3
  %t709 = extractvalue { i64, [15 x i64] } %t707, 0
  %t710 = icmp eq i64 %t709, 0
  br i1 %t710, label %bb99, label %bb100
bb99:
  %t712 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t713 = getelementptr { { i64, [4 x i64] } }, ptr %t712, i32 0, i32 0
  %t714 = load { i64, [4 x i64] }, ptr %t713
  store { i64, [4 x i64] } %t714, ptr %l46
  br label %bb101
bb100:
  br label %bb144
bb101:
  %t716 = load { i64, [4 x i64] }, ptr %l46
  %t718 = extractvalue { i64, [4 x i64] } %t716, 0
  %t719 = icmp eq i64 %t718, 1
  br i1 %t719, label %bb102, label %bb103
bb102:
  %t721 = getelementptr { i64, [4 x i64] }, ptr %l46, i32 0, i32 1
  %t722 = getelementptr { %"compiler/mir:Place" }, ptr %t721, i32 0, i32 0
  %t723 = load %"compiler/mir:Place", ptr %t722
  store %"compiler/mir:Place" %t723, ptr %l47
  br label %bb104
bb103:
  br label %bb139
bb104:
  store %olang.scope zeroinitializer, ptr %s25
  %t725 = load ptr, ptr %l4, !tbaa !29
  store ptr %t725, ptr %l302, !tbaa !29
  %t726 = load ptr, ptr %l4, !tbaa !29
  %t727 = load i32, ptr %l2, !tbaa !23
  %t730 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t726, i32 %t727)
  store i32 %t730, ptr %l305
  br label %bb105
bb105:
  %t731 = load ptr, ptr %l302, !tbaa !29
  %t732 = load i32, ptr %l305, !tbaa !23
  %t733 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t731, i32 %t732)
  store i32 %t733, ptr %l306
  br label %bb106
bb106:
  %t734 = load i32, ptr %l306
  store i32 %t734, ptr %l48
  %t735 = load i32, ptr %l48
  %t737 = trunc i64 19 to i32
  %t738 = icmp eq i32 %t735, %t737
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb107, label %bb108
bb107:
  %t742 = load i32, ptr %l48
  %t744 = trunc i64 18 to i32
  %t745 = icmp eq i32 %t742, %t744
  %t747 = xor i1 %t745, true
  store i1 %t747, ptr %l310, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb109
bb109:
  %t749 = load i1, ptr %l310, !tbaa !21
  br i1 %t749, label %bb110, label %bb111
bb110:
  %t750 = load i32, ptr %l48
  %t752 = trunc i64 24 to i32
  %t753 = icmp eq i32 %t750, %t752
  %t755 = xor i1 %t753, true
  store i1 %t755, ptr %l314, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb112
bb112:
  %t757 = load i1, ptr %l314, !tbaa !21
  br i1 %t757, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t759 = load ptr, ptr %l4, !tbaa !29
  store ptr %t759, ptr %l319, !tbaa !29
  %t760 = load ptr, ptr %l4, !tbaa !29
  %t761 = load i32, ptr %l2, !tbaa !23
  %t764 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t760, i32 %t761)
  store i32 %t764, ptr %l322
  br label %bb116
bb116:
  %t765 = load ptr, ptr %l319, !tbaa !29
  %t766 = load i32, ptr %l322, !tbaa !23
  %t767 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t765, i32 %t766)
  store i32 %t767, ptr %l323
  br label %bb117
bb117:
  %t768 = load i32, ptr %l323
  %t770 = trunc i64 19 to i32
  %t771 = icmp eq i32 %t768, %t770
  br i1 %t771, label %bb118, label %bb119
bb118:
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l327, !tbaa !29
  %t774 = load ptr, ptr %l4, !tbaa !29
  %t775 = load i32, ptr %l2, !tbaa !23
  %t778 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t774, i32 %t775)
  store i32 %t778, ptr %l330
  br label %bb120
bb119:
  store i1 false, ptr %l326, !tbaa !21
  br label %bb122
bb120:
  %t779 = load ptr, ptr %l327, !tbaa !29
  %t780 = load i32, ptr %l330, !tbaa !23
  %t781 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t779, i32 %t780)
  store i1 %t781, ptr %l331
  br label %bb121
bb121:
  %t782 = load i1, ptr %l331, !tbaa !21
  %t783 = xor i1 %t782, true
  store i1 %t783, ptr %l326, !tbaa !21
  br label %bb122
bb122:
  %t785 = load i1, ptr %l326, !tbaa !21
  br i1 %t785, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load i32, ptr %l2, !tbaa !23
  %t791 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t787, i32 %t788)
  store i64 %t791, ptr %l336
  br label %bb126
bb126:
  %t792 = load i64, ptr %l336, !tbaa !24
  %t793 = icmp sle i64 %t792, 128
  br i1 %t793, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l338, !tbaa !21
  br label %bb130
bb128:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t796 = load %"compiler/mir:Place", ptr %l47
  %t799 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t795, %"compiler/mir:Place" %t796)
  store i32 %t799, ptr %l341
  br label %bb129
bb129:
  %t800 = load i32, ptr %l2, !tbaa !23
  %t801 = load i32, ptr %l341, !tbaa !23
  %t803 = icmp ne i32 %t801, %t800
  store i1 %t803, ptr %l338, !tbaa !21
  br label %bb130
bb130:
  %t805 = load i1, ptr %l338, !tbaa !21
  br i1 %t805, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s25)
  store i1 false, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load %"compiler/mir:Place", ptr %l47
  %t811 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t807, %"compiler/mir:Place" %t808)
  store { { i64, ptr }, i32 } %t811, ptr %l347
  br label %bb134
bb134:
  %t812 = load { { i64, ptr }, i32 }, ptr %l347
  store { { i64, ptr }, i32 } %t812, ptr %l49
  %t813 = getelementptr { { i64, ptr }, i32 }, ptr %l49, i32 0, i32 0
  %t814 = load { i64, ptr }, ptr %t813, !tbaa !27
  store { i64, ptr } %t814, ptr %l348, !tbaa !27
  %t815 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t816 = extractvalue { i64, ptr } %t815, 0
  store i64 %t816, ptr %l349, !tbaa !24
  %t817 = load i64, ptr %l349, !tbaa !24
  %t818 = mul i64 %t817, 1
  %t819 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t818)
  %t820 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  store { i64, ptr } %t821, ptr %l350, !tbaa !27
  %t822 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t823 = load ptr, ptr %t822, !tbaa !27
  %t824 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !27
  %t826 = load i64, ptr %l349, !tbaa !24
  %t827 = mul i64 %t826, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t823, ptr %t825, i64 %t827, i1 false)
  %t828 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t828, ptr %l50, !tbaa !27
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load %"compiler/mir:Place", ptr %l1
  %t833 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s25, ptr %t829, %"compiler/mir:Place" %t830)
  store { { i64, ptr }, i32 } %t833, ptr %l353
  br label %bb135
bb135:
  %t834 = load { { i64, ptr }, i32 }, ptr %l353
  store { { i64, ptr }, i32 } %t834, ptr %l51
  %t835 = getelementptr { { i64, ptr }, i32 }, ptr %l51, i32 0, i32 0
  %t836 = load { i64, ptr }, ptr %t835, !tbaa !27
  store { i64, ptr } %t836, ptr %l354, !tbaa !27
  %t837 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t838 = extractvalue { i64, ptr } %t837, 0
  store i64 %t838, ptr %l355, !tbaa !24
  %t839 = load i64, ptr %l355, !tbaa !24
  %t840 = mul i64 %t839, 1
  %t841 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t840)
  %t842 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t843 = insertvalue { i64, ptr } %t842, ptr %t841, 1
  store { i64, ptr } %t843, ptr %l356, !tbaa !27
  %t844 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t847 = load ptr, ptr %t846, !tbaa !27
  %t848 = load i64, ptr %l355, !tbaa !24
  %t849 = mul i64 %t848, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t845, ptr %t847, i64 %t849, i1 false)
  %t850 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t850, ptr %l52, !tbaa !27
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = getelementptr %"compiler/emit:fnEm", ptr %t851, i32 0, i32 0
  %t854 = load ptr, ptr %t853, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s25, ptr %s25, ptr %t854, { i64, ptr } { i64 22, ptr @.d191 }, { i64, ptr } { i64 47, ptr @.d192 })
  br label %bb136
bb136:
  %t856 = load ptr, ptr %l0, !tbaa !29
  store ptr %t856, ptr %l359, !tbaa !29
  %t857 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t857, ptr %l360, !tbaa !27
  %t858 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t858, ptr %l361, !tbaa !27
  %t859 = load ptr, ptr %l0, !tbaa !29
  %t860 = load i32, ptr %l2, !tbaa !23
  %t863 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t859, i32 %t860)
  store i64 %t863, ptr %l364
  br label %bb137
bb137:
  %t864 = extractvalue { i64, ptr } { i64 38, ptr @.d193 }, 1
  %t865 = extractvalue { i64, ptr } { i64 38, ptr @.d193 }, 0
  %t866 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t869 = add i64 %t865, %t868
  %t870 = extractvalue { i64, ptr } { i64 6, ptr @.d194 }, 1
  %t871 = extractvalue { i64, ptr } { i64 6, ptr @.d194 }, 0
  %t872 = add i64 %t869, %t871
  %t873 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t874 = extractvalue { i64, ptr } %t873, 1
  %t875 = extractvalue { i64, ptr } %t873, 0
  %t876 = add i64 %t872, %t875
  %t877 = extractvalue { i64, ptr } { i64 6, ptr @.d195 }, 1
  %t878 = extractvalue { i64, ptr } { i64 6, ptr @.d195 }, 0
  %t879 = add i64 %t876, %t878
  %t880 = load i64, ptr %l364, !tbaa !24
  %t881 = call i64 @__olang_fmt_i64(ptr null, i64 %t880)
  %t882 = add i64 %t879, %t881
  %t883 = extractvalue { i64, ptr } { i64 11, ptr @.d196 }, 1
  %t884 = extractvalue { i64, ptr } { i64 11, ptr @.d196 }, 0
  %t885 = add i64 %t882, %t884
  %t886 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t885)
  call void @olang_textcopy(ptr %t886, ptr %t864, i64 %t865)
  %t887 = getelementptr i8, ptr %t886, i64 %t865
  call void @olang_textcopy(ptr %t887, ptr %t867, i64 %t868)
  %t888 = getelementptr i8, ptr %t887, i64 %t868
  call void @olang_textcopy(ptr %t888, ptr %t870, i64 %t871)
  %t889 = getelementptr i8, ptr %t888, i64 %t871
  call void @olang_textcopy(ptr %t889, ptr %t874, i64 %t875)
  %t890 = getelementptr i8, ptr %t889, i64 %t875
  call void @olang_textcopy(ptr %t890, ptr %t877, i64 %t878)
  %t891 = getelementptr i8, ptr %t890, i64 %t878
  %t892 = call i64 @__olang_fmt_i64(ptr %t891, i64 %t880)
  %t893 = getelementptr i8, ptr %t891, i64 %t881
  call void @olang_textcopy(ptr %t893, ptr %t883, i64 %t884)
  %t894 = insertvalue { i64, ptr } undef, i64 %t885, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t886, 1
  %t897 = extractvalue { i64, ptr } %t895, 0
  %t898 = extractvalue { i64, ptr } %t895, 1
  %t899 = mul i64 %t897, 1
  %t900 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t899)
  call void @llvm.memcpy.p0.p0.i64(ptr %t900, ptr %t898, i64 %t899, i1 false)
  %t901 = insertvalue { i64, ptr } undef, i64 %t897, 0
  %t902 = insertvalue { i64, ptr } %t901, ptr %t900, 1
  %t903 = load ptr, ptr %l359, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t903, { i64, ptr } %t902)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s25)
  store i1 true, ptr %rv
  br label %ret
bb139:
  br i1 true, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  store i1 false, ptr %rv
  br label %ret
bb143:
  call void @__olang_check_failed(ptr @olang_loc_9357034ceffa49e9_ad514f9345461395)
  unreachable
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  store i1 false, ptr %rv
  br label %ret
bb148:
  call void @__olang_check_failed(ptr @olang_loc_1dffb4089bad5318_6447f84abd9ba4a4)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:BasicBlock"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, [21 x i64] }
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, [15 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca { i64, [7 x i64] }
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"compiler/mir:Local"
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l48 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l66 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, [21 x i64] }
  %l115 = alloca { i64, [21 x i64] }
  %l118 = alloca { i64, [21 x i64] }
  %l121 = alloca { i64, [21 x i64] }
  %l127 = alloca i1
  %l128 = alloca i1
  %l130 = alloca { i64, [21 x i64] }
  %l135 = alloca { i64, [21 x i64] }
  %l140 = alloca { i64, [21 x i64] }
  %l155 = alloca i1
  %l156 = alloca i1
  %l165 = alloca i1
  %l166 = alloca i1
  %l171 = alloca i1
  %l172 = alloca i1
  %l192 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i32
  %l205 = alloca { i64, ptr }
  %l210 = alloca i1
  %l215 = alloca i1
  %l216 = alloca i1
  %l225 = alloca i64
  %l229 = alloca i64
  %l232 = alloca i64
  %l253 = alloca %"compiler/mir:ScopeInfo"
  %l258 = alloca i1
  %l264 = alloca i1
  %l266 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l48
  br label %bb1
bb1:
  %t11 = load i64, ptr %l48, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l48, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i1 false, ptr %l3, !tbaa !21
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Fn", ptr %t20, i32 0, i32 12
  store ptr %t22, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_3b6348629663638e_4d98396f767ecbfa)
  unreachable
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eRunF_Hfdafd2704446aebe706e7a16d9caf3c2(ptr %v0, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l57
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb6, label %ok.32
ok.32:
  store { i64, ptr } %t29, ptr %l56
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t33, ptr %l53, !tbaa !27
  br label %bb10
bb6:
  %t34 = load i32, ptr %l57, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f4a19adfa2908824_f7d19e69dc606aa8)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  %t39 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l66, !tbaa !27
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, [1 x i64] }, ptr %t56, i64 %t53
  %t58 = load { i64, [1 x i64] }, ptr %t57
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t60, { i64, [1 x i64] } %t58, { i64, ptr } %t62)
  store i1 %t66, ptr %l72
  br label %bb15
bb15:
  %t67 = load i1, ptr %l72, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb18
bb17:
  %t68 = load i1, ptr %l3, !tbaa !21
  store i1 %t68, ptr %l73, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l73, !tbaa !21
  store i1 %t70, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb11
bb20:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = add i64 %t75, %t76
  store i64 %t79, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb4
bb22:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/mir:Fn", ptr %t81, i32 0, i32 9
  store ptr %t83, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t85 = load ptr, ptr %l10, !tbaa !29
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t85, i64 %t86)
  %t90 = extractvalue { i32, { i64, ptr } } %t89, 1
  %t91 = extractvalue { i32, { i64, ptr } } %t89, 0
  store i32 %t91, ptr %l86
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb25, label %ok.93
ok.93:
  store { i64, ptr } %t90, ptr %l85
  br label %bb24
bb24:
  %t94 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t94, ptr %l82, !tbaa !27
  br label %bb29
bb25:
  %t95 = load i32, ptr %l86, !tbaa !23
  %t96 = ashr i32 %t95, 16
  %t98 = icmp eq i32 %t96, 1
  br i1 %t98, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7398c824c6ccd25f_37644bbf4fe2ca83)
  unreachable
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb119
bb29:
  %t100 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t100, ptr %l12, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i64, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb117
bb32:
  br label %bb33
bb33:
  %t113 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t113, ptr %l95, !tbaa !27
  %t114 = load i64, ptr %l14, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"compiler/mir:BasicBlock", ptr %t117, i64 %t114
  %t119 = load %"compiler/mir:BasicBlock", ptr %t118
  store %"compiler/mir:BasicBlock" %t119, ptr %l15
  %t121 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 0
  store ptr %t121, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t123 = load ptr, ptr %l16, !tbaa !29
  %t124 = load i64, ptr %l17, !tbaa !24
  %t127 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t123, i64 %t124)
  %t128 = extractvalue { i32, { i64, ptr } } %t127, 1
  %t129 = extractvalue { i32, { i64, ptr } } %t127, 0
  store i32 %t129, ptr %l103
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb36, label %ok.131
ok.131:
  store { i64, ptr } %t128, ptr %l102
  br label %bb35
bb35:
  %t132 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t132, ptr %l99, !tbaa !27
  br label %bb40
bb36:
  %t133 = load i32, ptr %l103, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  br i1 %t136, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5718aedbda8f05de_73125ecff2351902)
  unreachable
bb39:
  call void @__olang_scope_close(ptr %s9)
  br label %bb106
bb40:
  %t138 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load i64, ptr %l20, !tbaa !24
  %t144 = load i64, ptr %l19, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb104
bb43:
  br label %bb44
bb44:
  %t151 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t151, ptr %l112, !tbaa !27
  %t152 = load i64, ptr %l20, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, [21 x i64] }, ptr %t155, i64 %t152
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t156, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %l114, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %l21, i64 176, i1 false)
  %t157 = load { i64, [21 x i64] }, ptr %l115
  %t158 = extractvalue { i64, [21 x i64] } %t157, 0
  %t159 = icmp eq i64 %t158, 6
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t161, i32 0, i32 1
  %t163 = load { i64, [1 x i64] }, ptr %t162
  store { i64, [1 x i64] } %t163, ptr %l22
  br label %bb51
bb46:
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %l21, i64 176, i1 false)
  %t165 = load { i64, [21 x i64] }, ptr %l118
  %t166 = extractvalue { i64, [21 x i64] } %t165, 0
  %t167 = icmp eq i64 %t166, 7
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t169 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t169, i32 0, i32 1
  %t171 = load { i64, [1 x i64] }, ptr %t170
  store { i64, [1 x i64] } %t171, ptr %l22
  br label %bb51
bb48:
  call void @llvm.memmove.p0.p0.i64(ptr %l121, ptr %l21, i64 176, i1 false)
  %t173 = load { i64, [21 x i64] }, ptr %l121
  %t174 = extractvalue { i64, [21 x i64] } %t173, 0
  %t175 = icmp eq i64 %t174, 9
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t177 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t177, i32 0, i32 1
  %t179 = load { i64, [1 x i64] }, ptr %t178
  store { i64, [1 x i64] } %t179, ptr %l22
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load { i64, [1 x i64] }, ptr %l22
  %t183 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t181, { i64, [1 x i64] } %t182, { i64, ptr } %t183)
  store i1 %t187, ptr %l127
  br label %bb52
bb52:
  %t188 = load i1, ptr %l127, !tbaa !21
  br i1 %t188, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l128, !tbaa !21
  br label %bb55
bb54:
  %t189 = load i1, ptr %l3, !tbaa !21
  store i1 %t189, ptr %l128, !tbaa !21
  br label %bb55
bb55:
  %t191 = load i1, ptr %l128, !tbaa !21
  store i1 %t191, ptr %l3, !tbaa !21
  br label %bb102
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %l130, ptr %l21, i64 176, i1 false)
  %t192 = load { i64, [21 x i64] }, ptr %l130
  %t193 = extractvalue { i64, [21 x i64] } %t192, 0
  %t194 = icmp eq i64 %t193, 11
  br i1 %t194, label %bb57, label %bb58
bb57:
  %t196 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t196, i32 0, i32 1
  %t198 = load i32, ptr %t197
  store i32 %t198, ptr %l23, !tbaa !23
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t200 = load i32, ptr %l23, !tbaa !23
  %t202 = sext i32 %t200 to i64
  %t204 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i1, ptr %t205, i64 %t202
  store i1 true, ptr %t206, !tbaa !31
  br label %bb102
bb60:
  call void @llvm.memmove.p0.p0.i64(ptr %l135, ptr %l21, i64 176, i1 false)
  %t207 = load { i64, [21 x i64] }, ptr %l135
  %t208 = extractvalue { i64, [21 x i64] } %t207, 0
  %t209 = icmp eq i64 %t208, 5
  br i1 %t209, label %bb61, label %bb62
bb61:
  %t211 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32 }, ptr %t211, i32 0, i32 1
  %t213 = load i32, ptr %t212
  store i32 %t213, ptr %l24, !tbaa !23
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t215 = load i32, ptr %l24, !tbaa !23
  %t217 = sext i32 %t215 to i64
  %t219 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i1, ptr %t220, i64 %t217
  store i1 true, ptr %t221, !tbaa !31
  br label %bb102
bb64:
  call void @llvm.memmove.p0.p0.i64(ptr %l140, ptr %l21, i64 176, i1 false)
  %t222 = load { i64, [21 x i64] }, ptr %l140
  %t223 = extractvalue { i64, [21 x i64] } %t222, 0
  %t224 = icmp eq i64 %t223, 0
  br i1 %t224, label %bb65, label %bb66
bb65:
  %t226 = getelementptr { i64, [21 x i64] }, ptr %l21, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, [15 x i64] }, ptr %t227
  store { i64, [15 x i64] } %t228, ptr %l25
  br label %bb67
bb66:
  br label %bb97
bb67:
  %t230 = load { i64, [15 x i64] }, ptr %l25
  %t232 = extractvalue { i64, [15 x i64] } %t230, 0
  %t233 = icmp eq i64 %t232, 7
  br i1 %t233, label %bb68, label %bb69
bb68:
  %t235 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t236 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t235, i32 0, i32 0
  %t237 = load { i64, [1 x i64] }, ptr %t236
  store { i64, [1 x i64] } %t237, ptr %l26
  br label %bb74
bb69:
  %t239 = load { i64, [15 x i64] }, ptr %l25
  %t241 = extractvalue { i64, [15 x i64] } %t239, 0
  %t242 = icmp eq i64 %t241, 8
  br i1 %t242, label %bb70, label %bb71
bb70:
  %t244 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t245 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t244, i32 0, i32 0
  %t246 = load { i64, [1 x i64] }, ptr %t245
  store { i64, [1 x i64] } %t246, ptr %l26
  br label %bb74
bb71:
  %t248 = load { i64, [15 x i64] }, ptr %l25
  %t250 = extractvalue { i64, [15 x i64] } %t248, 0
  %t251 = icmp eq i64 %t250, 10
  br i1 %t251, label %bb72, label %bb73
bb72:
  %t253 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t254 = getelementptr { { i64, [1 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t253, i32 0, i32 2
  %t255 = load { i64, [1 x i64] }, ptr %t254
  store { i64, [1 x i64] } %t255, ptr %l26
  br label %bb74
bb73:
  br label %bb79
bb74:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load { i64, [1 x i64] }, ptr %l26
  %t259 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t263 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t257, { i64, [1 x i64] } %t258, { i64, ptr } %t259)
  store i1 %t263, ptr %l155
  br label %bb75
bb75:
  %t264 = load i1, ptr %l155, !tbaa !21
  br i1 %t264, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb78
bb77:
  %t265 = load i1, ptr %l3, !tbaa !21
  store i1 %t265, ptr %l156, !tbaa !21
  br label %bb78
bb78:
  %t267 = load i1, ptr %l156, !tbaa !21
  store i1 %t267, ptr %l3, !tbaa !21
  br label %bb96
bb79:
  %t268 = load { i64, [15 x i64] }, ptr %l25
  %t270 = extractvalue { i64, [15 x i64] } %t268, 0
  %t271 = icmp eq i64 %t270, 12
  br i1 %t271, label %bb80, label %bb81
bb80:
  %t273 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t274 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t273, i32 0, i32 0
  %t275 = load { i64, [1 x i64] }, ptr %t274
  store { i64, [1 x i64] } %t275, ptr %l27
  %t277 = getelementptr { i64, [15 x i64] }, ptr %l25, i32 0, i32 1
  %t278 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t277, i32 0, i32 1
  %t279 = load { i64, [1 x i64] }, ptr %t278
  store { i64, [1 x i64] } %t279, ptr %l28
  br label %bb82
bb81:
  br label %bb91
bb82:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load { i64, [1 x i64] }, ptr %l27
  %t283 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t287 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t281, { i64, [1 x i64] } %t282, { i64, ptr } %t283)
  store i1 %t287, ptr %l165
  br label %bb83
bb83:
  %t288 = load i1, ptr %l165, !tbaa !21
  br i1 %t288, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb86
bb85:
  %t289 = load i1, ptr %l3, !tbaa !21
  store i1 %t289, ptr %l166, !tbaa !21
  br label %bb86
bb86:
  %t291 = load i1, ptr %l166, !tbaa !21
  store i1 %t291, ptr %l3, !tbaa !21
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, [1 x i64] }, ptr %l28
  %t294 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t298 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t292, { i64, [1 x i64] } %t293, { i64, ptr } %t294)
  store i1 %t298, ptr %l171
  br label %bb87
bb87:
  %t299 = load i1, ptr %l171, !tbaa !21
  br i1 %t299, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb90
bb89:
  %t300 = load i1, ptr %l3, !tbaa !21
  store i1 %t300, ptr %l172, !tbaa !21
  br label %bb90
bb90:
  %t302 = load i1, ptr %l172, !tbaa !21
  store i1 %t302, ptr %l3, !tbaa !21
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_c174e5a3b34e67b9_6250aa572b15a6d5)
  unreachable
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_9206c849bcce77e8_1d8ffc9eff2b8ce4)
  unreachable
bb102:
  call void @__olang_scope_close(ptr %s10)
  br label %bb103
bb103:
  %t303 = load i64, ptr %l20, !tbaa !24
  %t305 = add i64 %t303, 1
  store i64 %t305, ptr %l20, !tbaa !24
  br label %bb41
bb104:
  %t307 = load i64, ptr %l17, !tbaa !24
  %t308 = load i64, ptr %l19, !tbaa !24
  %t311 = add i64 %t307, %t308
  store i64 %t311, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb105
bb105:
  br label %bb34
bb106:
  %t313 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 1
  %t314 = load { i64, [7 x i64] }, ptr %t313
  store { i64, [7 x i64] } %t314, ptr %l29
  %t316 = load { i64, [7 x i64] }, ptr %l29
  %t318 = extractvalue { i64, [7 x i64] } %t316, 0
  %t319 = icmp eq i64 %t318, 7
  br i1 %t319, label %bb107, label %bb108
bb107:
  %t321 = getelementptr { i64, [7 x i64] }, ptr %l29, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t321, i32 0, i32 1
  %t323 = load i32, ptr %t322
  store i32 %t323, ptr %l30, !tbaa !23
  br label %bb109
bb108:
  br label %bb110
bb109:
  %t325 = load i32, ptr %l30, !tbaa !23
  %t327 = sext i32 %t325 to i64
  %t329 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr i1, ptr %t330, i64 %t327
  store i1 true, ptr %t331, !tbaa !31
  br label %bb115
bb110:
  br i1 true, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_5234ed07c88e8ec3_fc55cf91bd0a7f1f)
  unreachable
bb115:
  call void @__olang_scope_close(ptr %s7)
  br label %bb116
bb116:
  %t332 = load i64, ptr %l14, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l14, !tbaa !24
  br label %bb30
bb117:
  %t336 = load i64, ptr %l11, !tbaa !24
  %t337 = load i64, ptr %l13, !tbaa !24
  %t340 = add i64 %t336, %t337
  store i64 %t340, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb118
bb118:
  br label %bb23
bb119:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/mir:Fn", ptr %t342, i32 0, i32 7
  store ptr %t344, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s24
  %t346 = load ptr, ptr %l31, !tbaa !29
  %t347 = load i64, ptr %l32, !tbaa !24
  %t350 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eRunFrom_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t346, i64 %t347)
  %t351 = extractvalue { i32, { i64, ptr } } %t350, 1
  %t352 = extractvalue { i32, { i64, ptr } } %t350, 0
  store i32 %t352, ptr %l196
  %t353 = icmp ne i32 %t352, 0
  br i1 %t353, label %bb122, label %ok.354
ok.354:
  store { i64, ptr } %t351, ptr %l195
  br label %bb121
bb121:
  %t355 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t355, ptr %l192, !tbaa !27
  br label %bb126
bb122:
  %t356 = load i32, ptr %l196, !tbaa !23
  %t357 = ashr i32 %t356, 16
  %t359 = icmp eq i32 %t357, 1
  br i1 %t359, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_163846ebfcde4742_93f6cefa6f5e149e)
  unreachable
bb125:
  call void @__olang_scope_close(ptr %s24)
  br label %bb142
bb126:
  %t361 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t361, ptr %l33, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb127
bb127:
  store %olang.scope zeroinitializer, ptr %s25
  %t366 = load i64, ptr %l35, !tbaa !24
  %t367 = load i64, ptr %l34, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s25)
  br label %bb140
bb129:
  br label %bb130
bb130:
  %t374 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t374, ptr %l205, !tbaa !27
  %t375 = load i64, ptr %l35, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr %"compiler/mir:Local", ptr %t378, i64 %t375
  %t380 = load %"compiler/mir:Local", ptr %t379
  store %"compiler/mir:Local" %t380, ptr %l36
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/mir:Local", ptr %l36, i32 0, i32 4
  %t384 = load { i64, [1 x i64] }, ptr %t383
  %t387 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t382, { i64, [1 x i64] } %t384)
  store i1 %t387, ptr %l210
  br label %bb131
bb131:
  %t388 = load i1, ptr %l210, !tbaa !21
  %t389 = xor i1 %t388, true
  br i1 %t389, label %bb132, label %bb133
bb132:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/mir:Local", ptr %l36, i32 0, i32 4
  %t393 = load { i64, [1 x i64] }, ptr %t392
  %t394 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t398 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %s0, ptr %t391, { i64, [1 x i64] } %t393, { i64, ptr } %t394)
  store i1 %t398, ptr %l215
  br label %bb134
bb133:
  br label %bb138
bb134:
  %t399 = load i1, ptr %l215, !tbaa !21
  br i1 %t399, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb137
bb136:
  %t400 = load i1, ptr %l3, !tbaa !21
  store i1 %t400, ptr %l216, !tbaa !21
  br label %bb137
bb137:
  %t402 = load i1, ptr %l216, !tbaa !21
  store i1 %t402, ptr %l3, !tbaa !21
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s25)
  br label %bb139
bb139:
  %t403 = load i64, ptr %l35, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l35, !tbaa !24
  br label %bb127
bb140:
  %t407 = load i64, ptr %l32, !tbaa !24
  %t408 = load i64, ptr %l34, !tbaa !24
  %t411 = add i64 %t407, %t408
  store i64 %t411, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb141
bb141:
  br label %bb120
bb142:
  store i64 0, ptr %l37, !tbaa !24
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr %"compiler/mir:Fn", ptr %t413, i32 0, i32 8
  %t417 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t415)
  store i64 %t417, ptr %l225
  br label %bb143
bb143:
  %t418 = load i64, ptr %l225, !tbaa !24
  store i64 %t418, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t419 = load i64, ptr %l38, !tbaa !24
  %t420 = load i64, ptr %l37, !tbaa !24
  %t423 = icmp sgt i64 %t419, %t420
  br i1 %t423, label %bb144, label %bb145
bb144:
  %t425 = load i64, ptr %l39, !tbaa !24
  %t427 = icmp sgt i64 %t425, 0
  br i1 %t427, label %bb146, label %bb147
bb145:
  store i64 0, ptr %l229, !tbaa !24
  br label %bb149
bb146:
  %t429 = load i64, ptr %l38, !tbaa !24
  %t430 = load i64, ptr %l37, !tbaa !24
  %t433 = sub i64 %t429, %t430
  %t434 = load i64, ptr %l39, !tbaa !24
  %t437 = add i64 %t433, %t434
  %t439 = sub i64 %t437, 1
  %t440 = load i64, ptr %l39, !tbaa !24
  %t443 = sdiv i64 %t439, %t440
  store i64 %t443, ptr %l232, !tbaa !24
  br label %bb148
bb147:
  store i64 0, ptr %l232, !tbaa !24
  br label %bb148
bb148:
  %t445 = load i64, ptr %l232, !tbaa !24
  store i64 %t445, ptr %l229, !tbaa !24
  br label %bb149
bb149:
  %t446 = load i64, ptr %l229, !tbaa !24
  store i64 %t446, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb150
bb150:
  store %olang.scope zeroinitializer, ptr %s29
  %t447 = load i64, ptr %l41, !tbaa !24
  %t448 = load i64, ptr %l40, !tbaa !24
  %t451 = icmp slt i64 %t447, %t448
  %t453 = xor i1 %t451, true
  br i1 %t453, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s29)
  br label %bb172
bb152:
  br label %bb153
bb153:
  %t455 = load i64, ptr %l37, !tbaa !24
  %t456 = load i64, ptr %l41, !tbaa !24
  %t457 = load i64, ptr %l39, !tbaa !24
  %t460 = mul i64 %t456, %t457
  %t463 = add i64 %t455, %t460
  store i64 %t463, ptr %l42, !tbaa !24
  %t465 = load ptr, ptr %l1, !tbaa !29
  %t467 = getelementptr %"compiler/mir:Fn", ptr %t465, i32 0, i32 8
  %t468 = load i64, ptr %l42, !tbaa !24
  %t471 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t467, i64 %t468)
  store %"compiler/mir:ScopeInfo" %t471, ptr %l253
  br label %bb154
bb154:
  %t472 = getelementptr %"compiler/mir:ScopeInfo", ptr %l253, i32 0, i32 0
  %t473 = load i32, ptr %t472
  store i32 %t473, ptr %l43
  %t475 = load i32, ptr %l43
  %t477 = trunc i64 0 to i32
  %t478 = icmp eq i32 %t475, %t477
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb155, label %bb156
bb155:
  %t482 = load i32, ptr %l43
  %t484 = trunc i64 1 to i32
  %t485 = icmp eq i32 %t482, %t484
  %t487 = xor i1 %t485, true
  store i1 %t487, ptr %l258, !tbaa !21
  br label %bb157
bb156:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb157
bb157:
  %t489 = load i1, ptr %l258, !tbaa !21
  br i1 %t489, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb159:
  br label %bb160
bb160:
  %t490 = load i64, ptr %l42, !tbaa !24
  %t492 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr i1, ptr %t493, i64 %t490
  %t495 = load i1, ptr %t494, !tbaa !31
  br i1 %t495, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l264, !tbaa !21
  br label %bb166
bb162:
  %t497 = load i1, ptr %l3, !tbaa !21
  br i1 %t497, label %bb163, label %bb164
bb163:
  %t499 = load i64, ptr %l42, !tbaa !24
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/emit:fnEm", ptr %t500, i32 0, i32 8
  %t503 = load i64, ptr %t502, !tbaa !24
  %t506 = icmp eq i64 %t499, %t503
  store i1 %t506, ptr %l266, !tbaa !21
  br label %bb165
bb164:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb165
bb165:
  %t508 = load i1, ptr %l266, !tbaa !21
  store i1 %t508, ptr %l264, !tbaa !21
  br label %bb166
bb166:
  %t509 = load i1, ptr %l264, !tbaa !21
  br i1 %t509, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb168:
  br label %bb169
bb169:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/emit:fnEm", ptr %t510, i32 0, i32 24
  %t513 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t512, i64 %t513, i1 true)
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s29)
  br label %bb171
bb171:
  %t516 = load i64, ptr %l41, !tbaa !24
  %t518 = add i64 %t516, 1
  store i64 %t518, ptr %l41, !tbaa !24
  br label %bb150
bb172:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l9
  br label %bb1
bb1:
  %t14 = load i32, ptr %l9, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load i32, ptr %l12
  %t22 = trunc i64 26 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l18
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb5:
  %t30 = load i64, ptr %l18, !tbaa !24
  store i64 %t30, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca i32
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { { i64, ptr }, i32 }
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { { i64, ptr }, i32 }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { { i64, ptr }, i32 }
  %l25 = alloca { { i64, ptr }, i32 }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l40 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l61 = alloca i1
  %l64 = alloca { { i64, ptr }, i32 }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l82 = alloca { { i64, ptr }, i32 }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l91 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load { i64, [15 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [15 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { { i64, [4 x i64] } }, ptr %t14, i32 0, i32 0
  %t16 = load { i64, [4 x i64] }, ptr %t15
  store { i64, [4 x i64] } %t16, ptr %l5
  br label %bb3
bb2:
  br label %bb6
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/mir:Place", ptr %l1
  %t22 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t18, %"compiler/mir:Place" %t19)
  store { { i64, ptr }, i32 } %t22, ptr %l25
  br label %bb4
bb4:
  %t23 = load { { i64, ptr }, i32 }, ptr %l25
  store { { i64, ptr }, i32 } %t23, ptr %l6
  %t24 = getelementptr { { i64, ptr }, i32 }, ptr %l6, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l26, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l27, !tbaa !24
  %t28 = load i64, ptr %l27, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l28, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t43 = load { i64, [4 x i64] }, ptr %l5
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s1, ptr %s1, ptr %t40, { i64, ptr } %t39, i32 %t42, { i64, [4 x i64] } %t43, { i64, ptr } { i64 0, ptr @.d197 })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t49 = load { i64, [15 x i64] }, ptr %l3
  %t51 = extractvalue { i64, [15 x i64] } %t49, 0
  %t52 = icmp eq i64 %t51, 6
  br i1 %t52, label %bb7, label %bb8
bb7:
  %t54 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t55 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t54, i32 0, i32 0
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l8, !tbaa !23
  %t58 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t59 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t58, i32 0, i32 2
  %t60 = load %"compiler/mir:Range", ptr %t59
  store %"compiler/mir:Range" %t60, ptr %l9
  br label %bb9
bb8:
  br label %bb34
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l40
  br label %bb10
bb10:
  %t67 = load i32, ptr %l40, !tbaa !23
  store i32 %t67, ptr %l10, !tbaa !23
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t69 = load i32, ptr %l10, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l43
  br label %bb11
bb11:
  %t73 = load i32, ptr %l43
  store i32 %t73, ptr %l11
  %t74 = load i32, ptr %l11
  %t76 = trunc i64 24 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb19
bb13:
  %t79 = load i32, ptr %l11
  %t81 = trunc i64 18 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = load ptr, ptr %l4, !tbaa !29
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l10, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l53
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb18
bb16:
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = load i32, ptr %l53, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t92, ptr %l54
  br label %bb17
bb17:
  %t93 = load i32, ptr %l54
  %t95 = trunc i64 1 to i32
  %t96 = icmp eq i32 %t93, %t95
  store i1 %t96, ptr %l49, !tbaa !21
  br label %bb18
bb18:
  %t98 = load i1, ptr %l49, !tbaa !21
  store i1 %t98, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t99 = load i1, ptr %l46, !tbaa !21
  br i1 %t99, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load %"compiler/mir:Place", ptr %l1
  %t103 = load %"compiler/mir:Range", ptr %l9
  %t107 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eapart(ptr %v0, ptr %t101, %"compiler/mir:Place" %t102, %"compiler/mir:Range" %t103)
  store i1 %t107, ptr %l61
  br label %bb23
bb23:
  %t108 = load i1, ptr %l61, !tbaa !21
  br i1 %t108, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load %"compiler/mir:Place", ptr %l1
  %t113 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s4, ptr %t109, %"compiler/mir:Place" %t110)
  store { { i64, ptr }, i32 } %t113, ptr %l64
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t114 = load { { i64, ptr }, i32 }, ptr %l64
  store { { i64, ptr }, i32 } %t114, ptr %l12
  %t115 = getelementptr { { i64, ptr }, i32 }, ptr %l12, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l65, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l66, !tbaa !24
  %t119 = load i64, ptr %l66, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l67, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l66, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l2, !tbaa !23
  %t134 = load %"compiler/mir:Range", ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %s4, ptr %t131, { i64, ptr } %t130, i32 %t133, %"compiler/mir:Range" %t134)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb28:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l2, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s2, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l75
  br label %bb29
bb29:
  %t145 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t145, ptr %l14, !tbaa !27
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t148 = load i32, ptr %l2, !tbaa !23
  %t149 = load %"compiler/mir:Range", ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %s2, ptr %t146, { i64, ptr } %t147, i32 %t148, %"compiler/mir:Range" %t149)
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/mir:Place", ptr %l1
  %t158 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s2, ptr %t154, %"compiler/mir:Place" %t155)
  store { { i64, ptr }, i32 } %t158, ptr %l82
  br label %bb31
bb31:
  %t159 = load { { i64, ptr }, i32 }, ptr %l82
  store { { i64, ptr }, i32 } %t159, ptr %l15
  %t160 = getelementptr { { i64, ptr }, i32 }, ptr %l15, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l83, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l84, !tbaa !24
  %t164 = load i64, ptr %l84, !tbaa !24
  %t165 = mul i64 %t164, 1
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l85, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l84, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l86, !tbaa !29
  store { i64, ptr } %t175, ptr %l87, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t178, ptr %l88, !tbaa !27
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l2, !tbaa !23
  %t183 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t179, i32 %t180)
  store i64 %t183, ptr %l91
  br label %bb32
bb32:
  %t184 = load ptr, ptr %l86, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t187 = load i64, ptr %l91, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s2, ptr %s2, ptr %t184, { i64, ptr } %t185, { i64, ptr } %t186, i64 %t187)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_1c84b7c0e51a2751_bb90751f2238f075)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d7426df353af1cf1_5409353fb5c530e5)
  unreachable
bb9:
  %t6 = load i1, ptr %l2, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v2, ptr %t1)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = load ptr, ptr %lp2
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %lp2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = extractvalue { i64, ptr } %t9, 0
  %t14 = extractvalue { i64, ptr } { i64 3, ptr @.d198 }, 1
  %t15 = extractvalue { i64, ptr } { i64 3, ptr @.d198 }, 0
  %t16 = add i64 %t13, %t15
  %t18 = extractvalue { i64, ptr } %a1, 1
  %t19 = extractvalue { i64, ptr } %a1, 0
  %t20 = add i64 %t16, %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t12, i64 %t13)
  %t22 = getelementptr i8, ptr %t21, i64 %t13
  call void @olang_textcopy(ptr %t22, ptr %t14, i64 %t15)
  %t23 = getelementptr i8, ptr %t22, i64 %t15
  call void @olang_textcopy(ptr %t23, ptr %t18, i64 %t19)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } %t32)
  br label %bb2
bb2:
  %t35 = load ptr, ptr %lp2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l4 = alloca i32
  %l13 = alloca i32
  %rv = alloca i32
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  br label %bb16
bb4:
  %t8 = load { i64, [4 x i64] }, ptr %l1
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t14 = getelementptr { %"compiler/mir:Place" }, ptr %t13, i32 0, i32 0
  %t15 = load %"compiler/mir:Place", ptr %t14
  store %"compiler/mir:Place" %t15, ptr %l2
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t18 = load %"compiler/mir:Place", ptr %l2
  %t21 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %t18)
  store i32 %t21, ptr %l13
  br label %bb8
bb8:
  %t22 = load i32, ptr %l13, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb16
bb9:
  %t23 = load { i64, [4 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [4 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  br label %bb14
bb11:
  %t32 = load { i64, [4 x i64] }, ptr %l1
  %t34 = extractvalue { i64, [4 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 3
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t38 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_34175b6f59aa64d9_d8857486e5aa61ad)
  unreachable
bb16:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l17 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load { i64, [4 x i64] }, ptr %l3
  %t11 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2esrcAddr(ptr %v0, ptr %s1, ptr %t7, { i64, [4 x i64] } %t8)
  store { i64, ptr } %t11, ptr %l11
  br label %bb4
bb3:
  br label %bb29
bb4:
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t12, ptr %l5, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr @.d199 })
  store i1 %t15, ptr %l13
  br label %bb5
bb5:
  %t16 = load i1, ptr %l13, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %v1, { i64, ptr } %t19, { i64, ptr } %t20)
  store i1 %t23, ptr %l17
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t30, i32 %t31)
  store i64 %t34, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %s1, ptr %t35, { i64, ptr } %t36, { i64, ptr } %t37, i64 %t38)
  br label %bb12
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t39 = load { i64, [4 x i64] }, ptr %l3
  %t41 = extractvalue { i64, [4 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 2
  br i1 %t42, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  %t44 = load { i64, [4 x i64] }, ptr %l3
  %t46 = extractvalue { i64, [4 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 0
  br i1 %t47, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s4, ptr %s4, ptr %t52, { i64, ptr } { i64 18, ptr @.d200 }, { i64, ptr } { i64 42, ptr @.d201 })
  br label %bb20
bb20:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l32, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t56, i32 %t57)
  store i64 %t60, ptr %l35
  br label %bb21
bb21:
  %t61 = extractvalue { i64, ptr } { i64 34, ptr @.d202 }, 1
  %t62 = extractvalue { i64, ptr } { i64 34, ptr @.d202 }, 0
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = add i64 %t62, %t65
  %t67 = extractvalue { i64, ptr } { i64 12, ptr @.d203 }, 1
  %t68 = extractvalue { i64, ptr } { i64 12, ptr @.d203 }, 0
  %t69 = add i64 %t66, %t68
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t72 = add i64 %t69, %t71
  %t73 = extractvalue { i64, ptr } { i64 11, ptr @.d204 }, 1
  %t74 = extractvalue { i64, ptr } { i64 11, ptr @.d204 }, 0
  %t75 = add i64 %t72, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t61, i64 %t62)
  %t77 = getelementptr i8, ptr %t76, i64 %t62
  call void @olang_textcopy(ptr %t77, ptr %t64, i64 %t65)
  %t78 = getelementptr i8, ptr %t77, i64 %t65
  call void @olang_textcopy(ptr %t78, ptr %t67, i64 %t68)
  %t79 = getelementptr i8, ptr %t78, i64 %t68
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t70)
  %t81 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t81, ptr %t73, i64 %t74)
  %t82 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t76, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s4, ptr %t91, { i64, ptr } %t90)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_3a52453b80be52d1_6c5ca24620edcd6d)
  unreachable
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l38, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t94, i32 %t95)
  store { i64, ptr } %t98, ptr %l41
  br label %bb30
bb30:
  %t99 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = extractvalue { i64, ptr } %t99, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l42, !tbaa !27
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load { i64, [4 x i64] }, ptr %l3
  %t108 = load i32, ptr %l2, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t106, { i64, [4 x i64] } %t107, i32 %t108)
  store { i64, ptr } %t112, ptr %l46
  br label %bb31
bb31:
  %t113 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t120 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t122 = load ptr, ptr %l38, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %t122, { i64, ptr } %t123, { i64, ptr } %t119, { i64, ptr } %t120, { i64, ptr } %a4)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eref(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { { i64, ptr }, i32 }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i32
  %l14 = alloca { { i64, ptr }, i32 }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i64
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s0, ptr %t9, %"compiler/mir:Place" %a1)
  store { { i64, ptr }, i32 } %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load { { i64, ptr }, i32 }, ptr %l14
  store { { i64, ptr }, i32 } %t14, ptr %l4
  %t15 = getelementptr { { i64, ptr }, i32 }, ptr %l4, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l15, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t31 = getelementptr { { i64, ptr }, i32 }, ptr %l4, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t35, i32 %a2)
  store i32 %t39, ptr %l22
  br label %bb2
bb2:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i32, ptr %l22, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t42, ptr %l23
  br label %bb3
bb3:
  %t43 = load i32, ptr %l23, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t48 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t44, i32 %t43)
  store i1 %t48, ptr %l26
  br label %bb4
bb4:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb5, label %bb6
bb5:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l6, !tbaa !23
  %t54 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l29
  br label %bb7
bb6:
  br label %bb18
bb7:
  %t55 = load i32, ptr %l29, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  %t56 = load i32, ptr %l8, !tbaa !23
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t60 = icmp ne i32 %t56, %t57
  br i1 %t60, label %bb8, label %bb9
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l36
  br label %bb10
bb9:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  %t67 = load i1, ptr %l36, !tbaa !21
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t68 = load i1, ptr %l33, !tbaa !21
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l8, !tbaa !23
  %t74 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t70, i32 %t71)
  store i64 %t74, ptr %l40
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t75)
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  %t78 = call i64 @__olang_fmt_i64(ptr %t77, i64 %t75)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } %t80, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t88 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %s0, ptr %v1, ptr %t89, { i64, ptr } %t87, { i64, ptr } %t88)
  store { i64, ptr } %t92, ptr %l44
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/emit:fnEm", ptr %t96, i32 0, i32 14
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s0, ptr %v0, ptr %v1, ptr %t94, { i64, ptr } { i64 12, ptr @.d205 }, { i64, ptr } %t95, { i64, ptr } %t99)
  store { i64, ptr } %t103, ptr %l49
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
bb18:
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t105, ptr %l50, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l51, !tbaa !24
  %t108 = load i64, ptr %l51, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l52, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l51, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = sext i32 %t10 to i64
  %t16 = icmp eq i64 %t12, %a2
  store i1 %t16, ptr %l4, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b58edc65c6718b49_26c0578031dccca5)
  unreachable
bb9:
  %t18 = load i1, ptr %l4, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:Local"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca i8
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i32
  %l42 = alloca i32
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca %"compiler/mir:BasicBlock"
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca { i64, [21 x i64] }
  %l84 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i64
  %l143 = alloca %"compiler/mir:ScopeInfo"
  %l146 = alloca i1
  %l156 = alloca i64
  %l160 = alloca i64
  %l163 = alloca i64
  %l184 = alloca %"compiler/mir:Local"
  %l188 = alloca i1
  %l194 = alloca { i64, ptr }
  %l197 = alloca i1
  %l207 = alloca i1
  %l214 = alloca i64
  %l219 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca i64
  %l225 = alloca i64
  %l228 = alloca i64
  %l244 = alloca i64
  %l248 = alloca i64
  %l251 = alloca i64
  %l272 = alloca i1
  %l273 = alloca i1
  %l277 = alloca i1
  %l281 = alloca %"compiler/mir:ScopeInfo"
  %l298 = alloca %"compiler/mir:ScopeInfo"
  %l319 = alloca { i64, ptr }
  %l321 = alloca i1
  %l331 = alloca { i64, ptr }
  %l334 = alloca i64
  %l338 = alloca i64
  %l341 = alloca i64
  %l362 = alloca i32
  %l367 = alloca %"compiler/mir:Local"
  %l369 = alloca ptr
  %l373 = alloca %"compiler/mir:Local"
  %l375 = alloca i1
  %l385 = alloca ptr
  %l386 = alloca i64
  %l387 = alloca i64
  %l390 = alloca i64
  %l415 = alloca ptr
  %l418 = alloca { i64, ptr }
  %l428 = alloca i64
  %l432 = alloca i64
  %l435 = alloca i64
  %l456 = alloca i32
  %l461 = alloca %"compiler/mir:Local"
  %l465 = alloca i1
  %l466 = alloca i1
  %l469 = alloca i1
  %l475 = alloca { i64, ptr }
  %l476 = alloca ptr
  %l480 = alloca { i64, ptr }
  %l490 = alloca i64
  %l493 = alloca { i64, ptr }
  %l496 = alloca i64
  %l500 = alloca i64
  %l503 = alloca i64
  %l524 = alloca i32
  %l526 = alloca ptr
  %l530 = alloca %"compiler/mir:Local"
  %l532 = alloca { i64, ptr }
  %l533 = alloca ptr
  %l537 = alloca %"compiler/mir:Local"
  %l539 = alloca i1
  %l549 = alloca ptr
  %l553 = alloca %"compiler/mir:Local"
  %l555 = alloca i1
  %l559 = alloca ptr
  %l560 = alloca i64
  %l561 = alloca i64
  %l562 = alloca ptr
  %l566 = alloca %"compiler/mir:Local"
  %l568 = alloca i64
  %l593 = alloca i64
  %l597 = alloca i64
  %l600 = alloca i64
  %l619 = alloca ptr
  %l620 = alloca i64
  %l621 = alloca { i64, ptr }
  %l624 = alloca i64
  %l636 = alloca ptr
  %l637 = alloca i64
  %l638 = alloca i64
  %l640 = alloca { i64, ptr }
  %l645 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l648 = alloca i1
  %l651 = alloca { i64, ptr }
  %l654 = alloca { i64, ptr }
  %l655 = alloca i32
  %l664 = alloca { i64, ptr }
  %l677 = alloca i64
  %l681 = alloca i64
  %l684 = alloca i64
  %l702 = alloca ptr
  %l706 = alloca { i64, ptr }
  %l711 = alloca %"compiler/mir:BasicBlock"
  %l714 = alloca i1
  %l719 = alloca { i64, ptr }
  %l722 = alloca { i64, ptr }
  %l723 = alloca i32
  %l732 = alloca { i64, ptr }
  %l734 = alloca { i64, [21 x i64] }
  %l751 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s69 = alloca %olang.scope
  %s72 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s76 = alloca %olang.scope
  %s79 = alloca %olang.scope
  %s80 = alloca %olang.scope
  %s83 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 3
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l84, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/mir:Fn", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t15, i32 %t19)
  store i32 %t22, ptr %l88
  br label %bb1
bb1:
  %t23 = load i32, ptr %l88, !tbaa !23
  %t24 = load ptr, ptr %l84, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t24, i32 0, i32 9
  store i32 %t23, ptr %t25, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l89, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l90, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/mir:Fn", ptr %t29, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t28, i32 %t32)
  store i32 %t35, ptr %l94
  br label %bb2
bb2:
  %t36 = load ptr, ptr %l90, !tbaa !29
  %t37 = load i32, ptr %l94, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l95
  br label %bb3
bb3:
  %t39 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t42 = icmp sgt i64 %t40, 0
  %t44 = load ptr, ptr %l89, !tbaa !29
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %t44, i32 0, i32 10
  store i1 %t42, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l98, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:fnEm", ptr %t47, i32 0, i32 9
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t54 = icmp ne i32 %t50, %t51
  br i1 %t54, label %bb4, label %bb5
bb4:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/emit:fnEm", ptr %t56, i32 0, i32 9
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t63 = icmp ne i32 %t59, %t60
  store i1 %t63, ptr %l103, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb6
bb6:
  %t65 = load i1, ptr %l103, !tbaa !21
  br i1 %t65, label %bb7, label %bb8
bb7:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/emit:fnEm", ptr %t67, i32 0, i32 9
  %t70 = load i32, ptr %t69, !tbaa !23
  %t73 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t66, i32 %t70)
  store i1 %t73, ptr %l112
  br label %bb9
bb8:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb10
bb9:
  %t74 = load i1, ptr %l112, !tbaa !21
  store i1 %t74, ptr %l108, !tbaa !21
  br label %bb10
bb10:
  %t75 = load i1, ptr %l108, !tbaa !21
  %t76 = load ptr, ptr %l98, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t76, i32 0, i32 11
  store i1 %t75, ptr %t77, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 8
  %t82 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l115
  br label %bb11
bb11:
  %t83 = load i64, ptr %l115, !tbaa !24
  store i64 %t83, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb17
bb14:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t95 = load i64, ptr %l3, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l5, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l122, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb16
bb16:
  %t110 = load i64, ptr %l122, !tbaa !24
  store i64 %t110, ptr %l119, !tbaa !24
  br label %bb17
bb17:
  %t111 = load i64, ptr %l119, !tbaa !24
  store i64 %t111, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t112 = load i64, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb20:
  br label %bb21
bb21:
  %t120 = load i64, ptr %l3, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l5, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l8, !tbaa !24
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/mir:Fn", ptr %t130, i32 0, i32 8
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t132, i64 %t133)
  store %"compiler/mir:ScopeInfo" %t136, ptr %l143
  br label %bb22
bb22:
  %t137 = getelementptr %"compiler/mir:ScopeInfo", ptr %l143, i32 0, i32 0
  %t138 = load i32, ptr %t137
  %t140 = trunc i64 0 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb23, label %bb24
bb23:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/emit:fnEm", ptr %t143, i32 0, i32 8
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  store i1 %t148, ptr %l146, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb25
bb25:
  %t150 = load i1, ptr %l146, !tbaa !21
  br i1 %t150, label %bb26, label %bb27
bb26:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l8, !tbaa !24
  %t155 = getelementptr %"compiler/emit:fnEm", ptr %t151, i32 0, i32 8
  store i64 %t152, ptr %t155, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t156 = load i64, ptr %l7, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l7, !tbaa !24
  br label %bb18
bb30:
  store i64 0, ptr %l9, !tbaa !24
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/mir:Fn", ptr %t160, i32 0, i32 7
  %t164 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l156
  br label %bb31
bb31:
  %t165 = load i64, ptr %l156, !tbaa !24
  store i64 %t165, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t167 = load i64, ptr %l9, !tbaa !24
  %t170 = icmp sgt i64 %t166, %t167
  br i1 %t170, label %bb32, label %bb33
bb32:
  %t172 = load i64, ptr %l11, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb37
bb34:
  %t176 = load i64, ptr %l10, !tbaa !24
  %t177 = load i64, ptr %l9, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load i64, ptr %l11, !tbaa !24
  %t184 = add i64 %t180, %t181
  %t186 = sub i64 %t184, 1
  %t187 = load i64, ptr %l11, !tbaa !24
  %t190 = sdiv i64 %t186, %t187
  store i64 %t190, ptr %l163, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb36
bb36:
  %t192 = load i64, ptr %l163, !tbaa !24
  store i64 %t192, ptr %l160, !tbaa !24
  br label %bb37
bb37:
  %t193 = load i64, ptr %l160, !tbaa !24
  store i64 %t193, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t194 = load i64, ptr %l13, !tbaa !24
  %t195 = load i64, ptr %l12, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb75
bb40:
  br label %bb41
bb41:
  %t202 = load i64, ptr %l9, !tbaa !24
  %t203 = load i64, ptr %l13, !tbaa !24
  %t204 = load i64, ptr %l11, !tbaa !24
  %t207 = mul i64 %t203, %t204
  %t210 = add i64 %t202, %t207
  store i64 %t210, ptr %l14, !tbaa !24
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/mir:Fn", ptr %t212, i32 0, i32 7
  %t215 = load i64, ptr %l14, !tbaa !24
  %t218 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t214, i64 %t215)
  store %"compiler/mir:Local" %t218, ptr %l184
  br label %bb42
bb42:
  %t219 = load %"compiler/mir:Local", ptr %l184
  store %"compiler/mir:Local" %t219, ptr %l15
  %t220 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t221 = load i32, ptr %t220, !tbaa !23
  %t222 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t225 = icmp eq i32 %t221, %t222
  br i1 %t225, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb45
bb44:
  %t227 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t228 = load i32, ptr %t227, !tbaa !23
  %t229 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t232 = icmp eq i32 %t228, %t229
  store i1 %t232, ptr %l188, !tbaa !21
  br label %bb45
bb45:
  %t234 = load i1, ptr %l188, !tbaa !21
  br i1 %t234, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb74
bb47:
  br label %bb48
bb48:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t237 = load i32, ptr %t236, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t235, i32 %t237)
  store { i64, ptr } %t240, ptr %l194
  br label %bb49
bb49:
  %t241 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 4
  %t244 = load { i64, [1 x i64] }, ptr %t243
  %t247 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t242, { i64, [1 x i64] } %t244)
  store i1 %t247, ptr %l197
  br label %bb50
bb50:
  %t248 = load i1, ptr %l197, !tbaa !21
  %t249 = xor i1 %t248, true
  br i1 %t249, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/emit:fnEm", ptr %t251, i32 0, i32 3
  %t254 = load i64, ptr %l14, !tbaa !24
  %t255 = extractvalue { i64, ptr } { i64 5, ptr @.d206 }, 1
  %t256 = extractvalue { i64, ptr } { i64 5, ptr @.d206 }, 0
  %t258 = call i64 @__olang_fmt_i64(ptr null, i64 %t254)
  %t259 = add i64 %t256, %t258
  %t260 = extractvalue { i64, ptr } { i64 14, ptr @.d207 }, 1
  %t261 = extractvalue { i64, ptr } { i64 14, ptr @.d207 }, 0
  %t262 = add i64 %t259, %t261
  %t263 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t262)
  call void @olang_textcopy(ptr %t263, ptr %t255, i64 %t256)
  %t264 = getelementptr i8, ptr %t263, i64 %t256
  %t265 = call i64 @__olang_fmt_i64(ptr %t264, i64 %t254)
  %t266 = getelementptr i8, ptr %t264, i64 %t258
  call void @olang_textcopy(ptr %t266, ptr %t260, i64 %t261)
  %t267 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t263, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t253, { i64, ptr } %t275)
  br label %bb53
bb52:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t280 = load i32, ptr %t279, !tbaa !23
  %t283 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t278, i32 %t280)
  store i64 %t283, ptr %l214
  br label %bb61
bb53:
  %t284 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 3
  %t285 = load i32, ptr %t284
  %t287 = trunc i64 2 to i32
  %t288 = icmp eq i32 %t285, %t287
  %t290 = xor i1 %t288, true
  br i1 %t290, label %bb54, label %bb55
bb54:
  %t292 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 3
  %t293 = load i32, ptr %t292
  %t295 = trunc i64 3 to i32
  %t296 = icmp eq i32 %t293, %t295
  %t298 = xor i1 %t296, true
  store i1 %t298, ptr %l207, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb56
bb56:
  %t300 = load i1, ptr %l207, !tbaa !21
  br i1 %t300, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  %t301 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s10, ptr %t301, { i64, ptr } { i64 34, ptr @.d208 })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s8)
  br label %bb73
bb61:
  %t303 = load i64, ptr %l214, !tbaa !24
  %t304 = icmp sgt i64 %t303, 65536
  br i1 %t304, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s12
  %t306 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %t306)
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/emit:fnEm", ptr %t308, i32 0, i32 3
  %t311 = load i64, ptr %l14, !tbaa !24
  %t312 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t313 = extractvalue { i64, ptr } { i64 4, ptr @.d209 }, 1
  %t314 = extractvalue { i64, ptr } { i64 4, ptr @.d209 }, 0
  %t316 = call i64 @__olang_fmt_i64(ptr null, i64 %t311)
  %t317 = add i64 %t314, %t316
  %t318 = extractvalue { i64, ptr } { i64 10, ptr @.d210 }, 1
  %t319 = extractvalue { i64, ptr } { i64 10, ptr @.d210 }, 0
  %t320 = add i64 %t317, %t319
  %t322 = extractvalue { i64, ptr } %t312, 1
  %t323 = extractvalue { i64, ptr } %t312, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr @.d211 }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr @.d211 }, 0
  %t327 = add i64 %t324, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t313, i64 %t314)
  %t329 = getelementptr i8, ptr %t328, i64 %t314
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t311)
  %t331 = getelementptr i8, ptr %t329, i64 %t316
  call void @olang_textcopy(ptr %t331, ptr %t318, i64 %t319)
  %t332 = getelementptr i8, ptr %t331, i64 %t319
  call void @olang_textcopy(ptr %t332, ptr %t322, i64 %t323)
  %t333 = getelementptr i8, ptr %t332, i64 %t323
  call void @olang_textcopy(ptr %t333, ptr %t325, i64 %t326)
  %t334 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t328, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s14, ptr %t310, { i64, ptr } %t342)
  br label %bb71
bb64:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t347 = load i32, ptr %t346, !tbaa !23
  %t350 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t345, i32 %t347)
  store i64 %t350, ptr %l219
  br label %bb65
bb65:
  %t351 = load i64, ptr %l219, !tbaa !24
  store i64 %t351, ptr %l17, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/emit:fnEm", ptr %t352, i32 0, i32 4
  store ptr %t354, ptr %l221, !tbaa !29
  %t355 = load i64, ptr %l14, !tbaa !24
  store i64 %t355, ptr %l222, !tbaa !24
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/mir:Local", ptr %l15, i32 0, i32 2
  %t358 = load i32, ptr %t357, !tbaa !23
  %t361 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t356, i32 %t358)
  store i64 %t361, ptr %l225
  br label %bb66
bb66:
  %t362 = load i64, ptr %l17, !tbaa !24
  %t364 = icmp sgt i64 %t362, 8
  br i1 %t364, label %bb67, label %bb68
bb67:
  %t366 = load i64, ptr %l17, !tbaa !24
  store i64 %t366, ptr %l228, !tbaa !24
  br label %bb69
bb68:
  store i64 8, ptr %l228, !tbaa !24
  br label %bb69
bb69:
  %t368 = extractvalue { i64, ptr } { i64 4, ptr @.d212 }, 1
  %t369 = extractvalue { i64, ptr } { i64 4, ptr @.d212 }, 0
  %t370 = load i64, ptr %l222, !tbaa !24
  %t371 = call i64 @__olang_fmt_i64(ptr null, i64 %t370)
  %t372 = add i64 %t369, %t371
  %t373 = extractvalue { i64, ptr } { i64 49, ptr @.d213 }, 1
  %t374 = extractvalue { i64, ptr } { i64 49, ptr @.d213 }, 0
  %t375 = add i64 %t372, %t374
  %t376 = load i64, ptr %l225, !tbaa !24
  %t377 = call i64 @__olang_fmt_i64(ptr null, i64 %t376)
  %t378 = add i64 %t375, %t377
  %t379 = extractvalue { i64, ptr } { i64 6, ptr @.d214 }, 1
  %t380 = extractvalue { i64, ptr } { i64 6, ptr @.d214 }, 0
  %t381 = add i64 %t378, %t380
  %t382 = load i64, ptr %l228, !tbaa !24
  %t383 = call i64 @__olang_fmt_i64(ptr null, i64 %t382)
  %t384 = add i64 %t381, %t383
  %t385 = extractvalue { i64, ptr } { i64 2, ptr @.d215 }, 1
  %t386 = extractvalue { i64, ptr } { i64 2, ptr @.d215 }, 0
  %t387 = add i64 %t384, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t368, i64 %t369)
  %t389 = getelementptr i8, ptr %t388, i64 %t369
  %t390 = call i64 @__olang_fmt_i64(ptr %t389, i64 %t370)
  %t391 = getelementptr i8, ptr %t389, i64 %t371
  call void @olang_textcopy(ptr %t391, ptr %t373, i64 %t374)
  %t392 = getelementptr i8, ptr %t391, i64 %t374
  %t393 = call i64 @__olang_fmt_i64(ptr %t392, i64 %t376)
  %t394 = getelementptr i8, ptr %t392, i64 %t377
  call void @olang_textcopy(ptr %t394, ptr %t379, i64 %t380)
  %t395 = getelementptr i8, ptr %t394, i64 %t380
  %t396 = call i64 @__olang_fmt_i64(ptr %t395, i64 %t382)
  %t397 = getelementptr i8, ptr %t395, i64 %t383
  call void @olang_textcopy(ptr %t397, ptr %t385, i64 %t386)
  %t398 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t388, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  %t407 = load ptr, ptr %l221, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s12, ptr %t407, { i64, ptr } %t406)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb72
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s6)
  br label %bb74
bb74:
  %t409 = load i64, ptr %l13, !tbaa !24
  %t411 = add i64 %t409, 1
  store i64 %t411, ptr %l13, !tbaa !24
  br label %bb38
bb75:
  %t413 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindDirect(ptr %v0, ptr %t413)
  br label %bb76
bb76:
  %t415 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindIdle(ptr %v0, ptr %t415)
  br label %bb77
bb77:
  store i64 0, ptr %l18, !tbaa !24
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr %"compiler/mir:Fn", ptr %t417, i32 0, i32 8
  %t421 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t419)
  store i64 %t421, ptr %l244
  br label %bb78
bb78:
  %t422 = load i64, ptr %l244, !tbaa !24
  store i64 %t422, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t423 = load i64, ptr %l19, !tbaa !24
  %t424 = load i64, ptr %l18, !tbaa !24
  %t427 = icmp sgt i64 %t423, %t424
  br i1 %t427, label %bb79, label %bb80
bb79:
  %t429 = load i64, ptr %l20, !tbaa !24
  %t431 = icmp sgt i64 %t429, 0
  br i1 %t431, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l248, !tbaa !24
  br label %bb84
bb81:
  %t433 = load i64, ptr %l19, !tbaa !24
  %t434 = load i64, ptr %l18, !tbaa !24
  %t437 = sub i64 %t433, %t434
  %t438 = load i64, ptr %l20, !tbaa !24
  %t441 = add i64 %t437, %t438
  %t443 = sub i64 %t441, 1
  %t444 = load i64, ptr %l20, !tbaa !24
  %t447 = sdiv i64 %t443, %t444
  store i64 %t447, ptr %l251, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb83
bb83:
  %t449 = load i64, ptr %l251, !tbaa !24
  store i64 %t449, ptr %l248, !tbaa !24
  br label %bb84
bb84:
  %t450 = load i64, ptr %l248, !tbaa !24
  store i64 %t450, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s18
  %t451 = load i64, ptr %l22, !tbaa !24
  %t452 = load i64, ptr %l21, !tbaa !24
  %t455 = icmp slt i64 %t451, %t452
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s18)
  br label %bb113
bb87:
  br label %bb88
bb88:
  %t459 = load i64, ptr %l18, !tbaa !24
  %t460 = load i64, ptr %l22, !tbaa !24
  %t461 = load i64, ptr %l20, !tbaa !24
  %t464 = mul i64 %t460, %t461
  %t467 = add i64 %t459, %t464
  store i64 %t467, ptr %l23, !tbaa !24
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/emit:fnEm", ptr %t469, i32 0, i32 23
  %t472 = load i64, ptr %l23, !tbaa !24
  %t475 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t471, i64 %t472)
  store i1 %t475, ptr %l272
  br label %bb89
bb89:
  %t476 = load i1, ptr %l272, !tbaa !21
  br i1 %t476, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l273, !tbaa !21
  br label %bb93
bb91:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/emit:fnEm", ptr %t477, i32 0, i32 24
  %t480 = load i64, ptr %l23, !tbaa !24
  %t483 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t479, i64 %t480)
  store i1 %t483, ptr %l277
  br label %bb92
bb92:
  %t484 = load i1, ptr %l277, !tbaa !21
  store i1 %t484, ptr %l273, !tbaa !21
  br label %bb93
bb93:
  %t485 = load i1, ptr %l273, !tbaa !21
  br i1 %t485, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s18)
  br label %bb112
bb95:
  br label %bb96
bb96:
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t488 = getelementptr %"compiler/mir:Fn", ptr %t486, i32 0, i32 8
  %t489 = load i64, ptr %l23, !tbaa !24
  %t492 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t488, i64 %t489)
  store %"compiler/mir:ScopeInfo" %t492, ptr %l281
  br label %bb97
bb97:
  %t493 = getelementptr %"compiler/mir:ScopeInfo", ptr %l281, i32 0, i32 0
  %t494 = load i32, ptr %t493
  %t496 = trunc i64 6 to i32
  %t497 = icmp eq i32 %t494, %t496
  br i1 %t497, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s20
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/emit:fnEm", ptr %t499, i32 0, i32 3
  %t502 = load i64, ptr %l23, !tbaa !24
  %t503 = load i64, ptr %l23, !tbaa !24
  %t504 = extractvalue { i64, ptr } { i64 4, ptr @.d216 }, 1
  %t505 = extractvalue { i64, ptr } { i64 4, ptr @.d216 }, 0
  %t507 = call i64 @__olang_fmt_i64(ptr null, i64 %t502)
  %t508 = add i64 %t505, %t507
  %t509 = extractvalue { i64, ptr } { i64 29, ptr @.d217 }, 1
  %t510 = extractvalue { i64, ptr } { i64 29, ptr @.d217 }, 0
  %t511 = add i64 %t508, %t510
  %t513 = call i64 @__olang_fmt_i64(ptr null, i64 %t503)
  %t514 = add i64 %t511, %t513
  %t515 = extractvalue { i64, ptr } { i64 33, ptr @.d218 }, 1
  %t516 = extractvalue { i64, ptr } { i64 33, ptr @.d218 }, 0
  %t517 = add i64 %t514, %t516
  %t518 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t517)
  call void @olang_textcopy(ptr %t518, ptr %t504, i64 %t505)
  %t519 = getelementptr i8, ptr %t518, i64 %t505
  %t520 = call i64 @__olang_fmt_i64(ptr %t519, i64 %t502)
  %t521 = getelementptr i8, ptr %t519, i64 %t507
  call void @olang_textcopy(ptr %t521, ptr %t509, i64 %t510)
  %t522 = getelementptr i8, ptr %t521, i64 %t510
  %t523 = call i64 @__olang_fmt_i64(ptr %t522, i64 %t503)
  %t524 = getelementptr i8, ptr %t522, i64 %t513
  call void @olang_textcopy(ptr %t524, ptr %t515, i64 %t516)
  %t525 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t526 = insertvalue { i64, ptr } %t525, ptr %t518, 1
  %t528 = extractvalue { i64, ptr } %t526, 0
  %t529 = extractvalue { i64, ptr } %t526, 1
  %t530 = mul i64 %t528, 1
  %t531 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t530)
  call void @llvm.memcpy.p0.p0.i64(ptr %t531, ptr %t529, i64 %t530, i1 false)
  %t532 = insertvalue { i64, ptr } undef, i64 %t528, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t531, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s20, ptr %t501, { i64, ptr } %t533)
  br label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s22
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/emit:fnEm", ptr %t536, i32 0, i32 3
  %t539 = load i64, ptr %l23, !tbaa !24
  %t540 = extractvalue { i64, ptr } { i64 4, ptr @.d219 }, 1
  %t541 = extractvalue { i64, ptr } { i64 4, ptr @.d219 }, 0
  %t543 = call i64 @__olang_fmt_i64(ptr null, i64 %t539)
  %t544 = add i64 %t541, %t543
  %t545 = extractvalue { i64, ptr } { i64 23, ptr @.d220 }, 1
  %t546 = extractvalue { i64, ptr } { i64 23, ptr @.d220 }, 0
  %t547 = add i64 %t544, %t546
  %t548 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t547)
  call void @olang_textcopy(ptr %t548, ptr %t540, i64 %t541)
  %t549 = getelementptr i8, ptr %t548, i64 %t541
  %t550 = call i64 @__olang_fmt_i64(ptr %t549, i64 %t539)
  %t551 = getelementptr i8, ptr %t549, i64 %t543
  call void @olang_textcopy(ptr %t551, ptr %t545, i64 %t546)
  %t552 = insertvalue { i64, ptr } undef, i64 %t547, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t548, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = extractvalue { i64, ptr } %t553, 1
  %t557 = mul i64 %t555, 1
  %t558 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t557)
  call void @llvm.memcpy.p0.p0.i64(ptr %t558, ptr %t556, i64 %t557, i1 false)
  %t559 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t538, { i64, ptr } %t560)
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s20)
  br label %bb111
bb101:
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr %"compiler/mir:Fn", ptr %t563, i32 0, i32 8
  %t566 = load i64, ptr %l23, !tbaa !24
  %t569 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t565, i64 %t566)
  store %"compiler/mir:ScopeInfo" %t569, ptr %l298
  br label %bb102
bb102:
  %t570 = getelementptr %"compiler/mir:ScopeInfo", ptr %l298, i32 0, i32 0
  %t571 = load i32, ptr %t570
  %t573 = trunc i64 3 to i32
  %t574 = icmp eq i32 %t571, %t573
  br i1 %t574, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s24
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/emit:fnEm", ptr %t576, i32 0, i32 3
  %t579 = load i64, ptr %l23, !tbaa !24
  %t580 = extractvalue { i64, ptr } { i64 5, ptr @.d221 }, 1
  %t581 = extractvalue { i64, ptr } { i64 5, ptr @.d221 }, 0
  %t583 = call i64 @__olang_fmt_i64(ptr null, i64 %t579)
  %t584 = add i64 %t581, %t583
  %t585 = extractvalue { i64, ptr } { i64 14, ptr @.d222 }, 1
  %t586 = extractvalue { i64, ptr } { i64 14, ptr @.d222 }, 0
  %t587 = add i64 %t584, %t586
  %t588 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t587)
  call void @olang_textcopy(ptr %t588, ptr %t580, i64 %t581)
  %t589 = getelementptr i8, ptr %t588, i64 %t581
  %t590 = call i64 @__olang_fmt_i64(ptr %t589, i64 %t579)
  %t591 = getelementptr i8, ptr %t589, i64 %t583
  call void @olang_textcopy(ptr %t591, ptr %t585, i64 %t586)
  %t592 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t588, 1
  %t595 = extractvalue { i64, ptr } %t593, 0
  %t596 = extractvalue { i64, ptr } %t593, 1
  %t597 = mul i64 %t595, 1
  %t598 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t597)
  call void @llvm.memcpy.p0.p0.i64(ptr %t598, ptr %t596, i64 %t597, i1 false)
  %t599 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s24, ptr %t578, { i64, ptr } %t600)
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s24)
  br label %bb106
bb106:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/emit:fnEm", ptr %t603, i32 0, i32 0
  %t606 = load ptr, ptr %t605, !tbaa !29
  %t608 = getelementptr %"compiler/emit:Emitter", ptr %t606, i32 0, i32 4
  %t609 = load i1, ptr %t608, !tbaa !21
  br i1 %t609, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s26
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/emit:fnEm", ptr %t611, i32 0, i32 3
  %t614 = load i64, ptr %l23, !tbaa !24
  %t615 = extractvalue { i64, ptr } { i64 4, ptr @.d223 }, 1
  %t616 = extractvalue { i64, ptr } { i64 4, ptr @.d223 }, 0
  %t618 = call i64 @__olang_fmt_i64(ptr null, i64 %t614)
  %t619 = add i64 %t616, %t618
  %t620 = extractvalue { i64, ptr } { i64 24, ptr @.d224 }, 1
  %t621 = extractvalue { i64, ptr } { i64 24, ptr @.d224 }, 0
  %t622 = add i64 %t619, %t621
  %t623 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t622)
  call void @olang_textcopy(ptr %t623, ptr %t615, i64 %t616)
  %t624 = getelementptr i8, ptr %t623, i64 %t616
  %t625 = call i64 @__olang_fmt_i64(ptr %t624, i64 %t614)
  %t626 = getelementptr i8, ptr %t624, i64 %t618
  call void @olang_textcopy(ptr %t626, ptr %t620, i64 %t621)
  %t627 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t623, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = extractvalue { i64, ptr } %t628, 1
  %t632 = mul i64 %t630, 1
  %t633 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t632)
  call void @llvm.memcpy.p0.p0.i64(ptr %t633, ptr %t631, i64 %t632, i1 false)
  %t634 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t633, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s26, ptr %t613, { i64, ptr } %t635)
  br label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_scope_close(ptr %s26)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s22)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s18)
  br label %bb112
bb112:
  %t638 = load i64, ptr %l22, !tbaa !24
  %t640 = add i64 %t638, 1
  store i64 %t640, ptr %l22, !tbaa !24
  br label %bb85
bb113:
  %t642 = load ptr, ptr %l2, !tbaa !29
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr %"compiler/mir:Fn", ptr %t643, i32 0, i32 1
  %t646 = load i32, ptr %t645, !tbaa !23
  %t649 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t642, i32 %t646)
  store { i64, ptr } %t649, ptr %l319
  br label %bb114
bb114:
  %t650 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t650, ptr %l24, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t653 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t651, { i64, ptr } { i64 4, ptr @.d225 })
  store i1 %t653, ptr %l321
  br label %bb115
bb115:
  %t654 = load i1, ptr %l321, !tbaa !21
  %t655 = xor i1 %t654, true
  br i1 %t655, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s29
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/emit:fnEm", ptr %t657, i32 0, i32 3
  %t660 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t661 = extractvalue { i64, ptr } { i64 15, ptr @.d226 }, 1
  %t662 = extractvalue { i64, ptr } { i64 15, ptr @.d226 }, 0
  %t664 = extractvalue { i64, ptr } %t660, 1
  %t665 = extractvalue { i64, ptr } %t660, 0
  %t666 = add i64 %t662, %t665
  %t667 = extractvalue { i64, ptr } { i64 1, ptr @.d227 }, 1
  %t668 = extractvalue { i64, ptr } { i64 1, ptr @.d227 }, 0
  %t669 = add i64 %t666, %t668
  %t670 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t669)
  call void @olang_textcopy(ptr %t670, ptr %t661, i64 %t662)
  %t671 = getelementptr i8, ptr %t670, i64 %t662
  call void @olang_textcopy(ptr %t671, ptr %t664, i64 %t665)
  %t672 = getelementptr i8, ptr %t671, i64 %t665
  call void @olang_textcopy(ptr %t672, ptr %t667, i64 %t668)
  %t673 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t670, 1
  %t676 = extractvalue { i64, ptr } %t674, 0
  %t677 = extractvalue { i64, ptr } %t674, 1
  %t678 = mul i64 %t676, 1
  %t679 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t678)
  call void @llvm.memcpy.p0.p0.i64(ptr %t679, ptr %t677, i64 %t678, i1 false)
  %t680 = insertvalue { i64, ptr } undef, i64 %t676, 0
  %t681 = insertvalue { i64, ptr } %t680, ptr %t679, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s29, ptr %t659, { i64, ptr } %t681)
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_scope_close(ptr %s29)
  br label %bb119
bb119:
  %t684 = load ptr, ptr %l2, !tbaa !29
  %t685 = load ptr, ptr %l1, !tbaa !29
  %t687 = getelementptr %"compiler/mir:Fn", ptr %t685, i32 0, i32 1
  %t688 = load i32, ptr %t687, !tbaa !23
  %t691 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t684, i32 %t688)
  store { i64, ptr } %t691, ptr %l331
  br label %bb120
bb120:
  %t692 = load { i64, ptr }, ptr %l331, !tbaa !27
  store { i64, ptr } %t692, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t693 = load ptr, ptr %l1, !tbaa !29
  %t695 = getelementptr %"compiler/mir:Fn", ptr %t693, i32 0, i32 4
  %t697 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t695)
  store i64 %t697, ptr %l334
  br label %bb121
bb121:
  %t698 = load i64, ptr %l334, !tbaa !24
  store i64 %t698, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t699 = load i64, ptr %l27, !tbaa !24
  %t700 = load i64, ptr %l26, !tbaa !24
  %t703 = icmp sgt i64 %t699, %t700
  br i1 %t703, label %bb122, label %bb123
bb122:
  %t705 = load i64, ptr %l28, !tbaa !24
  %t707 = icmp sgt i64 %t705, 0
  br i1 %t707, label %bb124, label %bb125
bb123:
  store i64 0, ptr %l338, !tbaa !24
  br label %bb127
bb124:
  %t709 = load i64, ptr %l27, !tbaa !24
  %t710 = load i64, ptr %l26, !tbaa !24
  %t713 = sub i64 %t709, %t710
  %t714 = load i64, ptr %l28, !tbaa !24
  %t717 = add i64 %t713, %t714
  %t719 = sub i64 %t717, 1
  %t720 = load i64, ptr %l28, !tbaa !24
  %t723 = sdiv i64 %t719, %t720
  store i64 %t723, ptr %l341, !tbaa !24
  br label %bb126
bb125:
  store i64 0, ptr %l341, !tbaa !24
  br label %bb126
bb126:
  %t725 = load i64, ptr %l341, !tbaa !24
  store i64 %t725, ptr %l338, !tbaa !24
  br label %bb127
bb127:
  %t726 = load i64, ptr %l338, !tbaa !24
  store i64 %t726, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s32
  %t727 = load i64, ptr %l30, !tbaa !24
  %t728 = load i64, ptr %l29, !tbaa !24
  %t731 = icmp slt i64 %t727, %t728
  %t733 = xor i1 %t731, true
  br i1 %t733, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s32)
  br label %bb162
bb130:
  br label %bb131
bb131:
  %t735 = load i64, ptr %l26, !tbaa !24
  %t736 = load i64, ptr %l30, !tbaa !24
  %t737 = load i64, ptr %l28, !tbaa !24
  %t740 = mul i64 %t736, %t737
  %t743 = add i64 %t735, %t740
  store i64 %t743, ptr %l31, !tbaa !24
  %t745 = load ptr, ptr %l1, !tbaa !29
  %t747 = getelementptr %"compiler/mir:Fn", ptr %t745, i32 0, i32 4
  %t748 = load i64, ptr %l31, !tbaa !24
  %t751 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t747, i64 %t748)
  store i32 %t751, ptr %l362
  br label %bb132
bb132:
  %t752 = load i32, ptr %l362, !tbaa !23
  %t753 = sext i32 %t752 to i64
  store i64 %t753, ptr %l32, !tbaa !24
  %t755 = load ptr, ptr %l1, !tbaa !29
  %t757 = getelementptr %"compiler/mir:Fn", ptr %t755, i32 0, i32 7
  %t758 = load i64, ptr %l32, !tbaa !24
  %t761 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t757, i64 %t758)
  store %"compiler/mir:Local" %t761, ptr %l367
  br label %bb133
bb133:
  %t762 = getelementptr %"compiler/mir:Local", ptr %l367, i32 0, i32 2
  %t763 = load i32, ptr %t762, !tbaa !23
  store i32 %t763, ptr %l33, !tbaa !23
  %t765 = load ptr, ptr %l0, !tbaa !29
  store ptr %t765, ptr %l369, !tbaa !29
  %t766 = load ptr, ptr %l1, !tbaa !29
  %t768 = getelementptr %"compiler/mir:Fn", ptr %t766, i32 0, i32 7
  %t769 = load i64, ptr %l32, !tbaa !24
  %t772 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t768, i64 %t769)
  store %"compiler/mir:Local" %t772, ptr %l373
  br label %bb134
bb134:
  %t773 = getelementptr %"compiler/mir:Local", ptr %l373, i32 0, i32 4
  %t774 = load { i64, [1 x i64] }, ptr %t773
  %t775 = load ptr, ptr %l369, !tbaa !29
  %t777 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t775, { i64, [1 x i64] } %t774)
  store i1 %t777, ptr %l375
  br label %bb135
bb135:
  %t778 = load i1, ptr %l375, !tbaa !21
  %t779 = xor i1 %t778, true
  br i1 %t779, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s33
  %t781 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s33, ptr %t781, { i64, ptr } { i64 29, ptr @.d228 })
  br label %bb138
bb137:
  br label %bb139
bb138:
  call void @__olang_scope_close(ptr %s33)
  br label %bb139
bb139:
  %t783 = load i64, ptr %l31, !tbaa !24
  %t785 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !27
  %t787 = getelementptr i8, ptr %t786, i64 %t783
  %t788 = load i8, ptr %t787, !tbaa !32
  store i8 %t788, ptr %l34, !tbaa !22
  %t790 = load i8, ptr %l34, !tbaa !22
  %t792 = icmp eq i8 %t790, 109
  br i1 %t792, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb146
bb142:
  store %olang.scope zeroinitializer, ptr %s34
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/emit:fnEm", ptr %t794, i32 0, i32 0
  %t797 = load ptr, ptr %t796, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s34, ptr %s34, ptr %t797, { i64, ptr } { i64 22, ptr @.d229 }, { i64, ptr } { i64 47, ptr @.d230 })
  br label %bb143
bb143:
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t801 = getelementptr %"compiler/emit:fnEm", ptr %t799, i32 0, i32 4
  store ptr %t801, ptr %l385, !tbaa !29
  %t802 = load i64, ptr %l32, !tbaa !24
  store i64 %t802, ptr %l386, !tbaa !24
  %t803 = load i64, ptr %l31, !tbaa !24
  store i64 %t803, ptr %l387, !tbaa !24
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = load i32, ptr %l33, !tbaa !23
  %t808 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t804, i32 %t805)
  store i64 %t808, ptr %l390
  br label %bb144
bb144:
  %t809 = extractvalue { i64, ptr } { i64 42, ptr @.d231 }, 1
  %t810 = extractvalue { i64, ptr } { i64 42, ptr @.d231 }, 0
  %t811 = load i64, ptr %l386, !tbaa !24
  %t812 = call i64 @__olang_fmt_i64(ptr null, i64 %t811)
  %t813 = add i64 %t810, %t812
  %t814 = extractvalue { i64, ptr } { i64 8, ptr @.d232 }, 1
  %t815 = extractvalue { i64, ptr } { i64 8, ptr @.d232 }, 0
  %t816 = add i64 %t813, %t815
  %t817 = load i64, ptr %l387, !tbaa !24
  %t818 = call i64 @__olang_fmt_i64(ptr null, i64 %t817)
  %t819 = add i64 %t816, %t818
  %t820 = extractvalue { i64, ptr } { i64 6, ptr @.d233 }, 1
  %t821 = extractvalue { i64, ptr } { i64 6, ptr @.d233 }, 0
  %t822 = add i64 %t819, %t821
  %t823 = load i64, ptr %l390, !tbaa !24
  %t824 = call i64 @__olang_fmt_i64(ptr null, i64 %t823)
  %t825 = add i64 %t822, %t824
  %t826 = extractvalue { i64, ptr } { i64 12, ptr @.d234 }, 1
  %t827 = extractvalue { i64, ptr } { i64 12, ptr @.d234 }, 0
  %t828 = add i64 %t825, %t827
  %t829 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t828)
  call void @olang_textcopy(ptr %t829, ptr %t809, i64 %t810)
  %t830 = getelementptr i8, ptr %t829, i64 %t810
  %t831 = call i64 @__olang_fmt_i64(ptr %t830, i64 %t811)
  %t832 = getelementptr i8, ptr %t830, i64 %t812
  call void @olang_textcopy(ptr %t832, ptr %t814, i64 %t815)
  %t833 = getelementptr i8, ptr %t832, i64 %t815
  %t834 = call i64 @__olang_fmt_i64(ptr %t833, i64 %t817)
  %t835 = getelementptr i8, ptr %t833, i64 %t818
  call void @olang_textcopy(ptr %t835, ptr %t820, i64 %t821)
  %t836 = getelementptr i8, ptr %t835, i64 %t821
  %t837 = call i64 @__olang_fmt_i64(ptr %t836, i64 %t823)
  %t838 = getelementptr i8, ptr %t836, i64 %t824
  call void @olang_textcopy(ptr %t838, ptr %t826, i64 %t827)
  %t839 = insertvalue { i64, ptr } undef, i64 %t828, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t829, 1
  %t842 = extractvalue { i64, ptr } %t840, 0
  %t843 = extractvalue { i64, ptr } %t840, 1
  %t844 = mul i64 %t842, 1
  %t845 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t844)
  call void @llvm.memcpy.p0.p0.i64(ptr %t845, ptr %t843, i64 %t844, i1 false)
  %t846 = insertvalue { i64, ptr } undef, i64 %t842, 0
  %t847 = insertvalue { i64, ptr } %t846, ptr %t845, 1
  %t848 = load ptr, ptr %l385, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s34, ptr %t848, { i64, ptr } %t847)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s34)
  br label %bb160
bb146:
  %t850 = load i8, ptr %l34, !tbaa !22
  %t852 = icmp eq i8 %t850, 115
  br i1 %t852, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb153
bb149:
  store %olang.scope zeroinitializer, ptr %s36
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t856 = getelementptr %"compiler/emit:fnEm", ptr %t854, i32 0, i32 4
  %t857 = load i64, ptr %l31, !tbaa !24
  %t858 = load i64, ptr %l31, !tbaa !24
  %t859 = extractvalue { i64, ptr } { i64 5, ptr @.d235 }, 1
  %t860 = extractvalue { i64, ptr } { i64 5, ptr @.d235 }, 0
  %t862 = call i64 @__olang_fmt_i64(ptr null, i64 %t857)
  %t863 = add i64 %t860, %t862
  %t864 = extractvalue { i64, ptr } { i64 41, ptr @.d236 }, 1
  %t865 = extractvalue { i64, ptr } { i64 41, ptr @.d236 }, 0
  %t866 = add i64 %t863, %t865
  %t868 = call i64 @__olang_fmt_i64(ptr null, i64 %t858)
  %t869 = add i64 %t866, %t868
  %t870 = extractvalue { i64, ptr } { i64 5, ptr @.d237 }, 1
  %t871 = extractvalue { i64, ptr } { i64 5, ptr @.d237 }, 0
  %t872 = add i64 %t869, %t871
  %t873 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t872)
  call void @olang_textcopy(ptr %t873, ptr %t859, i64 %t860)
  %t874 = getelementptr i8, ptr %t873, i64 %t860
  %t875 = call i64 @__olang_fmt_i64(ptr %t874, i64 %t857)
  %t876 = getelementptr i8, ptr %t874, i64 %t862
  call void @olang_textcopy(ptr %t876, ptr %t864, i64 %t865)
  %t877 = getelementptr i8, ptr %t876, i64 %t865
  %t878 = call i64 @__olang_fmt_i64(ptr %t877, i64 %t858)
  %t879 = getelementptr i8, ptr %t877, i64 %t868
  call void @olang_textcopy(ptr %t879, ptr %t870, i64 %t871)
  %t880 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t873, 1
  %t883 = extractvalue { i64, ptr } %t881, 0
  %t884 = extractvalue { i64, ptr } %t881, 1
  %t885 = mul i64 %t883, 1
  %t886 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t885)
  call void @llvm.memcpy.p0.p0.i64(ptr %t886, ptr %t884, i64 %t885, i1 false)
  %t887 = insertvalue { i64, ptr } undef, i64 %t883, 0
  %t888 = insertvalue { i64, ptr } %t887, ptr %t886, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s36, ptr %t856, { i64, ptr } %t888)
  br label %bb150
bb150:
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t893 = getelementptr %"compiler/emit:fnEm", ptr %t891, i32 0, i32 4
  %t894 = load i64, ptr %l31, !tbaa !24
  %t895 = load i64, ptr %l31, !tbaa !24
  %t896 = load i64, ptr %l31, !tbaa !24
  %t897 = extractvalue { i64, ptr } { i64 5, ptr @.d238 }, 1
  %t898 = extractvalue { i64, ptr } { i64 5, ptr @.d238 }, 0
  %t900 = call i64 @__olang_fmt_i64(ptr null, i64 %t894)
  %t901 = add i64 %t898, %t900
  %t902 = extractvalue { i64, ptr } { i64 31, ptr @.d239 }, 1
  %t903 = extractvalue { i64, ptr } { i64 31, ptr @.d239 }, 0
  %t904 = add i64 %t901, %t903
  %t906 = call i64 @__olang_fmt_i64(ptr null, i64 %t895)
  %t907 = add i64 %t904, %t906
  %t908 = extractvalue { i64, ptr } { i64 8, ptr @.d240 }, 1
  %t909 = extractvalue { i64, ptr } { i64 8, ptr @.d240 }, 0
  %t910 = add i64 %t907, %t909
  %t912 = call i64 @__olang_fmt_i64(ptr null, i64 %t896)
  %t913 = add i64 %t910, %t912
  %t914 = extractvalue { i64, ptr } { i64 5, ptr @.d241 }, 1
  %t915 = extractvalue { i64, ptr } { i64 5, ptr @.d241 }, 0
  %t916 = add i64 %t913, %t915
  %t917 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t916)
  call void @olang_textcopy(ptr %t917, ptr %t897, i64 %t898)
  %t918 = getelementptr i8, ptr %t917, i64 %t898
  %t919 = call i64 @__olang_fmt_i64(ptr %t918, i64 %t894)
  %t920 = getelementptr i8, ptr %t918, i64 %t900
  call void @olang_textcopy(ptr %t920, ptr %t902, i64 %t903)
  %t921 = getelementptr i8, ptr %t920, i64 %t903
  %t922 = call i64 @__olang_fmt_i64(ptr %t921, i64 %t895)
  %t923 = getelementptr i8, ptr %t921, i64 %t906
  call void @olang_textcopy(ptr %t923, ptr %t908, i64 %t909)
  %t924 = getelementptr i8, ptr %t923, i64 %t909
  %t925 = call i64 @__olang_fmt_i64(ptr %t924, i64 %t896)
  %t926 = getelementptr i8, ptr %t924, i64 %t912
  call void @olang_textcopy(ptr %t926, ptr %t914, i64 %t915)
  %t927 = insertvalue { i64, ptr } undef, i64 %t916, 0
  %t928 = insertvalue { i64, ptr } %t927, ptr %t917, 1
  %t930 = extractvalue { i64, ptr } %t928, 0
  %t931 = extractvalue { i64, ptr } %t928, 1
  %t932 = mul i64 %t930, 1
  %t933 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t932)
  call void @llvm.memcpy.p0.p0.i64(ptr %t933, ptr %t931, i64 %t932, i1 false)
  %t934 = insertvalue { i64, ptr } undef, i64 %t930, 0
  %t935 = insertvalue { i64, ptr } %t934, ptr %t933, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s36, ptr %t893, { i64, ptr } %t935)
  br label %bb151
bb151:
  %t938 = load ptr, ptr %l0, !tbaa !29
  %t940 = getelementptr %"compiler/emit:fnEm", ptr %t938, i32 0, i32 4
  %t941 = load i64, ptr %l31, !tbaa !24
  %t942 = load i64, ptr %l32, !tbaa !24
  %t943 = extractvalue { i64, ptr } { i64 24, ptr @.d242 }, 1
  %t944 = extractvalue { i64, ptr } { i64 24, ptr @.d242 }, 0
  %t946 = call i64 @__olang_fmt_i64(ptr null, i64 %t941)
  %t947 = add i64 %t944, %t946
  %t948 = extractvalue { i64, ptr } { i64 8, ptr @.d243 }, 1
  %t949 = extractvalue { i64, ptr } { i64 8, ptr @.d243 }, 0
  %t950 = add i64 %t947, %t949
  %t952 = call i64 @__olang_fmt_i64(ptr null, i64 %t942)
  %t953 = add i64 %t950, %t952
  %t954 = extractvalue { i64, ptr } { i64 1, ptr @.d244 }, 1
  %t955 = extractvalue { i64, ptr } { i64 1, ptr @.d244 }, 0
  %t956 = add i64 %t953, %t955
  %t957 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t956)
  call void @olang_textcopy(ptr %t957, ptr %t943, i64 %t944)
  %t958 = getelementptr i8, ptr %t957, i64 %t944
  %t959 = call i64 @__olang_fmt_i64(ptr %t958, i64 %t941)
  %t960 = getelementptr i8, ptr %t958, i64 %t946
  call void @olang_textcopy(ptr %t960, ptr %t948, i64 %t949)
  %t961 = getelementptr i8, ptr %t960, i64 %t949
  %t962 = call i64 @__olang_fmt_i64(ptr %t961, i64 %t942)
  %t963 = getelementptr i8, ptr %t961, i64 %t952
  call void @olang_textcopy(ptr %t963, ptr %t954, i64 %t955)
  %t964 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t965 = insertvalue { i64, ptr } %t964, ptr %t957, 1
  %t967 = extractvalue { i64, ptr } %t965, 0
  %t968 = extractvalue { i64, ptr } %t965, 1
  %t969 = mul i64 %t967, 1
  %t970 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t969)
  call void @llvm.memcpy.p0.p0.i64(ptr %t970, ptr %t968, i64 %t969, i1 false)
  %t971 = insertvalue { i64, ptr } undef, i64 %t967, 0
  %t972 = insertvalue { i64, ptr } %t971, ptr %t970, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s36, ptr %t940, { i64, ptr } %t972)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s36)
  br label %bb160
bb153:
  br i1 true, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb159
bb156:
  store %olang.scope zeroinitializer, ptr %s40
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t977 = getelementptr %"compiler/emit:fnEm", ptr %t975, i32 0, i32 4
  store ptr %t977, ptr %l415, !tbaa !29
  %t978 = load ptr, ptr %l0, !tbaa !29
  %t979 = load i32, ptr %l33, !tbaa !23
  %t982 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s40, ptr %t978, i32 %t979)
  store { i64, ptr } %t982, ptr %l418
  br label %bb157
bb157:
  %t983 = load i64, ptr %l31, !tbaa !24
  %t984 = load i64, ptr %l32, !tbaa !24
  %t985 = extractvalue { i64, ptr } { i64 8, ptr @.d245 }, 1
  %t986 = extractvalue { i64, ptr } { i64 8, ptr @.d245 }, 0
  %t987 = load { i64, ptr }, ptr %l418, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t987, 1
  %t989 = extractvalue { i64, ptr } %t987, 0
  %t990 = add i64 %t986, %t989
  %t991 = extractvalue { i64, ptr } { i64 3, ptr @.d246 }, 1
  %t992 = extractvalue { i64, ptr } { i64 3, ptr @.d246 }, 0
  %t993 = add i64 %t990, %t992
  %t995 = call i64 @__olang_fmt_i64(ptr null, i64 %t983)
  %t996 = add i64 %t993, %t995
  %t997 = extractvalue { i64, ptr } { i64 8, ptr @.d247 }, 1
  %t998 = extractvalue { i64, ptr } { i64 8, ptr @.d247 }, 0
  %t999 = add i64 %t996, %t998
  %t1001 = call i64 @__olang_fmt_i64(ptr null, i64 %t984)
  %t1002 = add i64 %t999, %t1001
  %t1003 = extractvalue { i64, ptr } { i64 1, ptr @.d248 }, 1
  %t1004 = extractvalue { i64, ptr } { i64 1, ptr @.d248 }, 0
  %t1005 = add i64 %t1002, %t1004
  %t1006 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1005)
  call void @olang_textcopy(ptr %t1006, ptr %t985, i64 %t986)
  %t1007 = getelementptr i8, ptr %t1006, i64 %t986
  call void @olang_textcopy(ptr %t1007, ptr %t988, i64 %t989)
  %t1008 = getelementptr i8, ptr %t1007, i64 %t989
  call void @olang_textcopy(ptr %t1008, ptr %t991, i64 %t992)
  %t1009 = getelementptr i8, ptr %t1008, i64 %t992
  %t1010 = call i64 @__olang_fmt_i64(ptr %t1009, i64 %t983)
  %t1011 = getelementptr i8, ptr %t1009, i64 %t995
  call void @olang_textcopy(ptr %t1011, ptr %t997, i64 %t998)
  %t1012 = getelementptr i8, ptr %t1011, i64 %t998
  %t1013 = call i64 @__olang_fmt_i64(ptr %t1012, i64 %t984)
  %t1014 = getelementptr i8, ptr %t1012, i64 %t1001
  call void @olang_textcopy(ptr %t1014, ptr %t1003, i64 %t1004)
  %t1015 = insertvalue { i64, ptr } undef, i64 %t1005, 0
  %t1016 = insertvalue { i64, ptr } %t1015, ptr %t1006, 1
  %t1018 = extractvalue { i64, ptr } %t1016, 0
  %t1019 = extractvalue { i64, ptr } %t1016, 1
  %t1020 = mul i64 %t1018, 1
  %t1021 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1020)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1021, ptr %t1019, i64 %t1020, i1 false)
  %t1022 = insertvalue { i64, ptr } undef, i64 %t1018, 0
  %t1023 = insertvalue { i64, ptr } %t1022, ptr %t1021, 1
  %t1024 = load ptr, ptr %l415, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s40, ptr %t1024, { i64, ptr } %t1023)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s40)
  br label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_fad0caecc364ec25_9c3ddefd20d373f1)
  unreachable
bb160:
  call void @__olang_scope_close(ptr %s32)
  br label %bb161
bb161:
  %t1026 = load i64, ptr %l30, !tbaa !24
  %t1028 = add i64 %t1026, 1
  store i64 %t1028, ptr %l30, !tbaa !24
  br label %bb128
bb162:
  %t1030 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t1030, { i64, ptr } { i64 5, ptr @.d249 })
  br label %bb163
bb163:
  store i64 0, ptr %l35, !tbaa !24
  %t1032 = load ptr, ptr %l1, !tbaa !29
  %t1034 = getelementptr %"compiler/mir:Fn", ptr %t1032, i32 0, i32 4
  %t1036 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t1034)
  store i64 %t1036, ptr %l428
  br label %bb164
bb164:
  %t1037 = load i64, ptr %l428, !tbaa !24
  store i64 %t1037, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t1038 = load i64, ptr %l36, !tbaa !24
  %t1039 = load i64, ptr %l35, !tbaa !24
  %t1042 = icmp sgt i64 %t1038, %t1039
  br i1 %t1042, label %bb165, label %bb166
bb165:
  %t1044 = load i64, ptr %l37, !tbaa !24
  %t1046 = icmp sgt i64 %t1044, 0
  br i1 %t1046, label %bb167, label %bb168
bb166:
  store i64 0, ptr %l432, !tbaa !24
  br label %bb170
bb167:
  %t1048 = load i64, ptr %l36, !tbaa !24
  %t1049 = load i64, ptr %l35, !tbaa !24
  %t1052 = sub i64 %t1048, %t1049
  %t1053 = load i64, ptr %l37, !tbaa !24
  %t1056 = add i64 %t1052, %t1053
  %t1058 = sub i64 %t1056, 1
  %t1059 = load i64, ptr %l37, !tbaa !24
  %t1062 = sdiv i64 %t1058, %t1059
  store i64 %t1062, ptr %l435, !tbaa !24
  br label %bb169
bb168:
  store i64 0, ptr %l435, !tbaa !24
  br label %bb169
bb169:
  %t1064 = load i64, ptr %l435, !tbaa !24
  store i64 %t1064, ptr %l432, !tbaa !24
  br label %bb170
bb170:
  %t1065 = load i64, ptr %l432, !tbaa !24
  store i64 %t1065, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb171
bb171:
  store %olang.scope zeroinitializer, ptr %s44
  %t1066 = load i64, ptr %l39, !tbaa !24
  %t1067 = load i64, ptr %l38, !tbaa !24
  %t1070 = icmp slt i64 %t1066, %t1067
  %t1072 = xor i1 %t1070, true
  br i1 %t1072, label %bb172, label %bb173
bb172:
  call void @__olang_scope_close(ptr %s44)
  br label %bb190
bb173:
  br label %bb174
bb174:
  %t1074 = load i64, ptr %l35, !tbaa !24
  %t1075 = load i64, ptr %l39, !tbaa !24
  %t1076 = load i64, ptr %l37, !tbaa !24
  %t1079 = mul i64 %t1075, %t1076
  %t1082 = add i64 %t1074, %t1079
  %t1084 = load ptr, ptr %l1, !tbaa !29
  %t1086 = getelementptr %"compiler/mir:Fn", ptr %t1084, i32 0, i32 4
  %t1090 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t1086, i64 %t1082)
  store i32 %t1090, ptr %l456
  br label %bb175
bb175:
  %t1091 = load i32, ptr %l456, !tbaa !23
  store i32 %t1091, ptr %l41, !tbaa !23
  %t1092 = load ptr, ptr %l1, !tbaa !29
  %t1094 = getelementptr %"compiler/mir:Fn", ptr %t1092, i32 0, i32 7
  %t1095 = load i32, ptr %l41, !tbaa !23
  %t1097 = sext i32 %t1095 to i64
  %t1100 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t1094, i64 %t1097)
  store %"compiler/mir:Local" %t1100, ptr %l461
  br label %bb176
bb176:
  %t1101 = getelementptr %"compiler/mir:Local", ptr %l461, i32 0, i32 2
  %t1102 = load i32, ptr %t1101, !tbaa !23
  store i32 %t1102, ptr %l42, !tbaa !23
  %t1104 = load ptr, ptr %l0, !tbaa !29
  %t1105 = load i32, ptr %l42, !tbaa !23
  %t1108 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t1104, i32 %t1105)
  store i1 %t1108, ptr %l465
  br label %bb177
bb177:
  %t1109 = load i1, ptr %l465, !tbaa !21
  br i1 %t1109, label %bb178, label %bb179
bb178:
  %t1110 = load ptr, ptr %l0, !tbaa !29
  %t1111 = load i32, ptr %l41, !tbaa !23
  %t1114 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewritesInto(ptr %v0, ptr %t1110, i32 %t1111)
  store i1 %t1114, ptr %l469
  br label %bb180
bb179:
  store i1 false, ptr %l466, !tbaa !21
  br label %bb181
bb180:
  %t1115 = load i1, ptr %l469, !tbaa !21
  store i1 %t1115, ptr %l466, !tbaa !21
  br label %bb181
bb181:
  %t1116 = load i1, ptr %l466, !tbaa !21
  br i1 %t1116, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s45
  %t1117 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %t1117)
  br label %bb184
bb183:
  br label %bb188
bb184:
  %t1119 = load ptr, ptr %l0, !tbaa !29
  %t1120 = load i32, ptr %l41, !tbaa !23
  %t1121 = extractvalue { i64, ptr } { i64 2, ptr @.d250 }, 1
  %t1122 = extractvalue { i64, ptr } { i64 2, ptr @.d250 }, 0
  %t1124 = sext i32 %t1120 to i64
  %t1125 = call i64 @__olang_fmt_i64(ptr null, i64 %t1124)
  %t1126 = add i64 %t1122, %t1125
  %t1127 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1126)
  call void @olang_textcopy(ptr %t1127, ptr %t1121, i64 %t1122)
  %t1128 = getelementptr i8, ptr %t1127, i64 %t1122
  %t1129 = call i64 @__olang_fmt_i64(ptr %t1128, i64 %t1124)
  %t1130 = insertvalue { i64, ptr } undef, i64 %t1126, 0
  %t1131 = insertvalue { i64, ptr } %t1130, ptr %t1127, 1
  %t1133 = extractvalue { i64, ptr } %t1131, 0
  %t1134 = extractvalue { i64, ptr } %t1131, 1
  %t1135 = mul i64 %t1133, 1
  %t1136 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1136, ptr %t1134, i64 %t1135, i1 false)
  %t1137 = insertvalue { i64, ptr } undef, i64 %t1133, 0
  %t1138 = insertvalue { i64, ptr } %t1137, ptr %t1136, 1
  %t1141 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s45, ptr %s45, ptr %s45, ptr %s45, ptr %t1119, { i64, ptr } { i64 12, ptr @.d251 }, { i64, ptr } %t1138, { i64, ptr } { i64 0, ptr @.d252 })
  store { i64, ptr } %t1141, ptr %l475
  br label %bb185
bb185:
  %t1142 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t1143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1143, ptr %l476, !tbaa !29
  %t1144 = load ptr, ptr %l0, !tbaa !29
  %t1146 = load i32, ptr %l42, !tbaa !23
  %t1150 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %s45, ptr %s45, ptr %s45, ptr %t1144, { i64, ptr } { i64 4, ptr @.d253 }, { i64, ptr } %t1142, i32 %t1146)
  store { i64, ptr } %t1150, ptr %l480
  br label %bb186
bb186:
  %t1151 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t1152 = extractvalue { i64, ptr } %t1151, 0
  %t1153 = extractvalue { i64, ptr } %t1151, 1
  %t1154 = mul i64 %t1152, 1
  %t1155 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1155, ptr %t1153, i64 %t1154, i1 false)
  %t1156 = insertvalue { i64, ptr } undef, i64 %t1152, 0
  %t1157 = insertvalue { i64, ptr } %t1156, ptr %t1155, 1
  %t1158 = load i32, ptr %l41, !tbaa !23
  %t1159 = extractvalue { i64, ptr } { i64 2, ptr @.d254 }, 1
  %t1160 = extractvalue { i64, ptr } { i64 2, ptr @.d254 }, 0
  %t1162 = sext i32 %t1158 to i64
  %t1163 = call i64 @__olang_fmt_i64(ptr null, i64 %t1162)
  %t1164 = add i64 %t1160, %t1163
  %t1165 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1164)
  call void @olang_textcopy(ptr %t1165, ptr %t1159, i64 %t1160)
  %t1166 = getelementptr i8, ptr %t1165, i64 %t1160
  %t1167 = call i64 @__olang_fmt_i64(ptr %t1166, i64 %t1162)
  %t1168 = insertvalue { i64, ptr } undef, i64 %t1164, 0
  %t1169 = insertvalue { i64, ptr } %t1168, ptr %t1165, 1
  %t1171 = extractvalue { i64, ptr } %t1169, 0
  %t1172 = extractvalue { i64, ptr } %t1169, 1
  %t1173 = mul i64 %t1171, 1
  %t1174 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1174, ptr %t1172, i64 %t1173, i1 false)
  %t1175 = insertvalue { i64, ptr } undef, i64 %t1171, 0
  %t1176 = insertvalue { i64, ptr } %t1175, ptr %t1174, 1
  %t1177 = load ptr, ptr %l476, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s45, ptr %s45, ptr %s45, ptr %s45, ptr %t1177, { i64, ptr } { i64 12, ptr @.d255 }, { i64, ptr } %t1157, { i64, ptr } %t1176, { i64, ptr } { i64 0, ptr @.d256 })
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s45)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s44)
  br label %bb189
bb189:
  %t1180 = load i64, ptr %l39, !tbaa !24
  %t1182 = add i64 %t1180, 1
  store i64 %t1182, ptr %l39, !tbaa !24
  br label %bb171
bb190:
  %t1184 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1184, { i64, ptr } { i64 13, ptr @.d257 })
  br label %bb191
bb191:
  %t1186 = load ptr, ptr %l1, !tbaa !29
  %t1188 = getelementptr %"compiler/mir:Fn", ptr %t1186, i32 0, i32 5
  %t1190 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t1188)
  store i64 %t1190, ptr %l490
  br label %bb192
bb192:
  %t1191 = load i64, ptr %l490, !tbaa !24
  %t1192 = icmp sgt i64 %t1191, 0
  br i1 %t1192, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s49
  %t1194 = load ptr, ptr %l0, !tbaa !29
  %t1196 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eenvType(ptr %v0, ptr %s49, ptr %t1194)
  store { i64, ptr } %t1196, ptr %l493
  br label %bb195
bb194:
  br label %bb249
bb195:
  %t1197 = load { i64, ptr }, ptr %l493, !tbaa !27
  store { i64, ptr } %t1197, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t1198 = load ptr, ptr %l1, !tbaa !29
  %t1200 = getelementptr %"compiler/mir:Fn", ptr %t1198, i32 0, i32 5
  %t1202 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t1200)
  store i64 %t1202, ptr %l496
  br label %bb196
bb196:
  %t1203 = load i64, ptr %l496, !tbaa !24
  store i64 %t1203, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t1204 = load i64, ptr %l46, !tbaa !24
  %t1205 = load i64, ptr %l45, !tbaa !24
  %t1208 = icmp sgt i64 %t1204, %t1205
  br i1 %t1208, label %bb197, label %bb198
bb197:
  %t1210 = load i64, ptr %l47, !tbaa !24
  %t1212 = icmp sgt i64 %t1210, 0
  br i1 %t1212, label %bb199, label %bb200
bb198:
  store i64 0, ptr %l500, !tbaa !24
  br label %bb202
bb199:
  %t1214 = load i64, ptr %l46, !tbaa !24
  %t1215 = load i64, ptr %l45, !tbaa !24
  %t1218 = sub i64 %t1214, %t1215
  %t1219 = load i64, ptr %l47, !tbaa !24
  %t1222 = add i64 %t1218, %t1219
  %t1224 = sub i64 %t1222, 1
  %t1225 = load i64, ptr %l47, !tbaa !24
  %t1228 = sdiv i64 %t1224, %t1225
  store i64 %t1228, ptr %l503, !tbaa !24
  br label %bb201
bb200:
  store i64 0, ptr %l503, !tbaa !24
  br label %bb201
bb201:
  %t1230 = load i64, ptr %l503, !tbaa !24
  store i64 %t1230, ptr %l500, !tbaa !24
  br label %bb202
bb202:
  %t1231 = load i64, ptr %l500, !tbaa !24
  store i64 %t1231, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb203
bb203:
  store %olang.scope zeroinitializer, ptr %s51
  %t1232 = load i64, ptr %l49, !tbaa !24
  %t1233 = load i64, ptr %l48, !tbaa !24
  %t1236 = icmp slt i64 %t1232, %t1233
  %t1238 = xor i1 %t1236, true
  br i1 %t1238, label %bb204, label %bb205
bb204:
  call void @__olang_scope_close(ptr %s51)
  br label %bb229
bb205:
  br label %bb206
bb206:
  %t1240 = load i64, ptr %l45, !tbaa !24
  %t1241 = load i64, ptr %l49, !tbaa !24
  %t1242 = load i64, ptr %l47, !tbaa !24
  %t1245 = mul i64 %t1241, %t1242
  %t1248 = add i64 %t1240, %t1245
  store i64 %t1248, ptr %l50, !tbaa !24
  %t1250 = load ptr, ptr %l1, !tbaa !29
  %t1252 = getelementptr %"compiler/mir:Fn", ptr %t1250, i32 0, i32 5
  %t1253 = load i64, ptr %l50, !tbaa !24
  %t1256 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t1252, i64 %t1253)
  store i32 %t1256, ptr %l524
  br label %bb207
bb207:
  %t1257 = load i32, ptr %l524, !tbaa !23
  %t1258 = sext i32 %t1257 to i64
  store i64 %t1258, ptr %l51, !tbaa !24
  %t1260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1260, ptr %l526, !tbaa !29
  %t1261 = load ptr, ptr %l1, !tbaa !29
  %t1263 = getelementptr %"compiler/mir:Fn", ptr %t1261, i32 0, i32 7
  %t1264 = load i64, ptr %l51, !tbaa !24
  %t1267 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t1263, i64 %t1264)
  store %"compiler/mir:Local" %t1267, ptr %l530
  br label %bb208
bb208:
  %t1268 = getelementptr %"compiler/mir:Local", ptr %l530, i32 0, i32 2
  %t1269 = load i32, ptr %t1268, !tbaa !23
  %t1270 = load ptr, ptr %l526, !tbaa !29
  %t1272 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s51, ptr %t1270, i32 %t1269)
  store { i64, ptr } %t1272, ptr %l532
  br label %bb209
bb209:
  %t1273 = load { i64, ptr }, ptr %l532, !tbaa !27
  store { i64, ptr } %t1273, ptr %l52, !tbaa !27
  %t1274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1274, ptr %l533, !tbaa !29
  %t1275 = load ptr, ptr %l1, !tbaa !29
  %t1277 = getelementptr %"compiler/mir:Fn", ptr %t1275, i32 0, i32 7
  %t1278 = load i64, ptr %l51, !tbaa !24
  %t1281 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t1277, i64 %t1278)
  store %"compiler/mir:Local" %t1281, ptr %l537
  br label %bb210
bb210:
  %t1282 = getelementptr %"compiler/mir:Local", ptr %l537, i32 0, i32 4
  %t1283 = load { i64, [1 x i64] }, ptr %t1282
  %t1284 = load ptr, ptr %l533, !tbaa !29
  %t1286 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t1284, { i64, [1 x i64] } %t1283)
  store i1 %t1286, ptr %l539
  br label %bb211
bb211:
  %t1287 = load i1, ptr %l539, !tbaa !21
  %t1288 = xor i1 %t1287, true
  br i1 %t1288, label %bb212, label %bb213
bb212:
  store %olang.scope zeroinitializer, ptr %s52
  %t1290 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s52, ptr %t1290, { i64, ptr } { i64 27, ptr @.d258 })
  br label %bb214
bb213:
  br label %bb215
bb214:
  call void @__olang_scope_close(ptr %s52)
  br label %bb215
bb215:
  %t1292 = load ptr, ptr %l0, !tbaa !29
  %t1294 = getelementptr %"compiler/emit:fnEm", ptr %t1292, i32 0, i32 4
  %t1295 = load i64, ptr %l50, !tbaa !24
  %t1296 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t1297 = load i64, ptr %l50, !tbaa !24
  %t1298 = extractvalue { i64, ptr } { i64 5, ptr @.d259 }, 1
  %t1299 = extractvalue { i64, ptr } { i64 5, ptr @.d259 }, 0
  %t1301 = call i64 @__olang_fmt_i64(ptr null, i64 %t1295)
  %t1302 = add i64 %t1299, %t1301
  %t1303 = extractvalue { i64, ptr } { i64 17, ptr @.d260 }, 1
  %t1304 = extractvalue { i64, ptr } { i64 17, ptr @.d260 }, 0
  %t1305 = add i64 %t1302, %t1304
  %t1307 = extractvalue { i64, ptr } %t1296, 1
  %t1308 = extractvalue { i64, ptr } %t1296, 0
  %t1309 = add i64 %t1305, %t1308
  %t1310 = extractvalue { i64, ptr } { i64 23, ptr @.d261 }, 1
  %t1311 = extractvalue { i64, ptr } { i64 23, ptr @.d261 }, 0
  %t1312 = add i64 %t1309, %t1311
  %t1314 = call i64 @__olang_fmt_i64(ptr null, i64 %t1297)
  %t1315 = add i64 %t1312, %t1314
  %t1316 = extractvalue { i64, ptr } { i64 1, ptr @.d262 }, 1
  %t1317 = extractvalue { i64, ptr } { i64 1, ptr @.d262 }, 0
  %t1318 = add i64 %t1315, %t1317
  %t1319 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1318)
  call void @olang_textcopy(ptr %t1319, ptr %t1298, i64 %t1299)
  %t1320 = getelementptr i8, ptr %t1319, i64 %t1299
  %t1321 = call i64 @__olang_fmt_i64(ptr %t1320, i64 %t1295)
  %t1322 = getelementptr i8, ptr %t1320, i64 %t1301
  call void @olang_textcopy(ptr %t1322, ptr %t1303, i64 %t1304)
  %t1323 = getelementptr i8, ptr %t1322, i64 %t1304
  call void @olang_textcopy(ptr %t1323, ptr %t1307, i64 %t1308)
  %t1324 = getelementptr i8, ptr %t1323, i64 %t1308
  call void @olang_textcopy(ptr %t1324, ptr %t1310, i64 %t1311)
  %t1325 = getelementptr i8, ptr %t1324, i64 %t1311
  %t1326 = call i64 @__olang_fmt_i64(ptr %t1325, i64 %t1297)
  %t1327 = getelementptr i8, ptr %t1325, i64 %t1314
  call void @olang_textcopy(ptr %t1327, ptr %t1316, i64 %t1317)
  %t1328 = insertvalue { i64, ptr } undef, i64 %t1318, 0
  %t1329 = insertvalue { i64, ptr } %t1328, ptr %t1319, 1
  %t1331 = extractvalue { i64, ptr } %t1329, 0
  %t1332 = extractvalue { i64, ptr } %t1329, 1
  %t1333 = mul i64 %t1331, 1
  %t1334 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1334, ptr %t1332, i64 %t1333, i1 false)
  %t1335 = insertvalue { i64, ptr } undef, i64 %t1331, 0
  %t1336 = insertvalue { i64, ptr } %t1335, ptr %t1334, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s51, ptr %t1294, { i64, ptr } %t1336)
  br label %bb216
bb216:
  %t1339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1339, ptr %l549, !tbaa !29
  %t1340 = load ptr, ptr %l1, !tbaa !29
  %t1342 = getelementptr %"compiler/mir:Fn", ptr %t1340, i32 0, i32 7
  %t1343 = load i64, ptr %l51, !tbaa !24
  %t1346 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t1342, i64 %t1343)
  store %"compiler/mir:Local" %t1346, ptr %l553
  br label %bb217
bb217:
  %t1347 = getelementptr %"compiler/mir:Local", ptr %l553, i32 0, i32 2
  %t1348 = load i32, ptr %t1347, !tbaa !23
  %t1349 = load ptr, ptr %l549, !tbaa !29
  %t1351 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t1349, i32 %t1348)
  store i1 %t1351, ptr %l555
  br label %bb218
bb218:
  %t1352 = load i1, ptr %l555, !tbaa !21
  br i1 %t1352, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s54
  %t1353 = load ptr, ptr %l0, !tbaa !29
  %t1355 = getelementptr %"compiler/emit:fnEm", ptr %t1353, i32 0, i32 0
  %t1356 = load ptr, ptr %t1355, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s54, ptr %s54, ptr %t1356, { i64, ptr } { i64 22, ptr @.d263 }, { i64, ptr } { i64 47, ptr @.d264 })
  br label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s56
  %t1358 = load ptr, ptr %l0, !tbaa !29
  %t1360 = getelementptr %"compiler/emit:fnEm", ptr %t1358, i32 0, i32 4
  %t1361 = load i64, ptr %l50, !tbaa !24
  %t1362 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1363 = load i64, ptr %l50, !tbaa !24
  %t1364 = extractvalue { i64, ptr } { i64 5, ptr @.d265 }, 1
  %t1365 = extractvalue { i64, ptr } { i64 5, ptr @.d265 }, 0
  %t1367 = call i64 @__olang_fmt_i64(ptr null, i64 %t1361)
  %t1368 = add i64 %t1365, %t1367
  %t1369 = extractvalue { i64, ptr } { i64 8, ptr @.d266 }, 1
  %t1370 = extractvalue { i64, ptr } { i64 8, ptr @.d266 }, 0
  %t1371 = add i64 %t1368, %t1370
  %t1373 = extractvalue { i64, ptr } %t1362, 1
  %t1374 = extractvalue { i64, ptr } %t1362, 0
  %t1375 = add i64 %t1371, %t1374
  %t1376 = extractvalue { i64, ptr } { i64 9, ptr @.d267 }, 1
  %t1377 = extractvalue { i64, ptr } { i64 9, ptr @.d267 }, 0
  %t1378 = add i64 %t1375, %t1377
  %t1380 = call i64 @__olang_fmt_i64(ptr null, i64 %t1363)
  %t1381 = add i64 %t1378, %t1380
  %t1382 = extractvalue { i64, ptr } { i64 12, ptr @.d268 }, 1
  %t1383 = extractvalue { i64, ptr } { i64 12, ptr @.d268 }, 0
  %t1384 = add i64 %t1381, %t1383
  %t1385 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1384)
  call void @olang_textcopy(ptr %t1385, ptr %t1364, i64 %t1365)
  %t1386 = getelementptr i8, ptr %t1385, i64 %t1365
  %t1387 = call i64 @__olang_fmt_i64(ptr %t1386, i64 %t1361)
  %t1388 = getelementptr i8, ptr %t1386, i64 %t1367
  call void @olang_textcopy(ptr %t1388, ptr %t1369, i64 %t1370)
  %t1389 = getelementptr i8, ptr %t1388, i64 %t1370
  call void @olang_textcopy(ptr %t1389, ptr %t1373, i64 %t1374)
  %t1390 = getelementptr i8, ptr %t1389, i64 %t1374
  call void @olang_textcopy(ptr %t1390, ptr %t1376, i64 %t1377)
  %t1391 = getelementptr i8, ptr %t1390, i64 %t1377
  %t1392 = call i64 @__olang_fmt_i64(ptr %t1391, i64 %t1363)
  %t1393 = getelementptr i8, ptr %t1391, i64 %t1380
  call void @olang_textcopy(ptr %t1393, ptr %t1382, i64 %t1383)
  %t1394 = insertvalue { i64, ptr } undef, i64 %t1384, 0
  %t1395 = insertvalue { i64, ptr } %t1394, ptr %t1385, 1
  %t1397 = extractvalue { i64, ptr } %t1395, 0
  %t1398 = extractvalue { i64, ptr } %t1395, 1
  %t1399 = mul i64 %t1397, 1
  %t1400 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1400, ptr %t1398, i64 %t1399, i1 false)
  %t1401 = insertvalue { i64, ptr } undef, i64 %t1397, 0
  %t1402 = insertvalue { i64, ptr } %t1401, ptr %t1400, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s56, ptr %t1360, { i64, ptr } %t1402)
  br label %bb225
bb221:
  %t1405 = load ptr, ptr %l0, !tbaa !29
  %t1407 = getelementptr %"compiler/emit:fnEm", ptr %t1405, i32 0, i32 4
  store ptr %t1407, ptr %l559, !tbaa !29
  %t1408 = load i64, ptr %l51, !tbaa !24
  store i64 %t1408, ptr %l560, !tbaa !24
  %t1409 = load i64, ptr %l50, !tbaa !24
  store i64 %t1409, ptr %l561, !tbaa !24
  %t1410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1410, ptr %l562, !tbaa !29
  %t1411 = load ptr, ptr %l1, !tbaa !29
  %t1413 = getelementptr %"compiler/mir:Fn", ptr %t1411, i32 0, i32 7
  %t1414 = load i64, ptr %l51, !tbaa !24
  %t1417 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t1413, i64 %t1414)
  store %"compiler/mir:Local" %t1417, ptr %l566
  br label %bb222
bb222:
  %t1418 = getelementptr %"compiler/mir:Local", ptr %l566, i32 0, i32 2
  %t1419 = load i32, ptr %t1418, !tbaa !23
  %t1420 = load ptr, ptr %l562, !tbaa !29
  %t1422 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1420, i32 %t1419)
  store i64 %t1422, ptr %l568
  br label %bb223
bb223:
  %t1423 = extractvalue { i64, ptr } { i64 42, ptr @.d269 }, 1
  %t1424 = extractvalue { i64, ptr } { i64 42, ptr @.d269 }, 0
  %t1425 = load i64, ptr %l560, !tbaa !24
  %t1426 = call i64 @__olang_fmt_i64(ptr null, i64 %t1425)
  %t1427 = add i64 %t1424, %t1426
  %t1428 = extractvalue { i64, ptr } { i64 9, ptr @.d270 }, 1
  %t1429 = extractvalue { i64, ptr } { i64 9, ptr @.d270 }, 0
  %t1430 = add i64 %t1427, %t1429
  %t1431 = load i64, ptr %l561, !tbaa !24
  %t1432 = call i64 @__olang_fmt_i64(ptr null, i64 %t1431)
  %t1433 = add i64 %t1430, %t1432
  %t1434 = extractvalue { i64, ptr } { i64 6, ptr @.d271 }, 1
  %t1435 = extractvalue { i64, ptr } { i64 6, ptr @.d271 }, 0
  %t1436 = add i64 %t1433, %t1435
  %t1437 = load i64, ptr %l568, !tbaa !24
  %t1438 = call i64 @__olang_fmt_i64(ptr null, i64 %t1437)
  %t1439 = add i64 %t1436, %t1438
  %t1440 = extractvalue { i64, ptr } { i64 12, ptr @.d272 }, 1
  %t1441 = extractvalue { i64, ptr } { i64 12, ptr @.d272 }, 0
  %t1442 = add i64 %t1439, %t1441
  %t1443 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1442)
  call void @olang_textcopy(ptr %t1443, ptr %t1423, i64 %t1424)
  %t1444 = getelementptr i8, ptr %t1443, i64 %t1424
  %t1445 = call i64 @__olang_fmt_i64(ptr %t1444, i64 %t1425)
  %t1446 = getelementptr i8, ptr %t1444, i64 %t1426
  call void @olang_textcopy(ptr %t1446, ptr %t1428, i64 %t1429)
  %t1447 = getelementptr i8, ptr %t1446, i64 %t1429
  %t1448 = call i64 @__olang_fmt_i64(ptr %t1447, i64 %t1431)
  %t1449 = getelementptr i8, ptr %t1447, i64 %t1432
  call void @olang_textcopy(ptr %t1449, ptr %t1434, i64 %t1435)
  %t1450 = getelementptr i8, ptr %t1449, i64 %t1435
  %t1451 = call i64 @__olang_fmt_i64(ptr %t1450, i64 %t1437)
  %t1452 = getelementptr i8, ptr %t1450, i64 %t1438
  call void @olang_textcopy(ptr %t1452, ptr %t1440, i64 %t1441)
  %t1453 = insertvalue { i64, ptr } undef, i64 %t1442, 0
  %t1454 = insertvalue { i64, ptr } %t1453, ptr %t1443, 1
  %t1456 = extractvalue { i64, ptr } %t1454, 0
  %t1457 = extractvalue { i64, ptr } %t1454, 1
  %t1458 = mul i64 %t1456, 1
  %t1459 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1459, ptr %t1457, i64 %t1458, i1 false)
  %t1460 = insertvalue { i64, ptr } undef, i64 %t1456, 0
  %t1461 = insertvalue { i64, ptr } %t1460, ptr %t1459, 1
  %t1462 = load ptr, ptr %l559, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s54, ptr %t1462, { i64, ptr } %t1461)
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s54)
  br label %bb227
bb225:
  %t1464 = load ptr, ptr %l0, !tbaa !29
  %t1466 = getelementptr %"compiler/emit:fnEm", ptr %t1464, i32 0, i32 4
  %t1467 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t1468 = load i64, ptr %l50, !tbaa !24
  %t1469 = load i64, ptr %l51, !tbaa !24
  %t1470 = extractvalue { i64, ptr } { i64 8, ptr @.d273 }, 1
  %t1471 = extractvalue { i64, ptr } { i64 8, ptr @.d273 }, 0
  %t1473 = extractvalue { i64, ptr } %t1467, 1
  %t1474 = extractvalue { i64, ptr } %t1467, 0
  %t1475 = add i64 %t1471, %t1474
  %t1476 = extractvalue { i64, ptr } { i64 4, ptr @.d274 }, 1
  %t1477 = extractvalue { i64, ptr } { i64 4, ptr @.d274 }, 0
  %t1478 = add i64 %t1475, %t1477
  %t1480 = call i64 @__olang_fmt_i64(ptr null, i64 %t1468)
  %t1481 = add i64 %t1478, %t1480
  %t1482 = extractvalue { i64, ptr } { i64 8, ptr @.d275 }, 1
  %t1483 = extractvalue { i64, ptr } { i64 8, ptr @.d275 }, 0
  %t1484 = add i64 %t1481, %t1483
  %t1486 = call i64 @__olang_fmt_i64(ptr null, i64 %t1469)
  %t1487 = add i64 %t1484, %t1486
  %t1488 = extractvalue { i64, ptr } { i64 1, ptr @.d276 }, 1
  %t1489 = extractvalue { i64, ptr } { i64 1, ptr @.d276 }, 0
  %t1490 = add i64 %t1487, %t1489
  %t1491 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1490)
  call void @olang_textcopy(ptr %t1491, ptr %t1470, i64 %t1471)
  %t1492 = getelementptr i8, ptr %t1491, i64 %t1471
  call void @olang_textcopy(ptr %t1492, ptr %t1473, i64 %t1474)
  %t1493 = getelementptr i8, ptr %t1492, i64 %t1474
  call void @olang_textcopy(ptr %t1493, ptr %t1476, i64 %t1477)
  %t1494 = getelementptr i8, ptr %t1493, i64 %t1477
  %t1495 = call i64 @__olang_fmt_i64(ptr %t1494, i64 %t1468)
  %t1496 = getelementptr i8, ptr %t1494, i64 %t1480
  call void @olang_textcopy(ptr %t1496, ptr %t1482, i64 %t1483)
  %t1497 = getelementptr i8, ptr %t1496, i64 %t1483
  %t1498 = call i64 @__olang_fmt_i64(ptr %t1497, i64 %t1469)
  %t1499 = getelementptr i8, ptr %t1497, i64 %t1486
  call void @olang_textcopy(ptr %t1499, ptr %t1488, i64 %t1489)
  %t1500 = insertvalue { i64, ptr } undef, i64 %t1490, 0
  %t1501 = insertvalue { i64, ptr } %t1500, ptr %t1491, 1
  %t1503 = extractvalue { i64, ptr } %t1501, 0
  %t1504 = extractvalue { i64, ptr } %t1501, 1
  %t1505 = mul i64 %t1503, 1
  %t1506 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1505)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1506, ptr %t1504, i64 %t1505, i1 false)
  %t1507 = insertvalue { i64, ptr } undef, i64 %t1503, 0
  %t1508 = insertvalue { i64, ptr } %t1507, ptr %t1506, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s56, ptr %t1466, { i64, ptr } %t1508)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s56)
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s51)
  br label %bb228
bb228:
  %t1511 = load i64, ptr %l49, !tbaa !24
  %t1513 = add i64 %t1511, 1
  store i64 %t1513, ptr %l49, !tbaa !24
  br label %bb203
bb229:
  %t1515 = load ptr, ptr %l0, !tbaa !29
  %t1517 = getelementptr %"compiler/emit:fnEm", ptr %t1515, i32 0, i32 0
  %t1518 = load ptr, ptr %t1517, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s49, ptr %t1518, { i64, ptr } { i64 21, ptr @.d277 })
  br label %bb230
bb230:
  store i64 0, ptr %l53, !tbaa !24
  %t1520 = load ptr, ptr %l0, !tbaa !29
  %t1522 = getelementptr %"compiler/emit:fnEm", ptr %t1520, i32 0, i32 0
  %t1523 = load ptr, ptr %t1522, !tbaa !29
  %t1524 = load ptr, ptr %l1, !tbaa !29
  %t1526 = getelementptr %"compiler/mir:Fn", ptr %t1524, i32 0, i32 0
  %t1527 = load { i64, [1 x i64] }, ptr %t1526
  %t1530 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %t1523, { i64, [1 x i64] } %t1527)
  store i64 %t1530, ptr %l593
  br label %bb231
bb231:
  %t1531 = load i64, ptr %l593, !tbaa !24
  store i64 %t1531, ptr %l54, !tbaa !24
  store i64 1, ptr %l55, !tbaa !24
  %t1532 = load i64, ptr %l54, !tbaa !24
  %t1533 = load i64, ptr %l53, !tbaa !24
  %t1536 = icmp sgt i64 %t1532, %t1533
  br i1 %t1536, label %bb232, label %bb233
bb232:
  %t1538 = load i64, ptr %l55, !tbaa !24
  %t1540 = icmp sgt i64 %t1538, 0
  br i1 %t1540, label %bb234, label %bb235
bb233:
  store i64 0, ptr %l597, !tbaa !24
  br label %bb237
bb234:
  %t1542 = load i64, ptr %l54, !tbaa !24
  %t1543 = load i64, ptr %l53, !tbaa !24
  %t1546 = sub i64 %t1542, %t1543
  %t1547 = load i64, ptr %l55, !tbaa !24
  %t1550 = add i64 %t1546, %t1547
  %t1552 = sub i64 %t1550, 1
  %t1553 = load i64, ptr %l55, !tbaa !24
  %t1556 = sdiv i64 %t1552, %t1553
  store i64 %t1556, ptr %l600, !tbaa !24
  br label %bb236
bb235:
  store i64 0, ptr %l600, !tbaa !24
  br label %bb236
bb236:
  %t1558 = load i64, ptr %l600, !tbaa !24
  store i64 %t1558, ptr %l597, !tbaa !24
  br label %bb237
bb237:
  %t1559 = load i64, ptr %l597, !tbaa !24
  store i64 %t1559, ptr %l56, !tbaa !24
  store i64 0, ptr %l57, !tbaa !24
  br label %bb238
bb238:
  store %olang.scope zeroinitializer, ptr %s61
  %t1560 = load i64, ptr %l57, !tbaa !24
  %t1561 = load i64, ptr %l56, !tbaa !24
  %t1564 = icmp slt i64 %t1560, %t1561
  %t1566 = xor i1 %t1564, true
  br i1 %t1566, label %bb239, label %bb240
bb239:
  call void @__olang_scope_close(ptr %s61)
  br label %bb248
bb240:
  br label %bb241
bb241:
  %t1568 = load i64, ptr %l53, !tbaa !24
  %t1569 = load i64, ptr %l57, !tbaa !24
  %t1570 = load i64, ptr %l55, !tbaa !24
  %t1573 = mul i64 %t1569, %t1570
  %t1576 = add i64 %t1568, %t1573
  store i64 %t1576, ptr %l58, !tbaa !24
  %t1578 = load ptr, ptr %l0, !tbaa !29
  %t1580 = getelementptr %"compiler/emit:fnEm", ptr %t1578, i32 0, i32 4
  store ptr %t1580, ptr %l619, !tbaa !29
  %t1581 = load i64, ptr %l58, !tbaa !24
  store i64 %t1581, ptr %l620, !tbaa !24
  %t1582 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t1582, ptr %l621, !tbaa !27
  %t1583 = load ptr, ptr %l1, !tbaa !29
  %t1585 = getelementptr %"compiler/mir:Fn", ptr %t1583, i32 0, i32 5
  %t1587 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t1585)
  store i64 %t1587, ptr %l624
  br label %bb242
bb242:
  %t1588 = load i64, ptr %l58, !tbaa !24
  %t1589 = load i64, ptr %l624, !tbaa !24
  %t1591 = add i64 %t1589, %t1588
  %t1592 = extractvalue { i64, ptr } { i64 5, ptr @.d278 }, 1
  %t1593 = extractvalue { i64, ptr } { i64 5, ptr @.d278 }, 0
  %t1594 = load i64, ptr %l620, !tbaa !24
  %t1595 = call i64 @__olang_fmt_i64(ptr null, i64 %t1594)
  %t1596 = add i64 %t1593, %t1595
  %t1597 = extractvalue { i64, ptr } { i64 17, ptr @.d279 }, 1
  %t1598 = extractvalue { i64, ptr } { i64 17, ptr @.d279 }, 0
  %t1599 = add i64 %t1596, %t1598
  %t1600 = load { i64, ptr }, ptr %l621, !tbaa !27
  %t1601 = extractvalue { i64, ptr } %t1600, 1
  %t1602 = extractvalue { i64, ptr } %t1600, 0
  %t1603 = add i64 %t1599, %t1602
  %t1604 = extractvalue { i64, ptr } { i64 23, ptr @.d280 }, 1
  %t1605 = extractvalue { i64, ptr } { i64 23, ptr @.d280 }, 0
  %t1606 = add i64 %t1603, %t1605
  %t1608 = call i64 @__olang_fmt_i64(ptr null, i64 %t1591)
  %t1609 = add i64 %t1606, %t1608
  %t1610 = extractvalue { i64, ptr } { i64 1, ptr @.d281 }, 1
  %t1611 = extractvalue { i64, ptr } { i64 1, ptr @.d281 }, 0
  %t1612 = add i64 %t1609, %t1611
  %t1613 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1612)
  call void @olang_textcopy(ptr %t1613, ptr %t1592, i64 %t1593)
  %t1614 = getelementptr i8, ptr %t1613, i64 %t1593
  %t1615 = call i64 @__olang_fmt_i64(ptr %t1614, i64 %t1594)
  %t1616 = getelementptr i8, ptr %t1614, i64 %t1595
  call void @olang_textcopy(ptr %t1616, ptr %t1597, i64 %t1598)
  %t1617 = getelementptr i8, ptr %t1616, i64 %t1598
  call void @olang_textcopy(ptr %t1617, ptr %t1601, i64 %t1602)
  %t1618 = getelementptr i8, ptr %t1617, i64 %t1602
  call void @olang_textcopy(ptr %t1618, ptr %t1604, i64 %t1605)
  %t1619 = getelementptr i8, ptr %t1618, i64 %t1605
  %t1620 = call i64 @__olang_fmt_i64(ptr %t1619, i64 %t1591)
  %t1621 = getelementptr i8, ptr %t1619, i64 %t1608
  call void @olang_textcopy(ptr %t1621, ptr %t1610, i64 %t1611)
  %t1622 = insertvalue { i64, ptr } undef, i64 %t1612, 0
  %t1623 = insertvalue { i64, ptr } %t1622, ptr %t1613, 1
  %t1625 = extractvalue { i64, ptr } %t1623, 0
  %t1626 = extractvalue { i64, ptr } %t1623, 1
  %t1627 = mul i64 %t1625, 1
  %t1628 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1627)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1628, ptr %t1626, i64 %t1627, i1 false)
  %t1629 = insertvalue { i64, ptr } undef, i64 %t1625, 0
  %t1630 = insertvalue { i64, ptr } %t1629, ptr %t1628, 1
  %t1631 = load ptr, ptr %l619, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s61, ptr %t1631, { i64, ptr } %t1630)
  br label %bb243
bb243:
  %t1633 = load ptr, ptr %l0, !tbaa !29
  %t1635 = getelementptr %"compiler/emit:fnEm", ptr %t1633, i32 0, i32 4
  %t1636 = load i64, ptr %l58, !tbaa !24
  %t1637 = load i64, ptr %l58, !tbaa !24
  %t1638 = extractvalue { i64, ptr } { i64 5, ptr @.d282 }, 1
  %t1639 = extractvalue { i64, ptr } { i64 5, ptr @.d282 }, 0
  %t1641 = call i64 @__olang_fmt_i64(ptr null, i64 %t1636)
  %t1642 = add i64 %t1639, %t1641
  %t1643 = extractvalue { i64, ptr } { i64 20, ptr @.d283 }, 1
  %t1644 = extractvalue { i64, ptr } { i64 20, ptr @.d283 }, 0
  %t1645 = add i64 %t1642, %t1644
  %t1647 = call i64 @__olang_fmt_i64(ptr null, i64 %t1637)
  %t1648 = add i64 %t1645, %t1647
  %t1649 = extractvalue { i64, ptr } { i64 12, ptr @.d284 }, 1
  %t1650 = extractvalue { i64, ptr } { i64 12, ptr @.d284 }, 0
  %t1651 = add i64 %t1648, %t1650
  %t1652 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1651)
  call void @olang_textcopy(ptr %t1652, ptr %t1638, i64 %t1639)
  %t1653 = getelementptr i8, ptr %t1652, i64 %t1639
  %t1654 = call i64 @__olang_fmt_i64(ptr %t1653, i64 %t1636)
  %t1655 = getelementptr i8, ptr %t1653, i64 %t1641
  call void @olang_textcopy(ptr %t1655, ptr %t1643, i64 %t1644)
  %t1656 = getelementptr i8, ptr %t1655, i64 %t1644
  %t1657 = call i64 @__olang_fmt_i64(ptr %t1656, i64 %t1637)
  %t1658 = getelementptr i8, ptr %t1656, i64 %t1647
  call void @olang_textcopy(ptr %t1658, ptr %t1649, i64 %t1650)
  %t1659 = insertvalue { i64, ptr } undef, i64 %t1651, 0
  %t1660 = insertvalue { i64, ptr } %t1659, ptr %t1652, 1
  %t1662 = extractvalue { i64, ptr } %t1660, 0
  %t1663 = extractvalue { i64, ptr } %t1660, 1
  %t1664 = mul i64 %t1662, 1
  %t1665 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1664)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1665, ptr %t1663, i64 %t1664, i1 false)
  %t1666 = insertvalue { i64, ptr } undef, i64 %t1662, 0
  %t1667 = insertvalue { i64, ptr } %t1666, ptr %t1665, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s61, ptr %t1635, { i64, ptr } %t1667)
  br label %bb244
bb244:
  %t1670 = load ptr, ptr %l0, !tbaa !29
  %t1672 = getelementptr %"compiler/emit:fnEm", ptr %t1670, i32 0, i32 4
  store ptr %t1672, ptr %l636, !tbaa !29
  %t1673 = load i64, ptr %l58, !tbaa !24
  store i64 %t1673, ptr %l637, !tbaa !24
  %t1674 = load i64, ptr %l58, !tbaa !24
  store i64 %t1674, ptr %l638, !tbaa !24
  %t1675 = load ptr, ptr %l0, !tbaa !29
  %t1677 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %s61, ptr %t1675)
  store { i64, ptr } %t1677, ptr %l640
  br label %bb245
bb245:
  %t1678 = extractvalue { i64, ptr } { i64 5, ptr @.d285 }, 1
  %t1679 = extractvalue { i64, ptr } { i64 5, ptr @.d285 }, 0
  %t1680 = load i64, ptr %l637, !tbaa !24
  %t1681 = call i64 @__olang_fmt_i64(ptr null, i64 %t1680)
  %t1682 = add i64 %t1679, %t1681
  %t1683 = extractvalue { i64, ptr } { i64 42, ptr @.d286 }, 1
  %t1684 = extractvalue { i64, ptr } { i64 42, ptr @.d286 }, 0
  %t1685 = add i64 %t1682, %t1684
  %t1686 = load i64, ptr %l638, !tbaa !24
  %t1687 = call i64 @__olang_fmt_i64(ptr null, i64 %t1686)
  %t1688 = add i64 %t1685, %t1687
  %t1689 = extractvalue { i64, ptr } { i64 1, ptr @.d287 }, 1
  %t1690 = extractvalue { i64, ptr } { i64 1, ptr @.d287 }, 0
  %t1691 = add i64 %t1688, %t1690
  %t1692 = load { i64, ptr }, ptr %l640, !tbaa !27
  %t1693 = extractvalue { i64, ptr } %t1692, 1
  %t1694 = extractvalue { i64, ptr } %t1692, 0
  %t1695 = add i64 %t1691, %t1694
  %t1696 = extractvalue { i64, ptr } { i64 1, ptr @.d288 }, 1
  %t1697 = extractvalue { i64, ptr } { i64 1, ptr @.d288 }, 0
  %t1698 = add i64 %t1695, %t1697
  %t1699 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1698)
  call void @olang_textcopy(ptr %t1699, ptr %t1678, i64 %t1679)
  %t1700 = getelementptr i8, ptr %t1699, i64 %t1679
  %t1701 = call i64 @__olang_fmt_i64(ptr %t1700, i64 %t1680)
  %t1702 = getelementptr i8, ptr %t1700, i64 %t1681
  call void @olang_textcopy(ptr %t1702, ptr %t1683, i64 %t1684)
  %t1703 = getelementptr i8, ptr %t1702, i64 %t1684
  %t1704 = call i64 @__olang_fmt_i64(ptr %t1703, i64 %t1686)
  %t1705 = getelementptr i8, ptr %t1703, i64 %t1687
  call void @olang_textcopy(ptr %t1705, ptr %t1689, i64 %t1690)
  %t1706 = getelementptr i8, ptr %t1705, i64 %t1690
  call void @olang_textcopy(ptr %t1706, ptr %t1693, i64 %t1694)
  %t1707 = getelementptr i8, ptr %t1706, i64 %t1694
  call void @olang_textcopy(ptr %t1707, ptr %t1696, i64 %t1697)
  %t1708 = insertvalue { i64, ptr } undef, i64 %t1698, 0
  %t1709 = insertvalue { i64, ptr } %t1708, ptr %t1699, 1
  %t1711 = extractvalue { i64, ptr } %t1709, 0
  %t1712 = extractvalue { i64, ptr } %t1709, 1
  %t1713 = mul i64 %t1711, 1
  %t1714 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1713)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1714, ptr %t1712, i64 %t1713, i1 false)
  %t1715 = insertvalue { i64, ptr } undef, i64 %t1711, 0
  %t1716 = insertvalue { i64, ptr } %t1715, ptr %t1714, 1
  %t1717 = load ptr, ptr %l636, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s61, ptr %t1717, { i64, ptr } %t1716)
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s61)
  br label %bb247
bb247:
  %t1719 = load i64, ptr %l57, !tbaa !24
  %t1721 = add i64 %t1719, 1
  store i64 %t1721, ptr %l57, !tbaa !24
  br label %bb238
bb248:
  call void @__olang_scope_close(ptr %s49)
  br label %bb249
bb249:
  %t1723 = load ptr, ptr @__olang_prog_scope
  %t1724 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1723)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1724, ptr %l645
  br label %bb250
bb250:
  %t1725 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l645
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1725, ptr %l59
  %t1726 = load ptr, ptr %l0, !tbaa !29
  %t1728 = getelementptr %"compiler/emit:fnEm", ptr %t1726, i32 0, i32 0
  %t1729 = load ptr, ptr %t1728, !tbaa !29
  %t1731 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t1729)
  store i1 %t1731, ptr %l648
  br label %bb251
bb251:
  %t1732 = load i1, ptr %l648, !tbaa !21
  br i1 %t1732, label %bb252, label %bb253
bb252:
  %t1733 = load ptr, ptr %l1, !tbaa !29
  %t1735 = getelementptr %"compiler/mir:Fn", ptr %t1733, i32 0, i32 22
  store ptr %t1735, ptr %l60, !tbaa !29
  store i64 0, ptr %l61, !tbaa !24
  br label %bb254
bb253:
  br label %bb270
bb254:
  store %olang.scope zeroinitializer, ptr %s68
  %t1737 = load ptr, ptr %l60, !tbaa !29
  %t1738 = load i64, ptr %l61, !tbaa !24
  %t1741 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t1737, i64 %t1738)
  %t1742 = extractvalue { i32, { i64, ptr } } %t1741, 1
  %t1743 = extractvalue { i32, { i64, ptr } } %t1741, 0
  store i32 %t1743, ptr %l655
  %t1744 = icmp ne i32 %t1743, 0
  br i1 %t1744, label %bb256, label %ok.1745
ok.1745:
  store { i64, ptr } %t1742, ptr %l654
  br label %bb255
bb255:
  %t1746 = load { i64, ptr }, ptr %l654, !tbaa !27
  store { i64, ptr } %t1746, ptr %l651, !tbaa !27
  br label %bb260
bb256:
  %t1747 = load i32, ptr %l655, !tbaa !23
  %t1748 = ashr i32 %t1747, 16
  %t1750 = icmp eq i32 %t1748, 1
  br i1 %t1750, label %bb257, label %bb258
bb257:
  br label %bb259
bb258:
  call void @__olang_check_failed(ptr @olang_loc_273e839fc85d1f4_991991d173f6efe0)
  unreachable
bb259:
  call void @__olang_scope_close(ptr %s68)
  br label %bb269
bb260:
  %t1752 = load { i64, ptr }, ptr %l651, !tbaa !27
  store { i64, ptr } %t1752, ptr %l62, !tbaa !27
  %t1753 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1755 = extractvalue { i64, ptr } %t1753, 0
  store i64 %t1755, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb261
bb261:
  store %olang.scope zeroinitializer, ptr %s69
  %t1757 = load i64, ptr %l64, !tbaa !24
  %t1758 = load i64, ptr %l63, !tbaa !24
  %t1761 = icmp slt i64 %t1757, %t1758
  %t1763 = xor i1 %t1761, true
  br i1 %t1763, label %bb262, label %bb263
bb262:
  call void @__olang_scope_close(ptr %s69)
  br label %bb267
bb263:
  br label %bb264
bb264:
  %t1765 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t1765, ptr %l664, !tbaa !27
  %t1766 = load i64, ptr %l64, !tbaa !24
  %t1768 = getelementptr { i64, ptr }, ptr %l664, i32 0, i32 1
  %t1769 = load ptr, ptr %t1768, !tbaa !27
  %t1770 = getelementptr i32, ptr %t1769, i64 %t1766
  %t1771 = load i32, ptr %t1770, !tbaa !33
  %t1775 = sext i32 %t1771 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l59, i64 %t1775, i1 true)
  br label %bb265
bb265:
  call void @__olang_scope_close(ptr %s69)
  br label %bb266
bb266:
  %t1778 = load i64, ptr %l64, !tbaa !24
  %t1780 = add i64 %t1778, 1
  store i64 %t1780, ptr %l64, !tbaa !24
  br label %bb261
bb267:
  %t1782 = load i64, ptr %l61, !tbaa !24
  %t1783 = load i64, ptr %l63, !tbaa !24
  %t1786 = add i64 %t1782, %t1783
  store i64 %t1786, ptr %l61, !tbaa !24
  call void @__olang_scope_close(ptr %s68)
  br label %bb268
bb268:
  br label %bb254
bb269:
  br label %bb270
bb270:
  store i64 0, ptr %l66, !tbaa !24
  %t1788 = load ptr, ptr %l1, !tbaa !29
  %t1790 = getelementptr %"compiler/mir:Fn", ptr %t1788, i32 0, i32 9
  %t1792 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %t1790)
  store i64 %t1792, ptr %l677
  br label %bb271
bb271:
  %t1793 = load i64, ptr %l677, !tbaa !24
  store i64 %t1793, ptr %l67, !tbaa !24
  store i64 1, ptr %l68, !tbaa !24
  %t1794 = load i64, ptr %l67, !tbaa !24
  %t1795 = load i64, ptr %l66, !tbaa !24
  %t1798 = icmp sgt i64 %t1794, %t1795
  br i1 %t1798, label %bb272, label %bb273
bb272:
  %t1800 = load i64, ptr %l68, !tbaa !24
  %t1802 = icmp sgt i64 %t1800, 0
  br i1 %t1802, label %bb274, label %bb275
bb273:
  store i64 0, ptr %l681, !tbaa !24
  br label %bb277
bb274:
  %t1804 = load i64, ptr %l67, !tbaa !24
  %t1805 = load i64, ptr %l66, !tbaa !24
  %t1808 = sub i64 %t1804, %t1805
  %t1809 = load i64, ptr %l68, !tbaa !24
  %t1812 = add i64 %t1808, %t1809
  %t1814 = sub i64 %t1812, 1
  %t1815 = load i64, ptr %l68, !tbaa !24
  %t1818 = sdiv i64 %t1814, %t1815
  store i64 %t1818, ptr %l684, !tbaa !24
  br label %bb276
bb275:
  store i64 0, ptr %l684, !tbaa !24
  br label %bb276
bb276:
  %t1820 = load i64, ptr %l684, !tbaa !24
  store i64 %t1820, ptr %l681, !tbaa !24
  br label %bb277
bb277:
  %t1821 = load i64, ptr %l681, !tbaa !24
  store i64 %t1821, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  br label %bb278
bb278:
  store %olang.scope zeroinitializer, ptr %s72
  %t1822 = load i64, ptr %l70, !tbaa !24
  %t1823 = load i64, ptr %l69, !tbaa !24
  %t1826 = icmp slt i64 %t1822, %t1823
  %t1828 = xor i1 %t1826, true
  br i1 %t1828, label %bb279, label %bb280
bb279:
  call void @__olang_scope_close(ptr %s72)
  br label %bb309
bb280:
  br label %bb281
bb281:
  %t1830 = load i64, ptr %l66, !tbaa !24
  %t1831 = load i64, ptr %l70, !tbaa !24
  %t1832 = load i64, ptr %l68, !tbaa !24
  %t1835 = mul i64 %t1831, %t1832
  %t1838 = add i64 %t1830, %t1835
  store i64 %t1838, ptr %l71, !tbaa !24
  %t1840 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1840, ptr %l702, !tbaa !29
  %t1841 = load i64, ptr %l71, !tbaa !24
  %t1843 = trunc i64 %t1841 to i32
  %t1846 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s72, i32 %t1843)
  store { i64, ptr } %t1846, ptr %l706
  br label %bb282
bb282:
  %t1847 = load { i64, ptr }, ptr %l706, !tbaa !27
  %t1848 = extractvalue { i64, ptr } %t1847, 0
  %t1849 = extractvalue { i64, ptr } %t1847, 1
  %t1850 = mul i64 %t1848, 1
  %t1851 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1850)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1851, ptr %t1849, i64 %t1850, i1 false)
  %t1852 = insertvalue { i64, ptr } undef, i64 %t1848, 0
  %t1853 = insertvalue { i64, ptr } %t1852, ptr %t1851, 1
  %t1854 = load ptr, ptr %l702, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s72, ptr %t1854, { i64, ptr } %t1853)
  br label %bb283
bb283:
  %t1856 = load ptr, ptr %l1, !tbaa !29
  %t1858 = getelementptr %"compiler/mir:Fn", ptr %t1856, i32 0, i32 9
  %t1859 = load i64, ptr %l71, !tbaa !24
  %t1862 = call %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v0, ptr %t1858, i64 %t1859)
  store %"compiler/mir:BasicBlock" %t1862, ptr %l711
  br label %bb284
bb284:
  %t1863 = load %"compiler/mir:BasicBlock", ptr %l711
  store %"compiler/mir:BasicBlock" %t1863, ptr %l72
  %t1864 = load i64, ptr %l71, !tbaa !24
  %t1867 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l59, i64 %t1864)
  store i1 %t1867, ptr %l714
  br label %bb285
bb285:
  %t1868 = load i1, ptr %l714, !tbaa !21
  br i1 %t1868, label %bb286, label %bb287
bb286:
  store %olang.scope zeroinitializer, ptr %s73
  %t1869 = load ptr, ptr %l0, !tbaa !29
  %t1871 = getelementptr %"compiler/emit:fnEm", ptr %t1869, i32 0, i32 0
  %t1872 = load ptr, ptr %t1871, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s73, ptr %t1872, { i64, ptr } { i64 17, ptr @.d289 })
  br label %bb288
bb287:
  br label %bb290
bb288:
  %t1874 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s73, ptr %t1874, { i64, ptr } { i64 30, ptr @.d290 })
  br label %bb289
bb289:
  call void @__olang_scope_close(ptr %s73)
  br label %bb290
bb290:
  %t1876 = getelementptr %"compiler/mir:BasicBlock", ptr %l72, i32 0, i32 0
  store ptr %t1876, ptr %l73, !tbaa !29
  store i64 0, ptr %l74, !tbaa !24
  br label %bb291
bb291:
  store %olang.scope zeroinitializer, ptr %s75
  %t1878 = load ptr, ptr %l73, !tbaa !29
  %t1879 = load i64, ptr %l74, !tbaa !24
  %t1882 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t1878, i64 %t1879)
  %t1883 = extractvalue { i32, { i64, ptr } } %t1882, 1
  %t1884 = extractvalue { i32, { i64, ptr } } %t1882, 0
  store i32 %t1884, ptr %l723
  %t1885 = icmp ne i32 %t1884, 0
  br i1 %t1885, label %bb293, label %ok.1886
ok.1886:
  store { i64, ptr } %t1883, ptr %l722
  br label %bb292
bb292:
  %t1887 = load { i64, ptr }, ptr %l722, !tbaa !27
  store { i64, ptr } %t1887, ptr %l719, !tbaa !27
  br label %bb297
bb293:
  %t1888 = load i32, ptr %l723, !tbaa !23
  %t1889 = ashr i32 %t1888, 16
  %t1891 = icmp eq i32 %t1889, 1
  br i1 %t1891, label %bb294, label %bb295
bb294:
  br label %bb296
bb295:
  call void @__olang_check_failed(ptr @olang_loc_3a1aa3acd228b12f_45ca77ec12fd04db)
  unreachable
bb296:
  call void @__olang_scope_close(ptr %s75)
  br label %bb306
bb297:
  %t1893 = load { i64, ptr }, ptr %l719, !tbaa !27
  store { i64, ptr } %t1893, ptr %l75, !tbaa !27
  %t1894 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t1896 = extractvalue { i64, ptr } %t1894, 0
  store i64 %t1896, ptr %l76, !tbaa !24
  store i64 0, ptr %l77, !tbaa !24
  br label %bb298
bb298:
  store %olang.scope zeroinitializer, ptr %s76
  %t1898 = load i64, ptr %l77, !tbaa !24
  %t1899 = load i64, ptr %l76, !tbaa !24
  %t1902 = icmp slt i64 %t1898, %t1899
  %t1904 = xor i1 %t1902, true
  br i1 %t1904, label %bb299, label %bb300
bb299:
  call void @__olang_scope_close(ptr %s76)
  br label %bb304
bb300:
  br label %bb301
bb301:
  %t1906 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t1906, ptr %l732, !tbaa !27
  %t1907 = load i64, ptr %l77, !tbaa !24
  %t1909 = getelementptr { i64, ptr }, ptr %l732, i32 0, i32 1
  %t1910 = load ptr, ptr %t1909, !tbaa !27
  %t1911 = getelementptr { i64, [21 x i64] }, ptr %t1910, i64 %t1907
  call void @llvm.memmove.p0.p0.i64(ptr %l734, ptr %t1911, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l78, ptr %l734, i64 176, i1 false)
  %t1912 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estmt(ptr %v0, ptr %s76, ptr %t1912, ptr %l78)
  br label %bb302
bb302:
  call void @__olang_scope_close(ptr %s76)
  br label %bb303
bb303:
  %t1915 = load i64, ptr %l77, !tbaa !24
  %t1917 = add i64 %t1915, 1
  store i64 %t1917, ptr %l77, !tbaa !24
  br label %bb298
bb304:
  %t1919 = load i64, ptr %l74, !tbaa !24
  %t1920 = load i64, ptr %l76, !tbaa !24
  %t1923 = add i64 %t1919, %t1920
  store i64 %t1923, ptr %l74, !tbaa !24
  call void @__olang_scope_close(ptr %s75)
  br label %bb305
bb305:
  br label %bb291
bb306:
  %t1925 = load ptr, ptr %l0, !tbaa !29
  %t1926 = getelementptr %"compiler/mir:BasicBlock", ptr %l72, i32 0, i32 1
  %t1927 = load { i64, [7 x i64] }, ptr %t1926
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eterm(ptr %v0, ptr %t1925, { i64, [7 x i64] } %t1927)
  br label %bb307
bb307:
  call void @__olang_scope_close(ptr %s72)
  br label %bb308
bb308:
  %t1930 = load i64, ptr %l70, !tbaa !24
  %t1932 = add i64 %t1930, 1
  store i64 %t1932, ptr %l70, !tbaa !24
  br label %bb278
bb309:
  %t1934 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t1934, { i64, ptr } { i64 3, ptr @.d291 })
  br label %bb310
bb310:
  %t1936 = load ptr, ptr %l0, !tbaa !29
  %t1938 = getelementptr %"compiler/emit:fnEm", ptr %t1936, i32 0, i32 13
  %t1939 = load i1, ptr %t1938, !tbaa !21
  br i1 %t1939, label %bb311, label %bb312
bb311:
  store %olang.scope zeroinitializer, ptr %s79
  %t1941 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s79, ptr %t1941, { i64, ptr } { i64 40, ptr @.d292 })
  br label %bb313
bb312:
  br label %bb314
bb313:
  call void @__olang_scope_close(ptr %s79)
  br label %bb314
bb314:
  %t1943 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t1945 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1943, { i64, ptr } { i64 4, ptr @.d293 })
  store i1 %t1945, ptr %l751
  br label %bb315
bb315:
  %t1946 = load i1, ptr %l751, !tbaa !21
  %t1947 = xor i1 %t1946, true
  br i1 %t1947, label %bb316, label %bb317
bb316:
  store %olang.scope zeroinitializer, ptr %s80
  %t1949 = load ptr, ptr %l0, !tbaa !29
  %t1950 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t1951 = extractvalue { i64, ptr } { i64 11, ptr @.d294 }, 1
  %t1952 = extractvalue { i64, ptr } { i64 11, ptr @.d294 }, 0
  %t1954 = extractvalue { i64, ptr } %t1950, 1
  %t1955 = extractvalue { i64, ptr } %t1950, 0
  %t1956 = add i64 %t1952, %t1955
  %t1957 = extractvalue { i64, ptr } { i64 9, ptr @.d295 }, 1
  %t1958 = extractvalue { i64, ptr } { i64 9, ptr @.d295 }, 0
  %t1959 = add i64 %t1956, %t1958
  %t1960 = call ptr @__olang_scope_alloc(ptr %s80, i64 %t1959)
  call void @olang_textcopy(ptr %t1960, ptr %t1951, i64 %t1952)
  %t1961 = getelementptr i8, ptr %t1960, i64 %t1952
  call void @olang_textcopy(ptr %t1961, ptr %t1954, i64 %t1955)
  %t1962 = getelementptr i8, ptr %t1961, i64 %t1955
  call void @olang_textcopy(ptr %t1962, ptr %t1957, i64 %t1958)
  %t1963 = insertvalue { i64, ptr } undef, i64 %t1959, 0
  %t1964 = insertvalue { i64, ptr } %t1963, ptr %t1960, 1
  %t1966 = extractvalue { i64, ptr } %t1964, 0
  %t1967 = extractvalue { i64, ptr } %t1964, 1
  %t1968 = mul i64 %t1966, 1
  %t1969 = call ptr @__olang_scope_alloc(ptr %s80, i64 %t1968)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1969, ptr %t1967, i64 %t1968, i1 false)
  %t1970 = insertvalue { i64, ptr } undef, i64 %t1966, 0
  %t1971 = insertvalue { i64, ptr } %t1970, ptr %t1969, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s80, ptr %t1949, { i64, ptr } %t1971)
  br label %bb318
bb317:
  store %olang.scope zeroinitializer, ptr %s83
  %t1974 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s83, ptr %t1974, { i64, ptr } { i64 8, ptr @.d296 })
  br label %bb320
bb318:
  %t1976 = load ptr, ptr %l0, !tbaa !29
  %t1977 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t1978 = extractvalue { i64, ptr } { i64 4, ptr @.d297 }, 1
  %t1979 = extractvalue { i64, ptr } { i64 4, ptr @.d297 }, 0
  %t1981 = extractvalue { i64, ptr } %t1977, 1
  %t1982 = extractvalue { i64, ptr } %t1977, 0
  %t1983 = add i64 %t1979, %t1982
  %t1984 = extractvalue { i64, ptr } { i64 4, ptr @.d298 }, 1
  %t1985 = extractvalue { i64, ptr } { i64 4, ptr @.d298 }, 0
  %t1986 = add i64 %t1983, %t1985
  %t1987 = call ptr @__olang_scope_alloc(ptr %s80, i64 %t1986)
  call void @olang_textcopy(ptr %t1987, ptr %t1978, i64 %t1979)
  %t1988 = getelementptr i8, ptr %t1987, i64 %t1979
  call void @olang_textcopy(ptr %t1988, ptr %t1981, i64 %t1982)
  %t1989 = getelementptr i8, ptr %t1988, i64 %t1982
  call void @olang_textcopy(ptr %t1989, ptr %t1984, i64 %t1985)
  %t1990 = insertvalue { i64, ptr } undef, i64 %t1986, 0
  %t1991 = insertvalue { i64, ptr } %t1990, ptr %t1987, 1
  %t1993 = extractvalue { i64, ptr } %t1991, 0
  %t1994 = extractvalue { i64, ptr } %t1991, 1
  %t1995 = mul i64 %t1993, 1
  %t1996 = call ptr @__olang_scope_alloc(ptr %s80, i64 %t1995)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1996, ptr %t1994, i64 %t1995, i1 false)
  %t1997 = insertvalue { i64, ptr } undef, i64 %t1993, 0
  %t1998 = insertvalue { i64, ptr } %t1997, ptr %t1996, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s80, ptr %t1976, { i64, ptr } %t1998)
  br label %bb319
bb319:
  call void @__olang_scope_close(ptr %s80)
  br label %bb321
bb320:
  call void @__olang_scope_close(ptr %s83)
  br label %bb321
bb321:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:fnEm", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l11
  br label %bb2
bb2:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2esrcAddr(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca { { i64, ptr }, i32 }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca { { i64, ptr }, i32 }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/mir:Place", ptr %l2
  %t14 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t10, %"compiler/mir:Place" %t11)
  store { { i64, ptr }, i32 } %t14, ptr %l14
  br label %bb4
bb4:
  %t15 = load { { i64, ptr }, i32 }, ptr %l14
  store { { i64, ptr }, i32 } %t15, ptr %l3
  %t16 = getelementptr { { i64, ptr }, i32 }, ptr %l3, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l16, !tbaa !24
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = mul i64 %t20, 1
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l16, !tbaa !24
  %t30 = mul i64 %t29, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l20, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t46, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb5:
  %t48 = load { i64, [4 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [4 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  %t57 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l6, !tbaa !23
  %t61 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 2
  %t63 = load i64, ptr %t62
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t65, i32 0, i32 3
  %t67 = load %"compiler/source:Span", ptr %t66
  store %"compiler/source:Span" %t67, ptr %l8
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t71 = load i32, ptr %l6, !tbaa !23
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load %"compiler/source:Span", ptr %l8
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edata(ptr %v0, ptr %v1, ptr %t69, i32 %t70, i32 %t71, i64 %t72, %"compiler/source:Span" %t73, i1 true)
  store { i64, ptr } %t79, ptr %l32
  br label %bb9
bb9:
  %t80 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr @.d299 }, ptr %l33, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t81, ptr %l34, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l35, !tbaa !24
  %t84 = load i64, ptr %l35, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l36, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l35, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t95, ptr %l34, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_37dcdc821423a995_2a435c3b360fb831)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t6 = extractvalue { i64, ptr } { i64 6, ptr @.d300 }, 1
  %t7 = extractvalue { i64, ptr } { i64 6, ptr @.d300 }, 0
  %t9 = extractvalue { i64, ptr } %a1, 1
  %t10 = extractvalue { i64, ptr } %a1, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d301 }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr @.d301 }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a2, 1
  %t17 = extractvalue { i64, ptr } %a2, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 6, ptr @.d302 }, 1
  %t20 = extractvalue { i64, ptr } { i64 6, ptr @.d302 }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a3, 1
  %t24 = extractvalue { i64, ptr } %a3, 0
  %t25 = add i64 %t21, %t24
  %t27 = extractvalue { i64, ptr } %a4, 1
  %t28 = extractvalue { i64, ptr } %a4, 0
  %t29 = add i64 %t25, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t6, i64 %t7)
  %t31 = getelementptr i8, ptr %t30, i64 %t7
  call void @olang_textcopy(ptr %t31, ptr %t9, i64 %t10)
  %t32 = getelementptr i8, ptr %t31, i64 %t10
  call void @olang_textcopy(ptr %t32, ptr %t12, i64 %t13)
  %t33 = getelementptr i8, ptr %t32, i64 %t13
  call void @olang_textcopy(ptr %t33, ptr %t16, i64 %t17)
  %t34 = getelementptr i8, ptr %t33, i64 %t17
  call void @olang_textcopy(ptr %t34, ptr %t19, i64 %t20)
  %t35 = getelementptr i8, ptr %t34, i64 %t20
  call void @olang_textcopy(ptr %t35, ptr %t23, i64 %t24)
  %t36 = getelementptr i8, ptr %t35, i64 %t24
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t30, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } %t45)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t2, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t8, i32 0, i32 6
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d303 }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr @.d303 }, 0
  %t17 = call i64 @__olang_fmt_i64(ptr null, i64 %t13)
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t14, i64 %t15)
  %t20 = getelementptr i8, ptr %t19, i64 %t15
  %t21 = call i64 @__olang_fmt_i64(ptr %t20, i64 %t13)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:BasicBlock"
  %l8 = alloca { i64, [7 x i64] }
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l38 = alloca { i64, ptr }
  %l59 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i32
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t4)
  store i1 %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load i1, ptr %l16, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 22
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:fnEm", ptr %t17, i32 0, i32 22
  store i1 true, ptr %t19, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/emit:fnEm", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/mir:Fn", ptr %t23, i32 0, i32 9
  store ptr %t25, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb37
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t27, i64 %t28)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l29
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb9, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l28
  br label %bb8
bb8:
  %t36 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  br label %bb13
bb9:
  %t37 = load i32, ptr %l29, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2ea555a1037c9329_7e95fb4c4c24cb65)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb13:
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t42, ptr %l4, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb16:
  br label %bb17
bb17:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr %"compiler/mir:BasicBlock", ptr %t59, i64 %t56
  %t61 = load %"compiler/mir:BasicBlock", ptr %t60
  store %"compiler/mir:BasicBlock" %t61, ptr %l7
  %t63 = getelementptr %"compiler/mir:BasicBlock", ptr %l7, i32 0, i32 1
  %t64 = load { i64, [7 x i64] }, ptr %t63
  store { i64, [7 x i64] } %t64, ptr %l8
  %t66 = load { i64, [7 x i64] }, ptr %l8
  %t68 = extractvalue { i64, [7 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 4
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32 }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/source:Span", ptr %t72
  store %"compiler/source:Span" %t73, ptr %l9
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 21
  %t78 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t79 = load i32, ptr %t78, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t77, i32 %t79, i64 1)
  br label %bb21
bb21:
  br label %bb32
bb22:
  %t82 = load { i64, [7 x i64] }, ptr %l8
  %t84 = extractvalue { i64, [7 x i64] } %t82, 0
  %t85 = icmp eq i64 %t84, 7
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t87 = getelementptr { i64, [7 x i64] }, ptr %l8, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t87, i32 0, i32 0
  %t89 = load %"compiler/source:Span", ptr %t88
  store %"compiler/source:Span" %t89, ptr %l10
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/emit:fnEm", ptr %t91, i32 0, i32 21
  %t94 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t93, i32 %t95, i64 2)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_bf62c1c7e423c058_299389d9c8f1c434)
  unreachable
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t98 = load i64, ptr %l6, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l6, !tbaa !24
  br label %bb14
bb34:
  %t102 = load i64, ptr %l3, !tbaa !24
  %t103 = load i64, ptr %l5, !tbaa !24
  %t106 = add i64 %t102, %t103
  store i64 %t106, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  br label %bb7
bb36:
  br label %bb37
bb37:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/emit:fnEm", ptr %t108, i32 0, i32 21
  %t111 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t115 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eGet_3cI32_2c_20I64_3e(ptr %v0, ptr %t110, i32 %t112)
  %t116 = extractvalue { i32, i64 } %t115, 1
  %t117 = extractvalue { i32, i64 } %t115, 0
  store i32 %t117, ptr %l64
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb39, label %ok.119
ok.119:
  store i64 %t116, ptr %l63
  br label %bb38
bb38:
  %t120 = load i64, ptr %l63, !tbaa !24
  store i64 %t120, ptr %l59, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb41
bb41:
  %t121 = load i64, ptr %l59, !tbaa !24
  store i64 %t121, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp eq i64 %t122, 1
  br i1 %t124, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 16, ptr @.d304 }, ptr %l67, !tbaa !27
  br label %bb47
bb43:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = icmp eq i64 %t126, 2
  br i1 %t128, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 40, ptr @.d305 }, ptr %l70, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 11, ptr @.d306 }, ptr %l70, !tbaa !27
  br label %bb46
bb46:
  %t130 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t130, ptr %l67, !tbaa !27
  br label %bb47
bb47:
  %t131 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t131, ptr %l12, !tbaa !27
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = icmp eq i64 %t132, 1
  br i1 %t134, label %bb48, label %bb49
bb48:
  store { i64, ptr } { i64 16, ptr @.d307 }, ptr %l73, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 17, ptr @.d308 }, ptr %l73, !tbaa !27
  br label %bb50
bb50:
  %t136 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t136, ptr %l13, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/emit:fnEm", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t143 = extractvalue { i64, ptr } { i64 6, ptr @.d309 }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr @.d309 }, 0
  %t146 = extractvalue { i64, ptr } %t142, 1
  %t147 = extractvalue { i64, ptr } %t142, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 5, ptr @.d310 }, 1
  %t150 = extractvalue { i64, ptr } { i64 5, ptr @.d310 }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t143, i64 %t144)
  %t153 = getelementptr i8, ptr %t152, i64 %t144
  call void @olang_textcopy(ptr %t153, ptr %t146, i64 %t147)
  %t154 = getelementptr i8, ptr %t153, i64 %t147
  call void @olang_textcopy(ptr %t154, ptr %t149, i64 %t150)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t164, ptr %s0, ptr %t140, { i64, ptr } %t141, { i64, ptr } %t163)
  br label %bb51
bb51:
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l80, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t169, ptr %l81, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l1
  %t172 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t173 = extractvalue { i64, ptr } { i64 2, ptr @.d311 }, 1
  %t174 = extractvalue { i64, ptr } { i64 2, ptr @.d311 }, 0
  %t176 = extractvalue { i64, ptr } %t172, 1
  %t177 = extractvalue { i64, ptr } %t172, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr @.d312 }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr @.d312 }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t173, i64 %t174)
  %t183 = getelementptr i8, ptr %t182, i64 %t174
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = getelementptr i8, ptr %t183, i64 %t177
  call void @olang_textcopy(ptr %t184, ptr %t179, i64 %t180)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t182, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = extractvalue { i64, ptr } %t186, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t197 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s0, ptr %s0, ptr %t170, %"compiler/source:Span" %t171, { i64, ptr } %t193)
  store { i64, ptr } %t197, ptr %l87
  br label %bb52
bb52:
  %t198 = extractvalue { i64, ptr } { i64 11, ptr @.d313 }, 1
  %t199 = extractvalue { i64, ptr } { i64 11, ptr @.d313 }, 0
  %t200 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = add i64 %t199, %t202
  %t204 = extractvalue { i64, ptr } { i64 5, ptr @.d314 }, 1
  %t205 = extractvalue { i64, ptr } { i64 5, ptr @.d314 }, 0
  %t206 = add i64 %t203, %t205
  %t207 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr @.d315 }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr @.d315 }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t198, i64 %t199)
  %t215 = getelementptr i8, ptr %t214, i64 %t199
  call void @olang_textcopy(ptr %t215, ptr %t201, i64 %t202)
  %t216 = getelementptr i8, ptr %t215, i64 %t202
  call void @olang_textcopy(ptr %t216, ptr %t204, i64 %t205)
  %t217 = getelementptr i8, ptr %t216, i64 %t205
  call void @olang_textcopy(ptr %t217, ptr %t208, i64 %t209)
  %t218 = getelementptr i8, ptr %t217, i64 %t209
  call void @olang_textcopy(ptr %t218, ptr %t211, i64 %t212)
  %t219 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t214, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = extractvalue { i64, ptr } %t220, 1
  %t224 = mul i64 %t222, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t224)
  call void @llvm.memcpy.p0.p0.i64(ptr %t225, ptr %t223, i64 %t224, i1 false)
  %t226 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  %t228 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t228, { i64, ptr } %t227)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 18, ptr @.d316 }, { i64, ptr } { i64 67, ptr @.d317 })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr @.d318 }, { i64, ptr } { i64 19, ptr @.d319 }, { i64, ptr } { i64 0, ptr @.d320 })
  store { i64, ptr } %t8, ptr %l7
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = extractvalue { i64, ptr } { i64 35, ptr @.d321 }, 1
  %t15 = extractvalue { i64, ptr } { i64 35, ptr @.d321 }, 0
  %t17 = sext i32 %t13 to i64
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t17)
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 14, ptr @.d322 }, 1
  %t21 = extractvalue { i64, ptr } { i64 14, ptr @.d322 }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = getelementptr i8, ptr %t23, i64 %t15
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t17)
  %t26 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t26, ptr %t20, i64 %t21)
  %t27 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t23, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t12, { i64, ptr } %t35)
  store { i64, ptr } %t38, ptr %l14
  br label %bb3
bb3:
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l8, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } { i64 3, ptr @.d323 }, { i64, ptr } %t47, { i64, ptr } %t45, { i64, ptr } { i64 0, ptr @.d324 })
  br label %bb4
bb4:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l16, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t51 = extractvalue { i64, ptr } { i64 2, ptr @.d325 }, 1
  %t52 = extractvalue { i64, ptr } { i64 2, ptr @.d325 }, 0
  %t54 = sext i32 %t50 to i64
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t54)
  %t56 = add i64 %t52, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t51, i64 %t52)
  %t58 = getelementptr i8, ptr %t57, i64 %t52
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t54)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l19, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t71 = extractvalue { i64, ptr } { i64 35, ptr @.d326 }, 1
  %t72 = extractvalue { i64, ptr } { i64 35, ptr @.d326 }, 0
  %t74 = sext i32 %t70 to i64
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t74)
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 14, ptr @.d327 }, 1
  %t78 = extractvalue { i64, ptr } { i64 14, ptr @.d327 }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  %t82 = call i64 @__olang_fmt_i64(ptr %t81, i64 %t74)
  %t83 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t83, ptr %t77, i64 %t78)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t80, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t95 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t69, { i64, ptr } %t92)
  store { i64, ptr } %t95, ptr %l24
  br label %bb5
bb5:
  %t96 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t103 = load ptr, ptr %l16, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t103, { i64, ptr } { i64 3, ptr @.d328 }, { i64, ptr } %t104, { i64, ptr } %t102, { i64, ptr } { i64 0, ptr @.d329 })
  br label %bb6
bb6:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l26, !tbaa !29
  br i1 %a2, label %bb7, label %bb8
bb7:
  %t109 = load i32, ptr %l1, !tbaa !23
  %t110 = extractvalue { i64, ptr } { i64 3, ptr @.d330 }, 1
  %t111 = extractvalue { i64, ptr } { i64 3, ptr @.d330 }, 0
  %t113 = sext i32 %t109 to i64
  %t114 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t115 = add i64 %t111, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t110, i64 %t111)
  %t117 = getelementptr i8, ptr %t116, i64 %t111
  %t118 = call i64 @__olang_fmt_i64(ptr %t117, i64 %t113)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } %t120, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l28, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 4, ptr @.d331 }, ptr %l28, !tbaa !27
  br label %bb9
bb9:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l1, !tbaa !23
  %t131 = extractvalue { i64, ptr } { i64 35, ptr @.d332 }, 1
  %t132 = extractvalue { i64, ptr } { i64 35, ptr @.d332 }, 0
  %t134 = sext i32 %t130 to i64
  %t135 = call i64 @__olang_fmt_i64(ptr null, i64 %t134)
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 14, ptr @.d333 }, 1
  %t138 = extractvalue { i64, ptr } { i64 14, ptr @.d333 }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t134)
  %t143 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t143, ptr %t137, i64 %t138)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t140, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t129, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l36
  br label %bb10
bb10:
  %t156 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l26, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t163, { i64, ptr } { i64 3, ptr @.d334 }, { i64, ptr } %t164, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr @.d335 })
  br label %bb11
bb11:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l1, !tbaa !23
  %t168 = extractvalue { i64, ptr } { i64 2, ptr @.d336 }, 1
  %t169 = extractvalue { i64, ptr } { i64 2, ptr @.d336 }, 0
  %t171 = sext i32 %t167 to i64
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t171)
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = getelementptr i8, ptr %t174, i64 %t169
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t166, { i64, ptr } { i64 3, ptr @.d337 }, { i64, ptr } %t185, { i64, ptr } { i64 19, ptr @.d338 }, { i64, ptr } { i64 0, ptr @.d339 })
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/emit:Emitter", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = load i1, ptr %l23, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l9 = alloca i1
  %l18 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } { i64 2, ptr @.d340 })
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:fnEm", ptr %t5, i32 0, i32 5
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 18
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr @.d341 })
  store i1 %t16, ptr %l9
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/emit:fnEm", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 18
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t26)
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:fnEm", ptr %t29, i32 0, i32 17
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 5, ptr @.d342 }, ptr %l21, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s2, { i64, ptr } %t36, { i64, ptr } %t39)
  store i1 %t40, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i1, ptr %l22, !tbaa !21
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l18, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %t43, i32 0, i32 5
  store ptr %t45, ptr %l24, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %s3, ptr %t46)
  store { i64, ptr } %t48, ptr %l26
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } %t55)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/emit:fnEm", ptr %t58, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t60, i8 10)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2edbgTail(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 18, ptr @.d343 }, 1
  %t3 = extractvalue { i64, ptr } { i64 18, ptr @.d343 }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 72, ptr @.d344 }, 1
  %t8 = extractvalue { i64, ptr } { i64 72, ptr @.d344 }, 0
  %t9 = add i64 %t6, %t8
  %t10 = extractvalue { i64, ptr } { i64 44, ptr @.d345 }, 1
  %t11 = extractvalue { i64, ptr } { i64 44, ptr @.d345 }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t2, i64 %t3)
  %t14 = getelementptr i8, ptr %t13, i64 %t3
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a0)
  %t16 = getelementptr i8, ptr %t14, i64 %t5
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t13, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2efnTypeOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"std/prelude/text:StringBuilder"
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l58 = alloca i1
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l69 = alloca i1
  %l74 = alloca i1
  %l75 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr @.d346 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l13
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l14, !tbaa !27
  store i64 %t9, ptr %l15, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = icmp sge i64 8, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp sle i64 8, %t16
  br i1 %t17, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e82d0ac416d48216_324114d396543a52)
  unreachable
bb7:
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e82d0ac416d48216_324114d396543a52)
  unreachable
bb9:
  %t23 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = getelementptr i8, ptr %t24, i64 8
  %t27 = sub i64 %t25, 8
  %t28 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr @.d347 })
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l24
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb12, label %ok.37
ok.37:
  store i64 %t34, ptr %l23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e82d0ac416d48216_324114d396543a52)
  unreachable
bb11:
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l21, !tbaa !24
  br label %bb14
bb14:
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  %t47 = add i64 %t43, 1
  store i64 %t47, ptr %l29, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = sub i64 %t50, 2
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load i64, ptr %l29, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l29, !tbaa !24
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_22732ff0c0400a73_b2dcb14ed3e7aa4f)
  unreachable
bb17:
  %t62 = load i64, ptr %l32, !tbaa !24
  %t63 = load i64, ptr %l33, !tbaa !24
  %t64 = icmp sle i64 %t62, %t63
  br i1 %t64, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_22732ff0c0400a73_b2dcb14ed3e7aa4f)
  unreachable
bb19:
  %t66 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l29, !tbaa !24
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = getelementptr i8, ptr %t67, i64 %t68
  %t71 = sub i64 %t69, %t68
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l4, !tbaa !27
  %t75 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t75, ptr %l38
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_22732ff0c0400a73_b2dcb14ed3e7aa4f)
  unreachable
bb21:
  %t76 = load %"std/prelude/text:StringBuilder", ptr %l38
  store %"std/prelude/text:StringBuilder" %t76, ptr %l5
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = extractvalue { i64, ptr } { i64 2, ptr @.d348 }, 1
  %t82 = extractvalue { i64, ptr } { i64 2, ptr @.d348 }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = getelementptr i8, ptr %t84, i64 %t80
  call void @olang_textcopy(ptr %t85, ptr %t81, i64 %t82)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t94)
  br label %bb22
bb22:
  store i64 0, ptr %l6, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l7, !tbaa !24
  store i1 true, ptr %l8, !tbaa !21
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t101 = load i64, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb25:
  br label %bb26
bb26:
  %t109 = load i64, ptr %l6, !tbaa !24
  store i64 %t109, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t111 = load i64, ptr %l6, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  br i1 %t115, label %bb28, label %bb29
bb28:
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t117, ptr %l54, !tbaa !27
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i8, ptr %t121, i64 %t118
  %t123 = load i8, ptr %t122, !tbaa !32
  %t125 = icmp eq i8 %t123, 32
  br i1 %t125, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb42
bb30:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = add i64 %t127, 1
  %t130 = load i64, ptr %l7, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  store i1 %t133, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l58, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t136, ptr %l64, !tbaa !27
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = add i64 %t137, 1
  %t141 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i8, ptr %t142, i64 %t139
  %t144 = load i8, ptr %t143, !tbaa !32
  %t146 = icmp eq i8 %t144, 37
  store i1 %t146, ptr %l63, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb35
bb35:
  %t148 = load i1, ptr %l63, !tbaa !21
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t151 = add i64 %t149, 2
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = icmp sge i64 %t151, %t152
  br i1 %t155, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb41
bb38:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb40
bb39:
  %t157 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t157, ptr %l75, !tbaa !27
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t158, 2
  %t162 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i8, ptr %t163, i64 %t160
  %t165 = load i8, ptr %t164, !tbaa !32
  %t167 = icmp ne i8 %t165, 34
  store i1 %t167, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t169 = load i1, ptr %l74, !tbaa !21
  store i1 %t169, ptr %l69, !tbaa !21
  br label %bb41
bb41:
  %t170 = load i1, ptr %l69, !tbaa !21
  %t171 = xor i1 %t170, true
  store i1 %t171, ptr %l53, !tbaa !21
  br label %bb42
bb42:
  %t173 = load i1, ptr %l53, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t176 = load i64, ptr %l6, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb46:
  br label %bb27
bb47:
  %t180 = load i1, ptr %l8, !tbaa !21
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 2, ptr @.d349 })
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb51:
  store i1 false, ptr %l8, !tbaa !21
  store ptr %l5, ptr %l87, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t185, ptr %l88, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  store i64 %t186, ptr %l89, !tbaa !24
  %t187 = load i64, ptr %l6, !tbaa !24
  store i64 %t187, ptr %l90, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l91, !tbaa !24
  %t190 = load i64, ptr %l89, !tbaa !24
  %t191 = icmp sge i64 %t190, 0
  br i1 %t191, label %bb52, label %bb53
bb52:
  %t193 = load i64, ptr %l89, !tbaa !24
  %t194 = load i64, ptr %l90, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8ee0ebce1ce81198_5305d4c1c6657a64)
  unreachable
bb54:
  %t197 = load i64, ptr %l90, !tbaa !24
  %t198 = load i64, ptr %l91, !tbaa !24
  %t199 = icmp sle i64 %t197, %t198
  br i1 %t199, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_8ee0ebce1ce81198_5305d4c1c6657a64)
  unreachable
bb56:
  %t201 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l89, !tbaa !24
  %t204 = load i64, ptr %l90, !tbaa !24
  %t205 = getelementptr i8, ptr %t202, i64 %t203
  %t206 = sub i64 %t204, %t203
  %t207 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t205, 1
  %t209 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t209, { i64, ptr } %t208)
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_8ee0ebce1ce81198_5305d4c1c6657a64)
  unreachable
bb58:
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s5
  %t211 = load i64, ptr %l6, !tbaa !24
  %t212 = load i64, ptr %l7, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  br i1 %t215, label %bb60, label %bb61
bb60:
  %t217 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t217, ptr %l100, !tbaa !27
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i8, ptr %t221, i64 %t218
  %t223 = load i8, ptr %t222, !tbaa !32
  %t225 = icmp ne i8 %t223, 44
  store i1 %t225, ptr %l99, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb62
bb62:
  %t227 = load i1, ptr %l99, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t230 = load i64, ptr %l6, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb66
bb66:
  br label %bb59
bb67:
  %t234 = load i64, ptr %l6, !tbaa !24
  %t236 = add i64 %t234, 2
  store i64 %t236, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb68:
  br label %bb23
bb69:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 1, ptr @.d350 })
  br label %bb70
bb70:
  %t240 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l5)
  store { i64, ptr } %t240, ptr %l111
  br label %bb71
bb71:
  %t241 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t241, ptr %l112, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l113, !tbaa !24
  %t244 = load i64, ptr %l113, !tbaa !24
  %t245 = mul i64 %t244, 1
  %t246 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t245)
  %t247 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  store { i64, ptr } %t248, ptr %l114, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = load i64, ptr %l113, !tbaa !24
  %t254 = mul i64 %t253, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t250, ptr %t252, i64 %t254, i1 false)
  %t255 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t255, ptr %l112, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t256 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t256, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2emathExact_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathExactTable(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr @G_2ecompiler_2femit_2emathExact
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2eprefixOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t57)
  store i1 %t59, ptr %l36
  br label %bb11
bb11:
  %t60 = load i1, ptr %l36, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l38, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = icmp sge i64 0, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = icmp sle i64 0, %t67
  br i1 %t68, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2)
  unreachable
bb16:
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2)
  unreachable
bb18:
  %t74 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l38, !tbaa !24
  %t77 = getelementptr i8, ptr %t75, i64 0
  %t78 = sub i64 %t76, 0
  %t79 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb7
bb22:
  %t92 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = extractvalue { i64, ptr } %t92, 0
  %t96 = extractvalue { i64, ptr } { i64 1, ptr @.d351 }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr @.d351 }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t94, i64 %t95)
  %t100 = getelementptr i8, ptr %t99, i64 %t95
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l50 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i1
  %l114 = alloca { i64, ptr }
  %l118 = alloca i1
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l8
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb94
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l4, !tbaa !22
  %t26 = load i8, ptr %l4, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  %t34 = load i8, ptr %l4, !tbaa !22
  %t36 = icmp eq i8 %t34, 59
  br i1 %t36, label %bb17, label %bb18
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t52 = icmp ne i8 %t50, 34
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l25, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb92
bb17:
  br label %bb19
bb18:
  %t65 = load i8, ptr %l4, !tbaa !22
  %t67 = icmp eq i8 %t65, 37
  br i1 %t67, label %bb28, label %bb29
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 %t76
  %t81 = load i8, ptr %t80, !tbaa !32
  %t83 = icmp ne i8 %t81, 10
  store i1 %t83, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l40, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb26
bb26:
  br label %bb19
bb27:
  br label %bb91
bb28:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  %t95 = load i64, ptr %l2, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  store i1 %t98, ptr %l50, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l50, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t101, ptr %l56, !tbaa !27
  %t102 = load i64, ptr %l3, !tbaa !24
  %t104 = add i64 %t102, 1
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t104
  %t109 = load i8, ptr %t108, !tbaa !32
  %t111 = icmp eq i8 %t109, 34
  store i1 %t111, ptr %l55, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb33
bb33:
  %t113 = load i1, ptr %l55, !tbaa !21
  br i1 %t113, label %bb34, label %bb35
bb34:
  %t114 = load i64, ptr %l3, !tbaa !24
  %t116 = add i64 %t114, 2
  store i64 %t116, ptr %l5, !tbaa !24
  %t118 = load i64, ptr %l5, !tbaa !24
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb36
bb35:
  %t120 = load i8, ptr %l4, !tbaa !22
  %t122 = icmp eq i8 %t120, 64
  br i1 %t122, label %bb48, label %bb49
bb36:
  store %olang.scope zeroinitializer, ptr %s9
  %t124 = load i64, ptr %l3, !tbaa !24
  %t125 = load i64, ptr %l2, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  br i1 %t128, label %bb37, label %bb38
bb37:
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l68, !tbaa !27
  %t131 = load i64, ptr %l3, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i8, ptr %t134, i64 %t131
  %t136 = load i8, ptr %t135, !tbaa !32
  %t138 = icmp ne i8 %t136, 34
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l67, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t143 = load i64, ptr %l3, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb43:
  br label %bb36
bb44:
  %t147 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t147, i64 1)
  br label %bb45
bb45:
  %t149 = load ptr, ptr %lp1
  %t150 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t149, i64 %t150)
  br label %bb46
bb46:
  %t153 = load ptr, ptr %lp1
  %t154 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t153, i64 %t154)
  br label %bb47
bb47:
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l3, !tbaa !24
  br label %bb90
bb48:
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l6, !tbaa !24
  %t165 = load i64, ptr %l6, !tbaa !24
  store i64 %t165, ptr %l3, !tbaa !24
  br label %bb50
bb49:
  %t167 = load i8, ptr %l4, !tbaa !22
  %t169 = icmp eq i8 %t167, 33
  br i1 %t169, label %bb66, label %bb67
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t171 = load i64, ptr %l3, !tbaa !24
  %t172 = load i64, ptr %l2, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t177, ptr %l91, !tbaa !27
  %t178 = load i64, ptr %l3, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i8, ptr %t181, i64 %t178
  %t183 = load i8, ptr %t182, !tbaa !32
  %t185 = call i1 @compiler_2femit_2esymbolChar(i8 %t183)
  store i1 %t185, ptr %l94
  br label %bb53
bb52:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb54
bb53:
  %t186 = load i1, ptr %l94, !tbaa !21
  store i1 %t186, ptr %l90, !tbaa !21
  br label %bb54
bb54:
  %t187 = load i1, ptr %l90, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t190 = load i64, ptr %l3, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb58
bb58:
  br label %bb50
bb59:
  %t194 = load i64, ptr %l3, !tbaa !24
  %t195 = load i64, ptr %l6, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb60, label %bb61
bb60:
  %t200 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t200, i64 0)
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t202 = load ptr, ptr %lp1
  %t203 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t202, i64 %t203)
  br label %bb63
bb63:
  %t206 = load ptr, ptr %lp1
  %t207 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t206, i64 %t207)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb89
bb66:
  %t210 = load i64, ptr %l3, !tbaa !24
  %t212 = add i64 %t210, 1
  %t213 = load i64, ptr %l2, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  store i1 %t216, ptr %l108, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb68
bb68:
  %t218 = load i1, ptr %l108, !tbaa !21
  br i1 %t218, label %bb69, label %bb70
bb69:
  %t219 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t219, ptr %l114, !tbaa !27
  %t220 = load i64, ptr %l3, !tbaa !24
  %t222 = add i64 %t220, 1
  %t224 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i8, ptr %t225, i64 %t222
  %t227 = load i8, ptr %t226, !tbaa !32
  %t229 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t227)
  store i1 %t229, ptr %l118
  br label %bb71
bb70:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb72
bb71:
  %t230 = load i1, ptr %l118, !tbaa !21
  store i1 %t230, ptr %l113, !tbaa !21
  br label %bb72
bb72:
  %t231 = load i1, ptr %l113, !tbaa !21
  br i1 %t231, label %bb73, label %bb74
bb73:
  %t232 = load i64, ptr %l3, !tbaa !24
  store i64 %t232, ptr %l7, !tbaa !24
  %t234 = load i64, ptr %l3, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l3, !tbaa !24
  br label %bb75
bb74:
  %t238 = load i64, ptr %l3, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l3, !tbaa !24
  br label %bb88
bb75:
  store %olang.scope zeroinitializer, ptr %s16
  %t242 = load i64, ptr %l3, !tbaa !24
  %t243 = load i64, ptr %l2, !tbaa !24
  %t246 = icmp slt i64 %t242, %t243
  br i1 %t246, label %bb76, label %bb77
bb76:
  %t248 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t248, ptr %l126, !tbaa !27
  %t249 = load i64, ptr %l3, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i8, ptr %t252, i64 %t249
  %t254 = load i8, ptr %t253, !tbaa !32
  %t256 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t254)
  store i1 %t256, ptr %l129
  br label %bb78
bb77:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb79
bb78:
  %t257 = load i1, ptr %l129, !tbaa !21
  store i1 %t257, ptr %l125, !tbaa !21
  br label %bb79
bb79:
  %t258 = load i1, ptr %l125, !tbaa !21
  %t259 = xor i1 %t258, true
  br i1 %t259, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb84
bb81:
  br label %bb82
bb82:
  %t261 = load i64, ptr %l3, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb83
bb83:
  br label %bb75
bb84:
  %t265 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t265, i64 2)
  br label %bb85
bb85:
  %t267 = load ptr, ptr %lp1
  %t268 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t267, i64 %t268)
  br label %bb86
bb86:
  %t271 = load ptr, ptr %lp1
  %t272 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t271, i64 %t272)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s1)
  br label %bb93
bb93:
  br label %bb2
bb94:
  %t275 = load ptr, ptr %lp1
  %t276 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t275
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t276, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca i1
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca i1
  %l67 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca i1
  %l69 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l100 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"compiler/emit:Emitter"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  store ptr %a1, ptr %l5, !tbaa !29
  store ptr %a2, ptr %l6, !tbaa !29
  store ptr %a3, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d352 }, ptr %l11, !tbaa !27
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l76
  br label %bb1
bb1:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l12
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l77
  br label %bb2
bb2:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l13
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %t15)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l78
  br label %bb3
bb3:
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l14
  store i64 -1, ptr %l15, !tbaa !24
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l79
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l16
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %t21)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l80
  br label %bb5
bb5:
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l17
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l81
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l18
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l82
  br label %bb7
bb7:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l19
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l83
  br label %bb8
bb8:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l20
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l84
  br label %bb9
bb9:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l21
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t36)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l85
  br label %bb10
bb10:
  %t38 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l22
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l86
  br label %bb11
bb11:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l23
  store { i64, ptr } { i64 19, ptr @.d353 }, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  store i1 false, ptr %l26, !tbaa !21
  store i64 0, ptr %l27, !tbaa !24
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %t42)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l87
  br label %bb12
bb12:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l28
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l88
  br label %bb13
bb13:
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l29
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t48)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l89
  br label %bb14
bb14:
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l30
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l90
  br label %bb15
bb15:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l31
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l91
  br label %bb16
bb16:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l32
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l92
  br label %bb17
bb17:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l33
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t60)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l93
  br label %bb18
bb18:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l34
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t63)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l94
  br label %bb19
bb19:
  %t65 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l35
  %t66 = load ptr, ptr @__olang_prog_scope
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %t66)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l95
  br label %bb20
bb20:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l36
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %t69)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l96
  br label %bb21
bb21:
  %t71 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l37
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t72)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l97
  br label %bb22
bb22:
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l38
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %t75)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l98
  br label %bb23
bb23:
  %t77 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l39
  store i1 false, ptr %l40, !tbaa !21
  store i1 false, ptr %l41, !tbaa !21
  store i64 4611686018427387904, ptr %l42, !tbaa !24
  %t78 = load i64, ptr @G_2ecompiler_2femit_2ePartSize, !tbaa !24
  store i64 %t78, ptr %l43, !tbaa !24
  store i1 false, ptr %l44, !tbaa !21
  %t80 = load ptr, ptr @__olang_prog_scope
  %t81 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t80)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l100
  br label %bb24
bb24:
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l45
  %t83 = load ptr, ptr @__olang_prog_scope
  %t84 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t83)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l101
  br label %bb25
bb25:
  %t85 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l46
  %t86 = load ptr, ptr @__olang_prog_scope
  %t87 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %t86)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l102
  br label %bb26
bb26:
  %t88 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l47
  store { i64, ptr } { i64 6, ptr @.d354 }, ptr %l48, !tbaa !27
  store i1 false, ptr %l49, !tbaa !21
  store i1 false, ptr %l50, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d355 }, ptr %l51, !tbaa !27
  store i1 false, ptr %l52, !tbaa !21
  store i64 1000, ptr %l53, !tbaa !24
  store i64 -1, ptr %l54, !tbaa !24
  store i64 -1, ptr %l55, !tbaa !24
  store i64 -1, ptr %l56, !tbaa !24
  %t89 = load ptr, ptr @__olang_prog_scope
  %t90 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t89)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l103
  br label %bb27
bb27:
  %t91 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l57
  %t92 = load ptr, ptr @__olang_prog_scope
  %t93 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t92)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l104
  br label %bb28
bb28:
  %t94 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l58
  %t95 = load ptr, ptr @__olang_prog_scope
  %t96 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t95)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l105
  br label %bb29
bb29:
  %t97 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l59
  %t98 = load ptr, ptr @__olang_prog_scope
  %t99 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t98)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l106
  br label %bb30
bb30:
  %t100 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l60
  %t101 = load ptr, ptr @__olang_prog_scope
  %t102 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t101)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l107
  br label %bb31
bb31:
  %t103 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l61
  store i1 false, ptr %l62, !tbaa !21
  %t104 = load ptr, ptr @__olang_prog_scope
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %t104)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l108
  br label %bb32
bb32:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l63
  %t107 = load ptr, ptr @__olang_prog_scope
  %t108 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t107)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l109
  br label %bb33
bb33:
  %t109 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %l64
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %t110)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l110
  br label %bb34
bb34:
  %t112 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %l65
  store i1 false, ptr %l66, !tbaa !21
  %t113 = load ptr, ptr @__olang_prog_scope
  %t114 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t113)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %l111
  br label %bb35
bb35:
  %t115 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l67
  store i1 false, ptr %l68, !tbaa !21
  %t116 = load ptr, ptr @__olang_prog_scope
  %t117 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t116)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l112
  br label %bb36
bb36:
  %t118 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l69
  %t119 = load ptr, ptr @__olang_prog_scope
  %t120 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t119)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %l113
  br label %bb37
bb37:
  %t121 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %l70
  %t122 = load ptr, ptr @__olang_prog_scope
  %t123 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t122)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l114
  br label %bb38
bb38:
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  %t125 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 0
  %t126 = load ptr, ptr %l4, !tbaa !29
  store ptr %t126, ptr %t125, !tbaa !29
  %t127 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 1
  %t128 = load ptr, ptr %l5, !tbaa !29
  store ptr %t128, ptr %t127, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 2
  %t130 = load ptr, ptr %l6, !tbaa !29
  store ptr %t130, ptr %t129, !tbaa !29
  %t131 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 3
  %t132 = load ptr, ptr %l7, !tbaa !29
  store ptr %t132, ptr %t131, !tbaa !29
  %t133 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 4
  %t134 = load i1, ptr %l8, !tbaa !21
  store i1 %t134, ptr %t133, !tbaa !21
  %t135 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 5
  %t136 = load i1, ptr %l9, !tbaa !21
  store i1 %t136, ptr %t135, !tbaa !21
  %t137 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 6
  %t138 = load i1, ptr %l10, !tbaa !21
  store i1 %t138, ptr %t137, !tbaa !21
  %t139 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 7
  %t140 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t140, ptr %t139, !tbaa !27
  %t141 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 8
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 9
  %t144 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 10
  %t146 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 11
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 12
  %t150 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %t149
  %t151 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 13
  %t152 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t151
  %t153 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 14
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t153
  %t155 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 15
  %t156 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %t155
  %t157 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 16
  %t158 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %t157
  %t159 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 17
  %t160 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t160, ptr %t159
  %t161 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 18
  %t162 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %t161
  %t163 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 19
  %t164 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t163
  %t165 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 20
  %t166 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t166, ptr %t165, !tbaa !27
  %t167 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 21
  %t168 = load i64, ptr %l25, !tbaa !24
  store i64 %t168, ptr %t167, !tbaa !24
  %t169 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 22
  %t170 = load i1, ptr %l26, !tbaa !21
  store i1 %t170, ptr %t169, !tbaa !21
  %t171 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 23
  %t172 = load i64, ptr %l27, !tbaa !24
  store i64 %t172, ptr %t171, !tbaa !24
  %t173 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 24
  %t174 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t173
  %t175 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 25
  %t176 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %t175
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 26
  %t178 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %t177
  %t179 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 27
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %t179
  %t181 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 28
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %t181
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 29
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t183
  %t185 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 30
  %t186 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %t185
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 31
  %t188 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %t187
  %t189 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 32
  %t190 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t190, ptr %t189
  %t191 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 33
  %t192 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %t191
  %t193 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 34
  %t194 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t193
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 35
  %t196 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %t195
  %t197 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 36
  %t198 = load i1, ptr %l40, !tbaa !21
  store i1 %t198, ptr %t197, !tbaa !21
  %t199 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 37
  %t200 = load i1, ptr %l41, !tbaa !21
  store i1 %t200, ptr %t199, !tbaa !21
  %t201 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 38
  %t202 = load i64, ptr %l42, !tbaa !24
  store i64 %t202, ptr %t201, !tbaa !24
  %t203 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 39
  %t204 = load i64, ptr %l43, !tbaa !24
  store i64 %t204, ptr %t203, !tbaa !24
  %t205 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 40
  %t206 = load i1, ptr %l44, !tbaa !21
  store i1 %t206, ptr %t205, !tbaa !21
  %t207 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 41
  %t208 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %t207
  %t209 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 42
  %t210 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %t209
  %t211 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 43
  %t212 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %t211
  %t213 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 44
  %t214 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t214, ptr %t213, !tbaa !27
  %t215 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 45
  %t216 = load i1, ptr %l49, !tbaa !21
  store i1 %t216, ptr %t215, !tbaa !21
  %t217 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 46
  %t218 = load i1, ptr %l50, !tbaa !21
  store i1 %t218, ptr %t217, !tbaa !21
  %t219 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 47
  %t220 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t220, ptr %t219, !tbaa !27
  %t221 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 48
  %t222 = load i1, ptr %l52, !tbaa !21
  store i1 %t222, ptr %t221, !tbaa !21
  %t223 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 49
  %t224 = load i64, ptr %l53, !tbaa !24
  store i64 %t224, ptr %t223, !tbaa !24
  %t225 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 50
  %t226 = load i64, ptr %l54, !tbaa !24
  store i64 %t226, ptr %t225, !tbaa !24
  %t227 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 51
  %t228 = load i64, ptr %l55, !tbaa !24
  store i64 %t228, ptr %t227, !tbaa !24
  %t229 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 52
  %t230 = load i64, ptr %l56, !tbaa !24
  store i64 %t230, ptr %t229, !tbaa !24
  %t231 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 53
  %t232 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %t231
  %t233 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 54
  %t234 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t233
  %t235 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 55
  %t236 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %t235
  %t237 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 56
  %t238 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %t237
  %t239 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 57
  %t240 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %t239
  %t241 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 58
  %t242 = load i1, ptr %l62, !tbaa !21
  store i1 %t242, ptr %t241, !tbaa !21
  %t243 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 59
  %t244 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %t243
  %t245 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 60
  %t246 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t246, ptr %t245
  %t247 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 61
  %t248 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %t247
  %t249 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 62
  %t250 = load i1, ptr %l66, !tbaa !21
  store i1 %t250, ptr %t249, !tbaa !21
  %t251 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 63
  %t252 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %t251
  %t253 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 64
  %t254 = load i1, ptr %l68, !tbaa !21
  store i1 %t254, ptr %t253, !tbaa !21
  %t255 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 65
  %t256 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %t255
  %t257 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 66
  %t258 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %t257
  %t259 = getelementptr %"compiler/emit:Emitter", ptr %l115, i32 0, i32 67
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t259
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l115, i64 544, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i1
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/emit:Reused"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l13
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = insertvalue %"compiler/emit:Reused" undef, i64 %t15, 0
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t18 = insertvalue %"compiler/emit:Reused" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 1
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t20 = insertvalue %"compiler/emit:Reused" %t18, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 2
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t22 = insertvalue %"compiler/emit:Reused" %t20, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 3
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = insertvalue %"compiler/emit:Reused" %t22, i64 %t23, 4
  %t25 = load i1, ptr %l6, !tbaa !21
  %t26 = insertvalue %"compiler/emit:Reused" %t24, i1 %t25, 5
  %t28 = insertvalue %"compiler/emit:Reused" %t26, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, 6
  %t30 = insertvalue %"compiler/emit:Reused" %t28, i64 -1, 7
  store %"compiler/emit:Reused" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:Reused", ptr %rv
  ret %"compiler/emit:Reused" %rr
}

@.d0 = private constant [40 x i8] c"attributes #0 = { null_pointer_is_valid "
@.d1 = private constant [3 x i8] c" }\0A"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant [8 x i8] c"ptr, ptr"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant [3 x i8] c"ptr"
@.d4 = private constant [0 x i8] c""
@.d5 = private constant [1 x i8] c" "
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [10 x i8] c"ptr byval("
@.d8 = private constant [8 x i8] c") align "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d9 = private constant [3 x i8] c"ptr"
declare void @__olang_check_failed(ptr)
@.d10 = private constant [1 x i8] c"."
@.d11 = private constant [19 x i8] c"!DIFile(filename: \22"
@.d12 = private constant [15 x i8] c"\22, directory: \22"
@.d13 = private constant [2 x i8] c"\22)"
@.d14 = private constant [66 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)"
@.d15 = private constant [4 x i8] c"void"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d16 = private constant [7 x i8] c"declare"
@.d17 = private constant [8 x i8] c"declare "
@.d18 = private constant [7 x i8] c"define "
@.d19 = private constant [1 x i8] c" "
@.d20 = private constant [2 x i8] c" @"
@.d21 = private constant [1 x i8] c"("
@.d22 = private constant [8 x i8] c"ptr %env"
@.d23 = private constant [2 x i8] c", "
@.d24 = private constant [8 x i8] c"ptr %out"
@.d25 = private constant [2 x i8] c", "
@.d26 = private constant [6 x i8] c"ptr %v"
@.d27 = private constant [2 x i8] c", "
@.d28 = private constant [6 x i8] c"ptr %a"
@.d29 = private constant [6 x i8] c"ptr %a"
@.d30 = private constant [9 x i8] c"c, ptr %a"
@.d31 = private constant [1 x i8] c"e"
@.d32 = private constant [3 x i8] c" %a"
@.d33 = private constant [7 x i8] c"declare"
@.d34 = private constant [2 x i8] c")\0A"
@.d35 = private constant [7 x i8] c") #0 {\0A"
@.d36 = private constant [1 x i8] c"f"
@.d37 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d38 = private constant [0 x i8] c""
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [2 x i8] c"32"
@.d41 = private constant [2 x i8] c"64"
@.d42 = private constant [5 x i8] c"llvm."
@.d43 = private constant [2 x i8] c".f"
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [21 x i8] c"__olang_scope_alloc_a"
@.d46 = private constant [36 x i8] c"call ptr @__olang_scope_alloc_a(ptr "
@.d47 = private constant [6 x i8] c", i64 "
@.d48 = private constant [6 x i8] c", i64 "
@.d49 = private constant [1 x i8] c")"
@.d50 = private constant [0 x i8] c""
@.d51 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d52 = private constant [3 x i8] c", 1"
@.d53 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d54 = private constant [3 x i8] c", 0"
@.d55 = private constant [29 x i8] c"  %big = alloca %olang.scope\0A"
@.d56 = private constant [47 x i8] c"  store %olang.scope zeroinitializer, ptr %big\0A"
@.d57 = private constant [21 x i8] c"__olang_scope_alloc_a"
@.d58 = private constant [19 x i8] c"__olang_scope_close"
@.d59 = private constant [0 x i8] c""
@.d60 = private constant [0 x i8] c""
@.d61 = private constant [9 x i8] c"ptr sret("
@.d62 = private constant [8 x i8] c") align "
@.d63 = private constant [1 x i8] c" "
@.d64 = private constant [2 x i8] c", "
@.d65 = private constant [0 x i8] c""
@.d66 = private constant [1 x i8] c" "
@.d67 = private constant [0 x i8] c""
@.d68 = private constant [1 x i8] c" "
@.d69 = private constant [1 x i8] c"["
@.d70 = private constant [6 x i8] c" x i8]"
@.d71 = private constant [0 x i8] c""
@.d72 = private constant [2 x i8] c", "
@.d73 = private constant [14 x i8] c" alignstack(8)"
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [22 x i8] c"getelementptr i8, ptr "
@.d76 = private constant [6 x i8] c", i64 "
@.d77 = private constant [0 x i8] c""
@.d78 = private constant [1 x i8] c" "
@.d79 = private constant [0 x i8] c""
@.d80 = private constant [10 x i8] c"ptr byval("
@.d81 = private constant [8 x i8] c") align "
@.d82 = private constant [1 x i8] c" "
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [4 x i8] c"ptr "
@.d85 = private constant [0 x i8] c""
@.d86 = private constant [0 x i8] c""
@.d87 = private constant [4 x i8] c"void"
@.d88 = private constant [10 x i8] c"call void "
@.d89 = private constant [1 x i8] c"("
@.d90 = private constant [1 x i8] c")"
@.d91 = private constant [5 x i8] c"call "
@.d92 = private constant [1 x i8] c" "
@.d93 = private constant [1 x i8] c"("
@.d94 = private constant [1 x i8] c")"
@.d95 = private constant [11 x i8] c"unreachable"
@.d96 = private constant [0 x i8] c""
@.d97 = private constant [1 x i8] c"["
@.d98 = private constant [6 x i8] c" x i8]"
@.d99 = private constant [13 x i8] c"extractvalue "
@.d100 = private constant [1 x i8] c" "
@.d101 = private constant [2 x i8] c", "
@.d102 = private constant [22 x i8] c"getelementptr i8, ptr "
@.d103 = private constant [6 x i8] c", i64 "
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [10 x i8] c"br label %"
@.d106 = private constant [4 x i8] c"null"
@.d107 = private constant [2 x i8] c"{ "
@.d108 = private constant [2 x i8] c", "
@.d109 = private constant [5 x i8] c", ptr"
@.d110 = private constant [2 x i8] c" }"
@.d111 = private constant [14 x i8] c"getelementptr "
@.d112 = private constant [17 x i8] c", ptr null, i32 1"
@.d113 = private constant [13 x i8] c"ptrtoint ptr "
@.d114 = private constant [7 x i8] c" to i64"
@.d115 = private constant [14 x i8] c"getelementptr "
@.d116 = private constant [6 x i8] c", ptr "
@.d117 = private constant [13 x i8] c", i32 0, i32 "
@.d118 = private constant [11 x i8] c", !tbaa !28"
@.d119 = private constant [4 x i8] c"null"
@.d120 = private constant [4 x i8] c"null"
@.d121 = private constant [20 x i8] c"__olang_scope_escape"
@.d122 = private constant [36 x i8] c"call void @__olang_scope_escape(ptr "
@.d123 = private constant [1 x i8] c")"
@.d124 = private constant [14 x i8] c"getelementptr "
@.d125 = private constant [6 x i8] c", ptr "
@.d126 = private constant [13 x i8] c", i32 0, i32 "
@.d127 = private constant [3 x i8] c"ptr"
@.d128 = private constant [11 x i8] c", !tbaa !28"
@.d129 = private constant [37 x i8] c"insertvalue { ptr, ptr } undef, ptr @"
@.d130 = private constant [3 x i8] c", 0"
@.d131 = private constant [25 x i8] c"insertvalue { ptr, ptr } "
@.d132 = private constant [6 x i8] c", ptr "
@.d133 = private constant [3 x i8] c", 1"
@.d134 = private constant [1 x i8] c"["
@.d135 = private constant [6 x i8] c" x i8]"
@.d136 = private constant [2 x i8] c"c\22"
@.d137 = private constant [1 x i8] c"\22"
@.d138 = private constant [2 x i8] c", "
@.d139 = private constant [1 x i8] c" "
@.d140 = private constant [1 x i8] c"["
@.d141 = private constant [3 x i8] c" x "
@.d142 = private constant [1 x i8] c"]"
@.d143 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d144 = private constant [3 x i8] c", 0"
@.d145 = private constant [26 x i8] c"extractvalue { i64, ptr } "
@.d146 = private constant [3 x i8] c", 1"
@.d147 = private constant [8 x i8] c"mul i64 "
@.d148 = private constant [2 x i8] c", "
@.d149 = private constant [19 x i8] c"__olang_scope_alloc"
@.d150 = private constant [34 x i8] c"call ptr @__olang_scope_alloc(ptr "
@.d151 = private constant [6 x i8] c", i64 "
@.d152 = private constant [1 x i8] c")"
@.d153 = private constant [21 x i8] c"llvm.memcpy.p0.p0.i64"
@.d154 = private constant [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)"
@.d155 = private constant [37 x i8] c"call void @llvm.memcpy.p0.p0.i64(ptr "
@.d156 = private constant [6 x i8] c", ptr "
@.d157 = private constant [6 x i8] c", i64 "
@.d158 = private constant [11 x i8] c", i1 false)"
@.d159 = private constant [0 x i8] c""
@.d160 = private constant [1 x i8] c"!"
@.d161 = private constant [21 x i8] c" = !DILocation(line: "
@.d162 = private constant [21 x i8] c", column: 1, scope: !"
@.d163 = private constant [2 x i8] c")\0A"
@.d164 = private constant [8 x i8] c", !dbg !"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aOperand(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l8 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb16
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb16
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Place" }, ptr %t11, i32 0, i32 0
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t15 = getelementptr { %"compiler/mir:Place" }, ptr %t14, i32 0, i32 0
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aPlace(ptr %t12, ptr %t15)
  store i1 %t18, ptr %l8
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t21 = getelementptr { i32, i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  %t25 = getelementptr { i32, i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t29 = icmp eq i32 %t22, %t26
  br i1 %t29, label %bb9, label %bb1
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t33 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t37 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t41 = icmp eq i32 %t34, %t38
  br i1 %t41, label %bb11, label %bb1
bb7:
  %t43 = load i1, ptr %l8, !tbaa !21
  br i1 %t43, label %bb8, label %bb1
bb8:
  br label %bb3
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t46 = getelementptr { i32, i64 }, ptr %t45, i32 0, i32 1
  %t47 = load i64, ptr %t46
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i32, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t54 = icmp eq i64 %t47, %t51
  br i1 %t54, label %bb10, label %bb1
bb10:
  br label %bb3
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  %t66 = icmp eq i32 %t59, %t63
  br i1 %t66, label %bb12, label %bb1
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t69, i32 0, i32 2
  %t71 = load i64, ptr %t70
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t73, i32 0, i32 2
  %t75 = load i64, ptr %t74
  %t78 = icmp eq i64 %t71, %t75
  br i1 %t78, label %bb13, label %bb1
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t81, i32 0, i32 3
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t85 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t84, i32 0, i32 3
  %t88 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %t82, ptr %t85)
  store i1 %t88, ptr %l26
  br label %bb14
bb14:
  %t89 = load i1, ptr %l26, !tbaa !21
  br i1 %t89, label %bb15, label %bb1
bb15:
  br label %bb3
bb16:
  %t90 = load i1, ptr %l2, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d165 = private constant [4 x i8] c"fill"
@.d166 = private constant [4 x i8] c"fill"
@.d167 = private constant [4 x i8] c"fill"
@.d168 = private constant [4 x i8] c"fill"
@.d169 = private constant [10 x i8] c"br label %"
@.d170 = private constant [10 x i8] c"br label %"
@.d171 = private constant [17 x i8] c" = phi i64 [ 0, %"
@.d172 = private constant [6 x i8] c" ], [ "
@.d173 = private constant [3 x i8] c", %"
@.d174 = private constant [2 x i8] c" ]"
@.d175 = private constant [13 x i8] c"icmp slt i64 "
@.d176 = private constant [2 x i8] c", "
@.d177 = private constant [6 x i8] c"br i1 "
@.d178 = private constant [9 x i8] c", label %"
@.d179 = private constant [9 x i8] c", label %"
@.d180 = private constant [14 x i8] c"getelementptr "
@.d181 = private constant [6 x i8] c", ptr "
@.d182 = private constant [13 x i8] c", i64 0, i64 "
@.d183 = private constant [0 x i8] c""
@.d184 = private constant [11 x i8] c" = add i64 "
@.d185 = private constant [3 x i8] c", 1"
@.d186 = private constant [10 x i8] c"br label %"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d187 = private constant [14 x i8] c"getelementptr "
@.d188 = private constant [6 x i8] c", ptr "
@.d189 = private constant [13 x i8] c", i64 0, i64 "
@.d190 = private constant [0 x i8] c""
@.d191 = private constant [22 x i8] c"llvm.memmove.p0.p0.i64"
@.d192 = private constant [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)"
@.d193 = private constant [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr "
@.d194 = private constant [6 x i8] c", ptr "
@.d195 = private constant [6 x i8] c", i64 "
@.d196 = private constant [11 x i8] c", i1 false)"
@.d197 = private constant [0 x i8] c""
@.d198 = private constant [3 x i8] c" = "
@.d199 = private constant [0 x i8] c""
@.d200 = private constant [18 x i8] c"llvm.memset.p0.i64"
@.d201 = private constant [42 x i8] c"void @llvm.memset.p0.i64(ptr, i8, i64, i1)"
@.d202 = private constant [34 x i8] c"call void @llvm.memset.p0.i64(ptr "
@.d203 = private constant [12 x i8] c", i8 0, i64 "
@.d204 = private constant [11 x i8] c", i1 false)"
@.d205 = private constant [12 x i8] c"{ i64, ptr }"
@.d206 = private constant [5 x i8] c"  %lp"
@.d207 = private constant [14 x i8] c" = alloca ptr\0A"
@.d208 = private constant [34 x i8] c"a parameter or capture in an arena"
@.d209 = private constant [4 x i8] c"  %l"
@.d210 = private constant [10 x i8] c" = alloca "
@.d211 = private constant [1 x i8] c"\0A"
@.d212 = private constant [4 x i8] c"  %l"
@.d213 = private constant [49 x i8] c" = call ptr @__olang_scope_alloc_a(ptr %big, i64 "
@.d214 = private constant [6 x i8] c", i64 "
@.d215 = private constant [2 x i8] c")\0A"
@.d216 = private constant [4 x i8] c"  %s"
@.d217 = private constant [29 x i8] c" = alloca %olang.builder\0A  %s"
@.d218 = private constant [33 x i8] c"room = alloca [64 x i8], align 8\0A"
@.d219 = private constant [4 x i8] c"  %s"
@.d220 = private constant [23 x i8] c" = alloca %olang.scope\0A"
@.d221 = private constant [5 x i8] c"  %jh"
@.d222 = private constant [14 x i8] c" = alloca ptr\0A"
@.d223 = private constant [4 x i8] c"  %u"
@.d224 = private constant [24 x i8] c" = alloca %olang.unwind\0A"
@.d225 = private constant [4 x i8] c"void"
@.d226 = private constant [15 x i8] c"  %rv = alloca "
@.d227 = private constant [1 x i8] c"\0A"
@.d228 = private constant [29 x i8] c"a parameter homed in an arena"
@.d229 = private constant [22 x i8] c"llvm.memmove.p0.p0.i64"
@.d230 = private constant [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)"
@.d231 = private constant [42 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr %l"
@.d232 = private constant [8 x i8] c", ptr %a"
@.d233 = private constant [6 x i8] c", i64 "
@.d234 = private constant [12 x i8] c", i1 false)\0A"
@.d235 = private constant [5 x i8] c"  %pf"
@.d236 = private constant [41 x i8] c" = insertvalue { ptr, ptr } undef, ptr %a"
@.d237 = private constant [5 x i8] c"c, 0\0A"
@.d238 = private constant [5 x i8] c"  %pg"
@.d239 = private constant [31 x i8] c" = insertvalue { ptr, ptr } %pf"
@.d240 = private constant [8 x i8] c", ptr %a"
@.d241 = private constant [5 x i8] c"e, 1\0A"
@.d242 = private constant [24 x i8] c"  store { ptr, ptr } %pg"
@.d243 = private constant [8 x i8] c", ptr %l"
@.d244 = private constant [1 x i8] c"\0A"
@.d245 = private constant [8 x i8] c"  store "
@.d246 = private constant [3 x i8] c" %a"
@.d247 = private constant [8 x i8] c", ptr %l"
@.d248 = private constant [1 x i8] c"\0A"
@.d249 = private constant [5 x i8] c"start"
@.d250 = private constant [2 x i8] c"%l"
@.d251 = private constant [12 x i8] c"{ i64, ptr }"
@.d252 = private constant [0 x i8] c""
@.d253 = private constant [4 x i8] c"%big"
@.d254 = private constant [2 x i8] c"%l"
@.d255 = private constant [12 x i8] c"{ i64, ptr }"
@.d256 = private constant [0 x i8] c""
@.d257 = private constant [13 x i8] c"br label %bb0"
@.d258 = private constant [27 x i8] c"a capture homed in an arena"
@.d259 = private constant [5 x i8] c"  %cp"
@.d260 = private constant [17 x i8] c" = getelementptr "
@.d261 = private constant [23 x i8] c", ptr %env, i32 0, i32 "
@.d262 = private constant [1 x i8] c"\0A"
@.d263 = private constant [22 x i8] c"llvm.memmove.p0.p0.i64"
@.d264 = private constant [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)"
@.d265 = private constant [5 x i8] c"  %cv"
@.d266 = private constant [8 x i8] c" = load "
@.d267 = private constant [9 x i8] c", ptr %cp"
@.d268 = private constant [12 x i8] c", !tbaa !28\0A"
@.d269 = private constant [42 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr %l"
@.d270 = private constant [9 x i8] c", ptr %cp"
@.d271 = private constant [6 x i8] c", i64 "
@.d272 = private constant [12 x i8] c", i1 false)\0A"
@.d273 = private constant [8 x i8] c"  store "
@.d274 = private constant [4 x i8] c" %cv"
@.d275 = private constant [8 x i8] c", ptr %l"
@.d276 = private constant [1 x i8] c"\0A"
@.d277 = private constant [21 x i8] c"__olang_capture_scope"
@.d278 = private constant [5 x i8] c"  %vq"
@.d279 = private constant [17 x i8] c" = getelementptr "
@.d280 = private constant [23 x i8] c", ptr %env, i32 0, i32 "
@.d281 = private constant [1 x i8] c"\0A"
@.d282 = private constant [5 x i8] c"  %vr"
@.d283 = private constant [20 x i8] c" = load ptr, ptr %vq"
@.d284 = private constant [12 x i8] c", !tbaa !28\0A"
@.d285 = private constant [5 x i8] c"  %vc"
@.d286 = private constant [42 x i8] c" = call ptr @__olang_capture_scope(ptr %vr"
@.d287 = private constant [1 x i8] c")"
@.d288 = private constant [1 x i8] c"\0A"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d289 = private constant [17 x i8] c"__olang_ert_clear"
@.d290 = private constant [30 x i8] c"call void @__olang_ert_clear()"
@.d291 = private constant [3 x i8] c"ret"
@.d292 = private constant [40 x i8] c"call void @__olang_scope_close(ptr %big)"
@.d293 = private constant [4 x i8] c"void"
@.d294 = private constant [11 x i8] c"%rr = load "
@.d295 = private constant [9 x i8] c", ptr %rv"
@.d296 = private constant [8 x i8] c"ret void"
@.d297 = private constant [4 x i8] c"ret "
@.d298 = private constant [4 x i8] c" %rr"
@.d299 = private constant [0 x i8] c""
@.d300 = private constant [6 x i8] c"store "
@.d301 = private constant [1 x i8] c" "
@.d302 = private constant [6 x i8] c", ptr "
@.d303 = private constant [2 x i8] c"%t"
@.d304 = private constant [16 x i8] c"try passed it on"
@.d305 = private constant [40 x i8] c"a task failed, and its join passed it on"
@.d306 = private constant [11 x i8] c"raised here"
@.d307 = private constant [16 x i8] c"__olang_ert_pass"
@.d308 = private constant [17 x i8] c"__olang_ert_raise"
@.d309 = private constant [6 x i8] c"void @"
@.d310 = private constant [5 x i8] c"(ptr)"
@.d311 = private constant [2 x i8] c": "
@.d312 = private constant [1 x i8] c"\0A"
@.d313 = private constant [11 x i8] c"call void @"
@.d314 = private constant [5 x i8] c"(ptr "
@.d315 = private constant [1 x i8] c")"
@.d316 = private constant [18 x i8] c"__olang_unwind_top"
@.d317 = private constant [67 x i8] c"@__olang_unwind_top = external thread_local(initialexec) global ptr"
@.d318 = private constant [3 x i8] c"ptr"
@.d319 = private constant [19 x i8] c"@__olang_unwind_top"
@.d320 = private constant [0 x i8] c""
@.d321 = private constant [35 x i8] c"getelementptr %olang.unwind, ptr %u"
@.d322 = private constant [14 x i8] c", i32 0, i32 0"
@.d323 = private constant [3 x i8] c"ptr"
@.d324 = private constant [0 x i8] c""
@.d325 = private constant [2 x i8] c"%s"
@.d326 = private constant [35 x i8] c"getelementptr %olang.unwind, ptr %u"
@.d327 = private constant [14 x i8] c", i32 0, i32 1"
@.d328 = private constant [3 x i8] c"ptr"
@.d329 = private constant [0 x i8] c""
@.d330 = private constant [3 x i8] c"%jh"
@.d331 = private constant [4 x i8] c"null"
@.d332 = private constant [35 x i8] c"getelementptr %olang.unwind, ptr %u"
@.d333 = private constant [14 x i8] c", i32 0, i32 2"
@.d334 = private constant [3 x i8] c"ptr"
@.d335 = private constant [0 x i8] c""
@.d336 = private constant [2 x i8] c"%u"
@.d337 = private constant [3 x i8] c"ptr"
@.d338 = private constant [19 x i8] c"@__olang_unwind_top"
@.d339 = private constant [0 x i8] c""
@.d340 = private constant [2 x i8] c"  "
@.d341 = private constant [0 x i8] c""
@.d342 = private constant [5 x i8] c"call "
@.d343 = private constant [18 x i8] c"!llvm.dbg.cu = !{!"
@.d344 = private constant [72 x i8] c"}\0A!llvm.module.flags = !{!1, !2}\0A!1 = !{i32 7, !\22Dwarf Version\22, i32 4}\0A"
@.d345 = private constant [44 x i8] c"!2 = !{i32 2, !\22Debug Info Version\22, i32 3}\0A"
@.d346 = private constant [2 x i8] c" @"
@.d347 = private constant [1 x i8] c"("
@.d348 = private constant [2 x i8] c" ("
@.d349 = private constant [2 x i8] c", "
@.d350 = private constant [1 x i8] c")"
@.d351 = private constant [1 x i8] c"."
@.d352 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d353 = private constant [19 x i8] c"x86_64-pc-linux-gnu"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d354 = private constant [6 x i8] c"x86_64"
@.d355 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aPlace(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Place", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/mir:Place", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Place", ptr %t9, i32 0, i32 1
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Place", ptr %t11, i32 0, i32 1
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %t10, ptr %t12)
  store i1 %t15, ptr %l8
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb1
bb5:
  br label %bb6
bb6:
  %t17 = load i1, ptr %l2, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb6, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i32, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb7, label %bb1
bb6:
  br label %bb3
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32, i32 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb8, label %bb1
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  %t56 = icmp eq i32 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/mir:Range", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Range", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2femit_2etbaaTree = external constant <{ [8 x i8], ptr }>
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2854570d7fadf599_61afc1034d008305 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_8ec8751bbb52a5fd_3161bca6b1c44ba9 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
@olang_loc_d8b0748be4d5a5b9_c527c32a89be493d = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5ad0f5036011b2cd_7d6f5911e17dc851 = external constant [0 x i8]
@olang_loc_aa3eb0efeafaca9c_7799b263c8155fc0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eb6d9c3809493fd7_39d95642e792ba3b = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_32ecc2f0b2e54909_486ad1b7ea10ca75 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_616c6f643d0ce9fd_dfe523617d4699c1 = external constant [0 x i8]
@olang_loc_b37ed008d0080fcc_cc9019489ebc5a30 = external constant [0 x i8]
@olang_loc_e68028fa4f0f457e_ac0c180900ac4e62 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathExact = external constant <{ ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8b9f7f38fd25c7fb_28bbaeaad75485df = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_d06aa239b7550a75_e0c8a30cfe0955c1 = external constant [0 x i8]
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, { i64, ptr } %a4)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_11f14fa65e4040d5_e8173accb9b141e1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c1b63f01de4704cb_7c986704c53dd4e7 = external constant [0 x i8]
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_abf674e0f035191f_fe40c9b44f4d0b8b = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeFor(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4c53df269225a815_e91774848fc42cb1 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare i8 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_617f1f302e56ab61_28fb076f83c3eed5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_abe6dc85fcec15d0_e43a59b757d9d4e4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e9e71ccb75095175_3df52a9a91674c89 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
@olang_loc_9357034ceffa49e9_ad514f9345461395 = external constant [0 x i8]
@olang_loc_1dffb4089bad5318_6447f84abd9ba4a4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eLen_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0)
@olang_loc_3b6348629663638e_4d98396f767ecbfa = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeRef_3e_2eRunF_Hfdafd2704446aebe706e7a16d9caf3c2(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f4a19adfa2908824_f7d19e69dc606aa8 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7398c824c6ccd25f_37644bbf4fe2ca83 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5718aedbda8f05de_73125ecff2351902 = external constant [0 x i8]
@olang_loc_c174e5a3b34e67b9_6250aa572b15a6d5 = external constant [0 x i8]
@olang_loc_9206c849bcce77e8_1d8ffc9eff2b8ce4 = external constant [0 x i8]
@olang_loc_5234ed07c88e8ec3_fc55cf91bd0a7f1f = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eRunFrom_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_163846ebfcde4742_93f6cefa6f5e149e = external constant [0 x i8]
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eapart(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, %"compiler/mir:Range" %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/mir:Range" %a3)
@olang_loc_1c84b7c0e51a2751_bb90751f2238f075 = external constant [0 x i8]
@olang_loc_d7426df353af1cf1_5409353fb5c530e5 = external constant [0 x i8]
@olang_loc_34175b6f59aa64d9_d8857486e5aa61ad = external constant [0 x i8]
@olang_loc_3a52453b80be52d1_6c5ca24620edcd6d = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b58edc65c6718b49_26c0578031dccca5 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindDirect(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fad0caecc364ec25_9c3ddefd20d373f1 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewritesInto(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eenvType(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBlockId_3e_2eRunFrom_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_273e839fc85d1f4_991991d173f6efe0 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eLe_H69361f3f24d6e754874d1471050918da(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_H3656f0f1de1a3ab6ee8c423316b96ef3(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3a1aa3acd228b12f_45ca77ec12fd04db = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eterm(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edata(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_37dcdc821423a995_2a435c3b360fb831 = external constant [0 x i8]
@olang_loc_2ea555a1037c9329_7e95fb4c4c24cb65 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_bf62c1c7e423c058_299389d9c8f1c434 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eGet_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_e82d0ac416d48216_324114d396543a52 = external constant [0 x i8]
@olang_loc_22732ff0c0400a73_b2dcb14ed3e7aa4f = external constant [0 x i8]
@olang_loc_8ee0ebce1ce81198_5305d4c1c6657a64 = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathExactTable(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_1e1ac9afcf25b4a6_b14a079dd13715c2 = external constant [0 x i8]
declare i1 @compiler_2femit_2esymbolChar(i8 %a0)
@G_2ecompiler_2femit_2ePartSize = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
