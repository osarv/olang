; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_772c54764e337a02_1b08b3073a69a3ee = weak_odr constant [46 x i8] c"std/chan.olang:62: array length out of range\0A\00"
@olang_loc_f51c3b74f2d4a8af_eaf8dafb70d5bb93 = weak_odr constant [46 x i8] c"std/chan.olang:62: array length out of range\0A\00"
