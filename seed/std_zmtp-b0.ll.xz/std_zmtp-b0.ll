; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/zmtp:Socket" = type { %"std/net:Conn", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1 }
%"std/net:Conn" = type { i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local { i32, %"std/zmtp:Socket" } @std_2fzmtp_2eSocket_2eAccept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca %"std/net:Conn"
  %l6 = alloca %"std/net:Conn"
  %l7 = alloca i32
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca %"std/zmtp:Socket"
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca %"std/zmtp:Socket"
  %l24 = alloca %"std/zmtp:Socket"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/zmtp:Socket" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, %"std/net:Conn" } @std_2fnet_2estd_2fnet_3aListener_2eAccept(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, %"std/net:Conn" } %t3, 1
  %t5 = extractvalue { i32, %"std/net:Conn" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/net:Conn" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/net:Conn", ptr %l6
  store %"std/net:Conn" %t8, ptr %l4
  br label %bb3
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, %"std/zmtp:Socket" } zeroinitializer, i32 %t17, 0
  store { i32, %"std/zmtp:Socket" } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_hold(ptr %s0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l9, !tbaa !24
  %t22 = load i1, ptr @olang_2esole_2estd_2fzmtp_3aSocket_2e1
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = call ptr @__olang_region_make_part(ptr %s0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t28 = extractvalue { i64, ptr } %a1, 1
  %t29 = extractvalue { i64, ptr } %a1, 0
  %t30 = load i64, ptr %l9
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l12, !tbaa !27
  %t35 = load i1, ptr @olang_2esole_2estd_2fzmtp_3aSocket_2e1
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp eq i64 %t38, 0
  br i1 %t40, label %bb8, label %bb9
bb7:
  %t42 = load %"std/net:Conn", ptr %l4
  %t43 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t44 = call %"std/zmtp:Socket" @std_2fzmtp_3aSocket_2ector(ptr %v2, %"std/net:Conn" %t42, { i64, ptr } %t43)
  store %"std/zmtp:Socket" %t44, ptr %l16
  br label %bb10
bb8:
  store { i64, ptr } zeroinitializer, ptr %l12, !tbaa !27
  br label %bb9
bb9:
  %t45 = load i64, ptr %l9
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = load { i64, ptr }, ptr %l12
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = call ptr @__olang_region_or(ptr %t48, ptr null)
  %t50 = icmp ne ptr %t49, null
  %t51 = select i1 %t50, ptr %t49, ptr null
  call void @__olang_region_settle_in(ptr %t46, ptr %t51)
  br label %bb7
bb10:
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t52, ptr %lp2
  %t53 = load %"std/zmtp:Socket", ptr %l16
  %t54 = load ptr, ptr %lp2
  store %"std/zmtp:Socket" %t53, ptr %t54
  store i1 true, ptr %l3, !tbaa !21
  %t55 = load ptr, ptr %lp2
  %t57 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2ehello(ptr %v2, ptr %t55, i1 true)
  store i32 %t57, ptr %l18
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb12, label %ok.59, !prof !99
ok.59:
  br label %bb11
bb11:
  br label %bb16
bb12:
  %t60 = load i32, ptr %l18, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %l19, !tbaa !23
  %t69 = load i1, ptr %l3, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load ptr, ptr %lp2
  call void @__olang_scope_register_dtor(ptr %v2, ptr %t71, ptr @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket_rt)
  store i1 false, ptr %l3, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i32, ptr %l19, !tbaa !23
  %t74 = insertvalue { i32, %"std/zmtp:Socket" } zeroinitializer, i32 %t73, 0
  store { i32, %"std/zmtp:Socket" } %t74, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %l3, !tbaa !21
  %t75 = load ptr, ptr %lp2
  %t76 = load %"std/zmtp:Socket", ptr %t75
  store %"std/zmtp:Socket" %t76, ptr %l22
  %t78 = call %"std/zmtp:Socket" @olang_2emir_2eHelperKind_2eCopy_2estd_2fzmtp_3aSocket(ptr %v2, ptr %l22)
  store %"std/zmtp:Socket" %t78, ptr %l24
  br label %bb17
bb17:
  %t79 = load %"std/zmtp:Socket", ptr %l24
  store %"std/zmtp:Socket" %t79, ptr %l22
  %t80 = load i1, ptr %l3, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t82 = load ptr, ptr %lp2
  call void @__olang_scope_register_dtor(ptr %v2, ptr %t82, ptr @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket_rt)
  store i1 false, ptr %l3, !tbaa !21
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"std/zmtp:Socket", ptr %l22
  %t85 = insertvalue { i32, %"std/zmtp:Socket" } zeroinitializer, %"std/zmtp:Socket" %t84, 1
  store { i32, %"std/zmtp:Socket" } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/zmtp:Socket" }, ptr %rv
  ret { i32, %"std/zmtp:Socket" } %rr
}

define dso_local { i32, %"std/zmtp:Socket" } @std_2fzmtp_2eSocket_2eDial(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca %"std/net:Conn"
  %l6 = alloca %"std/net:Conn"
  %l7 = alloca i32
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca %"std/zmtp:Socket"
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca %"std/zmtp:Socket"
  %l24 = alloca %"std/zmtp:Socket"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/zmtp:Socket" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, %"std/net:Conn" } @std_2fnet_2eConn_2eDial(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, %"std/net:Conn" } %t3, 1
  %t5 = extractvalue { i32, %"std/net:Conn" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/net:Conn" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/net:Conn", ptr %l6
  store %"std/net:Conn" %t8, ptr %l4
  br label %bb3
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, %"std/zmtp:Socket" } zeroinitializer, i32 %t17, 0
  store { i32, %"std/zmtp:Socket" } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_hold(ptr %s0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l9, !tbaa !24
  %t22 = load i1, ptr @olang_2esole_2estd_2fzmtp_3aSocket_2e1
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = call ptr @__olang_region_make_part(ptr %s0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t28 = extractvalue { i64, ptr } %a1, 1
  %t29 = extractvalue { i64, ptr } %a1, 0
  %t30 = load i64, ptr %l9
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l12, !tbaa !27
  %t35 = load i1, ptr @olang_2esole_2estd_2fzmtp_3aSocket_2e1
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp eq i64 %t38, 0
  br i1 %t40, label %bb8, label %bb9
bb7:
  %t42 = load %"std/net:Conn", ptr %l4
  %t43 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t44 = call %"std/zmtp:Socket" @std_2fzmtp_3aSocket_2ector(ptr %v2, %"std/net:Conn" %t42, { i64, ptr } %t43)
  store %"std/zmtp:Socket" %t44, ptr %l16
  br label %bb10
bb8:
  store { i64, ptr } zeroinitializer, ptr %l12, !tbaa !27
  br label %bb9
bb9:
  %t45 = load i64, ptr %l9
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = load { i64, ptr }, ptr %l12
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = call ptr @__olang_region_or(ptr %t48, ptr null)
  %t50 = icmp ne ptr %t49, null
  %t51 = select i1 %t50, ptr %t49, ptr null
  call void @__olang_region_settle_in(ptr %t46, ptr %t51)
  br label %bb7
bb10:
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t52, ptr %lp2
  %t53 = load %"std/zmtp:Socket", ptr %l16
  %t54 = load ptr, ptr %lp2
  store %"std/zmtp:Socket" %t53, ptr %t54
  store i1 true, ptr %l3, !tbaa !21
  %t55 = load ptr, ptr %lp2
  %t57 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2ehello(ptr %v2, ptr %t55, i1 false)
  store i32 %t57, ptr %l18
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb12, label %ok.59, !prof !99
ok.59:
  br label %bb11
bb11:
  br label %bb16
bb12:
  %t60 = load i32, ptr %l18, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %l19, !tbaa !23
  %t69 = load i1, ptr %l3, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load ptr, ptr %lp2
  call void @__olang_scope_register_dtor(ptr %v2, ptr %t71, ptr @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket_rt)
  store i1 false, ptr %l3, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i32, ptr %l19, !tbaa !23
  %t74 = insertvalue { i32, %"std/zmtp:Socket" } zeroinitializer, i32 %t73, 0
  store { i32, %"std/zmtp:Socket" } %t74, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %l3, !tbaa !21
  %t75 = load ptr, ptr %lp2
  %t76 = load %"std/zmtp:Socket", ptr %t75
  store %"std/zmtp:Socket" %t76, ptr %l22
  %t78 = call %"std/zmtp:Socket" @olang_2emir_2eHelperKind_2eCopy_2estd_2fzmtp_3aSocket(ptr %v2, ptr %l22)
  store %"std/zmtp:Socket" %t78, ptr %l24
  br label %bb17
bb17:
  %t79 = load %"std/zmtp:Socket", ptr %l24
  store %"std/zmtp:Socket" %t79, ptr %l22
  %t80 = load i1, ptr %l3, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t82 = load ptr, ptr %lp2
  call void @__olang_scope_register_dtor(ptr %v2, ptr %t82, ptr @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket_rt)
  store i1 false, ptr %l3, !tbaa !21
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"std/zmtp:Socket", ptr %l22
  %t85 = insertvalue { i32, %"std/zmtp:Socket" } zeroinitializer, %"std/zmtp:Socket" %t84, 1
  store { i32, %"std/zmtp:Socket" } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/zmtp:Socket" }, ptr %rv
  ret { i32, %"std/zmtp:Socket" } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fzmtp_2estd_2fzmtp_3aSocket_2eNext(ptr %v0, ptr %v1, ptr noalias dereferenceable(72) align 8 %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, i64 }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l11 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i64
  %l49 = alloca [4 x i8]
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l55 = alloca ptr
  %l61 = alloca { i64, i64 }
  %l70 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/zmtp:Socket", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/zmtp:Socket", ptr %t8, i32 0, i32 2
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l11
  br label %bb4
bb3:
  br label %bb34
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/zmtp:Socket", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t19 = sub i64 %t17, %t16
  %t21 = icmp slt i64 %t19, 64
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/zmtp:Socket", ptr %t25, i32 0, i32 2
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t27)
  store { i64, ptr } %t29, ptr %l19
  br label %bb8
bb8:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"std/zmtp:Socket", ptr %t31, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/zmtp:Socket", ptr %t35, i32 0, i32 3
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = add i64 %t38, 64
  store i64 %t40, ptr %l25, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l26, !tbaa !24
  %t43 = load i64, ptr %l22, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load i64, ptr %l22, !tbaa !24
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ae9a882ac7c9c3e7_127a36597258840b)
  unreachable
bb11:
  %t50 = load i64, ptr %l25, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = icmp sle i64 %t50, %t51
  br i1 %t52, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ae9a882ac7c9c3e7_127a36597258840b)
  unreachable
bb13:
  %t54 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = load i64, ptr %l25, !tbaa !24
  %t58 = getelementptr i8, ptr %t55, i64 %t56
  store ptr %t58, ptr %l1
  %t60 = load ptr, ptr %l1
  %t62 = getelementptr [64 x i8], ptr %t60, i64 0, i64 0
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp ne i8 %t63, -1
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_ae9a882ac7c9c3e7_127a36597258840b)
  unreachable
bb15:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  %t67 = load ptr, ptr %l1
  %t69 = getelementptr [64 x i8], ptr %t67, i64 0, i64 9
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = icmp ne i8 %t70, 127
  store i1 %t72, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l34, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb19:
  %t75 = load ptr, ptr %l1
  %t77 = getelementptr [64 x i8], ptr %t75, i64 0, i64 10
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp ult i8 %t78, 3
  store i1 %t80, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l38, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb30
bb22:
  %t83 = load ptr, ptr %l1
  store ptr %t83, ptr %l43
  %t84 = load ptr, ptr %l43
  %t85 = load [64 x i8], ptr %t84
  store i64 64, ptr %l44, !tbaa !24
  %t86 = icmp sge i64 12, 0
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t88 = icmp sle i64 12, 16
  br i1 %t88, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ce6aff91bca6310a_8709f628085e380e)
  unreachable
bb25:
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = icmp sle i64 16, %t90
  br i1 %t91, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ce6aff91bca6310a_8709f628085e380e)
  unreachable
bb27:
  %t93 = load ptr, ptr %l43
  %t94 = getelementptr i8, ptr %t93, i64 12
  %t96 = load [4 x i8], ptr %t94
  store [4 x i8] %t96, ptr %l49
  %t97 = mul i64 4, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 4, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l50, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = mul i64 4, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %l49, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t106, ptr %l52
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ce6aff91bca6310a_8709f628085e380e)
  unreachable
bb29:
  %t107 = load i1, ptr %l52, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l42, !tbaa !21
  br label %bb30
bb30:
  %t110 = load i1, ptr %l42, !tbaa !21
  br i1 %t110, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t112 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 131072, 0
  store { i32, { i64, ptr } } %t112, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l55, !tbaa !29
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t115 = getelementptr %"std/zmtp:Socket", ptr %t114, i32 0, i32 3
  %t116 = load i64, ptr %t115, !tbaa !24
  %t119 = add i64 %t116, 64
  %t121 = load ptr, ptr %l55, !tbaa !29
  %t122 = getelementptr %"std/zmtp:Socket", ptr %t121, i32 0, i32 3
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/zmtp:Socket", ptr %t123, i32 0, i32 4
  store i1 true, ptr %t125, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call { i64, i64 } @std_2fzmtp_2estd_2fzmtp_3aSocket_2ewhole(ptr %v0, ptr %t126)
  store { i64, i64 } %t128, ptr %l61
  br label %bb35
bb35:
  %t129 = load { i64, i64 }, ptr %l61
  store { i64, i64 } %t129, ptr %l2
  %t130 = getelementptr { i64, i64 }, ptr %l2, i32 0, i32 0
  %t131 = load i64, ptr %t130, !tbaa !24
  store i64 %t131, ptr %l3, !tbaa !24
  %t133 = getelementptr { i64, i64 }, ptr %l2, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  store i64 %t134, ptr %l4, !tbaa !24
  %t136 = load i64, ptr %l4, !tbaa !24
  %t138 = icmp slt i64 %t136, 0
  br i1 %t138, label %bb36, label %bb37
bb36:
  %t141 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t141, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l3, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  %t148 = call { i64, ptr } @std_2fzmtp_2estd_2fzmtp_3aSocket_2eframes(ptr %v0, ptr %v1, ptr %t142, i64 %t143, i64 %t144)
  store { i64, ptr } %t148, ptr %l70
  br label %bb39
bb39:
  %t149 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t149, ptr %l5, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l3, !tbaa !24
  %t154 = getelementptr %"std/zmtp:Socket", ptr %t150, i32 0, i32 3
  store i64 %t151, ptr %t154, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = icmp sgt i64 %t157, 0
  br i1 %t159, label %bb40, label %bb41
bb40:
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t163 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t161, 1
  store { i32, { i64, ptr } } %t163, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb1
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2fzmtp_2estd_2fzmtp_3aSocket_2eframes(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i1
  %l82 = alloca { i64, ptr }
  %l92 = alloca i64
  %l95 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l18, !tbaa !24
  %t2 = load i64, ptr %l18, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l18, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4bbdaade106d973e_8ca98eac508a18fa)
  unreachable
bb3:
  %t8 = load i64, ptr %l18, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"std/zmtp:Socket", ptr %t14, i32 0, i32 2
  %t18 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t16)
  store { i64, ptr } %t18, ptr %l24
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4bbdaade106d973e_8ca98eac508a18fa)
  unreachable
bb5:
  %t19 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/zmtp:Socket", ptr %t20, i32 0, i32 3
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %a1
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb34
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l31, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t34
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = and i8 %t39, 2
  %t43 = icmp ne i8 %t41, 0
  store i1 %t43, ptr %l7, !tbaa !21
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l36, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t46
  %t51 = load i8, ptr %t50, !tbaa !32
  %t53 = and i8 %t51, 4
  %t55 = icmp ne i8 %t53, 0
  store i1 %t55, ptr %l8, !tbaa !21
  %t57 = load i1, ptr %l7, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  store i64 9, ptr %l42, !tbaa !24
  br label %bb12
bb11:
  store i64 2, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i1, ptr %l7, !tbaa !21
  %t66 = call i64 @std_2fzmtp_2esizeAt(ptr %v0, { i64, ptr } %t60, i64 %t61, i1 %t62)
  store i64 %t66, ptr %l46
  br label %bb13
bb13:
  %t67 = load i64, ptr %l46, !tbaa !24
  store i64 %t67, ptr %l10, !tbaa !24
  %t68 = load i1, ptr %l8, !tbaa !21
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l49, !tbaa !24
  %t73 = load i64, ptr %l49, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t81, ptr %lp11
  %t83 = load ptr, ptr %lp11
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  store i64 %t84, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t86 = load i64, ptr %l13, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_237751653b136673_36a383b697e3f04f)
  unreachable
bb18:
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb23
bb20:
  %t96 = load i64, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l14, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l14, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l59, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t112 = load i64, ptr %l59, !tbaa !24
  store i64 %t112, ptr %l56, !tbaa !24
  br label %bb23
bb23:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t114 = load i64, ptr %l15, !tbaa !24
  %t115 = sub i64 %t114, 1
  store i64 %t115, ptr %l68, !tbaa !24
  %t116 = load i64, ptr %l15, !tbaa !24
  %t117 = icmp slt i64 %t116, 2147483648
  %t118 = load i64, ptr %l16, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  %t122 = and i1 %t117, %t119
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb24
bb24:
  %t123 = load i64, ptr %l16, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t131 = load i64, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l16, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l17, !tbaa !24
  %t141 = load i64, ptr %l17, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t143 = load i64, ptr %l5, !tbaa !24
  %t144 = load i64, ptr %l9, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t148 = load i64, ptr %l17, !tbaa !24
  %t151 = add i64 %t147, %t148
  %t153 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = load ptr, ptr %lp11
  %t160 = getelementptr { i64, ptr }, ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i8, ptr %t161, i64 %t141
  store i8 %t156, ptr %t162, !tbaa !32
  br label %bb28
bb28:
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb24
bb29:
  %t168 = load i64, ptr %l6, !tbaa !24
  store i64 %t168, ptr %l92, !tbaa !24
  %t169 = load ptr, ptr %lp11
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t172 = load i64, ptr %l92, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %t174, i64 %t172
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !37
  store { i64, ptr } %t176, ptr %l95, !tbaa !27
  %t178 = load i64, ptr %l92, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr { i64, ptr }, ptr %t180, i64 %t178
  store { i64, ptr } %t170, ptr %t181, !tbaa !37
  %t182 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1
  br i1 %t182, label %bb30, label %bb31
bb30:
  %t184 = load { i64, ptr }, ptr %l95
  %t185 = extractvalue { i64, ptr } %t184, 1
  call void @__olang_slot_release(ptr %t185)
  store { i64, ptr } zeroinitializer, ptr %l95
  br label %bb31
bb31:
  %t186 = load i64, ptr %l6, !tbaa !24
  %t189 = add i64 %t186, 1
  store i64 %t189, ptr %l6, !tbaa !24
  br label %bb32
bb32:
  %t191 = load i64, ptr %l5, !tbaa !24
  %t193 = load i64, ptr %l9, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t200 = add i64 %t191, %t197
  store i64 %t200, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb6
bb34:
  %t202 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, i64 } @std_2fzmtp_2estd_2fzmtp_3aSocket_2ewhole(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l39 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/zmtp:Socket", ptr %t1, i32 0, i32 2
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/zmtp:Socket", ptr %t7, i32 0, i32 3
  %t10 = load i64, ptr %t9, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = add i64 %t12, 2
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp sgt i64 %t14, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = insertvalue { i64, i64 } undef, i64 %t22, 0
  %t25 = insertvalue { i64, i64 } %t24, i64 -1, 1
  store { i64, i64 } %t25, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i8, ptr %t31, i64 %t28
  %t33 = load i8, ptr %t32, !tbaa !32
  store i8 %t33, ptr %l4, !tbaa !22
  %t35 = load i8, ptr %l4, !tbaa !22
  %t37 = and i8 %t35, 2
  %t39 = icmp ne i8 %t37, 0
  br i1 %t39, label %bb6, label %bb7
bb6:
  store i64 9, ptr %l25, !tbaa !24
  br label %bb8
bb7:
  store i64 2, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp sgt i64 %t46, %t49
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = insertvalue { i64, i64 } undef, i64 %t54, 0
  %t57 = insertvalue { i64, i64 } %t56, i64 -1, 1
  store { i64, i64 } %t57, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i8, ptr %l4, !tbaa !22
  %t63 = and i8 %t61, 2
  %t65 = icmp ne i8 %t63, 0
  %t69 = call i64 @std_2fzmtp_2esizeAt(ptr %v0, { i64, ptr } %t59, i64 %t60, i1 %t65)
  store i64 %t69, ptr %l39
  br label %bb12
bb12:
  %t70 = load i64, ptr %l39, !tbaa !24
  store i64 %t70, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t85 = icmp sgt i64 %t79, %t82
  br i1 %t85, label %bb13, label %bb14
bb13:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = insertvalue { i64, i64 } undef, i64 %t87, 0
  %t90 = insertvalue { i64, i64 } %t89, i64 -1, 1
  store { i64, i64 } %t90, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t92 = load i64, ptr %l2, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = add i64 %t94, %t95
  %t101 = add i64 %t92, %t98
  store i64 %t101, ptr %l2, !tbaa !24
  %t103 = load i8, ptr %l4, !tbaa !22
  %t105 = and i8 %t103, 4
  %t107 = icmp ne i8 %t105, 0
  br i1 %t107, label %bb16, label %bb17
bb16:
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load i64, ptr %l3, !tbaa !24
  %t112 = insertvalue { i64, i64 } undef, i64 %t109, 0
  %t114 = insertvalue { i64, i64 } %t112, i64 %t110, 1
  store { i64, i64 } %t114, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l3, !tbaa !24
  %t121 = load i8, ptr %l4, !tbaa !22
  %t123 = and i8 %t121, 1
  %t125 = icmp eq i8 %t123, 0
  br i1 %t125, label %bb19, label %bb20
bb19:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = insertvalue { i64, i64 } undef, i64 %t127, 0
  %t132 = insertvalue { i64, i64 } %t130, i64 %t128, 1
  store { i64, i64 } %t132, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb2
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fzmtp_3aSocket_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_register_dtor(ptr, ptr, ptr)
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket_rt(ptr %inst, ptr %scope) #0 {
entry:
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket(ptr %scope, ptr %inst)
  ret void
}

define linkonce_odr %"std/zmtp:Socket" @olang_2emir_2eHelperKind_2eCopy_2estd_2fzmtp_3aSocket(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/zmtp:Socket"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/zmtp:Socket"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/zmtp:Socket", ptr %a0
  store %"std/zmtp:Socket" %t2, ptr %l1
  %t3 = getelementptr %"std/zmtp:Socket", ptr %l1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/zmtp:Socket", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/zmtp:Socket", ptr %l1, i32 0, i32 2
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %t20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l6
  br label %bb1
bb1:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t24 = getelementptr %"std/zmtp:Socket", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %t24
  %t25 = load %"std/zmtp:Socket", ptr %l1
  store %"std/zmtp:Socket" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"std/zmtp:Socket", ptr %rv
  ret %"std/zmtp:Socket" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"NULL" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1 = weak hidden constant i1 false
declare void @__olang_slot_release(ptr) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fzmtp_3aSocket(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"std/zmtp:Socket", ptr %a0, i32 0, i32 0
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fnet_3aConn(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fnet_3aConn(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fnet_3aConn_2edtor(ptr %v0, ptr %a0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

declare { i32, %"std/net:Conn" } @std_2fnet_2estd_2fnet_3aListener_2eAccept(ptr %v0, ptr %a0)
declare %"std/zmtp:Socket" @std_2fzmtp_3aSocket_2ector(ptr %v0, %"std/net:Conn" %a0, { i64, ptr } %a1)
declare i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2ehello(ptr %v0, ptr %a0, i1 %a1)
declare { i32, %"std/net:Conn" } @std_2fnet_2eConn_2eDial(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ae9a882ac7c9c3e7_127a36597258840b = external constant [0 x i8]
@olang_loc_ce6aff91bca6310a_8709f628085e380e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4bbdaade106d973e_8ca98eac508a18fa = external constant [0 x i8]
declare i64 @std_2fzmtp_2esizeAt(ptr %v0, { i64, ptr } %a0, i64 %a1, i1 %a2)
@olang_loc_237751653b136673_36a383b697e3f04f = external constant [0 x i8]
declare void @std_2fnet_3aConn_2edtor(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
