; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/explain:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fsBody", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, i1, i1, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"compiler/source:Span", i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:Gap", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fsBody" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:instTree" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
define dso_local { i64, ptr } @compiler_2fexplain_2eAsValueWhere(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 3
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v1, ptr %v0, ptr %s0, ptr %t21, i64 %t22, ptr %t32)
  store { i64, ptr } %t36, ptr %l17
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l3, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb5, label %bb6
bb5:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v1, ptr %t44, i64 %t45)
  store i1 %t48, ptr %l24
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t49 = load i1, ptr %l24, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l21, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = call { i64, ptr } @std_2fprelude_2ftext_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store { i64, ptr } %t55, ptr %l27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t56 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = getelementptr i8, ptr %t66, i64 %t60
  call void @olang_textcopy(ptr %t67, ptr %t62, i64 %t63)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb12:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eGivesHeld(ptr %v1, ptr %s0, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l31
  br label %bb13
bb13:
  %t76 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t79, ptr %l33
  br label %bb14
bb14:
  %t80 = load i1, ptr %l33, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t81, ptr %l35, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l36, !tbaa !24
  %t84 = load i64, ptr %l36, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l36, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t95, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t97 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t101 = extractvalue { i64, ptr } %t97, 1
  %t102 = extractvalue { i64, ptr } %t97, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eCaps(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/effects:Facts"
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca %"compiler/effects:Facts"
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l81 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca %"compiler/effects:Facts"
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca { i64, ptr }
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca i64
  %l124 = alloca i64
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l157 = alloca i1
  %l164 = alloca i64
  %l166 = alloca i64
  %l171 = alloca i64
  %l174 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l185 = alloca %"std/prelude/text:StringBuilder"
  %l187 = alloca i64
  %l189 = alloca i64
  %l194 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i64
  %l213 = alloca i64
  %l216 = alloca i1
  %l234 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l244 = alloca i64
  %l245 = alloca { i64, ptr }
  %l247 = alloca i1
  %l249 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t31 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l40
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l40, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 10
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H6c17f05b74a2ea6689cdfc72c602a991(ptr %v0, ptr %v0, ptr %t13)
  store { i64, ptr } %t15, ptr %l45
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l47, !tbaa !24
  %t20 = call %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %s0)
  store %"compiler/effects:Facts" %t20, ptr %l48
  br label %bb3
bb3:
  %t21 = load i64, ptr %l47, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l47, !tbaa !24
  %t25 = icmp sle i64 %t24, 96076792050570581
  br i1 %t25, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_91de52063b71ca44_3ab230bc0b47a90)
  unreachable
bb6:
  %t27 = load i64, ptr %l47, !tbaa !24
  %t28 = mul i64 %t27, 96
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  %t30 = load %"compiler/effects:Facts", ptr %l48
  store i64 0, ptr %t31
  br label %fill.32
fill.32:
  %t35 = load i64, ptr %t31
  %t36 = icmp slt i64 %t35, %t27
  br i1 %t36, label %fillb.33, label %filld.34
fillb.33:
  %t37 = getelementptr %"compiler/effects:Facts", ptr %t29, i64 %t35
  store %"compiler/effects:Facts" %t30, ptr %t37
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %t31
  br label %fill.32
filld.34:
  %t39 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t29, 1
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 19
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l54
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_91de52063b71ca44_3ab230bc0b47a90)
  unreachable
bb8:
  %t47 = load i64, ptr %l54, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb14
bb11:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l61, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb13
bb13:
  %t74 = load i64, ptr %l61, !tbaa !24
  store i64 %t74, ptr %l58, !tbaa !24
  br label %bb14
bb14:
  %t75 = load i64, ptr %l58, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l9, !tbaa !24
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = call i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l81
  br label %bb19
bb19:
  %t99 = load i64, ptr %l81, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr %"compiler/effects:Facts", ptr %t107, i64 %t104
  store ptr %t108, ptr %l85, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t109, i64 %t110)
  store %"compiler/effects:Facts" %t113, ptr %l88
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t114 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2feffects_2eMerge(ptr %s0, ptr %s3, ptr %t114, ptr %l88)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l8, !tbaa !24
  br label %bb15
bb26:
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l93
  br label %bb27
bb27:
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %l11
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t123, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t137, ptr %l101, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  %t147 = getelementptr %"compiler/load:Module", ptr %t143, i32 0, i32 2
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l11, { i64, ptr } %t148)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l13, !tbaa !24
  br label %bb28
bb34:
  %t156 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %l110
  br label %bb35
bb35:
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l16
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/load:Loader", ptr %t164, i32 0, i32 12
  %t167 = load i64, ptr %t166, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l16, i64 %t167)
  br label %bb36
bb36:
  store i64 0, ptr %l17, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t174 = load i64, ptr %l18, !tbaa !24
  %t175 = load i64, ptr %l17, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb37, label %bb38
bb37:
  %t180 = load i64, ptr %l19, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb42
bb39:
  %t184 = load i64, ptr %l18, !tbaa !24
  %t185 = load i64, ptr %l17, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l19, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l19, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l124, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb41
bb41:
  %t200 = load i64, ptr %l124, !tbaa !24
  store i64 %t200, ptr %l121, !tbaa !24
  br label %bb42
bb42:
  %t201 = load i64, ptr %l121, !tbaa !24
  store i64 %t201, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  %t202 = load i64, ptr %l21, !tbaa !24
  %t203 = load i64, ptr %l20, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb44, label %bb45
bb44:
  br label %bb56
bb45:
  br label %bb46
bb46:
  %t210 = load i64, ptr %l17, !tbaa !24
  %t211 = load i64, ptr %l21, !tbaa !24
  %t212 = load i64, ptr %l19, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l22, !tbaa !24
  %t220 = load i64, ptr %l22, !tbaa !24
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/load:Loader", ptr %t227, i32 0, i32 12
  %t230 = load i64, ptr %t229, !tbaa !24
  %t233 = icmp ne i64 %t220, %t230
  br i1 %t233, label %bb47, label %bb48
bb47:
  %t235 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t235, ptr %l149, !tbaa !27
  %t236 = load i64, ptr %l22, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr ptr, ptr %t239, i64 %t236
  %t241 = load ptr, ptr %t240, !tbaa !39
  %t243 = getelementptr %"compiler/load:Module", ptr %t241, i32 0, i32 2
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t245, ptr %l153, !tbaa !27
  %t246 = load i64, ptr %l22, !tbaa !24
  %t248 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr ptr, ptr %t249, i64 %t246
  %t251 = load ptr, ptr %t250, !tbaa !39
  %t253 = getelementptr %"compiler/load:Module", ptr %t251, i32 0, i32 3
  %t254 = load i1, ptr %t253, !tbaa !21
  %t257 = call i1 @compiler_2fexplain_2ecapsShown(ptr %v0, { i64, ptr } %t244, i1 %t254)
  store i1 %t257, ptr %l157
  br label %bb49
bb48:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb50
bb49:
  %t258 = load i1, ptr %l157, !tbaa !21
  store i1 %t258, ptr %l148, !tbaa !21
  br label %bb50
bb50:
  %t259 = load i1, ptr %l148, !tbaa !21
  br i1 %t259, label %bb51, label %bb52
bb51:
  %t260 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l16, i64 %t260)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = add i64 %t263, 1
  store i64 %t266, ptr %l21, !tbaa !24
  br label %bb43
bb56:
  store i64 0, ptr %l23, !tbaa !24
  store ptr %l16, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t269 = load i64, ptr %l25, !tbaa !24
  store i64 %t269, ptr %l164, !tbaa !24
  %t270 = load ptr, ptr %l24, !tbaa !29
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t270)
  store i64 %t272, ptr %l166
  br label %bb58
bb58:
  %t273 = load i64, ptr %l164, !tbaa !24
  %t274 = load i64, ptr %l166, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb60:
  br label %bb61
bb61:
  %t279 = load ptr, ptr %l24, !tbaa !29
  %t280 = load i64, ptr %l25, !tbaa !24
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t279, i64 %t280)
  store i64 %t283, ptr %l171
  br label %bb62
bb62:
  %t284 = load i64, ptr %l171, !tbaa !24
  store i64 %t284, ptr %l26, !tbaa !24
  %t285 = load i64, ptr %l26, !tbaa !24
  %t288 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s13, ptr %l11, i64 %t285)
  store { i64, ptr } %t288, ptr %l174
  br label %bb63
bb63:
  %t289 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  %t291 = load i64, ptr %l23, !tbaa !24
  %t294 = icmp sgt i64 %t290, %t291
  br i1 %t294, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s14
  %t296 = load i64, ptr %l26, !tbaa !24
  %t299 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s14, ptr %l11, i64 %t296)
  store { i64, ptr } %t299, ptr %l180
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t300 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t303 = load i64, ptr %l25, !tbaa !24
  %t306 = add i64 %t303, 1
  store i64 %t306, ptr %l25, !tbaa !24
  br label %bb57
bb69:
  %t308 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t308, ptr %l185
  br label %bb70
bb70:
  %t309 = load %"std/prelude/text:StringBuilder", ptr %l185
  store %"std/prelude/text:StringBuilder" %t309, ptr %l27
  store ptr %l16, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s17
  %t311 = load i64, ptr %l29, !tbaa !24
  store i64 %t311, ptr %l187, !tbaa !24
  %t312 = load ptr, ptr %l28, !tbaa !29
  %t314 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t312)
  store i64 %t314, ptr %l189
  br label %bb72
bb72:
  %t315 = load i64, ptr %l187, !tbaa !24
  %t316 = load i64, ptr %l189, !tbaa !24
  %t317 = icmp slt i64 %t315, %t316
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s17)
  br label %bb102
bb74:
  br label %bb75
bb75:
  %t321 = load ptr, ptr %l28, !tbaa !29
  %t322 = load i64, ptr %l29, !tbaa !24
  %t325 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t321, i64 %t322)
  store i64 %t325, ptr %l194
  br label %bb76
bb76:
  %t326 = load i64, ptr %l194, !tbaa !24
  store i64 %t326, ptr %l30, !tbaa !24
  %t327 = load i64, ptr %l30, !tbaa !24
  %t329 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr %"compiler/effects:Facts", ptr %t330, i64 %t327
  %t332 = load %"compiler/effects:Facts", ptr %t331
  store %"compiler/effects:Facts" %t332, ptr %l31
  store i64 0, ptr %l32, !tbaa !24
  %t334 = load i64, ptr @G_2ecompiler_2feffects_2eCapCount, !tbaa !24
  store i64 %t334, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t336 = load i64, ptr %l33, !tbaa !24
  %t337 = load i64, ptr %l32, !tbaa !24
  %t340 = icmp sgt i64 %t336, %t337
  br i1 %t340, label %bb77, label %bb78
bb77:
  %t342 = load i64, ptr %l34, !tbaa !24
  %t344 = icmp sgt i64 %t342, 0
  br i1 %t344, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb82
bb79:
  %t346 = load i64, ptr %l33, !tbaa !24
  %t347 = load i64, ptr %l32, !tbaa !24
  %t350 = sub i64 %t346, %t347
  %t351 = load i64, ptr %l34, !tbaa !24
  %t354 = add i64 %t350, %t351
  %t356 = sub i64 %t354, 1
  %t357 = load i64, ptr %l34, !tbaa !24
  %t360 = sdiv i64 %t356, %t357
  store i64 %t360, ptr %l204, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb81
bb81:
  %t362 = load i64, ptr %l204, !tbaa !24
  store i64 %t362, ptr %l201, !tbaa !24
  br label %bb82
bb82:
  %t363 = load i64, ptr %l201, !tbaa !24
  store i64 %t363, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  %t364 = load i64, ptr %l35, !tbaa !24
  %t365 = sub i64 %t364, 1
  store i64 %t365, ptr %l213, !tbaa !24
  %t366 = load i64, ptr %l35, !tbaa !24
  %t367 = icmp slt i64 %t366, 2147483648
  %t368 = load i64, ptr %l36, !tbaa !24
  %t369 = icmp sge i64 %t368, 0
  %t372 = and i1 %t367, %t369
  store i1 %t372, ptr %l216, !tbaa !21
  br label %bb83
bb83:
  %t373 = load i64, ptr %l36, !tbaa !24
  %t374 = load i64, ptr %l35, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb84, label %bb85
bb84:
  br label %bb91
bb85:
  br label %bb86
bb86:
  %t381 = load i64, ptr %l32, !tbaa !24
  %t382 = load i64, ptr %l36, !tbaa !24
  %t383 = load i64, ptr %l34, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t389 = add i64 %t381, %t386
  store i64 %t389, ptr %l37, !tbaa !24
  %t391 = load i64, ptr %l37, !tbaa !24
  %t392 = getelementptr %"compiler/effects:Facts", ptr %l31, i32 0, i32 22
  %t394 = getelementptr [6 x i64], ptr %t392, i64 0, i64 %t391
  %t395 = load i64, ptr %t394, !tbaa !34
  %t396 = load i64, ptr %l30, !tbaa !24
  %t399 = icmp eq i64 %t395, %t396
  br i1 %t399, label %bb87, label %bb88
bb87:
  %t401 = load i64, ptr %l37, !tbaa !24
  %t402 = getelementptr %"compiler/effects:Facts", ptr %l31, i32 0, i32 22
  %t404 = getelementptr [6 x i64], ptr %t402, i64 0, i64 %t401
  store i64 -1, ptr %t404, !tbaa !34
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t405 = load i64, ptr %l36, !tbaa !24
  %t408 = add i64 %t405, 1
  store i64 %t408, ptr %l36, !tbaa !24
  br label %bb83
bb91:
  store ptr %l31, ptr %l234, !tbaa !29
  %t411 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t411, ptr %l236
  br label %bb92
bb92:
  %t412 = load ptr, ptr %l234, !tbaa !29
  %t413 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t414 = call { i64, ptr } @compiler_2feffects_2eCapText(ptr %s17, ptr %s0, ptr %s17, ptr %t412, { i64, ptr } %t413)
  store { i64, ptr } %t414, ptr %l237
  br label %bb93
bb93:
  %t415 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t415, ptr %l38, !tbaa !27
  store ptr %l27, ptr %l238, !tbaa !29
  %t416 = load i64, ptr %l30, !tbaa !24
  %t419 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l11, i64 %t416)
  store { i64, ptr } %t419, ptr %l241
  br label %bb94
bb94:
  %t420 = load i64, ptr %l23, !tbaa !24
  %t421 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t423 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s0, ptr %s17, { i64, ptr } %t421, i64 %t420, i8 32)
  store { i64, ptr } %t423, ptr %l243
  br label %bb95
bb95:
  %t424 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  store i64 %t425, ptr %l244, !tbaa !24
  %t426 = load i64, ptr %l244, !tbaa !24
  %t427 = mul i64 %t426, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t427)
  %t429 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  store { i64, ptr } %t430, ptr %l245, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = load i64, ptr %l244, !tbaa !24
  %t436 = mul i64 %t435, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t432, ptr %t434, i64 %t436, i1 false)
  %t437 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t439 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s17, ptr %s17, { i64, ptr } %t437, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t439, ptr %l247
  br label %bb96
bb96:
  %t440 = load i1, ptr %l247, !tbaa !21
  %t441 = xor i1 %t440, true
  br i1 %t441, label %bb97, label %bb98
bb97:
  %t443 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t443, ptr %l249, !tbaa !27
  br label %bb99
bb98:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb99
bb99:
  %t445 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 1
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t448 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t449 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t450 = add i64 %t447, %t449
  %t451 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = add i64 %t450, %t453
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t446, i64 %t447)
  %t459 = getelementptr i8, ptr %t458, i64 %t447
  call void @olang_textcopy(ptr %t459, ptr %t448, i64 %t449)
  %t460 = getelementptr i8, ptr %t459, i64 %t449
  call void @olang_textcopy(ptr %t460, ptr %t452, i64 %t453)
  %t461 = getelementptr i8, ptr %t460, i64 %t453
  call void @olang_textcopy(ptr %t461, ptr %t455, i64 %t456)
  %t462 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t463 = insertvalue { i64, ptr } %t462, ptr %t458, 1
  %t465 = load ptr, ptr %l238, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t465, { i64, ptr } %t463)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s17)
  br label %bb101
bb101:
  %t467 = load i64, ptr %l29, !tbaa !24
  %t470 = add i64 %t467, 1
  store i64 %t470, ptr %l29, !tbaa !24
  br label %bb71
bb102:
  %t473 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l27)
  store { i64, ptr } %t473, ptr %l257
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  %t474 = load { i64, ptr }, ptr %l257, !tbaa !27
  store { i64, ptr } %t474, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fexplain_2eCodes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %lp19 = alloca ptr
  %l25 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i64
  %l76 = alloca i32
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca %"compiler/explain:Code"
  %l92 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i64
  %l128 = alloca ptr
  %l132 = alloca i32
  %l138 = alloca i32
  %l145 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l150 = alloca i32
  %l151 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l160 = alloca i64
  %l164 = alloca { i64, ptr }
  %l165 = alloca %"compiler/explain:Code"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t11 = call i64 @compiler_2fexplain_2efnNamed(ptr %v0, ptr %v1, ptr %t5, i64 %t6, { i64, ptr } %a2)
  store i64 %t11, ptr %l25
  br label %bb2
bb2:
  %t12 = load i64, ptr %l25, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t18 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t18, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l32
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l32, !tbaa !29
  store ptr %t27, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/load:Loader", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 10
  store ptr %t47, ptr %l40, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l44
  br label %bb7
bb7:
  %t56 = load ptr, ptr %l40, !tbaa !29
  %t57 = load i64, ptr %l44, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t58, ptr %l45
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l45, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 4
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l6, !tbaa !24
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v2, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l50
  br label %bb9
bb9:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t69, ptr %lp7
  %t70 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t71 = load ptr, ptr %lp7
  store { i64, ptr } %t70, ptr %t71, !tbaa !27
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 0
  %t77 = getelementptr %"compiler/source:Span", ptr %t76, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t84 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t72, i64 %t73, i64 %t80)
  store i64 %t84, ptr %l56
  br label %bb10
bb10:
  %t85 = load i64, ptr %l56, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l57
  br label %bb11
bb11:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l9
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l59, !tbaa !29
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t92)
  store i64 %t94, ptr %l61
  br label %bb12
bb12:
  %t95 = load ptr, ptr %l59, !tbaa !29
  %t96 = load i64, ptr %l61, !tbaa !24
  %t97 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t95, i64 %t96)
  store i64 %t97, ptr %l62
  br label %bb13
bb13:
  %t98 = load i64, ptr %l62, !tbaa !24
  %t99 = icmp eq i64 %t98, 0
  br i1 %t99, label %bb14, label %bb15
bb14:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t104, i64 %t105, i32 0)
  store i64 %t108, ptr %l67
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t109 = load i64, ptr %l67, !tbaa !24
  store i64 %t109, ptr %l10, !tbaa !24
  store ptr %l9, ptr %l68, !tbaa !29
  %t110 = call ptr @__olang_scope_hold(ptr %v2)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l69, !tbaa !24
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2fexplain_3aCode_2e0
  br i1 %t112, label %bb17, label %bb18
bb17:
  %t114 = call ptr @__olang_region_make(ptr %v2)
  %t115 = ptrtoint ptr %t114 to i64
  store i64 %t115, ptr %l69, !tbaa !24
  br label %bb18
bb18:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l71, !tbaa !29
  %t117 = load i64, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l72, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t121, i64 %t122)
  store i32 %t125, ptr %l76
  br label %bb19
bb19:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l79
  br label %bb20
bb20:
  %t131 = load i64, ptr %l69
  %t132 = inttoptr i64 %t131 to ptr
  %t133 = load ptr, ptr %l71, !tbaa !29
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = load i32, ptr %l76, !tbaa !23
  %t136 = load i64, ptr %l79, !tbaa !24
  %t137 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %t132, ptr %t133, i64 %t134, i32 %t135, i64 %t136)
  store { i64, ptr } %t137, ptr %l80
  br label %bb21
bb21:
  %t138 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t138, ptr %l81, !tbaa !27
  %t139 = load ptr, ptr %lp7
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l82, !tbaa !27
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l83, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l87
  br label %bb22
bb22:
  %t150 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t152 = load i64, ptr %l83, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t154 = call %"compiler/explain:Code" @compiler_2fexplain_3aCode_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v2, { i64, ptr } %t150, { i64, ptr } %t151, i64 %t152, { i64, ptr } %t153)
  store %"compiler/explain:Code" %t154, ptr %l88
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l68, !tbaa !29
  %t156 = load %"compiler/explain:Code", ptr %l88
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ePush_3ccompiler_2fexplain_3aCode_3e(ptr %v2, ptr %v2, ptr %t155, %"compiler/explain:Code" %t156)
  br label %bb24
bb24:
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t159 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t159, ptr %rv
  br label %ret
bb25:
  store i64 0, ptr %l11, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t163)
  store i64 %t165, ptr %l92
  br label %bb26
bb26:
  %t166 = load i64, ptr %l92, !tbaa !24
  store i64 %t166, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l11, !tbaa !24
  %t171 = icmp sgt i64 %t167, %t168
  br i1 %t171, label %bb27, label %bb28
bb27:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t175 = icmp sgt i64 %t173, 0
  br i1 %t175, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb32
bb29:
  %t177 = load i64, ptr %l12, !tbaa !24
  %t178 = load i64, ptr %l11, !tbaa !24
  %t181 = sub i64 %t177, %t178
  %t182 = load i64, ptr %l13, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t187 = sub i64 %t185, 1
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = sdiv i64 %t187, %t188
  store i64 %t191, ptr %l99, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb31
bb31:
  %t193 = load i64, ptr %l99, !tbaa !24
  store i64 %t193, ptr %l96, !tbaa !24
  br label %bb32
bb32:
  %t194 = load i64, ptr %l96, !tbaa !24
  store i64 %t194, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t195 = load i64, ptr %l15, !tbaa !24
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb35:
  br label %bb36
bb36:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l13, !tbaa !24
  %t208 = mul i64 %t204, %t205
  %t211 = add i64 %t203, %t208
  store i64 %t211, ptr %l16, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load i64, ptr %l16, !tbaa !24
  %t220 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t216, i64 %t217)
  store i64 %t220, ptr %l120
  br label %bb37
bb37:
  %t221 = load i64, ptr %l3, !tbaa !24
  %t222 = load i64, ptr %l120, !tbaa !24
  %t224 = icmp ne i64 %t222, %t221
  br i1 %t224, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb39:
  br label %bb40
bb40:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i64, ptr %l16, !tbaa !24
  %t230 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t226, i64 %t227)
  store i64 %t230, ptr %l125
  br label %bb41
bb41:
  %t231 = load i64, ptr %l125, !tbaa !24
  store i64 %t231, ptr %l17, !tbaa !24
  %t232 = load i64, ptr %l17, !tbaa !24
  %t234 = icmp slt i64 %t232, 0
  br i1 %t234, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb43:
  br label %bb44
bb44:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l128, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t241 = load i64, ptr %l16, !tbaa !24
  %t244 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t240, i64 %t241)
  store i32 %t244, ptr %l132
  br label %bb45
bb45:
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Func", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = getelementptr %"compiler/ast:Func", ptr %t249, i32 0, i32 3
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/ast:Sig", ptr %t252, i32 0, i32 0
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = load ptr, ptr %l128, !tbaa !29
  %t257 = load i32, ptr %l132, !tbaa !23
  %t260 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t256, i32 %t257, ptr %t248, { i64, ptr } %t255)
  store i32 %t260, ptr %l138
  br label %bb46
bb46:
  %t261 = load i32, ptr %l138, !tbaa !23
  store i32 %t261, ptr %l18, !tbaa !23
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/generic:Program", ptr %t265, i32 0, i32 0
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t270 = getelementptr %"compiler/load:Loader", ptr %t268, i32 0, i32 3
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t272 = load ptr, ptr %l4, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Func", ptr %t272, i32 0, i32 2
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t271, i32 %t275)
  store { i64, ptr } %t278, ptr %l145
  br label %bb47
bb47:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l146, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t284 = load i64, ptr %l16, !tbaa !24
  %t287 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t283, i64 %t284)
  store i32 %t287, ptr %l150
  br label %bb48
bb48:
  %t288 = load ptr, ptr %l146, !tbaa !29
  %t289 = load i32, ptr %l150, !tbaa !23
  %t290 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s4, ptr %t288, i32 %t289)
  store { i64, ptr } %t290, ptr %l151
  br label %bb49
bb49:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l18, !tbaa !23
  %t293 = load i64, ptr %l17, !tbaa !24
  %t297 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s4, ptr %t291, i32 %t292, i64 %t293)
  store { i64, ptr } %t297, ptr %l155
  br label %bb50
bb50:
  %t298 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t300 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = add i64 %t299, %t302
  %t304 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t311 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = add i64 %t310, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t298, i64 %t299)
  %t316 = getelementptr i8, ptr %t315, i64 %t299
  call void @olang_textcopy(ptr %t316, ptr %t301, i64 %t302)
  %t317 = getelementptr i8, ptr %t316, i64 %t302
  call void @olang_textcopy(ptr %t317, ptr %t305, i64 %t306)
  %t318 = getelementptr i8, ptr %t317, i64 %t306
  call void @olang_textcopy(ptr %t318, ptr %t308, i64 %t309)
  %t319 = getelementptr i8, ptr %t318, i64 %t309
  call void @olang_textcopy(ptr %t319, ptr %t312, i64 %t313)
  %t320 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t315, 1
  %t322 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t322, ptr %lp19
  %t324 = load ptr, ptr %lp19
  store { i64, ptr } %t321, ptr %t324, !tbaa !27
  store ptr %l9, ptr %l157, !tbaa !29
  %t325 = load ptr, ptr %lp19
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l158, !tbaa !27
  %t327 = load ptr, ptr %lp7
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l159, !tbaa !27
  %t329 = load i64, ptr %l8, !tbaa !24
  store i64 %t329, ptr %l160, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t334 = load i64, ptr %l16, !tbaa !24
  %t337 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v0, ptr %t333, i64 %t334)
  store { i64, ptr } %t337, ptr %l164
  br label %bb51
bb51:
  %t338 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t340 = load i64, ptr %l160, !tbaa !24
  %t341 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t342 = call %"compiler/explain:Code" @compiler_2fexplain_3aCode_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v2, { i64, ptr } %t338, { i64, ptr } %t339, i64 %t340, { i64, ptr } %t341)
  store %"compiler/explain:Code" %t342, ptr %l165
  br label %bb52
bb52:
  %t343 = load ptr, ptr %l157, !tbaa !29
  %t344 = load %"compiler/explain:Code", ptr %l165
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ePush_3ccompiler_2fexplain_3aCode_3e(ptr %v2, ptr %v2, ptr %t343, %"compiler/explain:Code" %t344)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  %t345 = load i64, ptr %l15, !tbaa !24
  %t348 = add i64 %t345, 1
  store i64 %t348, ptr %l15, !tbaa !24
  br label %bb33
bb55:
  %t350 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t352 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t350, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t352, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t5)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t17, i64 %t18, i32 0)
  store i64 %t21, ptr %l12
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i64, ptr %l12, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l14, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l21
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l13, !tbaa !29
  %t39 = load i64, ptr %l14, !tbaa !24
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i32 %t40, i64 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l23, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l24, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load i64, ptr %l24, !tbaa !24
  %t56 = load i32, ptr %l28, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t54, i64 %t55, i32 %t56, i64 -1)
  store { i64, ptr } %t57, ptr %l29
  br label %bb11
bb11:
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Entry"
  %l13 = alloca i64
  %l14 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l30 = alloca i64
  %l36 = alloca { i64, ptr }
  %l40 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i64
  %l52 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca %"compiler/names:Entry"
  %l78 = alloca i64
  %l84 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l98 = alloca i32
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l24
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l23
  br label %bb2
bb2:
  %t23 = load i64, ptr %l23, !tbaa !24
  store i64 %t23, ptr %l21, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t24 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp sgt i64 %t24, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = call i64 @compiler_2fexplain_2efnNamed(ptr %v0, ptr %v3, ptr %t29, i64 %t30, { i64, ptr } %t31)
  store i64 %t35, ptr %l30
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t36 = load i64, ptr %l30, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load i64, ptr %l7, !tbaa !24
  %t47 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t41, ptr %t42, i64 %t43)
  store { i64, ptr } %t47, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t48, 1
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t50, i64 %t51, { i64, ptr } %t52)
  store i32 %t56, ptr %l40
  br label %bb13
bb13:
  %t57 = load i32, ptr %l40, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load i32, ptr %l8, !tbaa !23
  %t60 = icmp slt i32 %t58, 0
  br i1 %t60, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t63 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t63, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l8, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t64, i32 %t65)
  store { i64, ptr } %t68, ptr %l46
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t70 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t69, 1
  store { i32, { i64, ptr } } %t70, ptr %rv
  br label %ret
bb18:
  %t71 = load ptr, ptr %l5, !tbaa !29
  store ptr %t71, ptr %l47, !tbaa !29
  %t72 = call ptr @__olang_scope_hold(ptr %v0)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l48, !tbaa !24
  %t74 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load ptr, ptr %l47, !tbaa !29
  %t77 = call ptr @__olang_region_or(ptr %t76, ptr %v0)
  %t78 = call ptr @__olang_scope_hold(ptr %t77)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l48, !tbaa !24
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = load i64, ptr %l48
  %t83 = inttoptr i64 %t82 to ptr
  %t86 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t83, ptr %v3, ptr %t80, { i64, ptr } %t81)
  store i32 %t86, ptr %l52
  br label %bb21
bb21:
  %t87 = load i32, ptr %l52, !tbaa !23
  store i32 %t87, ptr %l9, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/names:Resolver", ptr %t94, i32 0, i32 1
  %t97 = load i64, ptr %l3, !tbaa !24
  %t100 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  store ptr %t100, ptr %l58
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t103 = getelementptr %"compiler/names:Table", ptr %t101, i32 0, i32 0
  store ptr %t103, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t105 = load i64, ptr %l11, !tbaa !24
  store i64 %t105, ptr %l61, !tbaa !24
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t106)
  store i64 %t108, ptr %l63
  br label %bb24
bb24:
  %t109 = load i64, ptr %l61, !tbaa !24
  %t110 = load i64, ptr %l63, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb25, label %bb26
bb25:
  br label %bb45
bb26:
  br label %bb27
bb27:
  %t115 = load ptr, ptr %l10, !tbaa !29
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t115, i64 %t116)
  store %"compiler/names:Entry" %t119, ptr %l68
  br label %bb28
bb28:
  %t120 = load %"compiler/names:Entry", ptr %l68
  store %"compiler/names:Entry" %t120, ptr %l12
  %t121 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t123 = load i32, ptr %l9, !tbaa !23
  %t126 = icmp ne i32 %t122, %t123
  br i1 %t126, label %bb29, label %bb30
bb29:
  br label %bb44
bb30:
  br label %bb31
bb31:
  %t128 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t129 = load i32, ptr %t128, !range !{i32 0, i32 9}
  %t131 = trunc i64 3 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb32, label %bb33
bb32:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i64, ptr %l3, !tbaa !24
  %t139 = load i32, ptr %l9, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t137, i64 %t138, i32 %t139)
  store i64 %t143, ptr %l78
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t144 = load i64, ptr %l78, !tbaa !24
  store i64 %t144, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t147 = icmp sge i64 %t145, 0
  br i1 %t147, label %bb35, label %bb36
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t151 = load i64, ptr %l13, !tbaa !24
  %t155 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t149, ptr %t150, i64 %t151)
  store { i64, ptr } %t155, ptr %l84
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t157 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t156, 1
  store { i32, { i64, ptr } } %t157, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t158 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t159 = load i32, ptr %t158, !range !{i32 0, i32 9}
  %t161 = trunc i64 2 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb40, label %bb41
bb40:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l3, !tbaa !24
  %t167 = load %"compiler/names:Entry", ptr %l12
  %t172 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t164, ptr %a2, i64 %t166, %"compiler/names:Entry" %t167)
  store { i64, ptr } %t172, ptr %l91
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t174 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t173, 1
  store { i32, { i64, ptr } } %t174, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l11, !tbaa !24
  br label %bb23
bb45:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l3, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t186 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t180, i64 %t181, { i64, ptr } %t182)
  store i32 %t186, ptr %l98
  br label %bb46
bb46:
  %t187 = load i32, ptr %l98, !tbaa !23
  store i32 %t187, ptr %l14, !tbaa !23
  %t188 = load i32, ptr %l14, !tbaa !23
  %t190 = icmp sge i32 %t188, 0
  br i1 %t190, label %bb47, label %bb48
bb47:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l14, !tbaa !23
  %t196 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t192, i32 %t193)
  store { i64, ptr } %t196, ptr %l103
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t197 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t198 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t197, 1
  store { i32, { i64, ptr } } %t198, ptr %rv
  br label %ret
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t200 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eNoValueWhy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l61 = alloca i64
  %l63 = alloca i1
  %l65 = alloca i1
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Func", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l25, !tbaa !24
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t51, ptr %l24, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t56, i64 %t57)
  store i1 %t60, ptr %l30
  br label %bb6
bb6:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t62, ptr %l32, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l34, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t76, ptr %l32, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t78)
  store i64 %t80, ptr %l36
  br label %bb10
bb10:
  %t81 = load i64, ptr %l36, !tbaa !24
  store i64 %t81, ptr %l6, !tbaa !24
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 5
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l39, !tbaa !24
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t88)
  store i1 %t90, ptr %l41
  br label %bb11
bb11:
  %t91 = load i1, ptr %l41, !tbaa !21
  br i1 %t91, label %bb12, label %bb13
bb12:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i64, ptr %l2, !tbaa !24
  %t99 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l46
  br label %bb14
bb13:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb14:
  %t100 = load i64, ptr %l46, !tbaa !24
  store i64 %t100, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t101 = load i64, ptr %l39, !tbaa !24
  %t102 = load i64, ptr %l42, !tbaa !24
  %t103 = add i64 %t101, %t102
  store i64 %t103, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l51
  br label %bb16
bb16:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l51, !tbaa !24
  %t116 = icmp sgt i64 %t114, %t113
  br i1 %t116, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t118, ptr %l55, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l56, !tbaa !24
  %t121 = load i64, ptr %l56, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l57, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l56, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t132, ptr %l55, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t133, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i64, ptr %l6, !tbaa !24
  %t141 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l61
  br label %bb20
bb20:
  %t142 = load i64, ptr %l61, !tbaa !24
  %t143 = icmp sgt i64 %t142, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t145)
  store i1 %t147, ptr %l65
  br label %bb23
bb22:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb24
bb23:
  %t148 = load i1, ptr %l65, !tbaa !21
  store i1 %t148, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t149 = load i1, ptr %l63, !tbaa !21
  br i1 %t149, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load ptr, ptr %l4, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/load:Loader", ptr %t157, i32 0, i32 3
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s4, ptr %t150, ptr %t160)
  store { i64, ptr } %t163, ptr %l71
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/load:Loader", ptr %t170, i32 0, i32 3
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Func", ptr %t174, i32 0, i32 9
  %t177 = load i32, ptr %t176, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t173, i32 %t177)
  store { i64, ptr } %t180, ptr %l78
  br label %bb28
bb28:
  %t181 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t183 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t181, i64 %t182)
  %t198 = getelementptr i8, ptr %t197, i64 %t182
  call void @olang_textcopy(ptr %t198, ptr %t184, i64 %t185)
  %t199 = getelementptr i8, ptr %t198, i64 %t185
  call void @olang_textcopy(ptr %t199, ptr %t187, i64 %t188)
  %t200 = getelementptr i8, ptr %t199, i64 %t188
  call void @olang_textcopy(ptr %t200, ptr %t191, i64 %t192)
  %t201 = getelementptr i8, ptr %t200, i64 %t192
  call void @olang_textcopy(ptr %t201, ptr %t194, i64 %t195)
  %t202 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t197, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t203, ptr %rv
  br label %ret
bb29:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t209 = load i64, ptr %l6, !tbaa !24
  %t212 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l83
  br label %bb30
bb30:
  %t213 = load i64, ptr %l83, !tbaa !24
  %t214 = icmp sgt i64 %t213, 0
  br i1 %t214, label %bb31, label %bb32
bb31:
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t217 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t220 = extractvalue { i64, ptr } %t216, 1
  %t221 = extractvalue { i64, ptr } %t216, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t217, i64 %t218)
  %t227 = getelementptr i8, ptr %t226, i64 %t218
  call void @olang_textcopy(ptr %t227, ptr %t220, i64 %t221)
  %t228 = getelementptr i8, ptr %t227, i64 %t221
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t226, 1
  store { i64, ptr } %t230, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l87, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t232, ptr %l88, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  store i64 %t234, ptr %l89, !tbaa !24
  %t235 = load i64, ptr %l89, !tbaa !24
  %t236 = mul i64 %t235, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t236)
  %t238 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l90, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = load i64, ptr %l89, !tbaa !24
  %t245 = mul i64 %t244, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t241, ptr %t243, i64 %t245, i1 false)
  %t246 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t246, ptr %l88, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t247, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2ebuilders(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v1, ptr %s1, ptr %t1, i32 %a2, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  store ptr %t7, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t10)
  store i64 %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l17
  br label %bb7
bb7:
  %t24 = load i64, ptr %l17, !tbaa !24
  store ptr %a0, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v1, ptr %s2, ptr %t26, i64 %t24)
  store { i64, ptr } %t30, ptr %l21
  br label %bb8
bb8:
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t46, { i64, ptr } %t44)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fexplain_2ecapsShown(ptr %v0, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = xor i1 %a1, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t8 = load i1, ptr %l6, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t14, ptr %l10
  br label %bb7
bb6:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb8
bb7:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t21, ptr %l14
  br label %bb11
bb10:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t22 = load i1, ptr %l14, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i1, ptr %l12, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb12:
  %t36 = mul i64 0, 8
  %t37 = insertvalue { i64, ptr } undef, i64 0, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5177bd7d484351dd_5d0dbb04dc509331)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb12:
  %t30 = mul i64 0, 8
  %t31 = insertvalue { i64, ptr } undef, i64 0, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_979fe2e14fb6de05_5947910940c194f1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2ectorRequires(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t4, i32 %t5)
  store ptr %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l10, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_1f3e281b9e5e1c1b_28b60c21bdf8ccb7)
  unreachable
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 5}
  %t27 = icmp eq i64 %t25, 0
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = getelementptr { i64, [6 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb12
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 2
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l25, !tbaa !27
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"compiler/ast:StructBody", ptr %t41, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t48, i32 %t49)
  store i64 %t52, ptr %l31
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l22, !tbaa !29
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t57 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fexplain_2ereqLines(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %s1, ptr %s1, ptr %t53, ptr %t54, { i64, ptr } %t55, { i64, ptr } %t56, ptr null, i64 %t57, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb12:
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 5}
  %t65 = icmp eq i64 %t63, 3
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr { i64, [6 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { ptr, ptr }, ptr %t69, i32 0, i32 1
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l42, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 4
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l44, !tbaa !27
  %t85 = load ptr, ptr %l6, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Func", ptr %t85, i32 0, i32 3
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Sig", ptr %t88, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i32, ptr %l2, !tbaa !23
  %t99 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t95, i32 %t96)
  store i64 %t99, ptr %l51
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t100 = load ptr, ptr %l41, !tbaa !29
  %t101 = load ptr, ptr %l42, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t104 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2fexplain_2ereqLines(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %s2, ptr %s2, ptr %t100, ptr %t101, { i64, ptr } %t102, { i64, ptr } %t103, ptr null, i64 %t104, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_56ca0331d7501bc3_73eac84a38a3448f)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %l7, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l9, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t24, ptr %l7, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l14
  br label %bb5
bb5:
  %t36 = load i1, ptr %l14, !tbaa !21
  br i1 %t36, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l17, !tbaa !24
  %t40 = load i64, ptr %l17, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l18, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l17, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t51, ptr %l16, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t53, ptr %l20, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l21, !tbaa !24
  %t56 = load i64, ptr %l21, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l22, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l21, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t67, ptr %l20, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2eeffectLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l14 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l34 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i64
  %l66 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca %"compiler/effects:Facts"
  %l79 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v1, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l18
  br label %bb3
bb3:
  %t13 = load i1, ptr %l18, !tbaa !21
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l22
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l22, !tbaa !29
  store ptr %t23, ptr %l5, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l23
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l6
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l6, ptr %l28, !tbaa !29
  %t35 = call ptr @__olang_scope_hold(ptr %s0)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l29, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t37, label %bb12, label %bb13
bb11:
  br label %bb19
bb12:
  %t39 = call ptr @__olang_region_make(ptr %s0)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l29, !tbaa !24
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l34, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_98928cfde749f632_385db913ea7e7976)
  unreachable
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Param", ptr %t61, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s2, ptr %t66, i32 %t65)
  store { i64, ptr } %t68, ptr %l42
  br label %bb17
bb17:
  %t69 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = load i64, ptr %l29
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @__olang_held_alloc(ptr %t73, i64 %t71)
  call void @olang_textcopy(ptr %t74, ptr %t70, i64 %t71)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t78, { i64, ptr } %t76)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 3
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Sig", ptr %t83, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t100, ptr %l54, !tbaa !27
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  store ptr %t106, ptr %l10, !tbaa !29
  store ptr %l6, ptr %l57, !tbaa !29
  %t108 = call ptr @__olang_scope_hold(ptr %s0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l58, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t110, label %bb24, label %bb25
bb24:
  %t112 = call ptr @__olang_region_make(ptr %s0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l58, !tbaa !24
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 0
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/load:Loader", ptr %t120, i32 0, i32 3
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load ptr, ptr %l10, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Param", ptr %t124, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s5, ptr %t123, i32 %t127)
  store { i64, ptr } %t130, ptr %l66
  br label %bb26
bb26:
  %t131 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = load i64, ptr %l58
  %t135 = inttoptr i64 %t134 to ptr
  %t136 = call ptr @__olang_held_alloc(ptr %t135, i64 %t133)
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  %t140 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t140, { i64, ptr } %t138)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l8, !tbaa !24
  br label %bb20
bb29:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v1, ptr %v1, ptr %t147)
  store ptr %t149, ptr %l73
  br label %bb30
bb30:
  %t150 = load ptr, ptr %l73, !tbaa !29
  store ptr %a0, ptr %l74, !tbaa !29
  store { i64, ptr } %a4, ptr %l75, !tbaa !27
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v1, ptr %t150, i64 %t154)
  store %"compiler/effects:Facts" %t157, ptr %l78
  br label %bb31
bb31:
  store ptr %l78, ptr %l79, !tbaa !29
  %t159 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t159, ptr %l81
  br label %bb32
bb32:
  %t160 = load ptr, ptr %l79, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t162 = call { i64, ptr } @compiler_2feffects_2eDescribe(ptr %s0, ptr %s0, ptr %s0, ptr %t160, { i64, ptr } %t161)
  store { i64, ptr } %t162, ptr %l82
  br label %bb33
bb33:
  %t163 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t164, i64 %t165)
  %t177 = getelementptr i8, ptr %t176, i64 %t165
  call void @olang_textcopy(ptr %t177, ptr %t166, i64 %t167)
  %t178 = getelementptr i8, ptr %t177, i64 %t167
  call void @olang_textcopy(ptr %t178, ptr %t170, i64 %t171)
  %t179 = getelementptr i8, ptr %t178, i64 %t171
  call void @olang_textcopy(ptr %t179, ptr %t173, i64 %t174)
  %t180 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t176, 1
  %t183 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t183, { i64, ptr } %t181)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorTypeItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l29 = alloca i1
  %l39 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca i64
  %l119 = alloca { i64, ptr }
  %l125 = alloca i64
  %l128 = alloca i64
  %l146 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l5, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v1, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l29
  br label %bb1
bb1:
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = extractvalue { i64, ptr } %t22, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  call void @olang_textcopy(ptr %t30, ptr %t26, i64 %t27)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } %t32)
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2ewordPayload(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i32 %t38, i64 0)
  br label %bb5
bb5:
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t42, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb6
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v3, ptr %t44)
  store { i64, ptr } %t46, ptr %l39
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb8:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 10
  store ptr %t56, ptr %l43, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t60, i32 %t61)
  store i64 %t64, ptr %l47
  br label %bb9
bb9:
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %l47, !tbaa !24
  %t67 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t65, i64 %t66)
  store ptr %t67, ptr %l48
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l48, !tbaa !29
  %t70 = getelementptr %"compiler/load:Module", ptr %t68, i32 0, i32 6
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l6, !tbaa !29
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e71eefb410212e60_d710e4409f4406c4)
  unreachable
bb12:
  br label %bb13
bb13:
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t80 = getelementptr %"compiler/source:Source", ptr %t77, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t85 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t88 = extractvalue { i64, ptr } %t84, 1
  %t89 = extractvalue { i64, ptr } %t84, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t85, i64 %t86)
  %t95 = getelementptr i8, ptr %t94, i64 %t86
  call void @olang_textcopy(ptr %t95, ptr %t88, i64 %t89)
  %t96 = getelementptr i8, ptr %t95, i64 %t89
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t94, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t83, { i64, ptr } %t98)
  br label %bb14
bb14:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i32, ptr %l2, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v1, ptr %s0, ptr %t105, i32 %t106)
  store { i64, ptr } %t109, ptr %l63
  br label %bb15
bb15:
  %t110 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t110, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb16, label %bb17
bb16:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb21
bb18:
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l11, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l72, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb20
bb20:
  %t141 = load i64, ptr %l72, !tbaa !24
  store i64 %t141, ptr %l69, !tbaa !24
  br label %bb21
bb21:
  %t142 = load i64, ptr %l69, !tbaa !24
  store i64 %t142, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t143 = load i64, ptr %l13, !tbaa !24
  %t144 = load i64, ptr %l12, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb24:
  br label %bb25
bb25:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l14, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l90, !tbaa !29
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l93, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l93, !tbaa !27
  br label %bb28
bb28:
  %t166 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t166, ptr %l94, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t167, ptr %l95, !tbaa !27
  %t168 = load i64, ptr %l14, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr ptr, ptr %t171, i64 %t168
  %t173 = load ptr, ptr %t172, !tbaa !39
  %t175 = getelementptr %"compiler/ast:Path", ptr %t173, i32 0, i32 0
  %t176 = getelementptr %"compiler/source:Span", ptr %t175, i32 0, i32 0
  %t177 = load i32, ptr %t176, !tbaa !23
  %t179 = sext i32 %t177 to i64
  store i64 %t179, ptr %l99, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t180, ptr %l100, !tbaa !27
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 %t181
  %t186 = load ptr, ptr %t185, !tbaa !39
  %t188 = getelementptr %"compiler/ast:Path", ptr %t186, i32 0, i32 0
  %t189 = getelementptr %"compiler/source:Span", ptr %t188, i32 0, i32 1
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = sext i32 %t190 to i64
  store i64 %t192, ptr %l104, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  store i64 %t194, ptr %l105, !tbaa !24
  %t195 = load i64, ptr %l99, !tbaa !24
  %t196 = icmp sge i64 %t195, 0
  br i1 %t196, label %bb29, label %bb30
bb29:
  %t198 = load i64, ptr %l99, !tbaa !24
  %t199 = load i64, ptr %l104, !tbaa !24
  %t200 = icmp sle i64 %t198, %t199
  br i1 %t200, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_5296f019e964cb45_44665f46e1029c89)
  unreachable
bb31:
  %t202 = load i64, ptr %l104, !tbaa !24
  %t203 = load i64, ptr %l105, !tbaa !24
  %t204 = icmp sle i64 %t202, %t203
  br i1 %t204, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5296f019e964cb45_44665f46e1029c89)
  unreachable
bb33:
  %t206 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l99, !tbaa !24
  %t209 = load i64, ptr %l104, !tbaa !24
  %t210 = getelementptr i8, ptr %t207, i64 %t208
  %t211 = sub i64 %t209, %t208
  %t212 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  %t214 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t218 = extractvalue { i64, ptr } %t213, 1
  %t219 = extractvalue { i64, ptr } %t213, 0
  %t220 = add i64 %t216, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t215, i64 %t216)
  %t222 = getelementptr i8, ptr %t221, i64 %t216
  call void @olang_textcopy(ptr %t222, ptr %t218, i64 %t219)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t221, 1
  %t226 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t226, { i64, ptr } %t224)
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5296f019e964cb45_44665f46e1029c89)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t228 = load i64, ptr %l13, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l13, !tbaa !24
  br label %bb22
bb37:
  %t233 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t233, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb38
bb38:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t239 = load i32, ptr %l2, !tbaa !23
  %t242 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v1, ptr %s0, ptr %t238, i32 %t239)
  store { i64, ptr } %t242, ptr %l119
  br label %bb39
bb39:
  %t243 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t243, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  %t249 = load i64, ptr %l16, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb40, label %bb41
bb40:
  %t254 = load i64, ptr %l18, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb45
bb42:
  %t258 = load i64, ptr %l17, !tbaa !24
  %t259 = load i64, ptr %l16, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l18, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l128, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb44
bb44:
  %t274 = load i64, ptr %l128, !tbaa !24
  store i64 %t274, ptr %l125, !tbaa !24
  br label %bb45
bb45:
  %t275 = load i64, ptr %l125, !tbaa !24
  store i64 %t275, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t276 = load i64, ptr %l20, !tbaa !24
  %t277 = load i64, ptr %l19, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb48:
  br label %bb49
bb49:
  %t284 = load i64, ptr %l16, !tbaa !24
  %t285 = load i64, ptr %l20, !tbaa !24
  %t286 = load i64, ptr %l18, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l21, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l146, !tbaa !29
  %t295 = load ptr, ptr %l5, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t296, ptr %l148, !tbaa !27
  %t297 = load i64, ptr %l21, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i32, ptr %t300, i64 %t297
  %t302 = load i32, ptr %t301, !tbaa !33
  %t305 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s9, ptr %t295, i32 %t302)
  store { i64, ptr } %t305, ptr %l151
  br label %bb50
bb50:
  %t306 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t308 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t306, i64 %t307)
  %t313 = getelementptr i8, ptr %t312, i64 %t307
  call void @olang_textcopy(ptr %t313, ptr %t309, i64 %t310)
  %t314 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t312, 1
  %t317 = load ptr, ptr %l146, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t317, { i64, ptr } %t315)
  br label %bb51
bb51:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load ptr, ptr %l1, !tbaa !29
  %t321 = load i32, ptr %l3, !tbaa !23
  %t322 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fexplain_2ewordPayload(ptr %v0, ptr %v1, ptr %t319, ptr %t320, i32 %t321, i64 %t322)
  br label %bb52
bb52:
  %t327 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t327, i8 10)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t329 = load i64, ptr %l20, !tbaa !24
  %t332 = add i64 %t329, 1
  store i64 %t332, ptr %l20, !tbaa !24
  br label %bb46
bb55:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v3, ptr %t334)
  store { i64, ptr } %t336, ptr %l163
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t337 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t337, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l45 = alloca { i64, ptr }
  %l50 = alloca i1
  %l53 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t35, 2147483648
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  %t41 = and i1 %t36, %t38
  store i1 %t41, ptr %l29, !tbaa !21
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = mul i64 0, %t42
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 1, %t44
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = add i64 %t46, %t43
  %t50 = add i64 0, %t45
  %t52 = sub i64 %t48, 1
  store i64 %t52, ptr %l34, !tbaa !24
  %t54 = sub i64 %t50, 0
  store i64 %t54, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb8, label %bb9
bb8:
  br label %bb51
bb9:
  br label %bb10
bb10:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l7, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t73, ptr %l45, !tbaa !27
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  store i8 %t79, ptr %l8, !tbaa !22
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 40
  br i1 %t83, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb13
bb12:
  %t85 = load i8, ptr %l8, !tbaa !22
  %t87 = icmp eq i8 %t85, 60
  store i1 %t87, ptr %l50, !tbaa !21
  br label %bb13
bb13:
  %t89 = load i1, ptr %l50, !tbaa !21
  br i1 %t89, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb16
bb15:
  %t90 = load i8, ptr %l8, !tbaa !22
  %t92 = icmp eq i8 %t90, 91
  store i1 %t92, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t100 = load i8, ptr %l8, !tbaa !22
  %t102 = icmp eq i8 %t100, 41
  br i1 %t102, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb22
bb21:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 62
  store i1 %t106, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t108 = load i1, ptr %l61, !tbaa !21
  br i1 %t108, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb25
bb24:
  %t109 = load i8, ptr %l8, !tbaa !22
  %t111 = icmp eq i8 %t109, 93
  store i1 %t111, ptr %l64, !tbaa !21
  br label %bb25
bb25:
  %t113 = load i1, ptr %l64, !tbaa !21
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t114 = load i64, ptr %l1, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  store i1 %t116, ptr %l67, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb28
bb28:
  %t118 = load i1, ptr %l67, !tbaa !21
  br i1 %t118, label %bb29, label %bb30
bb29:
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = sub i64 %t119, 1
  store i64 %t122, ptr %l1, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t124 = load i64, ptr %l1, !tbaa !24
  %t126 = icmp eq i64 %t124, 0
  br i1 %t126, label %bb32, label %bb33
bb32:
  %t128 = load i8, ptr %l8, !tbaa !22
  %t130 = icmp eq i8 %t128, 63
  store i1 %t130, ptr %l75, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t132 = load i1, ptr %l75, !tbaa !21
  br i1 %t132, label %bb35, label %bb36
bb35:
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = icmp sgt i64 %t133, 0
  store i1 %t135, ptr %l78, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb37
bb37:
  %t137 = load i1, ptr %l78, !tbaa !21
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t138 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t138, ptr %l82, !tbaa !27
  %t139 = load i64, ptr %l7, !tbaa !24
  %t141 = sub i64 %t139, 1
  %t143 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t148 = icmp eq i8 %t146, 32
  store i1 %t148, ptr %l81, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l81, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t151 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t151, ptr %l87, !tbaa !27
  %t152 = load i64, ptr %l7, !tbaa !24
  %t154 = sub i64 %t152, 1
  store i64 %t154, ptr %l89, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t155, 0
  store i64 %t158, ptr %l92, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l93, !tbaa !24
  %t161 = load i64, ptr %l89, !tbaa !24
  %t162 = icmp sge i64 %t161, 0
  br i1 %t162, label %bb43, label %bb44
bb42:
  br label %bb49
bb43:
  %t164 = load i64, ptr %l89, !tbaa !24
  %t165 = load i64, ptr %l92, !tbaa !24
  %t166 = icmp sle i64 %t164, %t165
  br i1 %t166, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb45:
  %t168 = load i64, ptr %l92, !tbaa !24
  %t169 = load i64, ptr %l93, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb47:
  %t172 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l89, !tbaa !24
  %t175 = load i64, ptr %l92, !tbaa !24
  %t176 = getelementptr i8, ptr %t173, i64 %t174
  %t177 = sub i64 %t175, %t174
  %t178 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  store { i64, ptr } %t179, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb49:
  br label %bb50
bb50:
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l6, !tbaa !24
  br label %bb7
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l102, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t187, ptr %l103, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l104, !tbaa !24
  %t190 = load i64, ptr %l104, !tbaa !24
  %t191 = mul i64 %t190, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t191)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l105, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l104, !tbaa !24
  %t200 = mul i64 %t199, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t196, ptr %t198, i64 %t200, i1 false)
  %t201 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t201, ptr %l103, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/typed:Local"
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l42 = alloca i32
  %l46 = alloca i1
  %l51 = alloca i32
  %l56 = alloca i32
  %l58 = alloca i1
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l118 = alloca ptr
  %l122 = alloca i32
  %l124 = alloca %"compiler/typed:Local"
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l139 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i64
  %l152 = alloca { i64, ptr }
  %l157 = alloca i1
  %l158 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 19
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l24, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l26
  br label %bb2
bb2:
  %t9 = load i64, ptr %l24, !tbaa !24
  %t10 = load i64, ptr %l26, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb71
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l31
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l31, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 1
  %t24 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t24, ptr %l6
  %t26 = load { i64, [2 x i64] }, ptr %l6
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t32 = getelementptr { i32, i32 }, ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l8, !tbaa !23
  br label %bb9
bb8:
  br label %bb64
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l42
  br label %bb10
bb10:
  %t49 = load i32, ptr %l42, !range !{i32 0, i32 33}
  %t51 = trunc i64 18 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb15
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l7, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l51
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l56
  br label %bb14
bb14:
  %t76 = load i32, ptr %l51, !tbaa !23
  %t77 = load i32, ptr %l56, !tbaa !23
  %t78 = icmp ne i32 %t76, %t77
  store i1 %t78, ptr %l46, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb18
bb17:
  %t81 = load i32, ptr %l8, !tbaa !23
  %t83 = icmp ne i32 %t81, 0
  store i1 %t83, ptr %l58, !tbaa !21
  br label %bb18
bb18:
  %t85 = load i1, ptr %l58, !tbaa !21
  br i1 %t85, label %bb19, label %bb20
bb19:
  br label %bb70
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l63, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l68
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i32, ptr %l68, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t102, i32 %t103)
  store { i64, ptr } %t104, ptr %l69
  br label %bb23
bb23:
  %t105 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t105, ptr %l9, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 10
  store ptr %t114, ptr %l73, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l75, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l2, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l80
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t130 = load i32, ptr %l80, !tbaa !23
  %t131 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t129, i32 %t130)
  store i64 %t131, ptr %l81
  br label %bb25
bb25:
  %t132 = load ptr, ptr %l73, !tbaa !29
  %t133 = load i64, ptr %l81, !tbaa !24
  %t134 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t132, i64 %t133)
  store ptr %t134, ptr %l82
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l82, !tbaa !29
  %t137 = getelementptr %"compiler/load:Module", ptr %t135, i32 0, i32 6
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l10, !tbaa !29
  %t140 = load ptr, ptr %l10, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1ab09a44950d5518_36fac77ffd6769bc)
  unreachable
bb28:
  br label %bb29
bb29:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t147 = getelementptr %"compiler/source:Source", ptr %t144, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Body", ptr %t150, i32 0, i32 10
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t152)
  store i64 %t154, ptr %l92
  br label %bb30
bb30:
  %t155 = load i64, ptr %l92, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb36
bb33:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l99, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb35
bb35:
  %t182 = load i64, ptr %l99, !tbaa !24
  store i64 %t182, ptr %l96, !tbaa !24
  br label %bb36
bb36:
  %t183 = load i64, ptr %l96, !tbaa !24
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb63
bb39:
  br label %bb40
bb40:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  store i64 %t200, ptr %l17, !tbaa !24
  %t202 = load ptr, ptr %l5, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Body", ptr %t202, i32 0, i32 7
  store ptr %t204, ptr %l118, !tbaa !29
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Body", ptr %t205, i32 0, i32 10
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t207, i64 %t208)
  store i32 %t211, ptr %l122
  br label %bb41
bb41:
  %t212 = load i32, ptr %l122, !tbaa !23
  %t213 = sext i32 %t212 to i64
  %t214 = load ptr, ptr %l118, !tbaa !29
  %t216 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t214, i64 %t213)
  store %"compiler/typed:Local" %t216, ptr %l124
  br label %bb42
bb42:
  %t217 = load %"compiler/typed:Local", ptr %l124
  store %"compiler/typed:Local" %t217, ptr %l18
  %t218 = load i64, ptr %l17, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t224 = icmp slt i64 %t218, %t221
  br i1 %t224, label %bb43, label %bb44
bb43:
  %t226 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t226, ptr %l130, !tbaa !27
  %t227 = load i64, ptr %l17, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr i32, ptr %t230, i64 %t227
  %t232 = load i32, ptr %t231, !tbaa !33
  store i32 %t232, ptr %l129, !tbaa !23
  br label %bb45
bb44:
  %t234 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  store i32 %t235, ptr %l129, !tbaa !23
  br label %bb45
bb45:
  %t237 = load i32, ptr %l129, !tbaa !23
  store i32 %t237, ptr %l19, !tbaa !23
  %t238 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t239 = load i32, ptr %t238, !tbaa !23
  %t241 = icmp eq i32 %t239, 0
  br i1 %t241, label %bb46, label %bb47
bb46:
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t243, ptr %l137, !tbaa !27
  %t244 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t245 = getelementptr %"compiler/source:Span", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  store i64 %t248, ptr %l139, !tbaa !24
  %t249 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t250 = getelementptr %"compiler/source:Span", ptr %t249, i32 0, i32 1
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  store i64 %t253, ptr %l141, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l142, !tbaa !24
  %t256 = load i64, ptr %l139, !tbaa !24
  %t257 = icmp sge i64 %t256, 0
  br i1 %t257, label %bb48, label %bb49
bb47:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = getelementptr %"compiler/generic:Program", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/load:Loader", ptr %t265, i32 0, i32 3
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s6, ptr %t268, i32 %t270)
  store { i64, ptr } %t273, ptr %l152
  br label %bb54
bb48:
  %t274 = load i64, ptr %l139, !tbaa !24
  %t275 = load i64, ptr %l141, !tbaa !24
  %t276 = icmp sle i64 %t274, %t275
  br i1 %t276, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb50:
  %t278 = load i64, ptr %l141, !tbaa !24
  %t279 = load i64, ptr %l142, !tbaa !24
  %t280 = icmp sle i64 %t278, %t279
  br i1 %t280, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb52:
  %t282 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l139, !tbaa !24
  %t285 = load i64, ptr %l141, !tbaa !24
  %t286 = getelementptr i8, ptr %t283, i64 %t284
  %t287 = sub i64 %t285, %t284
  %t288 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t286, 1
  store { i64, ptr } %t289, ptr %l136, !tbaa !27
  br label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021)
  unreachable
bb54:
  %t291 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t291, ptr %l136, !tbaa !27
  br label %bb55
bb55:
  %t292 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t292, ptr %l20, !tbaa !27
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t297 = load i32, ptr %l2, !tbaa !23
  %t298 = load i64, ptr %l17, !tbaa !24
  %t302 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWeakField(ptr %v1, ptr %t296, i32 %t297, i64 %t298)
  store i1 %t302, ptr %l157
  br label %bb56
bb56:
  %t303 = load i1, ptr %l157, !tbaa !21
  br i1 %t303, label %bb57, label %bb58
bb57:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l158, !tbaa !27
  br label %bb59
bb58:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l158, !tbaa !27
  br label %bb59
bb59:
  %t304 = load { i64, ptr }, ptr %l158, !tbaa !27
  store ptr %a0, ptr %l159, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t306, ptr %l160, !tbaa !27
  store { i64, ptr } %t304, ptr %l161, !tbaa !27
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t309 = load i32, ptr %l19, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s6, ptr %t308, i32 %t309)
  store { i64, ptr } %t312, ptr %l164
  br label %bb60
bb60:
  %t313 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t315 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t322 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t313, i64 %t314)
  %t334 = getelementptr i8, ptr %t333, i64 %t314
  call void @olang_textcopy(ptr %t334, ptr %t316, i64 %t317)
  %t335 = getelementptr i8, ptr %t334, i64 %t317
  call void @olang_textcopy(ptr %t335, ptr %t319, i64 %t320)
  %t336 = getelementptr i8, ptr %t335, i64 %t320
  call void @olang_textcopy(ptr %t336, ptr %t323, i64 %t324)
  %t337 = getelementptr i8, ptr %t336, i64 %t324
  call void @olang_textcopy(ptr %t337, ptr %t327, i64 %t328)
  %t338 = getelementptr i8, ptr %t337, i64 %t328
  call void @olang_textcopy(ptr %t338, ptr %t330, i64 %t331)
  %t339 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t333, 1
  %t342 = load ptr, ptr %l159, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t342, { i64, ptr } %t340)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb62:
  %t344 = load i64, ptr %l16, !tbaa !24
  %t347 = add i64 %t344, 1
  store i64 %t347, ptr %l16, !tbaa !24
  br label %bb37
bb63:
  br label %ret
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_b65b7d917c440185_24d12a03c9296209)
  unreachable
bb69:
  br label %bb70
bb70:
  %t349 = load i64, ptr %l4, !tbaa !24
  %t352 = add i64 %t349, 1
  store i64 %t352, ptr %l4, !tbaa !24
  br label %bb1
bb71:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2efitsLine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/effects:Facts"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l31 = alloca i1
  %l34 = alloca ptr
  %l39 = alloca i32
  %l44 = alloca i32
  %l47 = alloca i32
  %l52 = alloca i32
  %l57 = alloca i64
  %l58 = alloca i32
  %l60 = alloca ptr
  %l62 = alloca %"compiler/effects:Facts"
  %l68 = alloca i64
  %l71 = alloca i64
  %l91 = alloca i1
  %l93 = alloca i64
  %l95 = alloca { i64, ptr }
  %l97 = alloca i1
  %l100 = alloca i64
  %l106 = alloca i64
  %l108 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca i64
  %l119 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l147 = alloca i1
  %l148 = alloca i64
  %l152 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca i1
  %l173 = alloca i64
  %l177 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l191 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i32, ptr %l3, !tbaa !23
  store i32 %t5, ptr %l6, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v1, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l31
  br label %bb4
bb4:
  %t12 = load i1, ptr %l31, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  store ptr %t18, ptr %l34, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l39
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v1, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l44
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v1, ptr %t39, i64 %t40)
  store i32 %t43, ptr %l47
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v1, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l52
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v1, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l57
  br label %bb11
bb11:
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = load i32, ptr %l39, !tbaa !23
  %t66 = load i32, ptr %l44, !tbaa !23
  %t67 = load i32, ptr %l47, !tbaa !23
  %t68 = load i32, ptr %l52, !tbaa !23
  %t69 = load i64, ptr %l57, !tbaa !24
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v1, ptr %t64, i32 %t65, i32 %t66, i32 %t67, i32 %t68, i64 %t69, i1 false, i32 0, i64 0)
  store i32 %t70, ptr %l58
  br label %bb12
bb12:
  %t71 = load i32, ptr %l58, !tbaa !23
  store i32 %t71, ptr %l6, !tbaa !23
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v1, ptr %v1, ptr %t72)
  store ptr %t74, ptr %l60
  br label %bb14
bb14:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load ptr, ptr %l60, !tbaa !29
  %t78 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v1, ptr %t76, i64 %t75)
  store %"compiler/effects:Facts" %t78, ptr %l62
  br label %bb15
bb15:
  %t79 = load %"compiler/effects:Facts", ptr %l62
  store %"compiler/effects:Facts" %t79, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t80 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb21
bb18:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l71, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb20
bb20:
  %t109 = load i64, ptr %l71, !tbaa !24
  store i64 %t109, ptr %l68, !tbaa !24
  br label %bb21
bb21:
  %t110 = load i64, ptr %l68, !tbaa !24
  store i64 %t110, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t131 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t129
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !37
  %t133 = load ptr, ptr @__olang_prog_scope
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t133, ptr %s4, { i64, ptr } %t132, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t135, ptr %l91
  br label %bb26
bb26:
  %t136 = load i1, ptr %l91, !tbaa !21
  br i1 %t136, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t137 = load i64, ptr %l14, !tbaa !24
  store i64 %t137, ptr %l93, !tbaa !24
  %t138 = load i64, ptr %l93, !tbaa !24
  %t139 = load i64, ptr %l93, !tbaa !24
  %t140 = shl i64 1, %t139
  %t143 = call { i64, ptr } @compiler_2feffects_2eBreaks(ptr %s0, ptr %s4, ptr %l7, i64 %t140)
  store { i64, ptr } %t143, ptr %l95
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t144, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t146, ptr %l97
  br label %bb31
bb31:
  %t147 = load i1, ptr %l97, !tbaa !21
  br i1 %t147, label %bb32, label %bb33
bb32:
  %t148 = load i64, ptr %l8, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  store i64 %t150, ptr %l100, !tbaa !24
  %t151 = load i64, ptr %l100, !tbaa !24
  %t152 = load i64, ptr %l100, !tbaa !24
  %t153 = shl i64 1, %t152
  %t156 = or i64 %t148, %t153
  store i64 %t156, ptr %l8, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l13, !tbaa !24
  br label %bb22
bb36:
  %t163 = call ptr @__olang_scope_hold(ptr %s0)
  %t164 = ptrtoint ptr %t163 to i64
  store i64 %t164, ptr %l106, !tbaa !24
  %t165 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t165, label %bb37, label %bb38
bb37:
  %t167 = call ptr @__olang_region_make(ptr %s0)
  %t168 = ptrtoint ptr %t167 to i64
  store i64 %t168, ptr %l106, !tbaa !24
  br label %bb38
bb38:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l108, !tbaa !29
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  store ptr %t175, ptr %l111, !tbaa !29
  %t176 = load i32, ptr %l6, !tbaa !23
  store i32 %t176, ptr %l112, !tbaa !23
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  store ptr %t182, ptr %l115, !tbaa !29
  %t183 = load i64, ptr %l8, !tbaa !24
  store i64 %t183, ptr %l116, !tbaa !24
  %t184 = icmp sge i64 0, 0
  br i1 %t184, label %bb39, label %bb40
bb39:
  %t186 = icmp sle i64 0, 1152921504606846975
  br i1 %t186, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_a9d5b4a7460205c1_2b5a1ac3293d7e25)
  unreachable
bb41:
  %t188 = mul i64 0, 8
  %t189 = insertvalue { i64, ptr } undef, i64 0, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t190, ptr %l119, !tbaa !27
  %t191 = icmp sge i64 0, 0
  br i1 %t191, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_a9d5b4a7460205c1_2b5a1ac3293d7e25)
  unreachable
bb43:
  %t193 = icmp sle i64 0, 1152921504606846975
  br i1 %t193, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_a9d5b4a7460205c1_2b5a1ac3293d7e25)
  unreachable
bb45:
  %t195 = mul i64 0, 8
  %t196 = insertvalue { i64, ptr } undef, i64 0, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t198 = load ptr, ptr %l115, !tbaa !29
  %t199 = load i64, ptr %l116, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t202 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v1, ptr %s0, ptr %s0, ptr %t198, i64 %t199, { i64, ptr } %t200, { i64, ptr } %t197)
  store i64 %t202, ptr %l123
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_a9d5b4a7460205c1_2b5a1ac3293d7e25)
  unreachable
bb47:
  %t203 = load ptr, ptr %l111, !tbaa !29
  %t204 = load i32, ptr %l112, !tbaa !23
  %t205 = load i64, ptr %l123, !tbaa !24
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithPromises(ptr %v1, ptr %t203, i32 %t204, i64 %t205)
  store i32 %t206, ptr %l124
  br label %bb48
bb48:
  %t207 = load i64, ptr %l106
  %t208 = inttoptr i64 %t207 to ptr
  %t209 = load ptr, ptr %l108, !tbaa !29
  %t210 = load i32, ptr %l124, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %t208, ptr %t209, i32 %t210)
  store { i64, ptr } %t211, ptr %l125
  br label %bb49
bb49:
  %t212 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t212, label %bb50, label %bb51
bb50:
  %t214 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  %t217 = icmp eq i64 %t215, 0
  br i1 %t217, label %bb52, label %bb53
bb51:
  %t219 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t219, ptr %l15, !tbaa !27
  %t220 = load ptr, ptr %l2, !tbaa !29
  %t221 = load i64, ptr %l4, !tbaa !24
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/load:Loader", ptr %t228, i32 0, i32 3
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t235 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRelationWords(ptr %v2, ptr %v1, ptr %s0, ptr %t220, i64 %t221, ptr %t231)
  store { i64, ptr } %t235, ptr %l135
  br label %bb54
bb52:
  store { i64, ptr } zeroinitializer, ptr %l125, !tbaa !27
  br label %bb53
bb53:
  %t236 = load i64, ptr %l106
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = load { i64, ptr }, ptr %l125
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = call ptr @__olang_region_or(ptr %t239, ptr null)
  %t241 = icmp ne ptr %t240, null
  %t242 = select i1 %t241, ptr %t240, ptr null
  call void @__olang_region_settle_in(ptr %t237, ptr %t242)
  br label %bb51
bb54:
  %t243 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t243, ptr %l16, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t244, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  store i64 %t248, ptr %l19, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t250 = load i64, ptr %l18, !tbaa !24
  %t251 = load i64, ptr %l19, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb57:
  br label %bb58
bb58:
  %t258 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t258, ptr %l143, !tbaa !27
  %t259 = load i64, ptr %l18, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %t262, i64 %t259
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !37
  store { i64, ptr } %t264, ptr %l20, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t268 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t266, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t268, ptr %l147
  br label %bb59
bb59:
  %t269 = load i1, ptr %l147, !tbaa !21
  br i1 %t269, label %bb60, label %bb61
bb60:
  %t270 = call ptr @__olang_scope_hold(ptr %s0)
  %t271 = ptrtoint ptr %t270 to i64
  store i64 %t271, ptr %l148, !tbaa !24
  %t272 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t272, label %bb62, label %bb63
bb61:
  br label %bb70
bb62:
  %t274 = call ptr @__olang_region_make(ptr %s0)
  %t275 = ptrtoint ptr %t274 to i64
  store i64 %t275, ptr %l148, !tbaa !24
  br label %bb63
bb63:
  %t276 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = extractvalue { i64, ptr } %t276, 0
  %t281 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t285 = extractvalue { i64, ptr } %t277, 1
  %t286 = extractvalue { i64, ptr } %t277, 0
  %t287 = add i64 %t283, %t286
  %t288 = load i64, ptr %l148
  %t289 = inttoptr i64 %t288 to ptr
  %t290 = call ptr @__olang_held_alloc(ptr %t289, i64 %t287)
  call void @olang_textcopy(ptr %t290, ptr %t279, i64 %t280)
  %t291 = getelementptr i8, ptr %t290, i64 %t280
  call void @olang_textcopy(ptr %t291, ptr %t281, i64 %t282)
  %t292 = getelementptr i8, ptr %t291, i64 %t282
  call void @olang_textcopy(ptr %t292, ptr %t285, i64 %t286)
  %t293 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t290, 1
  store { i64, ptr } %t294, ptr %l152, !tbaa !27
  %t295 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t295, label %bb64, label %bb65
bb64:
  %t297 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  %t300 = icmp eq i64 %t298, 0
  br i1 %t300, label %bb66, label %bb67
bb65:
  %t302 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t302, ptr %l156, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t303, ptr %l15, !tbaa !27
  %t304 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t304, label %bb68, label %bb69
bb66:
  store { i64, ptr } zeroinitializer, ptr %l152, !tbaa !27
  br label %bb67
bb67:
  %t306 = load i64, ptr %l148
  %t307 = inttoptr i64 %t306 to ptr
  %t308 = load { i64, ptr }, ptr %l152
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = call ptr @__olang_region_or(ptr %t309, ptr null)
  %t311 = icmp ne ptr %t310, null
  %t312 = select i1 %t311, ptr %t310, ptr null
  call void @__olang_region_settle_in(ptr %t307, ptr %t312)
  br label %bb65
bb68:
  %t313 = load { i64, ptr }, ptr %l156
  %t314 = extractvalue { i64, ptr } %t313, 1
  call void @__olang_region_release(ptr %t314)
  store { i64, ptr } zeroinitializer, ptr %l156
  br label %bb69
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb71:
  %t315 = load i64, ptr %l18, !tbaa !24
  %t318 = add i64 %t315, 1
  store i64 %t318, ptr %l18, !tbaa !24
  br label %bb55
bb72:
  %t320 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t320, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  store i64 %t324, ptr %l23, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t326 = load i64, ptr %l22, !tbaa !24
  %t327 = load i64, ptr %l23, !tbaa !24
  %t330 = icmp slt i64 %t326, %t327
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb75:
  br label %bb76
bb76:
  %t334 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t334, ptr %l168, !tbaa !27
  %t335 = load i64, ptr %l22, !tbaa !24
  %t337 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr { i64, ptr }, ptr %t338, i64 %t335
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !37
  store { i64, ptr } %t340, ptr %l24, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t344 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s14, { i64, ptr } %t342, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t344, ptr %l172
  br label %bb77
bb77:
  %t345 = load i1, ptr %l172, !tbaa !21
  br i1 %t345, label %bb78, label %bb79
bb78:
  %t346 = call ptr @__olang_scope_hold(ptr %s0)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l173, !tbaa !24
  %t348 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t348, label %bb80, label %bb81
bb79:
  br label %bb88
bb80:
  %t350 = call ptr @__olang_region_make(ptr %s0)
  %t351 = ptrtoint ptr %t350 to i64
  store i64 %t351, ptr %l173, !tbaa !24
  br label %bb81
bb81:
  %t352 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = extractvalue { i64, ptr } %t352, 0
  %t357 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t358 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t359 = add i64 %t356, %t358
  %t361 = extractvalue { i64, ptr } %t353, 1
  %t362 = extractvalue { i64, ptr } %t353, 0
  %t363 = add i64 %t359, %t362
  %t364 = load i64, ptr %l173
  %t365 = inttoptr i64 %t364 to ptr
  %t366 = call ptr @__olang_held_alloc(ptr %t365, i64 %t363)
  call void @olang_textcopy(ptr %t366, ptr %t355, i64 %t356)
  %t367 = getelementptr i8, ptr %t366, i64 %t356
  call void @olang_textcopy(ptr %t367, ptr %t357, i64 %t358)
  %t368 = getelementptr i8, ptr %t367, i64 %t358
  call void @olang_textcopy(ptr %t368, ptr %t361, i64 %t362)
  %t369 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t366, 1
  store { i64, ptr } %t370, ptr %l177, !tbaa !27
  %t371 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t371, label %bb82, label %bb83
bb82:
  %t373 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 0
  %t376 = icmp eq i64 %t374, 0
  br i1 %t376, label %bb84, label %bb85
bb83:
  %t378 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t378, ptr %l181, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t379, ptr %l15, !tbaa !27
  %t380 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15
  br i1 %t380, label %bb86, label %bb87
bb84:
  store { i64, ptr } zeroinitializer, ptr %l177, !tbaa !27
  br label %bb85
bb85:
  %t382 = load i64, ptr %l173
  %t383 = inttoptr i64 %t382 to ptr
  %t384 = load { i64, ptr }, ptr %l177
  %t385 = extractvalue { i64, ptr } %t384, 1
  %t386 = call ptr @__olang_region_or(ptr %t385, ptr null)
  %t387 = icmp ne ptr %t386, null
  %t388 = select i1 %t387, ptr %t386, ptr null
  call void @__olang_region_settle_in(ptr %t383, ptr %t388)
  br label %bb83
bb86:
  %t389 = load { i64, ptr }, ptr %l181
  %t390 = extractvalue { i64, ptr } %t389, 1
  call void @__olang_region_release(ptr %t390)
  store { i64, ptr } zeroinitializer, ptr %l181
  br label %bb87
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb89:
  %t391 = load i64, ptr %l22, !tbaa !24
  %t394 = add i64 %t391, 1
  store i64 %t394, ptr %l22, !tbaa !24
  br label %bb73
bb90:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t397 = load ptr, ptr %l2, !tbaa !29
  %t398 = load i64, ptr %l4, !tbaa !24
  %t402 = call { i64, ptr } @compiler_2fexplain_2eAsValueWhere(ptr %v1, ptr %v2, ptr %s0, ptr %t396, ptr %t397, i64 %t398)
  store { i64, ptr } %t402, ptr %l189
  br label %bb91
bb91:
  %t403 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t405 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t403, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t405, ptr %l191
  br label %bb92
bb92:
  %t406 = load i1, ptr %l191, !tbaa !21
  %t407 = xor i1 %t406, true
  store ptr %a0, ptr %l193, !tbaa !29
  store { i64, ptr } %a5, ptr %l194, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t411, ptr %l195, !tbaa !27
  br i1 %t407, label %bb93, label %bb94
bb93:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb95
bb94:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb95
bb95:
  %t414 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t414, 1
  %t416 = extractvalue { i64, ptr } %t414, 0
  %t417 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t419 = add i64 %t416, %t418
  %t420 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 1
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t423 = add i64 %t419, %t422
  %t424 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = add i64 %t423, %t426
  %t428 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t429 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t430 = add i64 %t427, %t429
  %t431 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t430)
  call void @olang_textcopy(ptr %t431, ptr %t415, i64 %t416)
  %t432 = getelementptr i8, ptr %t431, i64 %t416
  call void @olang_textcopy(ptr %t432, ptr %t417, i64 %t418)
  %t433 = getelementptr i8, ptr %t432, i64 %t418
  call void @olang_textcopy(ptr %t433, ptr %t421, i64 %t422)
  %t434 = getelementptr i8, ptr %t433, i64 %t422
  call void @olang_textcopy(ptr %t434, ptr %t425, i64 %t426)
  %t435 = getelementptr i8, ptr %t434, i64 %t426
  call void @olang_textcopy(ptr %t435, ptr %t428, i64 %t429)
  %t436 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t431, 1
  %t439 = load ptr, ptr %l193, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t439, { i64, ptr } %t437)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l41 = alloca i32
  %l43 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i64
  %l81 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca i64
  %l97 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l125 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i64
  %l153 = alloca i64
  %l158 = alloca i64
  %l161 = alloca ptr
  %l165 = alloca i32
  %l171 = alloca i32
  %l172 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l184 = alloca i32
  %l185 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t3)
  store i64 %t5, ptr %l22
  br label %bb2
bb2:
  %t6 = load i64, ptr %l22, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t10, i64 %t6)
  store i64 %t14, ptr %l26
  br label %bb3
bb3:
  %t15 = load i64, ptr %l26, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t21, i64 %t22, i32 0)
  store i64 %t25, ptr %l31
  br label %bb6
bb5:
  br label %bb19
bb6:
  %t26 = load i64, ptr %l31, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l34
  br label %bb7
bb7:
  %t32 = load i64, ptr %l34, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l35, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l36, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l37, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l41
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l36, !tbaa !29
  %t45 = load i64, ptr %l37, !tbaa !24
  %t46 = load i32, ptr %l41, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t44, i64 %t45, i32 %t46, i64 %t43)
  store { i64, ptr } %t48, ptr %l43
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = getelementptr i8, ptr %t55, i64 %t51
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t60, { i64, ptr } %t58)
  br label %bb10
bb10:
  store ptr %l3, ptr %l46, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l47, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l51
  br label %bb11
bb11:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l2, !tbaa !24
  %t78 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l55
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l46, !tbaa !29
  %t80 = load ptr, ptr %l47, !tbaa !29
  %t81 = load ptr, ptr %l51, !tbaa !29
  %t82 = load i64, ptr %l55, !tbaa !24
  call void @compiler_2fexplain_2erequires(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t79, ptr %t80, ptr %t81, i64 %t82, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb13
bb13:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t83, ptr %t84, i64 %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb14
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t92 = load i64, ptr %l2, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2enoValue(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t90, ptr %t91, i64 %t92, i64 %t93, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb15
bb15:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %s0, ptr %v0, ptr %s1, ptr %l3, ptr %t99, i64 %t100, i64 %t101, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb16
bb16:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t108 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2etwinLines(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t106, ptr %t107, i64 %t108, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb17
bb17:
  %t114 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t114, ptr %l74
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb19:
  store ptr %l3, ptr %l75, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l76, !tbaa !29
  %t117 = load i64, ptr %l2, !tbaa !24
  store i64 %t117, ptr %l77, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l2, !tbaa !24
  %t125 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t121, i64 %t122)
  store i32 %t125, ptr %l81
  br label %bb20
bb20:
  %t126 = load ptr, ptr %l76, !tbaa !29
  %t127 = load i64, ptr %l77, !tbaa !24
  %t128 = load i32, ptr %l81, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t126, i64 %t127, i32 %t128, i64 -1)
  store { i64, ptr } %t129, ptr %l82
  br label %bb21
bb21:
  %t130 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t131, i64 %t132)
  %t137 = getelementptr i8, ptr %t136, i64 %t132
  call void @olang_textcopy(ptr %t137, ptr %t133, i64 %t134)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t141 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t141, { i64, ptr } %t139)
  br label %bb22
bb22:
  store ptr %l3, ptr %l85, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l86, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i64, ptr %l2, !tbaa !24
  %t151 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t147, i64 %t148)
  store ptr %t151, ptr %l90
  br label %bb23
bb23:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l2, !tbaa !24
  %t159 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t155, i64 %t156)
  store i64 %t159, ptr %l94
  br label %bb24
bb24:
  %t160 = load ptr, ptr %l85, !tbaa !29
  %t161 = load ptr, ptr %l86, !tbaa !29
  %t162 = load ptr, ptr %l90, !tbaa !29
  %t163 = load i64, ptr %l94, !tbaa !24
  call void @compiler_2fexplain_2erequires(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t160, ptr %t161, ptr %t162, i64 %t163, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l2, !tbaa !24
  %t168 = call { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %s4, ptr %t164, i64 %t165)
  store { i64, ptr } %t168, ptr %l97
  br label %bb26
bb26:
  %t169 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t169, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t175 = load i64, ptr %l8, !tbaa !24
  %t176 = load i64, ptr %l9, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t183 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t183, ptr %l105, !tbaa !27
  %t184 = load i64, ptr %l8, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %t187, i64 %t184
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !37
  %t192 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t195 = extractvalue { i64, ptr } %t189, 1
  %t196 = extractvalue { i64, ptr } %t189, 0
  %t197 = add i64 %t193, %t196
  %t198 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t200 = add i64 %t197, %t199
  %t201 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t200)
  call void @olang_textcopy(ptr %t201, ptr %t192, i64 %t193)
  %t202 = getelementptr i8, ptr %t201, i64 %t193
  call void @olang_textcopy(ptr %t202, ptr %t195, i64 %t196)
  %t203 = getelementptr i8, ptr %t202, i64 %t196
  call void @olang_textcopy(ptr %t203, ptr %t198, i64 %t199)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t201, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l3, { i64, ptr } %t205)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l8, !tbaa !24
  br label %bb27
bb33:
  call void @__olang_scope_close(ptr %s4)
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t216 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fexplain_2enoValue(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t214, ptr %t215, i64 %t216, i64 -1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb34
bb34:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t225 = load i64, ptr %l2, !tbaa !24
  %t228 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t224, i64 %t225)
  store ptr %t228, ptr %l122
  br label %bb35
bb35:
  %t229 = load ptr, ptr %l122, !tbaa !29
  store ptr %t229, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t233)
  store i64 %t235, ptr %l125
  br label %bb36
bb36:
  %t236 = load i64, ptr %l125, !tbaa !24
  store i64 %t236, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t237 = load i64, ptr %l13, !tbaa !24
  %t238 = load i64, ptr %l12, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb37, label %bb38
bb37:
  %t243 = load i64, ptr %l14, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l129, !tbaa !24
  br label %bb42
bb39:
  %t247 = load i64, ptr %l13, !tbaa !24
  %t248 = load i64, ptr %l12, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l14, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l14, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l132, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l132, !tbaa !24
  br label %bb41
bb41:
  %t263 = load i64, ptr %l132, !tbaa !24
  store i64 %t263, ptr %l129, !tbaa !24
  br label %bb42
bb42:
  %t264 = load i64, ptr %l129, !tbaa !24
  store i64 %t264, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t265 = load i64, ptr %l16, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s9)
  br label %bb67
bb45:
  br label %bb46
bb46:
  %t273 = load i64, ptr %l12, !tbaa !24
  %t274 = load i64, ptr %l16, !tbaa !24
  %t275 = load i64, ptr %l14, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l17, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t287 = load i64, ptr %l17, !tbaa !24
  %t290 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t286, i64 %t287)
  store i64 %t290, ptr %l153
  br label %bb47
bb47:
  %t291 = load i64, ptr %l2, !tbaa !24
  %t292 = load i64, ptr %l153, !tbaa !24
  %t294 = icmp ne i64 %t292, %t291
  br i1 %t294, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb49:
  br label %bb50
bb50:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i64, ptr %l17, !tbaa !24
  %t300 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t296, i64 %t297)
  store i64 %t300, ptr %l158
  br label %bb51
bb51:
  %t301 = load i64, ptr %l158, !tbaa !24
  store i64 %t301, ptr %l18, !tbaa !24
  %t302 = load i64, ptr %l18, !tbaa !24
  %t304 = icmp slt i64 %t302, 0
  br i1 %t304, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb53:
  br label %bb54
bb54:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l161, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t311 = load i64, ptr %l17, !tbaa !24
  %t314 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t310, i64 %t311)
  store i32 %t314, ptr %l165
  br label %bb55
bb55:
  %t315 = load ptr, ptr %l11, !tbaa !29
  %t317 = getelementptr %"compiler/ast:Func", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load ptr, ptr %l11, !tbaa !29
  %t321 = getelementptr %"compiler/ast:Func", ptr %t319, i32 0, i32 3
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Sig", ptr %t322, i32 0, i32 0
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !27
  %t326 = load ptr, ptr %l161, !tbaa !29
  %t327 = load i32, ptr %l165, !tbaa !23
  %t330 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t326, i32 %t327, ptr %t318, { i64, ptr } %t325)
  store i32 %t330, ptr %l171
  br label %bb56
bb56:
  %t331 = load i32, ptr %l171, !tbaa !23
  store i32 %t331, ptr %l19, !tbaa !23
  store ptr %l3, ptr %l172, !tbaa !29
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t337 = getelementptr %"compiler/generic:Program", ptr %t335, i32 0, i32 0
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = getelementptr %"compiler/load:Loader", ptr %t338, i32 0, i32 3
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t342 = load ptr, ptr %l11, !tbaa !29
  %t344 = getelementptr %"compiler/ast:Func", ptr %t342, i32 0, i32 2
  %t345 = load i32, ptr %t344, !tbaa !23
  %t348 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s9, ptr %t341, i32 %t345)
  store { i64, ptr } %t348, ptr %l179
  br label %bb57
bb57:
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l180, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t354 = load i64, ptr %l17, !tbaa !24
  %t357 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t353, i64 %t354)
  store i32 %t357, ptr %l184
  br label %bb58
bb58:
  %t358 = load ptr, ptr %l180, !tbaa !29
  %t359 = load i32, ptr %l184, !tbaa !23
  %t360 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s9, ptr %t358, i32 %t359)
  store { i64, ptr } %t360, ptr %l185
  br label %bb59
bb59:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l19, !tbaa !23
  %t363 = load i64, ptr %l18, !tbaa !24
  %t367 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s9, ptr %t361, i32 %t362, i64 %t363)
  store { i64, ptr } %t367, ptr %l189
  br label %bb60
bb60:
  %t368 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t370 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t373 = add i64 %t369, %t372
  %t374 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t381 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t368, i64 %t369)
  %t389 = getelementptr i8, ptr %t388, i64 %t369
  call void @olang_textcopy(ptr %t389, ptr %t371, i64 %t372)
  %t390 = getelementptr i8, ptr %t389, i64 %t372
  call void @olang_textcopy(ptr %t390, ptr %t375, i64 %t376)
  %t391 = getelementptr i8, ptr %t390, i64 %t376
  call void @olang_textcopy(ptr %t391, ptr %t378, i64 %t379)
  %t392 = getelementptr i8, ptr %t391, i64 %t379
  call void @olang_textcopy(ptr %t392, ptr %t382, i64 %t383)
  %t393 = getelementptr i8, ptr %t392, i64 %t383
  call void @olang_textcopy(ptr %t393, ptr %t385, i64 %t386)
  %t394 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t388, 1
  %t397 = load ptr, ptr %l172, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t397, { i64, ptr } %t395)
  br label %bb61
bb61:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load ptr, ptr %l1, !tbaa !29
  %t401 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s9, ptr %l3, ptr %t399, ptr %t400, i64 %t401, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb62
bb62:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t408 = load i32, ptr %l19, !tbaa !23
  %t409 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2efitsLine(ptr %s0, ptr %v0, ptr %v1, ptr %s9, ptr %l3, ptr %t406, ptr %t407, i32 %t408, i64 %t409, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb63
bb63:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load i64, ptr %l2, !tbaa !24
  %t417 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %s0, ptr %v0, ptr %s9, ptr %l3, ptr %t415, i64 %t416, i64 %t417, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb64
bb64:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t424 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fexplain_2etwinLines(ptr %s0, ptr %v0, ptr %v1, ptr %s9, ptr %l3, ptr %t422, ptr %t423, i64 %t424, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  %t429 = load i64, ptr %l16, !tbaa !24
  %t432 = add i64 %t429, 1
  store i64 %t432, ptr %l16, !tbaa !24
  br label %bb43
bb67:
  %t435 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t435, ptr %l213
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t436 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t436, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i8
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i64
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l86 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l96 = alloca i64
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l116 = alloca i32
  %l118 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l133 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l147 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca i64
  %l156 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l164 = alloca i1
  %l165 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i64
  %l179 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l188 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l196 = alloca i1
  %l197 = alloca i1
  %l199 = alloca i1
  %l201 = alloca i64
  %l202 = alloca i64
  %l215 = alloca i64
  %l218 = alloca i64
  %l227 = alloca i64
  %l230 = alloca i1
  %l240 = alloca { i64, ptr }
  %l245 = alloca i1
  %l253 = alloca i1
  %l256 = alloca i1
  %l264 = alloca i1
  %l267 = alloca i1
  %l270 = alloca i1
  %l273 = alloca i1
  %l279 = alloca i1
  %l280 = alloca { i64, ptr }
  %l289 = alloca i64
  %l295 = alloca i64
  %l296 = alloca i64
  %l300 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l302 = alloca i64
  %l303 = alloca i64
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l309 = alloca i64
  %l312 = alloca i64
  %l313 = alloca i64
  %l319 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l328 = alloca i1
  %l329 = alloca { i64, ptr }
  %l331 = alloca i64
  %l332 = alloca ptr
  %l333 = alloca i64
  %l334 = alloca i64
  %l338 = alloca { i64, ptr }
  %l341 = alloca { i64, ptr }
  %l345 = alloca i64
  %l350 = alloca i64
  %l351 = alloca { i64, ptr }
  %l352 = alloca i64
  %l354 = alloca i64
  %l355 = alloca i64
  %l369 = alloca i64
  %l370 = alloca i64
  %l371 = alloca i64
  %l379 = alloca { i64, ptr }
  %l381 = alloca i64
  %l383 = alloca i64
  %l384 = alloca i64
  %l389 = alloca i64
  %l391 = alloca i64
  %l392 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l30
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l30, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = call ptr @__olang_scope_hold(ptr %s0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l31, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e5
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = call ptr @__olang_region_make(ptr %s0)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l31, !tbaa !24
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 3
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t25, i32 %t29)
  store { i64, ptr } %t32, ptr %l39
  br label %bb4
bb4:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l40, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t34)
  store i64 %t36, ptr %l42
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l45
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l40, !tbaa !29
  %t43 = load i64, ptr %l42, !tbaa !24
  %t44 = load i64, ptr %l45, !tbaa !24
  %t45 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t42, i64 %t43, i64 %t44)
  store { i64, ptr } %t45, ptr %l46
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = load i64, ptr %l31
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  call void @olang_textcopy(ptr %t55, ptr %t47, i64 %t48)
  %t56 = getelementptr i8, ptr %t55, i64 %t48
  call void @olang_textcopy(ptr %t56, ptr %t50, i64 %t51)
  %t57 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l47, !tbaa !27
  %t59 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e5
  br i1 %t59, label %bb8, label %bb9
bb8:
  %t61 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  %t64 = icmp eq i64 %t62, 0
  br i1 %t64, label %bb10, label %bb11
bb9:
  %t66 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t67)
  store i1 %t69, ptr %l52
  br label %bb12
bb10:
  store { i64, ptr } zeroinitializer, ptr %l47, !tbaa !27
  br label %bb11
bb11:
  %t70 = load i64, ptr %l31
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = load { i64, ptr }, ptr %l47
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = call ptr @__olang_region_or(ptr %t73, ptr null)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr null
  call void @__olang_region_settle_in(ptr %t71, ptr %t76)
  br label %bb9
bb12:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/load:Loader", ptr %t84, i32 0, i32 10
  store ptr %t86, ptr %l56, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l60
  br label %bb15
bb14:
  br label %bb42
bb15:
  %t95 = load ptr, ptr %l56, !tbaa !29
  %t96 = load i64, ptr %l60, !tbaa !24
  %t97 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t97, ptr %l61
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l61, !tbaa !29
  %t100 = getelementptr %"compiler/load:Module", ptr %t98, i32 0, i32 6
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l6, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fc7f64fd7b454af3_cf2a3e2278d9fc1f)
  unreachable
bb18:
  br label %bb19
bb19:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/source:Source", ptr %t107, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l7, !tbaa !27
  %t113 = load ptr, ptr %l4, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Func", ptr %t113, i32 0, i32 8
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  br i1 %t118, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_499d9639469ba124_2d1e6838c6dcdf80)
  unreachable
bb21:
  br label %bb22
bb22:
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Func", ptr %t120, i32 0, i32 8
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t123)
  store %"compiler/source:Span" %t125, ptr %l74
  br label %bb23
bb23:
  %t126 = load %"compiler/source:Span", ptr %l74
  store %"compiler/source:Span" %t126, ptr %l8
  %t127 = call ptr @__olang_scope_hold(ptr %s0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l75, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e5
  br i1 %t129, label %bb24, label %bb25
bb24:
  %t131 = call ptr @__olang_region_make(ptr %s0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l75, !tbaa !24
  br label %bb25
bb25:
  %t133 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t133, ptr %l77, !tbaa !27
  %t134 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t135 = load i32, ptr %t134, !tbaa !23
  %t137 = sext i32 %t135 to i64
  store i64 %t137, ptr %l79, !tbaa !24
  %t138 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t139 = load i32, ptr %t138, !tbaa !23
  %t141 = sext i32 %t139 to i64
  store i64 %t141, ptr %l81, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l82, !tbaa !24
  %t144 = load i64, ptr %l79, !tbaa !24
  %t145 = icmp sge i64 %t144, 0
  br i1 %t145, label %bb26, label %bb27
bb26:
  %t147 = load i64, ptr %l79, !tbaa !24
  %t148 = load i64, ptr %l81, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb28:
  %t151 = load i64, ptr %l81, !tbaa !24
  %t152 = load i64, ptr %l82, !tbaa !24
  %t153 = icmp sle i64 %t151, %t152
  br i1 %t153, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb30:
  %t155 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l79, !tbaa !24
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = getelementptr i8, ptr %t156, i64 %t157
  %t160 = sub i64 %t158, %t157
  %t161 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  store { i64, ptr } %t162, ptr %l86, !tbaa !27
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 3
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = getelementptr %"compiler/ast:Func", ptr %t173, i32 0, i32 9
  %t176 = load i32, ptr %t175, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t172, i32 %t176)
  store { i64, ptr } %t179, ptr %l93
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb32:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l94, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t183 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t181)
  store i64 %t183, ptr %l96
  br label %bb33
bb33:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i64, ptr %l1, !tbaa !24
  %t191 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l100
  br label %bb34
bb34:
  %t192 = load ptr, ptr %l94, !tbaa !29
  %t193 = load i64, ptr %l96, !tbaa !24
  %t194 = load i64, ptr %l100, !tbaa !24
  %t195 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s2, ptr %t192, i64 %t193, i64 %t194)
  store { i64, ptr } %t195, ptr %l101
  br label %bb35
bb35:
  %t196 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t202 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = add i64 %t201, %t204
  %t206 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = load i64, ptr %l75
  %t211 = inttoptr i64 %t210 to ptr
  %t212 = call ptr @__olang_held_alloc(ptr %t211, i64 %t209)
  call void @olang_textcopy(ptr %t212, ptr %t197, i64 %t198)
  %t213 = getelementptr i8, ptr %t212, i64 %t198
  call void @olang_textcopy(ptr %t213, ptr %t199, i64 %t200)
  %t214 = getelementptr i8, ptr %t213, i64 %t200
  call void @olang_textcopy(ptr %t214, ptr %t203, i64 %t204)
  %t215 = getelementptr i8, ptr %t214, i64 %t204
  call void @olang_textcopy(ptr %t215, ptr %t207, i64 %t208)
  %t216 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t212, 1
  store { i64, ptr } %t217, ptr %l102, !tbaa !27
  %t218 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e5
  br i1 %t218, label %bb36, label %bb37
bb36:
  %t220 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t223 = icmp eq i64 %t221, 0
  br i1 %t223, label %bb38, label %bb39
bb37:
  %t225 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t225, ptr %l106, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t226, ptr %l5, !tbaa !27
  %t227 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e5
  br i1 %t227, label %bb40, label %bb41
bb38:
  store { i64, ptr } zeroinitializer, ptr %l102, !tbaa !27
  br label %bb39
bb39:
  %t229 = load i64, ptr %l75
  %t230 = inttoptr i64 %t229 to ptr
  %t231 = load { i64, ptr }, ptr %l102
  %t232 = extractvalue { i64, ptr } %t231, 1
  %t233 = call ptr @__olang_region_or(ptr %t232, ptr null)
  %t234 = icmp ne ptr %t233, null
  %t235 = select i1 %t234, ptr %t233, ptr null
  call void @__olang_region_settle_in(ptr %t230, ptr %t235)
  br label %bb37
bb40:
  %t236 = load { i64, ptr }, ptr %l106
  %t237 = extractvalue { i64, ptr } %t236, 1
  call void @__olang_region_release(ptr %t237)
  store { i64, ptr } zeroinitializer, ptr %l106
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l108, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l2, !tbaa !23
  %t241 = load ptr, ptr %l4, !tbaa !29
  %t243 = getelementptr %"compiler/ast:Func", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Func", ptr %t245, i32 0, i32 3
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/ast:Sig", ptr %t248, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t256 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t239, i32 %t240, ptr %t244, { i64, ptr } %t251)
  store i32 %t256, ptr %l116
  br label %bb43
bb43:
  %t258 = load ptr, ptr %l108, !tbaa !29
  %t259 = load i32, ptr %l116, !tbaa !23
  %t261 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t258, i32 %t259, i64 %a3)
  store { i64, ptr } %t261, ptr %l118
  br label %bb44
bb44:
  %t262 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t262, ptr %l9, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/check:Checker", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load i64, ptr %l1, !tbaa !24
  %t270 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t266, i64 %t267)
  store i1 %t270, ptr %l122
  br label %bb45
bb45:
  %t271 = load i1, ptr %l122, !tbaa !21
  br i1 %t271, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s4
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l123, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l2, !tbaa !23
  %t282 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t278, i32 %t279)
  store i32 %t282, ptr %l128
  br label %bb48
bb47:
  br label %bb191
bb48:
  %t283 = load ptr, ptr %l123, !tbaa !29
  %t284 = load i32, ptr %l128, !tbaa !23
  %t285 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t283, i32 %t284)
  store { i64, ptr } %t285, ptr %l129
  br label %bb49
bb49:
  %t286 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t286, ptr %l10, !tbaa !27
  %t287 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t291 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t287, { i64, ptr } %t288)
  store i1 %t291, ptr %l132
  br label %bb50
bb50:
  %t292 = load i1, ptr %l132, !tbaa !21
  br i1 %t292, label %bb51, label %bb52
bb51:
  %t293 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s4, { i64, ptr } %t293, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t295, ptr %l135
  br label %bb53
bb52:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb54
bb53:
  %t296 = load i1, ptr %l135, !tbaa !21
  store i1 %t296, ptr %l133, !tbaa !21
  br label %bb54
bb54:
  %t297 = load i1, ptr %l133, !tbaa !21
  br i1 %t297, label %bb55, label %bb56
bb55:
  %t298 = call ptr @__olang_scope_hold(ptr %s0)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l136, !tbaa !24
  %t300 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t300, label %bb57, label %bb58
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t302 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t306 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t302, { i64, ptr } %t303)
  store i1 %t306, ptr %l164
  br label %bb77
bb57:
  %t307 = call ptr @__olang_region_make(ptr %s0)
  %t308 = ptrtoint ptr %t307 to i64
  store i64 %t308, ptr %l136, !tbaa !24
  br label %bb58
bb58:
  %t309 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t317 = sub i64 %t311, %t314
  store i64 %t317, ptr %l142, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 0
  store i64 %t319, ptr %l143, !tbaa !24
  %t320 = icmp sge i64 0, 0
  br i1 %t320, label %bb59, label %bb60
bb59:
  %t322 = load i64, ptr %l142, !tbaa !24
  %t323 = icmp sle i64 0, %t322
  br i1 %t323, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb61:
  %t325 = load i64, ptr %l142, !tbaa !24
  %t326 = load i64, ptr %l143, !tbaa !24
  %t327 = icmp sle i64 %t325, %t326
  br i1 %t327, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb63:
  %t329 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l142, !tbaa !24
  %t332 = getelementptr i8, ptr %t330, i64 0
  %t333 = sub i64 %t331, 0
  %t334 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t332, 1
  store { i64, ptr } %t335, ptr %l147, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t336, 0
  store i64 %t338, ptr %l149, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l150, !tbaa !24
  %t341 = icmp sge i64 9, 0
  br i1 %t341, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb65:
  %t343 = load i64, ptr %l149, !tbaa !24
  %t344 = icmp sle i64 9, %t343
  br i1 %t344, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb67:
  %t346 = load i64, ptr %l149, !tbaa !24
  %t347 = load i64, ptr %l150, !tbaa !24
  %t348 = icmp sle i64 %t346, %t347
  br i1 %t348, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb69:
  %t350 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = load i64, ptr %l149, !tbaa !24
  %t353 = getelementptr i8, ptr %t351, i64 9
  %t354 = sub i64 %t352, 9
  %t355 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t353, 1
  %t357 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t362 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t363 = add i64 %t360, %t362
  %t365 = extractvalue { i64, ptr } %t356, 1
  %t366 = extractvalue { i64, ptr } %t356, 0
  %t367 = add i64 %t363, %t366
  %t368 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t370 = add i64 %t367, %t369
  %t372 = extractvalue { i64, ptr } %t357, 1
  %t373 = extractvalue { i64, ptr } %t357, 0
  %t374 = add i64 %t370, %t373
  %t375 = load i64, ptr %l136
  %t376 = inttoptr i64 %t375 to ptr
  %t377 = call ptr @__olang_held_alloc(ptr %t376, i64 %t374)
  call void @olang_textcopy(ptr %t377, ptr %t359, i64 %t360)
  %t378 = getelementptr i8, ptr %t377, i64 %t360
  call void @olang_textcopy(ptr %t378, ptr %t361, i64 %t362)
  %t379 = getelementptr i8, ptr %t378, i64 %t362
  call void @olang_textcopy(ptr %t379, ptr %t365, i64 %t366)
  %t380 = getelementptr i8, ptr %t379, i64 %t366
  call void @olang_textcopy(ptr %t380, ptr %t368, i64 %t369)
  %t381 = getelementptr i8, ptr %t380, i64 %t369
  call void @olang_textcopy(ptr %t381, ptr %t372, i64 %t373)
  %t382 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t377, 1
  store { i64, ptr } %t383, ptr %l156, !tbaa !27
  %t384 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t384, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb71:
  %t386 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 0
  %t389 = icmp eq i64 %t387, 0
  br i1 %t389, label %bb73, label %bb74
bb72:
  %t391 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t391, ptr %l160, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t392, ptr %l9, !tbaa !27
  %t393 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t393, label %bb75, label %bb76
bb73:
  store { i64, ptr } zeroinitializer, ptr %l156, !tbaa !27
  br label %bb74
bb74:
  %t395 = load i64, ptr %l136
  %t396 = inttoptr i64 %t395 to ptr
  %t397 = load { i64, ptr }, ptr %l156
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = call ptr @__olang_region_or(ptr %t398, ptr null)
  %t400 = icmp ne ptr %t399, null
  %t401 = select i1 %t400, ptr %t399, ptr null
  call void @__olang_region_settle_in(ptr %t396, ptr %t401)
  br label %bb72
bb75:
  %t402 = load { i64, ptr }, ptr %l160
  %t403 = extractvalue { i64, ptr } %t402, 1
  call void @__olang_region_release(ptr %t403)
  store { i64, ptr } zeroinitializer, ptr %l160
  br label %bb76
bb76:
  br label %bb190
bb77:
  %t404 = load i1, ptr %l164, !tbaa !21
  br i1 %t404, label %bb78, label %bb79
bb78:
  %t405 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t407 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s7, { i64, ptr } %t405, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t407, ptr %l167
  br label %bb80
bb79:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb81
bb80:
  %t408 = load i1, ptr %l167, !tbaa !21
  store i1 %t408, ptr %l165, !tbaa !21
  br label %bb81
bb81:
  %t409 = load i1, ptr %l165, !tbaa !21
  br i1 %t409, label %bb82, label %bb83
bb82:
  %t410 = call ptr @__olang_scope_hold(ptr %s0)
  %t411 = ptrtoint ptr %t410 to i64
  store i64 %t411, ptr %l168, !tbaa !24
  %t412 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t412, label %bb84, label %bb85
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t414 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t418 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s4, { i64, ptr } %t414, { i64, ptr } %t415)
  store i1 %t418, ptr %l196
  br label %bb104
bb84:
  %t419 = call ptr @__olang_region_make(ptr %s0)
  %t420 = ptrtoint ptr %t419 to i64
  store i64 %t420, ptr %l168, !tbaa !24
  br label %bb85
bb85:
  %t421 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t421, 0
  %t424 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t429 = sub i64 %t423, %t426
  store i64 %t429, ptr %l174, !tbaa !24
  %t430 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t431 = extractvalue { i64, ptr } %t430, 0
  store i64 %t431, ptr %l175, !tbaa !24
  %t432 = icmp sge i64 0, 0
  br i1 %t432, label %bb86, label %bb87
bb86:
  %t434 = load i64, ptr %l174, !tbaa !24
  %t435 = icmp sle i64 0, %t434
  br i1 %t435, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb88:
  %t437 = load i64, ptr %l174, !tbaa !24
  %t438 = load i64, ptr %l175, !tbaa !24
  %t439 = icmp sle i64 %t437, %t438
  br i1 %t439, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb90:
  %t441 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = load i64, ptr %l174, !tbaa !24
  %t444 = getelementptr i8, ptr %t442, i64 0
  %t445 = sub i64 %t443, 0
  %t446 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t444, 1
  store { i64, ptr } %t447, ptr %l179, !tbaa !27
  %t448 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t448, 0
  store i64 %t450, ptr %l181, !tbaa !24
  %t451 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  store i64 %t452, ptr %l182, !tbaa !24
  %t453 = icmp sge i64 16, 0
  br i1 %t453, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb92:
  %t455 = load i64, ptr %l181, !tbaa !24
  %t456 = icmp sle i64 16, %t455
  br i1 %t456, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb94:
  %t458 = load i64, ptr %l181, !tbaa !24
  %t459 = load i64, ptr %l182, !tbaa !24
  %t460 = icmp sle i64 %t458, %t459
  br i1 %t460, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb96:
  %t462 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = load i64, ptr %l181, !tbaa !24
  %t465 = getelementptr i8, ptr %t463, i64 16
  %t466 = sub i64 %t464, 16
  %t467 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t465, 1
  %t469 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t470 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t470, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t474 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t475 = add i64 %t472, %t474
  %t477 = extractvalue { i64, ptr } %t468, 1
  %t478 = extractvalue { i64, ptr } %t468, 0
  %t479 = add i64 %t475, %t478
  %t480 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t481 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t482 = add i64 %t479, %t481
  %t484 = extractvalue { i64, ptr } %t469, 1
  %t485 = extractvalue { i64, ptr } %t469, 0
  %t486 = add i64 %t482, %t485
  %t487 = load i64, ptr %l168
  %t488 = inttoptr i64 %t487 to ptr
  %t489 = call ptr @__olang_held_alloc(ptr %t488, i64 %t486)
  call void @olang_textcopy(ptr %t489, ptr %t471, i64 %t472)
  %t490 = getelementptr i8, ptr %t489, i64 %t472
  call void @olang_textcopy(ptr %t490, ptr %t473, i64 %t474)
  %t491 = getelementptr i8, ptr %t490, i64 %t474
  call void @olang_textcopy(ptr %t491, ptr %t477, i64 %t478)
  %t492 = getelementptr i8, ptr %t491, i64 %t478
  call void @olang_textcopy(ptr %t492, ptr %t480, i64 %t481)
  %t493 = getelementptr i8, ptr %t492, i64 %t481
  call void @olang_textcopy(ptr %t493, ptr %t484, i64 %t485)
  %t494 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t489, 1
  store { i64, ptr } %t495, ptr %l188, !tbaa !27
  %t496 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t496, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_904aca603cad2e45_e62ac09e4cb76009)
  unreachable
bb98:
  %t498 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 0
  %t501 = icmp eq i64 %t499, 0
  br i1 %t501, label %bb100, label %bb101
bb99:
  %t503 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t503, ptr %l192, !tbaa !27
  %t504 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t504, ptr %l9, !tbaa !27
  %t505 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t505, label %bb102, label %bb103
bb100:
  store { i64, ptr } zeroinitializer, ptr %l188, !tbaa !27
  br label %bb101
bb101:
  %t507 = load i64, ptr %l168
  %t508 = inttoptr i64 %t507 to ptr
  %t509 = load { i64, ptr }, ptr %l188
  %t510 = extractvalue { i64, ptr } %t509, 1
  %t511 = call ptr @__olang_region_or(ptr %t510, ptr null)
  %t512 = icmp ne ptr %t511, null
  %t513 = select i1 %t512, ptr %t511, ptr null
  call void @__olang_region_settle_in(ptr %t508, ptr %t513)
  br label %bb99
bb102:
  %t514 = load { i64, ptr }, ptr %l192
  %t515 = extractvalue { i64, ptr } %t514, 1
  call void @__olang_region_release(ptr %t515)
  store { i64, ptr } zeroinitializer, ptr %l192
  br label %bb103
bb103:
  br label %bb189
bb104:
  %t516 = load i1, ptr %l196, !tbaa !21
  br i1 %t516, label %bb105, label %bb106
bb105:
  %t517 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t519 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s10, { i64, ptr } %t517, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t519, ptr %l199
  br label %bb107
bb106:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb108
bb107:
  %t520 = load i1, ptr %l199, !tbaa !21
  store i1 %t520, ptr %l197, !tbaa !21
  br label %bb108
bb108:
  %t521 = load i1, ptr %l197, !tbaa !21
  br i1 %t521, label %bb109, label %bb110
bb109:
  %t522 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t522, 0
  store i64 %t524, ptr %l201, !tbaa !24
  %t525 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t525, 0
  store i64 %t526, ptr %l202, !tbaa !24
  %t527 = icmp sge i64 13, 0
  br i1 %t527, label %bb111, label %bb112
bb110:
  br label %bb188
bb111:
  %t529 = load i64, ptr %l201, !tbaa !24
  %t530 = icmp sle i64 13, %t529
  br i1 %t530, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb113:
  %t532 = load i64, ptr %l201, !tbaa !24
  %t533 = load i64, ptr %l202, !tbaa !24
  %t534 = icmp sle i64 %t532, %t533
  br i1 %t534, label %bb115, label %bb116
bb114:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb115:
  %t536 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = load i64, ptr %l201, !tbaa !24
  %t539 = getelementptr i8, ptr %t537, i64 13
  %t540 = sub i64 %t538, 13
  %t541 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t539, 1
  store { i64, ptr } %t542, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t544 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t546 = extractvalue { i64, ptr } %t544, 0
  %t548 = sub i64 %t546, 1
  store i64 %t548, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t550 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t550, 0
  store i64 %t552, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t554 = load i64, ptr %l15, !tbaa !24
  %t555 = load i64, ptr %l14, !tbaa !24
  %t558 = icmp sgt i64 %t554, %t555
  br i1 %t558, label %bb117, label %bb118
bb116:
  call void @__olang_check_failed(ptr @olang_loc_e59c902bb0ddc268_5b11d99e1c27629c)
  unreachable
bb117:
  %t560 = load i64, ptr %l16, !tbaa !24
  %t562 = icmp sgt i64 %t560, 0
  br i1 %t562, label %bb119, label %bb120
bb118:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb122
bb119:
  %t564 = load i64, ptr %l15, !tbaa !24
  %t565 = load i64, ptr %l14, !tbaa !24
  %t568 = sub i64 %t564, %t565
  %t569 = load i64, ptr %l16, !tbaa !24
  %t572 = add i64 %t568, %t569
  %t574 = sub i64 %t572, 1
  %t575 = load i64, ptr %l16, !tbaa !24
  %t578 = sdiv i64 %t574, %t575
  store i64 %t578, ptr %l218, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb121
bb121:
  %t580 = load i64, ptr %l218, !tbaa !24
  store i64 %t580, ptr %l215, !tbaa !24
  br label %bb122
bb122:
  %t581 = load i64, ptr %l215, !tbaa !24
  store i64 %t581, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t582 = load i64, ptr %l17, !tbaa !24
  %t583 = sub i64 %t582, 1
  store i64 %t583, ptr %l227, !tbaa !24
  %t584 = load i64, ptr %l17, !tbaa !24
  %t585 = icmp slt i64 %t584, 2147483648
  %t586 = load i64, ptr %l18, !tbaa !24
  %t587 = icmp sge i64 %t586, 0
  %t590 = and i1 %t585, %t587
  store i1 %t590, ptr %l230, !tbaa !21
  br label %bb123
bb123:
  %t591 = load i64, ptr %l18, !tbaa !24
  %t592 = load i64, ptr %l17, !tbaa !24
  %t595 = icmp slt i64 %t591, %t592
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb124, label %bb125
bb124:
  br label %bb161
bb125:
  br label %bb126
bb126:
  %t599 = load i64, ptr %l14, !tbaa !24
  %t600 = load i64, ptr %l18, !tbaa !24
  %t601 = load i64, ptr %l16, !tbaa !24
  %t604 = mul i64 %t600, %t601
  %t607 = add i64 %t599, %t604
  store i64 %t607, ptr %l19, !tbaa !24
  %t609 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t609, ptr %l240, !tbaa !27
  %t610 = load i64, ptr %l19, !tbaa !24
  %t612 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !27
  %t614 = getelementptr i8, ptr %t613, i64 %t610
  %t615 = load i8, ptr %t614, !tbaa !32
  store i8 %t615, ptr %l20, !tbaa !22
  %t617 = load i8, ptr %l20, !tbaa !22
  %t619 = icmp eq i8 %t617, 60
  br i1 %t619, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb129
bb128:
  %t621 = load i8, ptr %l20, !tbaa !22
  %t623 = icmp eq i8 %t621, 40
  store i1 %t623, ptr %l245, !tbaa !21
  br label %bb129
bb129:
  %t625 = load i1, ptr %l245, !tbaa !21
  br i1 %t625, label %bb130, label %bb131
bb130:
  %t626 = load i64, ptr %l12, !tbaa !24
  %t629 = add i64 %t626, 1
  store i64 %t629, ptr %l12, !tbaa !24
  br label %bb132
bb131:
  br label %bb132
bb132:
  %t631 = load i8, ptr %l20, !tbaa !22
  %t633 = icmp eq i8 %t631, 62
  br i1 %t633, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l253, !tbaa !21
  br label %bb135
bb134:
  %t635 = load i8, ptr %l20, !tbaa !22
  %t637 = icmp eq i8 %t635, 41
  store i1 %t637, ptr %l253, !tbaa !21
  br label %bb135
bb135:
  %t639 = load i1, ptr %l253, !tbaa !21
  br i1 %t639, label %bb136, label %bb137
bb136:
  %t640 = load i64, ptr %l12, !tbaa !24
  %t642 = icmp sgt i64 %t640, 0
  store i1 %t642, ptr %l256, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb138
bb138:
  %t644 = load i1, ptr %l256, !tbaa !21
  br i1 %t644, label %bb139, label %bb140
bb139:
  %t645 = load i64, ptr %l12, !tbaa !24
  %t648 = sub i64 %t645, 1
  store i64 %t648, ptr %l12, !tbaa !24
  br label %bb160
bb140:
  br label %bb141
bb141:
  %t650 = load i64, ptr %l12, !tbaa !24
  %t652 = icmp eq i64 %t650, 0
  br i1 %t652, label %bb142, label %bb143
bb142:
  %t654 = load i8, ptr %l20, !tbaa !22
  %t656 = icmp eq i8 %t654, 62
  br i1 %t656, label %bb144, label %bb145
bb143:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb156
bb144:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb146
bb145:
  %t658 = load i8, ptr %l20, !tbaa !22
  %t660 = icmp eq i8 %t658, 44
  store i1 %t660, ptr %l267, !tbaa !21
  br label %bb146
bb146:
  %t662 = load i1, ptr %l267, !tbaa !21
  br i1 %t662, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l270, !tbaa !21
  br label %bb155
bb148:
  %t663 = load i8, ptr %l20, !tbaa !22
  %t665 = icmp eq i8 %t663, 32
  br i1 %t665, label %bb149, label %bb150
bb149:
  %t667 = load i64, ptr %l19, !tbaa !24
  %t669 = add i64 %t667, 1
  %t670 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t670, 0
  %t675 = icmp slt i64 %t669, %t672
  store i1 %t675, ptr %l273, !tbaa !21
  br label %bb151
bb150:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb151
bb151:
  %t677 = load i1, ptr %l273, !tbaa !21
  br i1 %t677, label %bb152, label %bb153
bb152:
  %t678 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t678, ptr %l280, !tbaa !27
  %t679 = load i64, ptr %l19, !tbaa !24
  %t681 = add i64 %t679, 1
  %t683 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr i8, ptr %t684, i64 %t681
  %t686 = load i8, ptr %t685, !tbaa !32
  %t688 = icmp eq i8 %t686, 63
  store i1 %t688, ptr %l279, !tbaa !21
  br label %bb154
bb153:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb154
bb154:
  %t690 = load i1, ptr %l279, !tbaa !21
  store i1 %t690, ptr %l270, !tbaa !21
  br label %bb155
bb155:
  %t691 = load i1, ptr %l270, !tbaa !21
  store i1 %t691, ptr %l264, !tbaa !21
  br label %bb156
bb156:
  %t692 = load i1, ptr %l264, !tbaa !21
  br i1 %t692, label %bb157, label %bb158
bb157:
  %t693 = load i64, ptr %l19, !tbaa !24
  store i64 %t693, ptr %l13, !tbaa !24
  br label %bb161
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t695 = load i64, ptr %l18, !tbaa !24
  %t698 = add i64 %t695, 1
  store i64 %t698, ptr %l18, !tbaa !24
  br label %bb123
bb161:
  %t700 = call ptr @__olang_scope_hold(ptr %s0)
  %t701 = ptrtoint ptr %t700 to i64
  store i64 %t701, ptr %l289, !tbaa !24
  %t702 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t702, label %bb162, label %bb163
bb162:
  %t704 = call ptr @__olang_region_make(ptr %s0)
  %t705 = ptrtoint ptr %t704 to i64
  store i64 %t705, ptr %l289, !tbaa !24
  br label %bb163
bb163:
  %t706 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t706, 0
  %t709 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t709, 0
  %t714 = sub i64 %t708, %t711
  store i64 %t714, ptr %l295, !tbaa !24
  %t715 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t715, 0
  store i64 %t716, ptr %l296, !tbaa !24
  %t717 = icmp sge i64 0, 0
  br i1 %t717, label %bb164, label %bb165
bb164:
  %t719 = load i64, ptr %l295, !tbaa !24
  %t720 = icmp sle i64 0, %t719
  br i1 %t720, label %bb166, label %bb167
bb165:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb166:
  %t722 = load i64, ptr %l295, !tbaa !24
  %t723 = load i64, ptr %l296, !tbaa !24
  %t724 = icmp sle i64 %t722, %t723
  br i1 %t724, label %bb168, label %bb169
bb167:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb168:
  %t726 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = load i64, ptr %l295, !tbaa !24
  %t729 = getelementptr i8, ptr %t727, i64 0
  %t730 = sub i64 %t728, 0
  %t731 = insertvalue { i64, ptr } undef, i64 %t730, 0
  %t732 = insertvalue { i64, ptr } %t731, ptr %t729, 1
  store { i64, ptr } %t732, ptr %l300, !tbaa !27
  %t733 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t733, ptr %l301, !tbaa !27
  %t734 = load i64, ptr %l13, !tbaa !24
  store i64 %t734, ptr %l302, !tbaa !24
  %t735 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t736 = extractvalue { i64, ptr } %t735, 0
  store i64 %t736, ptr %l303, !tbaa !24
  %t737 = icmp sge i64 0, 0
  br i1 %t737, label %bb170, label %bb171
bb169:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb170:
  %t739 = load i64, ptr %l302, !tbaa !24
  %t740 = icmp sle i64 0, %t739
  br i1 %t740, label %bb172, label %bb173
bb171:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb172:
  %t742 = load i64, ptr %l302, !tbaa !24
  %t743 = load i64, ptr %l303, !tbaa !24
  %t744 = icmp sle i64 %t742, %t743
  br i1 %t744, label %bb174, label %bb175
bb173:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb174:
  %t746 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !27
  %t748 = load i64, ptr %l302, !tbaa !24
  %t749 = getelementptr i8, ptr %t747, i64 0
  %t750 = sub i64 %t748, 0
  %t751 = insertvalue { i64, ptr } undef, i64 %t750, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t749, 1
  store { i64, ptr } %t752, ptr %l307, !tbaa !27
  %t753 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t753, ptr %l308, !tbaa !27
  %t754 = load i64, ptr %l13, !tbaa !24
  store i64 %t754, ptr %l309, !tbaa !24
  %t755 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t758 = extractvalue { i64, ptr } %t755, 0
  store i64 %t758, ptr %l312, !tbaa !24
  %t759 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t760 = extractvalue { i64, ptr } %t759, 0
  store i64 %t760, ptr %l313, !tbaa !24
  %t761 = load i64, ptr %l309, !tbaa !24
  %t762 = icmp sge i64 %t761, 0
  br i1 %t762, label %bb176, label %bb177
bb175:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb176:
  %t764 = load i64, ptr %l309, !tbaa !24
  %t765 = load i64, ptr %l312, !tbaa !24
  %t766 = icmp sle i64 %t764, %t765
  br i1 %t766, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb178:
  %t768 = load i64, ptr %l312, !tbaa !24
  %t769 = load i64, ptr %l313, !tbaa !24
  %t770 = icmp sle i64 %t768, %t769
  br i1 %t770, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb180:
  %t772 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t773 = load ptr, ptr %t772, !tbaa !27
  %t774 = load i64, ptr %l309, !tbaa !24
  %t775 = load i64, ptr %l312, !tbaa !24
  %t776 = getelementptr i8, ptr %t773, i64 %t774
  %t777 = sub i64 %t775, %t774
  %t778 = insertvalue { i64, ptr } undef, i64 %t777, 0
  %t779 = insertvalue { i64, ptr } %t778, ptr %t776, 1
  %t780 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t781 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t782 = extractvalue { i64, ptr } %t781, 1
  %t783 = extractvalue { i64, ptr } %t781, 0
  %t784 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t785 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t786 = add i64 %t783, %t785
  %t787 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t787, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = add i64 %t786, %t789
  %t791 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t792 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t793 = add i64 %t790, %t792
  %t795 = extractvalue { i64, ptr } %t779, 1
  %t796 = extractvalue { i64, ptr } %t779, 0
  %t797 = add i64 %t793, %t796
  %t798 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t799 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t800 = add i64 %t797, %t799
  %t802 = extractvalue { i64, ptr } %t780, 1
  %t803 = extractvalue { i64, ptr } %t780, 0
  %t804 = add i64 %t800, %t803
  %t805 = load i64, ptr %l289
  %t806 = inttoptr i64 %t805 to ptr
  %t807 = call ptr @__olang_held_alloc(ptr %t806, i64 %t804)
  call void @olang_textcopy(ptr %t807, ptr %t782, i64 %t783)
  %t808 = getelementptr i8, ptr %t807, i64 %t783
  call void @olang_textcopy(ptr %t808, ptr %t784, i64 %t785)
  %t809 = getelementptr i8, ptr %t808, i64 %t785
  call void @olang_textcopy(ptr %t809, ptr %t788, i64 %t789)
  %t810 = getelementptr i8, ptr %t809, i64 %t789
  call void @olang_textcopy(ptr %t810, ptr %t791, i64 %t792)
  %t811 = getelementptr i8, ptr %t810, i64 %t792
  call void @olang_textcopy(ptr %t811, ptr %t795, i64 %t796)
  %t812 = getelementptr i8, ptr %t811, i64 %t796
  call void @olang_textcopy(ptr %t812, ptr %t798, i64 %t799)
  %t813 = getelementptr i8, ptr %t812, i64 %t799
  call void @olang_textcopy(ptr %t813, ptr %t802, i64 %t803)
  %t814 = insertvalue { i64, ptr } undef, i64 %t804, 0
  %t815 = insertvalue { i64, ptr } %t814, ptr %t807, 1
  store { i64, ptr } %t815, ptr %l319, !tbaa !27
  %t816 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t816, label %bb182, label %bb183
bb181:
  call void @__olang_check_failed(ptr @olang_loc_f3704e37964cb683_929f8ce39c458747)
  unreachable
bb182:
  %t818 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t819 = extractvalue { i64, ptr } %t818, 0
  %t821 = icmp eq i64 %t819, 0
  br i1 %t821, label %bb184, label %bb185
bb183:
  %t823 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t823, ptr %l323, !tbaa !27
  %t824 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t824, ptr %l9, !tbaa !27
  %t825 = load i1, ptr @olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9
  br i1 %t825, label %bb186, label %bb187
bb184:
  store { i64, ptr } zeroinitializer, ptr %l319, !tbaa !27
  br label %bb185
bb185:
  %t827 = load i64, ptr %l289
  %t828 = inttoptr i64 %t827 to ptr
  %t829 = load { i64, ptr }, ptr %l319
  %t830 = extractvalue { i64, ptr } %t829, 1
  %t831 = call ptr @__olang_region_or(ptr %t830, ptr null)
  %t832 = icmp ne ptr %t831, null
  %t833 = select i1 %t832, ptr %t831, ptr null
  call void @__olang_region_settle_in(ptr %t828, ptr %t833)
  br label %bb183
bb186:
  %t834 = load { i64, ptr }, ptr %l323
  %t835 = extractvalue { i64, ptr } %t834, 1
  call void @__olang_region_release(ptr %t835)
  store { i64, ptr } zeroinitializer, ptr %l323
  br label %bb187
bb187:
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s10)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s7)
  br label %bb190
bb190:
  call void @__olang_scope_close(ptr %s4)
  br label %bb191
bb191:
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t838 = getelementptr %"compiler/check:Checker", ptr %t836, i32 0, i32 1
  %t839 = load ptr, ptr %t838, !tbaa !29
  %t840 = load i64, ptr %l1, !tbaa !24
  %t843 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t839, i64 %t840)
  store i1 %t843, ptr %l328
  br label %bb192
bb192:
  %t844 = load i1, ptr %l328, !tbaa !21
  br i1 %t844, label %bb193, label %bb194
bb193:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l329, !tbaa !27
  br label %bb195
bb194:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l329, !tbaa !27
  br label %bb195
bb195:
  %t845 = load { i64, ptr }, ptr %l329, !tbaa !27
  store { i64, ptr } %t845, ptr %l21, !tbaa !27
  %t846 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t848 = call i64 @compiler_2fexplain_2efirstClose(ptr %s0, { i64, ptr } %t846)
  store i64 %t848, ptr %l331
  br label %bb196
bb196:
  %t849 = load i64, ptr %l331, !tbaa !24
  store i64 %t849, ptr %l22, !tbaa !24
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l332, !tbaa !29
  %t851 = load i64, ptr %l22, !tbaa !24
  store i64 %t851, ptr %l333, !tbaa !24
  %t852 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t852, 0
  store i64 %t853, ptr %l334, !tbaa !24
  %t854 = icmp sge i64 3, 0
  br i1 %t854, label %bb197, label %bb198
bb197:
  %t856 = load i64, ptr %l333, !tbaa !24
  %t857 = icmp sle i64 3, %t856
  br i1 %t857, label %bb199, label %bb200
bb198:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb199:
  %t859 = load i64, ptr %l333, !tbaa !24
  %t860 = load i64, ptr %l334, !tbaa !24
  %t861 = icmp sle i64 %t859, %t860
  br i1 %t861, label %bb201, label %bb202
bb200:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb201:
  %t863 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t864 = load ptr, ptr %t863, !tbaa !27
  %t865 = load i64, ptr %l333, !tbaa !24
  %t866 = getelementptr i8, ptr %t864, i64 3
  %t867 = sub i64 %t865, 3
  %t868 = insertvalue { i64, ptr } undef, i64 %t867, 0
  %t869 = insertvalue { i64, ptr } %t868, ptr %t866, 1
  store { i64, ptr } %t869, ptr %l338, !tbaa !27
  %t870 = load ptr, ptr %l4, !tbaa !29
  %t872 = getelementptr %"compiler/ast:Func", ptr %t870, i32 0, i32 3
  %t873 = load ptr, ptr %t872, !tbaa !29
  %t875 = getelementptr %"compiler/ast:Sig", ptr %t873, i32 0, i32 0
  %t876 = load { i64, ptr }, ptr %t875, !tbaa !27
  store { i64, ptr } %t876, ptr %l341, !tbaa !27
  %t877 = load ptr, ptr %l0, !tbaa !29
  %t879 = getelementptr %"compiler/check:Checker", ptr %t877, i32 0, i32 1
  %t880 = load ptr, ptr %t879, !tbaa !29
  %t881 = load i64, ptr %l1, !tbaa !24
  %t884 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t880, i64 %t881)
  store i64 %t884, ptr %l345
  br label %bb203
bb202:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb203:
  %t885 = load ptr, ptr %l4, !tbaa !29
  %t887 = getelementptr %"compiler/ast:Func", ptr %t885, i32 0, i32 1
  %t888 = load ptr, ptr %t887, !tbaa !29
  %t890 = icmp eq ptr %t888, null
  %t892 = xor i1 %t890, true
  br i1 %t892, label %bb204, label %bb205
bb204:
  store i64 1, ptr %l350, !tbaa !24
  br label %bb206
bb205:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb206
bb206:
  %t894 = load ptr, ptr %l332, !tbaa !29
  %t895 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t896 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t897 = load i64, ptr %l345, !tbaa !24
  %t898 = load i64, ptr %l350, !tbaa !24
  %t899 = call { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %t894, { i64, ptr } %t895, { i64, ptr } %t896, i64 %t897, i64 %t898)
  store { i64, ptr } %t899, ptr %l351
  br label %bb207
bb207:
  %t900 = load i64, ptr %l22, !tbaa !24
  store i64 %t900, ptr %l352, !tbaa !24
  %t901 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t901, 0
  store i64 %t903, ptr %l354, !tbaa !24
  %t904 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t905 = extractvalue { i64, ptr } %t904, 0
  store i64 %t905, ptr %l355, !tbaa !24
  %t906 = load i64, ptr %l352, !tbaa !24
  %t907 = icmp sge i64 %t906, 0
  br i1 %t907, label %bb208, label %bb209
bb208:
  %t909 = load i64, ptr %l352, !tbaa !24
  %t910 = load i64, ptr %l354, !tbaa !24
  %t911 = icmp sle i64 %t909, %t910
  br i1 %t911, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb210:
  %t913 = load i64, ptr %l354, !tbaa !24
  %t914 = load i64, ptr %l355, !tbaa !24
  %t915 = icmp sle i64 %t913, %t914
  br i1 %t915, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb212:
  %t917 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t918 = load ptr, ptr %t917, !tbaa !27
  %t919 = load i64, ptr %l352, !tbaa !24
  %t920 = load i64, ptr %l354, !tbaa !24
  %t921 = getelementptr i8, ptr %t918, i64 %t919
  %t922 = sub i64 %t920, %t919
  %t923 = insertvalue { i64, ptr } undef, i64 %t922, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t921, 1
  %t925 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t926 = extractvalue { i64, ptr } %t925, 1
  %t927 = extractvalue { i64, ptr } %t925, 0
  %t929 = extractvalue { i64, ptr } %t924, 1
  %t930 = extractvalue { i64, ptr } %t924, 0
  %t931 = add i64 %t927, %t930
  %t932 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t931)
  call void @olang_textcopy(ptr %t932, ptr %t926, i64 %t927)
  %t933 = getelementptr i8, ptr %t932, i64 %t927
  call void @olang_textcopy(ptr %t933, ptr %t929, i64 %t930)
  %t934 = insertvalue { i64, ptr } undef, i64 %t931, 0
  %t935 = insertvalue { i64, ptr } %t934, ptr %t932, 1
  store { i64, ptr } %t935, ptr %l23, !tbaa !27
  %t937 = load ptr, ptr %l4, !tbaa !29
  %t939 = getelementptr %"compiler/ast:Func", ptr %t937, i32 0, i32 1
  %t940 = load ptr, ptr %t939, !tbaa !29
  %t942 = icmp eq ptr %t940, null
  br i1 %t942, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_87334f8237d1e26_d87acd2b8515436a)
  unreachable
bb214:
  %t944 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t945 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t946 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t948 = extractvalue { i64, ptr } %t944, 1
  %t949 = extractvalue { i64, ptr } %t944, 0
  %t951 = extractvalue { i64, ptr } %t945, 1
  %t952 = extractvalue { i64, ptr } %t945, 0
  %t953 = add i64 %t949, %t952
  %t954 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t955 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t956 = add i64 %t953, %t955
  %t958 = extractvalue { i64, ptr } %t946, 1
  %t959 = extractvalue { i64, ptr } %t946, 0
  %t960 = add i64 %t956, %t959
  %t961 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t960)
  call void @olang_textcopy(ptr %t961, ptr %t948, i64 %t949)
  %t962 = getelementptr i8, ptr %t961, i64 %t949
  call void @olang_textcopy(ptr %t962, ptr %t951, i64 %t952)
  %t963 = getelementptr i8, ptr %t962, i64 %t952
  call void @olang_textcopy(ptr %t963, ptr %t954, i64 %t955)
  %t964 = getelementptr i8, ptr %t963, i64 %t955
  call void @olang_textcopy(ptr %t964, ptr %t958, i64 %t959)
  %t965 = insertvalue { i64, ptr } undef, i64 %t960, 0
  %t966 = insertvalue { i64, ptr } %t965, ptr %t961, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t966, ptr %rv
  br label %ret
bb215:
  br label %bb216
bb216:
  %t968 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t970 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t968)
  store i64 %t970, ptr %l369
  br label %bb217
bb217:
  %t971 = load i64, ptr %l369, !tbaa !24
  store i64 %t971, ptr %l24, !tbaa !24
  %t972 = load i64, ptr %l24, !tbaa !24
  store i64 %t972, ptr %l370, !tbaa !24
  %t973 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t974 = extractvalue { i64, ptr } %t973, 0
  store i64 %t974, ptr %l371, !tbaa !24
  %t975 = icmp sge i64 0, 0
  br i1 %t975, label %bb218, label %bb219
bb218:
  %t977 = load i64, ptr %l370, !tbaa !24
  %t978 = icmp sle i64 0, %t977
  br i1 %t978, label %bb220, label %bb221
bb219:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb220:
  %t980 = load i64, ptr %l370, !tbaa !24
  %t981 = load i64, ptr %l371, !tbaa !24
  %t982 = icmp sle i64 %t980, %t981
  br i1 %t982, label %bb222, label %bb223
bb221:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb222:
  %t984 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !27
  %t986 = load i64, ptr %l370, !tbaa !24
  %t987 = getelementptr i8, ptr %t985, i64 0
  %t988 = sub i64 %t986, 0
  %t989 = insertvalue { i64, ptr } undef, i64 %t988, 0
  %t990 = insertvalue { i64, ptr } %t989, ptr %t987, 1
  store { i64, ptr } %t990, ptr %l25, !tbaa !27
  %t992 = load i64, ptr %l24, !tbaa !24
  %t994 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !27
  %t996 = getelementptr i8, ptr %t995, i64 %t992
  %t997 = load i8, ptr %t996, !tbaa !32
  %t999 = icmp eq i8 %t997, 44
  br i1 %t999, label %bb224, label %bb225
bb223:
  call void @__olang_check_failed(ptr @olang_loc_96b8876366bd9a81_fe1335b03e31611d)
  unreachable
bb224:
  %t1001 = load i64, ptr %l24, !tbaa !24
  %t1003 = add i64 %t1001, 2
  store i64 %t1003, ptr %l381, !tbaa !24
  %t1004 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t1006 = extractvalue { i64, ptr } %t1004, 0
  store i64 %t1006, ptr %l383, !tbaa !24
  %t1007 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t1008 = extractvalue { i64, ptr } %t1007, 0
  store i64 %t1008, ptr %l384, !tbaa !24
  %t1009 = load i64, ptr %l381, !tbaa !24
  %t1010 = icmp sge i64 %t1009, 0
  br i1 %t1010, label %bb226, label %bb227
bb225:
  %t1012 = load i64, ptr %l24, !tbaa !24
  store i64 %t1012, ptr %l389, !tbaa !24
  %t1013 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t1015 = extractvalue { i64, ptr } %t1013, 0
  store i64 %t1015, ptr %l391, !tbaa !24
  %t1016 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t1017 = extractvalue { i64, ptr } %t1016, 0
  store i64 %t1017, ptr %l392, !tbaa !24
  %t1018 = load i64, ptr %l389, !tbaa !24
  %t1019 = icmp sge i64 %t1018, 0
  br i1 %t1019, label %bb232, label %bb233
bb226:
  %t1021 = load i64, ptr %l381, !tbaa !24
  %t1022 = load i64, ptr %l383, !tbaa !24
  %t1023 = icmp sle i64 %t1021, %t1022
  br i1 %t1023, label %bb228, label %bb229
bb227:
  call void @__olang_check_failed(ptr @olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0)
  unreachable
bb228:
  %t1025 = load i64, ptr %l383, !tbaa !24
  %t1026 = load i64, ptr %l384, !tbaa !24
  %t1027 = icmp sle i64 %t1025, %t1026
  br i1 %t1027, label %bb230, label %bb231
bb229:
  call void @__olang_check_failed(ptr @olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0)
  unreachable
bb230:
  %t1029 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t1030 = load ptr, ptr %t1029, !tbaa !27
  %t1031 = load i64, ptr %l381, !tbaa !24
  %t1032 = load i64, ptr %l383, !tbaa !24
  %t1033 = getelementptr i8, ptr %t1030, i64 %t1031
  %t1034 = sub i64 %t1032, %t1031
  %t1035 = insertvalue { i64, ptr } undef, i64 %t1034, 0
  %t1036 = insertvalue { i64, ptr } %t1035, ptr %t1033, 1
  store { i64, ptr } %t1036, ptr %l379, !tbaa !27
  br label %bb238
bb231:
  call void @__olang_check_failed(ptr @olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0)
  unreachable
bb232:
  %t1038 = load i64, ptr %l389, !tbaa !24
  %t1039 = load i64, ptr %l391, !tbaa !24
  %t1040 = icmp sle i64 %t1038, %t1039
  br i1 %t1040, label %bb234, label %bb235
bb233:
  call void @__olang_check_failed(ptr @olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0)
  unreachable
bb234:
  %t1042 = load i64, ptr %l391, !tbaa !24
  %t1043 = load i64, ptr %l392, !tbaa !24
  %t1044 = icmp sle i64 %t1042, %t1043
  br i1 %t1044, label %bb236, label %bb237
bb235:
  call void @__olang_check_failed(ptr @olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0)
  unreachable
bb236:
  %t1046 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t1047 = load ptr, ptr %t1046, !tbaa !27
  %t1048 = load i64, ptr %l389, !tbaa !24
  %t1049 = load i64, ptr %l391, !tbaa !24
  %t1050 = getelementptr i8, ptr %t1047, i64 %t1048
  %t1051 = sub i64 %t1049, %t1048
  %t1052 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1053 = insertvalue { i64, ptr } %t1052, ptr %t1050, 1
  store { i64, ptr } %t1053, ptr %l379, !tbaa !27
  br label %bb238
bb237:
  call void @__olang_check_failed(ptr @olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0)
  unreachable
bb238:
  %t1055 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t1056 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1057 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t1058 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1061 = extractvalue { i64, ptr } %t1056, 1
  %t1062 = extractvalue { i64, ptr } %t1056, 0
  %t1063 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t1064 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t1065 = add i64 %t1062, %t1064
  %t1067 = extractvalue { i64, ptr } %t1057, 1
  %t1068 = extractvalue { i64, ptr } %t1057, 0
  %t1069 = add i64 %t1065, %t1068
  %t1070 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1071 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1072 = add i64 %t1069, %t1071
  %t1074 = extractvalue { i64, ptr } %t1058, 1
  %t1075 = extractvalue { i64, ptr } %t1058, 0
  %t1076 = add i64 %t1072, %t1075
  %t1077 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t1078 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t1079 = add i64 %t1076, %t1078
  %t1081 = extractvalue { i64, ptr } %t1055, 1
  %t1082 = extractvalue { i64, ptr } %t1055, 0
  %t1083 = add i64 %t1079, %t1082
  %t1084 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t1083)
  call void @olang_textcopy(ptr %t1084, ptr %t1061, i64 %t1062)
  %t1085 = getelementptr i8, ptr %t1084, i64 %t1062
  call void @olang_textcopy(ptr %t1085, ptr %t1063, i64 %t1064)
  %t1086 = getelementptr i8, ptr %t1085, i64 %t1064
  call void @olang_textcopy(ptr %t1086, ptr %t1067, i64 %t1068)
  %t1087 = getelementptr i8, ptr %t1086, i64 %t1068
  call void @olang_textcopy(ptr %t1087, ptr %t1070, i64 %t1071)
  %t1088 = getelementptr i8, ptr %t1087, i64 %t1071
  call void @olang_textcopy(ptr %t1088, ptr %t1074, i64 %t1075)
  %t1089 = getelementptr i8, ptr %t1088, i64 %t1075
  call void @olang_textcopy(ptr %t1089, ptr %t1077, i64 %t1078)
  %t1090 = getelementptr i8, ptr %t1089, i64 %t1078
  call void @olang_textcopy(ptr %t1090, ptr %t1081, i64 %t1082)
  %t1091 = insertvalue { i64, ptr } undef, i64 %t1083, 0
  %t1092 = insertvalue { i64, ptr } %t1091, ptr %t1084, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t1092, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2efnNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/names:Entry"
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l47 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l60 = alloca i64
  %l62 = alloca ptr
  %l66 = alloca i32
  %l68 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i64
  %l99 = alloca i32
  %l105 = alloca ptr
  %l108 = alloca i64
  %l110 = alloca i64
  %l115 = alloca %"compiler/names:Entry"
  %l119 = alloca i1
  %l126 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l19
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb2, label %ok.18, !prof !99
ok.18:
  store i64 %t15, ptr %l18
  br label %bb1
bb1:
  %t19 = load i64, ptr %l18, !tbaa !24
  store i64 %t19, ptr %l16, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb4
bb4:
  %t20 = load i64, ptr %l16, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l24, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l25, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l26, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  br label %bb50
bb7:
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = icmp sle i64 0, %t33
  br i1 %t34, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_83191eb44b7384_f52b74cb91a30b30)
  unreachable
bb9:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp sle i64 %t36, %t37
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_83191eb44b7384_f52b74cb91a30b30)
  unreachable
bb11:
  %t40 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = getelementptr i8, ptr %t41, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = load i64, ptr %l23, !tbaa !24
  %t50 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %t47, i64 %t48, { i64, ptr } %t46)
  store i32 %t50, ptr %l31
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_83191eb44b7384_f52b74cb91a30b30)
  unreachable
bb13:
  %t51 = load i32, ptr %l31, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l3, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = call ptr @__olang_scope_hold(ptr %v0)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = call ptr @__olang_region_or(ptr %t57, ptr %v0)
  %t59 = call ptr @__olang_scope_hold(ptr %t58)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l3, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l36, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l38, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t66, 0
  store i64 %t69, ptr %l41, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l42, !tbaa !24
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = icmp sge i64 %t72, 0
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load i64, ptr %l38, !tbaa !24
  %t76 = load i64, ptr %l41, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d)
  unreachable
bb18:
  %t79 = load i64, ptr %l41, !tbaa !24
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d)
  unreachable
bb20:
  %t83 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l38, !tbaa !24
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = getelementptr i8, ptr %t84, i64 %t85
  %t88 = sub i64 %t86, %t85
  %t89 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t91 = load i64, ptr %l33
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = load ptr, ptr %l35, !tbaa !29
  %t95 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t92, ptr %v1, ptr %t93, { i64, ptr } %t90)
  store i32 %t95, ptr %l47
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d)
  unreachable
bb22:
  %t96 = load i32, ptr %l47, !tbaa !23
  store i32 %t96, ptr %l6, !tbaa !23
  %t97 = load i32, ptr %l5, !tbaa !23
  %t99 = icmp slt i32 %t97, 0
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l50, !tbaa !29
  %t102 = load i64, ptr %l1, !tbaa !24
  store i64 %t102, ptr %l51, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t103, ptr %l52, !tbaa !27
  %t104 = load i64, ptr %l4, !tbaa !24
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l54, !tbaa !24
  %t107 = icmp sge i64 0, 0
  br i1 %t107, label %bb25, label %bb26
bb24:
  br label %bb32
bb25:
  %t109 = load i64, ptr %l53, !tbaa !24
  %t110 = icmp sle i64 0, %t109
  br i1 %t110, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae)
  unreachable
bb27:
  %t112 = load i64, ptr %l53, !tbaa !24
  %t113 = load i64, ptr %l54, !tbaa !24
  %t114 = icmp sle i64 %t112, %t113
  br i1 %t114, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae)
  unreachable
bb29:
  %t116 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l53, !tbaa !24
  %t119 = getelementptr i8, ptr %t117, i64 0
  %t120 = sub i64 %t118, 0
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load i32, ptr %l6, !tbaa !23
  %t124 = load ptr, ptr %l50, !tbaa !29
  %t125 = load i64, ptr %l51, !tbaa !24
  %t128 = call i64 @compiler_2fexplain_2ewrittenMethod(ptr %v0, ptr %v1, ptr %t124, i64 %t125, { i64, ptr } %t122, i32 %t123)
  store i64 %t128, ptr %l60
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t129 = load i64, ptr %l60, !tbaa !24
  store i64 %t129, ptr %rv
  br label %ret
bb32:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  store ptr %t133, ptr %l62, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i32, ptr %l5, !tbaa !23
  %t141 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l66
  br label %bb33
bb33:
  %t142 = load i32, ptr %l6, !tbaa !23
  %t143 = load ptr, ptr %l62, !tbaa !29
  %t144 = load i32, ptr %l66, !tbaa !23
  %t146 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t143, i32 %t144, i32 %t142)
  store i64 %t146, ptr %l68
  br label %bb34
bb34:
  %t147 = load i64, ptr %l68, !tbaa !24
  store i64 %t147, ptr %l7, !tbaa !24
  %t148 = load i64, ptr %l7, !tbaa !24
  %t150 = icmp slt i64 %t148, 0
  br i1 %t150, label %bb35, label %bb36
bb35:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  store ptr %t155, ptr %l72, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i32, ptr %l5, !tbaa !23
  %t163 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l76
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t164 = load i32, ptr %l6, !tbaa !23
  %t165 = load ptr, ptr %l72, !tbaa !29
  %t166 = load i32, ptr %l76, !tbaa !23
  %t168 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t165, i32 %t166, i32 %t164, i1 true)
  store i64 %t168, ptr %l78
  br label %bb38
bb38:
  %t169 = load i64, ptr %l78, !tbaa !24
  store i64 %t169, ptr %l7, !tbaa !24
  br label %bb39
bb39:
  %t170 = load i64, ptr %l7, !tbaa !24
  %t172 = icmp sge i64 %t170, 0
  br i1 %t172, label %bb40, label %bb41
bb40:
  %t174 = load i64, ptr %l7, !tbaa !24
  store i64 %t174, ptr %l81, !tbaa !24
  br label %bb49
bb41:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l83, !tbaa !29
  %t177 = load i64, ptr %l1, !tbaa !24
  store i64 %t177, ptr %l84, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t178, ptr %l85, !tbaa !27
  %t179 = load i64, ptr %l4, !tbaa !24
  store i64 %t179, ptr %l86, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l87, !tbaa !24
  %t182 = icmp sge i64 0, 0
  br i1 %t182, label %bb42, label %bb43
bb42:
  %t184 = load i64, ptr %l86, !tbaa !24
  %t185 = icmp sle i64 0, %t184
  br i1 %t185, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab)
  unreachable
bb44:
  %t187 = load i64, ptr %l86, !tbaa !24
  %t188 = load i64, ptr %l87, !tbaa !24
  %t189 = icmp sle i64 %t187, %t188
  br i1 %t189, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab)
  unreachable
bb46:
  %t191 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l86, !tbaa !24
  %t194 = getelementptr i8, ptr %t192, i64 0
  %t195 = sub i64 %t193, 0
  %t196 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t194, 1
  %t198 = load i32, ptr %l6, !tbaa !23
  %t199 = load ptr, ptr %l83, !tbaa !29
  %t200 = load i64, ptr %l84, !tbaa !24
  %t203 = call i64 @compiler_2fexplain_2ewrittenMethod(ptr %v0, ptr %v1, ptr %t199, i64 %t200, { i64, ptr } %t197, i32 %t198)
  store i64 %t203, ptr %l93
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab)
  unreachable
bb48:
  %t204 = load i64, ptr %l93, !tbaa !24
  store i64 %t204, ptr %l81, !tbaa !24
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load i64, ptr %l81, !tbaa !24
  store i64 %t205, ptr %rv
  br label %ret
bb50:
  %t206 = load ptr, ptr %l3, !tbaa !29
  store ptr %t206, ptr %l94, !tbaa !29
  %t207 = call ptr @__olang_scope_hold(ptr %v0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l95, !tbaa !24
  %t209 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t209, label %bb51, label %bb52
bb51:
  %t211 = load ptr, ptr %l94, !tbaa !29
  %t212 = call ptr @__olang_region_or(ptr %t211, ptr %v0)
  %t213 = call ptr @__olang_scope_hold(ptr %t212)
  %t214 = ptrtoint ptr %t213 to i64
  store i64 %t214, ptr %l95, !tbaa !24
  br label %bb52
bb52:
  %t215 = load ptr, ptr %l3, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t217 = load i64, ptr %l95
  %t218 = inttoptr i64 %t217 to ptr
  %t221 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t218, ptr %v1, ptr %t215, { i64, ptr } %t216)
  store i32 %t221, ptr %l99
  br label %bb53
bb53:
  %t222 = load i32, ptr %l99, !tbaa !23
  store i32 %t222, ptr %l8, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/names:Resolver", ptr %t229, i32 0, i32 1
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t231, i64 %t232)
  store ptr %t235, ptr %l105
  br label %bb54
bb54:
  %t236 = load ptr, ptr %l105, !tbaa !29
  %t238 = getelementptr %"compiler/names:Table", ptr %t236, i32 0, i32 0
  store ptr %t238, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb55
bb55:
  %t240 = load i64, ptr %l10, !tbaa !24
  store i64 %t240, ptr %l108, !tbaa !24
  %t241 = load ptr, ptr %l9, !tbaa !29
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t241)
  store i64 %t243, ptr %l110
  br label %bb56
bb56:
  %t244 = load i64, ptr %l108, !tbaa !24
  %t245 = load i64, ptr %l110, !tbaa !24
  %t246 = icmp slt i64 %t244, %t245
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb57, label %bb58
bb57:
  br label %bb69
bb58:
  br label %bb59
bb59:
  %t250 = load ptr, ptr %l9, !tbaa !29
  %t251 = load i64, ptr %l10, !tbaa !24
  %t254 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t250, i64 %t251)
  store %"compiler/names:Entry" %t254, ptr %l115
  br label %bb60
bb60:
  %t255 = load %"compiler/names:Entry", ptr %l115
  store %"compiler/names:Entry" %t255, ptr %l11
  %t256 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  %t258 = load i32, ptr %l8, !tbaa !23
  %t261 = icmp eq i32 %t257, %t258
  br i1 %t261, label %bb61, label %bb62
bb61:
  %t263 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t264 = load i32, ptr %t263, !range !{i32 0, i32 9}
  %t266 = trunc i64 3 to i32
  %t267 = icmp eq i32 %t264, %t266
  store i1 %t267, ptr %l119, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb63
bb63:
  %t269 = load i1, ptr %l119, !tbaa !21
  br i1 %t269, label %bb64, label %bb65
bb64:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l1, !tbaa !24
  %t275 = load i32, ptr %l8, !tbaa !23
  %t279 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t273, i64 %t274, i32 %t275)
  store i64 %t279, ptr %l126
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t280 = load i64, ptr %l126, !tbaa !24
  store i64 %t280, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t281 = load i64, ptr %l10, !tbaa !24
  %t284 = add i64 %t281, 1
  store i64 %t284, ptr %l10, !tbaa !24
  br label %bb55
bb69:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fexplain_2egenLine(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 5
  %t9 = sext i32 %a2 to i64
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v1, ptr %s0, ptr %t6, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb2, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l10
  br label %bb1
bb1:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %t31, 1
  %t38 = extractvalue { i64, ptr } %t31, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t34, i64 %t35)
  %t44 = getelementptr i8, ptr %t43, i64 %t35
  call void @olang_textcopy(ptr %t44, ptr %t37, i64 %t38)
  %t45 = getelementptr i8, ptr %t44, i64 %t38
  call void @olang_textcopy(ptr %t45, ptr %t40, i64 %t41)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } %t47)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i32
  %l59 = alloca i32
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l18
  br label %bb1
bb1:
  %t20 = load i32, ptr %l18, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l21
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l26
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l35
  br label %bb10
bb10:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t83 = call { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  %t84 = extractvalue { i32, { i64, ptr } } %t83, 1
  %t85 = extractvalue { i32, { i64, ptr } } %t83, 0
  store i32 %t85, ptr %l40
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb12, label %ok.87, !prof !99
ok.87:
  store { i64, ptr } %t84, ptr %l39
  br label %bb11
bb11:
  %t88 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t88, ptr %l36, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t91, i64 %t92)
  %t97 = getelementptr i8, ptr %t96, i64 %t92
  call void @olang_textcopy(ptr %t97, ptr %t93, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t99, ptr %rv
  br label %ret
bb14:
  %t101 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t101, ptr %l8, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l5, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l47
  br label %bb15
bb15:
  %t112 = load i32, ptr %l47, !range !{i32 0, i32 33}
  %t114 = trunc i64 20 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb16, label %bb17
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l5, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l55
  br label %bb18
bb17:
  %t127 = load i32, ptr %l5, !tbaa !23
  store i32 %t127, ptr %l50, !tbaa !23
  br label %bb19
bb18:
  %t129 = load i32, ptr %l55, !tbaa !23
  store i32 %t129, ptr %l50, !tbaa !23
  br label %bb19
bb19:
  %t130 = load i32, ptr %l50, !tbaa !23
  store i32 %t130, ptr %l57, !tbaa !23
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t132)
  store i32 %t134, ptr %l59
  br label %bb20
bb20:
  %t135 = load i32, ptr %l57, !tbaa !23
  %t136 = load i32, ptr %l59, !tbaa !23
  %t137 = icmp eq i32 %t135, %t136
  br i1 %t137, label %bb21, label %bb22
bb21:
  %t139 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s0, { i64, ptr } %t139)
  store { i64, ptr } %t141, ptr %l63
  br label %bb23
bb22:
  %t142 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t144, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t150 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t151, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l61, !tbaa !27
  br label %bb24
bb24:
  %t157 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t157, ptr %l10, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  %t164 = icmp sgt i64 %t160, %t161
  br i1 %t164, label %bb25, label %bb26
bb25:
  %t166 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t166, ptr %l71, !tbaa !27
  %t167 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  store i64 %t167, ptr %l72, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l73, !tbaa !24
  %t170 = icmp sge i64 0, 0
  br i1 %t170, label %bb27, label %bb28
bb26:
  br label %bb33
bb27:
  %t172 = load i64, ptr %l72, !tbaa !24
  %t173 = icmp sle i64 0, %t172
  br i1 %t173, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb29:
  %t175 = load i64, ptr %l72, !tbaa !24
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = icmp sle i64 %t175, %t176
  br i1 %t177, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb31:
  %t179 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l72, !tbaa !24
  %t182 = getelementptr i8, ptr %t180, i64 0
  %t183 = sub i64 %t181, 0
  %t184 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = extractvalue { i64, ptr } %t185, 1
  %t197 = extractvalue { i64, ptr } %t185, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t204 = add i64 %t201, %t203
  %t205 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t190, i64 %t191)
  %t209 = getelementptr i8, ptr %t208, i64 %t191
  call void @olang_textcopy(ptr %t209, ptr %t192, i64 %t193)
  %t210 = getelementptr i8, ptr %t209, i64 %t193
  call void @olang_textcopy(ptr %t210, ptr %t196, i64 %t197)
  %t211 = getelementptr i8, ptr %t210, i64 %t197
  call void @olang_textcopy(ptr %t211, ptr %t199, i64 %t200)
  %t212 = getelementptr i8, ptr %t211, i64 %t200
  %t213 = call i64 @__olang_fmt_i64(ptr %t212, i64 %t188)
  %t214 = getelementptr i8, ptr %t212, i64 %t203
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t208, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb33:
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = extractvalue { i64, ptr } %t218, 0
  %t223 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t227 = extractvalue { i64, ptr } %t219, 1
  %t228 = extractvalue { i64, ptr } %t219, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t223, i64 %t224)
  %t235 = getelementptr i8, ptr %t234, i64 %t224
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = getelementptr i8, ptr %t235, i64 %t228
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t233, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i64
  %l32 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store ptr %l2, ptr %l22, !tbaa !29
  store { i64, ptr } %a0, ptr %l23, !tbaa !27
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l29
  br label %bb12
bb12:
  %t42 = getelementptr %"compiler/source:Span", ptr %l29, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb15:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t67 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t67, { i64, ptr } %t66)
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb2
bb21:
  %t75 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t75, ptr %l41
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i32
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l119 = alloca i32
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l131 = alloca i64
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca i64
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s2, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  %t136 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t138 = trunc i64 20 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l82
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l10, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l87
  br label %bb29
bb29:
  %t162 = load i32, ptr %l87, !range !{i32 0, i32 33}
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb34
bb31:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %l10, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l96
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l101
  br label %bb33
bb33:
  %t189 = load i32, ptr %l96, !tbaa !23
  %t190 = load i32, ptr %l101, !tbaa !23
  %t191 = icmp ne i32 %t189, %t190
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb36:
  br label %bb37
bb37:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t198)
  store i64 %t200, ptr %l106
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l107
  br label %bb39
bb39:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t210, i64 %t211, i32 0)
  store i64 %t214, ptr %l112
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l132, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l133, !tbaa !29
  %t217 = load i64, ptr %l8, !tbaa !24
  store i64 %t217, ptr %l134, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l138
  br label %bb49
bb42:
  %t226 = load i64, ptr %l112, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l113, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l119
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l122
  br label %bb44
bb44:
  %t243 = load ptr, ptr %l114, !tbaa !29
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t243, i64 %t244, i32 %t245, i64 %t246)
  store { i64, ptr } %t247, ptr %l123
  br label %bb45
bb45:
  %t248 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t263, { i64, ptr } %t261)
  br label %bb46
bb46:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l126, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l127, !tbaa !29
  %t267 = load i64, ptr %l8, !tbaa !24
  store i64 %t267, ptr %l128, !tbaa !24
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t269 = load i64, ptr %l11, !tbaa !24
  %t272 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t268, i64 %t269)
  store i64 %t272, ptr %l131
  br label %bb47
bb47:
  %t273 = load ptr, ptr %l126, !tbaa !29
  %t274 = load ptr, ptr %l127, !tbaa !29
  %t275 = load i64, ptr %l128, !tbaa !24
  %t276 = load i64, ptr %l131, !tbaa !24
  call void @compiler_2fexplain_2eeffectLine(ptr %v0, ptr %v1, ptr %s6, ptr %t273, ptr %t274, i64 %t275, i64 %t276, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb49:
  %t277 = load ptr, ptr %l133, !tbaa !29
  %t278 = load i64, ptr %l134, !tbaa !24
  %t279 = load i32, ptr %l138, !tbaa !23
  %t280 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t277, i64 %t278, i32 %t279, i64 -1)
  store { i64, ptr } %t280, ptr %l139
  br label %bb50
bb50:
  %t281 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t283 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = add i64 %t282, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t281, i64 %t282)
  %t291 = getelementptr i8, ptr %t290, i64 %t282
  call void @olang_textcopy(ptr %t291, ptr %t284, i64 %t285)
  %t292 = getelementptr i8, ptr %t291, i64 %t285
  call void @olang_textcopy(ptr %t292, ptr %t287, i64 %t288)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t290, 1
  %t296 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t296, { i64, ptr } %t294)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb53:
  %t298 = load i64, ptr %l7, !tbaa !24
  %t301 = add i64 %t298, 1
  store i64 %t301, ptr %l7, !tbaa !24
  br label %bb9
bb54:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2enoValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca i32
  %l45 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i64, ptr } @compiler_2fexplain_2eNoValueWhy(ptr %v1, ptr %v2, ptr %s0, ptr %t1, ptr %t2, i64 %t3, i64 %t4)
  store { i64, ptr } %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d113, i32 0, i32 1) })
  store i1 %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load i1, ptr %l15, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = extractvalue { i64, ptr } %t18, 0
  %t23 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t19, 1
  %t28 = extractvalue { i64, ptr } %t19, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t23, i64 %t24)
  %t35 = getelementptr i8, ptr %t34, i64 %t24
  call void @olang_textcopy(ptr %t35, ptr %t27, i64 %t28)
  %t36 = getelementptr i8, ptr %t35, i64 %t28
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t33, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t17, { i64, ptr } %t38)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %v1, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l27
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l27, !tbaa !29
  store ptr %t54, ptr %l7, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t58, i64 %t59, i32 0)
  store i64 %t62, ptr %l31
  br label %bb11
bb11:
  %t63 = load i64, ptr %l31, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l32, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l33, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %l34, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l35, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t75 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t71, i64 %t63)
  store i32 %t75, ptr %l39
  br label %bb12
bb12:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Func", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 3
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Sig", ptr %t83, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = load ptr, ptr %l35, !tbaa !29
  %t88 = load i32, ptr %l39, !tbaa !23
  %t91 = call i32 @compiler_2fexplain_2enamed(ptr %v1, ptr %v1, ptr %v1, ptr %t87, i32 %t88, ptr %t79, { i64, ptr } %t86)
  store i32 %t91, ptr %l45
  br label %bb13
bb13:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t94 = load ptr, ptr %l32, !tbaa !29
  %t95 = load ptr, ptr %l33, !tbaa !29
  %t96 = load ptr, ptr %l34, !tbaa !29
  %t97 = load i32, ptr %l45, !tbaa !23
  call void @compiler_2fexplain_2efitsLine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t94, ptr %t95, ptr %t96, i32 %t97, i64 %t92, { i64, ptr } %t93)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l25, !tbaa !27
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %t39, i64 %t36
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !37
  %t47 = extractvalue { i64, ptr } %a4, 1
  %t48 = extractvalue { i64, ptr } %a4, 0
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t41, 1
  %t54 = extractvalue { i64, ptr } %t41, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t47, i64 %t48)
  %t60 = getelementptr i8, ptr %t59, i64 %t48
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t61, ptr %t53, i64 %t54)
  %t62 = getelementptr i8, ptr %t61, i64 %t54
  call void @olang_textcopy(ptr %t62, ptr %t56, i64 %t57)
  %t63 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t59, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t64)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2eoverCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca i32
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t4, i32 %a2)
  store ptr %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l12, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2cc943ac2dc78fd5_5274b69301a971f1)
  unreachable
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l5, !tbaa !29
  %t20 = load ptr, ptr %l5, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t21 = load ptr, ptr %l18, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 5}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr { i64, [6 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb30
bb9:
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l27, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t50 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v1, ptr %t46, i32 %a3)
  store i32 %t50, ptr %l32
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t59 = load i32, ptr %l32, !tbaa !23
  %t61 = call i32 @compiler_2fexplain_2enamed(ptr %v1, ptr %s1, ptr %v1, ptr %t58, i32 %t59, ptr null, { i64, ptr } %t57)
  store i32 %t61, ptr %l36
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l27, !tbaa !29
  %t63 = load i32, ptr %l36, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v1, ptr %s1, ptr %t62, i32 %t63)
  store { i64, ptr } %t64, ptr %l37
  br label %bb14
bb14:
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t68 = call i64 @compiler_2fexplain_2efirstClose(ptr %s1, { i64, ptr } %t66)
  store i64 %t68, ptr %l39
  br label %bb15
bb15:
  %t69 = load i64, ptr %l39, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  store ptr %a0, ptr %l40, !tbaa !29
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = icmp sge i64 2, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = icmp sle i64 2, %t78
  br i1 %t79, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_99dba9233bab2306_11c4778e1aad7562)
  unreachable
bb18:
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = load i64, ptr %l43, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_99dba9233bab2306_11c4778e1aad7562)
  unreachable
bb20:
  %t85 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 2
  %t89 = sub i64 %t87, 2
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l49, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l51, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l52, !tbaa !24
  %t100 = load i64, ptr %l49, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_99dba9233bab2306_11c4778e1aad7562)
  unreachable
bb22:
  %t103 = load i64, ptr %l49, !tbaa !24
  %t104 = load i64, ptr %l51, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_99dba9233bab2306_11c4778e1aad7562)
  unreachable
bb24:
  %t107 = load i64, ptr %l51, !tbaa !24
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_99dba9233bab2306_11c4778e1aad7562)
  unreachable
bb26:
  %t111 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l49, !tbaa !24
  %t114 = load i64, ptr %l51, !tbaa !24
  %t115 = getelementptr i8, ptr %t112, i64 %t113
  %t116 = sub i64 %t114, %t113
  %t117 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s1, ptr %s1, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l57
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_99dba9233bab2306_11c4778e1aad7562)
  unreachable
bb28:
  %t121 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l58, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l59, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l58, !tbaa !24
  %t133 = mul i64 %t132, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t135, i64 %t136)
  %t142 = getelementptr i8, ptr %t141, i64 %t136
  call void @olang_textcopy(ptr %t142, ptr %t138, i64 %t139)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  %t146 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t146, { i64, ptr } %t144)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s1)
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_94ac06f7d37b19a6_b348a4f44ea9b892)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2epushPayload(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l43 = alloca i32
  %l47 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t4, i32 %t5)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_267284e461664677_b2c2386ba62ab5d3)
  unreachable
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call i1 @compiler_2fexplain_2ecaseWhole(ptr %v1, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l21, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l24, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t39 = load i64, ptr %l4, !tbaa !24
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v1, ptr %t37, i32 %t38, i64 %t39)
  store i32 %t43, ptr %l29
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l29, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t44, i32 %t45)
  store i32 %t46, ptr %l30
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s1, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l31
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i32, ptr %t52, i64 0
  %t54 = load i32, ptr %t53, !tbaa !33
  %t55 = load ptr, ptr %l18, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s1, ptr %t55, i32 %t54)
  store { i64, ptr } %t57, ptr %l34
  br label %bb11
bb11:
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t60 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t58, i64 %t59)
  %t65 = getelementptr i8, ptr %t64, i64 %t59
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t69, { i64, ptr } %t67)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l37, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l38, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i32, ptr %l3, !tbaa !23
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v1, ptr %t76, i32 %t77, i64 %t78)
  store i32 %t82, ptr %l43
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t86, i32 %t87)
  store ptr %t90, ptr %l47
  br label %bb15
bb15:
  %t91 = load ptr, ptr %l47, !tbaa !29
  store ptr %t91, ptr %l6, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_66f7703ccaf4f658_ca46a1b97aa24804)
  unreachable
bb17:
  br label %bb18
bb18:
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t97 = load i64, ptr %l4, !tbaa !24
  %t100 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v1, ptr %s0, ptr %t96, i64 %t97)
  store { i64, ptr } %t100, ptr %l52
  br label %bb19
bb19:
  %t101 = load ptr, ptr %l38, !tbaa !29
  %t102 = load i32, ptr %l43, !tbaa !23
  %t103 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t104 = call i32 @compiler_2fexplain_2enamed(ptr %v1, ptr %s0, ptr %s0, ptr %t101, i32 %t102, ptr null, { i64, ptr } %t103)
  store i32 %t104, ptr %l53
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l37, !tbaa !29
  %t106 = load i32, ptr %l53, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v1, ptr %s0, ptr %t105, i32 %t106)
  store { i64, ptr } %t107, ptr %l54
  br label %bb21
bb21:
  %t108 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t108, ptr %l7, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l55, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = call i64 @compiler_2fexplain_2efirstClose(ptr %s0, { i64, ptr } %t110)
  store i64 %t112, ptr %l57
  br label %bb22
bb22:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l58, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l59, !tbaa !24
  %t117 = icmp sge i64 2, 0
  br i1 %t117, label %bb23, label %bb24
bb23:
  %t119 = load i64, ptr %l58, !tbaa !24
  %t120 = icmp sle i64 2, %t119
  br i1 %t120, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb25:
  %t122 = load i64, ptr %l58, !tbaa !24
  %t123 = load i64, ptr %l59, !tbaa !24
  %t124 = icmp sle i64 %t122, %t123
  br i1 %t124, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb27:
  %t126 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l58, !tbaa !24
  %t129 = getelementptr i8, ptr %t127, i64 2
  %t130 = sub i64 %t128, 2
  %t131 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t133 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t133, { i64, ptr } %t132)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t59, ptr %l39
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  %t59 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t61 = trunc i64 20 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l2, !tbaa !23
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l41
  br label %bb13
bb13:
  %t85 = load i32, ptr %l41, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l53
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l54
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  call void @__olang_scope_close(ptr %s0)
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fexplain_2erequires(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 5
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  call void @olang_textcopy(ptr %t18, ptr %t14, i64 %t15)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t9, { i64, ptr } %t20)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Sig", ptr %t33, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Func", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fexplain_2ereqLines(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %v2, ptr %v3, ptr %t24, ptr %a1, { i64, ptr } %t29, { i64, ptr } %t36, ptr %t40, i64 %a3, { i64, ptr } %t42)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etraitItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l108 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v1, ptr %v1, ptr %t4, i32 %t5)
  store ptr %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l20, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t13, i32 %t14)
  store i64 %t17, ptr %l24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l24, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v1, ptr %v1, ptr %t27, i64 %t18)
  store ptr %t31, ptr %l30
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9c4fb7eb44276a12_39e0991f75dfa016)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t52 = extractvalue { i64, ptr } %a3, 1
  %t53 = extractvalue { i64, ptr } %a3, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t49, i64 %t50)
  %t59 = getelementptr i8, ptr %t58, i64 %t50
  call void @olang_textcopy(ptr %t59, ptr %t52, i64 %t53)
  %t60 = getelementptr i8, ptr %t59, i64 %t53
  call void @olang_textcopy(ptr %t60, ptr %t55, i64 %t56)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t58, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t47, { i64, ptr } %t62)
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f947637db6a06e39_bd7e608c8f724ffd)
  unreachable
bb9:
  br label %bb10
bb10:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/ast:TypeDecl", ptr %t70, i32 0, i32 3
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l8, !tbaa !29
  %t76 = load ptr, ptr %l8, !tbaa !29
  store ptr %t76, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb11, label %bb12
bb11:
  %t80 = load ptr, ptr %l47, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 5}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l48, !tbaa !21
  br label %bb12
bb12:
  %t84 = load i1, ptr %l48, !tbaa !21
  br i1 %t84, label %bb13, label %bb14
bb13:
  %t85 = load ptr, ptr %l8, !tbaa !29
  %t87 = getelementptr { i64, [6 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t87, i32 0, i32 1
  %t89 = load { i64, ptr }, ptr %t88
  store { i64, ptr } %t89, ptr %l9, !tbaa !27
  %t91 = load ptr, ptr %l8, !tbaa !29
  %t93 = getelementptr { i64, [6 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t93, i32 0, i32 2
  %t95 = load { i64, ptr }, ptr %t94
  store { i64, ptr } %t95, ptr %l10, !tbaa !27
  br label %bb15
bb14:
  br label %bb26
bb15:
  %t97 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l58, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t108 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v1, ptr %v1, ptr %s3, { i64, ptr } %t104, { i64, ptr } %t105)
  store { i64, ptr } %t108, ptr %l61
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t109 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t111 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = add i64 %t110, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t109, i64 %t110)
  %t116 = getelementptr i8, ptr %t115, i64 %t110
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t120 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t120, { i64, ptr } %t118)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t122 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v1, ptr %v1, ptr %s5, { i64, ptr } %t129, { i64, ptr } %t130)
  store { i64, ptr } %t133, ptr %l70
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t134 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t136 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t134, i64 %t135)
  %t141 = getelementptr i8, ptr %t140, i64 %t135
  call void @olang_textcopy(ptr %t141, ptr %t137, i64 %t138)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t140, 1
  %t145 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t145, { i64, ptr } %t143)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_945369bc48fd3cab_701e553ecbda785f)
  unreachable
bb31:
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t147, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb32
bb32:
  %t149 = load ptr, ptr %l4, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_6416ccbc4bdd9b53_41c21134d0645047)
  unreachable
bb34:
  br label %bb35
bb35:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/ast:TypeDecl", ptr %t153, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  store ptr %t157, ptr %l11, !tbaa !29
  %t159 = load ptr, ptr %l11, !tbaa !29
  store ptr %t159, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t160 = load ptr, ptr %l79, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb36, label %bb37
bb36:
  %t163 = load ptr, ptr %l79, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 5}
  %t166 = icmp eq i64 %t164, 2
  store i1 %t166, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  %t167 = load i1, ptr %l80, !tbaa !21
  br i1 %t167, label %bb38, label %bb39
bb38:
  %t168 = load ptr, ptr %l11, !tbaa !29
  %t170 = getelementptr { i64, [6 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t170, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171
  store { i64, ptr } %t172, ptr %l12, !tbaa !27
  br label %bb40
bb39:
  br label %bb55
bb40:
  %t174 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t174, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  store i64 %t178, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t180 = load i64, ptr %l14, !tbaa !24
  %t181 = load i64, ptr %l15, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb43:
  br label %bb44
bb44:
  %t188 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t188, ptr %l92, !tbaa !27
  %t189 = load i64, ptr %l14, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr ptr, ptr %t192, i64 %t189
  %t194 = load ptr, ptr %t193, !tbaa !39
  store ptr %t194, ptr %l16, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l95, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t197, ptr %l96, !tbaa !27
  %t198 = load ptr, ptr %l16, !tbaa !29
  %t200 = getelementptr %"compiler/ast:Func", ptr %t198, i32 0, i32 0
  %t201 = getelementptr %"compiler/source:Span", ptr %t200, i32 0, i32 0
  %t202 = load i32, ptr %t201, !tbaa !23
  %t204 = sext i32 %t202 to i64
  store i64 %t204, ptr %l99, !tbaa !24
  %t205 = load ptr, ptr %l16, !tbaa !29
  %t207 = getelementptr %"compiler/ast:Func", ptr %t205, i32 0, i32 0
  %t208 = getelementptr %"compiler/source:Span", ptr %t207, i32 0, i32 1
  %t209 = load i32, ptr %t208, !tbaa !23
  %t211 = sext i32 %t209 to i64
  store i64 %t211, ptr %l102, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  store i64 %t213, ptr %l103, !tbaa !24
  %t214 = load i64, ptr %l99, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t217 = load i64, ptr %l99, !tbaa !24
  %t218 = load i64, ptr %l102, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_4bcdc081c3d6706_49dcf1c0d0dc9572)
  unreachable
bb47:
  %t221 = load i64, ptr %l102, !tbaa !24
  %t222 = load i64, ptr %l103, !tbaa !24
  %t223 = icmp sle i64 %t221, %t222
  br i1 %t223, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_4bcdc081c3d6706_49dcf1c0d0dc9572)
  unreachable
bb49:
  %t225 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l99, !tbaa !24
  %t228 = load i64, ptr %l102, !tbaa !24
  %t229 = getelementptr i8, ptr %t226, i64 %t227
  %t230 = sub i64 %t228, %t227
  %t231 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t234 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %s10, { i64, ptr } %t232)
  store { i64, ptr } %t234, ptr %l108
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_4bcdc081c3d6706_49dcf1c0d0dc9572)
  unreachable
bb51:
  %t235 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t237 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t235, i64 %t236)
  %t245 = getelementptr i8, ptr %t244, i64 %t236
  call void @olang_textcopy(ptr %t245, ptr %t238, i64 %t239)
  %t246 = getelementptr i8, ptr %t245, i64 %t239
  call void @olang_textcopy(ptr %t246, ptr %t241, i64 %t242)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t244, 1
  %t250 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t250, { i64, ptr } %t248)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb53
bb53:
  %t252 = load i64, ptr %l14, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l14, !tbaa !24
  br label %bb41
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_183ac6c93ee000c_8e8c5563c1dc1de8)
  unreachable
bb60:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v3, ptr %t257)
  store { i64, ptr } %t259, ptr %l115
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t260 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t260, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:Entry"
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %l124 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i64
  %l130 = alloca { i64, ptr }
  %l139 = alloca i64
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 1
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb55
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v1, ptr %v1, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l54, !tbaa !29
  store ptr %t74, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t77 = getelementptr %"compiler/names:Table", ptr %t75, i32 0, i32 0
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t77)
  store i64 %t79, ptr %l57
  br label %bb14
bb14:
  %t80 = load i64, ptr %l57, !tbaa !24
  store i64 %t80, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb15, label %bb16
bb15:
  %t87 = load i64, ptr %l13, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t107 = load i64, ptr %l64, !tbaa !24
  store i64 %t107, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t108 = load i64, ptr %l61, !tbaa !24
  store i64 %t108, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load i64, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb23:
  br label %bb24
bb24:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = getelementptr %"compiler/names:Table", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t129, i64 %t130)
  store %"compiler/names:Entry" %t133, ptr %l85
  br label %bb25
bb25:
  %t134 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t135 = load i32, ptr %t134, !range !{i32 0, i32 9}
  %t137 = trunc i64 4 to i32
  %t138 = icmp eq i32 %t135, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb29
bb27:
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t144, i64 %t145)
  store %"compiler/names:Entry" %t148, ptr %l93
  br label %bb28
bb28:
  %t149 = getelementptr %"compiler/names:Entry", ptr %l93, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  store i1 %t152, ptr %l89, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l89, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l16, !tbaa !24
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t158, i64 %t159, i64 %t160)
  store i32 %t164, ptr %l100
  br label %bb33
bb33:
  %t165 = load i32, ptr %l100, !tbaa !23
  store i32 %t165, ptr %l17, !tbaa !23
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l17, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l105
  br label %bb34
bb34:
  %t176 = load i32, ptr %l105, !range !{i32 0, i32 6}
  %t178 = trunc i64 3 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb36:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l111, !tbaa !29
  %t187 = load i32, ptr %l17, !tbaa !23
  %t189 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t187)
  store i64 %t189, ptr %l113
  br label %bb37
bb37:
  %t190 = load ptr, ptr %l111, !tbaa !29
  %t191 = load i64, ptr %l113, !tbaa !24
  %t192 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t190, i64 %t191)
  store i64 %t192, ptr %l114
  br label %bb38
bb38:
  %t193 = load i64, ptr %l114, !tbaa !24
  %t194 = icmp sgt i64 %t193, 0
  store i1 %t194, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t196 = load i1, ptr %l109, !tbaa !21
  br i1 %t196, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb41:
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load i32, ptr %l17, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l119
  br label %bb43
bb43:
  %t205 = load i32, ptr %l119, !tbaa !23
  store i32 %t205, ptr %l18, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = load i32, ptr %l18, !tbaa !23
  %t215 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t209, i32 %a2, i32 %t211)
  store i1 %t215, ptr %l124
  br label %bb44
bb44:
  %t216 = load i1, ptr %l124, !tbaa !21
  br i1 %t216, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l125, !tbaa !29
  %t217 = call ptr @__olang_scope_hold(ptr %s0)
  %t218 = ptrtoint ptr %t217 to i64
  store i64 %t218, ptr %l126, !tbaa !24
  %t219 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t219, label %bb47, label %bb48
bb46:
  br label %bb51
bb47:
  %t221 = call ptr @__olang_region_make(ptr %s0)
  %t222 = ptrtoint ptr %t221 to i64
  store i64 %t222, ptr %l126, !tbaa !24
  br label %bb48
bb48:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t224 = load i32, ptr %l18, !tbaa !23
  %t225 = load i64, ptr %l126
  %t226 = inttoptr i64 %t225 to ptr
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %t226, ptr %t223, i32 %t224)
  store { i64, ptr } %t229, ptr %l130
  br label %bb49
bb49:
  %t230 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t231 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t231, { i64, ptr } %t230)
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb52:
  %t233 = load i64, ptr %l15, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l15, !tbaa !24
  br label %bb21
bb53:
  br label %bb54
bb54:
  %t238 = load i64, ptr %l8, !tbaa !24
  %t241 = add i64 %t238, 1
  store i64 %t241, ptr %l8, !tbaa !24
  br label %bb9
bb55:
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t244, ptr %l139
  br label %bb56
bb56:
  %t245 = load i64, ptr %l139, !tbaa !24
  %t246 = icmp sgt i64 %t245, 0
  br i1 %t246, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l141, !tbaa !29
  %t250 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store { i64, ptr } %t250, ptr %l143
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t251 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t253 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t260 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t251, i64 %t252)
  %t261 = getelementptr i8, ptr %t260, i64 %t252
  call void @olang_textcopy(ptr %t261, ptr %t254, i64 %t255)
  %t262 = getelementptr i8, ptr %t261, i64 %t255
  call void @olang_textcopy(ptr %t262, ptr %t257, i64 %t258)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t260, 1
  %t266 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t266, { i64, ptr } %t264)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2etwinLines(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { %"compiler/source:Span", i64 }
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { %"compiler/source:Span", i64 }
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l76 = alloca i64
  %l81 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinCount(ptr %v2, ptr %t16)
  store i64 %t18, ptr %l23
  br label %bb4
bb4:
  %t19 = load i64, ptr %l23, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l30, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l30, !tbaa !24
  store i64 %t46, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l27, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinBody(ptr %v2, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l50
  br label %bb15
bb15:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load i64, ptr %l50, !tbaa !24
  %t74 = icmp ne i64 %t72, %t71
  br i1 %t74, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = call { %"compiler/source:Span", i64 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinAt(ptr %v2, ptr %t76, i64 %t77)
  store { %"compiler/source:Span", i64 } %t80, ptr %l55
  br label %bb19
bb19:
  %t81 = load { %"compiler/source:Span", i64 }, ptr %l55
  store { %"compiler/source:Span", i64 } %t81, ptr %l12
  %t82 = getelementptr { %"compiler/source:Span", i64 }, ptr %l12, i32 0, i32 0
  %t83 = load %"compiler/source:Span", ptr %t82
  store %"compiler/source:Span" %t83, ptr %l13
  %t85 = getelementptr { %"compiler/source:Span", i64 }, ptr %l12, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 1
  %t94 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v2, ptr %v2, ptr %t90, i64 %t86)
  store ptr %t94, ptr %l61
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t95, i32 0, i32 3
  %t98 = load i64, ptr %t97, !tbaa !24
  store i64 %t98, ptr %l15, !tbaa !24
  store ptr %a0, ptr %l64, !tbaa !29
  store { i64, ptr } %a4, ptr %l65, !tbaa !27
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinWords(ptr %v2, ptr %s3, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l68
  br label %bb21
bb21:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t108 = load i64, ptr %l15, !tbaa !24
  %t111 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v1, ptr %s3, ptr %t107, i64 %t108)
  store { i64, ptr } %t111, ptr %l71
  br label %bb22
bb22:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t113 = load i64, ptr %l15, !tbaa !24
  %t114 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  %t121 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v1, ptr %t112, i64 %t113, i64 %t117)
  store i64 %t121, ptr %l76
  br label %bb23
bb23:
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t123 = load i64, ptr %l15, !tbaa !24
  %t124 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  %t131 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v1, ptr %t122, i64 %t123, i64 %t127)
  store i64 %t131, ptr %l81
  br label %bb24
bb24:
  %t132 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = add i64 %t137, %t140
  %t142 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = load i64, ptr %l76, !tbaa !24
  %t153 = call i64 @__olang_fmt_i64(ptr null, i64 %t152)
  %t154 = add i64 %t151, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = call i64 @__olang_fmt_i64(ptr null, i64 %t158)
  %t160 = add i64 %t157, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t133, i64 %t134)
  %t165 = getelementptr i8, ptr %t164, i64 %t134
  call void @olang_textcopy(ptr %t165, ptr %t135, i64 %t136)
  %t166 = getelementptr i8, ptr %t165, i64 %t136
  call void @olang_textcopy(ptr %t166, ptr %t139, i64 %t140)
  %t167 = getelementptr i8, ptr %t166, i64 %t140
  call void @olang_textcopy(ptr %t167, ptr %t142, i64 %t143)
  %t168 = getelementptr i8, ptr %t167, i64 %t143
  call void @olang_textcopy(ptr %t168, ptr %t146, i64 %t147)
  %t169 = getelementptr i8, ptr %t168, i64 %t147
  call void @olang_textcopy(ptr %t169, ptr %t149, i64 %t150)
  %t170 = getelementptr i8, ptr %t169, i64 %t150
  %t171 = call i64 @__olang_fmt_i64(ptr %t170, i64 %t152)
  %t172 = getelementptr i8, ptr %t170, i64 %t153
  call void @olang_textcopy(ptr %t172, ptr %t155, i64 %t156)
  %t173 = getelementptr i8, ptr %t172, i64 %t156
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t158)
  %t175 = getelementptr i8, ptr %t173, i64 %t159
  call void @olang_textcopy(ptr %t175, ptr %t161, i64 %t162)
  %t176 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t164, 1
  %t179 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t179, { i64, ptr } %t177)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l10, !tbaa !24
  br label %bb11
bb27:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca i32
  %l29 = alloca i1
  %l34 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l50 = alloca i32
  %l62 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l101 = alloca i64
  %l104 = alloca i64
  %l123 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca { i64, ptr }
  %l153 = alloca i32
  %l154 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l168 = alloca i32
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l195 = alloca i32
  %l199 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l204 = alloca i32
  %l205 = alloca { i64, ptr }
  %l207 = alloca i64
  %l208 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca i64
  %l214 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l222 = alloca { i64, ptr }
  %l226 = alloca i64
  %l227 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l237 = alloca i1
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l241 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i64
  %l249 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l25
  br label %bb2
bb2:
  %t11 = load i32, ptr %l25, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l29
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l34, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l39
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l34, !tbaa !29
  %t43 = load i32, ptr %l39, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l40
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l41, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t48 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t46)
  store i64 %t48, ptr %l43
  br label %bb6
bb6:
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = load i64, ptr %l43, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t49, i64 %t50, i64 0)
  store { i64, ptr } %t51, ptr %l44
  br label %bb7
bb7:
  %t52 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = add i64 %t54, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t53, i64 %t54)
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l50
  br label %bb8
bb8:
  %t74 = load i32, ptr %l50, !range !{i32 0, i32 6}
  store i32 %t74, ptr %l6
  %t75 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t77 = trunc i64 5 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = extractvalue { i64, ptr } %t80, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = getelementptr i8, ptr %t91, i64 %t85
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t94, ptr %rv
  br label %ret
bb12:
  %t96 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t98 = trunc i64 2 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l1, !tbaa !23
  %t103 = load i32, ptr %l3, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2fexplain_2eerrorTypeItem(ptr %s0, ptr %v0, ptr %s0, ptr %v1, ptr %l2, ptr %t101, i32 %t102, i32 %t103, { i64, ptr } %t104)
  store { i64, ptr } %t110, ptr %l62
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb17:
  %t112 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t114 = trunc i64 3 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l1, !tbaa !23
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t124 = call { i64, ptr } @compiler_2fexplain_2etraitItem(ptr %s0, ptr %v0, ptr %s0, ptr %v1, ptr %l2, ptr %t117, i32 %t118, { i64, ptr } %t119)
  store { i64, ptr } %t124, ptr %l69
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
bb22:
  %t126 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t128 = trunc i64 1 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb55
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l2, ptr %l72, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t131, ptr %l73, !tbaa !27
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l3, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %s6, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l76
  br label %bb26
bb26:
  %t137 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t139 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t137, i64 %t138)
  %t151 = getelementptr i8, ptr %t150, i64 %t138
  call void @olang_textcopy(ptr %t151, ptr %t140, i64 %t141)
  %t152 = getelementptr i8, ptr %t151, i64 %t141
  call void @olang_textcopy(ptr %t152, ptr %t144, i64 %t145)
  %t153 = getelementptr i8, ptr %t152, i64 %t145
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t150, 1
  %t157 = load ptr, ptr %l72, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t157, { i64, ptr } %t155)
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2egenLine(ptr %s0, ptr %v0, ptr %l2, ptr %t159, i32 %t160)
  br label %bb28
bb28:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  store ptr %t169, ptr %l84, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l3, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l89
  br label %bb29
bb29:
  %t180 = load ptr, ptr %l84, !tbaa !29
  %t181 = load i32, ptr %l89, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t180, i32 %t181)
  store { i64, ptr } %t182, ptr %l90
  br label %bb30
bb30:
  %t183 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t183, ptr %l7, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 2
  %t190 = load i32, ptr %l3, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s6, ptr %t189, i32 %t190)
  store { i64, ptr } %t193, ptr %l95
  br label %bb31
bb31:
  %t194 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t194, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  store i64 %t197, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t199 = load i64, ptr %l10, !tbaa !24
  %t200 = load i64, ptr %l9, !tbaa !24
  %t203 = icmp sgt i64 %t199, %t200
  br i1 %t203, label %bb32, label %bb33
bb32:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = icmp sgt i64 %t205, 0
  br i1 %t207, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb37
bb34:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t210 = load i64, ptr %l9, !tbaa !24
  %t213 = sub i64 %t209, %t210
  %t214 = load i64, ptr %l11, !tbaa !24
  %t217 = add i64 %t213, %t214
  %t219 = sub i64 %t217, 1
  %t220 = load i64, ptr %l11, !tbaa !24
  %t223 = sdiv i64 %t219, %t220
  store i64 %t223, ptr %l104, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb36
bb36:
  %t225 = load i64, ptr %l104, !tbaa !24
  store i64 %t225, ptr %l101, !tbaa !24
  br label %bb37
bb37:
  %t226 = load i64, ptr %l101, !tbaa !24
  store i64 %t226, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t227 = load i64, ptr %l13, !tbaa !24
  %t228 = load i64, ptr %l12, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb40:
  br label %bb41
bb41:
  %t235 = load i64, ptr %l9, !tbaa !24
  %t236 = load i64, ptr %l13, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = mul i64 %t236, %t237
  %t243 = add i64 %t235, %t240
  store i64 %t243, ptr %l14, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb42
bb42:
  store ptr %l2, ptr %l123, !tbaa !29
  %t246 = load ptr, ptr %l4, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t247, ptr %l125, !tbaa !27
  %t248 = load i64, ptr %l14, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i32, ptr %t251, i64 %t248
  %t253 = load i32, ptr %t252, !tbaa !33
  %t256 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t246, i32 %t253)
  store { i64, ptr } %t256, ptr %l128
  br label %bb43
bb43:
  %t257 = load ptr, ptr %l123, !tbaa !29
  %t258 = load { i64, ptr }, ptr %l128, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t257, { i64, ptr } %t258)
  br label %bb44
bb44:
  %t259 = load i64, ptr %l14, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t265 = icmp slt i64 %t259, %t262
  br i1 %t265, label %bb45, label %bb46
bb45:
  %t267 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t267, ptr %l134, !tbaa !27
  %t268 = load i64, ptr %l14, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  %t275 = icmp ne i32 %t273, 0
  store i1 %t275, ptr %l133, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb47
bb47:
  %t277 = load i1, ptr %l133, !tbaa !21
  br i1 %t277, label %bb48, label %bb49
bb48:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i32, ptr %l1, !tbaa !23
  %t280 = load i32, ptr %l3, !tbaa !23
  %t281 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fexplain_2epushPayload(ptr %s0, ptr %v0, ptr %l2, ptr %t278, i32 %t279, i32 %t280, i64 %t281)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  %t288 = load i64, ptr %l13, !tbaa !24
  %t291 = add i64 %t288, 1
  store i64 %t291, ptr %l13, !tbaa !24
  br label %bb38
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb118
bb55:
  %t293 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t295 = trunc i64 4 to i32
  %t296 = icmp eq i32 %t293, %t295
  br i1 %t296, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb75
bb58:
  store %olang.scope zeroinitializer, ptr %s12
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l3, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l153
  br label %bb59
bb59:
  %t308 = load i32, ptr %l153, !tbaa !23
  store i32 %t308, ptr %l15, !tbaa !23
  store ptr %l2, ptr %l154, !tbaa !29
  %t309 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t309, ptr %l155, !tbaa !27
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l3, !tbaa !23
  %t314 = call { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %s12, ptr %t310, i32 %t311)
  store { i64, ptr } %t314, ptr %l158
  br label %bb60
bb60:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load i32, ptr %l3, !tbaa !23
  %t322 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t318, i32 %t319)
  store i1 %t322, ptr %l162
  br label %bb61
bb61:
  %t323 = load i1, ptr %l162, !tbaa !21
  br i1 %t323, label %bb62, label %bb63
bb62:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l163, !tbaa !27
  br label %bb64
bb63:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l163, !tbaa !27
  br label %bb64
bb64:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/generic:Program", ptr %t327, i32 0, i32 2
  %t330 = load i32, ptr %l15, !tbaa !23
  %t333 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t329, i32 %t330)
  store i32 %t333, ptr %l168
  br label %bb65
bb65:
  %t334 = load i32, ptr %l168, !range !{i32 0, i32 33}
  %t336 = trunc i64 21 to i32
  %t337 = icmp eq i32 %t334, %t336
  br i1 %t337, label %bb66, label %bb67
bb66:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i32, ptr %l15, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s12, ptr %t339, i32 %t340)
  store { i64, ptr } %t343, ptr %l174
  br label %bb68
bb67:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load i32, ptr %l15, !tbaa !23
  %t348 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s12, ptr %t344, i32 %t345)
  store { i64, ptr } %t348, ptr %l177
  br label %bb69
bb68:
  %t349 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t349, ptr %l171, !tbaa !27
  br label %bb70
bb69:
  %t350 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t350, ptr %l171, !tbaa !27
  br label %bb70
bb70:
  %t351 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t353 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = add i64 %t352, %t355
  %t357 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 1
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = add i64 %t356, %t359
  %t361 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t361, 1
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t364 = add i64 %t360, %t363
  %t365 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = add i64 %t364, %t367
  %t369 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t351, i64 %t352)
  %t370 = getelementptr i8, ptr %t369, i64 %t352
  call void @olang_textcopy(ptr %t370, ptr %t354, i64 %t355)
  %t371 = getelementptr i8, ptr %t370, i64 %t355
  call void @olang_textcopy(ptr %t371, ptr %t358, i64 %t359)
  %t372 = getelementptr i8, ptr %t371, i64 %t359
  call void @olang_textcopy(ptr %t372, ptr %t362, i64 %t363)
  %t373 = getelementptr i8, ptr %t372, i64 %t363
  call void @olang_textcopy(ptr %t373, ptr %t366, i64 %t367)
  %t374 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t369, 1
  %t377 = load ptr, ptr %l154, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t377, { i64, ptr } %t375)
  br label %bb71
bb71:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i32, ptr %l1, !tbaa !23
  %t381 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2eoverCtor(ptr %s0, ptr %v0, ptr %l2, ptr %t379, i32 %t380, i32 %t381)
  br label %bb72
bb72:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb73
bb73:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2ectorRequires(ptr %s0, ptr %v0, ptr %l2, ptr %t387, i32 %t388)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s12)
  br label %bb118
bb75:
  %t392 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t394 = trunc i64 0 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb117
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l190, !tbaa !29
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l191, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t403 = load i32, ptr %l3, !tbaa !23
  %t406 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t406, ptr %l195
  br label %bb79
bb79:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t411 = load i32, ptr %l1, !tbaa !23
  %t414 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t410, i32 %t411)
  store ptr %t414, ptr %l199
  br label %bb80
bb80:
  %t415 = load ptr, ptr %l199, !tbaa !29
  store ptr %t415, ptr %l16, !tbaa !29
  %t416 = load ptr, ptr %l16, !tbaa !29
  %t418 = icmp eq ptr %t416, null
  br i1 %t418, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a)
  unreachable
bb82:
  br label %bb83
bb83:
  %t420 = load ptr, ptr %l16, !tbaa !29
  %t422 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %s14, ptr %t420)
  store { i64, ptr } %t422, ptr %l203
  br label %bb84
bb84:
  %t423 = load ptr, ptr %l191, !tbaa !29
  %t424 = load i32, ptr %l195, !tbaa !23
  %t425 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t426 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s14, ptr %s14, ptr %t423, i32 %t424, ptr null, { i64, ptr } %t425)
  store i32 %t426, ptr %l204
  br label %bb85
bb85:
  %t427 = load ptr, ptr %l190, !tbaa !29
  %t428 = load i32, ptr %l204, !tbaa !23
  %t429 = call { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %s14, ptr %t427, i32 %t428)
  store { i64, ptr } %t429, ptr %l205
  br label %bb86
bb86:
  %t430 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t430, ptr %l17, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t433 = call i64 @compiler_2fexplain_2efirstClose(ptr %s14, { i64, ptr } %t431)
  store i64 %t433, ptr %l207
  br label %bb87
bb87:
  %t434 = load i64, ptr %l207, !tbaa !24
  store i64 %t434, ptr %l18, !tbaa !24
  %t435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t435, ptr %l208, !tbaa !29
  %t436 = load i64, ptr %l18, !tbaa !24
  store i64 %t436, ptr %l209, !tbaa !24
  %t437 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 0
  store i64 %t438, ptr %l210, !tbaa !24
  %t439 = icmp sge i64 3, 0
  br i1 %t439, label %bb88, label %bb89
bb88:
  %t441 = load i64, ptr %l209, !tbaa !24
  %t442 = icmp sle i64 3, %t441
  br i1 %t442, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb90:
  %t444 = load i64, ptr %l209, !tbaa !24
  %t445 = load i64, ptr %l210, !tbaa !24
  %t446 = icmp sle i64 %t444, %t445
  br i1 %t446, label %bb92, label %bb93
bb91:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb92:
  %t448 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = load i64, ptr %l209, !tbaa !24
  %t451 = getelementptr i8, ptr %t449, i64 3
  %t452 = sub i64 %t450, 3
  %t453 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t451, 1
  store { i64, ptr } %t454, ptr %l214, !tbaa !27
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t459 = load i32, ptr %l1, !tbaa !23
  %t462 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t458, i32 %t459)
  store ptr %t462, ptr %l218
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb94:
  %t463 = load ptr, ptr %l218, !tbaa !29
  store ptr %t463, ptr %l19, !tbaa !29
  %t464 = load ptr, ptr %l19, !tbaa !29
  %t466 = icmp eq ptr %t464, null
  br i1 %t466, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_a185ff5f85e75430_c999a61f9f0eedcc)
  unreachable
bb96:
  br label %bb97
bb97:
  %t468 = load ptr, ptr %l19, !tbaa !29
  %t470 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %s14, ptr %t468)
  store { i64, ptr } %t470, ptr %l222
  br label %bb98
bb98:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/check:Checker", ptr %t471, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t475 = load i32, ptr %l1, !tbaa !23
  %t478 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t474, i32 %t475)
  store i64 %t478, ptr %l226
  br label %bb99
bb99:
  %t479 = load ptr, ptr %l208, !tbaa !29
  %t480 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t481 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t482 = load i64, ptr %l226, !tbaa !24
  %t483 = call { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %s14, ptr %s14, ptr %s14, ptr %t479, { i64, ptr } %t480, { i64, ptr } %t481, i64 %t482, i64 0)
  store { i64, ptr } %t483, ptr %l227
  br label %bb100
bb100:
  %t484 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t484, ptr %l20, !tbaa !27
  store ptr %l2, ptr %l228, !tbaa !29
  %t485 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t485, ptr %l229, !tbaa !27
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l3, !tbaa !23
  %t490 = call { i64, ptr } @compiler_2fexplain_2edeclWord(ptr %v0, ptr %s14, ptr %t486, i32 %t487)
  store { i64, ptr } %t490, ptr %l232
  br label %bb101
bb101:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !29
  %t496 = getelementptr %"compiler/generic:Program", ptr %t494, i32 0, i32 2
  %t497 = load i32, ptr %l3, !tbaa !23
  %t500 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t496, i32 %t497)
  store i1 %t500, ptr %l237
  br label %bb102
bb102:
  %t501 = load i1, ptr %l237, !tbaa !21
  br i1 %t501, label %bb103, label %bb104
bb103:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l238, !tbaa !27
  br label %bb105
bb104:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d145, i32 0, i32 1) }, ptr %l238, !tbaa !27
  br label %bb105
bb105:
  %t502 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t502, ptr %l239, !tbaa !27
  %t503 = load i64, ptr %l18, !tbaa !24
  %t505 = add i64 %t503, 1
  store i64 %t505, ptr %l241, !tbaa !24
  %t506 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t506, 0
  store i64 %t508, ptr %l243, !tbaa !24
  %t509 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t510 = extractvalue { i64, ptr } %t509, 0
  store i64 %t510, ptr %l244, !tbaa !24
  %t511 = load i64, ptr %l241, !tbaa !24
  %t512 = icmp sge i64 %t511, 0
  br i1 %t512, label %bb106, label %bb107
bb106:
  %t514 = load i64, ptr %l241, !tbaa !24
  %t515 = load i64, ptr %l243, !tbaa !24
  %t516 = icmp sle i64 %t514, %t515
  br i1 %t516, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_3b65fc1599fe4b35_e6657610cbc0cf91)
  unreachable
bb108:
  %t518 = load i64, ptr %l243, !tbaa !24
  %t519 = load i64, ptr %l244, !tbaa !24
  %t520 = icmp sle i64 %t518, %t519
  br i1 %t520, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_3b65fc1599fe4b35_e6657610cbc0cf91)
  unreachable
bb110:
  %t522 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = load i64, ptr %l241, !tbaa !24
  %t525 = load i64, ptr %l243, !tbaa !24
  %t526 = getelementptr i8, ptr %t523, i64 %t524
  %t527 = sub i64 %t525, %t524
  %t528 = insertvalue { i64, ptr } undef, i64 %t527, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t526, 1
  %t531 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s14, ptr %s14, { i64, ptr } %t529)
  store { i64, ptr } %t531, ptr %l249
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_3b65fc1599fe4b35_e6657610cbc0cf91)
  unreachable
bb112:
  %t532 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  store i64 %t533, ptr %l250, !tbaa !24
  %t534 = load i64, ptr %l250, !tbaa !24
  %t535 = mul i64 %t534, 1
  %t536 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t535)
  %t537 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t536, 1
  store { i64, ptr } %t538, ptr %l251, !tbaa !27
  %t539 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = load i64, ptr %l250, !tbaa !24
  %t544 = mul i64 %t543, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t540, ptr %t542, i64 %t544, i1 false)
  %t545 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t547 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 1
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t550 = add i64 %t546, %t549
  %t551 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  %t554 = add i64 %t550, %t553
  %t555 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 1
  %t557 = extractvalue { i64, ptr } %t555, 0
  %t558 = add i64 %t554, %t557
  %t559 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t560 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t561 = add i64 %t558, %t560
  %t562 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t562, 1
  %t564 = extractvalue { i64, ptr } %t562, 0
  %t565 = add i64 %t561, %t564
  %t566 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t567 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t568 = add i64 %t565, %t567
  %t569 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = add i64 %t568, %t571
  %t573 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t574 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t575 = add i64 %t572, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t545, i64 %t546)
  %t577 = getelementptr i8, ptr %t576, i64 %t546
  call void @olang_textcopy(ptr %t577, ptr %t548, i64 %t549)
  %t578 = getelementptr i8, ptr %t577, i64 %t549
  call void @olang_textcopy(ptr %t578, ptr %t552, i64 %t553)
  %t579 = getelementptr i8, ptr %t578, i64 %t553
  call void @olang_textcopy(ptr %t579, ptr %t556, i64 %t557)
  %t580 = getelementptr i8, ptr %t579, i64 %t557
  call void @olang_textcopy(ptr %t580, ptr %t559, i64 %t560)
  %t581 = getelementptr i8, ptr %t580, i64 %t560
  call void @olang_textcopy(ptr %t581, ptr %t563, i64 %t564)
  %t582 = getelementptr i8, ptr %t581, i64 %t564
  call void @olang_textcopy(ptr %t582, ptr %t566, i64 %t567)
  %t583 = getelementptr i8, ptr %t582, i64 %t567
  call void @olang_textcopy(ptr %t583, ptr %t570, i64 %t571)
  %t584 = getelementptr i8, ptr %t583, i64 %t571
  call void @olang_textcopy(ptr %t584, ptr %t573, i64 %t574)
  %t585 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t576, 1
  %t588 = load ptr, ptr %l228, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t588, { i64, ptr } %t586)
  br label %bb113
bb113:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2ectorRequires(ptr %s0, ptr %v0, ptr %l2, ptr %t590, i32 %t591)
  br label %bb114
bb114:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2egenLine(ptr %s0, ptr %v0, ptr %l2, ptr %t595, i32 %t596)
  br label %bb115
bb115:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t600, i32 %t601)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s14)
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_9e7f77c067ece8f1_2a0afb54e00d35)
  unreachable
bb118:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2ebuilders(ptr %s0, ptr %v0, ptr %l2, ptr %t605, i32 %t606)
  br label %bb119
bb119:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t610, i32 %t611)
  br label %bb120
bb120:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t615, i32 %t616)
  br label %bb121
bb121:
  %t621 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t621, ptr %l273
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s0)
  %t622 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t622, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca %"compiler/generic:varRow"
  %l64 = alloca i1
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l19
  br label %bb1
bb1:
  %t9 = load i64, ptr %l19, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l25, !tbaa !24
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l26, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l27
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l27
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb51
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l59
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l59
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t99, i64 %t100, i64 %t101)
  store i1 %t105, ptr %l64
  br label %bb18
bb18:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l65, !tbaa !29
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb21, label %bb22
bb20:
  br label %bb26
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/load:Loader", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t122, i32 %t124)
  store { i64, ptr } %t127, ptr %l75
  br label %bb24
bb24:
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = getelementptr i8, ptr %t135, i64 %t130
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t140 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t140, { i64, ptr } %t138)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb26:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l2, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  store ptr %l4, ptr %l82, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/load:Loader", ptr %t155, i32 0, i32 3
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t160 = load i32, ptr %t159, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t158, i32 %t160)
  store { i64, ptr } %t163, ptr %l88
  br label %bb31
bb31:
  %t164 = load ptr, ptr %l82, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t164, { i64, ptr } %t165)
  br label %bb32
bb32:
  %t166 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t167 = load i32, ptr %t166, !tbaa !23
  %t168 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  br i1 %t171, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l92, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t175 = load i32, ptr %t174, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t173, i32 %t175)
  store { i64, ptr } %t178, ptr %l95
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t181 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t179, i64 %t180)
  %t186 = getelementptr i8, ptr %t185, i64 %t180
  call void @olang_textcopy(ptr %t186, ptr %t182, i64 %t183)
  %t187 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t185, 1
  %t190 = load ptr, ptr %l92, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t190, { i64, ptr } %t188)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t192 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t193 = load i32, ptr %t192, !tbaa !23
  %t194 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t197 = icmp ne i32 %t193, %t194
  br i1 %t197, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t203 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t204 = load i32, ptr %t203, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %s10, ptr %t202, i32 %t204)
  store { i64, ptr } %t207, ptr %l104
  br label %bb40
bb39:
  br label %bb49
bb40:
  %t208 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t208, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t210 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  %t214 = load i64, ptr %l13, !tbaa !24
  %t215 = load i64, ptr %l14, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s11)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t222 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t222, ptr %l112, !tbaa !27
  %t223 = load i64, ptr %l13, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  store ptr %l4, ptr %l115, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t234 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s11, ptr %t230, i32 %t228)
  store { i64, ptr } %t234, ptr %l118
  br label %bb45
bb45:
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t237 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t235, i64 %t236)
  %t242 = getelementptr i8, ptr %t241, i64 %t236
  call void @olang_textcopy(ptr %t242, ptr %t238, i64 %t239)
  %t243 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t241, 1
  %t246 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t246, { i64, ptr } %t244)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb47:
  %t248 = load i64, ptr %l13, !tbaa !24
  %t251 = add i64 %t248, 1
  store i64 %t251, ptr %l13, !tbaa !24
  br label %bb41
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t253 = load i64, ptr %l9, !tbaa !24
  %t256 = add i64 %t253, 1
  store i64 %t256, ptr %l9, !tbaa !24
  br label %bb13
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb52
bb52:
  %t260 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t260, ptr %l129
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t261 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t261, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2ewithDefaults(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l17 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l56 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l118 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l27
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 6
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ff0e4b22591d4baf_6e63db52d9d49f33)
  unreachable
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/source:Source", ptr %t42, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  %t48 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t48, ptr %l35
  br label %bb11
bb11:
  %t49 = load %"std/prelude/text:StringBuilder", ptr %l35
  store %"std/prelude/text:StringBuilder" %t49, ptr %l7
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb61
bb14:
  br label %bb15
bb15:
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %v1, { i64, ptr } %t60)
  store i64 %t62, ptr %l42
  br label %bb16
bb16:
  %t63 = load i64, ptr %l42, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store ptr %l7, ptr %l43, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t64, ptr %l44, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l46, !tbaa !24
  %t68 = icmp sge i64 0, 0
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = icmp sle i64 0, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb19:
  %t73 = load i64, ptr %l45, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb21:
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l45, !tbaa !24
  %t80 = getelementptr i8, ptr %t78, i64 0
  %t81 = sub i64 %t79, 0
  %t82 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t80, 1
  %t84 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t84, { i64, ptr } %t83)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9a288766c4af6878_87d82d450b86e5bc)
  unreachable
bb23:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t90 = sub i64 %t86, %a4
  store i64 %t90, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  store i1 %t102, ptr %l56, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t104 = load i1, ptr %l56, !tbaa !21
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l62, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = getelementptr %"compiler/ast:Param", ptr %t111, i32 0, i32 3
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb29
bb29:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t121, ptr %l68, !tbaa !27
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t129 = getelementptr %"compiler/ast:Param", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  store ptr %t130, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb32, label %bb33
bb31:
  br label %bb43
bb32:
  call void @__olang_check_failed(ptr @olang_loc_dff7162f9e8224a5_8282e6f3b3a12619)
  unreachable
bb33:
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t138 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t136)
  store %"compiler/source:Span" %t138, ptr %l75
  br label %bb35
bb35:
  %t139 = load %"compiler/source:Span", ptr %l75
  store %"compiler/source:Span" %t139, ptr %l13
  store ptr %l7, ptr %l76, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t140, ptr %l77, !tbaa !27
  %t141 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t144 = sext i32 %t142 to i64
  store i64 %t144, ptr %l79, !tbaa !24
  %t145 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t146 = load i32, ptr %t145, !tbaa !23
  %t148 = sext i32 %t146 to i64
  store i64 %t148, ptr %l81, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l79, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  br i1 %t152, label %bb36, label %bb37
bb36:
  %t154 = load i64, ptr %l79, !tbaa !24
  %t155 = load i64, ptr %l81, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb38:
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = load i64, ptr %l82, !tbaa !24
  %t160 = icmp sle i64 %t158, %t159
  br i1 %t160, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb40:
  %t162 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l79, !tbaa !24
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = getelementptr i8, ptr %t163, i64 %t164
  %t167 = sub i64 %t165, %t164
  %t168 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t170 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t173 = extractvalue { i64, ptr } %t169, 1
  %t174 = extractvalue { i64, ptr } %t169, 0
  %t175 = add i64 %t171, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = getelementptr i8, ptr %t176, i64 %t171
  call void @olang_textcopy(ptr %t177, ptr %t173, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t181, { i64, ptr } %t179)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t183 = load i64, ptr %l9, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l9, !tbaa !24
  %t188 = load i64, ptr %l10, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t194 = icmp sge i64 %t188, %t191
  br i1 %t194, label %bb44, label %bb45
bb44:
  br label %bb61
bb45:
  br label %bb46
bb46:
  store ptr %l7, ptr %l96, !tbaa !29
  %t196 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t196, ptr %l97, !tbaa !27
  %t197 = load i64, ptr %l10, !tbaa !24
  store i64 %t197, ptr %l98, !tbaa !24
  %t198 = load i64, ptr %l10, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l100, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  store i64 %t202, ptr %l101, !tbaa !24
  %t203 = load i64, ptr %l98, !tbaa !24
  %t204 = icmp sge i64 %t203, 0
  br i1 %t204, label %bb47, label %bb48
bb47:
  %t206 = load i64, ptr %l98, !tbaa !24
  %t207 = load i64, ptr %l100, !tbaa !24
  %t208 = icmp sle i64 %t206, %t207
  br i1 %t208, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb49:
  %t210 = load i64, ptr %l100, !tbaa !24
  %t211 = load i64, ptr %l101, !tbaa !24
  %t212 = icmp sle i64 %t210, %t211
  br i1 %t212, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb51:
  %t214 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = load i64, ptr %l98, !tbaa !24
  %t217 = load i64, ptr %l100, !tbaa !24
  %t218 = getelementptr i8, ptr %t215, i64 %t216
  %t219 = sub i64 %t217, %t216
  %t220 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t218, 1
  %t222 = load ptr, ptr %l96, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t222, { i64, ptr } %t221)
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405)
  unreachable
bb53:
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t224, ptr %l106, !tbaa !27
  %t225 = load i64, ptr %l10, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l108, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t228, 0
  store i64 %t231, ptr %l111, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 0
  store i64 %t233, ptr %l112, !tbaa !24
  %t234 = load i64, ptr %l108, !tbaa !24
  %t235 = icmp sge i64 %t234, 0
  br i1 %t235, label %bb54, label %bb55
bb54:
  %t237 = load i64, ptr %l108, !tbaa !24
  %t238 = load i64, ptr %l111, !tbaa !24
  %t239 = icmp sle i64 %t237, %t238
  br i1 %t239, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb56:
  %t241 = load i64, ptr %l111, !tbaa !24
  %t242 = load i64, ptr %l112, !tbaa !24
  %t243 = icmp sle i64 %t241, %t242
  br i1 %t243, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb58:
  %t245 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l108, !tbaa !24
  %t248 = load i64, ptr %l111, !tbaa !24
  %t249 = getelementptr i8, ptr %t246, i64 %t247
  %t250 = sub i64 %t248, %t247
  %t251 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t249, 1
  store { i64, ptr } %t252, ptr %l8, !tbaa !27
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_6ea1601f041f7d0c_6257690dec820828)
  unreachable
bb60:
  br label %bb12
bb61:
  %t255 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l7)
  store { i64, ptr } %t255, ptr %l118
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t256 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t256, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2ewordPayload(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l37 = alloca i32
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v1, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l4, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v1, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l20
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = load i32, ptr %l20, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %v1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l21
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp sge i64 %t36, %t39
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = icmp eq i32 %t50, 0
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  store ptr %a0, ptr %l31, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l4, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l37
  br label %bb13
bb13:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  call void @compiler_2fexplain_2epushPayload(ptr %v0, ptr %v1, ptr %t69, ptr %t70, i32 %t71, i32 %t67, i64 %t68)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2ewrittenMethod(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca i1
  %l54 = alloca i1
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l22, !tbaa !24
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l43
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l43, !tbaa !29
  store ptr %t67, ptr %l10, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l47
  br label %bb14
bb14:
  %t77 = load i64, ptr %l47, !tbaa !24
  %t79 = icmp ne i64 %t77, %a1
  br i1 %t79, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb17
bb16:
  %t81 = load ptr, ptr %l10, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  store i1 %t86, ptr %l50, !tbaa !21
  br label %bb17
bb17:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb20
bb19:
  %t89 = load ptr, ptr %l10, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %t91, !tbaa !23
  %t96 = icmp ne i32 %t92, %a3
  store i1 %t96, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t98 = load i1, ptr %l54, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l10, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v0, ptr %s2, ptr %t99, ptr %t109)
  store { i64, ptr } %t112, ptr %l64
  br label %bb24
bb24:
  %t113 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %v1, { i64, ptr } %t113, { i64, ptr } %a2)
  store i1 %t117, ptr %l67
  br label %bb25
bb25:
  %t118 = load i1, ptr %l67, !tbaa !21
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t119 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t119, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l8, !tbaa !24
  br label %bb9
bb30:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/explain:Code" @compiler_2fexplain_3aCode_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/explain:Code"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/explain:Code" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/explain:Code" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/explain:Code" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/explain:Code" %t14, { i64, ptr } %a3, 3
  store %"compiler/explain:Code" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/explain:Code", ptr %rv
  ret %"compiler/explain:Code" %rr
}

@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d2 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"held in locals and results only - its scopes (" }>, align 8
@.d3 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c") are more than a written function type says of every call (T22a)" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"held in locals and results only - the function it gives, " }>, align 8
@.d7 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c", ties scopes more than a written function type says of every call (T22a)" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"   " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fexplain_3aCode_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d12 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"instance " }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
@.d15 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"a method is called as one (M19) - a lambda calling it is a value" }>, align 8
@.d16 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"an extern fn is called by its name (X1) - a lambda calling it is a value" }>, align 8
@.d17 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"it is compiled once per length of an array it takes by value (G29) - pass a lambda calling it" }>, align 8
@.d18 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"a generic builder is a value only named with its type arguments, '" }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"<...>." }>, align 8
@.d20 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"' (G12, D19)" }>, align 8
@.d21 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a generic is a value only named with its type arguments, '" }>, align 8
@.d22 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"<...>' (G12)" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".c" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" unique" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d34 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"# effects: " }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error " }>, align 8
@.d37 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"   # declared where it is raised (R3b)\0A" }>, align 8
@.d38 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"weak " }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noborrow" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fexplain__2efitsLine_2elocal_2e15 = weak hidden constant i1 false
declare void @__olang_region_settle_in(ptr, ptr)
@.d52 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"borrows " }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @__olang_region_release(ptr) noinline
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"keeps " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"   # held in locals and results only (T22a)" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"# fits: " }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d62 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d63 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d64 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d65 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d66 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d68 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d69 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"    # " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d72 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d75 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d76 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d77 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d78 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e5 = weak hidden constant i1 false
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Generator" }>, align 8
@olang_2esole_2ecompiler__2fexplain__2efnLine_2elocal_2e9 = weak hidden constant i1 false
@.d81 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d82 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d83 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"HoldingGenerator<" }>, align 8
@.d84 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d85 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d86 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ViewGenerator<" }>, align 8
@.d87 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d89 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d90 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d94 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d96 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"    # generational: held by reference; weak from " }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d98 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d100 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d101 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d102 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d103 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"...   # " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d104 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" characters\0A" }>, align 8
@.d105 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d108 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d110 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d111 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d113 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d114 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"# not a value: " }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d116 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"# scopes: " }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d119 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d121 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"# commutes: the operator applies with its operands the other way round too (E31c)\0A" }>, align 8
@.d122 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d123 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" trait" }>, align 8
@.d124 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d125 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d127 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d129 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d130 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"    meets " }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d132 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"# followed for: " }>, align 8
@.d133 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", at " }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d136 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d138 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d139 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" enum\0A" }>, align 8
@.d140 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d141 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d143 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d144 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" packed" }>, align 8
@.d145 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d146 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d147 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" struct(" }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d149 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d150 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d151 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d152 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d153 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d154 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d155 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eGivesHeld(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H6c17f05b74a2ea6689cdfc72c602a991(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_3aFacts_2ector(ptr %v0)
@olang_loc_91de52063b71ca44_3ab230bc0b47a90 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eModuleOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feffects_2eMerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@G_2ecompiler_2feffects_2eCapCount = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2feffects_2eCapText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2ePush_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/explain:Code" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerVarCount(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_430839a36fc86f5_d60a2ea9e5c9a99 = external constant [0 x i8]
@olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3 = external constant [0 x i8]
@olang_loc_5177bd7d484351dd_5d0dbb04dc509331 = external constant [0 x i8]
@olang_loc_6448edf003c535f3_ebaded49d6e07c97 = external constant [0 x i8]
@olang_loc_979fe2e14fb6de05_5947910940c194f1 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_1f3e281b9e5e1c1b_28b60c21bdf8ccb7 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fexplain_2ereqLines(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4, i64 %a5, { i64, ptr } %a6)
@olang_loc_56ca0331d7501bc3_73eac84a38a3448f = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98928cfde749f632_385db913ea7e7976 = external constant [0 x i8]
declare { i64, ptr } @compiler_2feffects_2eDescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsRaisedError(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e71eefb410212e60_d710e4409f4406c4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_5296f019e964cb45_44665f46e1029c89 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_8f9ce818ff296c0e_932c83e6c6076d82 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_1ab09a44950d5518_36fac77ffd6769bc = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2b8cc73a4c7e88bd_6bb5eb1cd2f38021 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWeakField(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b65b7d917c440185_24d12a03c9296209 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
@G_2ecompiler_2ftypes_2ePromiseNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @compiler_2feffects_2eBreaks(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_a9d5b4a7460205c1_2b5a1ac3293d7e25 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithPromises(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRelationWords(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_fc7f64fd7b454af3_cf2a3e2278d9fc1f = external constant [0 x i8]
@olang_loc_499d9639469ba124_2d1e6838c6dcdf80 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546 = external constant [0 x i8]
@olang_loc_904aca603cad2e45_e62ac09e4cb76009 = external constant [0 x i8]
@olang_loc_e59c902bb0ddc268_5b11d99e1c27629c = external constant [0 x i8]
@olang_loc_f3704e37964cb683_929f8ce39c458747 = external constant [0 x i8]
declare i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0)
@olang_loc_87334f8237d1e26_d87acd2b8515436a = external constant [0 x i8]
declare i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0)
@olang_loc_96b8876366bd9a81_fe1335b03e31611d = external constant [0 x i8]
@olang_loc_6dce684f2a2d9d14_6d1dd538a51f95c0 = external constant [0 x i8]
@olang_loc_83191eb44b7384_f52b74cb91a30b30 = external constant [0 x i8]
@olang_loc_b6495ab5ccd815f1_8b49adc496fcf80d = external constant [0 x i8]
@olang_loc_f77a02592a0a9372_4ac4ccf0828b43ae = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
@olang_loc_85b05f6e7a1e78ef_648f77bc98c82cab = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i32, { i64, ptr } } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
@G_2ecompiler_2fexplain_2eLongValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\90\01\00\00\00\00\00\00" }>, align 8
@olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
@olang_loc_24a71f1628ab63b4_59f385be22d57b28 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
@olang_loc_2cc943ac2dc78fd5_5274b69301a971f1 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fexplain_2edeclSig(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_99dba9233bab2306_11c4778e1aad7562 = external constant [0 x i8]
@olang_loc_94ac06f7d37b19a6_b348a4f44ea9b892 = external constant [0 x i8]
@olang_loc_267284e461664677_b2c2386ba62ab5d3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_66f7703ccaf4f658_ca46a1b97aa24804 = external constant [0 x i8]
@olang_loc_f786d30f5b15881b_2a3d6cb8e4e51887 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c4fb7eb44276a12_39e0991f75dfa016 = external constant [0 x i8]
@olang_loc_f947637db6a06e39_bd7e608c8f724ffd = external constant [0 x i8]
@olang_loc_945369bc48fd3cab_701e553ecbda785f = external constant [0 x i8]
@olang_loc_6416ccbc4bdd9b53_41c21134d0645047 = external constant [0 x i8]
@olang_loc_4bcdc081c3d6706_49dcf1c0d0dc9572 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_183ac6c93ee000c_8e8c5563c1dc1de8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H1e7e683fc0332c06b6c705cd46691777(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinBody(ptr %v0, ptr %a0, i64 %a1)
declare { %"compiler/source:Span", i64 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinAt(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinWords(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a = external constant [0 x i8]
@olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f = external constant [0 x i8]
@olang_loc_a185ff5f85e75430_c999a61f9f0eedcc = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3b65fc1599fe4b35_e6657610cbc0cf91 = external constant [0 x i8]
@olang_loc_9e7f77c067ece8f1_2a0afb54e00d35 = external constant [0 x i8]
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ff0e4b22591d4baf_6e63db52d9d49f33 = external constant [0 x i8]
@olang_loc_9a288766c4af6878_87d82d450b86e5bc = external constant [0 x i8]
@olang_loc_dff7162f9e8224a5_8282e6f3b3a12619 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_a8ae3786bbd05e76_8adb6c8ffb4c6a8a = external constant [0 x i8]
@olang_loc_5d08aa5c1c4e2139_c45b4cae2d84e405 = external constant [0 x i8]
@olang_loc_6ea1601f041f7d0c_6257690dec820828 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fast_2eRecvTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
