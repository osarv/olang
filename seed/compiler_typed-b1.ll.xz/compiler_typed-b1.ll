; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Nodes" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:DerivedArg" = type { i64, i64, { i64, [2 x i64] } }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1 }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
define dso_local i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l85 = alloca { i64, ptr }
  %l92 = alloca i1
  %l97 = alloca i1
  %l106 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l124 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l139 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l156 = alloca i1
  %l168 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l188 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l198 = alloca i1
  %l199 = alloca i1
  %l203 = alloca i1
  %l205 = alloca { i64, ptr }
  %l208 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l25, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 7
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb20
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t16 = load ptr, ptr %l29, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l29, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 5
  store i1 %t22, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l30, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 8
  store i1 %t31, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l34, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb16, label %bb17
bb16:
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 16
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t44 = load ptr, ptr %l42, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb22, label %bb23
bb22:
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 6
  store i1 %t50, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t51 = load i1, ptr %l43, !tbaa !21
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l2, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l50
  br label %bb27
bb27:
  %t63 = load i1, ptr %l50, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t65 = load ptr, ptr %l51, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb29, label %bb30
bb29:
  %t68 = load ptr, ptr %l51, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 11
  store i1 %t71, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t72 = load i1, ptr %l52, !tbaa !21
  br i1 %t72, label %bb31, label %bb32
bb31:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Cond", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i1 %t86, ptr %l60
  br label %bb34
bb34:
  %t87 = load i1, ptr %l60, !tbaa !21
  br i1 %t87, label %bb35, label %bb36
bb35:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Cond", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t96 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  store i1 %t96, ptr %l66
  br label %bb37
bb36:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb38
bb37:
  %t97 = load i1, ptr %l66, !tbaa !21
  store i1 %t97, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t98 = load i1, ptr %l61, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
bb39:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb40, label %bb41
bb40:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 13
  store i1 %t106, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t107 = load i1, ptr %l68, !tbaa !21
  br i1 %t107, label %bb42, label %bb43
bb42:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l4, !tbaa !29
  br label %bb44
bb43:
  br label %bb74
bb44:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Match", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Match", ptr %t122, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l7, !tbaa !24
  br label %bb48
bb48:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb49, label %bb50
bb49:
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l85, !tbaa !27
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Arm", ptr %t147, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb52, label %bb53
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Arm", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t164 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t156, ptr %t160)
  store i1 %t164, ptr %l97
  br label %bb54
bb53:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb55
bb54:
  %t165 = load i1, ptr %l97, !tbaa !21
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l92, !tbaa !21
  br label %bb55
bb55:
  %t168 = load i1, ptr %l92, !tbaa !21
  br i1 %t168, label %bb56, label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t170 = load i64, ptr %l6, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l6, !tbaa !24
  br label %bb48
bb60:
  %t175 = load ptr, ptr %l4, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Match", ptr %t175, i32 0, i32 2
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = icmp eq ptr %t178, null
  br i1 %t180, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb66
bb62:
  %t182 = load ptr, ptr %l4, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Match", ptr %t182, i32 0, i32 2
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = icmp eq ptr %t185, null
  br i1 %t187, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb64:
  br label %bb65
bb65:
  %t189 = load ptr, ptr %l4, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Match", ptr %t189, i32 0, i32 2
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Arm", ptr %t192, i32 0, i32 4
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  store i1 %t198, ptr %l106, !tbaa !21
  br label %bb66
bb66:
  %t200 = load i1, ptr %l106, !tbaa !21
  br i1 %t200, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb73
bb68:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l116, !tbaa !29
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Match", ptr %t202, i32 0, i32 2
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = icmp eq ptr %t205, null
  br i1 %t207, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb70:
  br label %bb71
bb71:
  %t209 = load ptr, ptr %l4, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Match", ptr %t209, i32 0, i32 2
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Arm", ptr %t212, i32 0, i32 4
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load ptr, ptr %l116, !tbaa !29
  %t219 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t217, ptr %t216)
  store i1 %t219, ptr %l124
  br label %bb72
bb72:
  %t220 = load i1, ptr %l124, !tbaa !21
  store i1 %t220, ptr %l115, !tbaa !21
  br label %bb73
bb73:
  %t221 = load i1, ptr %l115, !tbaa !21
  store i1 %t221, ptr %rv
  br label %ret
bb74:
  %t222 = load ptr, ptr %l1, !tbaa !29
  store ptr %t222, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t223 = load ptr, ptr %l125, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb75, label %bb76
bb75:
  %t226 = load ptr, ptr %l125, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 18}
  %t229 = icmp eq i64 %t227, 14
  store i1 %t229, ptr %l126, !tbaa !21
  br label %bb76
bb76:
  %t230 = load i1, ptr %l126, !tbaa !21
  br i1 %t230, label %bb77, label %bb78
bb77:
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr { i64, [5 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t233, i32 0, i32 2
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l9, !tbaa !29
  br label %bb79
bb78:
  br label %bb97
bb79:
  %t237 = load ptr, ptr %l9, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Try", ptr %t237, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb80
bb80:
  %t246 = load i64, ptr %l11, !tbaa !24
  %t247 = load i64, ptr %l12, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  %t252 = xor i1 %t250, true
  br i1 %t252, label %bb81, label %bb82
bb81:
  br label %bb95
bb82:
  br label %bb83
bb83:
  %t254 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t254, ptr %l139, !tbaa !27
  %t255 = load i64, ptr %l11, !tbaa !24
  %t257 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr ptr, ptr %t258, i64 %t255
  %t260 = load ptr, ptr %t259, !tbaa !39
  %t264 = getelementptr %"compiler/typed:Clause", ptr %t260, i32 0, i32 4
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  store i64 %t269, ptr %l16, !tbaa !24
  br label %bb84
bb84:
  %t271 = load i64, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l16, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t279 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t279, ptr %l150, !tbaa !27
  %t280 = load i64, ptr %l15, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr ptr, ptr %t283, i64 %t280
  %t285 = load ptr, ptr %t284, !tbaa !39
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t292 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t287, ptr %t285)
  store i1 %t292, ptr %l156
  br label %bb88
bb88:
  %t293 = load i1, ptr %l156, !tbaa !21
  %t294 = xor i1 %t293, true
  br i1 %t294, label %bb89, label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t297 = load i64, ptr %l15, !tbaa !24
  %t300 = add i64 %t297, 1
  store i64 %t300, ptr %l15, !tbaa !24
  br label %bb84
bb93:
  br label %bb94
bb94:
  %t302 = load i64, ptr %l11, !tbaa !24
  %t305 = add i64 %t302, 1
  store i64 %t305, ptr %l11, !tbaa !24
  br label %bb80
bb95:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l9, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Try", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t314 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  store i1 %t314, ptr %l168
  br label %bb96
bb96:
  %t315 = load i1, ptr %l168, !tbaa !21
  store i1 %t315, ptr %rv
  br label %ret
bb97:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t317 = load ptr, ptr %l169, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb98, label %bb99
bb98:
  %t320 = load ptr, ptr %l169, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 18}
  %t323 = icmp eq i64 %t321, 12
  store i1 %t323, ptr %l170, !tbaa !21
  br label %bb99
bb99:
  %t324 = load i1, ptr %l170, !tbaa !21
  br i1 %t324, label %bb100, label %bb101
bb100:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l18, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Seq", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t338 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t331, ptr %t335)
  store i1 %t338, ptr %l178
  br label %bb103
bb103:
  %t339 = load i1, ptr %l178, !tbaa !21
  store i1 %t339, ptr %rv
  br label %ret
bb104:
  %t340 = load ptr, ptr %l1, !tbaa !29
  store ptr %t340, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t341 = load ptr, ptr %l179, !tbaa !29
  %t342 = icmp ne ptr %t341, null
  br i1 %t342, label %bb105, label %bb106
bb105:
  %t344 = load ptr, ptr %l179, !tbaa !29
  %t345 = load i64, ptr %t344, !range !{i64 0, i64 18}
  %t347 = icmp eq i64 %t345, 17
  store i1 %t347, ptr %l180, !tbaa !21
  br label %bb106
bb106:
  %t348 = load i1, ptr %l180, !tbaa !21
  br i1 %t348, label %bb107, label %bb108
bb107:
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr { i64, [5 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t351, i32 0, i32 2
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l19, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l19, !tbaa !29
  %t360 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t355, ptr %t356)
  store i1 %t360, ptr %l188
  br label %bb110
bb110:
  %t361 = load i1, ptr %l188, !tbaa !21
  store i1 %t361, ptr %rv
  br label %ret
bb111:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t363 = load ptr, ptr %l189, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb112, label %bb113
bb112:
  %t366 = load ptr, ptr %l189, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 18}
  %t369 = icmp eq i64 %t367, 9
  store i1 %t369, ptr %l190, !tbaa !21
  br label %bb113
bb113:
  %t370 = load i1, ptr %l190, !tbaa !21
  br i1 %t370, label %bb114, label %bb115
bb114:
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t373, i32 0, i32 2
  %t375 = load i32, ptr %t374, !range !{i32 0, i32 54}
  store i32 %t375, ptr %l20
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t379, i32 0, i32 4
  %t381 = load { i64, ptr }, ptr %t380
  store { i64, ptr } %t381, ptr %l21, !tbaa !27
  br label %bb116
bb115:
  br label %bb125
bb116:
  %t383 = load i32, ptr %l20, !range !{i32 0, i32 54}
  %t385 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t383)
  store i1 %t385, ptr %l198
  br label %bb117
bb117:
  %t386 = load i1, ptr %l198, !tbaa !21
  br i1 %t386, label %bb118, label %bb119
bb118:
  %t387 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t391 = icmp sgt i64 %t389, 0
  store i1 %t391, ptr %l199, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb120
bb120:
  %t393 = load i1, ptr %l199, !tbaa !21
  br i1 %t393, label %bb121, label %bb122
bb121:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t395, ptr %l205, !tbaa !27
  %t396 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr ptr, ptr %t397, i64 0
  %t399 = load ptr, ptr %t398, !tbaa !39
  %t403 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t394, ptr %t399)
  store i1 %t403, ptr %l208
  br label %bb123
bb122:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb124
bb123:
  %t404 = load i1, ptr %l208, !tbaa !21
  store i1 %t404, ptr %l203, !tbaa !21
  br label %bb124
bb124:
  %t405 = load i1, ptr %l203, !tbaa !21
  store i1 %t405, ptr %rv
  br label %ret
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  store i1 false, ptr %rv
  br label %ret
bb129:
  call void @__olang_check_failed(ptr @olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 6
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l8, !tbaa !29
  br label %bb28
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Promote", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = add i64 %t43, 1
  %t48 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l27
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l27, !tbaa !29
  store ptr %t49, ptr %l8, !tbaa !29
  br label %bb28
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t66, 1
  %t71 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %t65, i64 %t68)
  store ptr %t71, ptr %l37
  br label %bb22
bb22:
  %t72 = load ptr, ptr %l37, !tbaa !29
  store ptr %t72, ptr %l8, !tbaa !29
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store ptr null, ptr %l8, !tbaa !29
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_22aea6a044f95e17_c10e152cae22b18b)
  unreachable
bb28:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ftyped_2eFreshViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca i1
  %l22 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { ptr, ptr }
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l71 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l84 = alloca i64
  %l92 = alloca i1
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, [2 x i64] }
  %l98 = alloca { i64, [2 x i64] }
  %l100 = alloca i1
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l110 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l124 = alloca i64
  %l127 = alloca ptr
  %l129 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, [2 x i64] }
  %l138 = alloca { i64, [2 x i64] }
  %l140 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t9 = and i64 %t5, %t6
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp slt i32 %t17, 0
  store i1 %t19, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l22, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l27, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  store i32 %t27, ptr %l29, !tbaa !23
  %t28 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t28, ptr %l30
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t29)
  store i64 %t31, ptr %l32
  br label %bb10
bb10:
  %t32 = load i64, ptr %l32, !tbaa !24
  %t33 = trunc i64 %t32 to i32
  %t35 = load { ptr, ptr }, ptr %l30
  %t36 = extractvalue { ptr, ptr } %t35, 0
  %t37 = extractvalue { ptr, ptr } %t35, 1
  %t39 = call { i64, ptr } %t36(ptr %t37, ptr %s0, i32 %t33)
  store { i64, ptr } %t39, ptr %l35
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 8
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load i32, ptr %l29, !tbaa !23
  %t50 = call { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %s0, ptr %t47, i32 %t48, { i64, ptr } %t46)
  store { i64, [2 x i64] } %t50, ptr %l37
  br label %bb12
bb12:
  %t51 = load { i64, [2 x i64] }, ptr %l37
  store { i64, [2 x i64] } %t51, ptr %l5
  %t52 = load { i64, [2 x i64] }, ptr %l5
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l6, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t63, i64 %t64)
  store i64 %t67, ptr %l45
  br label %bb16
bb16:
  %t68 = load i64, ptr %l45, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb22
bb19:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l52, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb21
bb21:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb22
bb22:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb25:
  br label %bb26
bb26:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l2, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  store i64 %t116, ptr %l71, !tbaa !24
  %t117 = load i64, ptr %l71, !tbaa !24
  %t118 = load i64, ptr %l71, !tbaa !24
  %t119 = shl i64 1, %t118
  %t122 = and i64 %t115, %t119
  %t124 = icmp eq i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Call", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l76, !tbaa !27
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = call i1 @compiler_2ftyped_2eMovedArg(ptr %v1, ptr %t135)
  store i1 %t137, ptr %l79
  br label %bb30
bb30:
  %t138 = load i1, ptr %l79, !tbaa !21
  br i1 %t138, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb32:
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Call", ptr %t139, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l81, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  %t150 = call i64 @compiler_2ftyped_2efreshText(ptr %v1, ptr %t148, i64 0)
  store i64 %t150, ptr %l84
  br label %bb34
bb34:
  %t151 = load i64, ptr %l84, !tbaa !24
  store i64 %t151, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l12, !tbaa !24
  %t154 = icmp sge i64 %t152, 0
  br i1 %t154, label %bb35, label %bb36
bb35:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Plan", ptr %t157, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t165 = icmp sge i64 %t156, %t162
  br i1 %t165, label %bb37, label %bb38
bb36:
  br label %bb44
bb37:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb40
bb38:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Plan", ptr %t167, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l94, !tbaa !27
  %t171 = load i64, ptr %l12, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i64 %t171
  %t176 = load { i64, [2 x i64] }, ptr %t175
  store { i64, [2 x i64] } %t176, ptr %l96
  %t177 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t177, ptr %l98
  %t180 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l96, ptr %l98)
  store i1 %t180, ptr %l100
  br label %bb39
bb39:
  %t181 = load i1, ptr %l100, !tbaa !21
  %t182 = xor i1 %t181, true
  store i1 %t182, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t184 = load i1, ptr %l92, !tbaa !21
  br i1 %t184, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb44:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Call", ptr %t186, i32 0, i32 1
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l104, !tbaa !27
  %t190 = load i64, ptr %l11, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr ptr, ptr %t193, i64 %t190
  %t195 = load ptr, ptr %t194, !tbaa !39
  %t197 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v1, ptr %v1, ptr %t195, i64 0)
  store ptr %t197, ptr %l107
  br label %bb45
bb45:
  %t198 = load ptr, ptr %l107, !tbaa !29
  store ptr %t198, ptr %l13, !tbaa !29
  %t199 = load ptr, ptr %l13, !tbaa !29
  %t201 = icmp eq ptr %t199, null
  br i1 %t201, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb48
bb47:
  %t203 = load ptr, ptr %l13, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Call", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = icmp slt i32 %t206, 0
  store i1 %t208, ptr %l110, !tbaa !21
  br label %bb48
bb48:
  %t210 = load i1, ptr %l110, !tbaa !21
  br i1 %t210, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t212 = load ptr, ptr %l13, !tbaa !29
  %t214 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t212)
  store i64 %t214, ptr %l116
  br label %bb52
bb52:
  %t215 = load i64, ptr %l116, !tbaa !24
  store i64 %t215, ptr %l14, !tbaa !24
  %t216 = load i64, ptr %l14, !tbaa !24
  %t218 = icmp slt i64 %t216, 0
  br i1 %t218, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb56
bb54:
  %t221 = load i64, ptr %l14, !tbaa !24
  %t223 = trunc i64 %t221 to i32
  %t226 = extractvalue { ptr, ptr } %pg3, 0
  %t227 = extractvalue { ptr, ptr } %pg3, 1
  %t229 = call i64 %t226(ptr %t227, i32 %t223)
  store i64 %t229, ptr %l124
  br label %bb55
bb55:
  %t230 = load i64, ptr %l124, !tbaa !24
  %t231 = icmp ne i64 %t230, 0
  store i1 %t231, ptr %l119, !tbaa !21
  br label %bb56
bb56:
  %t233 = load i1, ptr %l119, !tbaa !21
  br i1 %t233, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l127, !tbaa !29
  %t236 = load ptr, ptr %l13, !tbaa !29
  %t238 = getelementptr %"compiler/typed:Call", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %t238, !tbaa !23
  store i32 %t239, ptr %l129, !tbaa !23
  %t240 = load { ptr, ptr }, ptr %l4
  %t241 = load i64, ptr %l14, !tbaa !24
  %t243 = trunc i64 %t241 to i32
  %t246 = extractvalue { ptr, ptr } %t240, 0
  %t247 = extractvalue { ptr, ptr } %t240, 1
  %t249 = call { i64, ptr } %t246(ptr %t247, ptr %s4, i32 %t243)
  store { i64, ptr } %t249, ptr %l134
  br label %bb60
bb60:
  %t250 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 8
  %t254 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load ptr, ptr %l127, !tbaa !29
  %t258 = load i32, ptr %l129, !tbaa !23
  %t260 = call { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %s4, ptr %t257, i32 %t258, { i64, ptr } %t256)
  store { i64, [2 x i64] } %t260, ptr %l136
  br label %bb61
bb61:
  %t261 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t261, ptr %l138
  %t264 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l136, ptr %l138)
  store i1 %t264, ptr %l140
  br label %bb62
bb62:
  %t265 = load i1, ptr %l140, !tbaa !21
  %t266 = xor i1 %t265, true
  br i1 %t266, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb66:
  %t269 = load i64, ptr %l10, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l10, !tbaa !24
  br label %bb23
bb67:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2eLocalUses_2eOver(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/typed:Local"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca %"compiler/typed:LocalUses"
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca %"compiler/typed:Local"
  %l79 = alloca ptr
  %l82 = alloca i64
  %l89 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i1
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i32
  %l124 = alloca %"compiler/typed:LocalUses"
  %t3 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_3aLocalUses_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %v3, ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t3, i64 1640, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 1640, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l18, i64 1640, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t10)
  store i64 %t12, ptr %l21
  br label %bb2
bb2:
  %t13 = load i64, ptr %l21, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l28, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l28, !tbaa !24
  store i64 %t40, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load ptr, ptr %lp3
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t60, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t61, i1 false)
  br label %bb13
bb13:
  %t63 = load ptr, ptr %lp3
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t63, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t64, i1 false)
  br label %bb14
bb14:
  %t66 = load ptr, ptr %lp3
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %t66, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t67, i1 false)
  br label %bb15
bb15:
  %t69 = load ptr, ptr %lp3
  %t70 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t70, i1 false)
  br label %bb16
bb16:
  %t72 = load ptr, ptr %lp3
  %t73 = getelementptr %"compiler/typed:LocalUses", ptr %t72, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t73, i1 false)
  br label %bb17
bb17:
  %t75 = load ptr, ptr %lp3
  %t76 = getelementptr %"compiler/typed:LocalUses", ptr %t75, i32 0, i32 56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t76, i64 0)
  br label %bb18
bb18:
  %t78 = load ptr, ptr %lp3
  %t79 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t79, i1 false)
  br label %bb19
bb19:
  %t81 = load ptr, ptr %lp3
  %t82 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t82, i1 false)
  br label %bb20
bb20:
  %t84 = load ptr, ptr %lp3
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t84, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t85, i1 false)
  br label %bb21
bb21:
  %t87 = load ptr, ptr %lp3
  %t88 = getelementptr %"compiler/typed:LocalUses", ptr %t87, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t88, i1 false)
  br label %bb22
bb22:
  %t90 = load ptr, ptr %lp3
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t90, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t91, i1 false)
  br label %bb23
bb23:
  %t93 = load ptr, ptr %lp3
  %t94 = getelementptr %"compiler/typed:LocalUses", ptr %t93, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t94, i64 -1)
  br label %bb24
bb24:
  %t96 = load ptr, ptr %lp3
  %t97 = getelementptr %"compiler/typed:LocalUses", ptr %t96, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v3, ptr %v3, ptr %t97, ptr null)
  br label %bb25
bb25:
  %t99 = load ptr, ptr %lp3
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t99, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v3, ptr %v3, ptr %t100, ptr null)
  br label %bb26
bb26:
  %t102 = load ptr, ptr %lp3
  %t103 = getelementptr %"compiler/typed:LocalUses", ptr %t102, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t103, i1 false)
  br label %bb27
bb27:
  %t105 = load ptr, ptr %lp3
  %t106 = getelementptr %"compiler/typed:LocalUses", ptr %t105, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t106, i1 false)
  br label %bb28
bb28:
  %t108 = load ptr, ptr %lp3
  %t109 = getelementptr %"compiler/typed:LocalUses", ptr %t108, i32 0, i32 41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t109, i1 false)
  br label %bb29
bb29:
  %t111 = load ptr, ptr %lp3
  %t112 = getelementptr %"compiler/typed:LocalUses", ptr %t111, i32 0, i32 42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t112, i1 false)
  br label %bb30
bb30:
  %t114 = load ptr, ptr %lp3
  %t115 = getelementptr %"compiler/typed:LocalUses", ptr %t114, i32 0, i32 43
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t115, i1 false)
  br label %bb31
bb31:
  %t117 = load ptr, ptr %lp3
  %t118 = getelementptr %"compiler/typed:LocalUses", ptr %t117, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t118, i1 false)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l8, !tbaa !24
  br label %bb9
bb34:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Body", ptr %t125, i32 0, i32 7
  store ptr %t127, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb35
bb35:
  %t129 = load i64, ptr %l11, !tbaa !24
  store i64 %t129, ptr %l71, !tbaa !24
  %t130 = load ptr, ptr %l10, !tbaa !29
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t130)
  store i64 %t132, ptr %l73
  br label %bb36
bb36:
  %t133 = load i64, ptr %l71, !tbaa !24
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = icmp slt i64 %t133, %t134
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb37, label %bb38
bb37:
  br label %bb46
bb38:
  br label %bb39
bb39:
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t139, i64 %t140)
  store %"compiler/typed:Local" %t143, ptr %l78
  br label %bb40
bb40:
  %t144 = load %"compiler/typed:Local", ptr %l78
  store %"compiler/typed:Local" %t144, ptr %l12
  %t145 = load ptr, ptr %lp3
  %t146 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 55
  store ptr %t146, ptr %l79, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 4
  %t148 = load i32, ptr %t147, !range !{i32 0, i32 7}
  %t150 = trunc i64 0 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb41, label %bb42
bb41:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb43
bb42:
  store i64 9223372036854775807, ptr %l82, !tbaa !24
  br label %bb43
bb43:
  %t153 = load ptr, ptr %l79, !tbaa !29
  %t154 = load i64, ptr %l82, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t153, i64 %t154)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l11, !tbaa !24
  br label %bb35
bb46:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %t163, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t160, i32 %t164)
  store i32 %t167, ptr %l89
  br label %bb47
bb47:
  %t168 = load i32, ptr %l89, !range !{i32 0, i32 33}
  %t170 = trunc i64 21 to i32
  %t171 = icmp eq i32 %t168, %t170
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb52
bb49:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l94, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Body", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t176, i32 %t180)
  store i32 %t183, ptr %l98
  br label %bb50
bb50:
  %t184 = load ptr, ptr %l94, !tbaa !29
  %t185 = load i32, ptr %l98, !tbaa !23
  %t186 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t184, i32 %t185)
  store i1 %t186, ptr %l99
  br label %bb51
bb51:
  %t187 = load i1, ptr %l99, !tbaa !21
  %t188 = xor i1 %t187, true
  store i1 %t188, ptr %l93, !tbaa !21
  br label %bb52
bb52:
  %t190 = load i1, ptr %l93, !tbaa !21
  %t191 = load ptr, ptr %lp3
  %t192 = getelementptr %"compiler/typed:LocalUses", ptr %t191, i32 0, i32 63
  store i1 %t190, ptr %t192, !tbaa !21
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb53, label %bb54
bb53:
  %t199 = load ptr, ptr %lp3
  %t200 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v3, ptr %v2, ptr %v1, ptr %v0, ptr %t199, ptr %t200)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Body", ptr %t204, i32 0, i32 10
  store ptr %t206, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb57
bb57:
  %t208 = load i64, ptr %l14, !tbaa !24
  store i64 %t208, ptr %l109, !tbaa !24
  %t209 = load ptr, ptr %l13, !tbaa !29
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t209)
  store i64 %t211, ptr %l111
  br label %bb58
bb58:
  %t212 = load i64, ptr %l109, !tbaa !24
  %t213 = load i64, ptr %l111, !tbaa !24
  %t214 = icmp slt i64 %t212, %t213
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb59, label %bb60
bb59:
  br label %bb65
bb60:
  br label %bb61
bb61:
  %t218 = load ptr, ptr %l13, !tbaa !29
  %t219 = load i64, ptr %l14, !tbaa !24
  %t222 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t218, i64 %t219)
  store i32 %t222, ptr %l116
  br label %bb62
bb62:
  %t223 = load i32, ptr %l116, !tbaa !23
  %t224 = load ptr, ptr %lp3
  %t225 = getelementptr %"compiler/typed:LocalUses", ptr %t224, i32 0, i32 18
  %t228 = sext i32 %t223 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v3, ptr %t225, i64 %t228, i1 true)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t231 = load i64, ptr %l14, !tbaa !24
  %t234 = add i64 %t231, 1
  store i64 %t234, ptr %l14, !tbaa !24
  br label %bb57
bb65:
  %t236 = load ptr, ptr %lp3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v3, ptr %v0, ptr %t236)
  br label %bb66
bb66:
  %t238 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l124, ptr %t238, i64 1640, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l124, i64 1640, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftyped_2ePlan_2eRead(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3c, ptr %a3e, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l17 = alloca %"compiler/typed:Plan"
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca %"compiler/typed:Plan"
  %l27 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l45 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i32
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca i32
  %l89 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l111 = alloca i32
  %l116 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  %t32 = alloca %"compiler/typed:Plan", align 8
  store { i64, ptr } %a1, ptr %l1
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l15
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l14
  br label %bb1
bb1:
  %t8 = load i64, ptr %l14, !tbaa !24
  store i64 %t8, ptr %l12, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb4:
  %t10 = load i64, ptr %l12, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store ptr %a0, ptr %l18, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l19, !tbaa !27
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l20, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l21, !tbaa !24
  %t16 = icmp sge i64 0, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp sle i64 0, %t18
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3e253382f788b905_6ccfe79f085c7c71)
  unreachable
bb7:
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = load i64, ptr %l21, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3e253382f788b905_6ccfe79f085c7c71)
  unreachable
bb9:
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = getelementptr i8, ptr %t26, i64 0
  %t29 = sub i64 %t27, 0
  %t30 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t35 = call i32 @compiler_2ftyped_2ePlan_2ereadHead(ptr %t32, ptr %v0, ptr %v1, ptr %v5, ptr %t33, { i64, ptr } %t31)
  store i32 %t35, ptr %l27
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb12, label %ok.37, !prof !99
ok.37:
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t32, i64 584, i1 false)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3e253382f788b905_6ccfe79f085c7c71)
  unreachable
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l26, i64 584, i1 false)
  br label %bb13
bb12:
  %t38 = load i32, ptr %l27, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
bb13:
  %t48 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 584, i64 8)
  store ptr %t48, ptr %lp6
  %t49 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %l17, i64 584, i1 false)
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %l29, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t51, 3
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t54, 0
  store i64 %t57, ptr %l34, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l35, !tbaa !24
  %t60 = load i64, ptr %l31, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = load i64, ptr %l31, !tbaa !24
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_dc214fe2b685dd28_b709a607efcfda04)
  unreachable
bb16:
  %t67 = load i64, ptr %l34, !tbaa !24
  %t68 = load i64, ptr %l35, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_dc214fe2b685dd28_b709a607efcfda04)
  unreachable
bb18:
  %t71 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l31, !tbaa !24
  %t74 = load i64, ptr %l34, !tbaa !24
  %t75 = getelementptr i8, ptr %t72, i64 %t73
  %t76 = sub i64 %t74, %t73
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  store { i64, ptr } %t78, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_dc214fe2b685dd28_b709a607efcfda04)
  unreachable
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t86 = icmp slt i64 %t80, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb65
bb22:
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp ne i8 %t96, 32
  br i1 %t98, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t105, 0
  store i64 %t108, ptr %l56, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l57, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sge i64 %t111, 0
  br i1 %t112, label %bb27, label %bb28
bb27:
  %t114 = load i64, ptr %l53, !tbaa !24
  %t115 = load i64, ptr %l56, !tbaa !24
  %t116 = icmp sle i64 %t114, %t115
  br i1 %t116, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5740aeca99b81243_3c36ec57b5a2df6f)
  unreachable
bb29:
  %t118 = load i64, ptr %l56, !tbaa !24
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = icmp sle i64 %t118, %t119
  br i1 %t120, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_5740aeca99b81243_3c36ec57b5a2df6f)
  unreachable
bb31:
  %t122 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l53, !tbaa !24
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = getelementptr i8, ptr %t123, i64 %t124
  %t127 = sub i64 %t125, %t124
  %t128 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t131 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s2, { i64, ptr } %t129, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  %t132 = extractvalue { i32, i64 } %t131, 1
  %t133 = extractvalue { i32, i64 } %t131, 0
  store i32 %t133, ptr %l63
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb34, label %ok.135, !prof !99
ok.135:
  store i64 %t132, ptr %l62
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5740aeca99b81243_3c36ec57b5a2df6f)
  unreachable
bb33:
  %t136 = load i64, ptr %l62, !tbaa !24
  store i64 %t136, ptr %l50, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb36:
  %t138 = load i64, ptr %l50, !tbaa !24
  store i64 %t138, ptr %l9, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t139, ptr %l66, !tbaa !27
  %t140 = load i64, ptr %l8, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l68, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load i64, ptr %l9, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l72, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l73, !tbaa !24
  %t152 = load i64, ptr %l68, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb37, label %bb38
bb37:
  %t155 = load i64, ptr %l68, !tbaa !24
  %t156 = load i64, ptr %l72, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  br i1 %t157, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_69f10c2cb664a4e6_ae008f42658ef9f2)
  unreachable
bb39:
  %t159 = load i64, ptr %l72, !tbaa !24
  %t160 = load i64, ptr %l73, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  br i1 %t161, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_69f10c2cb664a4e6_ae008f42658ef9f2)
  unreachable
bb41:
  %t163 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l68, !tbaa !24
  %t166 = load i64, ptr %l72, !tbaa !24
  %t167 = getelementptr i8, ptr %t164, i64 %t165
  %t168 = sub i64 %t166, %t165
  %t169 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  store { i64, ptr } %t170, ptr %l77, !tbaa !27
  %t171 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 10)
  %t172 = extractvalue { i32, i64 } %t171, 1
  %t173 = extractvalue { i32, i64 } %t171, 0
  store i32 %t173, ptr %l79
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb44, label %ok.175, !prof !99
ok.175:
  store i64 %t172, ptr %l78
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_69f10c2cb664a4e6_ae008f42658ef9f2)
  unreachable
bb43:
  %t176 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t177 = load i64, ptr %l78, !tbaa !24
  %t178 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v1, { i64, ptr } %t176, i64 %t177)
  %t179 = extractvalue { i32, i64 } %t178, 1
  %t180 = extractvalue { i32, i64 } %t178, 0
  store i32 %t180, ptr %l81
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb47, label %ok.182, !prof !99
ok.182:
  store i64 %t179, ptr %l80
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb46:
  %t184 = load i64, ptr %l80, !tbaa !24
  store i64 %t184, ptr %l65, !tbaa !24
  br label %bb48
bb47:
  br label %bb45
bb48:
  %t185 = load i64, ptr %l65, !tbaa !24
  store i64 %t185, ptr %l10, !tbaa !24
  %t186 = load i64, ptr %l8, !tbaa !24
  %t188 = add i64 %t186, 2
  %t189 = load i64, ptr %l9, !tbaa !24
  %t192 = add i64 %t188, %t189
  store i64 %t192, ptr %l11, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t196 = icmp sle i64 %t194, 0
  br i1 %t196, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb51
bb50:
  %t198 = load i64, ptr %l11, !tbaa !24
  %t199 = load i64, ptr %l10, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t203 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t208 = icmp sgt i64 %t202, %t205
  store i1 %t208, ptr %l89, !tbaa !21
  br label %bb51
bb51:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t212 = load ptr, ptr %lp6
  store ptr %t212, ptr %l97, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t213, ptr %l98, !tbaa !27
  %t214 = load i64, ptr %l11, !tbaa !24
  store i64 %t214, ptr %l99, !tbaa !24
  %t215 = load i64, ptr %l11, !tbaa !24
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = add i64 %t215, %t216
  store i64 %t219, ptr %l102, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l103, !tbaa !24
  %t222 = load i64, ptr %l99, !tbaa !24
  %t223 = icmp sge i64 %t222, 0
  br i1 %t223, label %bb55, label %bb56
bb55:
  %t225 = load i64, ptr %l99, !tbaa !24
  %t226 = load i64, ptr %l102, !tbaa !24
  %t227 = icmp sle i64 %t225, %t226
  br i1 %t227, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_6900592c315792a9_d75ca3f288cd056d)
  unreachable
bb57:
  %t229 = load i64, ptr %l102, !tbaa !24
  %t230 = load i64, ptr %l103, !tbaa !24
  %t231 = icmp sle i64 %t229, %t230
  br i1 %t231, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_6900592c315792a9_d75ca3f288cd056d)
  unreachable
bb59:
  %t233 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l99, !tbaa !24
  %t236 = load i64, ptr %l102, !tbaa !24
  %t237 = getelementptr i8, ptr %t234, i64 %t235
  %t238 = sub i64 %t236, %t235
  %t239 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t237, 1
  %t244 = load ptr, ptr %l97, !tbaa !29
  %t248 = extractvalue { ptr, ptr } %pg3, 0
  %t249 = extractvalue { ptr, ptr } %pg3, 1
  %t251 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ereadRef(ptr %v5, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t244, { i64, ptr } %t240, ptr %a2, ptr %t248, ptr %t249, { i64, ptr } %a4)
  store i32 %t251, ptr %l111
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb62, label %ok.253, !prof !99
ok.253:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_6900592c315792a9_d75ca3f288cd056d)
  unreachable
bb61:
  br label %bb63
bb62:
  %t254 = load i32, ptr %l111, !tbaa !23
  %t255 = lshr i32 %t254, 16
  %t256 = and i32 %t254, 65535
  %t257 = icmp eq i32 %t255, 1
  %t258 = select i1 %t257, i32 1, i32 0
  %t259 = icmp eq i32 %t254, 0
  %t260 = shl i32 %t258, 16
  %t261 = or i32 %t260, %t256
  %t262 = select i1 %t259, i32 0, i32 %t261
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t262, ptr %rv
  br label %ret
bb63:
  %t264 = load i64, ptr %l11, !tbaa !24
  %t265 = load i64, ptr %l10, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb64:
  br label %bb20
bb65:
  %t270 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %l116, ptr %t270, i64 584, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l116, i64 584, i1 false)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb37
bb4:
  %t8 = load { i64, [2 x i64] }, ptr %l0
  %t10 = extractvalue { i64, [2 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t14 = getelementptr { i32 }, ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l1, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = load i32, ptr %l1, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t23 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = getelementptr i8, ptr %t25, i64 %t21
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %t19)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  br label %bb37
bb8:
  %t31 = load { i64, [2 x i64] }, ptr %l0
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 2
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t37 = getelementptr { i64 }, ptr %t36, i32 0, i32 0
  %t38 = load i64, ptr %t37
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t40)
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t40)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  br label %bb37
bb12:
  %t52 = load { i64, [2 x i64] }, ptr %l0
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 3
  br i1 %t55, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t57, ptr %l6, !tbaa !27
  br label %bb37
bb16:
  %t59 = load { i64, [2 x i64] }, ptr %l0
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 5
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t64, ptr %l6, !tbaa !27
  br label %bb37
bb20:
  %t66 = load { i64, [2 x i64] }, ptr %l0
  %t68 = extractvalue { i64, [2 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 6
  br i1 %t69, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  br label %bb37
bb24:
  %t73 = load { i64, [2 x i64] }, ptr %l0
  %t75 = extractvalue { i64, [2 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 7
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t79 = getelementptr { i64 }, ptr %t78, i32 0, i32 0
  %t80 = load i64, ptr %t79
  store i64 %t80, ptr %l3, !tbaa !24
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t86 = call i64 @__olang_fmt_i64(ptr null, i64 %t82)
  %t87 = add i64 %t84, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t83, i64 %t84)
  %t89 = getelementptr i8, ptr %t88, i64 %t84
  %t90 = call i64 @__olang_fmt_i64(ptr %t89, i64 %t82)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t88, 1
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  br label %bb37
bb28:
  %t94 = load { i64, [2 x i64] }, ptr %l0
  %t96 = extractvalue { i64, [2 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 8
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t100 = getelementptr { i64, i64 }, ptr %t99, i32 0, i32 0
  %t101 = load i64, ptr %t100
  store i64 %t101, ptr %l4, !tbaa !24
  %t103 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t104 = getelementptr { i64, i64 }, ptr %t103, i32 0, i32 1
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t107 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t112 = call i64 @__olang_fmt_i64(ptr null, i64 %t107)
  %t113 = add i64 %t110, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t118 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t109, i64 %t110)
  %t121 = getelementptr i8, ptr %t120, i64 %t110
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t107)
  %t123 = getelementptr i8, ptr %t121, i64 %t112
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  %t125 = call i64 @__olang_fmt_i64(ptr %t124, i64 %t108)
  %t126 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t120, 1
  store { i64, ptr } %t127, ptr %l6, !tbaa !27
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4b5d458aacbb0718_a8ad2bd2a7dc13cc)
  unreachable
bb37:
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l47, !tbaa !24
  %t133 = load i64, ptr %l47, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l48, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l47, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t144, ptr %l6, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t145, 1
  store { i32, { i64, ptr } } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t76 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t58 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t69 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %t65)
  store { i64, [2 x i64] } %t69, ptr %l43
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t70 = load { i64, [2 x i64] }, ptr %l43
  store { i64, [2 x i64] } %t70, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l7, !tbaa !24
  br label %bb7
bb16:
  store { i64, [2 x i64] } zeroinitializer, ptr %t76
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t76, i32 0, i32 0
  store i64 0, ptr %t77
  %t78 = load { i64, [2 x i64] }, ptr %t76
  store { i64, [2 x i64] } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i32
  %l18 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load i32, ptr %l13, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t15 = trunc i64 19 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l18
  br label %bb6
bb6:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = icmp eq i32 %t23, 0
  store i1 %t24, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t28 = trunc i64 22 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t33 = trunc i64 23 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = load i32, ptr %l27, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l28
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t66, i32 %t64)
  store i1 %t70, ptr %l40
  br label %bb19
bb19:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb15
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ecb034f719e18c1b_985175307bfdc34f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ebitsText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l20 = alloca i8
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i1, ptr %t22, i64 %t19
  %t24 = load i1, ptr %t23, !tbaa !31
  store ptr %l1, ptr %l18, !tbaa !29
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i8 49, ptr %l20, !tbaa !22
  br label %bb9
bb8:
  store i8 48, ptr %l20, !tbaa !22
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load i8, ptr %l20, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t28, i8 %t29)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb3
bb12:
  %t36 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t36, ptr %l25
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca i1
  %l87 = alloca i64
  %l91 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:LastUses", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LastUses", ptr %t55, i32 0, i32 8
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l47
  br label %bb12
bb12:
  %t62 = load i64, ptr %l47, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb37
bb14:
  br label %bb15
bb15:
  %t69 = add i64 %a1, 1
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LastUses", ptr %t71, i32 0, i32 3
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb21
bb18:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l12, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l61, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t104 = load i64, ptr %l61, !tbaa !24
  store i64 %t104, ptr %l58, !tbaa !24
  br label %bb21
bb21:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t106 = load i64, ptr %l14, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb23, label %bb24
bb23:
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l15, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp ne i64 %t124, %t125
  br i1 %t128, label %bb26, label %bb27
bb26:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/typed:LastUses", ptr %t130, i32 0, i32 9
  %t133 = load i64, ptr %l15, !tbaa !24
  %t135 = sub i64 %t133, 1
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t132, i64 %t135)
  store i64 %t138, ptr %l87
  br label %bb28
bb27:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb30
bb28:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:LastUses", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l91
  br label %bb29
bb29:
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = load i64, ptr %l91, !tbaa !24
  %t148 = icmp eq i64 %t146, %t147
  store i1 %t148, ptr %l82, !tbaa !21
  br label %bb30
bb30:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/typed:LastUses", ptr %t151, i32 0, i32 8
  %t154 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t153, i64 %t154, i64 -1)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l14, !tbaa !24
  br label %bb22
bb36:
  br label %bb37
bb37:
  %t162 = load i64, ptr %l7, !tbaa !24
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %l7, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l9, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %t59, i32 %t63)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l9, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  br label %bb11
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l9, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Bind", ptr %t75, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t74, i32 %t78)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb6
bb14:
  br label %bb15
bb15:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t98, ptr %t102)
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Arm", ptr %t106, i32 0, i32 4
  %t109 = load ptr, ptr %t108, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t105, ptr %t109)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i1
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l49 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l56 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Make", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 5}
  %t6 = trunc i64 4 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Make", ptr %t11, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Make", ptr %t21, i32 0, i32 4
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = icmp slt i32 %t24, 0
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Make", ptr %t29, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 0
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v1, ptr %t36)
  store i64 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:LastUses", ptr %t45, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = icmp sge i64 %t44, %t48
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:LastUses", ptr %t54, i32 0, i32 6
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Make", ptr %t57, i32 0, i32 4
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t56, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:LastUses", ptr %t65, i32 0, i32 7
  %t68 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LastUses", ptr %t71, i32 0, i32 5
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp sgt i64 %t74, 0
  br i1 %t76, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb24
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LastUses", ptr %t78, i32 0, i32 2
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  %t89 = icmp sge i64 %t87, 0
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/typed:LastUses", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LastUses", ptr %t95, i32 0, i32 2
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l49, !tbaa !27
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i64, ptr %t102, i64 %t99
  %t104 = load i64, ptr %t103, !tbaa !34
  %t107 = icmp sgt i64 %t94, %t104
  store i1 %t107, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t109 = load i1, ptr %l45, !tbaa !21
  store i1 %t109, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t110 = load i1, ptr %l39, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:LastUses", ptr %t111, i32 0, i32 8
  store ptr %t113, ptr %l54, !tbaa !29
  br i1 %t110, label %bb25, label %bb26
bb25:
  store i64 -1, ptr %l56, !tbaa !24
  br label %bb27
bb26:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/typed:LastUses", ptr %t116, i32 0, i32 3
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l56, !tbaa !24
  br label %bb27
bb27:
  %t123 = load ptr, ptr %l54, !tbaa !29
  %t124 = load i64, ptr %l56, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t123, i64 %t124)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l213 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l251 = alloca ptr
  %l252 = alloca i1
  %l265 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l269 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t6 = load ptr, ptr %l33, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l33, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l34, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t15 = load ptr, ptr %l37, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l37, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l38, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l38, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb170
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t24 = load ptr, ptr %l41, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l41, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l42, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t39 = load ptr, ptr %l47, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l47, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l48, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t54 = load ptr, ptr %l53, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l53, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l54, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb170
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t73 = load ptr, ptr %l61, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l61, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l62, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l62, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb170
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t96 = load ptr, ptr %l71, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l71, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l72, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb56
bb40:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LastUses", ptr %t110, i32 0, i32 3
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:LastUses", ptr %t115, i32 0, i32 6
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l81
  br label %bb41
bb41:
  %t120 = load i64, ptr %l81, !tbaa !24
  store i64 %t120, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l7, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  store ptr %t126, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t127 = load ptr, ptr %l84, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l84, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 5}
  %t133 = icmp eq i64 %t131, 2
  store i1 %t133, ptr %l85, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l85, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { ptr }, ptr %t137, i32 0, i32 0
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l8, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_198aad80d0550ab5_c06608159f163401)
  unreachable
bb53:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Call", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t146, { i64, ptr } %t150)
  br label %bb54
bb54:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i64, ptr %l5, !tbaa !24
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  br label %bb55
bb55:
  br label %bb170
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t160 = load ptr, ptr %l99, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb57, label %bb58
bb57:
  %t163 = load ptr, ptr %l99, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 7
  store i1 %t166, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l100, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb67
bb61:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LastUses", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l10, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/typed:LastUses", ptr %t179, i32 0, i32 6
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l109
  br label %bb62
bb62:
  %t184 = load i64, ptr %l109, !tbaa !24
  store i64 %t184, ptr %l11, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %t185, ptr %t186)
  br label %bb63
bb63:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Make", ptr %t190, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t189, { i64, ptr } %t193)
  br label %bb64
bb64:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l9, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Make", ptr %t197, i32 0, i32 3
  %t200 = load ptr, ptr %t199, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t196, ptr %t200)
  br label %bb65
bb65:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t203, i64 %t204, i64 %t205)
  br label %bb66
bb66:
  br label %bb170
bb67:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t210 = load ptr, ptr %l121, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l121, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 8
  store i1 %t216, ptr %l122, !tbaa !21
  br label %bb69
bb69:
  %t217 = load i1, ptr %l122, !tbaa !21
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l12, !tbaa !29
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Collect", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t228)
  br label %bb73
bb73:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l130, !tbaa !29
  %t232 = load ptr, ptr %l130, !tbaa !29
  %t233 = getelementptr %"compiler/typed:LastUses", ptr %t232, i32 0, i32 4
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = add i64 %t234, 1
  %t239 = load ptr, ptr %l130, !tbaa !29
  %t240 = getelementptr %"compiler/typed:LastUses", ptr %t239, i32 0, i32 4
  store i64 %t237, ptr %t240, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l12, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Collect", ptr %t242, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t241, ptr %t245)
  br label %bb74
bb74:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l138, !tbaa !29
  %t250 = load ptr, ptr %l138, !tbaa !29
  %t251 = getelementptr %"compiler/typed:LastUses", ptr %t250, i32 0, i32 4
  %t252 = load i64, ptr %t251, !tbaa !24
  %t255 = sub i64 %t252, 1
  %t257 = load ptr, ptr %l138, !tbaa !29
  %t258 = getelementptr %"compiler/typed:LastUses", ptr %t257, i32 0, i32 4
  store i64 %t255, ptr %t258, !tbaa !24
  br label %bb170
bb75:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t260 = load ptr, ptr %l142, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb76, label %bb77
bb76:
  %t263 = load ptr, ptr %l142, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 9
  store i1 %t266, ptr %l143, !tbaa !21
  br label %bb77
bb77:
  %t267 = load i1, ptr %l143, !tbaa !21
  br i1 %t267, label %bb78, label %bb79
bb78:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t270, i32 0, i32 4
  %t272 = load { i64, ptr }, ptr %t271
  store { i64, ptr } %t272, ptr %l13, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t274, { i64, ptr } %t275)
  br label %bb81
bb81:
  br label %bb170
bb82:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t279 = load ptr, ptr %l150, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l150, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 18}
  %t285 = icmp eq i64 %t283, 10
  store i1 %t285, ptr %l151, !tbaa !21
  br label %bb84
bb84:
  %t286 = load i1, ptr %l151, !tbaa !21
  br i1 %t286, label %bb85, label %bb86
bb85:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [5 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t289, i32 0, i32 2
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l14, !tbaa !29
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l14, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Slice", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t293, ptr %t297)
  br label %bb88
bb88:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Slice", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t300, ptr %t304)
  br label %bb89
bb89:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l14, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Slice", ptr %t309, i32 0, i32 2
  %t312 = load ptr, ptr %t311, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t308, ptr %t312)
  br label %bb90
bb90:
  br label %bb170
bb91:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t317 = load ptr, ptr %l167, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb92, label %bb93
bb92:
  %t320 = load ptr, ptr %l167, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 18}
  %t323 = icmp eq i64 %t321, 11
  store i1 %t323, ptr %l168, !tbaa !21
  br label %bb93
bb93:
  %t324 = load i1, ptr %l168, !tbaa !21
  br i1 %t324, label %bb94, label %bb95
bb94:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l15, !tbaa !29
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l15, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Cond", ptr %t332, i32 0, i32 0
  %t335 = load ptr, ptr %t334, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t331, ptr %t335)
  br label %bb97
bb97:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l15, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Cond", ptr %t340, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t339, ptr %t343)
  br label %bb98
bb98:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l15, !tbaa !29
  %t349 = getelementptr %"compiler/typed:Cond", ptr %t347, i32 0, i32 2
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t350)
  br label %bb99
bb99:
  br label %bb170
bb100:
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t355 = load ptr, ptr %l184, !tbaa !29
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %bb101, label %bb102
bb101:
  %t358 = load ptr, ptr %l184, !tbaa !29
  %t359 = load i64, ptr %t358, !range !{i64 0, i64 18}
  %t361 = icmp eq i64 %t359, 12
  store i1 %t361, ptr %l185, !tbaa !21
  br label %bb102
bb102:
  %t362 = load i1, ptr %l185, !tbaa !21
  br i1 %t362, label %bb103, label %bb104
bb103:
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr { i64, [5 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t365, i32 0, i32 2
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l16, !tbaa !29
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l16, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Seq", ptr %t370, i32 0, i32 0
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t369, { i64, ptr } %t373)
  br label %bb106
bb106:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l16, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Seq", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t376, ptr %t380)
  br label %bb107
bb107:
  br label %bb170
bb108:
  %t383 = load ptr, ptr %l1, !tbaa !29
  store ptr %t383, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t384 = load ptr, ptr %l196, !tbaa !29
  %t385 = icmp ne ptr %t384, null
  br i1 %t385, label %bb109, label %bb110
bb109:
  %t387 = load ptr, ptr %l196, !tbaa !29
  %t388 = load i64, ptr %t387, !range !{i64 0, i64 18}
  %t390 = icmp eq i64 %t388, 13
  store i1 %t390, ptr %l197, !tbaa !21
  br label %bb110
bb110:
  %t391 = load i1, ptr %l197, !tbaa !21
  br i1 %t391, label %bb111, label %bb112
bb111:
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t392, i32 0, i32 1
  %t395 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t394, i32 0, i32 2
  %t396 = load ptr, ptr %t395
  store ptr %t396, ptr %l17, !tbaa !29
  br label %bb113
bb112:
  br label %bb129
bb113:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l17, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Match", ptr %t399, i32 0, i32 0
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t398, { i64, ptr } %t402)
  br label %bb114
bb114:
  %t405 = load ptr, ptr %l17, !tbaa !29
  %t407 = getelementptr %"compiler/typed:Match", ptr %t405, i32 0, i32 1
  %t408 = load { i64, ptr }, ptr %t407, !tbaa !27
  store { i64, ptr } %t408, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t410 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 0
  store i64 %t412, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t414 = load i64, ptr %l19, !tbaa !24
  %t415 = load i64, ptr %l20, !tbaa !24
  %t418 = icmp slt i64 %t414, %t415
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t422 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t422, ptr %l213, !tbaa !27
  %t423 = load i64, ptr %l19, !tbaa !24
  %t425 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = getelementptr ptr, ptr %t426, i64 %t423
  %t428 = load ptr, ptr %t427, !tbaa !39
  %t430 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t430, ptr %t428)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t434 = load i64, ptr %l19, !tbaa !24
  %t437 = add i64 %t434, 1
  store i64 %t437, ptr %l19, !tbaa !24
  br label %bb115
bb121:
  %t439 = load ptr, ptr %l17, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Match", ptr %t439, i32 0, i32 2
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = icmp eq ptr %t442, null
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb122, label %bb123
bb122:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l225, !tbaa !29
  %t449 = load ptr, ptr %l17, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Match", ptr %t449, i32 0, i32 2
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = icmp eq ptr %t452, null
  br i1 %t454, label %bb124, label %bb125
bb123:
  br label %bb128
bb124:
  call void @__olang_check_failed(ptr @olang_loc_28655f8a56cf669d_dc60f62ebe04c639)
  unreachable
bb125:
  br label %bb126
bb126:
  %t456 = load ptr, ptr %l17, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Match", ptr %t456, i32 0, i32 2
  %t459 = load ptr, ptr %t458, !tbaa !29
  %t460 = load ptr, ptr %l225, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t460, ptr %t459)
  br label %bb127
bb127:
  br label %bb128
bb128:
  br label %bb170
bb129:
  %t462 = load ptr, ptr %l1, !tbaa !29
  store ptr %t462, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = icmp ne ptr %t463, null
  br i1 %t464, label %bb130, label %bb131
bb130:
  %t466 = load ptr, ptr %l231, !tbaa !29
  %t467 = load i64, ptr %t466, !range !{i64 0, i64 18}
  %t469 = icmp eq i64 %t467, 14
  store i1 %t469, ptr %l232, !tbaa !21
  br label %bb131
bb131:
  %t470 = load i1, ptr %l232, !tbaa !21
  br i1 %t470, label %bb132, label %bb133
bb132:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = getelementptr { i64, [5 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t473, i32 0, i32 2
  %t475 = load ptr, ptr %t474
  store ptr %t475, ptr %l22, !tbaa !29
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t478 = load ptr, ptr %l22, !tbaa !29
  %t480 = getelementptr %"compiler/typed:Try", ptr %t478, i32 0, i32 0
  %t481 = load ptr, ptr %t480, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t477, ptr %t481)
  br label %bb135
bb135:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load ptr, ptr %l22, !tbaa !29
  %t487 = getelementptr %"compiler/typed:Try", ptr %t485, i32 0, i32 1
  %t488 = load { i64, ptr }, ptr %t487, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t484, { i64, ptr } %t488)
  br label %bb136
bb136:
  br label %bb170
bb137:
  %t491 = load ptr, ptr %l1, !tbaa !29
  store ptr %t491, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t492 = load ptr, ptr %l243, !tbaa !29
  %t493 = icmp ne ptr %t492, null
  br i1 %t493, label %bb138, label %bb139
bb138:
  %t495 = load ptr, ptr %l243, !tbaa !29
  %t496 = load i64, ptr %t495, !range !{i64 0, i64 18}
  %t498 = icmp eq i64 %t496, 15
  store i1 %t498, ptr %l244, !tbaa !21
  br label %bb139
bb139:
  %t499 = load i1, ptr %l244, !tbaa !21
  br i1 %t499, label %bb140, label %bb141
bb140:
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr { i64, [5 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t502, i32 0, i32 2
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l23, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %t506, ptr %t507)
  br label %bb143
bb143:
  br label %bb170
bb144:
  %t510 = load ptr, ptr %l1, !tbaa !29
  store ptr %t510, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t511 = load ptr, ptr %l251, !tbaa !29
  %t512 = icmp ne ptr %t511, null
  br i1 %t512, label %bb145, label %bb146
bb145:
  %t514 = load ptr, ptr %l251, !tbaa !29
  %t515 = load i64, ptr %t514, !range !{i64 0, i64 18}
  %t517 = icmp eq i64 %t515, 16
  store i1 %t517, ptr %l252, !tbaa !21
  br label %bb146
bb146:
  %t518 = load i1, ptr %l252, !tbaa !21
  br i1 %t518, label %bb147, label %bb148
bb147:
  %t519 = load ptr, ptr %l1, !tbaa !29
  %t521 = getelementptr { i64, [5 x i64] }, ptr %t519, i32 0, i32 1
  %t522 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t521, i32 0, i32 2
  %t523 = load ptr, ptr %t522
  store ptr %t523, ptr %l24, !tbaa !29
  br label %bb149
bb148:
  br label %bb162
bb149:
  %t525 = load ptr, ptr %l24, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Text", ptr %t525, i32 0, i32 0
  %t528 = load { i64, ptr }, ptr %t527, !tbaa !27
  store { i64, ptr } %t528, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t530 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t530, 0
  store i64 %t532, ptr %l27, !tbaa !24
  br label %bb150
bb150:
  %t534 = load i64, ptr %l26, !tbaa !24
  %t535 = load i64, ptr %l27, !tbaa !24
  %t538 = icmp slt i64 %t534, %t535
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb151, label %bb152
bb151:
  br label %bb161
bb152:
  br label %bb153
bb153:
  %t542 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t542, ptr %l265, !tbaa !27
  %t543 = load i64, ptr %l26, !tbaa !24
  %t545 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr ptr, ptr %t546, i64 %t543
  %t548 = load ptr, ptr %t547, !tbaa !39
  store ptr %t548, ptr %l28, !tbaa !29
  %t550 = load ptr, ptr %l28, !tbaa !29
  store ptr %t550, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t551 = load ptr, ptr %l268, !tbaa !29
  %t552 = icmp ne ptr %t551, null
  br i1 %t552, label %bb154, label %bb155
bb154:
  %t554 = load ptr, ptr %l268, !tbaa !29
  %t555 = load i64, ptr %t554, !range !{i64 0, i64 2}
  %t557 = icmp eq i64 %t555, 1
  store i1 %t557, ptr %l269, !tbaa !21
  br label %bb155
bb155:
  %t558 = load i1, ptr %l269, !tbaa !21
  br i1 %t558, label %bb156, label %bb157
bb156:
  %t559 = load ptr, ptr %l28, !tbaa !29
  %t561 = getelementptr { i64, [2 x i64] }, ptr %t559, i32 0, i32 1
  %t562 = getelementptr { ptr }, ptr %t561, i32 0, i32 0
  %t563 = load ptr, ptr %t562
  %t565 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t565, ptr %t563)
  br label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t570 = load i64, ptr %l26, !tbaa !24
  %t573 = add i64 %t570, 1
  store i64 %t573, ptr %l26, !tbaa !24
  br label %bb150
bb161:
  br label %bb170
bb162:
  %t575 = load ptr, ptr %l1, !tbaa !29
  store ptr %t575, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t576 = load ptr, ptr %l280, !tbaa !29
  %t577 = icmp ne ptr %t576, null
  br i1 %t577, label %bb163, label %bb164
bb163:
  %t579 = load ptr, ptr %l280, !tbaa !29
  %t580 = load i64, ptr %t579, !range !{i64 0, i64 18}
  %t582 = icmp eq i64 %t580, 17
  store i1 %t582, ptr %l281, !tbaa !21
  br label %bb164
bb164:
  %t583 = load i1, ptr %l281, !tbaa !21
  br i1 %t583, label %bb165, label %bb166
bb165:
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t586 = getelementptr { i64, [5 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t586, i32 0, i32 2
  %t588 = load ptr, ptr %t587
  store ptr %t588, ptr %l30, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t590, ptr %t591)
  br label %bb168
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_d36f57f073c6a2ff_232866ca740484ab)
  unreachable
bb170:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 3}
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l32, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { i32, ptr, i32 }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t72 = load ptr, ptr %l40, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 3}
  %t78 = icmp eq i64 %t76, 0
  store i1 %t78, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_faea1712f2053751_ed9fc9ee56afb56d)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t27, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 19
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t15, i32 0, i32 19
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = sub i64 %t23, 1
  store i64 %t26, ptr %l1, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = add i64 %t40, 1
  %t43 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %v1, ptr %t39, i64 %t42, i64 %t43)
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca i32
  %l80 = alloca i64
  %l84 = alloca { i64, [1 x i64] }
  %t71 = alloca { i64, [1 x i64] }, align 8
  %t158 = alloca { i64, [1 x i64] }, align 8
  %t173 = alloca { i64, [1 x i64] }, align 8
  %t182 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb54
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l40, !tbaa !27
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l10, !tbaa !29
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = icmp eq i64 %t59, 0
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t65 = call i1 @compiler_2ftyped_2ewritesFirst(i32 %t63)
  store i1 %t65, ptr %l47
  br label %bb13
bb12:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb14
bb13:
  %t66 = load i1, ptr %l47, !tbaa !21
  store i1 %t66, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t67 = load i1, ptr %l45, !tbaa !21
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l10, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t71, i32 0, i32 0
  store i64 1, ptr %t72
  %t73 = load { i64, [1 x i64] }, ptr %t71
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t68, ptr %t69, { i64, [1 x i64] } %t73)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb53
bb18:
  %t77 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t79 = trunc i64 20 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l10, !tbaa !29
  %t85 = load { i64, [1 x i64] }, ptr %l3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t82, ptr %t83, { i64, [1 x i64] } %t85)
  br label %bb22
bb22:
  br label %bb52
bb23:
  %t89 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t91 = trunc i64 44 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb41
bb26:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l60, !tbaa !29
  %t95 = load ptr, ptr %l10, !tbaa !29
  store ptr %t95, ptr %l62, !tbaa !29
  %t97 = load { i64, [1 x i64] }, ptr %l3
  %t99 = extractvalue { i64, [1 x i64] } %t97, 0
  %t100 = icmp eq i64 %t99, 4
  br i1 %t100, label %bb27, label %bb28
bb27:
  %t102 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t103 = getelementptr { i32 }, ptr %t102, i32 0, i32 0
  %t104 = load i32, ptr %t103
  store i32 %t104, ptr %l11, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/typed:LocalUses", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l68, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t110)
  store i32 %t112, ptr %l70
  br label %bb29
bb28:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb31
bb29:
  %t113 = load ptr, ptr %l68, !tbaa !29
  %t114 = call ptr @__olang_scope_or(ptr %v2, ptr %t113)
  %t115 = call ptr @__olang_scope_hold(ptr %t114)
  %t116 = ptrtoint ptr %t115 to i64
  %t118 = inttoptr i64 %t116 to ptr
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = load i32, ptr %l70, !tbaa !23
  %t121 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t118, ptr %t119, i32 %t120)
  store i1 %t121, ptr %l72
  br label %bb30
bb30:
  %t122 = load i1, ptr %l72, !tbaa !21
  store i1 %t122, ptr %l65, !tbaa !21
  br label %bb31
bb31:
  %t123 = load i1, ptr %l65, !tbaa !21
  br i1 %t123, label %bb32, label %bb33
bb32:
  %t124 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t125 = getelementptr { i32 }, ptr %t124, i32 0, i32 0
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l12, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/typed:LocalUses", ptr %t128, i32 0, i32 0
  %t131 = load ptr, ptr %t130, !tbaa !29
  store ptr %t131, ptr %l76, !tbaa !29
  %t132 = load ptr, ptr %l10, !tbaa !29
  %t134 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t132)
  store i32 %t134, ptr %l78
  br label %bb34
bb33:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb36
bb34:
  %t135 = load ptr, ptr %l76, !tbaa !29
  %t136 = call ptr @__olang_scope_or(ptr %v2, ptr %t135)
  %t137 = call ptr @__olang_scope_hold(ptr %t136)
  %t138 = ptrtoint ptr %t137 to i64
  %t140 = inttoptr i64 %t138 to ptr
  %t141 = load ptr, ptr %l76, !tbaa !29
  %t142 = load i32, ptr %l78, !tbaa !23
  %t143 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t140, ptr %t141, i32 %t142)
  store i64 %t143, ptr %l80
  br label %bb35
bb35:
  %t144 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t145 = load i64, ptr %l80, !tbaa !24
  %t147 = and i64 %t145, %t144
  %t149 = icmp eq i64 %t147, 0
  store i1 %t149, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t151 = load i1, ptr %l73, !tbaa !21
  br i1 %t151, label %bb37, label %bb38
bb37:
  %t152 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t153 = getelementptr { i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l13, !tbaa !23
  %t156 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t156, ptr %l84
  br label %bb39
bb38:
  store { i64, [1 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [1 x i64] }, ptr %t158, i32 0, i32 0
  store i64 5, ptr %t159
  %t160 = load { i64, [1 x i64] }, ptr %t158
  store { i64, [1 x i64] } %t160, ptr %l84
  br label %bb39
bb39:
  %t162 = load ptr, ptr %l60, !tbaa !29
  %t163 = load ptr, ptr %l62, !tbaa !29
  %t164 = load { i64, [1 x i64] }, ptr %l84
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t162, ptr %t163, { i64, [1 x i64] } %t164)
  br label %bb40
bb40:
  br label %bb52
bb41:
  %t165 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t167 = trunc i64 31 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l10, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [1 x i64] }, ptr %t173, i32 0, i32 0
  store i64 1, ptr %t174
  %t175 = load { i64, [1 x i64] }, ptr %t173
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t170, ptr %t171, { i64, [1 x i64] } %t175)
  br label %bb45
bb45:
  br label %bb52
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l10, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [1 x i64] }, ptr %t182, i32 0, i32 0
  store i64 0, ptr %t183
  %t184 = load { i64, [1 x i64] }, ptr %t182
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t179, ptr %t180, { i64, [1 x i64] } %t184)
  br label %bb50
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_dac0899521d00a27_f5966ad5b7471ec3)
  unreachable
bb52:
  br label %bb53
bb53:
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l8, !tbaa !24
  br label %bb7
bb54:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2c, ptr %a2e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { ptr, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  store { ptr, ptr } %pg2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t11)
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t11)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t21, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l4
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l6, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t53, i32 0, i32 3
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l28, !tbaa !23
  %t59 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  store i32 %t60, ptr %l29, !tbaa !23
  %t61 = load i32, ptr %l5, !tbaa !23
  %t62 = load { ptr, ptr }, ptr %l2
  %t65 = extractvalue { ptr, ptr } %t62, 0
  %t66 = extractvalue { ptr, ptr } %t62, 1
  %t67 = call { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v2, ptr %s3, i32 %t61, ptr %t65, ptr %t66)
  %t68 = extractvalue { i32, { i64, ptr } } %t67, 1
  %t69 = extractvalue { i32, { i64, ptr } } %t67, 0
  store i32 %t69, ptr %l34
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb11, label %ok.71, !prof !99
ok.71:
  store { i64, ptr } %t68, ptr %l33
  br label %bb10
bb10:
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t72, ptr %l30, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i32, ptr %l34, !tbaa !23
  %t74 = lshr i32 %t73, 16
  %t75 = and i32 %t73, 65535
  %t76 = icmp eq i32 %t74, 1
  %t77 = select i1 %t76, i32 1, i32 0
  %t78 = icmp eq i32 %t73, 0
  %t79 = shl i32 %t77, 16
  %t80 = or i32 %t79, %t75
  %t81 = select i1 %t78, i32 0, i32 %t80
  call void @__olang_scope_close(ptr %s3)
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t81, 0
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
bb12:
  %t84 = load i32, ptr %l7, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l37, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t89 = load { ptr, ptr }, ptr %l2
  %t93 = extractvalue { ptr, ptr } %t89, 0
  %t94 = extractvalue { ptr, ptr } %t89, 1
  %t95 = call { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceWord(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t87, ptr %t88, ptr %t93, ptr %t94)
  %t96 = extractvalue { i32, { i64, ptr } } %t95, 1
  %t97 = extractvalue { i32, { i64, ptr } } %t95, 0
  store i32 %t97, ptr %l43
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb14, label %ok.99, !prof !99
ok.99:
  store { i64, ptr } %t96, ptr %l42
  br label %bb13
bb13:
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t100, ptr %l38, !tbaa !27
  br label %bb15
bb14:
  %t101 = load i32, ptr %l43, !tbaa !23
  %t102 = lshr i32 %t101, 16
  %t103 = and i32 %t101, 65535
  %t104 = icmp eq i32 %t102, 1
  %t105 = select i1 %t104, i32 1, i32 0
  %t106 = icmp eq i32 %t101, 0
  %t107 = shl i32 %t105, 16
  %t108 = or i32 %t107, %t103
  %t109 = select i1 %t106, i32 0, i32 %t108
  call void @__olang_scope_close(ptr %s3)
  %t111 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t109, 0
  store { i32, { i64, ptr } } %t111, ptr %rv
  br label %ret
bb15:
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t114 = load i32, ptr %l28, !tbaa !23
  %t115 = sext i32 %t114 to i64
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i32, ptr %l29, !tbaa !23
  %t122 = sext i32 %t121 to i64
  %t123 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t128 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = add i64 %t127, %t130
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = load i64, ptr %l37, !tbaa !24
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t134, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = add i64 %t140, %t143
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t112, i64 %t113)
  %t149 = getelementptr i8, ptr %t148, i64 %t113
  %t150 = call i64 @__olang_fmt_i64(ptr %t149, i64 %t115)
  %t151 = getelementptr i8, ptr %t149, i64 %t116
  call void @olang_textcopy(ptr %t151, ptr %t118, i64 %t119)
  %t152 = getelementptr i8, ptr %t151, i64 %t119
  %t153 = call i64 @__olang_fmt_i64(ptr %t152, i64 %t122)
  %t154 = getelementptr i8, ptr %t152, i64 %t123
  call void @olang_textcopy(ptr %t154, ptr %t125, i64 %t126)
  %t155 = getelementptr i8, ptr %t154, i64 %t126
  call void @olang_textcopy(ptr %t155, ptr %t129, i64 %t130)
  %t156 = getelementptr i8, ptr %t155, i64 %t130
  call void @olang_textcopy(ptr %t156, ptr %t132, i64 %t133)
  %t157 = getelementptr i8, ptr %t156, i64 %t133
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t135)
  %t159 = getelementptr i8, ptr %t157, i64 %t136
  call void @olang_textcopy(ptr %t159, ptr %t138, i64 %t139)
  %t160 = getelementptr i8, ptr %t159, i64 %t139
  call void @olang_textcopy(ptr %t160, ptr %t142, i64 %t143)
  %t161 = getelementptr i8, ptr %t160, i64 %t143
  call void @olang_textcopy(ptr %t161, ptr %t145, i64 %t146)
  %t162 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t148, 1
  store { i64, ptr } %t163, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t166 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t166, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_afe89d4716bb52e8_bab84d91c7a69354)
  unreachable
bb21:
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t168 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t167, 1
  store { i32, { i64, ptr } } %t168, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l26 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f34835f3d61f57d9_feeccb0fe1526945)
  unreachable
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Call", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t50, ptr %t48)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l5, !tbaa !24
  br label %bb13
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l83 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l120 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l212 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l216 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Nodes", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t8 = load ptr, ptr %l32, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l32, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 2
  store i1 %t14, ptr %l33, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l33, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb14
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t23 = load ptr, ptr %l38, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l38, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l39, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l39, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l2, !tbaa !29
  br label %bb14
bb9:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t38 = load ptr, ptr %l44, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l44, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 4
  store i1 %t44, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l45, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb15
bb15:
  br label %bb143
bb16:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t57 = load ptr, ptr %l52, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l52, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 5
  store i1 %t63, ptr %l53, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l53, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Promote", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t71, ptr %t75)
  br label %bb22
bb22:
  br label %bb143
bb23:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t79 = load ptr, ptr %l61, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t82 = load ptr, ptr %l61, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l62, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ecall(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  br label %bb29
bb29:
  br label %bb143
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t98 = load ptr, ptr %l69, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l69, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 7
  store i1 %t104, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb44
bb35:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Make", ptr %t112, i32 0, i32 2
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l8, !tbaa !24
  br label %bb36
bb36:
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb37, label %bb38
bb37:
  br label %bb42
bb38:
  br label %bb39
bb39:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = load i64, ptr %l7, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t137, ptr %t135)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t141 = load i64, ptr %l7, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l7, !tbaa !24
  br label %bb36
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l5, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Make", ptr %t147, i32 0, i32 3
  %t150 = load ptr, ptr %t149, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t146, ptr %t150)
  br label %bb43
bb43:
  br label %bb143
bb44:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t154 = load ptr, ptr %l94, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb45, label %bb46
bb45:
  %t157 = load ptr, ptr %l94, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 18}
  %t160 = icmp eq i64 %t158, 8
  store i1 %t160, ptr %l95, !tbaa !21
  br label %bb46
bb46:
  %t161 = load i1, ptr %l95, !tbaa !21
  br i1 %t161, label %bb47, label %bb48
bb47:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [5 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t164, i32 0, i32 2
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l10, !tbaa !29
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l10, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Collect", ptr %t169, i32 0, i32 0
  %t172 = load ptr, ptr %t171, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t168, ptr %t172)
  br label %bb50
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Collect", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t175, ptr %t179)
  br label %bb51
bb51:
  br label %bb143
bb52:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t184 = load ptr, ptr %l107, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb53, label %bb54
bb53:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 18}
  %t190 = icmp eq i64 %t188, 9
  store i1 %t190, ptr %l108, !tbaa !21
  br label %bb54
bb54:
  %t191 = load i1, ptr %l108, !tbaa !21
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t194, i32 0, i32 4
  %t196 = load { i64, ptr }, ptr %t195
  store { i64, ptr } %t196, ptr %l11, !tbaa !27
  br label %bb57
bb56:
  br label %bb65
bb57:
  %t198 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t198, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l14, !tbaa !24
  br label %bb58
bb58:
  %t204 = load i64, ptr %l13, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t212 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t212, ptr %l120, !tbaa !27
  %t213 = load i64, ptr %l13, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t220, ptr %t218)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t224 = load i64, ptr %l13, !tbaa !24
  %t227 = add i64 %t224, 1
  store i64 %t227, ptr %l13, !tbaa !24
  br label %bb58
bb64:
  br label %bb143
bb65:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t230 = load ptr, ptr %l128, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb66, label %bb67
bb66:
  %t233 = load ptr, ptr %l128, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 18}
  %t236 = icmp eq i64 %t234, 10
  store i1 %t236, ptr %l129, !tbaa !21
  br label %bb67
bb67:
  %t237 = load i1, ptr %l129, !tbaa !21
  br i1 %t237, label %bb68, label %bb69
bb68:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l16, !tbaa !29
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l16, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Slice", ptr %t245, i32 0, i32 0
  %t248 = load ptr, ptr %t247, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t244, ptr %t248)
  br label %bb71
bb71:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l16, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Slice", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t251, ptr %t255)
  br label %bb72
bb72:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l16, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Slice", ptr %t259, i32 0, i32 2
  %t262 = load ptr, ptr %t261, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t258, ptr %t262)
  br label %bb73
bb73:
  br label %bb143
bb74:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t266 = load ptr, ptr %l143, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb75, label %bb76
bb75:
  %t269 = load ptr, ptr %l143, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 18}
  %t272 = icmp eq i64 %t270, 11
  store i1 %t272, ptr %l144, !tbaa !21
  br label %bb76
bb76:
  %t273 = load i1, ptr %l144, !tbaa !21
  br i1 %t273, label %bb77, label %bb78
bb77:
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t276, i32 0, i32 2
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l17, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l17, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Cond", ptr %t281, i32 0, i32 0
  %t284 = load ptr, ptr %t283, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t280, ptr %t284)
  br label %bb80
bb80:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l17, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Cond", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t287, ptr %t291)
  br label %bb81
bb81:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l17, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Cond", ptr %t295, i32 0, i32 2
  %t298 = load ptr, ptr %t297, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t294, ptr %t298)
  br label %bb82
bb82:
  br label %bb143
bb83:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t302 = load ptr, ptr %l158, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb84, label %bb85
bb84:
  %t305 = load ptr, ptr %l158, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 18}
  %t308 = icmp eq i64 %t306, 12
  store i1 %t308, ptr %l159, !tbaa !21
  br label %bb85
bb85:
  %t309 = load i1, ptr %l159, !tbaa !21
  br i1 %t309, label %bb86, label %bb87
bb86:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [5 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t312, i32 0, i32 2
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l18, !tbaa !29
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l18, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Seq", ptr %t317, i32 0, i32 0
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmts(ptr %v0, ptr %v1, ptr %t316, { i64, ptr } %t320)
  br label %bb89
bb89:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l18, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Seq", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t323, ptr %t327)
  br label %bb90
bb90:
  br label %bb143
bb91:
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t331 = load ptr, ptr %l170, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb92, label %bb93
bb92:
  %t334 = load ptr, ptr %l170, !tbaa !29
  %t335 = load i64, ptr %t334, !range !{i64 0, i64 18}
  %t337 = icmp eq i64 %t335, 13
  store i1 %t337, ptr %l171, !tbaa !21
  br label %bb93
bb93:
  %t338 = load i1, ptr %l171, !tbaa !21
  br i1 %t338, label %bb94, label %bb95
bb94:
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t341, i32 0, i32 2
  %t343 = load ptr, ptr %t342
  store ptr %t343, ptr %l19, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ematch(ptr %v0, ptr %v1, ptr %t345, ptr %t346)
  br label %bb97
bb97:
  br label %bb143
bb98:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t350 = load ptr, ptr %l178, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb99, label %bb100
bb99:
  %t353 = load ptr, ptr %l178, !tbaa !29
  %t354 = load i64, ptr %t353, !range !{i64 0, i64 18}
  %t356 = icmp eq i64 %t354, 14
  store i1 %t356, ptr %l179, !tbaa !21
  br label %bb100
bb100:
  %t357 = load i1, ptr %l179, !tbaa !21
  br i1 %t357, label %bb101, label %bb102
bb101:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t360, i32 0, i32 2
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l20, !tbaa !29
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l20, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Try", ptr %t365, i32 0, i32 0
  %t368 = load ptr, ptr %t367, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t364, ptr %t368)
  br label %bb104
bb104:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l20, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Try", ptr %t372, i32 0, i32 1
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %t371, { i64, ptr } %t375)
  br label %bb105
bb105:
  br label %bb143
bb106:
  %t378 = load ptr, ptr %l1, !tbaa !29
  store ptr %t378, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t379 = load ptr, ptr %l190, !tbaa !29
  %t380 = icmp ne ptr %t379, null
  br i1 %t380, label %bb107, label %bb108
bb107:
  %t382 = load ptr, ptr %l190, !tbaa !29
  %t383 = load i64, ptr %t382, !range !{i64 0, i64 18}
  %t385 = icmp eq i64 %t383, 15
  store i1 %t385, ptr %l191, !tbaa !21
  br label %bb108
bb108:
  %t386 = load i1, ptr %l191, !tbaa !21
  br i1 %t386, label %bb109, label %bb110
bb109:
  %t387 = load ptr, ptr %l1, !tbaa !29
  %t389 = getelementptr { i64, [5 x i64] }, ptr %t387, i32 0, i32 1
  %t390 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t389, i32 0, i32 2
  %t391 = load ptr, ptr %t390
  store ptr %t391, ptr %l21, !tbaa !29
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2efnVal(ptr %v0, ptr %v1, ptr %t393, ptr %t394)
  br label %bb112
bb112:
  br label %bb143
bb113:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t398 = load ptr, ptr %l198, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb114, label %bb115
bb114:
  %t401 = load ptr, ptr %l198, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 18}
  %t404 = icmp eq i64 %t402, 16
  store i1 %t404, ptr %l199, !tbaa !21
  br label %bb115
bb115:
  %t405 = load i1, ptr %l199, !tbaa !21
  br i1 %t405, label %bb116, label %bb117
bb116:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [5 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t408, i32 0, i32 2
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l22, !tbaa !29
  br label %bb118
bb117:
  br label %bb131
bb118:
  %t412 = load ptr, ptr %l22, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Text", ptr %t412, i32 0, i32 0
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  store { i64, ptr } %t415, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t417 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  store i64 %t419, ptr %l25, !tbaa !24
  br label %bb119
bb119:
  %t421 = load i64, ptr %l24, !tbaa !24
  %t422 = load i64, ptr %l25, !tbaa !24
  %t425 = icmp slt i64 %t421, %t422
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb120, label %bb121
bb120:
  br label %bb130
bb121:
  br label %bb122
bb122:
  %t429 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t429, ptr %l212, !tbaa !27
  %t430 = load i64, ptr %l24, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr ptr, ptr %t433, i64 %t430
  %t435 = load ptr, ptr %t434, !tbaa !39
  store ptr %t435, ptr %l26, !tbaa !29
  %t437 = load ptr, ptr %l26, !tbaa !29
  store ptr %t437, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t438 = load ptr, ptr %l215, !tbaa !29
  %t439 = icmp ne ptr %t438, null
  br i1 %t439, label %bb123, label %bb124
bb123:
  %t441 = load ptr, ptr %l215, !tbaa !29
  %t442 = load i64, ptr %t441, !range !{i64 0, i64 2}
  %t444 = icmp eq i64 %t442, 1
  store i1 %t444, ptr %l216, !tbaa !21
  br label %bb124
bb124:
  %t445 = load i1, ptr %l216, !tbaa !21
  br i1 %t445, label %bb125, label %bb126
bb125:
  %t446 = load ptr, ptr %l26, !tbaa !29
  %t448 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 1
  %t449 = getelementptr { ptr }, ptr %t448, i32 0, i32 0
  %t450 = load ptr, ptr %t449
  %t452 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t452, ptr %t450)
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t456 = load i64, ptr %l24, !tbaa !24
  %t459 = add i64 %t456, 1
  store i64 %t459, ptr %l24, !tbaa !24
  br label %bb119
bb130:
  br label %bb143
bb131:
  %t461 = load ptr, ptr %l1, !tbaa !29
  store ptr %t461, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t462 = load ptr, ptr %l226, !tbaa !29
  %t463 = icmp ne ptr %t462, null
  br i1 %t463, label %bb132, label %bb133
bb132:
  %t465 = load ptr, ptr %l226, !tbaa !29
  %t466 = load i64, ptr %t465, !range !{i64 0, i64 18}
  %t468 = icmp eq i64 %t466, 17
  store i1 %t468, ptr %l227, !tbaa !21
  br label %bb133
bb133:
  %t469 = load i1, ptr %l227, !tbaa !21
  br i1 %t469, label %bb134, label %bb135
bb134:
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  %t473 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t472, i32 0, i32 2
  %t474 = load ptr, ptr %t473
  store ptr %t474, ptr %l28, !tbaa !29
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t476, ptr %t477)
  br label %bb137
bb137:
  br label %bb143
bb138:
  br i1 true, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_fc4a9e97a0375850_6fc32d1d5d28aa84)
  unreachable
bb143:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t45, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb25
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 3}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { i32, ptr, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_57f1440b51b1670e_340f688d6d5dc432)
  unreachable
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Match", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmts(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Match", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2earm(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t37, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Match", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eoptArm(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eoptArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Nodes", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Nodes", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t63 = icmp eq ptr %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t65, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2c, ptr %a2e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { ptr, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i1
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i1
  %l82 = alloca i32
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i32
  %l90 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  store { ptr, ptr } %pg2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceAt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t11)
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t11)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t21, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t25 = load ptr, ptr %l22, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l4
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb9
bb8:
  br label %bb13
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %l32, !tbaa !23
  %t53 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  store i32 %t54, ptr %l33, !tbaa !23
  %t55 = load i32, ptr %l5, !tbaa !23
  %t56 = load { ptr, ptr }, ptr %l2
  %t59 = extractvalue { ptr, ptr } %t56, 0
  %t60 = extractvalue { ptr, ptr } %t56, 1
  %t61 = call { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v2, ptr %s3, i32 %t55, ptr %t59, ptr %t60)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l38
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb11, label %ok.65, !prof !99
ok.65:
  store { i64, ptr } %t62, ptr %l37
  br label %bb10
bb10:
  %t66 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t66, ptr %l34, !tbaa !27
  br label %bb12
bb11:
  %t67 = load i32, ptr %l38, !tbaa !23
  %t68 = lshr i32 %t67, 16
  %t69 = and i32 %t67, 65535
  %t70 = icmp eq i32 %t68, 1
  %t71 = select i1 %t70, i32 1, i32 0
  %t72 = icmp eq i32 %t67, 0
  %t73 = shl i32 %t71, 16
  %t74 = or i32 %t73, %t69
  %t75 = select i1 %t72, i32 0, i32 %t74
  call void @__olang_scope_close(ptr %s3)
  %t77 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t75, 0
  store { i32, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb12:
  %t78 = load i32, ptr %l6, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t83 = load i32, ptr %l32, !tbaa !23
  %t84 = sext i32 %t83 to i64
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = load i32, ptr %l33, !tbaa !23
  %t91 = sext i32 %t90 to i64
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t91)
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t105 = call i64 @__olang_fmt_i64(ptr null, i64 %t80)
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t81, i64 %t82)
  %t108 = getelementptr i8, ptr %t107, i64 %t82
  %t109 = call i64 @__olang_fmt_i64(ptr %t108, i64 %t84)
  %t110 = getelementptr i8, ptr %t108, i64 %t85
  call void @olang_textcopy(ptr %t110, ptr %t87, i64 %t88)
  %t111 = getelementptr i8, ptr %t110, i64 %t88
  %t112 = call i64 @__olang_fmt_i64(ptr %t111, i64 %t91)
  %t113 = getelementptr i8, ptr %t111, i64 %t92
  call void @olang_textcopy(ptr %t113, ptr %t94, i64 %t95)
  %t114 = getelementptr i8, ptr %t113, i64 %t95
  call void @olang_textcopy(ptr %t114, ptr %t98, i64 %t99)
  %t115 = getelementptr i8, ptr %t114, i64 %t99
  call void @olang_textcopy(ptr %t115, ptr %t101, i64 %t102)
  %t116 = getelementptr i8, ptr %t115, i64 %t102
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t80)
  %t118 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t107, 1
  store { i64, ptr } %t119, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb13:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t122 = load ptr, ptr %l43, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb14, label %bb15
bb14:
  %t125 = load ptr, ptr %l43, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 8}
  %t128 = icmp eq i64 %t126, 3
  store i1 %t128, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t129 = load i1, ptr %l44, !tbaa !21
  br i1 %t129, label %bb16, label %bb17
bb16:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t132, i32 0, i32 0
  %t134 = load %"compiler/source:Span", ptr %t133
  store %"compiler/source:Span" %t134, ptr %l7
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t138, i32 0, i32 1
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l8, !tbaa !23
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t144, i32 0, i32 2
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l9, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t150, i32 0, i32 3
  %t152 = load i64, ptr %t151
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb18
bb17:
  br label %bb25
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t155 = load i32, ptr %t154, !tbaa !23
  store i32 %t155, ptr %l55, !tbaa !23
  %t156 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t157 = load i32, ptr %t156, !tbaa !23
  store i32 %t157, ptr %l56, !tbaa !23
  %t158 = load i32, ptr %l8, !tbaa !23
  %t159 = load { ptr, ptr }, ptr %l2
  %t162 = extractvalue { ptr, ptr } %t159, 0
  %t163 = extractvalue { ptr, ptr } %t159, 1
  %t164 = call { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v2, ptr %s5, i32 %t158, ptr %t162, ptr %t163)
  %t165 = extractvalue { i32, { i64, ptr } } %t164, 1
  %t166 = extractvalue { i32, { i64, ptr } } %t164, 0
  store i32 %t166, ptr %l61
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb20, label %ok.168, !prof !99
ok.168:
  store { i64, ptr } %t165, ptr %l60
  br label %bb19
bb19:
  %t169 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t169, ptr %l57, !tbaa !27
  br label %bb21
bb20:
  %t170 = load i32, ptr %l61, !tbaa !23
  %t171 = lshr i32 %t170, 16
  %t172 = and i32 %t170, 65535
  %t173 = icmp eq i32 %t171, 1
  %t174 = select i1 %t173, i32 1, i32 0
  %t175 = icmp eq i32 %t170, 0
  %t176 = shl i32 %t174, 16
  %t177 = or i32 %t176, %t172
  %t178 = select i1 %t175, i32 0, i32 %t177
  call void @__olang_scope_close(ptr %s5)
  %t180 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t178, 0
  store { i32, { i64, ptr } } %t180, ptr %rv
  br label %ret
bb21:
  %t181 = load i64, ptr %l10, !tbaa !24
  store i64 %t181, ptr %l63, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l9, !tbaa !29
  %t184 = load { ptr, ptr }, ptr %l2
  %t188 = extractvalue { ptr, ptr } %t184, 0
  %t189 = extractvalue { ptr, ptr } %t184, 1
  %t190 = call { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceWord(ptr %v0, ptr %v1, ptr %v2, ptr %s5, ptr %t182, ptr %t183, ptr %t188, ptr %t189)
  %t191 = extractvalue { i32, { i64, ptr } } %t190, 1
  %t192 = extractvalue { i32, { i64, ptr } } %t190, 0
  store i32 %t192, ptr %l69
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb23, label %ok.194, !prof !99
ok.194:
  store { i64, ptr } %t191, ptr %l68
  br label %bb22
bb22:
  %t195 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t195, ptr %l64, !tbaa !27
  br label %bb24
bb23:
  %t196 = load i32, ptr %l69, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s5)
  %t206 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t204, 0
  store { i32, { i64, ptr } } %t206, ptr %rv
  br label %ret
bb24:
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t209 = load i32, ptr %l55, !tbaa !23
  %t210 = sext i32 %t209 to i64
  %t211 = call i64 @__olang_fmt_i64(ptr null, i64 %t210)
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = load i32, ptr %l56, !tbaa !23
  %t217 = sext i32 %t216 to i64
  %t218 = call i64 @__olang_fmt_i64(ptr null, i64 %t217)
  %t219 = add i64 %t215, %t218
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t223 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 1
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t230 = load i64, ptr %l63, !tbaa !24
  %t231 = call i64 @__olang_fmt_i64(ptr null, i64 %t230)
  %t232 = add i64 %t229, %t231
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = add i64 %t235, %t238
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t242 = add i64 %t239, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t207, i64 %t208)
  %t244 = getelementptr i8, ptr %t243, i64 %t208
  %t245 = call i64 @__olang_fmt_i64(ptr %t244, i64 %t210)
  %t246 = getelementptr i8, ptr %t244, i64 %t211
  call void @olang_textcopy(ptr %t246, ptr %t213, i64 %t214)
  %t247 = getelementptr i8, ptr %t246, i64 %t214
  %t248 = call i64 @__olang_fmt_i64(ptr %t247, i64 %t217)
  %t249 = getelementptr i8, ptr %t247, i64 %t218
  call void @olang_textcopy(ptr %t249, ptr %t220, i64 %t221)
  %t250 = getelementptr i8, ptr %t249, i64 %t221
  call void @olang_textcopy(ptr %t250, ptr %t224, i64 %t225)
  %t251 = getelementptr i8, ptr %t250, i64 %t225
  call void @olang_textcopy(ptr %t251, ptr %t227, i64 %t228)
  %t252 = getelementptr i8, ptr %t251, i64 %t228
  %t253 = call i64 @__olang_fmt_i64(ptr %t252, i64 %t230)
  %t254 = getelementptr i8, ptr %t252, i64 %t231
  call void @olang_textcopy(ptr %t254, ptr %t233, i64 %t234)
  %t255 = getelementptr i8, ptr %t254, i64 %t234
  call void @olang_textcopy(ptr %t255, ptr %t237, i64 %t238)
  %t256 = getelementptr i8, ptr %t255, i64 %t238
  call void @olang_textcopy(ptr %t256, ptr %t240, i64 %t241)
  %t257 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t243, 1
  store { i64, ptr } %t258, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb25:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t261 = load ptr, ptr %l72, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb26, label %bb27
bb26:
  %t264 = load ptr, ptr %l72, !tbaa !29
  %t265 = load i64, ptr %t264, !range !{i64 0, i64 8}
  %t267 = icmp eq i64 %t265, 2
  store i1 %t267, ptr %l73, !tbaa !21
  br label %bb27
bb27:
  %t268 = load i1, ptr %l73, !tbaa !21
  br i1 %t268, label %bb28, label %bb29
bb28:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t271, i32 0, i32 0
  %t273 = load %"compiler/source:Span", ptr %t272
  store %"compiler/source:Span" %t273, ptr %l11
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t277, i32 0, i32 1
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l12, !tbaa !23
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [4 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t283, i32 0, i32 2
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l13, !tbaa !29
  br label %bb30
bb29:
  br label %bb37
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t287 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t288 = load i32, ptr %t287, !tbaa !23
  store i32 %t288, ptr %l82, !tbaa !23
  %t289 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t290 = load i32, ptr %t289, !tbaa !23
  store i32 %t290, ptr %l83, !tbaa !23
  %t291 = load i32, ptr %l12, !tbaa !23
  %t292 = load { ptr, ptr }, ptr %l2
  %t295 = extractvalue { ptr, ptr } %t292, 0
  %t296 = extractvalue { ptr, ptr } %t292, 1
  %t297 = call { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v2, ptr %s7, i32 %t291, ptr %t295, ptr %t296)
  %t298 = extractvalue { i32, { i64, ptr } } %t297, 1
  %t299 = extractvalue { i32, { i64, ptr } } %t297, 0
  store i32 %t299, ptr %l88
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb32, label %ok.301, !prof !99
ok.301:
  store { i64, ptr } %t298, ptr %l87
  br label %bb31
bb31:
  %t302 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t302, ptr %l84, !tbaa !27
  br label %bb33
bb32:
  %t303 = load i32, ptr %l88, !tbaa !23
  %t304 = lshr i32 %t303, 16
  %t305 = and i32 %t303, 65535
  %t306 = icmp eq i32 %t304, 1
  %t307 = select i1 %t306, i32 1, i32 0
  %t308 = icmp eq i32 %t303, 0
  %t309 = shl i32 %t307, 16
  %t310 = or i32 %t309, %t305
  %t311 = select i1 %t308, i32 0, i32 %t310
  call void @__olang_scope_close(ptr %s7)
  %t313 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t311, 0
  store { i32, { i64, ptr } } %t313, ptr %rv
  br label %ret
bb33:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l13, !tbaa !29
  %t316 = load { ptr, ptr }, ptr %l2
  %t320 = extractvalue { ptr, ptr } %t316, 0
  %t321 = extractvalue { ptr, ptr } %t316, 1
  %t322 = call { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprWord(ptr %v0, ptr %v1, ptr %v2, ptr %s7, ptr %t314, ptr %t315, ptr %t320, ptr %t321)
  %t323 = extractvalue { i32, { i64, ptr } } %t322, 1
  %t324 = extractvalue { i32, { i64, ptr } } %t322, 0
  store i32 %t324, ptr %l95
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb35, label %ok.326, !prof !99
ok.326:
  store { i64, ptr } %t323, ptr %l94
  br label %bb34
bb34:
  %t327 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t327, ptr %l90, !tbaa !27
  br label %bb36
bb35:
  %t328 = load i32, ptr %l95, !tbaa !23
  %t329 = lshr i32 %t328, 16
  %t330 = and i32 %t328, 65535
  %t331 = icmp eq i32 %t329, 1
  %t332 = select i1 %t331, i32 1, i32 0
  %t333 = icmp eq i32 %t328, 0
  %t334 = shl i32 %t332, 16
  %t335 = or i32 %t334, %t330
  %t336 = select i1 %t333, i32 0, i32 %t335
  call void @__olang_scope_close(ptr %s7)
  %t338 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t336, 0
  store { i32, { i64, ptr } } %t338, ptr %rv
  br label %ret
bb36:
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t341 = load i32, ptr %l82, !tbaa !23
  %t342 = sext i32 %t341 to i64
  %t343 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t348 = load i32, ptr %l83, !tbaa !23
  %t349 = sext i32 %t348 to i64
  %t350 = call i64 @__olang_fmt_i64(ptr null, i64 %t349)
  %t351 = add i64 %t347, %t350
  %t352 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t355 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = add i64 %t354, %t357
  %t359 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t361 = add i64 %t358, %t360
  %t362 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 1
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t365 = add i64 %t361, %t364
  %t366 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t368 = add i64 %t365, %t367
  %t369 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t339, i64 %t340)
  %t370 = getelementptr i8, ptr %t369, i64 %t340
  %t371 = call i64 @__olang_fmt_i64(ptr %t370, i64 %t342)
  %t372 = getelementptr i8, ptr %t370, i64 %t343
  call void @olang_textcopy(ptr %t372, ptr %t345, i64 %t346)
  %t373 = getelementptr i8, ptr %t372, i64 %t346
  %t374 = call i64 @__olang_fmt_i64(ptr %t373, i64 %t349)
  %t375 = getelementptr i8, ptr %t373, i64 %t350
  call void @olang_textcopy(ptr %t375, ptr %t352, i64 %t353)
  %t376 = getelementptr i8, ptr %t375, i64 %t353
  call void @olang_textcopy(ptr %t376, ptr %t356, i64 %t357)
  %t377 = getelementptr i8, ptr %t376, i64 %t357
  call void @olang_textcopy(ptr %t377, ptr %t359, i64 %t360)
  %t378 = getelementptr i8, ptr %t377, i64 %t360
  call void @olang_textcopy(ptr %t378, ptr %t363, i64 %t364)
  %t379 = getelementptr i8, ptr %t378, i64 %t364
  call void @olang_textcopy(ptr %t379, ptr %t366, i64 %t367)
  %t380 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t369, 1
  store { i64, ptr } %t381, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t384 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t384, ptr %rv
  br label %ret
bb41:
  call void @__olang_check_failed(ptr @olang_loc_4c0069332dc3373a_9f4d81ed437fa5b6)
  unreachable
bb42:
  %t385 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t386 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t385, 1
  store { i32, { i64, ptr } } %t386, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2c, ptr %a2e, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:DerivedArg"
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l65 = alloca { i64, ptr }
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i64
  %l125 = alloca %"std/prelude/text:StringBuilder"
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca i64
  %l137 = alloca i64
  %l142 = alloca %"compiler/typed:DerivedArg"
  %l143 = alloca ptr
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i32
  %l156 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l167 = alloca i64
  %l171 = alloca i64
  %l174 = alloca i64
  %l192 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca i64
  %l203 = alloca { i64, ptr }
  %l207 = alloca { i64, [2 x i64] }
  %l208 = alloca { i64, ptr }
  %l209 = alloca i32
  %l213 = alloca { i64, ptr }
  %l224 = alloca i64
  %l227 = alloca i64
  %l246 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l251 = alloca i64
  %l252 = alloca i64
  %l255 = alloca { i64, ptr }
  %l258 = alloca i64
  %l259 = alloca i32
  %l263 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l35
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l35
  store %"std/prelude/text:StringBuilder" %t2, ptr %l4
  store ptr %l4, ptr %l36, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t7 = call { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2etext(ptr %v0, ptr %v3, ptr %s0, ptr %t3, i1 false, ptr %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l41
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l40
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t12, ptr %l37, !tbaa !27
  br label %bb4
bb3:
  %t13 = load i32, ptr %l41, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t25 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t25, { i64, ptr } %t24)
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Plan", ptr %t28, i32 0, i32 11
  store ptr %t30, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %l47, !tbaa !24
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l49
  br label %bb8
bb8:
  %t36 = load i64, ptr %l47, !tbaa !24
  %t37 = load i64, ptr %l49, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store ptr %t46, ptr %l54
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l54, !tbaa !29
  store ptr %l4, ptr %l55, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t54 = extractvalue { ptr, ptr } %pg2, 0
  %t55 = extractvalue { ptr, ptr } %pg2, 1
  %t56 = call { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprWord(ptr %v1, ptr %v0, ptr %v2, ptr %s2, ptr %t48, ptr %t47, ptr %t54, ptr %t55)
  %t57 = extractvalue { i32, { i64, ptr } } %t56, 1
  %t58 = extractvalue { i32, { i64, ptr } } %t56, 0
  store i32 %t58, ptr %l61
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb14, label %ok.60, !prof !99
ok.60:
  store { i64, ptr } %t57, ptr %l60
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t61, ptr %l56, !tbaa !27
  br label %bb15
bb14:
  %t62 = load i32, ptr %l61, !tbaa !23
  %t63 = lshr i32 %t62, 16
  %t64 = and i32 %t62, 65535
  %t65 = icmp eq i32 %t63, 1
  %t66 = select i1 %t65, i32 1, i32 0
  %t67 = icmp eq i32 %t62, 0
  %t68 = shl i32 %t66, 16
  %t69 = or i32 %t68, %t64
  %t70 = select i1 %t67, i32 0, i32 %t69
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t72 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t70, 0
  store { i32, { i64, ptr } } %t72, ptr %rv
  br label %ret
bb15:
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t75 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t73, i64 %t74)
  %t80 = getelementptr i8, ptr %t79, i64 %t74
  call void @olang_textcopy(ptr %t80, ptr %t76, i64 %t77)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t85 = call { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %s2, ptr %s2, { i64, ptr } %t82)
  store { i64, ptr } %t85, ptr %l65
  br label %bb16
bb16:
  %t86 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t87 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t87, { i64, ptr } %t86)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = add i64 %t89, 1
  store i64 %t92, ptr %l6, !tbaa !24
  br label %bb7
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Plan", ptr %t94, i32 0, i32 12
  store ptr %t96, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t98 = load i64, ptr %l9, !tbaa !24
  store i64 %t98, ptr %l72, !tbaa !24
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l74
  br label %bb21
bb21:
  %t102 = load i64, ptr %l72, !tbaa !24
  %t103 = load i64, ptr %l74, !tbaa !24
  %t104 = icmp slt i64 %t102, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l8, !tbaa !29
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t108, i64 %t109)
  store i64 %t112, ptr %l79
  br label %bb25
bb25:
  %t113 = load i64, ptr %l79, !tbaa !24
  store ptr %l4, ptr %l80, !tbaa !29
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t118 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t115, i64 %t116)
  %t121 = getelementptr i8, ptr %t120, i64 %t116
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t113)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t120, 1
  %t127 = call { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %s6, ptr %s6, { i64, ptr } %t124)
  store { i64, ptr } %t127, ptr %l84
  br label %bb26
bb26:
  %t128 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t129 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t129, { i64, ptr } %t128)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l9, !tbaa !24
  br label %bb20
bb29:
  store i64 0, ptr %l11, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Plan", ptr %t136, i32 0, i32 20
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l91
  br label %bb30
bb30:
  %t141 = load i64, ptr %l91, !tbaa !24
  store i64 %t141, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb31, label %bb32
bb31:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb36
bb33:
  %t152 = load i64, ptr %l12, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l98, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb35
bb35:
  %t168 = load i64, ptr %l98, !tbaa !24
  store i64 %t168, ptr %l95, !tbaa !24
  br label %bb36
bb36:
  %t169 = load i64, ptr %l95, !tbaa !24
  store i64 %t169, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb39:
  br label %bb40
bb40:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l16, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l116, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Plan", ptr %t189, i32 0, i32 20
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t191, i64 %t192)
  store ptr %t195, ptr %l120
  br label %bb41
bb41:
  %t196 = load ptr, ptr %l116, !tbaa !29
  %t197 = load ptr, ptr %l120, !tbaa !29
  %t198 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v1, ptr %v0, ptr %t196, ptr %t197)
  store i64 %t198, ptr %l121
  br label %bb42
bb42:
  %t199 = load i64, ptr %l121, !tbaa !24
  store i64 %t199, ptr %l17, !tbaa !24
  %t200 = load i64, ptr %l17, !tbaa !24
  %t202 = icmp slt i64 %t200, 0
  br i1 %t202, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t205 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t205, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t206 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s10)
  store %"std/prelude/text:StringBuilder" %t206, ptr %l125
  br label %bb46
bb46:
  %t207 = load %"std/prelude/text:StringBuilder", ptr %l125
  store %"std/prelude/text:StringBuilder" %t207, ptr %l18
  %t208 = load i64, ptr %l17, !tbaa !24
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t212 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t209, i64 %t210)
  %t215 = getelementptr i8, ptr %t214, i64 %t210
  %t216 = call i64 @__olang_fmt_i64(ptr %t215, i64 %t208)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t214, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s10, ptr %l18, { i64, ptr } %t218)
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Plan", ptr %t222, i32 0, i32 21
  %t225 = load i64, ptr %l16, !tbaa !24
  %t228 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hb773ac01a07f3f9e7f749c328573d0ee(ptr %v0, ptr %s13, ptr %t224, i64 %t225)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l133
  br label %bb48
bb48:
  %t229 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  %t230 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %t230
  store ptr %t230, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s14
  %t232 = load i64, ptr %l20, !tbaa !24
  store i64 %t232, ptr %l135, !tbaa !24
  %t233 = load ptr, ptr %l19, !tbaa !29
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %s13, ptr %t233)
  store i64 %t235, ptr %l137
  br label %bb50
bb50:
  %t236 = load i64, ptr %l135, !tbaa !24
  %t237 = load i64, ptr %l137, !tbaa !24
  %t238 = icmp slt i64 %t236, %t237
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s14)
  br label %bb60
bb52:
  br label %bb53
bb53:
  %t242 = load ptr, ptr %l19, !tbaa !29
  %t243 = load i64, ptr %l20, !tbaa !24
  %t246 = call %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %s13, ptr %t242, i64 %t243)
  store %"compiler/typed:DerivedArg" %t246, ptr %l142
  br label %bb54
bb54:
  %t247 = load %"compiler/typed:DerivedArg", ptr %l142
  store %"compiler/typed:DerivedArg" %t247, ptr %l21
  store ptr %l18, ptr %l143, !tbaa !29
  %t248 = getelementptr %"compiler/typed:DerivedArg", ptr %l21, i32 0, i32 0
  %t249 = load i64, ptr %t248, !tbaa !24
  store i64 %t249, ptr %l144, !tbaa !24
  %t250 = getelementptr %"compiler/typed:DerivedArg", ptr %l21, i32 0, i32 1
  %t251 = load i64, ptr %t250, !tbaa !24
  store i64 %t251, ptr %l145, !tbaa !24
  %t252 = getelementptr %"compiler/typed:DerivedArg", ptr %l21, i32 0, i32 2
  %t253 = load { i64, [2 x i64] }, ptr %t252
  %t255 = call { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %s14, { i64, [2 x i64] } %t253)
  %t256 = extractvalue { i32, { i64, ptr } } %t255, 1
  %t257 = extractvalue { i32, { i64, ptr } } %t255, 0
  store i32 %t257, ptr %l149
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb56, label %ok.259, !prof !99
ok.259:
  store { i64, ptr } %t256, ptr %l148
  br label %bb55
bb55:
  %t260 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t260, ptr %l146, !tbaa !27
  br label %bb57
bb56:
  %t261 = load i32, ptr %l149, !tbaa !23
  %t262 = lshr i32 %t261, 16
  %t263 = and i32 %t261, 65535
  %t264 = icmp eq i32 %t262, 1
  %t265 = select i1 %t264, i32 1, i32 0
  %t266 = icmp eq i32 %t261, 0
  %t267 = shl i32 %t265, 16
  %t268 = or i32 %t267, %t263
  %t269 = select i1 %t266, i32 0, i32 %t268
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t271 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t269, 0
  store { i32, { i64, ptr } } %t271, ptr %rv
  br label %ret
bb57:
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t274 = load i64, ptr %l144, !tbaa !24
  %t275 = call i64 @__olang_fmt_i64(ptr null, i64 %t274)
  %t276 = add i64 %t273, %t275
  %t277 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t280 = load i64, ptr %l145, !tbaa !24
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t282 = add i64 %t279, %t281
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t272, i64 %t273)
  %t291 = getelementptr i8, ptr %t290, i64 %t273
  %t292 = call i64 @__olang_fmt_i64(ptr %t291, i64 %t274)
  %t293 = getelementptr i8, ptr %t291, i64 %t275
  call void @olang_textcopy(ptr %t293, ptr %t277, i64 %t278)
  %t294 = getelementptr i8, ptr %t293, i64 %t278
  %t295 = call i64 @__olang_fmt_i64(ptr %t294, i64 %t280)
  %t296 = getelementptr i8, ptr %t294, i64 %t281
  call void @olang_textcopy(ptr %t296, ptr %t283, i64 %t284)
  %t297 = getelementptr i8, ptr %t296, i64 %t284
  call void @olang_textcopy(ptr %t297, ptr %t287, i64 %t288)
  %t298 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t290, 1
  %t301 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s14, ptr %t301, { i64, ptr } %t299)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s14)
  br label %bb59
bb59:
  %t303 = load i64, ptr %l20, !tbaa !24
  %t306 = add i64 %t303, 1
  store i64 %t306, ptr %l20, !tbaa !24
  br label %bb49
bb60:
  call void @__olang_scope_close(ptr %s13)
  store ptr %l4, ptr %l156, !tbaa !29
  %t309 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s10, ptr %s10, ptr %l18)
  store { i64, ptr } %t309, ptr %l158
  br label %bb61
bb61:
  %t310 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t312 = call { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %s10, ptr %s10, { i64, ptr } %t310)
  store { i64, ptr } %t312, ptr %l160
  br label %bb62
bb62:
  %t313 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t314 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t314, { i64, ptr } %t313)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  %t316 = load i64, ptr %l15, !tbaa !24
  %t319 = add i64 %t316, 1
  store i64 %t319, ptr %l15, !tbaa !24
  br label %bb37
bb65:
  store i64 0, ptr %l22, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Plan", ptr %t321, i32 0, i32 22
  %t325 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t323)
  store i64 %t325, ptr %l167
  br label %bb66
bb66:
  %t326 = load i64, ptr %l167, !tbaa !24
  store i64 %t326, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t327 = load i64, ptr %l23, !tbaa !24
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = icmp sgt i64 %t327, %t328
  br i1 %t331, label %bb67, label %bb68
bb67:
  %t333 = load i64, ptr %l24, !tbaa !24
  %t335 = icmp sgt i64 %t333, 0
  br i1 %t335, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb72
bb69:
  %t337 = load i64, ptr %l23, !tbaa !24
  %t338 = load i64, ptr %l22, !tbaa !24
  %t341 = sub i64 %t337, %t338
  %t342 = load i64, ptr %l24, !tbaa !24
  %t345 = add i64 %t341, %t342
  %t347 = sub i64 %t345, 1
  %t348 = load i64, ptr %l24, !tbaa !24
  %t351 = sdiv i64 %t347, %t348
  store i64 %t351, ptr %l174, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb71
bb71:
  %t353 = load i64, ptr %l174, !tbaa !24
  store i64 %t353, ptr %l171, !tbaa !24
  br label %bb72
bb72:
  %t354 = load i64, ptr %l171, !tbaa !24
  store i64 %t354, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s19
  %t355 = load i64, ptr %l26, !tbaa !24
  %t356 = load i64, ptr %l25, !tbaa !24
  %t359 = icmp slt i64 %t355, %t356
  %t361 = xor i1 %t359, true
  br i1 %t361, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s19)
  br label %bb89
bb75:
  br label %bb76
bb76:
  %t363 = load i64, ptr %l22, !tbaa !24
  %t364 = load i64, ptr %l26, !tbaa !24
  %t365 = load i64, ptr %l24, !tbaa !24
  %t368 = mul i64 %t364, %t365
  %t371 = add i64 %t363, %t368
  store i64 %t371, ptr %l27, !tbaa !24
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l192, !tbaa !29
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Plan", ptr %t374, i32 0, i32 22
  %t377 = load i64, ptr %l27, !tbaa !24
  %t380 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t376, i64 %t377)
  store ptr %t380, ptr %l196
  br label %bb77
bb77:
  %t381 = load ptr, ptr %l192, !tbaa !29
  %t382 = load ptr, ptr %l196, !tbaa !29
  %t383 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v1, ptr %v0, ptr %t381, ptr %t382)
  store i64 %t383, ptr %l197
  br label %bb78
bb78:
  %t384 = load i64, ptr %l197, !tbaa !24
  store i64 %t384, ptr %l28, !tbaa !24
  %t385 = load i64, ptr %l28, !tbaa !24
  %t387 = icmp slt i64 %t385, 0
  br i1 %t387, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t390 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t390, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  store ptr %l4, ptr %l201, !tbaa !29
  %t391 = load i64, ptr %l28, !tbaa !24
  store i64 %t391, ptr %l202, !tbaa !24
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/typed:Plan", ptr %t392, i32 0, i32 23
  %t395 = load i64, ptr %l27, !tbaa !24
  %t398 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t394, i64 %t395)
  store { i64, [2 x i64] } %t398, ptr %l207
  br label %bb82
bb82:
  %t399 = load { i64, [2 x i64] }, ptr %l207
  %t400 = call { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %s19, { i64, [2 x i64] } %t399)
  %t401 = extractvalue { i32, { i64, ptr } } %t400, 1
  %t402 = extractvalue { i32, { i64, ptr } } %t400, 0
  store i32 %t402, ptr %l209
  %t403 = icmp ne i32 %t402, 0
  br i1 %t403, label %bb84, label %ok.404, !prof !99
ok.404:
  store { i64, ptr } %t401, ptr %l208
  br label %bb83
bb83:
  %t405 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t405, ptr %l203, !tbaa !27
  br label %bb85
bb84:
  %t406 = load i32, ptr %l209, !tbaa !23
  %t407 = lshr i32 %t406, 16
  %t408 = and i32 %t406, 65535
  %t409 = icmp eq i32 %t407, 1
  %t410 = select i1 %t409, i32 1, i32 0
  %t411 = icmp eq i32 %t406, 0
  %t412 = shl i32 %t410, 16
  %t413 = or i32 %t412, %t408
  %t414 = select i1 %t411, i32 0, i32 %t413
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t416 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t414, 0
  store { i32, { i64, ptr } } %t416, ptr %rv
  br label %ret
bb85:
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t419 = load i64, ptr %l202, !tbaa !24
  %t420 = call i64 @__olang_fmt_i64(ptr null, i64 %t419)
  %t421 = add i64 %t418, %t420
  %t422 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t424 = add i64 %t421, %t423
  %t425 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = add i64 %t424, %t427
  %t429 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t428)
  call void @olang_textcopy(ptr %t429, ptr %t417, i64 %t418)
  %t430 = getelementptr i8, ptr %t429, i64 %t418
  %t431 = call i64 @__olang_fmt_i64(ptr %t430, i64 %t419)
  %t432 = getelementptr i8, ptr %t430, i64 %t420
  call void @olang_textcopy(ptr %t432, ptr %t422, i64 %t423)
  %t433 = getelementptr i8, ptr %t432, i64 %t423
  call void @olang_textcopy(ptr %t433, ptr %t426, i64 %t427)
  %t434 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t429, 1
  %t438 = call { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %s19, ptr %s19, { i64, ptr } %t435)
  store { i64, ptr } %t438, ptr %l213
  br label %bb86
bb86:
  %t439 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t440 = load ptr, ptr %l201, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t440, { i64, ptr } %t439)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s19)
  br label %bb88
bb88:
  %t442 = load i64, ptr %l26, !tbaa !24
  %t445 = add i64 %t442, 1
  store i64 %t445, ptr %l26, !tbaa !24
  br label %bb73
bb89:
  store i64 0, ptr %l29, !tbaa !24
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/typed:Plan", ptr %t447, i32 0, i32 13
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t450, 0
  store i64 %t452, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t454 = load i64, ptr %l30, !tbaa !24
  %t455 = load i64, ptr %l29, !tbaa !24
  %t458 = icmp sgt i64 %t454, %t455
  br i1 %t458, label %bb90, label %bb91
bb90:
  %t460 = load i64, ptr %l31, !tbaa !24
  %t462 = icmp sgt i64 %t460, 0
  br i1 %t462, label %bb92, label %bb93
bb91:
  store i64 0, ptr %l224, !tbaa !24
  br label %bb95
bb92:
  %t464 = load i64, ptr %l30, !tbaa !24
  %t465 = load i64, ptr %l29, !tbaa !24
  %t468 = sub i64 %t464, %t465
  %t469 = load i64, ptr %l31, !tbaa !24
  %t472 = add i64 %t468, %t469
  %t474 = sub i64 %t472, 1
  %t475 = load i64, ptr %l31, !tbaa !24
  %t478 = sdiv i64 %t474, %t475
  store i64 %t478, ptr %l227, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l227, !tbaa !24
  br label %bb94
bb94:
  %t480 = load i64, ptr %l227, !tbaa !24
  store i64 %t480, ptr %l224, !tbaa !24
  br label %bb95
bb95:
  %t481 = load i64, ptr %l224, !tbaa !24
  store i64 %t481, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb96
bb96:
  %t482 = load i64, ptr %l33, !tbaa !24
  %t483 = load i64, ptr %l32, !tbaa !24
  %t486 = icmp slt i64 %t482, %t483
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb97, label %bb98
bb97:
  br label %bb110
bb98:
  br label %bb99
bb99:
  %t490 = load i64, ptr %l29, !tbaa !24
  %t491 = load i64, ptr %l33, !tbaa !24
  %t492 = load i64, ptr %l31, !tbaa !24
  %t495 = mul i64 %t491, %t492
  %t498 = add i64 %t490, %t495
  store i64 %t498, ptr %l34, !tbaa !24
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/typed:Plan", ptr %t500, i32 0, i32 13
  %t503 = load { i64, ptr }, ptr %t502, !tbaa !27
  store { i64, ptr } %t503, ptr %l246, !tbaa !27
  %t504 = load i64, ptr %l34, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr i64, ptr %t507, i64 %t504
  %t509 = load i64, ptr %t508, !tbaa !34
  %t511 = icmp sge i64 %t509, 0
  br i1 %t511, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s25
  store ptr %l4, ptr %l250, !tbaa !29
  %t513 = load i64, ptr %l34, !tbaa !24
  store i64 %t513, ptr %l251, !tbaa !24
  %t514 = load ptr, ptr %l3, !tbaa !29
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/typed:Plan", ptr %t515, i32 0, i32 13
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l255, !tbaa !27
  %t519 = load i64, ptr %l34, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr i64, ptr %t522, i64 %t519
  %t524 = load i64, ptr %t523, !tbaa !34
  %t527 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v3, ptr %t514, i64 %t524)
  %t528 = extractvalue { i32, i64 } %t527, 1
  %t529 = extractvalue { i32, i64 } %t527, 0
  store i32 %t529, ptr %l259
  %t530 = icmp ne i32 %t529, 0
  br i1 %t530, label %bb103, label %ok.531, !prof !99
ok.531:
  store i64 %t528, ptr %l258
  br label %bb102
bb101:
  br label %bb108
bb102:
  %t532 = load i64, ptr %l258, !tbaa !24
  store i64 %t532, ptr %l252, !tbaa !24
  br label %bb105
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t534 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t534, ptr %rv
  br label %ret
bb105:
  %t535 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t536 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t537 = load i64, ptr %l251, !tbaa !24
  %t538 = call i64 @__olang_fmt_i64(ptr null, i64 %t537)
  %t539 = add i64 %t536, %t538
  %t540 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t541 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t542 = add i64 %t539, %t541
  %t543 = load i64, ptr %l252, !tbaa !24
  %t544 = call i64 @__olang_fmt_i64(ptr null, i64 %t543)
  %t545 = add i64 %t542, %t544
  %t546 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t545)
  call void @olang_textcopy(ptr %t546, ptr %t535, i64 %t536)
  %t547 = getelementptr i8, ptr %t546, i64 %t536
  %t548 = call i64 @__olang_fmt_i64(ptr %t547, i64 %t537)
  %t549 = getelementptr i8, ptr %t547, i64 %t538
  call void @olang_textcopy(ptr %t549, ptr %t540, i64 %t541)
  %t550 = getelementptr i8, ptr %t549, i64 %t541
  %t551 = call i64 @__olang_fmt_i64(ptr %t550, i64 %t543)
  %t552 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t546, 1
  %t556 = call { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %s25, ptr %s25, { i64, ptr } %t553)
  store { i64, ptr } %t556, ptr %l263
  br label %bb106
bb106:
  %t557 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t558 = load ptr, ptr %l250, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t558, { i64, ptr } %t557)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s25)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t560 = load i64, ptr %l33, !tbaa !24
  %t563 = add i64 %t560, 1
  store i64 %t563, ptr %l33, !tbaa !24
  br label %bb96
bb110:
  %t566 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l4)
  store { i64, ptr } %t566, ptr %l269
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s0)
  %t567 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t568 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t567, 1
  store { i32, { i64, ptr } } %t568, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2etext(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/typed:DerivedArg"
  %l38 = alloca %"std/prelude/text:StringBuilder"
  %l60 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l83 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l141 = alloca i1
  %l143 = alloca { i64, ptr }
  %l147 = alloca i1
  %l149 = alloca { i64, ptr }
  %l154 = alloca i1
  %l156 = alloca { i64, ptr }
  %l164 = alloca i1
  %l166 = alloca { i64, ptr }
  %l170 = alloca i1
  %l172 = alloca { i64, ptr }
  %l179 = alloca i1
  %l181 = alloca { i64, ptr }
  %l185 = alloca i1
  %l188 = alloca { i64, ptr }
  %l191 = alloca i1
  %l195 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l210 = alloca i64
  %l213 = alloca i64
  %l231 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l242 = alloca { i64, [2 x i64] }
  %l243 = alloca { i64, ptr }
  %l244 = alloca i32
  %l257 = alloca i64
  %l261 = alloca i64
  %l264 = alloca i64
  %l282 = alloca ptr
  %l286 = alloca i64
  %l290 = alloca i64
  %l299 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l301 = alloca ptr
  %l305 = alloca i64
  %l307 = alloca i64
  %l312 = alloca i64
  %l317 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l321 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l322 = alloca i32
  %l324 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l327 = alloca i64
  %l329 = alloca i64
  %l334 = alloca %"compiler/typed:DerivedArg"
  %l335 = alloca ptr
  %l336 = alloca i64
  %l337 = alloca i64
  %l338 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l341 = alloca i32
  %l352 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l38
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l38
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Plan", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Plan", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Plan", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = call i64 @__olang_fmt_i64(ptr null, i64 %t8)
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t28 = add i64 %t25, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t33 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  %t36 = call i64 @__olang_fmt_i64(ptr %t35, i64 %t8)
  %t37 = getelementptr i8, ptr %t35, i64 %t22
  call void @olang_textcopy(ptr %t37, ptr %t23, i64 %t24)
  %t38 = getelementptr i8, ptr %t37, i64 %t24
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t14)
  %t40 = getelementptr i8, ptr %t38, i64 %t27
  call void @olang_textcopy(ptr %t40, ptr %t29, i64 %t30)
  %t41 = getelementptr i8, ptr %t40, i64 %t30
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t20)
  %t43 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t35, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t44)
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb3
bb3:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Plan", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l60, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i64 %t67
  %t72 = load { i64, [2 x i64] }, ptr %t71
  store ptr %l3, ptr %l63, !tbaa !29
  %t76 = call { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %s3, { i64, [2 x i64] } %t72)
  %t77 = extractvalue { i32, { i64, ptr } } %t76, 1
  %t78 = extractvalue { i32, { i64, ptr } } %t76, 0
  store i32 %t78, ptr %l67
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb9, label %ok.80, !prof !99
ok.80:
  store { i64, ptr } %t77, ptr %l66
  br label %bb8
bb8:
  %t81 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t81, ptr %l64, !tbaa !27
  br label %bb10
bb9:
  %t82 = load i32, ptr %l67, !tbaa !23
  %t83 = lshr i32 %t82, 16
  %t84 = and i32 %t82, 65535
  %t85 = icmp eq i32 %t83, 1
  %t86 = select i1 %t85, i32 1, i32 0
  %t87 = icmp eq i32 %t82, 0
  %t88 = shl i32 %t86, 16
  %t89 = or i32 %t88, %t84
  %t90 = select i1 %t87, i32 0, i32 %t89
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t92 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t90, 0
  store { i32, { i64, ptr } } %t92, ptr %rv
  br label %ret
bb10:
  %t93 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t95 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t93, i64 %t94)
  %t100 = getelementptr i8, ptr %t99, i64 %t94
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  %t104 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t104, { i64, ptr } %t102)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %l5, !tbaa !24
  br label %bb4
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb14
bb14:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Plan", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s7
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t129 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = load i64, ptr %l9, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i64 %t130
  %t135 = load { i64, [2 x i64] }, ptr %t134
  store ptr %l3, ptr %l86, !tbaa !29
  %t139 = call { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %s7, { i64, [2 x i64] } %t135)
  %t140 = extractvalue { i32, { i64, ptr } } %t139, 1
  %t141 = extractvalue { i32, { i64, ptr } } %t139, 0
  store i32 %t141, ptr %l90
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb20, label %ok.143, !prof !99
ok.143:
  store { i64, ptr } %t140, ptr %l89
  br label %bb19
bb19:
  %t144 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t144, ptr %l87, !tbaa !27
  br label %bb21
bb20:
  %t145 = load i32, ptr %l90, !tbaa !23
  %t146 = lshr i32 %t145, 16
  %t147 = and i32 %t145, 65535
  %t148 = icmp eq i32 %t146, 1
  %t149 = select i1 %t148, i32 1, i32 0
  %t150 = icmp eq i32 %t145, 0
  %t151 = shl i32 %t149, 16
  %t152 = or i32 %t151, %t147
  %t153 = select i1 %t150, i32 0, i32 %t152
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t155 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t153, 0
  store { i32, { i64, ptr } } %t155, ptr %rv
  br label %ret
bb21:
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t158 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = add i64 %t157, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t156, i64 %t157)
  %t163 = getelementptr i8, ptr %t162, i64 %t157
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  %t167 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t167, { i64, ptr } %t165)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  %t169 = load i64, ptr %l9, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l9, !tbaa !24
  br label %bb15
bb24:
  store ptr %l3, ptr %l97, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Plan", ptr %t174, i32 0, i32 2
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  %t179 = call { i64, ptr } @compiler_2ftyped_2ebitsText(ptr %v0, ptr %s0, { i64, ptr } %t177)
  store { i64, ptr } %t179, ptr %l100
  br label %bb25
bb25:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Plan", ptr %t180, i32 0, i32 3
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = call { i64, ptr } @compiler_2ftyped_2ebitsText(ptr %v0, ptr %s0, { i64, ptr } %t183)
  store { i64, ptr } %t185, ptr %l103
  br label %bb26
bb26:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Plan", ptr %t186, i32 0, i32 5
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t191 = call { i64, ptr } @compiler_2ftyped_2ebitsText(ptr %v0, ptr %s0, { i64, ptr } %t189)
  store { i64, ptr } %t191, ptr %l106
  br label %bb27
bb27:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Plan", ptr %t192, i32 0, i32 4
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t197 = call { i64, ptr } @compiler_2ftyped_2ebitsText(ptr %v0, ptr %s0, { i64, ptr } %t195)
  store { i64, ptr } %t197, ptr %l109
  br label %bb28
bb28:
  %t198 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t200 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = add i64 %t199, %t202
  %t204 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t207 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = add i64 %t213, %t216
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t198, i64 %t199)
  %t229 = getelementptr i8, ptr %t228, i64 %t199
  call void @olang_textcopy(ptr %t229, ptr %t201, i64 %t202)
  %t230 = getelementptr i8, ptr %t229, i64 %t202
  call void @olang_textcopy(ptr %t230, ptr %t204, i64 %t205)
  %t231 = getelementptr i8, ptr %t230, i64 %t205
  call void @olang_textcopy(ptr %t231, ptr %t208, i64 %t209)
  %t232 = getelementptr i8, ptr %t231, i64 %t209
  call void @olang_textcopy(ptr %t232, ptr %t211, i64 %t212)
  %t233 = getelementptr i8, ptr %t232, i64 %t212
  call void @olang_textcopy(ptr %t233, ptr %t215, i64 %t216)
  %t234 = getelementptr i8, ptr %t233, i64 %t216
  call void @olang_textcopy(ptr %t234, ptr %t218, i64 %t219)
  %t235 = getelementptr i8, ptr %t234, i64 %t219
  call void @olang_textcopy(ptr %t235, ptr %t222, i64 %t223)
  %t236 = getelementptr i8, ptr %t235, i64 %t223
  call void @olang_textcopy(ptr %t236, ptr %t225, i64 %t226)
  %t237 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t228, 1
  %t240 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t240, { i64, ptr } %t238)
  br label %bb29
bb29:
  store i64 0, ptr %l12, !tbaa !24
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Plan", ptr %t242, i32 0, i32 0
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  store i64 %t247, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t249 = load i64, ptr %l13, !tbaa !24
  %t250 = load i64, ptr %l12, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb30, label %bb31
bb30:
  %t255 = load i64, ptr %l14, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb35
bb32:
  %t259 = load i64, ptr %l13, !tbaa !24
  %t260 = load i64, ptr %l12, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l14, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l14, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l121, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb34
bb34:
  %t275 = load i64, ptr %l121, !tbaa !24
  store i64 %t275, ptr %l118, !tbaa !24
  br label %bb35
bb35:
  %t276 = load i64, ptr %l118, !tbaa !24
  store i64 %t276, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s12
  %t277 = load i64, ptr %l16, !tbaa !24
  %t278 = load i64, ptr %l15, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb38:
  br label %bb39
bb39:
  %t285 = load i64, ptr %l12, !tbaa !24
  %t286 = load i64, ptr %l16, !tbaa !24
  %t287 = load i64, ptr %l14, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l17, !tbaa !24
  %t295 = load i1, ptr %l1, !tbaa !21
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb40, label %bb41
bb40:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Plan", ptr %t299, i32 0, i32 6
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  store { i64, ptr } %t302, ptr %l143, !tbaa !27
  %t303 = load i64, ptr %l17, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i64, ptr %t306, i64 %t303
  %t308 = load i64, ptr %t307, !tbaa !34
  %t310 = icmp ne i64 %t308, 0
  br i1 %t310, label %bb42, label %bb43
bb41:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb48
bb42:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb44
bb43:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/typed:Plan", ptr %t312, i32 0, i32 7
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l149, !tbaa !27
  %t316 = load i64, ptr %l17, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr { i64, [2 x i64] }, ptr %t319, i64 %t316
  %t321 = load { i64, [2 x i64] }, ptr %t320
  %t323 = extractvalue { i64, [2 x i64] } %t321, 0
  %t324 = icmp eq i64 %t323, 0
  %t326 = xor i1 %t324, true
  store i1 %t326, ptr %l147, !tbaa !21
  br label %bb44
bb44:
  %t328 = load i1, ptr %l147, !tbaa !21
  br i1 %t328, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb47
bb46:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Plan", ptr %t329, i32 0, i32 8
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l156, !tbaa !27
  %t333 = load i64, ptr %l17, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr ptr, ptr %t336, i64 %t333
  %t338 = load ptr, ptr %t337, !tbaa !39
  %t340 = icmp eq ptr %t338, null
  %t342 = xor i1 %t340, true
  store i1 %t342, ptr %l154, !tbaa !21
  br label %bb47
bb47:
  %t344 = load i1, ptr %l154, !tbaa !21
  store i1 %t344, ptr %l141, !tbaa !21
  br label %bb48
bb48:
  %t345 = load i1, ptr %l141, !tbaa !21
  br i1 %t345, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t347 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t347, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t348 = load i1, ptr %l1, !tbaa !21
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb52, label %bb53
bb52:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Plan", ptr %t352, i32 0, i32 9
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !27
  store { i64, ptr } %t355, ptr %l166, !tbaa !27
  %t356 = load i64, ptr %l17, !tbaa !24
  %t358 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr i64, ptr %t359, i64 %t356
  %t361 = load i64, ptr %t360, !tbaa !34
  %t363 = icmp ne i64 %t361, -1
  br i1 %t363, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb57
bb54:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb56
bb55:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Plan", ptr %t365, i32 0, i32 10
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l172, !tbaa !27
  %t369 = load i64, ptr %l17, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr i64, ptr %t372, i64 %t369
  %t374 = load i64, ptr %t373, !tbaa !34
  %t376 = icmp ne i64 %t374, -1
  store i1 %t376, ptr %l170, !tbaa !21
  br label %bb56
bb56:
  %t378 = load i1, ptr %l170, !tbaa !21
  store i1 %t378, ptr %l164, !tbaa !21
  br label %bb57
bb57:
  %t379 = load i1, ptr %l164, !tbaa !21
  br i1 %t379, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t381 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t381, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t382 = load i1, ptr %l1, !tbaa !21
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb61, label %bb62
bb61:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Plan", ptr %t386, i32 0, i32 13
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  store { i64, ptr } %t389, ptr %l181, !tbaa !27
  %t390 = load i64, ptr %l17, !tbaa !24
  %t392 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr i64, ptr %t393, i64 %t390
  %t395 = load i64, ptr %t394, !tbaa !34
  %t397 = icmp ne i64 %t395, -1
  store i1 %t397, ptr %l179, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb63
bb63:
  %t399 = load i1, ptr %l179, !tbaa !21
  br i1 %t399, label %bb64, label %bb65
bb64:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Plan", ptr %t401, i32 0, i32 13
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  store { i64, ptr } %t404, ptr %l188, !tbaa !27
  %t405 = load i64, ptr %l17, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i64, ptr %t408, i64 %t405
  %t410 = load i64, ptr %t409, !tbaa !34
  %t413 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v1, ptr %a2, i64 %t410)
  store i1 %t413, ptr %l191
  br label %bb66
bb65:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb67
bb66:
  %t414 = load i1, ptr %l191, !tbaa !21
  %t415 = xor i1 %t414, true
  store i1 %t415, ptr %l185, !tbaa !21
  br label %bb67
bb67:
  %t417 = load i1, ptr %l185, !tbaa !21
  br i1 %t417, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t419 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t419, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Plan", ptr %t420, i32 0, i32 14
  %t423 = load { i64, ptr }, ptr %t422, !tbaa !27
  store { i64, ptr } %t423, ptr %l195, !tbaa !27
  %t424 = load i64, ptr %l17, !tbaa !24
  %t426 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr i64, ptr %t427, i64 %t424
  %t429 = load i64, ptr %t428, !tbaa !34
  %t431 = icmp eq i64 %t429, 0
  br i1 %t431, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s12)
  br label %bb92
bb72:
  br label %bb73
bb73:
  %t433 = load i64, ptr %l17, !tbaa !24
  %t434 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t435 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t437 = call i64 @__olang_fmt_i64(ptr null, i64 %t433)
  %t438 = add i64 %t435, %t437
  %t439 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t440 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t441 = add i64 %t438, %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t434, i64 %t435)
  %t443 = getelementptr i8, ptr %t442, i64 %t435
  %t444 = call i64 @__olang_fmt_i64(ptr %t443, i64 %t433)
  %t445 = getelementptr i8, ptr %t443, i64 %t437
  call void @olang_textcopy(ptr %t445, ptr %t439, i64 %t440)
  %t446 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t442, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l3, { i64, ptr } %t447)
  br label %bb74
bb74:
  store i64 0, ptr %l18, !tbaa !24
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/typed:Plan", ptr %t451, i32 0, i32 15
  %t454 = load { i64, ptr }, ptr %t453, !tbaa !27
  store { i64, ptr } %t454, ptr %l204, !tbaa !27
  %t455 = load i64, ptr %l17, !tbaa !24
  %t457 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !27
  %t459 = getelementptr i64, ptr %t458, i64 %t455
  %t460 = load i64, ptr %t459, !tbaa !34
  store i64 %t460, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t462 = load i64, ptr %l19, !tbaa !24
  %t463 = load i64, ptr %l18, !tbaa !24
  %t466 = icmp sgt i64 %t462, %t463
  br i1 %t466, label %bb75, label %bb76
bb75:
  %t468 = load i64, ptr %l20, !tbaa !24
  %t470 = icmp sgt i64 %t468, 0
  br i1 %t470, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb80
bb77:
  %t472 = load i64, ptr %l19, !tbaa !24
  %t473 = load i64, ptr %l18, !tbaa !24
  %t476 = sub i64 %t472, %t473
  %t477 = load i64, ptr %l20, !tbaa !24
  %t480 = add i64 %t476, %t477
  %t482 = sub i64 %t480, 1
  %t483 = load i64, ptr %l20, !tbaa !24
  %t486 = sdiv i64 %t482, %t483
  store i64 %t486, ptr %l213, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb79
bb79:
  %t488 = load i64, ptr %l213, !tbaa !24
  store i64 %t488, ptr %l210, !tbaa !24
  br label %bb80
bb80:
  %t489 = load i64, ptr %l210, !tbaa !24
  store i64 %t489, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  %t490 = load i64, ptr %l22, !tbaa !24
  %t491 = load i64, ptr %l21, !tbaa !24
  %t494 = icmp slt i64 %t490, %t491
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s19)
  br label %bb91
bb83:
  br label %bb84
bb84:
  %t498 = load i64, ptr %l18, !tbaa !24
  %t499 = load i64, ptr %l22, !tbaa !24
  %t500 = load i64, ptr %l20, !tbaa !24
  %t503 = mul i64 %t499, %t500
  %t506 = add i64 %t498, %t503
  store ptr %l3, ptr %l231, !tbaa !29
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/typed:Plan", ptr %t508, i32 0, i32 16
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Plan", ptr %t511, i32 0, i32 14
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l236, !tbaa !27
  %t515 = load i64, ptr %l17, !tbaa !24
  %t517 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !27
  %t519 = getelementptr i64, ptr %t518, i64 %t515
  %t520 = load i64, ptr %t519, !tbaa !34
  %t522 = sub i64 %t520, 1
  %t526 = add i64 %t522, %t506
  %t529 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t510, i64 %t526)
  store { i64, [2 x i64] } %t529, ptr %l242
  br label %bb85
bb85:
  %t530 = load { i64, [2 x i64] }, ptr %l242
  %t531 = call { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %s19, { i64, [2 x i64] } %t530)
  %t532 = extractvalue { i32, { i64, ptr } } %t531, 1
  %t533 = extractvalue { i32, { i64, ptr } } %t531, 0
  store i32 %t533, ptr %l244
  %t534 = icmp ne i32 %t533, 0
  br i1 %t534, label %bb87, label %ok.535, !prof !99
ok.535:
  store { i64, ptr } %t532, ptr %l243
  br label %bb86
bb86:
  %t536 = load { i64, ptr }, ptr %l243, !tbaa !27
  store { i64, ptr } %t536, ptr %l232, !tbaa !27
  br label %bb88
bb87:
  %t537 = load i32, ptr %l244, !tbaa !23
  %t538 = lshr i32 %t537, 16
  %t539 = and i32 %t537, 65535
  %t540 = icmp eq i32 %t538, 1
  %t541 = select i1 %t540, i32 1, i32 0
  %t542 = icmp eq i32 %t537, 0
  %t543 = shl i32 %t541, 16
  %t544 = or i32 %t543, %t539
  %t545 = select i1 %t542, i32 0, i32 %t544
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t547 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t545, 0
  store { i32, { i64, ptr } } %t547, ptr %rv
  br label %ret
bb88:
  %t548 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t549 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t550 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t550, 1
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t553 = add i64 %t549, %t552
  %t554 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t553)
  call void @olang_textcopy(ptr %t554, ptr %t548, i64 %t549)
  %t555 = getelementptr i8, ptr %t554, i64 %t549
  call void @olang_textcopy(ptr %t555, ptr %t551, i64 %t552)
  %t556 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t554, 1
  %t559 = load ptr, ptr %l231, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t559, { i64, ptr } %t557)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s19)
  br label %bb90
bb90:
  %t561 = load i64, ptr %l22, !tbaa !24
  %t564 = add i64 %t561, 1
  store i64 %t564, ptr %l22, !tbaa !24
  br label %bb81
bb91:
  call void @__olang_scope_close(ptr %s12)
  br label %bb92
bb92:
  %t566 = load i64, ptr %l16, !tbaa !24
  %t569 = add i64 %t566, 1
  store i64 %t569, ptr %l16, !tbaa !24
  br label %bb36
bb93:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb94
bb94:
  store i64 0, ptr %l24, !tbaa !24
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/typed:Plan", ptr %t572, i32 0, i32 17
  %t576 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t574)
  store i64 %t576, ptr %l257
  br label %bb95
bb95:
  %t577 = load i64, ptr %l257, !tbaa !24
  store i64 %t577, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t578 = load i64, ptr %l25, !tbaa !24
  %t579 = load i64, ptr %l24, !tbaa !24
  %t582 = icmp sgt i64 %t578, %t579
  br i1 %t582, label %bb96, label %bb97
bb96:
  %t584 = load i64, ptr %l26, !tbaa !24
  %t586 = icmp sgt i64 %t584, 0
  br i1 %t586, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb101
bb98:
  %t588 = load i64, ptr %l25, !tbaa !24
  %t589 = load i64, ptr %l24, !tbaa !24
  %t592 = sub i64 %t588, %t589
  %t593 = load i64, ptr %l26, !tbaa !24
  %t596 = add i64 %t592, %t593
  %t598 = sub i64 %t596, 1
  %t599 = load i64, ptr %l26, !tbaa !24
  %t602 = sdiv i64 %t598, %t599
  store i64 %t602, ptr %l264, !tbaa !24
  br label %bb100
bb99:
  store i64 0, ptr %l264, !tbaa !24
  br label %bb100
bb100:
  %t604 = load i64, ptr %l264, !tbaa !24
  store i64 %t604, ptr %l261, !tbaa !24
  br label %bb101
bb101:
  %t605 = load i64, ptr %l261, !tbaa !24
  store i64 %t605, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s24
  %t606 = load i64, ptr %l28, !tbaa !24
  %t607 = load i64, ptr %l27, !tbaa !24
  %t610 = icmp slt i64 %t606, %t607
  %t612 = xor i1 %t610, true
  br i1 %t612, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s24)
  br label %bb110
bb104:
  br label %bb105
bb105:
  %t614 = load i64, ptr %l24, !tbaa !24
  %t615 = load i64, ptr %l28, !tbaa !24
  %t616 = load i64, ptr %l26, !tbaa !24
  %t619 = mul i64 %t615, %t616
  %t622 = add i64 %t614, %t619
  store i64 %t622, ptr %l29, !tbaa !24
  store ptr %l3, ptr %l282, !tbaa !29
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/typed:Plan", ptr %t624, i32 0, i32 17
  %t627 = load i64, ptr %l29, !tbaa !24
  %t630 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t626, i64 %t627)
  store i64 %t630, ptr %l286
  br label %bb106
bb106:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/typed:Plan", ptr %t631, i32 0, i32 18
  %t634 = load i64, ptr %l29, !tbaa !24
  %t637 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t633, i64 %t634)
  store i64 %t637, ptr %l290
  br label %bb107
bb107:
  %t638 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t639 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t640 = load i64, ptr %l286, !tbaa !24
  %t641 = call i64 @__olang_fmt_i64(ptr null, i64 %t640)
  %t642 = add i64 %t639, %t641
  %t643 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t644 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t645 = add i64 %t642, %t644
  %t646 = load i64, ptr %l290, !tbaa !24
  %t647 = call i64 @__olang_fmt_i64(ptr null, i64 %t646)
  %t648 = add i64 %t645, %t647
  %t649 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t648)
  call void @olang_textcopy(ptr %t649, ptr %t638, i64 %t639)
  %t650 = getelementptr i8, ptr %t649, i64 %t639
  %t651 = call i64 @__olang_fmt_i64(ptr %t650, i64 %t640)
  %t652 = getelementptr i8, ptr %t650, i64 %t641
  call void @olang_textcopy(ptr %t652, ptr %t643, i64 %t644)
  %t653 = getelementptr i8, ptr %t652, i64 %t644
  %t654 = call i64 @__olang_fmt_i64(ptr %t653, i64 %t646)
  %t655 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t649, 1
  %t658 = load ptr, ptr %l282, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %t658, { i64, ptr } %t656)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s24)
  br label %bb109
bb109:
  %t660 = load i64, ptr %l28, !tbaa !24
  %t663 = add i64 %t660, 1
  store i64 %t663, ptr %l28, !tbaa !24
  br label %bb102
bb110:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb111
bb111:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Plan", ptr %t666, i32 0, i32 19
  %t670 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7ff170222aba52a9798b1085ab00b195(ptr %v0, ptr %v0, ptr %t668)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t670, ptr %l299
  br label %bb112
bb112:
  %t671 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l299
  %t672 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 16, i64 8)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t671, ptr %t672
  %t674 = call ptr @std_2fprelude_2fiterator_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20std_2fprelude_2fv_H35a7352784077c26387f60e3d578bee5(ptr %v0, ptr %s0, ptr %t672)
  store ptr %t674, ptr %l301
  br label %bb113
bb113:
  %t675 = load ptr, ptr %l301, !tbaa !29
  store ptr %t675, ptr %l30, !tbaa !29
  %t676 = load ptr, ptr %l30, !tbaa !29
  %t677 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_53, 0
  %t678 = insertvalue { ptr, ptr } %t677, ptr null, 1
  %t681 = extractvalue { ptr, ptr } %t678, 0
  %t682 = extractvalue { ptr, ptr } %t678, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %t676, ptr %t681, ptr %t682)
  br label %bb114
bb114:
  %t683 = load ptr, ptr %l30, !tbaa !29
  store ptr %t683, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s28
  %t685 = load i64, ptr %l32, !tbaa !24
  store i64 %t685, ptr %l305, !tbaa !24
  %t686 = load ptr, ptr %l31, !tbaa !29
  %t688 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t686)
  store i64 %t688, ptr %l307
  br label %bb116
bb116:
  %t689 = load i64, ptr %l305, !tbaa !24
  %t690 = load i64, ptr %l307, !tbaa !24
  %t691 = icmp slt i64 %t689, %t690
  %t693 = xor i1 %t691, true
  br i1 %t693, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s28)
  br label %bb140
bb118:
  br label %bb119
bb119:
  %t695 = load ptr, ptr %l31, !tbaa !29
  %t696 = load i64, ptr %l32, !tbaa !24
  %t699 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t695, i64 %t696)
  store i64 %t699, ptr %l312
  br label %bb120
bb120:
  %t700 = load i64, ptr %l312, !tbaa !24
  store i64 %t700, ptr %l33, !tbaa !24
  %t701 = load i64, ptr %l33, !tbaa !24
  %t702 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t703 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t705 = call i64 @__olang_fmt_i64(ptr null, i64 %t701)
  %t706 = add i64 %t703, %t705
  %t707 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t708 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t709 = add i64 %t706, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t702, i64 %t703)
  %t711 = getelementptr i8, ptr %t710, i64 %t703
  %t712 = call i64 @__olang_fmt_i64(ptr %t711, i64 %t701)
  %t713 = getelementptr i8, ptr %t711, i64 %t705
  call void @olang_textcopy(ptr %t713, ptr %t707, i64 %t708)
  %t714 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t715 = insertvalue { i64, ptr } %t714, ptr %t710, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %l3, { i64, ptr } %t715)
  br label %bb121
bb121:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t721 = getelementptr %"compiler/typed:Plan", ptr %t719, i32 0, i32 19
  %t722 = load i64, ptr %l33, !tbaa !24
  %t725 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H05bdc185ea10b7cb65a89c49d4b056c8(ptr %v0, ptr %v0, ptr %t721, i64 %t722)
  %t726 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t725, 1
  %t727 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t725, 0
  store i32 %t727, ptr %l322
  %t728 = icmp ne i32 %t727, 0
  br i1 %t728, label %bb123, label %ok.729, !prof !99
ok.729:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t726, ptr %l321
  br label %bb122
bb122:
  %t731 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %s28, ptr %l321)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t731, ptr %l324
  br label %bb125
bb123:
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t733 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t733, ptr %rv
  br label %ret
bb125:
  %t734 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l324
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t734, ptr %l317
  br label %bb126
bb126:
  %t735 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l317
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t735, ptr %l34
  store ptr %l34, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb127
bb127:
  store %olang.scope zeroinitializer, ptr %s32
  %t737 = load i64, ptr %l36, !tbaa !24
  store i64 %t737, ptr %l327, !tbaa !24
  %t738 = load ptr, ptr %l35, !tbaa !29
  %t740 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %s28, ptr %t738)
  store i64 %t740, ptr %l329
  br label %bb128
bb128:
  %t741 = load i64, ptr %l327, !tbaa !24
  %t742 = load i64, ptr %l329, !tbaa !24
  %t743 = icmp slt i64 %t741, %t742
  %t745 = xor i1 %t743, true
  br i1 %t745, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s32)
  br label %bb138
bb130:
  br label %bb131
bb131:
  %t747 = load ptr, ptr %l35, !tbaa !29
  %t748 = load i64, ptr %l36, !tbaa !24
  %t751 = call %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %s28, ptr %t747, i64 %t748)
  store %"compiler/typed:DerivedArg" %t751, ptr %l334
  br label %bb132
bb132:
  %t752 = load %"compiler/typed:DerivedArg", ptr %l334
  store %"compiler/typed:DerivedArg" %t752, ptr %l37
  store ptr %l3, ptr %l335, !tbaa !29
  %t753 = getelementptr %"compiler/typed:DerivedArg", ptr %l37, i32 0, i32 0
  %t754 = load i64, ptr %t753, !tbaa !24
  store i64 %t754, ptr %l336, !tbaa !24
  %t755 = getelementptr %"compiler/typed:DerivedArg", ptr %l37, i32 0, i32 1
  %t756 = load i64, ptr %t755, !tbaa !24
  store i64 %t756, ptr %l337, !tbaa !24
  %t757 = getelementptr %"compiler/typed:DerivedArg", ptr %l37, i32 0, i32 2
  %t758 = load { i64, [2 x i64] }, ptr %t757
  %t760 = call { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %s32, { i64, [2 x i64] } %t758)
  %t761 = extractvalue { i32, { i64, ptr } } %t760, 1
  %t762 = extractvalue { i32, { i64, ptr } } %t760, 0
  store i32 %t762, ptr %l341
  %t763 = icmp ne i32 %t762, 0
  br i1 %t763, label %bb134, label %ok.764, !prof !99
ok.764:
  store { i64, ptr } %t761, ptr %l340
  br label %bb133
bb133:
  %t765 = load { i64, ptr }, ptr %l340, !tbaa !27
  store { i64, ptr } %t765, ptr %l338, !tbaa !27
  br label %bb135
bb134:
  %t766 = load i32, ptr %l341, !tbaa !23
  %t767 = lshr i32 %t766, 16
  %t768 = and i32 %t766, 65535
  %t769 = icmp eq i32 %t767, 1
  %t770 = select i1 %t769, i32 1, i32 0
  %t771 = icmp eq i32 %t766, 0
  %t772 = shl i32 %t770, 16
  %t773 = or i32 %t772, %t768
  %t774 = select i1 %t771, i32 0, i32 %t773
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t776 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t774, 0
  store { i32, { i64, ptr } } %t776, ptr %rv
  br label %ret
bb135:
  %t777 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t778 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t779 = load i64, ptr %l336, !tbaa !24
  %t780 = call i64 @__olang_fmt_i64(ptr null, i64 %t779)
  %t781 = add i64 %t778, %t780
  %t782 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t784 = add i64 %t781, %t783
  %t785 = load i64, ptr %l337, !tbaa !24
  %t786 = call i64 @__olang_fmt_i64(ptr null, i64 %t785)
  %t787 = add i64 %t784, %t786
  %t788 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t790 = add i64 %t787, %t789
  %t791 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = add i64 %t790, %t793
  %t795 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t794)
  call void @olang_textcopy(ptr %t795, ptr %t777, i64 %t778)
  %t796 = getelementptr i8, ptr %t795, i64 %t778
  %t797 = call i64 @__olang_fmt_i64(ptr %t796, i64 %t779)
  %t798 = getelementptr i8, ptr %t796, i64 %t780
  call void @olang_textcopy(ptr %t798, ptr %t782, i64 %t783)
  %t799 = getelementptr i8, ptr %t798, i64 %t783
  %t800 = call i64 @__olang_fmt_i64(ptr %t799, i64 %t785)
  %t801 = getelementptr i8, ptr %t799, i64 %t786
  call void @olang_textcopy(ptr %t801, ptr %t788, i64 %t789)
  %t802 = getelementptr i8, ptr %t801, i64 %t789
  call void @olang_textcopy(ptr %t802, ptr %t792, i64 %t793)
  %t803 = insertvalue { i64, ptr } undef, i64 %t794, 0
  %t804 = insertvalue { i64, ptr } %t803, ptr %t795, 1
  %t806 = load ptr, ptr %l335, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s32, ptr %t806, { i64, ptr } %t804)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s32)
  br label %bb137
bb137:
  %t808 = load i64, ptr %l36, !tbaa !24
  %t811 = add i64 %t808, 1
  store i64 %t811, ptr %l36, !tbaa !24
  br label %bb127
bb138:
  call void @__olang_scope_close(ptr %s28)
  br label %bb139
bb139:
  %t813 = load i64, ptr %l32, !tbaa !24
  %t816 = add i64 %t813, 1
  store i64 %t816, ptr %l32, !tbaa !24
  br label %bb115
bb140:
  %t819 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t819, ptr %l352
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s0)
  %t820 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t821 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t820, 1
  store { i32, { i64, ptr } } %t821, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca %"compiler/typed:Local"
  %l45 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l112 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i1
  %l125 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l163 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i1
  %l176 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i1
  %l211 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l218 = alloca i64
  %l222 = alloca i64
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l228 = alloca i64
  %l232 = alloca i64
  %l233 = alloca i1
  %l234 = alloca i1
  %l242 = alloca i64
  %l246 = alloca i64
  %l249 = alloca i64
  %l270 = alloca i64
  %l273 = alloca i1
  %l279 = alloca i64
  %l281 = alloca ptr
  %l282 = alloca ptr
  %l283 = alloca ptr
  %l284 = alloca ptr
  %l288 = alloca i64
  %l289 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l33, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v3, ptr %t8)
  store i64 %t10, ptr %l36
  br label %bb3
bb3:
  %t11 = load i64, ptr %l33, !tbaa !24
  %t12 = load i64, ptr %l36, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l32, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l32, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb9
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l39, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 7
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v3, ptr %t19, i64 %t20)
  store %"compiler/typed:Local" %t23, ptr %l43
  br label %bb7
bb7:
  %t24 = getelementptr %"compiler/typed:Local", ptr %l43, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l39, !tbaa !29
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t26, i32 %t25)
  store i1 %t28, ptr %l45
  br label %bb8
bb8:
  %t29 = load i1, ptr %l45, !tbaa !21
  store i1 %t29, ptr %l38, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l38, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 39
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v4, ptr %t34, i64 %t35)
  store i1 %t38, ptr %l50
  br label %bb13
bb13:
  %t39 = load i1, ptr %l50, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/typed:LocalUses", ptr %t40, i32 0, i32 42
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v4, ptr %t42, i64 %t43)
  store i1 %t46, ptr %l55
  br label %bb16
bb16:
  %t47 = load i1, ptr %l55, !tbaa !21
  store i1 %t47, ptr %l51, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l51, !tbaa !21
  br i1 %t48, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:LocalUses", ptr %t50, i32 0, i32 44
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v4, ptr %t52, i64 %t53)
  store i1 %t56, ptr %l60
  br label %bb21
bb21:
  %t57 = load i1, ptr %l60, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 63
  %t61 = load i1, ptr %t60, !tbaa !21
  %t63 = xor i1 %t61, true
  store i1 %t63, ptr %l61, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t65 = load i1, ptr %l61, !tbaa !21
  br i1 %t65, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store i64 0, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 27
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t69)
  store i64 %t71, ptr %l68
  br label %bb28
bb28:
  %t72 = load i64, ptr %l68, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb34
bb31:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l75, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb33
bb33:
  %t99 = load i64, ptr %l75, !tbaa !24
  store i64 %t99, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t100 = load i64, ptr %l72, !tbaa !24
  store i64 %t100, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb36, label %bb37
bb36:
  br label %bb54
bb37:
  br label %bb38
bb38:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l11, !tbaa !24
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t121 = getelementptr %"compiler/typed:LocalUses", ptr %t119, i32 0, i32 27
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t121, i64 %t122)
  store i64 %t125, ptr %l96
  br label %bb39
bb39:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t127 = load i64, ptr %l96, !tbaa !24
  %t129 = icmp eq i64 %t127, %t126
  br i1 %t129, label %bb40, label %bb41
bb40:
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = getelementptr %"compiler/typed:LocalUses", ptr %t131, i32 0, i32 30
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v4, ptr %t133, i64 %t134)
  store i1 %t137, ptr %l103
  br label %bb42
bb41:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb43
bb42:
  %t138 = load i1, ptr %l103, !tbaa !21
  %t139 = xor i1 %t138, true
  store i1 %t139, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t141 = load i1, ptr %l99, !tbaa !21
  br i1 %t141, label %bb44, label %bb45
bb44:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l106, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l107, !tbaa !29
  %t144 = load ptr, ptr %l2, !tbaa !29
  store ptr %t144, ptr %l108, !tbaa !29
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 28
  %t148 = load i64, ptr %l11, !tbaa !24
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t147, i64 %t148)
  store i64 %t151, ptr %l112
  br label %bb46
bb45:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb49
bb46:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/typed:LocalUses", ptr %t152, i32 0, i32 29
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l116
  br label %bb47
bb47:
  %t159 = load ptr, ptr %l106, !tbaa !29
  %t160 = load ptr, ptr %l107, !tbaa !29
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = load i64, ptr %l112, !tbaa !24
  %t163 = load i64, ptr %l116, !tbaa !24
  %t164 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t159, ptr %t160, ptr %t161, i64 %t162, i64 %t163, i1 true)
  store i1 %t164, ptr %l117
  br label %bb48
bb48:
  %t165 = load i1, ptr %l117, !tbaa !21
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l105, !tbaa !21
  br label %bb49
bb49:
  %t168 = load i1, ptr %l105, !tbaa !21
  br i1 %t168, label %bb50, label %bb51
bb50:
  store i1 true, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t170 = load i64, ptr %l10, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l10, !tbaa !24
  br label %bb35
bb54:
  store i64 0, ptr %l12, !tbaa !24
  %t175 = load ptr, ptr %l4, !tbaa !29
  %t177 = getelementptr %"compiler/typed:LocalUses", ptr %t175, i32 0, i32 24
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t177)
  store i64 %t179, ptr %l125
  br label %bb55
bb55:
  %t180 = load i64, ptr %l125, !tbaa !24
  store i64 %t180, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t181 = load i64, ptr %l13, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = icmp sgt i64 %t181, %t182
  br i1 %t185, label %bb56, label %bb57
bb56:
  %t187 = load i64, ptr %l14, !tbaa !24
  %t189 = icmp sgt i64 %t187, 0
  br i1 %t189, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l129, !tbaa !24
  br label %bb61
bb58:
  %t191 = load i64, ptr %l13, !tbaa !24
  %t192 = load i64, ptr %l12, !tbaa !24
  %t195 = sub i64 %t191, %t192
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = add i64 %t195, %t196
  %t201 = sub i64 %t199, 1
  %t202 = load i64, ptr %l14, !tbaa !24
  %t205 = sdiv i64 %t201, %t202
  store i64 %t205, ptr %l132, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l132, !tbaa !24
  br label %bb60
bb60:
  %t207 = load i64, ptr %l132, !tbaa !24
  store i64 %t207, ptr %l129, !tbaa !24
  br label %bb61
bb61:
  %t208 = load i64, ptr %l129, !tbaa !24
  store i64 %t208, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb62
bb62:
  %t209 = load i64, ptr %l16, !tbaa !24
  %t210 = load i64, ptr %l15, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb63, label %bb64
bb63:
  br label %bb77
bb64:
  br label %bb65
bb65:
  %t217 = load i64, ptr %l12, !tbaa !24
  %t218 = load i64, ptr %l16, !tbaa !24
  %t219 = load i64, ptr %l14, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t225 = add i64 %t217, %t222
  store i64 %t225, ptr %l17, !tbaa !24
  %t227 = load ptr, ptr %l4, !tbaa !29
  %t229 = getelementptr %"compiler/typed:LocalUses", ptr %t227, i32 0, i32 24
  %t230 = load i64, ptr %l17, !tbaa !24
  %t233 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t229, i64 %t230)
  store i64 %t233, ptr %l153
  br label %bb66
bb66:
  %t234 = load i64, ptr %l5, !tbaa !24
  %t235 = load i64, ptr %l153, !tbaa !24
  %t237 = icmp eq i64 %t235, %t234
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l157, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  store ptr %t240, ptr %l158, !tbaa !29
  %t241 = load ptr, ptr %l2, !tbaa !29
  store ptr %t241, ptr %l159, !tbaa !29
  %t242 = load ptr, ptr %l4, !tbaa !29
  %t244 = getelementptr %"compiler/typed:LocalUses", ptr %t242, i32 0, i32 25
  %t245 = load i64, ptr %l17, !tbaa !24
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t244, i64 %t245)
  store i64 %t248, ptr %l163
  br label %bb69
bb68:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb72
bb69:
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = getelementptr %"compiler/typed:LocalUses", ptr %t249, i32 0, i32 26
  %t252 = load i64, ptr %l17, !tbaa !24
  %t255 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t251, i64 %t252)
  store i64 %t255, ptr %l167
  br label %bb70
bb70:
  %t256 = load ptr, ptr %l157, !tbaa !29
  %t257 = load ptr, ptr %l158, !tbaa !29
  %t258 = load ptr, ptr %l159, !tbaa !29
  %t259 = load i64, ptr %l163, !tbaa !24
  %t260 = load i64, ptr %l167, !tbaa !24
  %t261 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t256, ptr %t257, ptr %t258, i64 %t259, i64 %t260, i1 true)
  store i1 %t261, ptr %l168
  br label %bb71
bb71:
  %t262 = load i1, ptr %l168, !tbaa !21
  %t263 = xor i1 %t262, true
  store i1 %t263, ptr %l156, !tbaa !21
  br label %bb72
bb72:
  %t265 = load i1, ptr %l156, !tbaa !21
  br i1 %t265, label %bb73, label %bb74
bb73:
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t267 = load i64, ptr %l16, !tbaa !24
  %t270 = add i64 %t267, 1
  store i64 %t270, ptr %l16, !tbaa !24
  br label %bb62
bb77:
  store i64 0, ptr %l18, !tbaa !24
  %t272 = load ptr, ptr %l4, !tbaa !29
  %t274 = getelementptr %"compiler/typed:LocalUses", ptr %t272, i32 0, i32 45
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t274)
  store i64 %t276, ptr %l176
  br label %bb78
bb78:
  %t277 = load i64, ptr %l176, !tbaa !24
  store i64 %t277, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t278 = load i64, ptr %l19, !tbaa !24
  %t279 = load i64, ptr %l18, !tbaa !24
  %t282 = icmp sgt i64 %t278, %t279
  br i1 %t282, label %bb79, label %bb80
bb79:
  %t284 = load i64, ptr %l20, !tbaa !24
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb84
bb81:
  %t288 = load i64, ptr %l19, !tbaa !24
  %t289 = load i64, ptr %l18, !tbaa !24
  %t292 = sub i64 %t288, %t289
  %t293 = load i64, ptr %l20, !tbaa !24
  %t296 = add i64 %t292, %t293
  %t298 = sub i64 %t296, 1
  %t299 = load i64, ptr %l20, !tbaa !24
  %t302 = sdiv i64 %t298, %t299
  store i64 %t302, ptr %l183, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb83
bb83:
  %t304 = load i64, ptr %l183, !tbaa !24
  store i64 %t304, ptr %l180, !tbaa !24
  br label %bb84
bb84:
  %t305 = load i64, ptr %l180, !tbaa !24
  store i64 %t305, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb85
bb85:
  %t306 = load i64, ptr %l22, !tbaa !24
  %t307 = load i64, ptr %l21, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb86, label %bb87
bb86:
  br label %bb107
bb87:
  br label %bb88
bb88:
  %t314 = load i64, ptr %l18, !tbaa !24
  %t315 = load i64, ptr %l22, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l23, !tbaa !24
  %t324 = load ptr, ptr %l4, !tbaa !29
  %t326 = getelementptr %"compiler/typed:LocalUses", ptr %t324, i32 0, i32 45
  %t327 = load i64, ptr %l23, !tbaa !24
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t326, i64 %t327)
  store i64 %t330, ptr %l204
  br label %bb89
bb89:
  %t331 = load i64, ptr %l5, !tbaa !24
  %t332 = load i64, ptr %l204, !tbaa !24
  %t334 = icmp ne i64 %t332, %t331
  br i1 %t334, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb93
bb91:
  %t336 = load ptr, ptr %l4, !tbaa !29
  %t338 = getelementptr %"compiler/typed:LocalUses", ptr %t336, i32 0, i32 48
  %t339 = load i64, ptr %l23, !tbaa !24
  %t342 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v4, ptr %t338, i64 %t339)
  store i1 %t342, ptr %l211
  br label %bb92
bb92:
  %t343 = load i1, ptr %l211, !tbaa !21
  store i1 %t343, ptr %l207, !tbaa !21
  br label %bb93
bb93:
  %t344 = load i1, ptr %l207, !tbaa !21
  br i1 %t344, label %bb94, label %bb95
bb94:
  br label %bb106
bb95:
  br label %bb96
bb96:
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l212, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l213, !tbaa !29
  %t347 = load ptr, ptr %l2, !tbaa !29
  store ptr %t347, ptr %l214, !tbaa !29
  %t348 = load ptr, ptr %l4, !tbaa !29
  %t350 = getelementptr %"compiler/typed:LocalUses", ptr %t348, i32 0, i32 46
  %t351 = load i64, ptr %l23, !tbaa !24
  %t354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t350, i64 %t351)
  store i64 %t354, ptr %l218
  br label %bb97
bb97:
  %t355 = load ptr, ptr %l4, !tbaa !29
  %t357 = getelementptr %"compiler/typed:LocalUses", ptr %t355, i32 0, i32 47
  %t358 = load i64, ptr %l23, !tbaa !24
  %t361 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t357, i64 %t358)
  store i64 %t361, ptr %l222
  br label %bb98
bb98:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l223, !tbaa !29
  %t363 = load ptr, ptr %l2, !tbaa !29
  store ptr %t363, ptr %l224, !tbaa !29
  %t364 = load ptr, ptr %l4, !tbaa !29
  %t366 = getelementptr %"compiler/typed:LocalUses", ptr %t364, i32 0, i32 46
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t366, i64 %t367)
  store i64 %t370, ptr %l228
  br label %bb99
bb99:
  %t371 = load ptr, ptr %l4, !tbaa !29
  %t373 = getelementptr %"compiler/typed:LocalUses", ptr %t371, i32 0, i32 47
  %t374 = load i64, ptr %l23, !tbaa !24
  %t377 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t373, i64 %t374)
  store i64 %t377, ptr %l232
  br label %bb100
bb100:
  %t378 = load ptr, ptr %l223, !tbaa !29
  %t379 = load ptr, ptr %l224, !tbaa !29
  %t380 = load i64, ptr %l228, !tbaa !24
  %t381 = load i64, ptr %l232, !tbaa !24
  %t382 = call i1 @compiler_2ftyped_2erefParam(ptr %v1, ptr %v2, ptr %t378, ptr %t379, i64 %t380, i64 %t381)
  store i1 %t382, ptr %l233
  br label %bb101
bb101:
  %t383 = load ptr, ptr %l212, !tbaa !29
  %t384 = load ptr, ptr %l213, !tbaa !29
  %t385 = load ptr, ptr %l214, !tbaa !29
  %t386 = load i64, ptr %l218, !tbaa !24
  %t387 = load i64, ptr %l222, !tbaa !24
  %t388 = load i1, ptr %l233, !tbaa !21
  %t389 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t383, ptr %t384, ptr %t385, i64 %t386, i64 %t387, i1 %t388)
  store i1 %t389, ptr %l234
  br label %bb102
bb102:
  %t390 = load i1, ptr %l234, !tbaa !21
  %t391 = xor i1 %t390, true
  br i1 %t391, label %bb103, label %bb104
bb103:
  store i1 true, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t394 = load i64, ptr %l22, !tbaa !24
  %t397 = add i64 %t394, 1
  store i64 %t397, ptr %l22, !tbaa !24
  br label %bb85
bb107:
  store i64 0, ptr %l24, !tbaa !24
  %t399 = load ptr, ptr %l4, !tbaa !29
  %t401 = getelementptr %"compiler/typed:LocalUses", ptr %t399, i32 0, i32 50
  %t403 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v4, ptr %t401)
  store i64 %t403, ptr %l242
  br label %bb108
bb108:
  %t404 = load i64, ptr %l242, !tbaa !24
  store i64 %t404, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t405 = load i64, ptr %l25, !tbaa !24
  %t406 = load i64, ptr %l24, !tbaa !24
  %t409 = icmp sgt i64 %t405, %t406
  br i1 %t409, label %bb109, label %bb110
bb109:
  %t411 = load i64, ptr %l26, !tbaa !24
  %t413 = icmp sgt i64 %t411, 0
  br i1 %t413, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb114
bb111:
  %t415 = load i64, ptr %l25, !tbaa !24
  %t416 = load i64, ptr %l24, !tbaa !24
  %t419 = sub i64 %t415, %t416
  %t420 = load i64, ptr %l26, !tbaa !24
  %t423 = add i64 %t419, %t420
  %t425 = sub i64 %t423, 1
  %t426 = load i64, ptr %l26, !tbaa !24
  %t429 = sdiv i64 %t425, %t426
  store i64 %t429, ptr %l249, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb113
bb113:
  %t431 = load i64, ptr %l249, !tbaa !24
  store i64 %t431, ptr %l246, !tbaa !24
  br label %bb114
bb114:
  %t432 = load i64, ptr %l246, !tbaa !24
  store i64 %t432, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb115
bb115:
  %t433 = load i64, ptr %l28, !tbaa !24
  %t434 = load i64, ptr %l27, !tbaa !24
  %t437 = icmp slt i64 %t433, %t434
  %t439 = xor i1 %t437, true
  br i1 %t439, label %bb116, label %bb117
bb116:
  br label %bb133
bb117:
  br label %bb118
bb118:
  %t441 = load i64, ptr %l24, !tbaa !24
  %t442 = load i64, ptr %l28, !tbaa !24
  %t443 = load i64, ptr %l26, !tbaa !24
  %t446 = mul i64 %t442, %t443
  %t449 = add i64 %t441, %t446
  store i64 %t449, ptr %l29, !tbaa !24
  %t451 = load ptr, ptr %l4, !tbaa !29
  %t453 = getelementptr %"compiler/typed:LocalUses", ptr %t451, i32 0, i32 50
  %t454 = load i64, ptr %l29, !tbaa !24
  %t457 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t453, i64 %t454)
  store i64 %t457, ptr %l270
  br label %bb119
bb119:
  %t458 = load i64, ptr %l5, !tbaa !24
  %t459 = load i64, ptr %l270, !tbaa !24
  %t461 = icmp ne i64 %t459, %t458
  br i1 %t461, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l273, !tbaa !21
  br label %bb123
bb121:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t465 = load ptr, ptr %l2, !tbaa !29
  %t466 = load ptr, ptr %l4, !tbaa !29
  %t467 = load i64, ptr %l29, !tbaa !24
  %t473 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t463, ptr %t464, ptr %t465, ptr %t466, i64 %t467)
  store i64 %t473, ptr %l279
  br label %bb122
bb122:
  %t474 = load i64, ptr %l279, !tbaa !24
  %t475 = icmp slt i64 %t474, 2
  store i1 %t475, ptr %l273, !tbaa !21
  br label %bb123
bb123:
  %t477 = load i1, ptr %l273, !tbaa !21
  br i1 %t477, label %bb124, label %bb125
bb124:
  br label %bb132
bb125:
  br label %bb126
bb126:
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l281, !tbaa !29
  %t479 = load ptr, ptr %l1, !tbaa !29
  store ptr %t479, ptr %l282, !tbaa !29
  %t480 = load ptr, ptr %l2, !tbaa !29
  store ptr %t480, ptr %l283, !tbaa !29
  %t481 = load ptr, ptr %l4, !tbaa !29
  store ptr %t481, ptr %l284, !tbaa !29
  %t482 = load ptr, ptr %l4, !tbaa !29
  %t484 = getelementptr %"compiler/typed:LocalUses", ptr %t482, i32 0, i32 49
  %t485 = load i64, ptr %l29, !tbaa !24
  %t488 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v4, ptr %t484, i64 %t485)
  store i64 %t488, ptr %l288
  br label %bb127
bb127:
  %t489 = load ptr, ptr %l281, !tbaa !29
  %t490 = load ptr, ptr %l282, !tbaa !29
  %t491 = load ptr, ptr %l283, !tbaa !29
  %t492 = load ptr, ptr %l284, !tbaa !29
  %t493 = load i64, ptr %l288, !tbaa !24
  %t494 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t489, ptr %t490, ptr %t491, ptr %t492, i64 %t493, i1 false, i64 0)
  store i1 %t494, ptr %l289
  br label %bb128
bb128:
  %t495 = load i1, ptr %l289, !tbaa !21
  br i1 %t495, label %bb129, label %bb130
bb129:
  store i1 true, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t497 = load i64, ptr %l28, !tbaa !24
  %t500 = add i64 %t497, 1
  store i64 %t500, ptr %l28, !tbaa !24
  br label %bb115
bb133:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4, i1 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l38 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i64
  %l73 = alloca i64
  %l75 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i1
  %l134 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l162 = alloca i64
  %l165 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l172 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i1
  %l185 = alloca i64
  %l189 = alloca i64
  %l192 = alloca i64
  %l213 = alloca i64
  %l216 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l223 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i1
  %l236 = alloca i64
  %l240 = alloca i64
  %l243 = alloca i64
  %l264 = alloca i64
  %l267 = alloca i1
  %l273 = alloca i64
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l277 = alloca ptr
  %l278 = alloca ptr
  %l282 = alloca i64
  %l286 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftyped_2eHanded, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i1, ptr %l5, !tbaa !21
  %t9 = xor i1 %t7, true
  store i1 %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 16
  store i1 %t17, ptr %l38, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l38, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:LocalUses", ptr %t21, i32 0, i32 39
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t23, i64 %t24)
  store i1 %t27, ptr %l45
  br label %bb10
bb10:
  %t28 = load i1, ptr %l45, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb14
bb12:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/typed:LocalUses", ptr %t29, i32 0, i32 40
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l50
  br label %bb13
bb13:
  %t36 = load i1, ptr %l50, !tbaa !21
  store i1 %t36, ptr %l46, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l46, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb16:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %t38, i32 0, i32 41
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l55
  br label %bb17
bb17:
  %t45 = load i1, ptr %l55, !tbaa !21
  store i1 %t45, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l51, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t48 = load i1, ptr %l5, !tbaa !21
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/typed:LocalUses", ptr %t52, i32 0, i32 42
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t54, i64 %t55)
  store i1 %t58, ptr %l63
  br label %bb24
bb23:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb37
bb24:
  %t59 = load i1, ptr %l63, !tbaa !21
  br i1 %t59, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb28
bb26:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/typed:LocalUses", ptr %t60, i32 0, i32 43
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t62, i64 %t63)
  store i1 %t66, ptr %l68
  br label %bb27
bb27:
  %t67 = load i1, ptr %l68, !tbaa !21
  store i1 %t67, ptr %l64, !tbaa !21
  br label %bb28
bb28:
  %t68 = load i1, ptr %l64, !tbaa !21
  br i1 %t68, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb36
bb30:
  %t69 = load i64, ptr %l4, !tbaa !24
  store i64 %t69, ptr %l70, !tbaa !24
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:LocalUses", ptr %t70, i32 0, i32 18
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v3, ptr %t72)
  store i64 %t74, ptr %l73
  br label %bb31
bb31:
  %t75 = load i64, ptr %l70, !tbaa !24
  %t76 = load i64, ptr %l73, !tbaa !24
  %t77 = icmp slt i64 %t75, %t76
  br i1 %t77, label %bb32, label %bb33
bb32:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/typed:LocalUses", ptr %t79, i32 0, i32 18
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t81, i64 %t82)
  store i1 %t85, ptr %l79
  br label %bb34
bb33:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb35
bb34:
  %t86 = load i1, ptr %l79, !tbaa !21
  store i1 %t86, ptr %l75, !tbaa !21
  br label %bb35
bb35:
  %t87 = load i1, ptr %l75, !tbaa !21
  store i1 %t87, ptr %l69, !tbaa !21
  br label %bb36
bb36:
  %t88 = load i1, ptr %l69, !tbaa !21
  store i1 %t88, ptr %l59, !tbaa !21
  br label %bb37
bb37:
  %t89 = load i1, ptr %l59, !tbaa !21
  br i1 %t89, label %bb38, label %bb39
bb38:
  store i1 true, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l7, !tbaa !24
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/typed:LocalUses", ptr %t91, i32 0, i32 27
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t93)
  store i64 %t95, ptr %l83
  br label %bb41
bb41:
  %t96 = load i64, ptr %l83, !tbaa !24
  store i64 %t96, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb42, label %bb43
bb42:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb47
bb44:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l90, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb46
bb46:
  %t123 = load i64, ptr %l90, !tbaa !24
  store i64 %t123, ptr %l87, !tbaa !24
  br label %bb47
bb47:
  %t124 = load i64, ptr %l87, !tbaa !24
  store i64 %t124, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb48
bb48:
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb49, label %bb50
bb49:
  br label %bb63
bb50:
  br label %bb51
bb51:
  %t133 = load i64, ptr %l7, !tbaa !24
  %t134 = load i64, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l12, !tbaa !24
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/typed:LocalUses", ptr %t143, i32 0, i32 27
  %t146 = load i64, ptr %l12, !tbaa !24
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l111
  br label %bb52
bb52:
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l111, !tbaa !24
  %t153 = icmp eq i64 %t151, %t150
  br i1 %t153, label %bb53, label %bb54
bb53:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l115, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l116, !tbaa !29
  %t157 = load ptr, ptr %l2, !tbaa !29
  store ptr %t157, ptr %l117, !tbaa !29
  %t158 = load ptr, ptr %l3, !tbaa !29
  %t160 = getelementptr %"compiler/typed:LocalUses", ptr %t158, i32 0, i32 28
  %t161 = load i64, ptr %l12, !tbaa !24
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t160, i64 %t161)
  store i64 %t164, ptr %l121
  br label %bb55
bb54:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb58
bb55:
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/typed:LocalUses", ptr %t165, i32 0, i32 29
  %t168 = load i64, ptr %l12, !tbaa !24
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l125
  br label %bb56
bb56:
  %t172 = load ptr, ptr %l115, !tbaa !29
  %t173 = load ptr, ptr %l116, !tbaa !29
  %t174 = load ptr, ptr %l117, !tbaa !29
  %t175 = load i64, ptr %l121, !tbaa !24
  %t176 = load i64, ptr %l125, !tbaa !24
  %t177 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t172, ptr %t173, ptr %t174, i64 %t175, i64 %t176, i1 false)
  store i1 %t177, ptr %l126
  br label %bb57
bb57:
  %t178 = load i1, ptr %l126, !tbaa !21
  %t179 = xor i1 %t178, true
  store i1 %t179, ptr %l114, !tbaa !21
  br label %bb58
bb58:
  %t181 = load i1, ptr %l114, !tbaa !21
  br i1 %t181, label %bb59, label %bb60
bb59:
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l11, !tbaa !24
  br label %bb48
bb63:
  store i64 0, ptr %l13, !tbaa !24
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t190 = getelementptr %"compiler/typed:LocalUses", ptr %t188, i32 0, i32 24
  %t192 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t190)
  store i64 %t192, ptr %l134
  br label %bb64
bb64:
  %t193 = load i64, ptr %l134, !tbaa !24
  store i64 %t193, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb65, label %bb66
bb65:
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb70
bb67:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l13, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l15, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l141, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb69
bb69:
  %t220 = load i64, ptr %l141, !tbaa !24
  store i64 %t220, ptr %l138, !tbaa !24
  br label %bb70
bb70:
  %t221 = load i64, ptr %l138, !tbaa !24
  store i64 %t221, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb71
bb71:
  %t222 = load i64, ptr %l17, !tbaa !24
  %t223 = load i64, ptr %l16, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb72, label %bb73
bb72:
  br label %bb86
bb73:
  br label %bb74
bb74:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l17, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l18, !tbaa !24
  %t240 = load ptr, ptr %l3, !tbaa !29
  %t242 = getelementptr %"compiler/typed:LocalUses", ptr %t240, i32 0, i32 24
  %t243 = load i64, ptr %l18, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t242, i64 %t243)
  store i64 %t246, ptr %l162
  br label %bb75
bb75:
  %t247 = load i64, ptr %l4, !tbaa !24
  %t248 = load i64, ptr %l162, !tbaa !24
  %t250 = icmp eq i64 %t248, %t247
  br i1 %t250, label %bb76, label %bb77
bb76:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l166, !tbaa !29
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l167, !tbaa !29
  %t254 = load ptr, ptr %l2, !tbaa !29
  store ptr %t254, ptr %l168, !tbaa !29
  %t255 = load ptr, ptr %l3, !tbaa !29
  %t257 = getelementptr %"compiler/typed:LocalUses", ptr %t255, i32 0, i32 25
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t257, i64 %t258)
  store i64 %t261, ptr %l172
  br label %bb78
bb77:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb81
bb78:
  %t262 = load ptr, ptr %l3, !tbaa !29
  %t264 = getelementptr %"compiler/typed:LocalUses", ptr %t262, i32 0, i32 26
  %t265 = load i64, ptr %l18, !tbaa !24
  %t268 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t264, i64 %t265)
  store i64 %t268, ptr %l176
  br label %bb79
bb79:
  %t269 = load ptr, ptr %l166, !tbaa !29
  %t270 = load ptr, ptr %l167, !tbaa !29
  %t271 = load ptr, ptr %l168, !tbaa !29
  %t272 = load i64, ptr %l172, !tbaa !24
  %t273 = load i64, ptr %l176, !tbaa !24
  %t274 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t269, ptr %t270, ptr %t271, i64 %t272, i64 %t273, i1 false)
  store i1 %t274, ptr %l177
  br label %bb80
bb80:
  %t275 = load i1, ptr %l177, !tbaa !21
  %t276 = xor i1 %t275, true
  store i1 %t276, ptr %l165, !tbaa !21
  br label %bb81
bb81:
  %t278 = load i1, ptr %l165, !tbaa !21
  br i1 %t278, label %bb82, label %bb83
bb82:
  store i1 true, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t280 = load i64, ptr %l17, !tbaa !24
  %t283 = add i64 %t280, 1
  store i64 %t283, ptr %l17, !tbaa !24
  br label %bb71
bb86:
  store i64 0, ptr %l19, !tbaa !24
  %t285 = load ptr, ptr %l3, !tbaa !29
  %t287 = getelementptr %"compiler/typed:LocalUses", ptr %t285, i32 0, i32 45
  %t289 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t287)
  store i64 %t289, ptr %l185
  br label %bb87
bb87:
  %t290 = load i64, ptr %l185, !tbaa !24
  store i64 %t290, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t291 = load i64, ptr %l20, !tbaa !24
  %t292 = load i64, ptr %l19, !tbaa !24
  %t295 = icmp sgt i64 %t291, %t292
  br i1 %t295, label %bb88, label %bb89
bb88:
  %t297 = load i64, ptr %l21, !tbaa !24
  %t299 = icmp sgt i64 %t297, 0
  br i1 %t299, label %bb90, label %bb91
bb89:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb93
bb90:
  %t301 = load i64, ptr %l20, !tbaa !24
  %t302 = load i64, ptr %l19, !tbaa !24
  %t305 = sub i64 %t301, %t302
  %t306 = load i64, ptr %l21, !tbaa !24
  %t309 = add i64 %t305, %t306
  %t311 = sub i64 %t309, 1
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = sdiv i64 %t311, %t312
  store i64 %t315, ptr %l192, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb92
bb92:
  %t317 = load i64, ptr %l192, !tbaa !24
  store i64 %t317, ptr %l189, !tbaa !24
  br label %bb93
bb93:
  %t318 = load i64, ptr %l189, !tbaa !24
  store i64 %t318, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb94
bb94:
  %t319 = load i64, ptr %l23, !tbaa !24
  %t320 = load i64, ptr %l22, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb95, label %bb96
bb95:
  br label %bb109
bb96:
  br label %bb97
bb97:
  %t327 = load i64, ptr %l19, !tbaa !24
  %t328 = load i64, ptr %l23, !tbaa !24
  %t329 = load i64, ptr %l21, !tbaa !24
  %t332 = mul i64 %t328, %t329
  %t335 = add i64 %t327, %t332
  store i64 %t335, ptr %l24, !tbaa !24
  %t337 = load ptr, ptr %l3, !tbaa !29
  %t339 = getelementptr %"compiler/typed:LocalUses", ptr %t337, i32 0, i32 45
  %t340 = load i64, ptr %l24, !tbaa !24
  %t343 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t339, i64 %t340)
  store i64 %t343, ptr %l213
  br label %bb98
bb98:
  %t344 = load i64, ptr %l4, !tbaa !24
  %t345 = load i64, ptr %l213, !tbaa !24
  %t347 = icmp eq i64 %t345, %t344
  br i1 %t347, label %bb99, label %bb100
bb99:
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l217, !tbaa !29
  %t350 = load ptr, ptr %l1, !tbaa !29
  store ptr %t350, ptr %l218, !tbaa !29
  %t351 = load ptr, ptr %l2, !tbaa !29
  store ptr %t351, ptr %l219, !tbaa !29
  %t352 = load ptr, ptr %l3, !tbaa !29
  %t354 = getelementptr %"compiler/typed:LocalUses", ptr %t352, i32 0, i32 46
  %t355 = load i64, ptr %l24, !tbaa !24
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t354, i64 %t355)
  store i64 %t358, ptr %l223
  br label %bb101
bb100:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb104
bb101:
  %t359 = load ptr, ptr %l3, !tbaa !29
  %t361 = getelementptr %"compiler/typed:LocalUses", ptr %t359, i32 0, i32 47
  %t362 = load i64, ptr %l24, !tbaa !24
  %t365 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t361, i64 %t362)
  store i64 %t365, ptr %l227
  br label %bb102
bb102:
  %t366 = load ptr, ptr %l217, !tbaa !29
  %t367 = load ptr, ptr %l218, !tbaa !29
  %t368 = load ptr, ptr %l219, !tbaa !29
  %t369 = load i64, ptr %l223, !tbaa !24
  %t370 = load i64, ptr %l227, !tbaa !24
  %t371 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t366, ptr %t367, ptr %t368, i64 %t369, i64 %t370, i1 false)
  store i1 %t371, ptr %l228
  br label %bb103
bb103:
  %t372 = load i1, ptr %l228, !tbaa !21
  %t373 = xor i1 %t372, true
  store i1 %t373, ptr %l216, !tbaa !21
  br label %bb104
bb104:
  %t375 = load i1, ptr %l216, !tbaa !21
  br i1 %t375, label %bb105, label %bb106
bb105:
  store i1 true, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t377 = load i64, ptr %l23, !tbaa !24
  %t380 = add i64 %t377, 1
  store i64 %t380, ptr %l23, !tbaa !24
  br label %bb94
bb109:
  store i64 0, ptr %l25, !tbaa !24
  %t382 = load ptr, ptr %l3, !tbaa !29
  %t384 = getelementptr %"compiler/typed:LocalUses", ptr %t382, i32 0, i32 50
  %t386 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v3, ptr %t384)
  store i64 %t386, ptr %l236
  br label %bb110
bb110:
  %t387 = load i64, ptr %l236, !tbaa !24
  store i64 %t387, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t388 = load i64, ptr %l26, !tbaa !24
  %t389 = load i64, ptr %l25, !tbaa !24
  %t392 = icmp sgt i64 %t388, %t389
  br i1 %t392, label %bb111, label %bb112
bb111:
  %t394 = load i64, ptr %l27, !tbaa !24
  %t396 = icmp sgt i64 %t394, 0
  br i1 %t396, label %bb113, label %bb114
bb112:
  store i64 0, ptr %l240, !tbaa !24
  br label %bb116
bb113:
  %t398 = load i64, ptr %l26, !tbaa !24
  %t399 = load i64, ptr %l25, !tbaa !24
  %t402 = sub i64 %t398, %t399
  %t403 = load i64, ptr %l27, !tbaa !24
  %t406 = add i64 %t402, %t403
  %t408 = sub i64 %t406, 1
  %t409 = load i64, ptr %l27, !tbaa !24
  %t412 = sdiv i64 %t408, %t409
  store i64 %t412, ptr %l243, !tbaa !24
  br label %bb115
bb114:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb115
bb115:
  %t414 = load i64, ptr %l243, !tbaa !24
  store i64 %t414, ptr %l240, !tbaa !24
  br label %bb116
bb116:
  %t415 = load i64, ptr %l240, !tbaa !24
  store i64 %t415, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb117
bb117:
  %t416 = load i64, ptr %l29, !tbaa !24
  %t417 = load i64, ptr %l28, !tbaa !24
  %t420 = icmp slt i64 %t416, %t417
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb118, label %bb119
bb118:
  br label %bb135
bb119:
  br label %bb120
bb120:
  %t424 = load i64, ptr %l25, !tbaa !24
  %t425 = load i64, ptr %l29, !tbaa !24
  %t426 = load i64, ptr %l27, !tbaa !24
  %t429 = mul i64 %t425, %t426
  %t432 = add i64 %t424, %t429
  store i64 %t432, ptr %l30, !tbaa !24
  %t434 = load ptr, ptr %l3, !tbaa !29
  %t436 = getelementptr %"compiler/typed:LocalUses", ptr %t434, i32 0, i32 50
  %t437 = load i64, ptr %l30, !tbaa !24
  %t440 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t436, i64 %t437)
  store i64 %t440, ptr %l264
  br label %bb121
bb121:
  %t441 = load i64, ptr %l4, !tbaa !24
  %t442 = load i64, ptr %l264, !tbaa !24
  %t444 = icmp ne i64 %t442, %t441
  br i1 %t444, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb125
bb123:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t448 = load ptr, ptr %l2, !tbaa !29
  %t449 = load ptr, ptr %l3, !tbaa !29
  %t450 = load i64, ptr %l30, !tbaa !24
  %t456 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t446, ptr %t447, ptr %t448, ptr %t449, i64 %t450)
  store i64 %t456, ptr %l273
  br label %bb124
bb124:
  %t457 = load i64, ptr %l273, !tbaa !24
  %t458 = icmp eq i64 %t457, 0
  store i1 %t458, ptr %l267, !tbaa !21
  br label %bb125
bb125:
  %t460 = load i1, ptr %l267, !tbaa !21
  br i1 %t460, label %bb126, label %bb127
bb126:
  br label %bb134
bb127:
  br label %bb128
bb128:
  %t461 = load ptr, ptr %l0, !tbaa !29
  store ptr %t461, ptr %l275, !tbaa !29
  %t462 = load ptr, ptr %l1, !tbaa !29
  store ptr %t462, ptr %l276, !tbaa !29
  %t463 = load ptr, ptr %l2, !tbaa !29
  store ptr %t463, ptr %l277, !tbaa !29
  %t464 = load ptr, ptr %l3, !tbaa !29
  store ptr %t464, ptr %l278, !tbaa !29
  %t465 = load ptr, ptr %l3, !tbaa !29
  %t467 = getelementptr %"compiler/typed:LocalUses", ptr %t465, i32 0, i32 49
  %t468 = load i64, ptr %l30, !tbaa !24
  %t471 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t467, i64 %t468)
  store i64 %t471, ptr %l282
  br label %bb129
bb129:
  %t472 = load i1, ptr %l5, !tbaa !21
  %t473 = load i64, ptr %l6, !tbaa !24
  %t475 = add i64 %t473, 1
  %t476 = load ptr, ptr %l275, !tbaa !29
  %t477 = load ptr, ptr %l276, !tbaa !29
  %t478 = load ptr, ptr %l277, !tbaa !29
  %t479 = load ptr, ptr %l278, !tbaa !29
  %t480 = load i64, ptr %l282, !tbaa !24
  %t483 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t476, ptr %t477, ptr %t478, ptr %t479, i64 %t480, i1 %t472, i64 %t475)
  store i1 %t483, ptr %l286
  br label %bb130
bb130:
  %t484 = load i1, ptr %l286, !tbaa !21
  br i1 %t484, label %bb131, label %bb132
bb131:
  store i1 true, ptr %rv
  br label %ret
bb132:
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t486 = load i64, ptr %l29, !tbaa !24
  %t489 = add i64 %t486, 1
  store i64 %t489, ptr %l29, !tbaa !24
  br label %bb117
bb135:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneKeptIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:LocalUses"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/typed:LocalUses"
  %l47 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i1
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l136 = alloca i64
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l145 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i1
  %l156 = alloca i64
  %l160 = alloca i64
  %l163 = alloca i64
  %l183 = alloca i64
  %l186 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l192 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i1
  %l203 = alloca i64
  %l207 = alloca i64
  %l210 = alloca i64
  %l230 = alloca i64
  %l233 = alloca i1
  %l239 = alloca i64
  %l241 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l244 = alloca ptr
  %l247 = alloca i64
  %l248 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t22 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb4
bb2:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l35, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t11)
  store i64 %t13, ptr %l38
  br label %bb3
bb3:
  %t14 = load i64, ptr %l35, !tbaa !24
  %t15 = load i64, ptr %l38, !tbaa !24
  %t16 = icmp sge i64 %t14, %t15
  store i1 %t16, ptr %l34, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l34, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t22, ptr %v1, ptr %v3, ptr %s0, ptr %t20, ptr %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t22, i64 1640, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l43, i64 1640, i1 false)
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t27, i64 %t28)
  store i32 %t31, ptr %l47
  br label %bb9
bb9:
  %t32 = load i32, ptr %l47, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l6, !tbaa !24
  %t35 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 39
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l51
  br label %bb10
bb10:
  %t40 = load i1, ptr %l51, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb14
bb12:
  %t41 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 40
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l55
  br label %bb13
bb13:
  %t46 = load i1, ptr %l55, !tbaa !21
  store i1 %t46, ptr %l52, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l52, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 41
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l59
  br label %bb17
bb17:
  %t53 = load i1, ptr %l59, !tbaa !21
  store i1 %t53, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l56, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l7, !tbaa !24
  %t56 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 27
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t56)
  store i64 %t58, ptr %l62
  br label %bb22
bb22:
  %t59 = load i64, ptr %l62, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb28
bb25:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l69, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb27
bb27:
  %t86 = load i64, ptr %l69, !tbaa !24
  store i64 %t86, ptr %l66, !tbaa !24
  br label %bb28
bb28:
  %t87 = load i64, ptr %l66, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb30, label %bb31
bb30:
  br label %bb44
bb31:
  br label %bb32
bb32:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l12, !tbaa !24
  %t106 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 27
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t106, i64 %t107)
  store i64 %t110, ptr %l89
  br label %bb33
bb33:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t112 = load i64, ptr %l89, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l93, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l94, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  store ptr %t118, ptr %l95, !tbaa !29
  %t119 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 28
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t119, i64 %t120)
  store i64 %t123, ptr %l98
  br label %bb36
bb35:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb39
bb36:
  %t124 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 29
  %t125 = load i64, ptr %l12, !tbaa !24
  %t128 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t124, i64 %t125)
  store i64 %t128, ptr %l101
  br label %bb37
bb37:
  %t129 = load ptr, ptr %l93, !tbaa !29
  %t130 = load ptr, ptr %l94, !tbaa !29
  %t131 = load ptr, ptr %l95, !tbaa !29
  %t132 = load i64, ptr %l98, !tbaa !24
  %t133 = load i64, ptr %l101, !tbaa !24
  %t134 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t129, ptr %t130, ptr %t131, i64 %t132, i64 %t133, i1 false)
  store i1 %t134, ptr %l102
  br label %bb38
bb38:
  %t135 = load i1, ptr %l102, !tbaa !21
  %t136 = xor i1 %t135, true
  store i1 %t136, ptr %l92, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l92, !tbaa !21
  br i1 %t138, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l11, !tbaa !24
  br label %bb29
bb44:
  store i64 0, ptr %l13, !tbaa !24
  %t145 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 24
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t145)
  store i64 %t147, ptr %l109
  br label %bb45
bb45:
  %t148 = load i64, ptr %l109, !tbaa !24
  store i64 %t148, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l13, !tbaa !24
  %t153 = icmp sgt i64 %t149, %t150
  br i1 %t153, label %bb46, label %bb47
bb46:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t157 = icmp sgt i64 %t155, 0
  br i1 %t157, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb51
bb48:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t169 = sub i64 %t167, 1
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = sdiv i64 %t169, %t170
  store i64 %t173, ptr %l116, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb50
bb50:
  %t175 = load i64, ptr %l116, !tbaa !24
  store i64 %t175, ptr %l113, !tbaa !24
  br label %bb51
bb51:
  %t176 = load i64, ptr %l113, !tbaa !24
  store i64 %t176, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb52
bb52:
  %t177 = load i64, ptr %l17, !tbaa !24
  %t178 = load i64, ptr %l16, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb53, label %bb54
bb53:
  br label %bb67
bb54:
  br label %bb55
bb55:
  %t185 = load i64, ptr %l13, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = mul i64 %t186, %t187
  %t193 = add i64 %t185, %t190
  store i64 %t193, ptr %l18, !tbaa !24
  %t195 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 24
  %t196 = load i64, ptr %l18, !tbaa !24
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t195, i64 %t196)
  store i64 %t199, ptr %l136
  br label %bb56
bb56:
  %t200 = load i64, ptr %l6, !tbaa !24
  %t201 = load i64, ptr %l136, !tbaa !24
  %t203 = icmp eq i64 %t201, %t200
  br i1 %t203, label %bb57, label %bb58
bb57:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l140, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l141, !tbaa !29
  %t207 = load ptr, ptr %l2, !tbaa !29
  store ptr %t207, ptr %l142, !tbaa !29
  %t208 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 25
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l145
  br label %bb59
bb58:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb62
bb59:
  %t213 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 26
  %t214 = load i64, ptr %l18, !tbaa !24
  %t217 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t213, i64 %t214)
  store i64 %t217, ptr %l148
  br label %bb60
bb60:
  %t218 = load ptr, ptr %l140, !tbaa !29
  %t219 = load ptr, ptr %l141, !tbaa !29
  %t220 = load ptr, ptr %l142, !tbaa !29
  %t221 = load i64, ptr %l145, !tbaa !24
  %t222 = load i64, ptr %l148, !tbaa !24
  %t223 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t218, ptr %t219, ptr %t220, i64 %t221, i64 %t222, i1 false)
  store i1 %t223, ptr %l149
  br label %bb61
bb61:
  %t224 = load i1, ptr %l149, !tbaa !21
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l139, !tbaa !21
  br label %bb62
bb62:
  %t227 = load i1, ptr %l139, !tbaa !21
  br i1 %t227, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t229 = load i64, ptr %l17, !tbaa !24
  %t232 = add i64 %t229, 1
  store i64 %t232, ptr %l17, !tbaa !24
  br label %bb52
bb67:
  store i64 0, ptr %l19, !tbaa !24
  %t234 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 45
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t234)
  store i64 %t236, ptr %l156
  br label %bb68
bb68:
  %t237 = load i64, ptr %l156, !tbaa !24
  store i64 %t237, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load i64, ptr %l19, !tbaa !24
  %t242 = icmp sgt i64 %t238, %t239
  br i1 %t242, label %bb69, label %bb70
bb69:
  %t244 = load i64, ptr %l21, !tbaa !24
  %t246 = icmp sgt i64 %t244, 0
  br i1 %t246, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb74
bb71:
  %t248 = load i64, ptr %l20, !tbaa !24
  %t249 = load i64, ptr %l19, !tbaa !24
  %t252 = sub i64 %t248, %t249
  %t253 = load i64, ptr %l21, !tbaa !24
  %t256 = add i64 %t252, %t253
  %t258 = sub i64 %t256, 1
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = sdiv i64 %t258, %t259
  store i64 %t262, ptr %l163, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb73
bb73:
  %t264 = load i64, ptr %l163, !tbaa !24
  store i64 %t264, ptr %l160, !tbaa !24
  br label %bb74
bb74:
  %t265 = load i64, ptr %l160, !tbaa !24
  store i64 %t265, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb75
bb75:
  %t266 = load i64, ptr %l23, !tbaa !24
  %t267 = load i64, ptr %l22, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb76, label %bb77
bb76:
  br label %bb90
bb77:
  br label %bb78
bb78:
  %t274 = load i64, ptr %l19, !tbaa !24
  %t275 = load i64, ptr %l23, !tbaa !24
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = mul i64 %t275, %t276
  %t282 = add i64 %t274, %t279
  store i64 %t282, ptr %l24, !tbaa !24
  %t284 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 45
  %t285 = load i64, ptr %l24, !tbaa !24
  %t288 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t284, i64 %t285)
  store i64 %t288, ptr %l183
  br label %bb79
bb79:
  %t289 = load i64, ptr %l6, !tbaa !24
  %t290 = load i64, ptr %l183, !tbaa !24
  %t292 = icmp eq i64 %t290, %t289
  br i1 %t292, label %bb80, label %bb81
bb80:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l187, !tbaa !29
  %t295 = load ptr, ptr %l1, !tbaa !29
  store ptr %t295, ptr %l188, !tbaa !29
  %t296 = load ptr, ptr %l2, !tbaa !29
  store ptr %t296, ptr %l189, !tbaa !29
  %t297 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 46
  %t298 = load i64, ptr %l24, !tbaa !24
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t297, i64 %t298)
  store i64 %t301, ptr %l192
  br label %bb82
bb81:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb85
bb82:
  %t302 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 47
  %t303 = load i64, ptr %l24, !tbaa !24
  %t306 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t302, i64 %t303)
  store i64 %t306, ptr %l195
  br label %bb83
bb83:
  %t307 = load ptr, ptr %l187, !tbaa !29
  %t308 = load ptr, ptr %l188, !tbaa !29
  %t309 = load ptr, ptr %l189, !tbaa !29
  %t310 = load i64, ptr %l192, !tbaa !24
  %t311 = load i64, ptr %l195, !tbaa !24
  %t312 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t307, ptr %t308, ptr %t309, i64 %t310, i64 %t311, i1 false)
  store i1 %t312, ptr %l196
  br label %bb84
bb84:
  %t313 = load i1, ptr %l196, !tbaa !21
  %t314 = xor i1 %t313, true
  store i1 %t314, ptr %l186, !tbaa !21
  br label %bb85
bb85:
  %t316 = load i1, ptr %l186, !tbaa !21
  br i1 %t316, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t318 = load i64, ptr %l23, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l23, !tbaa !24
  br label %bb75
bb90:
  store i64 0, ptr %l25, !tbaa !24
  %t323 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 50
  %t325 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t323)
  store i64 %t325, ptr %l203
  br label %bb91
bb91:
  %t326 = load i64, ptr %l203, !tbaa !24
  store i64 %t326, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t327 = load i64, ptr %l26, !tbaa !24
  %t328 = load i64, ptr %l25, !tbaa !24
  %t331 = icmp sgt i64 %t327, %t328
  br i1 %t331, label %bb92, label %bb93
bb92:
  %t333 = load i64, ptr %l27, !tbaa !24
  %t335 = icmp sgt i64 %t333, 0
  br i1 %t335, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb97
bb94:
  %t337 = load i64, ptr %l26, !tbaa !24
  %t338 = load i64, ptr %l25, !tbaa !24
  %t341 = sub i64 %t337, %t338
  %t342 = load i64, ptr %l27, !tbaa !24
  %t345 = add i64 %t341, %t342
  %t347 = sub i64 %t345, 1
  %t348 = load i64, ptr %l27, !tbaa !24
  %t351 = sdiv i64 %t347, %t348
  store i64 %t351, ptr %l210, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb96
bb96:
  %t353 = load i64, ptr %l210, !tbaa !24
  store i64 %t353, ptr %l207, !tbaa !24
  br label %bb97
bb97:
  %t354 = load i64, ptr %l207, !tbaa !24
  store i64 %t354, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb98
bb98:
  %t355 = load i64, ptr %l29, !tbaa !24
  %t356 = load i64, ptr %l28, !tbaa !24
  %t359 = icmp slt i64 %t355, %t356
  %t361 = xor i1 %t359, true
  br i1 %t361, label %bb99, label %bb100
bb99:
  br label %bb116
bb100:
  br label %bb101
bb101:
  %t363 = load i64, ptr %l25, !tbaa !24
  %t364 = load i64, ptr %l29, !tbaa !24
  %t365 = load i64, ptr %l27, !tbaa !24
  %t368 = mul i64 %t364, %t365
  %t371 = add i64 %t363, %t368
  store i64 %t371, ptr %l30, !tbaa !24
  %t373 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 50
  %t374 = load i64, ptr %l30, !tbaa !24
  %t377 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t373, i64 %t374)
  store i64 %t377, ptr %l230
  br label %bb102
bb102:
  %t378 = load i64, ptr %l6, !tbaa !24
  %t379 = load i64, ptr %l230, !tbaa !24
  %t381 = icmp ne i64 %t379, %t378
  br i1 %t381, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l233, !tbaa !21
  br label %bb106
bb104:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t385 = load ptr, ptr %l2, !tbaa !29
  %t386 = load i64, ptr %l30, !tbaa !24
  %t392 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t383, ptr %t384, ptr %t385, ptr %l5, i64 %t386)
  store i64 %t392, ptr %l239
  br label %bb105
bb105:
  %t393 = load i64, ptr %l239, !tbaa !24
  %t394 = icmp eq i64 %t393, 0
  store i1 %t394, ptr %l233, !tbaa !21
  br label %bb106
bb106:
  %t396 = load i1, ptr %l233, !tbaa !21
  br i1 %t396, label %bb107, label %bb108
bb107:
  br label %bb115
bb108:
  br label %bb109
bb109:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l241, !tbaa !29
  %t398 = load ptr, ptr %l1, !tbaa !29
  store ptr %t398, ptr %l242, !tbaa !29
  %t399 = load ptr, ptr %l2, !tbaa !29
  store ptr %t399, ptr %l243, !tbaa !29
  store ptr %l5, ptr %l244, !tbaa !29
  %t400 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 49
  %t401 = load i64, ptr %l30, !tbaa !24
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t400, i64 %t401)
  store i64 %t404, ptr %l247
  br label %bb110
bb110:
  %t405 = load ptr, ptr %l241, !tbaa !29
  %t406 = load ptr, ptr %l242, !tbaa !29
  %t407 = load ptr, ptr %l243, !tbaa !29
  %t408 = load ptr, ptr %l244, !tbaa !29
  %t409 = load i64, ptr %l247, !tbaa !24
  %t410 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t405, ptr %t406, ptr %t407, ptr %t408, i64 %t409, i1 true, i64 0)
  store i1 %t410, ptr %l248
  br label %bb111
bb111:
  %t411 = load i1, ptr %l248, !tbaa !21
  br i1 %t411, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb113:
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t413 = load i64, ptr %l29, !tbaa !24
  %t416 = add i64 %t413, 1
  store i64 %t416, ptr %l29, !tbaa !24
  br label %bb98
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2estorageKeptIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:LocalUses"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/typed:LocalUses"
  %l47 = alloca i32
  %l51 = alloca i1
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l106 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l142 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i1
  %l153 = alloca i64
  %l157 = alloca i64
  %l160 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i1
  %l186 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l192 = alloca i64
  %l195 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca ptr
  %l200 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i1
  %l205 = alloca i1
  %l212 = alloca i64
  %l216 = alloca i64
  %l219 = alloca i64
  %l239 = alloca i64
  %l242 = alloca i1
  %l248 = alloca i64
  %l250 = alloca ptr
  %l251 = alloca ptr
  %l252 = alloca ptr
  %l253 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t22 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb4
bb2:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l35, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t11)
  store i64 %t13, ptr %l38
  br label %bb3
bb3:
  %t14 = load i64, ptr %l35, !tbaa !24
  %t15 = load i64, ptr %l38, !tbaa !24
  %t16 = icmp sge i64 %t14, %t15
  store i1 %t16, ptr %l34, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l34, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t22, ptr %v1, ptr %v3, ptr %s0, ptr %t20, ptr %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t22, i64 1640, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l43, i64 1640, i1 false)
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t27, i64 %t28)
  store i32 %t31, ptr %l47
  br label %bb9
bb9:
  %t32 = load i32, ptr %l47, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l6, !tbaa !24
  %t35 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 39
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l51
  br label %bb10
bb10:
  %t40 = load i1, ptr %l51, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l7, !tbaa !24
  %t42 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 27
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l54
  br label %bb14
bb14:
  %t45 = load i64, ptr %l54, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb20
bb17:
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l61, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l61, !tbaa !24
  store i64 %t72, ptr %l58, !tbaa !24
  br label %bb20
bb20:
  %t73 = load i64, ptr %l58, !tbaa !24
  store i64 %t73, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb40
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l12, !tbaa !24
  %t92 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 27
  %t93 = load i64, ptr %l12, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l81
  br label %bb25
bb25:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load i64, ptr %l81, !tbaa !24
  %t100 = icmp eq i64 %t98, %t97
  br i1 %t100, label %bb26, label %bb27
bb26:
  %t102 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 30
  %t103 = load i64, ptr %l12, !tbaa !24
  %t106 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t102, i64 %t103)
  store i1 %t106, ptr %l87
  br label %bb28
bb27:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb29
bb28:
  %t107 = load i1, ptr %l87, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l84, !tbaa !21
  br label %bb29
bb29:
  %t110 = load i1, ptr %l84, !tbaa !21
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l90, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l91, !tbaa !29
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l92, !tbaa !29
  %t114 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 28
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l95
  br label %bb32
bb31:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb35
bb32:
  %t119 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 29
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t119, i64 %t120)
  store i64 %t123, ptr %l98
  br label %bb33
bb33:
  %t124 = load ptr, ptr %l90, !tbaa !29
  %t125 = load ptr, ptr %l91, !tbaa !29
  %t126 = load ptr, ptr %l92, !tbaa !29
  %t127 = load i64, ptr %l95, !tbaa !24
  %t128 = load i64, ptr %l98, !tbaa !24
  %t129 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t124, ptr %t125, ptr %t126, i64 %t127, i64 %t128, i1 true)
  store i1 %t129, ptr %l99
  br label %bb34
bb34:
  %t130 = load i1, ptr %l99, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l89, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l89, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l11, !tbaa !24
  br label %bb21
bb40:
  store i64 0, ptr %l13, !tbaa !24
  %t140 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t140)
  store i64 %t142, ptr %l106
  br label %bb41
bb41:
  %t143 = load i64, ptr %l106, !tbaa !24
  store i64 %t143, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l14, !tbaa !24
  %t145 = load i64, ptr %l13, !tbaa !24
  %t148 = icmp sgt i64 %t144, %t145
  br i1 %t148, label %bb42, label %bb43
bb42:
  %t150 = load i64, ptr %l15, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb47
bb44:
  %t154 = load i64, ptr %l14, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l15, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l15, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l113, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb46
bb46:
  %t170 = load i64, ptr %l113, !tbaa !24
  store i64 %t170, ptr %l110, !tbaa !24
  br label %bb47
bb47:
  %t171 = load i64, ptr %l110, !tbaa !24
  store i64 %t171, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb48
bb48:
  %t172 = load i64, ptr %l17, !tbaa !24
  %t173 = load i64, ptr %l16, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb49, label %bb50
bb49:
  br label %bb63
bb50:
  br label %bb51
bb51:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t181 = load i64, ptr %l17, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  store i64 %t188, ptr %l18, !tbaa !24
  %t190 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 24
  %t191 = load i64, ptr %l18, !tbaa !24
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t190, i64 %t191)
  store i64 %t194, ptr %l133
  br label %bb52
bb52:
  %t195 = load i64, ptr %l6, !tbaa !24
  %t196 = load i64, ptr %l133, !tbaa !24
  %t198 = icmp eq i64 %t196, %t195
  br i1 %t198, label %bb53, label %bb54
bb53:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l137, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l138, !tbaa !29
  %t202 = load ptr, ptr %l2, !tbaa !29
  store ptr %t202, ptr %l139, !tbaa !29
  %t203 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 25
  %t204 = load i64, ptr %l18, !tbaa !24
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t203, i64 %t204)
  store i64 %t207, ptr %l142
  br label %bb55
bb54:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb58
bb55:
  %t208 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 26
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l145
  br label %bb56
bb56:
  %t213 = load ptr, ptr %l137, !tbaa !29
  %t214 = load ptr, ptr %l138, !tbaa !29
  %t215 = load ptr, ptr %l139, !tbaa !29
  %t216 = load i64, ptr %l142, !tbaa !24
  %t217 = load i64, ptr %l145, !tbaa !24
  %t218 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t213, ptr %t214, ptr %t215, i64 %t216, i64 %t217, i1 true)
  store i1 %t218, ptr %l146
  br label %bb57
bb57:
  %t219 = load i1, ptr %l146, !tbaa !21
  %t220 = xor i1 %t219, true
  store i1 %t220, ptr %l136, !tbaa !21
  br label %bb58
bb58:
  %t222 = load i1, ptr %l136, !tbaa !21
  br i1 %t222, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t224 = load i64, ptr %l17, !tbaa !24
  %t227 = add i64 %t224, 1
  store i64 %t227, ptr %l17, !tbaa !24
  br label %bb48
bb63:
  store i64 0, ptr %l19, !tbaa !24
  %t229 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 45
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t229)
  store i64 %t231, ptr %l153
  br label %bb64
bb64:
  %t232 = load i64, ptr %l153, !tbaa !24
  store i64 %t232, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t233 = load i64, ptr %l20, !tbaa !24
  %t234 = load i64, ptr %l19, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb65, label %bb66
bb65:
  %t239 = load i64, ptr %l21, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb70
bb67:
  %t243 = load i64, ptr %l20, !tbaa !24
  %t244 = load i64, ptr %l19, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l21, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l21, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l160, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb69
bb69:
  %t259 = load i64, ptr %l160, !tbaa !24
  store i64 %t259, ptr %l157, !tbaa !24
  br label %bb70
bb70:
  %t260 = load i64, ptr %l157, !tbaa !24
  store i64 %t260, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb71
bb71:
  %t261 = load i64, ptr %l23, !tbaa !24
  %t262 = load i64, ptr %l22, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb72, label %bb73
bb72:
  br label %bb93
bb73:
  br label %bb74
bb74:
  %t269 = load i64, ptr %l19, !tbaa !24
  %t270 = load i64, ptr %l23, !tbaa !24
  %t271 = load i64, ptr %l21, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l24, !tbaa !24
  %t279 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 45
  %t280 = load i64, ptr %l24, !tbaa !24
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t279, i64 %t280)
  store i64 %t283, ptr %l180
  br label %bb75
bb75:
  %t284 = load i64, ptr %l6, !tbaa !24
  %t285 = load i64, ptr %l180, !tbaa !24
  %t287 = icmp ne i64 %t285, %t284
  br i1 %t287, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb79
bb77:
  %t289 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 48
  %t290 = load i64, ptr %l24, !tbaa !24
  %t293 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t289, i64 %t290)
  store i1 %t293, ptr %l186
  br label %bb78
bb78:
  %t294 = load i1, ptr %l186, !tbaa !21
  store i1 %t294, ptr %l183, !tbaa !21
  br label %bb79
bb79:
  %t295 = load i1, ptr %l183, !tbaa !21
  br i1 %t295, label %bb80, label %bb81
bb80:
  br label %bb92
bb81:
  br label %bb82
bb82:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l187, !tbaa !29
  %t297 = load ptr, ptr %l1, !tbaa !29
  store ptr %t297, ptr %l188, !tbaa !29
  %t298 = load ptr, ptr %l2, !tbaa !29
  store ptr %t298, ptr %l189, !tbaa !29
  %t299 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 46
  %t300 = load i64, ptr %l24, !tbaa !24
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t299, i64 %t300)
  store i64 %t303, ptr %l192
  br label %bb83
bb83:
  %t304 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 47
  %t305 = load i64, ptr %l24, !tbaa !24
  %t308 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t304, i64 %t305)
  store i64 %t308, ptr %l195
  br label %bb84
bb84:
  %t309 = load ptr, ptr %l1, !tbaa !29
  store ptr %t309, ptr %l196, !tbaa !29
  %t310 = load ptr, ptr %l2, !tbaa !29
  store ptr %t310, ptr %l197, !tbaa !29
  %t311 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 46
  %t312 = load i64, ptr %l24, !tbaa !24
  %t315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t311, i64 %t312)
  store i64 %t315, ptr %l200
  br label %bb85
bb85:
  %t316 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 47
  %t317 = load i64, ptr %l24, !tbaa !24
  %t320 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t316, i64 %t317)
  store i64 %t320, ptr %l203
  br label %bb86
bb86:
  %t321 = load ptr, ptr %l196, !tbaa !29
  %t322 = load ptr, ptr %l197, !tbaa !29
  %t323 = load i64, ptr %l200, !tbaa !24
  %t324 = load i64, ptr %l203, !tbaa !24
  %t325 = call i1 @compiler_2ftyped_2erefParam(ptr %v1, ptr %v2, ptr %t321, ptr %t322, i64 %t323, i64 %t324)
  store i1 %t325, ptr %l204
  br label %bb87
bb87:
  %t326 = load ptr, ptr %l187, !tbaa !29
  %t327 = load ptr, ptr %l188, !tbaa !29
  %t328 = load ptr, ptr %l189, !tbaa !29
  %t329 = load i64, ptr %l192, !tbaa !24
  %t330 = load i64, ptr %l195, !tbaa !24
  %t331 = load i1, ptr %l204, !tbaa !21
  %t332 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t326, ptr %t327, ptr %t328, i64 %t329, i64 %t330, i1 %t331)
  store i1 %t332, ptr %l205
  br label %bb88
bb88:
  %t333 = load i1, ptr %l205, !tbaa !21
  %t334 = xor i1 %t333, true
  br i1 %t334, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t337 = load i64, ptr %l23, !tbaa !24
  %t340 = add i64 %t337, 1
  store i64 %t340, ptr %l23, !tbaa !24
  br label %bb71
bb93:
  store i64 0, ptr %l25, !tbaa !24
  %t342 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 50
  %t344 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t342)
  store i64 %t344, ptr %l212
  br label %bb94
bb94:
  %t345 = load i64, ptr %l212, !tbaa !24
  store i64 %t345, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t346 = load i64, ptr %l26, !tbaa !24
  %t347 = load i64, ptr %l25, !tbaa !24
  %t350 = icmp sgt i64 %t346, %t347
  br i1 %t350, label %bb95, label %bb96
bb95:
  %t352 = load i64, ptr %l27, !tbaa !24
  %t354 = icmp sgt i64 %t352, 0
  br i1 %t354, label %bb97, label %bb98
bb96:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb100
bb97:
  %t356 = load i64, ptr %l26, !tbaa !24
  %t357 = load i64, ptr %l25, !tbaa !24
  %t360 = sub i64 %t356, %t357
  %t361 = load i64, ptr %l27, !tbaa !24
  %t364 = add i64 %t360, %t361
  %t366 = sub i64 %t364, 1
  %t367 = load i64, ptr %l27, !tbaa !24
  %t370 = sdiv i64 %t366, %t367
  store i64 %t370, ptr %l219, !tbaa !24
  br label %bb99
bb98:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb99
bb99:
  %t372 = load i64, ptr %l219, !tbaa !24
  store i64 %t372, ptr %l216, !tbaa !24
  br label %bb100
bb100:
  %t373 = load i64, ptr %l216, !tbaa !24
  store i64 %t373, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb101
bb101:
  %t374 = load i64, ptr %l29, !tbaa !24
  %t375 = load i64, ptr %l28, !tbaa !24
  %t378 = icmp slt i64 %t374, %t375
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb102, label %bb103
bb102:
  br label %bb119
bb103:
  br label %bb104
bb104:
  %t382 = load i64, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l29, !tbaa !24
  %t384 = load i64, ptr %l27, !tbaa !24
  %t387 = mul i64 %t383, %t384
  %t390 = add i64 %t382, %t387
  store i64 %t390, ptr %l30, !tbaa !24
  %t392 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 50
  %t393 = load i64, ptr %l30, !tbaa !24
  %t396 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t392, i64 %t393)
  store i64 %t396, ptr %l239
  br label %bb105
bb105:
  %t397 = load i64, ptr %l6, !tbaa !24
  %t398 = load i64, ptr %l239, !tbaa !24
  %t400 = icmp ne i64 %t398, %t397
  br i1 %t400, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l242, !tbaa !21
  br label %bb109
bb107:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l1, !tbaa !29
  %t404 = load ptr, ptr %l2, !tbaa !29
  %t405 = load i64, ptr %l30, !tbaa !24
  %t411 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t402, ptr %t403, ptr %t404, ptr %l5, i64 %t405)
  store i64 %t411, ptr %l248
  br label %bb108
bb108:
  %t412 = load i64, ptr %l248, !tbaa !24
  %t413 = icmp slt i64 %t412, 2
  store i1 %t413, ptr %l242, !tbaa !21
  br label %bb109
bb109:
  %t415 = load i1, ptr %l242, !tbaa !21
  br i1 %t415, label %bb110, label %bb111
bb110:
  br label %bb118
bb111:
  br label %bb112
bb112:
  %t416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t416, ptr %l250, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  store ptr %t417, ptr %l251, !tbaa !29
  %t418 = load ptr, ptr %l2, !tbaa !29
  store ptr %t418, ptr %l252, !tbaa !29
  store ptr %l5, ptr %l253, !tbaa !29
  %t419 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 49
  %t420 = load i64, ptr %l30, !tbaa !24
  %t423 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t419, i64 %t420)
  store i64 %t423, ptr %l256
  br label %bb113
bb113:
  %t424 = load ptr, ptr %l250, !tbaa !29
  %t425 = load ptr, ptr %l251, !tbaa !29
  %t426 = load ptr, ptr %l252, !tbaa !29
  %t427 = load ptr, ptr %l253, !tbaa !29
  %t428 = load i64, ptr %l256, !tbaa !24
  %t429 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t424, ptr %t425, ptr %t426, ptr %t427, i64 %t428, i1 true, i64 0)
  store i1 %t429, ptr %l257
  br label %bb114
bb114:
  %t430 = load i1, ptr %l257, !tbaa !21
  br i1 %t430, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t432 = load i64, ptr %l29, !tbaa !24
  %t435 = add i64 %t432, 1
  store i64 %t435, ptr %l29, !tbaa !24
  br label %bb101
bb119:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l22 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l92 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t57, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Arm", ptr %t78, i32 0, i32 2
  %t81 = load ptr, ptr %t80, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t77, ptr %t81)
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Arm", ptr %t84, i32 0, i32 3
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Arm", ptr %t92, i32 0, i32 4
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %ret
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Versions", ptr %t98, i32 0, i32 16
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Arm", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_43c6edd5f3ea6aa2_25eece1f43523776)
  unreachable
bb21:
  br label %bb22
bb22:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Block", ptr %t111, i32 0, i32 0
  %t115 = load i32, ptr %t114, !tbaa !23
  %t116 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t116, i32 %t115)
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Arm", ptr %t118, i32 0, i32 3
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = icmp eq ptr %t121, null
  br i1 %t123, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8a2b699ea2f67509_3bce0390ecfabbdd)
  unreachable
bb25:
  br label %bb26
bb26:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Arm", ptr %t125, i32 0, i32 3
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Block", ptr %t128, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t146 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t146, ptr %l81, !tbaa !27
  %t147 = load i64, ptr %l11, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 %t147
  %t152 = load ptr, ptr %t151, !tbaa !39
  %t154 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t154, ptr %t152)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l11, !tbaa !24
  br label %bb27
bb33:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Arm", ptr %t164, i32 0, i32 4
  %t167 = load ptr, ptr %t166, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t163, ptr %t167)
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Versions", ptr %t170, i32 0, i32 16
  %t174 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t172)
  %t175 = extractvalue { i32, i32 } %t174, 1
  %t176 = extractvalue { i32, i32 } %t174, 0
  store i32 %t176, ptr %l96
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb36, label %ok.178, !prof !99
ok.178:
  store i32 %t175, ptr %l95
  br label %bb35
bb35:
  %t179 = load i32, ptr %l95, !tbaa !23
  store i32 %t179, ptr %l92, !tbaa !23
  br label %bb43
bb36:
  %t180 = load i32, ptr %l96, !tbaa !23
  %t181 = icmp eq i32 %t180, 65536
  br i1 %t181, label %bb37, label %bb38
bb37:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a872ad126d8d9744_e4960385d07a8740)
  unreachable
bb38:
  %t183 = load i32, ptr %l96, !tbaa !23
  %t184 = icmp eq i32 %t183, 65537
  br i1 %t184, label %bb39, label %bb40
bb39:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f34031efedf98c99_ae8fa248572091b5)
  unreachable
bb40:
  %t186 = load i32, ptr %l96, !tbaa !23
  %t187 = icmp eq i32 %t186, 65538
  br i1 %t187, label %bb41, label %bb42
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1baf36c5dd0b9bdd_a2c9e1d98e30c571)
  unreachable
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_49ff4d0dc0b12b63_5e68d9fa98bc7cb7)
  unreachable
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclassify(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i8
  %l91 = alloca { i64, ptr }
  %l94 = alloca i1
  %l100 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l20
  br label %bb2
bb2:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Versions", ptr %t9, i32 0, i32 11
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l23, !tbaa !24
  %t17 = sdiv i64 %t15, %t14
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb9
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l32, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l32, !tbaa !24
  store i64 %t45, ptr %l29, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l29, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l8, !tbaa !24
  %t65 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t65, ptr %l50
  br label %bb14
bb14:
  %t66 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t66, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l12, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t95 = load i64, ptr %l58, !tbaa !24
  store i64 %t95, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l55, !tbaa !24
  store i64 %t96, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t105 = load i64, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store ptr %l9, ptr %l76, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Versions", ptr %t115, i32 0, i32 11
  %t118 = load i64, ptr %l8, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t126 = add i64 %t122, %t113
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t117, i64 %t126)
  store i64 %t129, ptr %l84
  br label %bb25
bb25:
  %t130 = load i64, ptr %l84, !tbaa !24
  %t131 = icmp sgt i64 %t130, -2
  br i1 %t131, label %bb26, label %bb27
bb26:
  store i8 49, ptr %l86, !tbaa !22
  br label %bb28
bb27:
  store i8 48, ptr %l86, !tbaa !22
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l76, !tbaa !29
  %t134 = load i8, ptr %l86, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %t133, i8 %t134)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l14, !tbaa !24
  br label %bb21
bb31:
  %t141 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l9)
  store { i64, ptr } %t141, ptr %l91
  br label %bb32
bb32:
  %t142 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t142, ptr %l16, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t146 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H6a1e9f71e6394ce7f250c1dfd2eee93e(ptr %s0, ptr %l2, { i64, ptr } %t143)
  store i1 %t146, ptr %l94
  br label %bb33
bb33:
  %t147 = load i1, ptr %l94, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb34, label %bb35
bb34:
  %t150 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Versions", ptr %t151, i32 0, i32 13
  %t154 = load i64, ptr %t153, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H3f302293c6f4c07a80dfb5e30c1500bf(ptr %s0, ptr %l2, { i64, ptr } %t150, i64 %t154)
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l100, !tbaa !29
  %t159 = load ptr, ptr %l100, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Versions", ptr %t159, i32 0, i32 13
  %t161 = load i64, ptr %t160, !tbaa !24
  %t164 = add i64 %t161, 1
  %t166 = load ptr, ptr %l100, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Versions", ptr %t166, i32 0, i32 13
  store i64 %t164, ptr %t167, !tbaa !24
  br label %bb37
bb37:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Versions", ptr %t168, i32 0, i32 12
  store ptr %t170, ptr %l105, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t174 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H1914ebd8236b397314fec30d887725e8(ptr %s0, ptr %l2, { i64, ptr } %t171)
  %t175 = extractvalue { i32, i64 } %t174, 1
  %t176 = extractvalue { i32, i64 } %t174, 0
  store i32 %t176, ptr %l110
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb39, label %ok.178, !prof !99
ok.178:
  store i64 %t175, ptr %l109
  br label %bb38
bb38:
  %t179 = load i64, ptr %l109, !tbaa !24
  store i64 %t179, ptr %l106, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb41
bb41:
  %t180 = load ptr, ptr %l105, !tbaa !29
  %t181 = load i64, ptr %l106, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t180, i64 %t181)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t182 = load i64, ptr %l7, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l7, !tbaa !24
  br label %bb10
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i64
  %l31 = alloca i32
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca ptr
  %l76 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l16
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  store i1 %t9, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t10 = load i1, ptr %l14, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t11)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Versions", ptr %t13, i32 0, i32 3
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l20
  br label %bb9
bb9:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 17
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l23
  br label %bb10
bb10:
  %t24 = load i64, ptr %l23, !tbaa !24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb12, label %bb13
bb12:
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Versions", ptr %t33, i32 0, i32 17
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t35, i64 %t36)
  store i32 %t39, ptr %l31
  br label %bb15
bb15:
  %t41 = load i32, ptr %l31, !tbaa !23
  %t43 = icmp ne i32 %t41, %a2
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb47
bb17:
  br label %bb18
bb18:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, 1
  %t51 = mul i64 %t45, %t48
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb24
bb21:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l45, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t81 = load i64, ptr %l45, !tbaa !24
  store i64 %t81, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t82 = load i64, ptr %l42, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb41
bb27:
  br label %bb28
bb28:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l11, !tbaa !24
  %t101 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t103 = trunc i64 0 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Versions", ptr %t106, i32 0, i32 18
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = add i64 %t109, %t110
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l70, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Versions", ptr %t115, i32 0, i32 18
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t117, i64 %t122)
  store i64 %t125, ptr %l76
  br label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Versions", ptr %t126, i32 0, i32 19
  store ptr %t128, ptr %l83, !tbaa !29
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t129, %t130
  store i64 %t133, ptr %l86, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l87, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Versions", ptr %t135, i32 0, i32 19
  %t138 = load i64, ptr %l5, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t142)
  store i64 %t145, ptr %l93
  br label %bb35
bb31:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Versions", ptr %t146, i32 0, i32 14
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l80
  br label %bb32
bb32:
  %t153 = load ptr, ptr %l70, !tbaa !29
  %t154 = load i64, ptr %l76, !tbaa !24
  %t155 = load i64, ptr %l80, !tbaa !24
  %t156 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  store i64 %t156, ptr %l81
  br label %bb33
bb33:
  %t157 = load ptr, ptr %l66, !tbaa !29
  %t158 = load i64, ptr %l69, !tbaa !24
  %t159 = load i64, ptr %l81, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t157, i64 %t158, i64 %t159)
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Versions", ptr %t160, i32 0, i32 14
  %t163 = load i64, ptr %l11, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l97
  br label %bb36
bb36:
  %t167 = load ptr, ptr %l87, !tbaa !29
  %t168 = load i64, ptr %l93, !tbaa !24
  %t169 = load i64, ptr %l97, !tbaa !24
  %t170 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t167, i64 %t168, i64 %t169)
  store i64 %t170, ptr %l98
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l83, !tbaa !29
  %t172 = load i64, ptr %l86, !tbaa !24
  %t173 = load i64, ptr %l98, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172, i64 %t173)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l10, !tbaa !24
  br label %bb25
bb41:
  %t179 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t181 = trunc i64 0 to i32
  %t182 = icmp eq i32 %t179, %t181
  br i1 %t182, label %bb42, label %bb43
bb42:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Versions", ptr %t184, i32 0, i32 18
  %t187 = load i64, ptr %l5, !tbaa !24
  %t188 = load i64, ptr %l3, !tbaa !24
  %t191 = add i64 %t187, %t188
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t186, i64 %t191, i64 0)
  br label %bb44
bb43:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Versions", ptr %t194, i32 0, i32 19
  %t197 = load i64, ptr %l5, !tbaa !24
  %t198 = load i64, ptr %l3, !tbaa !24
  %t201 = add i64 %t197, %t198
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t201, i64 0)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb48
bb47:
  %t204 = load i64, ptr %l4, !tbaa !24
  %t207 = sub i64 %t204, 1
  store i64 %t207, ptr %l4, !tbaa !24
  br label %bb11
bb48:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t209)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l38 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca ptr
  %l74 = alloca i64
  %l76 = alloca ptr
  %l80 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l96 = alloca i64
  %l115 = alloca ptr
  %l121 = alloca i64
  %l125 = alloca i64
  %l132 = alloca ptr
  %l135 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l150 = alloca i32
  %l153 = alloca i32
  %l154 = alloca i32
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i32
  %l192 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v2, ptr %t11, ptr %t12)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v3, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l32
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 3
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l35
  br label %bb7
bb7:
  %t24 = load i64, ptr %l35, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Versions", ptr %t25, i32 0, i32 17
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l38
  br label %bb8
bb8:
  %t30 = load i64, ptr %l38, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 17
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Block", ptr %t34, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t33, i32 %t37)
  br label %bb9
bb9:
  store i64 0, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb15
bb12:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l51, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l51, !tbaa !24
  store i64 %t70, ptr %l48, !tbaa !24
  br label %bb15
bb15:
  %t71 = load i64, ptr %l48, !tbaa !24
  store i64 %t71, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb17, label %bb18
bb17:
  br label %bb29
bb18:
  br label %bb19
bb19:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l10, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Versions", ptr %t90, i32 0, i32 18
  store ptr %t92, ptr %l70, !tbaa !29
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l3, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb20, label %bb21
bb20:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb22
bb21:
  store i64 -2, ptr %l74, !tbaa !24
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l70, !tbaa !29
  %t100 = load i64, ptr %l74, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t99, i64 %t100)
  br label %bb23
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Versions", ptr %t101, i32 0, i32 19
  store ptr %t103, ptr %l76, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = icmp eq i64 %t104, %t105
  br i1 %t108, label %bb24, label %bb25
bb24:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb26
bb25:
  store i64 -2, ptr %l80, !tbaa !24
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l76, !tbaa !29
  %t111 = load i64, ptr %l80, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = add i64 %t112, 1
  store i64 %t115, ptr %l9, !tbaa !24
  br label %bb16
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v3, ptr %t117)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l85
  br label %bb30
bb30:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l11
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v3, ptr %t121, ptr %l11)
  br label %bb32
bb32:
  store i64 0, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l3, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l12, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t134 = load i64, ptr %l14, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb38
bb35:
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l96, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb37
bb37:
  %t154 = load i64, ptr %l96, !tbaa !24
  store i64 %t154, ptr %l93, !tbaa !24
  br label %bb38
bb38:
  %t155 = load i64, ptr %l93, !tbaa !24
  store i64 %t155, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  %t156 = load i64, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t164 = load i64, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l17, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Versions", ptr %t174, i32 0, i32 19
  store ptr %t176, ptr %l115, !tbaa !29
  %t177 = load i64, ptr %l4, !tbaa !24
  %t178 = load i64, ptr %l3, !tbaa !24
  %t180 = add i64 %t178, 1
  %t183 = mul i64 %t177, %t180
  %t184 = load i64, ptr %l17, !tbaa !24
  %t187 = add i64 %t183, %t184
  store i64 %t187, ptr %l121, !tbaa !24
  %t188 = load i64, ptr %l17, !tbaa !24
  %t189 = load i64, ptr %l3, !tbaa !24
  %t192 = icmp eq i64 %t188, %t189
  br i1 %t192, label %bb43, label %bb44
bb43:
  store i64 1, ptr %l125, !tbaa !24
  br label %bb45
bb44:
  store i64 -2, ptr %l125, !tbaa !24
  br label %bb45
bb45:
  %t194 = load ptr, ptr %l115, !tbaa !29
  %t195 = load i64, ptr %l121, !tbaa !24
  %t196 = load i64, ptr %l125, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195, i64 %t196)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t197 = load i64, ptr %l16, !tbaa !24
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %l16, !tbaa !24
  br label %bb39
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t202, ptr %t203)
  br label %bb49
bb49:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l132, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i64, ptr %l4, !tbaa !24
  %t212 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %s5, ptr %t208, i1 false, i64 %t209)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l135
  br label %bb50
bb50:
  %t213 = load ptr, ptr %l132, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s5, ptr %t213, ptr %l135)
  br label %bb51
bb51:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v2, ptr %t215, ptr %t216)
  br label %bb52
bb52:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Block", ptr %t220, i32 0, i32 0
  %t223 = load i32, ptr %t222, !tbaa !23
  %t227 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ewiden(ptr %v0, ptr %v3, ptr %t219, ptr %l11, i32 %t223)
  store i64 %t227, ptr %l143
  br label %bb53
bb53:
  %t228 = load i64, ptr %l143, !tbaa !24
  %t229 = icmp eq i64 %t228, 0
  br i1 %t229, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb57:
  br label %bb31
bb58:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l145, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l4, !tbaa !24
  %t236 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %s0, ptr %t232, i1 true, i64 %t233)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %l148
  br label %bb59
bb59:
  %t237 = load ptr, ptr %l145, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t237, ptr %l148)
  br label %bb60
bb60:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Versions", ptr %t239, i32 0, i32 17
  %t243 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t241)
  %t244 = extractvalue { i32, i32 } %t243, 1
  %t245 = extractvalue { i32, i32 } %t243, 0
  store i32 %t245, ptr %l154
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb62, label %ok.247, !prof !99
ok.247:
  store i32 %t244, ptr %l153
  br label %bb61
bb61:
  %t248 = load i32, ptr %l153, !tbaa !23
  store i32 %t248, ptr %l150, !tbaa !23
  br label %bb69
bb62:
  %t249 = load i32, ptr %l154, !tbaa !23
  %t250 = icmp eq i32 %t249, 65536
  br i1 %t250, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4b8ddca9d8f0d204_c8cf417eb9785a78)
  unreachable
bb64:
  %t252 = load i32, ptr %l154, !tbaa !23
  %t253 = icmp eq i32 %t252, 65537
  br i1 %t253, label %bb65, label %bb66
bb65:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f658218d2a233859_f81a26e56b3c591d)
  unreachable
bb66:
  %t255 = load i32, ptr %l154, !tbaa !23
  %t256 = icmp eq i32 %t255, 65538
  br i1 %t256, label %bb67, label %bb68
bb67:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4c95fac740fe18b9_da00c3dfb70c298d)
  unreachable
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1ae239f8e5f7a55f_790ae28d8c0cd633)
  unreachable
bb69:
  store i64 0, ptr %l18, !tbaa !24
  %t258 = load i64, ptr %l3, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t262 = load i64, ptr %l19, !tbaa !24
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = icmp sgt i64 %t262, %t263
  br i1 %t266, label %bb70, label %bb71
bb70:
  %t268 = load i64, ptr %l20, !tbaa !24
  %t270 = icmp sgt i64 %t268, 0
  br i1 %t270, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb75
bb72:
  %t272 = load i64, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l18, !tbaa !24
  %t276 = sub i64 %t272, %t273
  %t277 = load i64, ptr %l20, !tbaa !24
  %t280 = add i64 %t276, %t277
  %t282 = sub i64 %t280, 1
  %t283 = load i64, ptr %l20, !tbaa !24
  %t286 = sdiv i64 %t282, %t283
  store i64 %t286, ptr %l166, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb74
bb74:
  %t288 = load i64, ptr %l166, !tbaa !24
  store i64 %t288, ptr %l163, !tbaa !24
  br label %bb75
bb75:
  %t289 = load i64, ptr %l163, !tbaa !24
  store i64 %t289, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb76
bb76:
  %t290 = load i64, ptr %l22, !tbaa !24
  %t291 = load i64, ptr %l21, !tbaa !24
  %t294 = icmp slt i64 %t290, %t291
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb77, label %bb78
bb77:
  br label %bb99
bb78:
  br label %bb79
bb79:
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l22, !tbaa !24
  %t300 = load i64, ptr %l20, !tbaa !24
  %t303 = mul i64 %t299, %t300
  %t306 = add i64 %t298, %t303
  store i64 %t306, ptr %l23, !tbaa !24
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Versions", ptr %t308, i32 0, i32 18
  %t312 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t310)
  %t313 = extractvalue { i32, i64 } %t312, 1
  %t314 = extractvalue { i32, i64 } %t312, 0
  store i32 %t314, ptr %l188
  %t315 = icmp ne i32 %t314, 0
  br i1 %t315, label %bb81, label %ok.316, !prof !99
ok.316:
  store i64 %t313, ptr %l187
  br label %bb80
bb80:
  %t317 = load i64, ptr %l187, !tbaa !24
  store i64 %t317, ptr %l184, !tbaa !24
  br label %bb88
bb81:
  %t318 = load i32, ptr %l188, !tbaa !23
  %t319 = icmp eq i32 %t318, 65536
  br i1 %t319, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c0631815a77772a8_ad2a1d61fb1cdf14)
  unreachable
bb83:
  %t321 = load i32, ptr %l188, !tbaa !23
  %t322 = icmp eq i32 %t321, 65537
  br i1 %t322, label %bb84, label %bb85
bb84:
  call void @__olang_bang_failed_plain(ptr @olang_loc_bb3d6fb8f9a8facd_6b23a8aabab7ea69)
  unreachable
bb85:
  %t324 = load i32, ptr %l188, !tbaa !23
  %t325 = icmp eq i32 %t324, 65538
  br i1 %t325, label %bb86, label %bb87
bb86:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cb0f3499142fc19d_d94490f94af5f129)
  unreachable
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_730e5d3857c59e23_64c21f8ca2d9dbaf)
  unreachable
bb88:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Versions", ptr %t327, i32 0, i32 19
  %t331 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t329)
  %t332 = extractvalue { i32, i64 } %t331, 1
  %t333 = extractvalue { i32, i64 } %t331, 0
  store i32 %t333, ptr %l196
  %t334 = icmp ne i32 %t333, 0
  br i1 %t334, label %bb90, label %ok.335, !prof !99
ok.335:
  store i64 %t332, ptr %l195
  br label %bb89
bb89:
  %t336 = load i64, ptr %l195, !tbaa !24
  store i64 %t336, ptr %l192, !tbaa !24
  br label %bb97
bb90:
  %t337 = load i32, ptr %l196, !tbaa !23
  %t338 = icmp eq i32 %t337, 65536
  br i1 %t338, label %bb91, label %bb92
bb91:
  call void @__olang_bang_failed_plain(ptr @olang_loc_14162ea47c0c801c_ce4205068f01e790)
  unreachable
bb92:
  %t340 = load i32, ptr %l196, !tbaa !23
  %t341 = icmp eq i32 %t340, 65537
  br i1 %t341, label %bb93, label %bb94
bb93:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a93f600a1cb39be1_ee16d2dfcadba585)
  unreachable
bb94:
  %t343 = load i32, ptr %l196, !tbaa !23
  %t344 = icmp eq i32 %t343, 65538
  br i1 %t344, label %bb95, label %bb96
bb95:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f25a0dcb15ec66ae_41d78ed91c6395da)
  unreachable
bb96:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8726c5b979482c78_cdee9de0701e13e4)
  unreachable
bb97:
  br label %bb98
bb98:
  %t346 = load i64, ptr %l22, !tbaa !24
  %t349 = add i64 %t346, 1
  store i64 %t349, ptr %l22, !tbaa !24
  br label %bb76
bb99:
  %t351 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t351, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca ptr
  %l40 = alloca i64
  %l50 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l29
  br label %bb8
bb8:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l6
  %t39 = call ptr @__olang_scope_hold(ptr %s0)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l30, !tbaa !24
  %t41 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = call ptr @__olang_region_make(ptr %s0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l30, !tbaa !24
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l30
  %t47 = inttoptr i64 %t46 to ptr
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t47, ptr %t45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l33
  br label %bb11
bb11:
  %t50 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l30
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = call ptr @__olang_region_or(ptr %t56, ptr null)
  %t58 = call ptr @__olang_region_home(ptr %t57)
  %t59 = icmp ne ptr %t58, null
  %t60 = select i1 %t59, ptr %t58, ptr null
  call void @__olang_region_settle_in(ptr %t53, ptr %t60)
  br label %bb13
bb13:
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l7
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Versions", ptr %t62, i32 0, i32 20
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb14, label %bb15
bb14:
  store ptr %l7, ptr %l38, !tbaa !29
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t70, ptr %l40
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = sub i64 %t71, 1
  %t73 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %t73, i64 %t72, i64 1)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Match", ptr %t75, i32 0, i32 1
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t84 = load i64, ptr %l9, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb20, label %bb21
bb20:
  br label %bb36
bb21:
  br label %bb22
bb22:
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t92, ptr %l50, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l11, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t100, ptr %l6)
  br label %bb23
bb23:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb24
bb24:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t107, ptr %l7)
  br label %bb25
bb25:
  %t110 = call ptr @__olang_scope_hold(ptr %s0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l59, !tbaa !24
  %t112 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t112, label %bb26, label %bb27
bb26:
  %t114 = call ptr @__olang_region_make(ptr %s0)
  %t115 = ptrtoint ptr %t114 to i64
  store i64 %t115, ptr %l59, !tbaa !24
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l59
  %t118 = inttoptr i64 %t117 to ptr
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t118, ptr %t116)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l62
  br label %bb28
bb28:
  %t121 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t123 = load i64, ptr %l59
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = call ptr @__olang_region_or(ptr %t127, ptr null)
  %t129 = call ptr @__olang_region_home(ptr %t128)
  %t130 = icmp ne ptr %t129, null
  %t131 = select i1 %t130, ptr %t129, ptr null
  call void @__olang_region_settle_in(ptr %t124, ptr %t131)
  br label %bb30
bb30:
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l64
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l7
  %t134 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t134, label %bb31, label %bb32
bb31:
  %t136 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = call ptr @__olang_region_or(ptr %t138, ptr null)
  %t140 = call ptr @__olang_region_home(ptr %t139)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr null
  call void @__olang_region_drop(ptr %t142)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l64
  br label %bb32
bb32:
  %t143 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t143, label %bb33, label %bb34
bb33:
  %t145 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  call void @__olang_region_release_part(ptr %t148, i64 %t147)
  store { i64, ptr } zeroinitializer, ptr %t145
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = add i64 %t149, 1
  store i64 %t152, ptr %l9, !tbaa !24
  br label %bb19
bb36:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Match", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb37, label %bb38
bb37:
  %t163 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t163, ptr %l6)
  br label %bb39
bb38:
  br label %bb54
bb39:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l76, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Match", ptr %t167, i32 0, i32 2
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = icmp eq ptr %t170, null
  br i1 %t172, label %bb40, label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_456f0c0b74db68d5_29242d1724c8a7c1)
  unreachable
bb41:
  br label %bb42
bb42:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Match", ptr %t174, i32 0, i32 2
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %t178, ptr %t177)
  br label %bb43
bb43:
  %t180 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t180, ptr %l7)
  br label %bb44
bb44:
  %t183 = call ptr @__olang_scope_hold(ptr %s0)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l84, !tbaa !24
  %t185 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t185, label %bb45, label %bb46
bb45:
  %t187 = call ptr @__olang_region_make(ptr %s0)
  %t188 = ptrtoint ptr %t187 to i64
  store i64 %t188, ptr %l84, !tbaa !24
  br label %bb46
bb46:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l84
  %t191 = inttoptr i64 %t190 to ptr
  %t193 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t191, ptr %t189)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l87
  br label %bb47
bb47:
  %t194 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t194, label %bb48, label %bb49
bb48:
  %t196 = load i64, ptr %l84
  %t197 = inttoptr i64 %t196 to ptr
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = call ptr @__olang_region_or(ptr %t200, ptr null)
  %t202 = call ptr @__olang_region_home(ptr %t201)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr null
  call void @__olang_region_settle_in(ptr %t197, ptr %t204)
  br label %bb49
bb49:
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l89
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l7
  %t207 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t207, label %bb50, label %bb51
bb50:
  %t209 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = call ptr @__olang_region_or(ptr %t211, ptr null)
  %t213 = call ptr @__olang_region_home(ptr %t212)
  %t214 = icmp ne ptr %t213, null
  %t215 = select i1 %t214, ptr %t213, ptr null
  call void @__olang_region_drop(ptr %t215)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l89
  br label %bb51
bb51:
  %t216 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t216, label %bb52, label %bb53
bb52:
  %t218 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89, i32 0, i32 0
  %t219 = load { i64, ptr }, ptr %t218
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %t218
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t222, ptr %l7)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erow(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca i64
  %l51 = alloca i64
  %l59 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = add i64 %t6, 1
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l10, !tbaa !24
  store ptr %l4, ptr %l41, !tbaa !29
  br i1 %a1, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Versions", ptr %t61, i32 0, i32 18
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t72)
  store i64 %t75, ptr %l51
  br label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Versions", ptr %t76, i32 0, i32 19
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t87)
  store i64 %t90, ptr %l59
  br label %bb16
bb15:
  %t91 = load i64, ptr %l51, !tbaa !24
  store i64 %t91, ptr %l43, !tbaa !24
  br label %bb17
bb16:
  %t92 = load i64, ptr %l59, !tbaa !24
  store i64 %t92, ptr %l43, !tbaa !24
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l41, !tbaa !29
  %t94 = load i64, ptr %l43, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t93, i64 %t94)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ewiden(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i1, ptr %l13, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Versions", ptr %t6, i32 0, i32 3
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l17
  br label %bb5
bb5:
  %t11 = load i64, ptr %l17, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l20
  br label %bb6
bb6:
  %t17 = load i64, ptr %l20, !tbaa !24
  %t18 = icmp ne i64 %t17, 0
  br i1 %t18, label %bb7, label %bb8
bb7:
  store i64 1, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v1, ptr %t21, i64 %t22, i64 0)
  br label %bb10
bb10:
  store i64 0, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb16
bb13:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l32, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t53 = load i64, ptr %l32, !tbaa !24
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb16
bb16:
  %t54 = load i64, ptr %l29, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb18, label %bb19
bb18:
  br label %bb35
bb19:
  br label %bb20
bb20:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l10, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Versions", ptr %t73, i32 0, i32 14
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l53
  br label %bb21
bb21:
  %t80 = load i64, ptr %l53, !tbaa !24
  %t81 = icmp eq i64 %t80, -2
  br i1 %t81, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  br label %bb24
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l55, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l58
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l59, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Versions", ptr %t90, i32 0, i32 14
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l63
  br label %bb26
bb26:
  %t99 = sext i32 %a2 to i64
  %t100 = load ptr, ptr %l59, !tbaa !29
  %t101 = load i64, ptr %l63, !tbaa !24
  %t103 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t100, i64 %t101, i64 %t99)
  store i64 %t103, ptr %l66
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l55, !tbaa !29
  %t105 = load i64, ptr %l58, !tbaa !24
  %t106 = load i64, ptr %l66, !tbaa !24
  %t107 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t104, i64 %t105, i64 %t106)
  store i64 %t107, ptr %l67
  br label %bb28
bb28:
  %t108 = load i64, ptr %l67, !tbaa !24
  store i64 %t108, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  store i64 %t109, ptr %l68, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t110, i64 %t111)
  store i64 %t114, ptr %l71
  br label %bb29
bb29:
  %t115 = load i64, ptr %l68, !tbaa !24
  %t116 = load i64, ptr %l71, !tbaa !24
  %t117 = icmp ne i64 %t115, %t116
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l4, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v1, ptr %t124, i64 %t125, i64 %t126)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l9, !tbaa !24
  br label %bb17
bb35:
  %t135 = load i64, ptr %l4, !tbaa !24
  store i64 %t135, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eSettle(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l55 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l97 = alloca ptr
  %l101 = alloca ptr
  %l103 = alloca i64
  %l110 = alloca i1
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t9 = extractvalue { i64, [2 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 1
  store i1 %t10, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:ViewWalk", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  store ptr %t17, ptr %l24, !tbaa !29
  %t18 = load ptr, ptr %l24, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v3, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l24, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %t23, ptr %t24)
  store i64 %t25, ptr %l26
  br label %bb1
bb1:
  %t26 = load i64, ptr %l26, !tbaa !24
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb2, label %bb3
bb2:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb4:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l33, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb6
bb6:
  %t53 = load i64, ptr %l33, !tbaa !24
  store i64 %t53, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l30, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb9, label %bb10
bb9:
  br label %bb45
bb10:
  br label %bb11
bb11:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l10, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i1, ptr %l4, !tbaa !21
  %t81 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t73, ptr %t74, i64 %t75, i1 %t76)
  store i1 %t81, ptr %l55
  br label %bb12
bb12:
  %t82 = load i1, ptr %l55, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb13, label %bb14
bb13:
  br label %bb44
bb14:
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l57, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:LocalUses", ptr %t86, i32 0, i32 20
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t88, i64 %t89)
  store ptr %t92, ptr %l61
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l57, !tbaa !29
  %t94 = load ptr, ptr %l61, !tbaa !29
  %t95 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v4, ptr %v3, ptr %t93, ptr %t94)
  store i64 %t95, ptr %l62
  br label %bb17
bb17:
  %t96 = load i64, ptr %l62, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:LocalUses", ptr %t97, i32 0, i32 22
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t99)
  store i64 %t101, ptr %l65
  br label %bb18
bb18:
  %t102 = load i64, ptr %l65, !tbaa !24
  store i64 %t102, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr %l12, !tbaa !24
  %t107 = icmp sgt i64 %t103, %t104
  br i1 %t107, label %bb19, label %bb20
bb19:
  %t109 = load i64, ptr %l14, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb24
bb21:
  %t113 = load i64, ptr %l13, !tbaa !24
  %t114 = load i64, ptr %l12, !tbaa !24
  %t117 = sub i64 %t113, %t114
  %t118 = load i64, ptr %l14, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t123 = sub i64 %t121, 1
  %t124 = load i64, ptr %l14, !tbaa !24
  %t127 = sdiv i64 %t123, %t124
  store i64 %t127, ptr %l72, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb23
bb23:
  %t129 = load i64, ptr %l72, !tbaa !24
  store i64 %t129, ptr %l69, !tbaa !24
  br label %bb24
bb24:
  %t130 = load i64, ptr %l69, !tbaa !24
  store i64 %t130, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb25
bb25:
  %t131 = load i64, ptr %l16, !tbaa !24
  %t132 = load i64, ptr %l15, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb26, label %bb27
bb26:
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t139 = load i64, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l16, !tbaa !24
  %t141 = load i64, ptr %l14, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  store i64 %t147, ptr %l17, !tbaa !24
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr %"compiler/typed:LocalUses", ptr %t149, i32 0, i32 22
  %t152 = load i64, ptr %l17, !tbaa !24
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t151, i64 %t152)
  store i64 %t155, ptr %l93
  br label %bb29
bb29:
  %t156 = load i64, ptr %l10, !tbaa !24
  %t157 = load i64, ptr %l93, !tbaa !24
  %t159 = icmp eq i64 %t157, %t156
  br i1 %t159, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load i64, ptr %l11, !tbaa !24
  store i64 %t161, ptr %l96, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l97, !tbaa !29
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr %"compiler/typed:LocalUses", ptr %t163, i32 0, i32 23
  %t166 = load i64, ptr %l17, !tbaa !24
  %t169 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %s6, ptr %t165, i64 %t166)
  store ptr %t169, ptr %l101
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t170 = load ptr, ptr %l101, !tbaa !29
  %t171 = load ptr, ptr %l97, !tbaa !29
  %t173 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %s6, ptr %v4, ptr %v3, ptr %t171, ptr %t170)
  store i64 %t173, ptr %l103
  br label %bb33
bb33:
  %t174 = load i64, ptr %l96, !tbaa !24
  %t175 = load i64, ptr %l103, !tbaa !24
  %t176 = or i64 %t174, %t175
  store i64 %t176, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t178 = load i64, ptr %l16, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l16, !tbaa !24
  br label %bb25
bb36:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t185 = icmp sgt i64 %t183, 0
  br i1 %t185, label %bb37, label %bb38
bb37:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t191 = and i64 %t187, %a2
  %t192 = load i64, ptr %l11, !tbaa !24
  %t195 = icmp eq i64 %t191, %t192
  store i1 %t195, ptr %l110, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb39
bb39:
  %t197 = load i1, ptr %l110, !tbaa !21
  br i1 %t197, label %bb40, label %bb41
bb40:
  %t199 = load i64, ptr %l10, !tbaa !24
  %t200 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %a3, i64 %t199, i64 %t200)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t204 = load i64, ptr %l9, !tbaa !24
  %t207 = add i64 %t204, 1
  store i64 %t207, ptr %l9, !tbaa !24
  br label %bb8
bb45:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l25 = alloca i1
  %l29 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l92 = alloca i64
  %l102 = alloca i1
  %l110 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca i64
  %l116 = alloca ptr
  %l119 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l17, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l17, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t16 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t13, ptr %t14, i64 %t7)
  store %"compiler/typed:Local" %t16, ptr %l20
  br label %bb1
bb1:
  %t17 = load %"compiler/typed:Local", ptr %l20
  store %"compiler/typed:Local" %t17, ptr %l4
  %t18 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 7}
  store i32 %t19, ptr %l5
  %t21 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t30 = trunc i64 3 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l25, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb4
bb4:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t36 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t38 = trunc i64 6 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  store i1 %t41, ptr %l29, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t43 = load i1, ptr %l29, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:ViewWalk", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l35, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l35, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v3, ptr %t51)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t54 to ptr
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t56, ptr %t57, i32 %t50)
  store i1 %t59, ptr %l38
  br label %bb11
bb11:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb15
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:ViewWalk", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l41, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t66 = load i32, ptr %t65, !tbaa !23
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = call ptr @__olang_scope_or(ptr %v3, ptr %t67)
  %t69 = call ptr @__olang_scope_hold(ptr %t68)
  %t70 = ptrtoint ptr %t69 to i64
  %t72 = inttoptr i64 %t70 to ptr
  %t73 = load ptr, ptr %l41, !tbaa !29
  %t75 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t72, ptr %t73, i32 %t66)
  store i1 %t75, ptr %l44
  br label %bb14
bb14:
  %t76 = load i1, ptr %l44, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t79 = load i1, ptr %l39, !tbaa !21
  br i1 %t79, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 7
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l50
  br label %bb19
bb19:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t91, i64 %t92)
  store i1 %t95, ptr %l55
  br label %bb22
bb22:
  %t96 = load i1, ptr %l55, !tbaa !21
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb27
bb25:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t98, i32 0, i32 4
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t100, i64 %t101)
  store i1 %t104, ptr %l60
  br label %bb26
bb26:
  %t105 = load i1, ptr %l60, !tbaa !21
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i64 0, ptr %l6, !tbaa !24
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/typed:LocalUses", ptr %t108, i32 0, i32 24
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t110)
  store i64 %t112, ptr %l64
  br label %bb31
bb31:
  %t113 = load i64, ptr %l64, !tbaa !24
  store i64 %t113, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb37
bb34:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load i64, ptr %l6, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l71, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb36
bb36:
  %t140 = load i64, ptr %l71, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  br label %bb37
bb37:
  %t141 = load i64, ptr %l68, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb38
bb38:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t150 = load i64, ptr %l6, !tbaa !24
  %t151 = load i64, ptr %l10, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/typed:LocalUses", ptr %t160, i32 0, i32 24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t162, i64 %t158)
  store i64 %t166, ptr %l92
  br label %bb42
bb42:
  %t167 = load i64, ptr %l2, !tbaa !24
  %t168 = load i64, ptr %l92, !tbaa !24
  %t170 = icmp eq i64 %t168, %t167
  br i1 %t170, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t173 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t173, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb38
bb47:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/typed:LocalUses", ptr %t178, i32 0, i32 18
  %t181 = load i64, ptr %l2, !tbaa !24
  %t184 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t180, i64 %t181)
  store i1 %t184, ptr %l102
  br label %bb48
bb48:
  %t185 = load i1, ptr %l102, !tbaa !21
  br i1 %t185, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t189 = xor i1 %a3, true
  br i1 %t189, label %bb52, label %bb53
bb52:
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/typed:ViewWalk", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Body", ptr %t195, i32 0, i32 10
  store ptr %t197, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb55
bb55:
  %t199 = load i64, ptr %l13, !tbaa !24
  store i64 %t199, ptr %l110, !tbaa !24
  %t200 = load ptr, ptr %l12, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l111, !tbaa !29
  %t202 = call ptr @__olang_scope_or(ptr %v2, ptr %t201)
  %t203 = call ptr @__olang_scope_hold(ptr %t202)
  %t204 = ptrtoint ptr %t203 to i64
  %t206 = inttoptr i64 %t204 to ptr
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t206, ptr %t207)
  store i64 %t208, ptr %l113
  br label %bb56
bb56:
  %t209 = load i64, ptr %l110, !tbaa !24
  %t210 = load i64, ptr %l113, !tbaa !24
  %t211 = icmp slt i64 %t209, %t210
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb57, label %bb58
bb57:
  br label %bb65
bb58:
  br label %bb59
bb59:
  %t215 = load ptr, ptr %l12, !tbaa !29
  store ptr %t215, ptr %l116, !tbaa !29
  %t216 = load i64, ptr %l13, !tbaa !24
  %t217 = load ptr, ptr %l116, !tbaa !29
  %t218 = call ptr @__olang_scope_or(ptr %v2, ptr %t217)
  %t219 = call ptr @__olang_scope_hold(ptr %t218)
  %t220 = ptrtoint ptr %t219 to i64
  %t222 = inttoptr i64 %t220 to ptr
  %t223 = load ptr, ptr %l116, !tbaa !29
  %t225 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t222, ptr %t223, i64 %t216)
  store i32 %t225, ptr %l119
  br label %bb60
bb60:
  %t226 = load i32, ptr %l119, !tbaa !23
  %t229 = sext i32 %t226 to i64
  %t230 = load i64, ptr %l2, !tbaa !24
  %t233 = icmp eq i64 %t229, %t230
  br i1 %t233, label %bb61, label %bb62
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t236 = load i64, ptr %l13, !tbaa !24
  %t239 = add i64 %t236, 1
  store i64 %t239, ptr %l13, !tbaa !24
  br label %bb55
bb65:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l80 = alloca { i64, ptr }
  %l88 = alloca i64
  %l91 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l142 = alloca i32
  %l145 = alloca i32
  %l146 = alloca i32
  %l150 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i32
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca i1
  %l187 = alloca i1
  %l188 = alloca i32
  %l192 = alloca i1
  %l195 = alloca i1
  %l196 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i64, ptr %l26, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i64, ptr %l29, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 7
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Block", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t15, i32 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:dropWalk", ptr %t22, i32 0, i32 8
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:dropWalk", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t24, i64 %t28)
  br label %bb4
bb4:
  store i64 0, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t35, %t36
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb10
bb7:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = add i64 %t49, %t50
  %t55 = sub i64 %t53, 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sdiv i64 %t55, %t56
  store i64 %t59, ptr %l46, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l43, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = mul i64 %t72, %t73
  %t79 = add i64 %t71, %t76
  store i64 %t79, ptr %l10, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:dropWalk", ptr %t81, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t83, i1 false)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t87, i1 false)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t89, 1
  store i64 %t92, ptr %l9, !tbaa !24
  br label %bb11
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:dropWalk", ptr %t94, i32 0, i32 9
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t98, 1
  %t103 = mul i64 %t97, %t100
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = add i64 %t103, %t104
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t96, i64 %t107, i1 true)
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t110)
  store { i64, ptr } %t112, ptr %l80
  br label %bb20
bb20:
  %t113 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t113, ptr %l11, !tbaa !27
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t114, { i64, ptr } %t115)
  br label %bb22
bb22:
  store i64 0, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l3, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb23, label %bb24
bb23:
  %t128 = load i64, ptr %l14, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb28
bb25:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l91, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb27
bb27:
  %t148 = load i64, ptr %l91, !tbaa !24
  store i64 %t148, ptr %l88, !tbaa !24
  br label %bb28
bb28:
  %t149 = load i64, ptr %l88, !tbaa !24
  store i64 %t149, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  %t150 = load i64, ptr %l16, !tbaa !24
  %t151 = load i64, ptr %l15, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l16, !tbaa !24
  %t160 = load i64, ptr %l14, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l17, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/typed:dropWalk", ptr %t168, i32 0, i32 10
  %t171 = load i64, ptr %l4, !tbaa !24
  %t172 = load i64, ptr %l3, !tbaa !24
  %t174 = add i64 %t172, 1
  %t177 = mul i64 %t171, %t174
  %t178 = load i64, ptr %l17, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load i64, ptr %l3, !tbaa !24
  %t186 = icmp eq i64 %t182, %t183
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t170, i64 %t181, i1 %t186)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t190 = load i64, ptr %l16, !tbaa !24
  %t193 = add i64 %t190, 1
  store i64 %t193, ptr %l16, !tbaa !24
  br label %bb29
bb35:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t195, ptr %t196)
  br label %bb36
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l126, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l4, !tbaa !24
  %t205 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %s4, ptr %t201, i1 false, i64 %t202)
  store { i64, ptr } %t205, ptr %l129
  br label %bb37
bb37:
  %t206 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t207 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s4, ptr %t207, { i64, ptr } %t206)
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v2, ptr %t209, ptr %a2)
  br label %bb39
bb39:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t217 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %s0, ptr %t213, { i64, ptr } %t214)
  store i64 %t217, ptr %l135
  br label %bb40
bb40:
  %t218 = load i64, ptr %l135, !tbaa !24
  %t219 = icmp eq i64 %t218, 0
  br i1 %t219, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %bb21
bb45:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l137, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i64, ptr %l4, !tbaa !24
  %t226 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %s0, ptr %t222, i1 true, i64 %t223)
  store { i64, ptr } %t226, ptr %l140
  br label %bb46
bb46:
  %t227 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t228 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t228, { i64, ptr } %t227)
  br label %bb47
bb47:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/typed:dropWalk", ptr %t230, i32 0, i32 7
  %t234 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t232)
  %t235 = extractvalue { i32, i32 } %t234, 1
  %t236 = extractvalue { i32, i32 } %t234, 0
  store i32 %t236, ptr %l146
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb49, label %ok.238, !prof !99
ok.238:
  store i32 %t235, ptr %l145
  br label %bb48
bb48:
  %t239 = load i32, ptr %l145, !tbaa !23
  store i32 %t239, ptr %l142, !tbaa !23
  br label %bb56
bb49:
  %t240 = load i32, ptr %l146, !tbaa !23
  %t241 = icmp eq i32 %t240, 65536
  br i1 %t241, label %bb50, label %bb51
bb50:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1a9a85648681e97_fcf9d2fab7c32a6b)
  unreachable
bb51:
  %t243 = load i32, ptr %l146, !tbaa !23
  %t244 = icmp eq i32 %t243, 65537
  br i1 %t244, label %bb52, label %bb53
bb52:
  call void @__olang_bang_failed_plain(ptr @olang_loc_54fd08b205476dc4_657f8db756d05b08)
  unreachable
bb53:
  %t246 = load i32, ptr %l146, !tbaa !23
  %t247 = icmp eq i32 %t246, 65538
  br i1 %t247, label %bb54, label %bb55
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_923c0e7922172d2c_3d5b7ddd1cd85e60)
  unreachable
bb55:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3398753e62525e0a_a26aec7fb7dfed8e)
  unreachable
bb56:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/typed:dropWalk", ptr %t249, i32 0, i32 8
  %t253 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t251)
  %t254 = extractvalue { i32, i64 } %t253, 1
  %t255 = extractvalue { i32, i64 } %t253, 0
  store i32 %t255, ptr %l154
  %t256 = icmp ne i32 %t255, 0
  br i1 %t256, label %bb58, label %ok.257, !prof !99
ok.257:
  store i64 %t254, ptr %l153
  br label %bb57
bb57:
  %t258 = load i64, ptr %l153, !tbaa !24
  store i64 %t258, ptr %l150, !tbaa !24
  br label %bb65
bb58:
  %t259 = load i32, ptr %l154, !tbaa !23
  %t260 = icmp eq i32 %t259, 65536
  br i1 %t260, label %bb59, label %bb60
bb59:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8b9fe86f9939495b_ac6312ba480f0d67)
  unreachable
bb60:
  %t262 = load i32, ptr %l154, !tbaa !23
  %t263 = icmp eq i32 %t262, 65537
  br i1 %t263, label %bb61, label %bb62
bb61:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3f464ddbb91b0a38_82918aeeacdcc614)
  unreachable
bb62:
  %t265 = load i32, ptr %l154, !tbaa !23
  %t266 = icmp eq i32 %t265, 65538
  br i1 %t266, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_29167372d5c184b0_5aaac5f2b3f16f1c)
  unreachable
bb64:
  call void @__olang_bang_failed_plain(ptr @olang_loc_18d2a0b724f39c7e_37ab118f04dce49a)
  unreachable
bb65:
  store i64 0, ptr %l18, !tbaa !24
  %t268 = load i64, ptr %l3, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t272 = load i64, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l18, !tbaa !24
  %t276 = icmp sgt i64 %t272, %t273
  br i1 %t276, label %bb66, label %bb67
bb66:
  %t278 = load i64, ptr %l20, !tbaa !24
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb71
bb68:
  %t282 = load i64, ptr %l19, !tbaa !24
  %t283 = load i64, ptr %l18, !tbaa !24
  %t286 = sub i64 %t282, %t283
  %t287 = load i64, ptr %l20, !tbaa !24
  %t290 = add i64 %t286, %t287
  %t292 = sub i64 %t290, 1
  %t293 = load i64, ptr %l20, !tbaa !24
  %t296 = sdiv i64 %t292, %t293
  store i64 %t296, ptr %l166, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb70
bb70:
  %t298 = load i64, ptr %l166, !tbaa !24
  store i64 %t298, ptr %l163, !tbaa !24
  br label %bb71
bb71:
  %t299 = load i64, ptr %l163, !tbaa !24
  store i64 %t299, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb72
bb72:
  %t300 = load i64, ptr %l22, !tbaa !24
  %t301 = load i64, ptr %l21, !tbaa !24
  %t304 = icmp slt i64 %t300, %t301
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb73, label %bb74
bb73:
  br label %bb95
bb74:
  br label %bb75
bb75:
  %t308 = load i64, ptr %l18, !tbaa !24
  %t309 = load i64, ptr %l22, !tbaa !24
  %t310 = load i64, ptr %l20, !tbaa !24
  %t313 = mul i64 %t309, %t310
  %t316 = add i64 %t308, %t313
  store i64 %t316, ptr %l23, !tbaa !24
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/typed:dropWalk", ptr %t318, i32 0, i32 9
  %t322 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t320)
  %t323 = extractvalue { i32, i1 } %t322, 1
  %t324 = extractvalue { i32, i1 } %t322, 0
  store i32 %t324, ptr %l188
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb77, label %ok.326, !prof !99
ok.326:
  store i1 %t323, ptr %l187
  br label %bb76
bb76:
  %t327 = load i1, ptr %l187, !tbaa !21
  store i1 %t327, ptr %l184, !tbaa !21
  br label %bb84
bb77:
  %t328 = load i32, ptr %l188, !tbaa !23
  %t329 = icmp eq i32 %t328, 65536
  br i1 %t329, label %bb78, label %bb79
bb78:
  call void @__olang_bang_failed_plain(ptr @olang_loc_fb0720d2dfee7f_1f99818eb62f02f3)
  unreachable
bb79:
  %t331 = load i32, ptr %l188, !tbaa !23
  %t332 = icmp eq i32 %t331, 65537
  br i1 %t332, label %bb80, label %bb81
bb80:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3cd7aa482e25463c_a46dd5e6d10de4a0)
  unreachable
bb81:
  %t334 = load i32, ptr %l188, !tbaa !23
  %t335 = icmp eq i32 %t334, 65538
  br i1 %t335, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_65fecb72da6e9be9_e6833fce5f1f4ea5)
  unreachable
bb83:
  call void @__olang_bang_failed_plain(ptr @olang_loc_313fe9555679a06f_fa589a226c49c6eb)
  unreachable
bb84:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/typed:dropWalk", ptr %t337, i32 0, i32 10
  %t341 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t339)
  %t342 = extractvalue { i32, i1 } %t341, 1
  %t343 = extractvalue { i32, i1 } %t341, 0
  store i32 %t343, ptr %l196
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb86, label %ok.345, !prof !99
ok.345:
  store i1 %t342, ptr %l195
  br label %bb85
bb85:
  %t346 = load i1, ptr %l195, !tbaa !21
  store i1 %t346, ptr %l192, !tbaa !21
  br label %bb93
bb86:
  %t347 = load i32, ptr %l196, !tbaa !23
  %t348 = icmp eq i32 %t347, 65536
  br i1 %t348, label %bb87, label %bb88
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f3df993f4c7e1fd4_8419908bae6ac650)
  unreachable
bb88:
  %t350 = load i32, ptr %l196, !tbaa !23
  %t351 = icmp eq i32 %t350, 65537
  br i1 %t351, label %bb89, label %bb90
bb89:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e306d5ccad957c29_6b95b0de26f94a45)
  unreachable
bb90:
  %t353 = load i32, ptr %l196, !tbaa !23
  %t354 = icmp eq i32 %t353, 65538
  br i1 %t354, label %bb91, label %bb92
bb91:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d73b6870bbe51a4d_d845c63f23993221)
  unreachable
bb92:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2545ce011bc2e3f3_a4cac8bc0a2d8747)
  unreachable
bb93:
  br label %bb94
bb94:
  %t356 = load i64, ptr %l22, !tbaa !24
  %t359 = add i64 %t356, 1
  store i64 %t359, ptr %l22, !tbaa !24
  br label %bb72
bb95:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l48 = alloca i1
  %l54 = alloca i1
  %l60 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l10, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:dropWalk", ptr %t2, i32 0, i32 2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = add i64 %t7, 1
  %t9 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t9, %t8
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 2
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = add i64 %t18, 1
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l9, !tbaa !24
  br i1 %a1, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82)
  store i1 %t85, ptr %l54
  br label %bb15
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:dropWalk", ptr %t86, i32 0, i32 10
  %t89 = load i64, ptr %l3, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t96 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t93)
  store i1 %t96, ptr %l60
  br label %bb16
bb15:
  %t97 = load i1, ptr %l54, !tbaa !21
  store i1 %t97, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l48, !tbaa !21
  %t100 = load i64, ptr %l37, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t99, ptr %t103, !tbaa !31
  %t104 = load i64, ptr %l37, !tbaa !24
  %t105 = add i64 %t104, 1
  store i64 %t105, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t111 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i64
  %l83 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l112 = alloca i64
  %l121 = alloca i1
  %l125 = alloca i1
  %l128 = alloca i1
  %l129 = alloca i32
  %l133 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i32
  %l146 = alloca i64
  %l149 = alloca i64
  %l167 = alloca i1
  %l170 = alloca i1
  %l171 = alloca i32
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 11
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l34
  br label %bb2
bb2:
  %t12 = load i64, ptr %l34, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 11
  store ptr %t15, ptr %l36, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 4
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  %t26 = xor i1 %t24, true
  store i1 %t26, ptr %l39, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = load i1, ptr %l39, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t28, i1 %t29)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 12
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:dropWalk", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t32, i64 %t36)
  br label %bb7
bb7:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb13
bb10:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l54, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l54, !tbaa !24
  store i64 %t67, ptr %l51, !tbaa !24
  br label %bb13
bb13:
  %t68 = load i64, ptr %l51, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:dropWalk", ptr %t87, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t89, i1 false)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb14
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:dropWalk", ptr %t96, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t98, i1 true)
  br label %bb21
bb21:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Try", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t100, ptr %t104)
  br label %bb22
bb22:
  %t107 = load i64, ptr %l2, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l83, !tbaa !24
  %t110 = load i64, ptr %l83, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb23, label %bb24
bb23:
  %t113 = load i64, ptr %l83, !tbaa !24
  %t114 = mul i64 %t113, 1
  %t115 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l2, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp sgt i64 %t123, %t124
  br i1 %t127, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2cf1608fd5d1230c_1374e48cd144e348)
  unreachable
bb25:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb30
bb27:
  %t133 = load i64, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = sub i64 %t133, %t134
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = add i64 %t137, %t138
  %t143 = sub i64 %t141, 1
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = sdiv i64 %t143, %t144
  store i64 %t147, ptr %l94, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb29
bb29:
  %t149 = load i64, ptr %l94, !tbaa !24
  store i64 %t149, ptr %l91, !tbaa !24
  br label %bb30
bb30:
  %t150 = load i64, ptr %l91, !tbaa !24
  store i64 %t150, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t152 = load i64, ptr %l14, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t159 = load i64, ptr %l11, !tbaa !24
  %t160 = load i64, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = mul i64 %t160, %t161
  %t167 = add i64 %t159, %t164
  store i64 %t167, ptr %l16, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  store i64 %t169, ptr %l112, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/typed:dropWalk", ptr %t170, i32 0, i32 13
  %t173 = load i64, ptr %l3, !tbaa !24
  %t174 = load i64, ptr %l2, !tbaa !24
  %t176 = add i64 %t174, 1
  %t179 = mul i64 %t173, %t176
  %t180 = load i64, ptr %l16, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t186 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t172, i64 %t183)
  store i1 %t186, ptr %l121
  br label %bb35
bb35:
  %t187 = load i1, ptr %l121, !tbaa !21
  %t188 = load i64, ptr %l112, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i1, ptr %t190, i64 %t188
  store i1 %t187, ptr %t191, !tbaa !31
  br label %bb36
bb36:
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l15, !tbaa !24
  br label %bb31
bb37:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/typed:dropWalk", ptr %t197, i32 0, i32 11
  %t201 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t199)
  %t202 = extractvalue { i32, i1 } %t201, 1
  %t203 = extractvalue { i32, i1 } %t201, 0
  store i32 %t203, ptr %l129
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb39, label %ok.205, !prof !99
ok.205:
  store i1 %t202, ptr %l128
  br label %bb38
bb38:
  %t206 = load i1, ptr %l128, !tbaa !21
  store i1 %t206, ptr %l125, !tbaa !21
  br label %bb46
bb39:
  %t207 = load i32, ptr %l129, !tbaa !23
  %t208 = icmp eq i32 %t207, 65536
  br i1 %t208, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_73be6a0e490978a7_b5fa18d3e7eede33)
  unreachable
bb41:
  %t210 = load i32, ptr %l129, !tbaa !23
  %t211 = icmp eq i32 %t210, 65537
  br i1 %t211, label %bb42, label %bb43
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2fb6091d652311b2_1c71a9a414fce87e)
  unreachable
bb43:
  %t213 = load i32, ptr %l129, !tbaa !23
  %t214 = icmp eq i32 %t213, 65538
  br i1 %t214, label %bb44, label %bb45
bb44:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8c1b8241682c8a5c_1491e83e9da6f28)
  unreachable
bb45:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fc9df9522ae1330_697d53c50db00ce4)
  unreachable
bb46:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/typed:dropWalk", ptr %t216, i32 0, i32 12
  %t220 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t218)
  %t221 = extractvalue { i32, i64 } %t220, 1
  %t222 = extractvalue { i32, i64 } %t220, 0
  store i32 %t222, ptr %l137
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb48, label %ok.224, !prof !99
ok.224:
  store i64 %t221, ptr %l136
  br label %bb47
bb47:
  %t225 = load i64, ptr %l136, !tbaa !24
  store i64 %t225, ptr %l133, !tbaa !24
  br label %bb55
bb48:
  %t226 = load i32, ptr %l137, !tbaa !23
  %t227 = icmp eq i32 %t226, 65536
  br i1 %t227, label %bb49, label %bb50
bb49:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e4195c8d52320dab_6e5abcaf8844f88f)
  unreachable
bb50:
  %t229 = load i32, ptr %l137, !tbaa !23
  %t230 = icmp eq i32 %t229, 65537
  br i1 %t230, label %bb51, label %bb52
bb51:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6df7d27e20fc18e6_9af88db0bee394aa)
  unreachable
bb52:
  %t232 = load i32, ptr %l137, !tbaa !23
  %t233 = icmp eq i32 %t232, 65538
  br i1 %t233, label %bb53, label %bb54
bb53:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c52364142dc414a0_4d1da6470710a144)
  unreachable
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730)
  unreachable
bb55:
  store i64 0, ptr %l17, !tbaa !24
  %t235 = load i64, ptr %l2, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t239 = load i64, ptr %l18, !tbaa !24
  %t240 = load i64, ptr %l17, !tbaa !24
  %t243 = icmp sgt i64 %t239, %t240
  br i1 %t243, label %bb56, label %bb57
bb56:
  %t245 = load i64, ptr %l19, !tbaa !24
  %t247 = icmp sgt i64 %t245, 0
  br i1 %t247, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb61
bb58:
  %t249 = load i64, ptr %l18, !tbaa !24
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = sub i64 %t249, %t250
  %t254 = load i64, ptr %l19, !tbaa !24
  %t257 = add i64 %t253, %t254
  %t259 = sub i64 %t257, 1
  %t260 = load i64, ptr %l19, !tbaa !24
  %t263 = sdiv i64 %t259, %t260
  store i64 %t263, ptr %l149, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb60
bb60:
  %t265 = load i64, ptr %l149, !tbaa !24
  store i64 %t265, ptr %l146, !tbaa !24
  br label %bb61
bb61:
  %t266 = load i64, ptr %l146, !tbaa !24
  store i64 %t266, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb62
bb62:
  %t267 = load i64, ptr %l21, !tbaa !24
  %t268 = load i64, ptr %l20, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb63, label %bb64
bb63:
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t275 = load i64, ptr %l17, !tbaa !24
  %t276 = load i64, ptr %l21, !tbaa !24
  %t277 = load i64, ptr %l19, !tbaa !24
  %t280 = mul i64 %t276, %t277
  %t283 = add i64 %t275, %t280
  store i64 %t283, ptr %l22, !tbaa !24
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/typed:dropWalk", ptr %t285, i32 0, i32 13
  %t289 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t287)
  %t290 = extractvalue { i32, i1 } %t289, 1
  %t291 = extractvalue { i32, i1 } %t289, 0
  store i32 %t291, ptr %l171
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb67, label %ok.293, !prof !99
ok.293:
  store i1 %t290, ptr %l170
  br label %bb66
bb66:
  %t294 = load i1, ptr %l170, !tbaa !21
  store i1 %t294, ptr %l167, !tbaa !21
  br label %bb74
bb67:
  %t295 = load i32, ptr %l171, !tbaa !23
  %t296 = icmp eq i32 %t295, 65536
  br i1 %t296, label %bb68, label %bb69
bb68:
  call void @__olang_bang_failed_plain(ptr @olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab)
  unreachable
bb69:
  %t298 = load i32, ptr %l171, !tbaa !23
  %t299 = icmp eq i32 %t298, 65537
  br i1 %t299, label %bb70, label %bb71
bb70:
  call void @__olang_bang_failed_plain(ptr @olang_loc_cdd2e50680d68485_7d51e204495f7309)
  unreachable
bb71:
  %t301 = load i32, ptr %l171, !tbaa !23
  %t302 = icmp eq i32 %t301, 65538
  br i1 %t302, label %bb72, label %bb73
bb72:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2ee7063c57fe9793_68bf97cc73752027)
  unreachable
bb73:
  call void @__olang_bang_failed_plain(ptr @olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f)
  unreachable
bb74:
  br label %bb75
bb75:
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = add i64 %t304, 1
  store i64 %t307, ptr %l21, !tbaa !24
  br label %bb62
bb76:
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Try", ptr %t309, i32 0, i32 1
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t316 = icmp eq i64 %t314, 0
  br i1 %t316, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb78:
  br label %bb79
bb79:
  %t318 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t318, ptr %l182, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  store i64 %t320, ptr %l183, !tbaa !24
  %t321 = load i64, ptr %l183, !tbaa !24
  %t322 = mul i64 %t321, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l184, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = load i64, ptr %l183, !tbaa !24
  %t331 = mul i64 %t330, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t327, ptr %t329, i64 %t331, i1 false)
  %t332 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t332, ptr %l23, !tbaa !27
  %t333 = load ptr, ptr %l1, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Try", ptr %t333, i32 0, i32 1
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l26, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t342 = load i64, ptr %l25, !tbaa !24
  %t343 = load i64, ptr %l26, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t350 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t350, ptr %l193, !tbaa !27
  %t351 = load i64, ptr %l25, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  store ptr %t356, ptr %l27, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t358)
  store { i64, ptr } %t360, ptr %l197
  br label %bb84
bb84:
  %t361 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t361, ptr %l28, !tbaa !27
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t362, { i64, ptr } %t363)
  br label %bb85
bb85:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l27, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Clause", ptr %t367, i32 0, i32 3
  %t370 = load ptr, ptr %t369, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t366, ptr %t370)
  br label %bb86
bb86:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load ptr, ptr %l27, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Clause", ptr %t374, i32 0, i32 4
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t373, { i64, ptr } %t377)
  br label %bb87
bb87:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t380, { i64, ptr } %t381)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t384 = load i64, ptr %l25, !tbaa !24
  %t387 = add i64 %t384, 1
  store i64 %t387, ptr %l25, !tbaa !24
  br label %bb80
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca i1
  %l70 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:dropWalk", ptr %t8, i32 0, i32 2
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb4
bb4:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i1, ptr %t15, i64 %t13
  %t17 = load i1, ptr %t16, !tbaa !31
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l17, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t19 = load i64, ptr %l17, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l18, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:dropWalk", ptr %t21, i32 0, i32 2
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l21
  br label %bb8
bb8:
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i1, ptr %t28, i64 %t26
  store i1 false, ptr %t29, !tbaa !31
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 2
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb15
bb12:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l31, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l31, !tbaa !24
  store i64 %t62, ptr %l28, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l28, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb32
bb18:
  br label %bb19
bb19:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:dropWalk", ptr %t82, i32 0, i32 2
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t88, ptr %l52
  br label %bb20
bb20:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t90, ptr %l54, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t91
  %t96 = load i1, ptr %t95, !tbaa !31
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l2, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %l61, !tbaa !27
  %t107 = load i64, ptr %l8, !tbaa !24
  store i64 %t107, ptr %l62, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t108, ptr %l63, !tbaa !27
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i1, ptr %t112, i64 %t109
  %t114 = load i1, ptr %t113, !tbaa !31
  br i1 %t114, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/typed:dropWalk", ptr %t116, i32 0, i32 2
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t118, i64 %t119)
  store i1 %t122, ptr %l70
  br label %bb29
bb29:
  %t123 = load i1, ptr %l70, !tbaa !21
  store i1 %t123, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t124 = load i1, ptr %l66, !tbaa !21
  %t125 = load i64, ptr %l62, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i1, ptr %t127, i64 %t125
  store i1 %t124, ptr %t128, !tbaa !31
  br label %bb31
bb31:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb16
bb32:
  %t134 = load i64, ptr %l2, !tbaa !24
  store i64 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l39 = alloca { i64, ptr }
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca i1
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l20
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Call", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  store ptr %t10, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t11 = load ptr, ptr %l23, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l23, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l24, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { ptr }, ptr %t21, i32 0, i32 0
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l5, !tbaa !29
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %v1, ptr %l3, ptr %t25)
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2676a1f2cfb255f8_2530c83c98e00394)
  unreachable
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t45, ptr %l39, !tbaa !27
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %v1, ptr %l3, ptr %t51)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t56, 1
  store i64 %t59, ptr %l7, !tbaa !24
  br label %bb15
bb21:
  store ptr %l3, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t62 = load i64, ptr %l11, !tbaa !24
  store i64 %t62, ptr %l48, !tbaa !24
  %t63 = load ptr, ptr %l10, !tbaa !29
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %t63)
  store i64 %t65, ptr %l50
  br label %bb23
bb23:
  %t66 = load i64, ptr %l48, !tbaa !24
  %t67 = load i64, ptr %l50, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t72 = load ptr, ptr %l10, !tbaa !29
  %t73 = load i64, ptr %l11, !tbaa !24
  %t76 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l55
  br label %bb27
bb27:
  %t77 = load ptr, ptr %l55, !tbaa !29
  store ptr %l2, ptr %l56, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %s0, ptr %v0, ptr %v3, ptr %v4, ptr %t78, ptr %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l60
  br label %bb28
bb28:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  %t85 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t85
  %t86 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t86, ptr %t85)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l11, !tbaa !24
  br label %bb22
bb31:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l65, !tbaa !29
  %t95 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t95, ptr %l67
  br label %bb32
bb32:
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l67, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t96, { i64, ptr } %t97)
  br label %bb33
bb33:
  store i64 0, ptr %l13, !tbaa !24
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %l3)
  store i64 %t99, ptr %l69
  br label %bb34
bb34:
  %t100 = load i64, ptr %l69, !tbaa !24
  store i64 %t100, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t107 = load i64, ptr %l15, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb40
bb37:
  %t111 = load i64, ptr %l14, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l15, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l15, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l76, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb39
bb39:
  %t127 = load i64, ptr %l76, !tbaa !24
  store i64 %t127, ptr %l73, !tbaa !24
  br label %bb40
bb40:
  %t128 = load i64, ptr %l73, !tbaa !24
  store i64 %t128, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t129 = load i64, ptr %l17, !tbaa !24
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb43:
  br label %bb44
bb44:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l17, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l18, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l94, !tbaa !29
  %t148 = load i64, ptr %l18, !tbaa !24
  %t151 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s10, ptr %l3, i64 %t148)
  store ptr %t151, ptr %l97
  br label %bb45
bb45:
  %t152 = load ptr, ptr %l97, !tbaa !29
  %t153 = load ptr, ptr %l94, !tbaa !29
  %t155 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %s10, ptr %v3, ptr %t153, ptr %t152)
  store i1 %t155, ptr %l99
  br label %bb46
bb46:
  %t156 = load i1, ptr %l99, !tbaa !21
  br i1 %t156, label %bb47, label %bb48
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:holdWalk", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  store ptr %t160, ptr %l102, !tbaa !29
  %t161 = load i64, ptr %l18, !tbaa !24
  %t164 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t161)
  store ptr %t164, ptr %l105
  br label %bb49
bb48:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb52
bb49:
  %t165 = load ptr, ptr %l105, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %s0, ptr %t165)
  store i32 %t166, ptr %l106
  br label %bb50
bb50:
  %t167 = load ptr, ptr %l102, !tbaa !29
  %t168 = call ptr @__olang_scope_or(ptr %v3, ptr %t167)
  %t169 = call ptr @__olang_scope_hold(ptr %t168)
  %t170 = ptrtoint ptr %t169 to i64
  %t172 = inttoptr i64 %t170 to ptr
  %t173 = load ptr, ptr %l102, !tbaa !29
  %t174 = load i32, ptr %l106, !tbaa !23
  %t175 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %t172, ptr %t173, i32 %t174, i1 false)
  store i1 %t175, ptr %l108
  br label %bb51
bb51:
  %t176 = load i1, ptr %l108, !tbaa !21
  store i1 %t176, ptr %l100, !tbaa !21
  br label %bb52
bb52:
  %t177 = load i1, ptr %l100, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t178, i64 %t179, ptr %l3)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t183 = load i64, ptr %l17, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l17, !tbaa !24
  br label %bb41
bb58:
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t37, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_10efe43793a641ac_2dabf1c43cd6a168)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l140 = alloca i1
  %l141 = alloca i1
  %l146 = alloca i1
  %l147 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l163 = alloca i1
  %l164 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %l199 = alloca i1
  %l200 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i1
  %l211 = alloca ptr
  %l217 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l227 = alloca i1
  %l231 = alloca i1
  %l235 = alloca i1
  %l238 = alloca i1
  %l241 = alloca i1
  %l243 = alloca i1
  %l246 = alloca i1
  %l249 = alloca i1
  %l253 = alloca i1
  %l254 = alloca i1
  %l258 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i1
  %l268 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l278 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb198
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t34 = load ptr, ptr %l32, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l33, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l44, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t71 = load i1, ptr %l45, !tbaa !21
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t82 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t78, ptr %t79)
  store i1 %t82, ptr %l52
  br label %bb31
bb31:
  %t83 = load i1, ptr %l52, !tbaa !21
  store i1 %t83, ptr %l19, !tbaa !21
  br label %bb198
bb32:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t85 = load ptr, ptr %l53, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb33, label %bb34
bb33:
  %t88 = load ptr, ptr %l53, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 5
  store i1 %t91, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t92 = load i1, ptr %l54, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb35:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t107 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  store i1 %t107, ptr %l63
  br label %bb38
bb38:
  %t108 = load i1, ptr %l63, !tbaa !21
  store i1 %t108, ptr %l19, !tbaa !21
  br label %bb198
bb39:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb40, label %bb41
bb40:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 18}
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t117 = load i1, ptr %l65, !tbaa !21
  br i1 %t117, label %bb42, label %bb43
bb42:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 1
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l4, !tbaa !23
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb59
bb44:
  %t130 = load i32, ptr %l4, !tbaa !23
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t134 = icmp eq i32 %t130, %t131
  br i1 %t134, label %bb45, label %bb46
bb45:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:leaveWalk", ptr %t136, i32 0, i32 2
  %t139 = load i1, ptr %t138, !tbaa !21
  br i1 %t139, label %bb47, label %bb48
bb46:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb50
bb47:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb49
bb48:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/typed:leaveWalk", ptr %t141, i32 0, i32 1
  %t144 = load i1, ptr %t143, !tbaa !21
  %t146 = xor i1 %t144, true
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l78, !tbaa !21
  store i1 %t148, ptr %l75, !tbaa !21
  br label %bb50
bb50:
  %t149 = load i1, ptr %l75, !tbaa !21
  br i1 %t149, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb54
bb52:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %t150, ptr %t154)
  store i1 %t157, ptr %l86
  br label %bb53
bb53:
  %t158 = load i1, ptr %l86, !tbaa !21
  store i1 %t158, ptr %l82, !tbaa !21
  br label %bb54
bb54:
  %t159 = load i1, ptr %l82, !tbaa !21
  br i1 %t159, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb58
bb56:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Call", ptr %t161, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t167 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t160, { i64, ptr } %t164)
  store i1 %t167, ptr %l91
  br label %bb57
bb57:
  %t168 = load i1, ptr %l91, !tbaa !21
  store i1 %t168, ptr %l87, !tbaa !21
  br label %bb58
bb58:
  %t169 = load i1, ptr %l87, !tbaa !21
  store i1 %t169, ptr %l19, !tbaa !21
  br label %bb198
bb59:
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t171 = load ptr, ptr %l92, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb60, label %bb61
bb60:
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 7
  store i1 %t177, ptr %l93, !tbaa !21
  br label %bb61
bb61:
  %t178 = load i1, ptr %l93, !tbaa !21
  br i1 %t178, label %bb62, label %bb63
bb62:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l6, !tbaa !29
  br label %bb64
bb63:
  br label %bb70
bb64:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Make", ptr %t186, i32 0, i32 2
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t192 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t185, { i64, ptr } %t189)
  store i1 %t192, ptr %l101
  br label %bb65
bb65:
  %t193 = load i1, ptr %l101, !tbaa !21
  br i1 %t193, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb69
bb67:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l6, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Make", ptr %t195, i32 0, i32 3
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t201 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t194, ptr %t198)
  store i1 %t201, ptr %l106
  br label %bb68
bb68:
  %t202 = load i1, ptr %l106, !tbaa !21
  store i1 %t202, ptr %l102, !tbaa !21
  br label %bb69
bb69:
  %t203 = load i1, ptr %l102, !tbaa !21
  store i1 %t203, ptr %l19, !tbaa !21
  br label %bb198
bb70:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t205 = load ptr, ptr %l107, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb71, label %bb72
bb71:
  %t208 = load ptr, ptr %l107, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 18}
  %t211 = icmp eq i64 %t209, 8
  store i1 %t211, ptr %l108, !tbaa !21
  br label %bb72
bb72:
  %t212 = load i1, ptr %l108, !tbaa !21
  br i1 %t212, label %bb73, label %bb74
bb73:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t215, i32 0, i32 2
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l7, !tbaa !29
  br label %bb75
bb74:
  br label %bb81
bb75:
  store %olang.scope zeroinitializer, ptr %s7
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l7, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Collect", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t226 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t219, ptr %t223)
  store i1 %t226, ptr %l116
  br label %bb76
bb76:
  %t227 = load i1, ptr %l116, !tbaa !21
  br i1 %t227, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb80
bb78:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l7, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Collect", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t235 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %s7, ptr %t228, ptr %t232, ptr null)
  store i1 %t235, ptr %l121
  br label %bb79
bb79:
  %t236 = load i1, ptr %l121, !tbaa !21
  store i1 %t236, ptr %l117, !tbaa !21
  br label %bb80
bb80:
  %t237 = load i1, ptr %l117, !tbaa !21
  store i1 %t237, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb198
bb81:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t239 = load ptr, ptr %l122, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb82, label %bb83
bb82:
  %t242 = load ptr, ptr %l122, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 18}
  %t245 = icmp eq i64 %t243, 9
  store i1 %t245, ptr %l123, !tbaa !21
  br label %bb83
bb83:
  %t246 = load i1, ptr %l123, !tbaa !21
  br i1 %t246, label %bb84, label %bb85
bb84:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t249, i32 0, i32 4
  %t251 = load { i64, ptr }, ptr %t250
  store { i64, ptr } %t251, ptr %l8, !tbaa !27
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t257 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t253, { i64, ptr } %t254)
  store i1 %t257, ptr %l130
  br label %bb87
bb87:
  %t258 = load i1, ptr %l130, !tbaa !21
  store i1 %t258, ptr %l19, !tbaa !21
  br label %bb198
bb88:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t260 = load ptr, ptr %l131, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb89, label %bb90
bb89:
  %t263 = load ptr, ptr %l131, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 10
  store i1 %t266, ptr %l132, !tbaa !21
  br label %bb90
bb90:
  %t267 = load i1, ptr %l132, !tbaa !21
  br i1 %t267, label %bb91, label %bb92
bb91:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t270, i32 0, i32 2
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l9, !tbaa !29
  br label %bb93
bb92:
  br label %bb103
bb93:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l9, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Slice", ptr %t275, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t281 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t274, ptr %t278)
  store i1 %t281, ptr %l140
  br label %bb94
bb94:
  %t282 = load i1, ptr %l140, !tbaa !21
  br i1 %t282, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb98
bb96:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l9, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Slice", ptr %t284, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t291 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t283, ptr %t287)
  store i1 %t291, ptr %l146
  br label %bb97
bb97:
  %t292 = load i1, ptr %l146, !tbaa !21
  store i1 %t292, ptr %l141, !tbaa !21
  br label %bb98
bb98:
  %t293 = load i1, ptr %l141, !tbaa !21
  br i1 %t293, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb102
bb100:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l9, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Slice", ptr %t295, i32 0, i32 2
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t302 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t294, ptr %t298)
  store i1 %t302, ptr %l152
  br label %bb101
bb101:
  %t303 = load i1, ptr %l152, !tbaa !21
  store i1 %t303, ptr %l147, !tbaa !21
  br label %bb102
bb102:
  %t304 = load i1, ptr %l147, !tbaa !21
  store i1 %t304, ptr %l19, !tbaa !21
  br label %bb198
bb103:
  %t305 = load ptr, ptr %l1, !tbaa !29
  store ptr %t305, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = icmp ne ptr %t306, null
  br i1 %t307, label %bb104, label %bb105
bb104:
  %t309 = load ptr, ptr %l153, !tbaa !29
  %t310 = load i64, ptr %t309, !range !{i64 0, i64 18}
  %t312 = icmp eq i64 %t310, 11
  store i1 %t312, ptr %l154, !tbaa !21
  br label %bb105
bb105:
  %t313 = load i1, ptr %l154, !tbaa !21
  br i1 %t313, label %bb106, label %bb107
bb106:
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t316, i32 0, i32 2
  %t318 = load ptr, ptr %t317
  store ptr %t318, ptr %l10, !tbaa !29
  br label %bb108
bb107:
  br label %bb118
bb108:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l10, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Cond", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t328 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t320, ptr %t324)
  store i1 %t328, ptr %l163
  br label %bb109
bb109:
  %t329 = load i1, ptr %l163, !tbaa !21
  br i1 %t329, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb113
bb111:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l10, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Cond", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t337 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t330, ptr %t334)
  store i1 %t337, ptr %l168
  br label %bb112
bb112:
  %t338 = load i1, ptr %l168, !tbaa !21
  store i1 %t338, ptr %l164, !tbaa !21
  br label %bb113
bb113:
  %t339 = load i1, ptr %l164, !tbaa !21
  br i1 %t339, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb117
bb115:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l10, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Cond", ptr %t341, i32 0, i32 2
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t348 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t340, ptr %t344)
  store i1 %t348, ptr %l174
  br label %bb116
bb116:
  %t349 = load i1, ptr %l174, !tbaa !21
  store i1 %t349, ptr %l169, !tbaa !21
  br label %bb117
bb117:
  %t350 = load i1, ptr %l169, !tbaa !21
  store i1 %t350, ptr %l19, !tbaa !21
  br label %bb198
bb118:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t352 = load ptr, ptr %l175, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb119, label %bb120
bb119:
  %t355 = load ptr, ptr %l175, !tbaa !29
  %t356 = load i64, ptr %t355, !range !{i64 0, i64 18}
  %t358 = icmp eq i64 %t356, 12
  store i1 %t358, ptr %l176, !tbaa !21
  br label %bb120
bb120:
  %t359 = load i1, ptr %l176, !tbaa !21
  br i1 %t359, label %bb121, label %bb122
bb121:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t362, i32 0, i32 2
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l11, !tbaa !29
  br label %bb123
bb122:
  br label %bb129
bb123:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l11, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Seq", ptr %t367, i32 0, i32 0
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  %t373 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t366, { i64, ptr } %t370)
  store i1 %t373, ptr %l184
  br label %bb124
bb124:
  %t374 = load i1, ptr %l184, !tbaa !21
  br i1 %t374, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb128
bb126:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l11, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Seq", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t382 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t375, ptr %t379)
  store i1 %t382, ptr %l189
  br label %bb127
bb127:
  %t383 = load i1, ptr %l189, !tbaa !21
  store i1 %t383, ptr %l185, !tbaa !21
  br label %bb128
bb128:
  %t384 = load i1, ptr %l185, !tbaa !21
  store i1 %t384, ptr %l19, !tbaa !21
  br label %bb198
bb129:
  %t385 = load ptr, ptr %l1, !tbaa !29
  store ptr %t385, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t386 = load ptr, ptr %l190, !tbaa !29
  %t387 = icmp ne ptr %t386, null
  br i1 %t387, label %bb130, label %bb131
bb130:
  %t389 = load ptr, ptr %l190, !tbaa !29
  %t390 = load i64, ptr %t389, !range !{i64 0, i64 18}
  %t392 = icmp eq i64 %t390, 13
  store i1 %t392, ptr %l191, !tbaa !21
  br label %bb131
bb131:
  %t393 = load i1, ptr %l191, !tbaa !21
  br i1 %t393, label %bb132, label %bb133
bb132:
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t396, i32 0, i32 2
  %t398 = load ptr, ptr %t397
  store ptr %t398, ptr %l12, !tbaa !29
  br label %bb134
bb133:
  br label %bb150
bb134:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l12, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Match", ptr %t401, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  %t407 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t400, { i64, ptr } %t404)
  store i1 %t407, ptr %l199
  br label %bb135
bb135:
  %t408 = load i1, ptr %l199, !tbaa !21
  br i1 %t408, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb139
bb137:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load ptr, ptr %l12, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Match", ptr %t410, i32 0, i32 1
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  %t416 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %t409, { i64, ptr } %t413)
  store i1 %t416, ptr %l204
  br label %bb138
bb138:
  %t417 = load i1, ptr %l204, !tbaa !21
  store i1 %t417, ptr %l200, !tbaa !21
  br label %bb139
bb139:
  %t418 = load i1, ptr %l200, !tbaa !21
  br i1 %t418, label %bb140, label %bb141
bb140:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb149
bb141:
  %t419 = load ptr, ptr %l12, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Match", ptr %t419, i32 0, i32 2
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = icmp eq ptr %t422, null
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb142, label %bb143
bb142:
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l211, !tbaa !29
  %t429 = load ptr, ptr %l12, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Match", ptr %t429, i32 0, i32 2
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = icmp eq ptr %t432, null
  br i1 %t434, label %bb144, label %bb145
bb143:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb148
bb144:
  call void @__olang_check_failed(ptr @olang_loc_b80660129801afa0_e660219d512f014)
  unreachable
bb145:
  br label %bb146
bb146:
  %t436 = load ptr, ptr %l12, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Match", ptr %t436, i32 0, i32 2
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t440 = load ptr, ptr %l211, !tbaa !29
  %t442 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %t440, ptr %t439)
  store i1 %t442, ptr %l217
  br label %bb147
bb147:
  %t443 = load i1, ptr %l217, !tbaa !21
  store i1 %t443, ptr %l210, !tbaa !21
  br label %bb148
bb148:
  %t444 = load i1, ptr %l210, !tbaa !21
  store i1 %t444, ptr %l205, !tbaa !21
  br label %bb149
bb149:
  %t445 = load i1, ptr %l205, !tbaa !21
  store i1 %t445, ptr %l19, !tbaa !21
  br label %bb198
bb150:
  %t446 = load ptr, ptr %l1, !tbaa !29
  store ptr %t446, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t447 = load ptr, ptr %l218, !tbaa !29
  %t448 = icmp ne ptr %t447, null
  br i1 %t448, label %bb151, label %bb152
bb151:
  %t450 = load ptr, ptr %l218, !tbaa !29
  %t451 = load i64, ptr %t450, !range !{i64 0, i64 18}
  %t453 = icmp eq i64 %t451, 14
  store i1 %t453, ptr %l219, !tbaa !21
  br label %bb152
bb152:
  %t454 = load i1, ptr %l219, !tbaa !21
  br i1 %t454, label %bb153, label %bb154
bb153:
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr { i64, [5 x i64] }, ptr %t455, i32 0, i32 1
  %t458 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t457, i32 0, i32 2
  %t459 = load ptr, ptr %t458
  store ptr %t459, ptr %l13, !tbaa !29
  br label %bb155
bb154:
  br label %bb183
bb155:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/typed:leaveWalk", ptr %t461, i32 0, i32 1
  %t464 = load i1, ptr %t463, !tbaa !21
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb156, label %bb157
bb156:
  %t468 = load ptr, ptr %l13, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Try", ptr %t468, i32 0, i32 2
  %t471 = load i1, ptr %t470, !tbaa !21
  %t473 = xor i1 %t471, true
  store i1 %t473, ptr %l227, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb158
bb158:
  %t475 = load i1, ptr %l227, !tbaa !21
  br i1 %t475, label %bb159, label %bb160
bb159:
  %t476 = load ptr, ptr %l13, !tbaa !29
  %t478 = getelementptr %"compiler/typed:Try", ptr %t476, i32 0, i32 3
  %t479 = load i1, ptr %t478, !tbaa !21
  %t481 = xor i1 %t479, true
  store i1 %t481, ptr %l231, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb161
bb161:
  %t483 = load i1, ptr %l231, !tbaa !21
  br i1 %t483, label %bb162, label %bb163
bb162:
  %t484 = load ptr, ptr %l13, !tbaa !29
  %t486 = getelementptr %"compiler/typed:Try", ptr %t484, i32 0, i32 4
  %t487 = load i1, ptr %t486, !tbaa !21
  store i1 %t487, ptr %l235, !tbaa !21
  br label %bb164
bb163:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb164
bb164:
  %t489 = load i1, ptr %l235, !tbaa !21
  br i1 %t489, label %bb165, label %bb166
bb165:
  %t490 = load ptr, ptr %l13, !tbaa !29
  %t492 = getelementptr %"compiler/typed:Try", ptr %t490, i32 0, i32 1
  %t493 = load { i64, ptr }, ptr %t492, !tbaa !27
  %t495 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t493)
  store i1 %t495, ptr %l241
  br label %bb167
bb166:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb168
bb167:
  %t496 = load i1, ptr %l241, !tbaa !21
  %t497 = xor i1 %t496, true
  store i1 %t497, ptr %l238, !tbaa !21
  br label %bb168
bb168:
  %t499 = load i1, ptr %l238, !tbaa !21
  br i1 %t499, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l243, !tbaa !21
  br label %bb174
bb170:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/typed:leaveWalk", ptr %t500, i32 0, i32 2
  %t503 = load i1, ptr %t502, !tbaa !21
  br i1 %t503, label %bb171, label %bb172
bb171:
  %t505 = load ptr, ptr %l13, !tbaa !29
  %t507 = getelementptr %"compiler/typed:Try", ptr %t505, i32 0, i32 2
  %t508 = load i1, ptr %t507, !tbaa !21
  store i1 %t508, ptr %l246, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb173
bb173:
  %t510 = load i1, ptr %l246, !tbaa !21
  store i1 %t510, ptr %l243, !tbaa !21
  br label %bb174
bb174:
  %t511 = load i1, ptr %l243, !tbaa !21
  br i1 %t511, label %bb175, label %bb176
bb175:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb178
bb176:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load ptr, ptr %l13, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Try", ptr %t513, i32 0, i32 0
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t519 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t512, ptr %t516)
  store i1 %t519, ptr %l253
  br label %bb177
bb177:
  %t520 = load i1, ptr %l253, !tbaa !21
  store i1 %t520, ptr %l249, !tbaa !21
  br label %bb178
bb178:
  %t521 = load i1, ptr %l249, !tbaa !21
  br i1 %t521, label %bb179, label %bb180
bb179:
  store i1 true, ptr %l254, !tbaa !21
  br label %bb182
bb180:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load ptr, ptr %l13, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Try", ptr %t523, i32 0, i32 1
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  %t529 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t522, { i64, ptr } %t526)
  store i1 %t529, ptr %l258
  br label %bb181
bb181:
  %t530 = load i1, ptr %l258, !tbaa !21
  store i1 %t530, ptr %l254, !tbaa !21
  br label %bb182
bb182:
  %t531 = load i1, ptr %l254, !tbaa !21
  store i1 %t531, ptr %l19, !tbaa !21
  br label %bb198
bb183:
  %t532 = load ptr, ptr %l1, !tbaa !29
  store ptr %t532, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t533 = load ptr, ptr %l259, !tbaa !29
  %t534 = icmp ne ptr %t533, null
  br i1 %t534, label %bb184, label %bb185
bb184:
  %t536 = load ptr, ptr %l259, !tbaa !29
  %t537 = load i64, ptr %t536, !range !{i64 0, i64 18}
  %t539 = icmp eq i64 %t537, 16
  store i1 %t539, ptr %l260, !tbaa !21
  br label %bb185
bb185:
  %t540 = load i1, ptr %l260, !tbaa !21
  br i1 %t540, label %bb186, label %bb187
bb186:
  %t541 = load ptr, ptr %l1, !tbaa !29
  %t543 = getelementptr { i64, [5 x i64] }, ptr %t541, i32 0, i32 1
  %t544 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t543, i32 0, i32 2
  %t545 = load ptr, ptr %t544
  store ptr %t545, ptr %l14, !tbaa !29
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l14, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Text", ptr %t548, i32 0, i32 0
  %t551 = load { i64, ptr }, ptr %t550, !tbaa !27
  %t554 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %t547, { i64, ptr } %t551)
  store i1 %t554, ptr %l268
  br label %bb189
bb189:
  %t555 = load i1, ptr %l268, !tbaa !21
  store i1 %t555, ptr %l19, !tbaa !21
  br label %bb198
bb190:
  %t556 = load ptr, ptr %l1, !tbaa !29
  store ptr %t556, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t557 = load ptr, ptr %l269, !tbaa !29
  %t558 = icmp ne ptr %t557, null
  br i1 %t558, label %bb191, label %bb192
bb191:
  %t560 = load ptr, ptr %l269, !tbaa !29
  %t561 = load i64, ptr %t560, !range !{i64 0, i64 18}
  %t563 = icmp eq i64 %t561, 17
  store i1 %t563, ptr %l270, !tbaa !21
  br label %bb192
bb192:
  %t564 = load i1, ptr %l270, !tbaa !21
  br i1 %t564, label %bb193, label %bb194
bb193:
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t565, i32 0, i32 1
  %t568 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t567, i32 0, i32 2
  %t569 = load ptr, ptr %t568
  store ptr %t569, ptr %l15, !tbaa !29
  br label %bb195
bb194:
  br label %bb197
bb195:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load ptr, ptr %l15, !tbaa !29
  %t576 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t571, ptr %t572)
  store i1 %t576, ptr %l278
  br label %bb196
bb196:
  %t577 = load i1, ptr %l278, !tbaa !21
  store i1 %t577, ptr %l19, !tbaa !21
  br label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba)
  unreachable
bb198:
  %t578 = load i1, ptr %l19, !tbaa !21
  store i1 %t578, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 2}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { ptr }, ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t46)
  store i1 %t50, ptr %l30
  br label %bb13
bb13:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 2}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4c49c2cc391943fc_885b7fff3b4a3180)
  unreachable
bb24:
  br label %bb25
bb25:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t62, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  br label %bb36
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 5}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  store { i64, ptr } %t54, ptr %l9, !tbaa !27
  br label %bb36
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 5}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l27, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { ptr }, ptr %t67, i32 0, i32 0
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %v3, ptr %t71, ptr %t72)
  store { i64, ptr } %t76, ptr %l35
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t85 = load ptr, ptr %l37, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 5}
  %t91 = icmp eq i64 %t89, 4
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l38, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { i32, i32 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 2}
  store i32 %t97, ptr %l5
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { i32, i32 }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l6, !tbaa !23
  br label %bb24
bb23:
  br label %bb28
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i32, ptr %l5, !range !{i32 0, i32 2}
  store i32 %t105, ptr %l45
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %s8, ptr %l45, i64 0)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %s8
  %t108 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t109 = load i64, ptr %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t107, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l47, !tbaa !27
  %t113 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t114 = load ptr, ptr %t113
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %sbgrew.116, label %sbdone.117
sbgrew.116:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.117
sbdone.117:
  %t118 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t120 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l49
  br label %bb26
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/typed:printer", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l51, !tbaa !29
  %t125 = load i32, ptr %l6, !tbaa !23
  %t126 = load ptr, ptr %l51, !tbaa !29
  %t127 = call ptr @__olang_scope_or(ptr %v3, ptr %t126)
  %t128 = call ptr @__olang_scope_hold(ptr %t127)
  %t129 = ptrtoint ptr %t128 to i64
  %t131 = inttoptr i64 %t129 to ptr
  %t133 = inttoptr i64 0 to ptr
  %t134 = load ptr, ptr %l51, !tbaa !29
  %t136 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t131, ptr %s7, ptr %t133, ptr %t134, i32 %t125)
  store { i64, ptr } %t136, ptr %l55
  br label %bb27
bb27:
  %t137 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t138, i64 %t139)
  %t148 = getelementptr i8, ptr %t147, i64 %t139
  call void @olang_textcopy(ptr %t148, ptr %t140, i64 %t141)
  %t149 = getelementptr i8, ptr %t148, i64 %t141
  call void @olang_textcopy(ptr %t149, ptr %t144, i64 %t145)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t147, 1
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb28:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t154 = load ptr, ptr %l57, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l57, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 5}
  %t160 = icmp eq i64 %t158, 3
  store i1 %t160, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t161 = load i1, ptr %l58, !tbaa !21
  br i1 %t161, label %bb31, label %bb32
bb31:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { i32, i64, i32 }, ptr %t164, i32 0, i32 0
  %t166 = load i32, ptr %t165
  store i32 %t166, ptr %l7, !tbaa !23
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { i32, i64, i32 }, ptr %t170, i32 0, i32 1
  %t172 = load i64, ptr %t171
  store i64 %t172, ptr %l8, !tbaa !24
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:printer", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  store ptr %t177, ptr %l66, !tbaa !29
  %t178 = load i32, ptr %l7, !tbaa !23
  %t179 = load ptr, ptr %l66, !tbaa !29
  %t180 = call ptr @__olang_scope_or(ptr %v3, ptr %t179)
  %t181 = call ptr @__olang_scope_hold(ptr %t180)
  %t182 = ptrtoint ptr %t181 to i64
  %t184 = inttoptr i64 %t182 to ptr
  %t186 = inttoptr i64 0 to ptr
  %t187 = load ptr, ptr %l66, !tbaa !29
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t184, ptr %s10, ptr %t186, ptr %t187, i32 %t178)
  store { i64, ptr } %t189, ptr %l70
  br label %bb34
bb34:
  %t190 = load i64, ptr %l8, !tbaa !24
  %t191 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t193 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t201 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t191, i64 %t192)
  %t204 = getelementptr i8, ptr %t203, i64 %t192
  call void @olang_textcopy(ptr %t204, ptr %t194, i64 %t195)
  %t205 = getelementptr i8, ptr %t204, i64 %t195
  call void @olang_textcopy(ptr %t205, ptr %t197, i64 %t198)
  %t206 = getelementptr i8, ptr %t205, i64 %t198
  %t207 = call i64 @__olang_fmt_i64(ptr %t206, i64 %t190)
  %t208 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t203, 1
  store { i64, ptr } %t209, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22)
  unreachable
bb36:
  %t211 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t211, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i64
  %l144 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i64
  %l159 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l179 = alloca ptr
  %l183 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i64
  %l198 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l202 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i64
  %l209 = alloca i32
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i64
  %l227 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l231 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca i64
  %l262 = alloca { i64, ptr }
  %l270 = alloca ptr
  %l271 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i64
  %l282 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i64
  %l298 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l302 = alloca i1
  %l307 = alloca ptr
  %l308 = alloca i64
  %l309 = alloca ptr
  %l314 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l33, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l34, !tbaa !24
  %t24 = load i32, ptr %l3, !tbaa !23
  store i32 %t24, ptr %l35, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %v2, ptr %t25, ptr %t26)
  store { i64, ptr } %t30, ptr %l39
  br label %bb6
bb6:
  %t31 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t33 = load i32, ptr %l35, !tbaa !23
  %t34 = sext i32 %t33 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t31, i64 %t32)
  %t45 = getelementptr i8, ptr %t44, i64 %t32
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t34)
  %t47 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t44, 1
  %t52 = load ptr, ptr %l33, !tbaa !29
  %t53 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s1, ptr %t52, i64 %t53, { i64, ptr } %t50)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb163
bb8:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t56 = load ptr, ptr %l42, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t59 = load ptr, ptr %l42, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 17}
  %t62 = icmp eq i64 %t60, 1
  store i1 %t62, ptr %l43, !tbaa !21
  br label %bb10
bb10:
  %t63 = load i1, ptr %l43, !tbaa !21
  br i1 %t63, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l5, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %l51, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t82 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s3, ptr %v2, ptr %t78, ptr %t79)
  store { i64, ptr } %t82, ptr %l54
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %v2, ptr %t83, ptr %t84)
  store { i64, ptr } %t88, ptr %l58
  br label %bb15
bb15:
  %t89 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t91 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = add i64 %t90, %t93
  %t95 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t97 = add i64 %t94, %t96
  %t98 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = add i64 %t97, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t89, i64 %t90)
  %t103 = getelementptr i8, ptr %t102, i64 %t90
  call void @olang_textcopy(ptr %t103, ptr %t92, i64 %t93)
  %t104 = getelementptr i8, ptr %t103, i64 %t93
  call void @olang_textcopy(ptr %t104, ptr %t95, i64 %t96)
  %t105 = getelementptr i8, ptr %t104, i64 %t96
  call void @olang_textcopy(ptr %t105, ptr %t99, i64 %t100)
  %t106 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t102, 1
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s3, ptr %t109, i64 %t110, { i64, ptr } %t107)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb163
bb17:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb18, label %bb19
bb18:
  %t116 = load ptr, ptr %l61, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 17}
  %t119 = icmp eq i64 %t117, 2
  store i1 %t119, ptr %l62, !tbaa !21
  br label %bb19
bb19:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb20, label %bb21
bb20:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [3 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l67, !tbaa !29
  %t128 = load i64, ptr %l2, !tbaa !24
  store i64 %t128, ptr %l68, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t134 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %v2, ptr %t129, ptr %t130)
  store { i64, ptr } %t134, ptr %l72
  br label %bb23
bb23:
  %t135 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t137 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t135, i64 %t136)
  %t142 = getelementptr i8, ptr %t141, i64 %t136
  call void @olang_textcopy(ptr %t142, ptr %t138, i64 %t139)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  %t146 = load ptr, ptr %l67, !tbaa !29
  %t147 = load i64, ptr %l68, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s5, ptr %t146, i64 %t147, { i64, ptr } %t144)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb163
bb25:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb26, label %bb27
bb26:
  %t153 = load ptr, ptr %l75, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 17}
  %t156 = icmp eq i64 %t154, 3
  store i1 %t156, ptr %l76, !tbaa !21
  br label %bb27
bb27:
  %t157 = load i1, ptr %l76, !tbaa !21
  br i1 %t157, label %bb28, label %bb29
bb28:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb42
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l81, !tbaa !29
  %t165 = load i64, ptr %l2, !tbaa !24
  store i64 %t165, ptr %l82, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l8, !tbaa !29
  %t169 = getelementptr %"compiler/typed:If", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t174 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %v2, ptr %t166, ptr %t170)
  store { i64, ptr } %t174, ptr %l87
  br label %bb31
bb31:
  %t175 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t177 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = add i64 %t176, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = getelementptr i8, ptr %t181, i64 %t176
  call void @olang_textcopy(ptr %t182, ptr %t178, i64 %t179)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t181, 1
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load i64, ptr %l82, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s7, ptr %t186, i64 %t187, { i64, ptr } %t184)
  br label %bb32
bb32:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = getelementptr %"compiler/typed:If", ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t194 = load i64, ptr %l2, !tbaa !24
  %t196 = add i64 %t194, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t189, ptr %t193, i64 %t196)
  br label %bb33
bb33:
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t202 = getelementptr %"compiler/typed:If", ptr %t200, i32 0, i32 2
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s9, ptr %t209, i64 %t210, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l101, !tbaa !29
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t216 = getelementptr %"compiler/typed:If", ptr %t214, i32 0, i32 2
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_7b432bbe8f05f1d7_7deffd42aa472253)
  unreachable
bb38:
  br label %bb39
bb39:
  %t221 = load ptr, ptr %l8, !tbaa !29
  %t223 = getelementptr %"compiler/typed:If", ptr %t221, i32 0, i32 2
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t225 = load i64, ptr %l2, !tbaa !24
  %t227 = add i64 %t225, 1
  %t228 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t228, ptr %t224, i64 %t227)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb163
bb42:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t232 = load ptr, ptr %l109, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb43, label %bb44
bb43:
  %t235 = load ptr, ptr %l109, !tbaa !29
  %t236 = load i64, ptr %t235, !range !{i64 0, i64 17}
  %t238 = icmp eq i64 %t236, 4
  store i1 %t238, ptr %l110, !tbaa !21
  br label %bb44
bb44:
  %t239 = load i1, ptr %l110, !tbaa !21
  br i1 %t239, label %bb45, label %bb46
bb45:
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr { i64, [3 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t242, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l9, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t248, i32 0, i32 2
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s10, ptr %t252, i64 %t253, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb48
bb48:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l9, !tbaa !29
  %t258 = load i64, ptr %l2, !tbaa !24
  %t260 = add i64 %t258, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t256, ptr %t257, i64 %t260)
  br label %bb49
bb49:
  %t264 = load ptr, ptr %l10, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s11, ptr %t270, i64 %t271, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l10, !tbaa !29
  %t276 = load i64, ptr %l2, !tbaa !24
  %t278 = add i64 %t276, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t274, ptr %t275, i64 %t278)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb163
bb55:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t283 = load ptr, ptr %l132, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb56, label %bb57
bb56:
  %t286 = load ptr, ptr %l132, !tbaa !29
  %t287 = load i64, ptr %t286, !range !{i64 0, i64 17}
  %t289 = icmp eq i64 %t287, 5
  store i1 %t289, ptr %l133, !tbaa !21
  br label %bb57
bb57:
  %t290 = load i1, ptr %l133, !tbaa !21
  br i1 %t290, label %bb58, label %bb59
bb58:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t293, i32 0, i32 1
  %t295 = load i32, ptr %t294, !range !{i32 0, i32 2}
  store i32 %t295, ptr %l11
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t299, i32 0, i32 2
  %t301 = load i32, ptr %t300
  store i32 %t301, ptr %l12, !tbaa !23
  br label %bb60
bb59:
  br label %bb65
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l140, !tbaa !29
  %t304 = load i64, ptr %l2, !tbaa !24
  store i64 %t304, ptr %l141, !tbaa !24
  %t305 = load i32, ptr %l11, !range !{i32 0, i32 2}
  %t307 = trunc i64 0 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb61, label %bb62
bb61:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb63
bb63:
  %t310 = load i32, ptr %l12, !tbaa !23
  %t311 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t316 = add i64 %t313, %t315
  %t318 = sext i32 %t310 to i64
  %t319 = call i64 @__olang_fmt_i64(ptr null, i64 %t318)
  %t320 = add i64 %t316, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t312, i64 %t313)
  %t322 = getelementptr i8, ptr %t321, i64 %t313
  call void @olang_textcopy(ptr %t322, ptr %t314, i64 %t315)
  %t323 = getelementptr i8, ptr %t322, i64 %t315
  %t324 = call i64 @__olang_fmt_i64(ptr %t323, i64 %t318)
  %t325 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t321, 1
  %t328 = load ptr, ptr %l140, !tbaa !29
  %t329 = load i64, ptr %l141, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s12, ptr %t328, i64 %t329, { i64, ptr } %t326)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb163
bb65:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t332 = load ptr, ptr %l148, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb66, label %bb67
bb66:
  %t335 = load ptr, ptr %l148, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 17}
  %t338 = icmp eq i64 %t336, 6
  store i1 %t338, ptr %l149, !tbaa !21
  br label %bb67
bb67:
  %t339 = load i1, ptr %l149, !tbaa !21
  br i1 %t339, label %bb68, label %bb69
bb68:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr }, ptr %t342, i32 0, i32 1
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l13, !tbaa !29
  br label %bb70
bb69:
  br label %bb76
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l154, !tbaa !29
  %t347 = load i64, ptr %l2, !tbaa !24
  store i64 %t347, ptr %l155, !tbaa !24
  %t348 = load ptr, ptr %l13, !tbaa !29
  %t350 = icmp eq ptr %t348, null
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb71, label %bb72
bb71:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l13, !tbaa !29
  %t359 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s14, ptr %v2, ptr %t354, ptr %t355)
  store { i64, ptr } %t359, ptr %l163
  br label %bb73
bb72:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l159, !tbaa !27
  br label %bb74
bb73:
  %t360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t362 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 1
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t365 = add i64 %t361, %t364
  %t366 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t365)
  call void @olang_textcopy(ptr %t366, ptr %t360, i64 %t361)
  %t367 = getelementptr i8, ptr %t366, i64 %t361
  call void @olang_textcopy(ptr %t367, ptr %t363, i64 %t364)
  %t368 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t366, 1
  store { i64, ptr } %t369, ptr %l159, !tbaa !27
  br label %bb74
bb74:
  %t372 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t374 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t372, i64 %t373)
  %t379 = getelementptr i8, ptr %t378, i64 %t373
  call void @olang_textcopy(ptr %t379, ptr %t375, i64 %t376)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  %t383 = load ptr, ptr %l154, !tbaa !29
  %t384 = load i64, ptr %l155, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s14, ptr %t383, i64 %t384, { i64, ptr } %t381)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb163
bb76:
  %t386 = load ptr, ptr %l1, !tbaa !29
  store ptr %t386, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t387 = load ptr, ptr %l168, !tbaa !29
  %t388 = icmp ne ptr %t387, null
  br i1 %t388, label %bb77, label %bb78
bb77:
  %t390 = load ptr, ptr %l168, !tbaa !29
  %t391 = load i64, ptr %t390, !range !{i64 0, i64 17}
  %t393 = icmp eq i64 %t391, 7
  store i1 %t393, ptr %l169, !tbaa !21
  br label %bb78
bb78:
  %t394 = load i1, ptr %l169, !tbaa !21
  br i1 %t394, label %bb79, label %bb80
bb79:
  %t395 = load ptr, ptr %l1, !tbaa !29
  %t397 = getelementptr { i64, [3 x i64] }, ptr %t395, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t397, i32 0, i32 1
  %t399 = load i32, ptr %t398
  store i32 %t399, ptr %l14, !tbaa !23
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [3 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t403, i32 0, i32 2
  %t405 = load i64, ptr %t404
  store i64 %t405, ptr %l15, !tbaa !24
  br label %bb81
bb80:
  br label %bb84
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l176, !tbaa !29
  %t408 = load i64, ptr %l2, !tbaa !24
  store i64 %t408, ptr %l177, !tbaa !24
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/typed:printer", ptr %t409, i32 0, i32 0
  %t412 = load ptr, ptr %t411, !tbaa !29
  store ptr %t412, ptr %l179, !tbaa !29
  %t413 = load i32, ptr %l14, !tbaa !23
  %t414 = load ptr, ptr %l179, !tbaa !29
  %t415 = call ptr @__olang_scope_or(ptr %v2, ptr %t414)
  %t416 = call ptr @__olang_scope_hold(ptr %t415)
  %t417 = ptrtoint ptr %t416 to i64
  %t419 = inttoptr i64 %t417 to ptr
  %t421 = inttoptr i64 0 to ptr
  %t422 = load ptr, ptr %l179, !tbaa !29
  %t424 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t419, ptr %s17, ptr %t421, ptr %t422, i32 %t413)
  store { i64, ptr } %t424, ptr %l183
  br label %bb82
bb82:
  %t425 = load i64, ptr %l15, !tbaa !24
  %t426 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t427 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t428 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t428, 1
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t431 = add i64 %t427, %t430
  %t432 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t433 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t434 = add i64 %t431, %t433
  %t436 = call i64 @__olang_fmt_i64(ptr null, i64 %t425)
  %t437 = add i64 %t434, %t436
  %t438 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t426, i64 %t427)
  %t439 = getelementptr i8, ptr %t438, i64 %t427
  call void @olang_textcopy(ptr %t439, ptr %t429, i64 %t430)
  %t440 = getelementptr i8, ptr %t439, i64 %t430
  call void @olang_textcopy(ptr %t440, ptr %t432, i64 %t433)
  %t441 = getelementptr i8, ptr %t440, i64 %t433
  %t442 = call i64 @__olang_fmt_i64(ptr %t441, i64 %t425)
  %t443 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t438, 1
  %t446 = load ptr, ptr %l176, !tbaa !29
  %t447 = load i64, ptr %l177, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s17, ptr %t446, i64 %t447, { i64, ptr } %t444)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb163
bb84:
  %t449 = load ptr, ptr %l1, !tbaa !29
  store ptr %t449, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t450 = load ptr, ptr %l187, !tbaa !29
  %t451 = icmp ne ptr %t450, null
  br i1 %t451, label %bb85, label %bb86
bb85:
  %t453 = load ptr, ptr %l187, !tbaa !29
  %t454 = load i64, ptr %t453, !range !{i64 0, i64 17}
  %t456 = icmp eq i64 %t454, 8
  store i1 %t456, ptr %l188, !tbaa !21
  br label %bb86
bb86:
  %t457 = load i1, ptr %l188, !tbaa !21
  br i1 %t457, label %bb87, label %bb88
bb87:
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t460 = getelementptr { i64, [3 x i64] }, ptr %t458, i32 0, i32 1
  %t461 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t460, i32 0, i32 1
  %t462 = load ptr, ptr %t461
  store ptr %t462, ptr %l16, !tbaa !29
  br label %bb89
bb88:
  br label %bb92
bb89:
  store %olang.scope zeroinitializer, ptr %s19
  %t464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t464, ptr %l193, !tbaa !29
  %t465 = load i64, ptr %l2, !tbaa !24
  store i64 %t465, ptr %l194, !tbaa !24
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load ptr, ptr %l16, !tbaa !29
  %t471 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %v2, ptr %t466, ptr %t467)
  store { i64, ptr } %t471, ptr %l198
  br label %bb90
bb90:
  %t472 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t474 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t474, 1
  %t476 = extractvalue { i64, ptr } %t474, 0
  %t477 = add i64 %t473, %t476
  %t478 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t477)
  call void @olang_textcopy(ptr %t478, ptr %t472, i64 %t473)
  %t479 = getelementptr i8, ptr %t478, i64 %t473
  call void @olang_textcopy(ptr %t479, ptr %t475, i64 %t476)
  %t480 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t478, 1
  %t483 = load ptr, ptr %l193, !tbaa !29
  %t484 = load i64, ptr %l194, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s19, ptr %t483, i64 %t484, { i64, ptr } %t481)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s19)
  br label %bb163
bb92:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t487 = load ptr, ptr %l201, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb93, label %bb94
bb93:
  %t490 = load ptr, ptr %l201, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 17}
  %t493 = icmp eq i64 %t491, 9
  store i1 %t493, ptr %l202, !tbaa !21
  br label %bb94
bb94:
  %t494 = load i1, ptr %l202, !tbaa !21
  br i1 %t494, label %bb95, label %bb96
bb95:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [3 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t497, i32 0, i32 1
  %t499 = load i32, ptr %t498, !range !{i32 0, i32 2}
  store i32 %t499, ptr %l17
  br label %bb97
bb96:
  br label %bb101
bb97:
  store %olang.scope zeroinitializer, ptr %s21
  %t501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t501, ptr %l207, !tbaa !29
  %t502 = load i64, ptr %l2, !tbaa !24
  store i64 %t502, ptr %l208, !tbaa !24
  %t503 = load i32, ptr %l17, !range !{i32 0, i32 2}
  store i32 %t503, ptr %l209
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %s22, ptr %l209, i64 0)
  br label %bb98
bb98:
  %t505 = load ptr, ptr %s22
  %t506 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t507 = load i64, ptr %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t505, i64 %t507)
  %t509 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t508, 1
  store { i64, ptr } %t510, ptr %l211, !tbaa !27
  %t511 = getelementptr %olang.builder, ptr %s22, i32 0, i32 3
  %t512 = load ptr, ptr %t511
  %t513 = icmp ne ptr %t512, null
  br i1 %t513, label %sbgrew.514, label %sbdone.515
sbgrew.514:
  call void @__olang_sb_done(ptr %s22)
  br label %sbdone.515
sbdone.515:
  %t516 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t518 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s21, ptr %s21, { i64, ptr } %t516)
  store { i64, ptr } %t518, ptr %l213
  br label %bb99
bb99:
  %t519 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t521 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t521, 1
  %t523 = extractvalue { i64, ptr } %t521, 0
  %t524 = add i64 %t520, %t523
  %t525 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t524)
  call void @olang_textcopy(ptr %t525, ptr %t519, i64 %t520)
  %t526 = getelementptr i8, ptr %t525, i64 %t520
  call void @olang_textcopy(ptr %t526, ptr %t522, i64 %t523)
  %t527 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t528 = insertvalue { i64, ptr } %t527, ptr %t525, 1
  %t530 = load ptr, ptr %l207, !tbaa !29
  %t531 = load i64, ptr %l208, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s21, ptr %t530, i64 %t531, { i64, ptr } %t528)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s21)
  br label %bb163
bb101:
  %t533 = load ptr, ptr %l1, !tbaa !29
  store ptr %t533, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t534 = load ptr, ptr %l216, !tbaa !29
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %bb102, label %bb103
bb102:
  %t537 = load ptr, ptr %l216, !tbaa !29
  %t538 = load i64, ptr %t537, !range !{i64 0, i64 17}
  %t540 = icmp eq i64 %t538, 10
  store i1 %t540, ptr %l217, !tbaa !21
  br label %bb103
bb103:
  %t541 = load i1, ptr %l217, !tbaa !21
  br i1 %t541, label %bb104, label %bb105
bb104:
  %t542 = load ptr, ptr %l1, !tbaa !29
  %t544 = getelementptr { i64, [3 x i64] }, ptr %t542, i32 0, i32 1
  %t545 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t544, i32 0, i32 1
  %t546 = load ptr, ptr %t545
  store ptr %t546, ptr %l18, !tbaa !29
  br label %bb106
bb105:
  br label %bb109
bb106:
  store %olang.scope zeroinitializer, ptr %s24
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l222, !tbaa !29
  %t549 = load i64, ptr %l2, !tbaa !24
  store i64 %t549, ptr %l223, !tbaa !24
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load ptr, ptr %l18, !tbaa !29
  %t555 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s24, ptr %v2, ptr %t550, ptr %t551)
  store { i64, ptr } %t555, ptr %l227
  br label %bb107
bb107:
  %t556 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t557 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t558 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 1
  %t560 = extractvalue { i64, ptr } %t558, 0
  %t561 = add i64 %t557, %t560
  %t562 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t561)
  call void @olang_textcopy(ptr %t562, ptr %t556, i64 %t557)
  %t563 = getelementptr i8, ptr %t562, i64 %t557
  call void @olang_textcopy(ptr %t563, ptr %t559, i64 %t560)
  %t564 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr %t562, 1
  %t567 = load ptr, ptr %l222, !tbaa !29
  %t568 = load i64, ptr %l223, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s24, ptr %t567, i64 %t568, { i64, ptr } %t565)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s24)
  br label %bb163
bb109:
  %t570 = load ptr, ptr %l1, !tbaa !29
  store ptr %t570, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t571 = load ptr, ptr %l230, !tbaa !29
  %t572 = icmp ne ptr %t571, null
  br i1 %t572, label %bb110, label %bb111
bb110:
  %t574 = load ptr, ptr %l230, !tbaa !29
  %t575 = load i64, ptr %t574, !range !{i64 0, i64 17}
  %t577 = icmp eq i64 %t575, 11
  store i1 %t577, ptr %l231, !tbaa !21
  br label %bb111
bb111:
  %t578 = load i1, ptr %l231, !tbaa !21
  br i1 %t578, label %bb112, label %bb113
bb112:
  %t579 = load ptr, ptr %l1, !tbaa !29
  %t581 = getelementptr { i64, [3 x i64] }, ptr %t579, i32 0, i32 1
  %t582 = getelementptr { %"compiler/source:Span", ptr }, ptr %t581, i32 0, i32 1
  %t583 = load ptr, ptr %t582
  store ptr %t583, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load ptr, ptr %l19, !tbaa !29
  %t587 = load i64, ptr %l2, !tbaa !24
  %t589 = add i64 %t587, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t585, ptr %t586, i64 %t589)
  br label %bb115
bb115:
  br label %bb163
bb116:
  %t593 = load ptr, ptr %l1, !tbaa !29
  store ptr %t593, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t594 = load ptr, ptr %l240, !tbaa !29
  %t595 = icmp ne ptr %t594, null
  br i1 %t595, label %bb117, label %bb118
bb117:
  %t597 = load ptr, ptr %l240, !tbaa !29
  %t598 = load i64, ptr %t597, !range !{i64 0, i64 17}
  %t600 = icmp eq i64 %t598, 12
  store i1 %t600, ptr %l241, !tbaa !21
  br label %bb118
bb118:
  %t601 = load i1, ptr %l241, !tbaa !21
  br i1 %t601, label %bb119, label %bb120
bb119:
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [3 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", ptr }, ptr %t604, i32 0, i32 1
  %t606 = load ptr, ptr %t605
  store ptr %t606, ptr %l20, !tbaa !29
  br label %bb121
bb120:
  br label %bb124
bb121:
  store %olang.scope zeroinitializer, ptr %s27
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s27, ptr %t608, i64 %t609, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb122
bb122:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load ptr, ptr %l20, !tbaa !29
  %t614 = load i64, ptr %l2, !tbaa !24
  %t616 = add i64 %t614, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t612, ptr %t613, i64 %t616)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s27)
  br label %bb163
bb124:
  %t620 = load ptr, ptr %l1, !tbaa !29
  store ptr %t620, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t621 = load ptr, ptr %l252, !tbaa !29
  %t622 = icmp ne ptr %t621, null
  br i1 %t622, label %bb125, label %bb126
bb125:
  %t624 = load ptr, ptr %l252, !tbaa !29
  %t625 = load i64, ptr %t624, !range !{i64 0, i64 17}
  %t627 = icmp eq i64 %t625, 13
  store i1 %t627, ptr %l253, !tbaa !21
  br label %bb126
bb126:
  %t628 = load i1, ptr %l253, !tbaa !21
  br i1 %t628, label %bb127, label %bb128
bb127:
  %t629 = load ptr, ptr %l1, !tbaa !29
  %t631 = getelementptr { i64, [3 x i64] }, ptr %t629, i32 0, i32 1
  %t632 = getelementptr { %"compiler/source:Span", ptr }, ptr %t631, i32 0, i32 1
  %t633 = load ptr, ptr %t632
  store ptr %t633, ptr %l21, !tbaa !29
  br label %bb129
bb128:
  br label %bb135
bb129:
  store %olang.scope zeroinitializer, ptr %s28
  %t635 = load ptr, ptr %l0, !tbaa !29
  store ptr %t635, ptr %l258, !tbaa !29
  %t636 = load i64, ptr %l2, !tbaa !24
  store i64 %t636, ptr %l259, !tbaa !24
  %t637 = load ptr, ptr %l21, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Join", ptr %t637, i32 0, i32 1
  %t640 = load i1, ptr %t639, !tbaa !21
  br i1 %t640, label %bb130, label %bb131
bb130:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l262, !tbaa !27
  br label %bb132
bb131:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l262, !tbaa !27
  br label %bb132
bb132:
  %t642 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t643 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t644 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 1
  %t646 = extractvalue { i64, ptr } %t644, 0
  %t647 = add i64 %t643, %t646
  %t648 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t647)
  call void @olang_textcopy(ptr %t648, ptr %t642, i64 %t643)
  %t649 = getelementptr i8, ptr %t648, i64 %t643
  call void @olang_textcopy(ptr %t649, ptr %t645, i64 %t646)
  %t650 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t651 = insertvalue { i64, ptr } %t650, ptr %t648, 1
  %t653 = load ptr, ptr %l258, !tbaa !29
  %t654 = load i64, ptr %l259, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s28, ptr %t653, i64 %t654, { i64, ptr } %t651)
  br label %bb133
bb133:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load ptr, ptr %l21, !tbaa !29
  %t659 = getelementptr %"compiler/typed:Join", ptr %t657, i32 0, i32 0
  %t660 = load ptr, ptr %t659, !tbaa !29
  %t661 = load i64, ptr %l2, !tbaa !24
  %t663 = add i64 %t661, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t656, ptr %t660, i64 %t663)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s28)
  br label %bb163
bb135:
  %t667 = load ptr, ptr %l1, !tbaa !29
  store ptr %t667, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t668 = load ptr, ptr %l270, !tbaa !29
  %t669 = icmp ne ptr %t668, null
  br i1 %t669, label %bb136, label %bb137
bb136:
  %t671 = load ptr, ptr %l270, !tbaa !29
  %t672 = load i64, ptr %t671, !range !{i64 0, i64 17}
  %t674 = icmp eq i64 %t672, 14
  store i1 %t674, ptr %l271, !tbaa !21
  br label %bb137
bb137:
  %t675 = load i1, ptr %l271, !tbaa !21
  br i1 %t675, label %bb138, label %bb139
bb138:
  %t676 = load ptr, ptr %l1, !tbaa !29
  %t678 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 1
  %t679 = getelementptr { %"compiler/source:Span", ptr }, ptr %t678, i32 0, i32 1
  %t680 = load ptr, ptr %t679
  store ptr %t680, ptr %l22, !tbaa !29
  br label %bb140
bb139:
  br label %bb143
bb140:
  store %olang.scope zeroinitializer, ptr %s30
  %t682 = load ptr, ptr %l0, !tbaa !29
  store ptr %t682, ptr %l276, !tbaa !29
  %t683 = load i64, ptr %l2, !tbaa !24
  store i64 %t683, ptr %l277, !tbaa !24
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l22, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Spawn", ptr %t685, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !29
  %t692 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s30, ptr %v2, ptr %t684, ptr %t688)
  store { i64, ptr } %t692, ptr %l282
  br label %bb141
bb141:
  %t693 = load ptr, ptr %l22, !tbaa !29
  %t695 = getelementptr %"compiler/typed:Spawn", ptr %t693, i32 0, i32 3
  %t696 = load i32, ptr %t695, !tbaa !23
  %t697 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t699 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 1
  %t701 = extractvalue { i64, ptr } %t699, 0
  %t702 = add i64 %t698, %t701
  %t703 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t704 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t705 = add i64 %t702, %t704
  %t707 = sext i32 %t696 to i64
  %t708 = call i64 @__olang_fmt_i64(ptr null, i64 %t707)
  %t709 = add i64 %t705, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t697, i64 %t698)
  %t711 = getelementptr i8, ptr %t710, i64 %t698
  call void @olang_textcopy(ptr %t711, ptr %t700, i64 %t701)
  %t712 = getelementptr i8, ptr %t711, i64 %t701
  call void @olang_textcopy(ptr %t712, ptr %t703, i64 %t704)
  %t713 = getelementptr i8, ptr %t712, i64 %t704
  %t714 = call i64 @__olang_fmt_i64(ptr %t713, i64 %t707)
  %t715 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t710, 1
  %t718 = load ptr, ptr %l276, !tbaa !29
  %t719 = load i64, ptr %l277, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s30, ptr %t718, i64 %t719, { i64, ptr } %t716)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s30)
  br label %bb163
bb143:
  %t721 = load ptr, ptr %l1, !tbaa !29
  store ptr %t721, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t722 = load ptr, ptr %l287, !tbaa !29
  %t723 = icmp ne ptr %t722, null
  br i1 %t723, label %bb144, label %bb145
bb144:
  %t725 = load ptr, ptr %l287, !tbaa !29
  %t726 = load i64, ptr %t725, !range !{i64 0, i64 17}
  %t728 = icmp eq i64 %t726, 15
  store i1 %t728, ptr %l288, !tbaa !21
  br label %bb145
bb145:
  %t729 = load i1, ptr %l288, !tbaa !21
  br i1 %t729, label %bb146, label %bb147
bb146:
  %t730 = load ptr, ptr %l1, !tbaa !29
  %t732 = getelementptr { i64, [3 x i64] }, ptr %t730, i32 0, i32 1
  %t733 = getelementptr { %"compiler/source:Span", ptr }, ptr %t732, i32 0, i32 1
  %t734 = load ptr, ptr %t733
  store ptr %t734, ptr %l23, !tbaa !29
  br label %bb148
bb147:
  br label %bb151
bb148:
  store %olang.scope zeroinitializer, ptr %s32
  %t736 = load ptr, ptr %l0, !tbaa !29
  store ptr %t736, ptr %l293, !tbaa !29
  %t737 = load i64, ptr %l2, !tbaa !24
  store i64 %t737, ptr %l294, !tbaa !24
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t739 = load ptr, ptr %l23, !tbaa !29
  %t743 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s32, ptr %v2, ptr %t738, ptr %t739)
  store { i64, ptr } %t743, ptr %l298
  br label %bb149
bb149:
  %t744 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t745 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t746 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t746, 1
  %t748 = extractvalue { i64, ptr } %t746, 0
  %t749 = add i64 %t745, %t748
  %t750 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t749)
  call void @olang_textcopy(ptr %t750, ptr %t744, i64 %t745)
  %t751 = getelementptr i8, ptr %t750, i64 %t745
  call void @olang_textcopy(ptr %t751, ptr %t747, i64 %t748)
  %t752 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t750, 1
  %t755 = load ptr, ptr %l293, !tbaa !29
  %t756 = load i64, ptr %l294, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s32, ptr %t755, i64 %t756, { i64, ptr } %t753)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s32)
  br label %bb163
bb151:
  %t758 = load ptr, ptr %l1, !tbaa !29
  store ptr %t758, ptr %l301, !tbaa !29
  store i1 false, ptr %l302, !tbaa !21
  %t759 = load ptr, ptr %l301, !tbaa !29
  %t760 = icmp ne ptr %t759, null
  br i1 %t760, label %bb152, label %bb153
bb152:
  %t762 = load ptr, ptr %l301, !tbaa !29
  %t763 = load i64, ptr %t762, !range !{i64 0, i64 17}
  %t765 = icmp eq i64 %t763, 16
  store i1 %t765, ptr %l302, !tbaa !21
  br label %bb153
bb153:
  %t766 = load i1, ptr %l302, !tbaa !21
  br i1 %t766, label %bb154, label %bb155
bb154:
  %t767 = load ptr, ptr %l1, !tbaa !29
  %t769 = getelementptr { i64, [3 x i64] }, ptr %t767, i32 0, i32 1
  %t770 = getelementptr { %"compiler/source:Span", ptr }, ptr %t769, i32 0, i32 1
  %t771 = load ptr, ptr %t770
  store ptr %t771, ptr %l24, !tbaa !29
  br label %bb156
bb155:
  br label %bb162
bb156:
  store %olang.scope zeroinitializer, ptr %s34
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l307, !tbaa !29
  %t774 = load i64, ptr %l2, !tbaa !24
  store i64 %t774, ptr %l308, !tbaa !24
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l309, !tbaa !29
  %t776 = load ptr, ptr %l24, !tbaa !29
  %t778 = icmp eq ptr %t776, null
  br i1 %t778, label %bb157, label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_78afbb313fff45b8_957466907ebeb484)
  unreachable
bb158:
  br label %bb159
bb159:
  %t780 = load ptr, ptr %l24, !tbaa !29
  %t782 = load ptr, ptr %l309, !tbaa !29
  %t784 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s34, ptr %v2, ptr %t782, ptr %t780)
  store { i64, ptr } %t784, ptr %l314
  br label %bb160
bb160:
  %t785 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t786 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t787 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t787, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = add i64 %t786, %t789
  %t791 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t790)
  call void @olang_textcopy(ptr %t791, ptr %t785, i64 %t786)
  %t792 = getelementptr i8, ptr %t791, i64 %t786
  call void @olang_textcopy(ptr %t792, ptr %t788, i64 %t789)
  %t793 = insertvalue { i64, ptr } undef, i64 %t790, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t791, 1
  %t796 = load ptr, ptr %l307, !tbaa !29
  %t797 = load i64, ptr %l308, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s34, ptr %t796, i64 %t797, { i64, ptr } %t794)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s34)
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_90a2a4daf32abd74_d37804826367c570)
  unreachable
bb163:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 16
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Text", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = sext i32 %t24 to i64
  store i64 %t26, ptr %l9, !tbaa !24
  br label %bb37
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 7
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Make", ptr %t43, i32 0, i32 0
  %t46 = load i32, ptr %t45, !range !{i32 0, i32 5}
  %t48 = trunc i64 3 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Make", ptr %t51, i32 0, i32 4
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  store i64 %t56, ptr %l28, !tbaa !24
  br label %bb17
bb16:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l28, !tbaa !24
  store i64 %t58, ptr %l9, !tbaa !24
  br label %bb37
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l32, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 5
  store i1 %t66, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l33, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Promote", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l1, !tbaa !24
  %t80 = add i64 %t78, 1
  %t83 = call i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %t77, i64 %t80)
  store i64 %t83, ptr %l42
  br label %bb24
bb24:
  %t84 = load i64, ptr %l42, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  br label %bb37
bb25:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l43, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 17
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb27
bb27:
  %t93 = load i1, ptr %l44, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  %t103 = add i64 %t101, 1
  %t106 = call i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %t100, i64 %t103)
  store i64 %t106, ptr %l52
  br label %bb31
bb31:
  %t107 = load i64, ptr %l52, !tbaa !24
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_48b93bf05ad91c8c_dfcbf93f670f6050)
  unreachable
bb37:
  %t108 = load i64, ptr %l9, !tbaa !24
  store i64 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2elengthWord(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t3)
  %t9 = add i64 %t6, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t4, 1
  %t15 = extractvalue { i64, ptr } %t4, 0
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t3)
  %t20 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t10, i64 %t11)
  %t21 = getelementptr i8, ptr %t20, i64 %t11
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t17, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i32, i32 }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i32
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l66 = alloca i1
  %l70 = alloca i1
  %l74 = alloca i1
  %l81 = alloca { i32, i32 }
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l102 = alloca i1
  %l110 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l18
  br label %bb5
bb5:
  %t13 = load i32, ptr %l18, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l21
  br label %bb6
bb6:
  %t19 = load i32, ptr %l21, !range !{i32 0, i32 33}
  store i32 %t19, ptr %l4
  %t20 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t22 = trunc i64 1 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t25 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t27 = trunc i64 17 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t32, 8
  br i1 %t34, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l30, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb22
bb17:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l36
  br label %bb18
bb18:
  %t47 = load i1, ptr %l36, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  store i1 %t50, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t52 = load i1, ptr %l37, !tbaa !21
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t57 = trunc i64 19 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l43, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l46
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = add i64 %t66, 1
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = load i32, ptr %l46, !tbaa !23
  %t72 = call i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %t69, i32 %t70, i64 %t68)
  store i1 %t72, ptr %l49
  br label %bb29
bb29:
  %t73 = load i1, ptr %l49, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
bb30:
  %t74 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t76 = trunc i64 18 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb31, label %bb32
bb31:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l55
  br label %bb33
bb32:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb34
bb33:
  %t84 = load i1, ptr %l55, !tbaa !21
  store i1 %t84, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t85 = load i1, ptr %l52, !tbaa !21
  br i1 %t85, label %bb35, label %bb36
bb35:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l57, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l3, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l60
  br label %bb37
bb36:
  store i32 3, ptr %l56
  br label %bb39
bb37:
  %t93 = load ptr, ptr %l57, !tbaa !29
  %t94 = load i32, ptr %l60, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t95, ptr %l61
  br label %bb38
bb38:
  %t96 = load i32, ptr %l61, !range !{i32 0, i32 6}
  store i32 %t96, ptr %l56
  br label %bb39
bb39:
  %t97 = load i32, ptr %l56, !range !{i32 0, i32 6}
  store i32 %t97, ptr %l5
  %t98 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t100 = trunc i64 22 to i32
  %t101 = icmp eq i32 %t98, %t100
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb40, label %bb41
bb40:
  %t105 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t107 = trunc i64 23 to i32
  %t108 = icmp eq i32 %t105, %t107
  %t110 = xor i1 %t108, true
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t112 = load i1, ptr %l66, !tbaa !21
  br i1 %t112, label %bb43, label %bb44
bb43:
  %t113 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t115 = trunc i64 0 to i32
  %t116 = icmp eq i32 %t113, %t115
  %t118 = xor i1 %t116, true
  store i1 %t118, ptr %l70, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t120 = load i1, ptr %l70, !tbaa !21
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t121 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t123 = trunc i64 1 to i32
  %t124 = icmp eq i32 %t121, %t123
  %t126 = xor i1 %t124, true
  store i1 %t126, ptr %l74, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb48
bb48:
  %t128 = load i1, ptr %l74, !tbaa !21
  br i1 %t128, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l3, !tbaa !23
  %t134 = call { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHeldParts(ptr %v0, ptr %t130, i32 %t131)
  store { i32, i32 } %t134, ptr %l81
  br label %bb52
bb52:
  %t135 = load { i32, i32 }, ptr %l81
  store { i32, i32 } %t135, ptr %l6
  %t136 = getelementptr { i32, i32 }, ptr %l6, i32 0, i32 0
  %t137 = load i32, ptr %t136, !tbaa !23
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t139, i32 %t137)
  store { i64, ptr } %t143, ptr %l85
  br label %bb53
bb53:
  %t144 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb54
bb54:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t150 = load i64, ptr %l10, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb55, label %bb56
bb55:
  br label %bb75
bb56:
  br label %bb57
bb57:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t157, ptr %l92, !tbaa !27
  %t158 = load i64, ptr %l9, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i32, ptr %t161, i64 %t158
  %t163 = load i32, ptr %t162, !tbaa !33
  store i32 %t163, ptr %l11, !tbaa !23
  %t165 = load i32, ptr %l11, !tbaa !23
  %t167 = icmp eq i32 %t165, 0
  br i1 %t167, label %bb58, label %bb59
bb58:
  %t169 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t171 = trunc i64 1 to i32
  %t172 = icmp eq i32 %t169, %t171
  store i1 %t172, ptr %l97, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb60
bb60:
  %t174 = load i1, ptr %l97, !tbaa !21
  br i1 %t174, label %bb61, label %bb62
bb61:
  br label %bb74
bb62:
  br label %bb63
bb63:
  %t175 = load i32, ptr %l11, !tbaa !23
  %t177 = icmp eq i32 %t175, 0
  br i1 %t177, label %bb64, label %bb65
bb64:
  %t179 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t181 = trunc i64 0 to i32
  %t182 = icmp eq i32 %t179, %t181
  store i1 %t182, ptr %l102, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb66
bb66:
  %t184 = load i1, ptr %l102, !tbaa !21
  br i1 %t184, label %bb67, label %bb68
bb67:
  store i1 true, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l11, !tbaa !23
  %t188 = load i64, ptr %l2, !tbaa !24
  %t190 = add i64 %t188, 1
  %t194 = call i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %t186, i32 %t187, i64 %t190)
  store i1 %t194, ptr %l110
  br label %bb70
bb70:
  %t195 = load i1, ptr %l110, !tbaa !21
  br i1 %t195, label %bb71, label %bb72
bb71:
  store i1 true, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = add i64 %t197, 1
  store i64 %t200, ptr %l9, !tbaa !24
  br label %bb54
bb75:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ewritesFirst(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t3 = trunc i64 24 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb13
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t8 = trunc i64 25 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t13 = trunc i64 26 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t18 = trunc i64 27 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t23 = trunc i64 28 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t28 = trunc i64 41 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f30894d45741e677_8f67e2978087020b)
  unreachable
bb19:
  %t31 = load i1, ptr %l1, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca i64
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca %"compiler/typed:Body"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l6
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = call ptr @__olang_scope_hold(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l31, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e5
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = call ptr @__olang_region_make(ptr %v0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l31, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l31
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %t18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l33
  br label %bb3
bb3:
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e5
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l31
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = call ptr @__olang_region_or(ptr %t26, ptr null)
  %t28 = call ptr @__olang_region_home(ptr %t27)
  %t29 = icmp ne ptr %t28, null
  %t30 = select i1 %t29, ptr %t28, ptr null
  call void @__olang_region_settle_in(ptr %t23, ptr %t30)
  br label %bb5
bb5:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l10
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l35
  br label %bb6
bb6:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l11
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l36
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l12
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l37
  br label %bb8
bb8:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l13
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l38
  br label %bb9
bb9:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l14
  %t40 = call ptr @__olang_scope_hold(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l39, !tbaa !24
  %t42 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e10
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = call ptr @__olang_region_make(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l39, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l39
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %t47, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l41
  br label %bb12
bb12:
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e10
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l39
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = call ptr @__olang_region_or(ptr %t55, ptr null)
  %t57 = call ptr @__olang_region_home(ptr %t56)
  %t58 = icmp ne ptr %t57, null
  %t59 = select i1 %t58, ptr %t57, ptr null
  call void @__olang_region_settle_in(ptr %t52, ptr %t59)
  br label %bb14
bb14:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l15
  store ptr null, ptr %l16, !tbaa !29
  %t61 = call ptr @__olang_scope_hold(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l43, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e12
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = call ptr @__olang_region_make(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l43
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t68, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l45
  br label %bb17
bb17:
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e12
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = load i64, ptr %l43
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45, i32 0, i32 0
  %t75 = load { i64, ptr }, ptr %t74
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = call ptr @__olang_region_or(ptr %t76, ptr null)
  %t78 = call ptr @__olang_region_home(ptr %t77)
  %t79 = icmp ne ptr %t78, null
  %t80 = select i1 %t79, ptr %t78, ptr null
  call void @__olang_region_settle_in(ptr %t73, ptr %t80)
  br label %bb19
bb19:
  %t81 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l17
  %t82 = call ptr @__olang_scope_hold(ptr %v0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l47, !tbaa !24
  %t84 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e13
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = call ptr @__olang_region_make(ptr %v0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t88 = load i64, ptr %l47
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t89, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l49
  br label %bb22
bb22:
  %t91 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e13
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = load i64, ptr %l47
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = call ptr @__olang_region_or(ptr %t97, ptr null)
  %t99 = call ptr @__olang_region_home(ptr %t98)
  %t100 = icmp ne ptr %t99, null
  %t101 = select i1 %t100, ptr %t99, ptr null
  call void @__olang_region_settle_in(ptr %t94, ptr %t101)
  br label %bb24
bb24:
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l18
  store i1 false, ptr %l19, !tbaa !21
  store i32 -1, ptr %l20, !tbaa !23
  store i1 false, ptr %l21, !tbaa !21
  %t103 = call ptr @__olang_scope_hold(ptr %v0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l51, !tbaa !24
  %t105 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e17
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t107 = call ptr @__olang_region_make(ptr %v0)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l51, !tbaa !24
  br label %bb26
bb26:
  %t109 = load i64, ptr %l51
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %t110, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %l53
  br label %bb27
bb27:
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e17
  br i1 %t112, label %bb28, label %bb29
bb28:
  %t114 = load i64, ptr %l51
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = call ptr @__olang_region_or(ptr %t118, ptr null)
  %t120 = call ptr @__olang_region_home(ptr %t119)
  %t121 = icmp ne ptr %t120, null
  %t122 = select i1 %t121, ptr %t120, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t122)
  br label %bb29
bb29:
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %l22
  store i1 false, ptr %l23, !tbaa !21
  %t124 = call ptr @__olang_scope_hold(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l55, !tbaa !24
  %t126 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e19
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t128 = call ptr @__olang_region_make(ptr %v0)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l55, !tbaa !24
  br label %bb31
bb31:
  %t130 = load i64, ptr %l55
  %t131 = inttoptr i64 %t130 to ptr
  %t132 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t131, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l57
  br label %bb32
bb32:
  %t133 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e19
  br i1 %t133, label %bb33, label %bb34
bb33:
  %t135 = load i64, ptr %l55
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = call ptr @__olang_region_home(ptr %t140)
  %t142 = icmp ne ptr %t141, null
  %t143 = select i1 %t142, ptr %t141, ptr null
  call void @__olang_region_settle_in(ptr %t136, ptr %t143)
  br label %bb34
bb34:
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %l24
  %t145 = call ptr @__olang_scope_hold(ptr %v0)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l59, !tbaa !24
  %t147 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e20
  br i1 %t147, label %bb35, label %bb36
bb35:
  %t149 = call ptr @__olang_region_make(ptr %v0)
  %t150 = ptrtoint ptr %t149 to i64
  store i64 %t150, ptr %l59, !tbaa !24
  br label %bb36
bb36:
  %t151 = load i64, ptr %l59
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t152, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %l61
  br label %bb37
bb37:
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aBody_2e20
  br i1 %t154, label %bb38, label %bb39
bb38:
  %t156 = load i64, ptr %l59
  %t157 = inttoptr i64 %t156 to ptr
  %t158 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = call ptr @__olang_region_or(ptr %t160, ptr null)
  %t162 = call ptr @__olang_region_home(ptr %t161)
  %t163 = icmp ne ptr %t162, null
  %t164 = select i1 %t163, ptr %t162, ptr null
  call void @__olang_region_settle_in(ptr %t157, ptr %t164)
  br label %bb39
bb39:
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  %t166 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 0
  %t167 = load i32, ptr %l5, !tbaa !23
  store i32 %t167, ptr %t166, !tbaa !23
  %t168 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 1
  %t169 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t169, ptr %t168
  %t170 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 2
  %t171 = load i32, ptr %l7, !tbaa !23
  store i32 %t171, ptr %t170, !tbaa !23
  %t172 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 3
  %t173 = load i64, ptr %l8, !tbaa !24
  store i64 %t173, ptr %t172, !tbaa !24
  %t174 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 4
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %t174
  %t176 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 5
  %t177 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %t176
  %t178 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 6
  %t179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %t178
  %t180 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 7
  %t181 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %t180
  %t182 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 8
  %t183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183, ptr %t182
  %t184 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 9
  %t185 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t185, ptr %t184
  %t186 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 10
  %t187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187, ptr %t186
  %t188 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 11
  %t189 = load ptr, ptr %l16, !tbaa !29
  store ptr %t189, ptr %t188, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 12
  %t191 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t191, ptr %t190
  %t192 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 13
  %t193 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %t192
  %t194 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 14
  %t195 = load i1, ptr %l19, !tbaa !21
  store i1 %t195, ptr %t194, !tbaa !21
  %t196 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 15
  %t197 = load i32, ptr %l20, !tbaa !23
  store i32 %t197, ptr %t196, !tbaa !23
  %t198 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 16
  %t199 = load i1, ptr %l21, !tbaa !21
  store i1 %t199, ptr %t198, !tbaa !21
  %t200 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 17
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %t200
  %t202 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 18
  %t203 = load i1, ptr %l23, !tbaa !21
  store i1 %t203, ptr %t202, !tbaa !21
  %t204 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 19
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %t204
  %t206 = getelementptr %"compiler/typed:Body", ptr %l63, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %t206
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l63, i64 440, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aDropHolding_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"compiler/typed:DropHolding"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l7, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l9
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l7
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call ptr @__olang_scope_hold(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l11, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = call ptr @__olang_region_make(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l11
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t29, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l13
  br label %bb8
bb8:
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e1
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l11
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_region_or(ptr %t37, ptr null)
  %t39 = call ptr @__olang_region_home(ptr %t38)
  %t40 = icmp ne ptr %t39, null
  %t41 = select i1 %t40, ptr %t39, ptr null
  call void @__olang_region_settle_in(ptr %t34, ptr %t41)
  br label %bb10
bb10:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l1
  %t43 = call ptr @__olang_scope_hold(ptr %v0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l15, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e2
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = call ptr @__olang_region_make(ptr %v0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l15, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l15
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %t50, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l17
  br label %bb13
bb13:
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e2
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l15
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  call void @__olang_region_settle_in(ptr %t55, ptr %t62)
  br label %bb15
bb15:
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l2
  %t64 = call ptr @__olang_scope_hold(ptr %v0)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l19, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e3
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = call ptr @__olang_region_make(ptr %v0)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l19, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l19
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t71, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l21
  br label %bb18
bb18:
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e3
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t75 = load i64, ptr %l19
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = call ptr @__olang_region_or(ptr %t79, ptr null)
  %t81 = call ptr @__olang_region_home(ptr %t80)
  %t82 = icmp ne ptr %t81, null
  %t83 = select i1 %t82, ptr %t81, ptr null
  call void @__olang_region_settle_in(ptr %t76, ptr %t83)
  br label %bb20
bb20:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l3
  %t85 = call ptr @__olang_scope_hold(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l23, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e4
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = call ptr @__olang_region_make(ptr %v0)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l23, !tbaa !24
  br label %bb22
bb22:
  %t91 = load i64, ptr %l23
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t92, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l25
  br label %bb23
bb23:
  %t94 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e4
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l23
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t104)
  br label %bb25
bb25:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l4
  %t106 = call ptr @__olang_scope_hold(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l27, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e5
  br i1 %t108, label %bb26, label %bb27
bb26:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l27, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l27
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t113, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l29
  br label %bb28
bb28:
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e5
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load i64, ptr %l27
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr null
  call void @__olang_region_settle_in(ptr %t118, ptr %t125)
  br label %bb30
bb30:
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %l5
  %t127 = call ptr @__olang_scope_hold(ptr %v0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l31, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e6
  br i1 %t129, label %bb31, label %bb32
bb31:
  %t131 = call ptr @__olang_region_make(ptr %v0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l31, !tbaa !24
  br label %bb32
bb32:
  %t133 = load i64, ptr %l31
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t134, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l33
  br label %bb33
bb33:
  %t136 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e6
  br i1 %t136, label %bb34, label %bb35
bb34:
  %t138 = load i64, ptr %l31
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = call ptr @__olang_region_or(ptr %t142, ptr null)
  %t144 = call ptr @__olang_region_home(ptr %t143)
  %t145 = icmp ne ptr %t144, null
  %t146 = select i1 %t145, ptr %t144, ptr null
  call void @__olang_region_settle_in(ptr %t139, ptr %t146)
  br label %bb35
bb35:
  %t147 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t148 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 0
  %t149 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %t148
  %t150 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 1
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %t150
  %t152 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 2
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %t152
  %t154 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 3
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %t154
  %t156 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 4
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %t156
  %t158 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 5
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %t158
  %t160 = getelementptr %"compiler/typed:DropHolding", ptr %l35, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %t160
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l35, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aLandings_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l64 = alloca i64
  %l66 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l68 = alloca i64
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i64
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca i64
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca i64
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca i64
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca %"compiler/typed:Landings"
  %t47 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = call ptr @__olang_scope_hold(ptr %v3)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l31, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e3
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = call ptr @__olang_region_make(ptr %v3)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l31, !tbaa !24
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l34, !tbaa !24
  %t16 = load i64, ptr %l34, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l34, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = load i64, ptr %l31
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_scope_alloc_zeroed(ptr %t22, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v3)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l37, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e4
  br i1 %t29, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6cac4c556ee1b7d9_257131421adb63ad)
  unreachable
bb5:
  %t31 = call ptr @__olang_region_make(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l37, !tbaa !24
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l40, !tbaa !24
  %t36 = load i64, ptr %l40, !tbaa !24
  %t37 = icmp sge i64 %t36, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load i64, ptr %l40, !tbaa !24
  %t40 = icmp sle i64 %t39, 1152921504606846975
  br i1 %t40, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_52c63b14e30804cc_be8191a117211c80)
  unreachable
bb9:
  %t42 = load i64, ptr %l40, !tbaa !24
  %t43 = mul i64 %t42, 8
  %t44 = load i64, ptr %l37
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call ptr @__olang_held_alloc(ptr %t45, i64 %t43)
  store i64 0, ptr %t47
  br label %fill.48
fill.48:
  %t51 = load i64, ptr %t47
  %t52 = icmp slt i64 %t51, %t42
  br i1 %t52, label %fillb.49, label %filld.50
fillb.49:
  %t53 = getelementptr i64, ptr %t46, i64 %t51
  store i64 -1, ptr %t53
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %t47
  br label %fill.48
filld.50:
  %t55 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t46, 1
  store { i64, ptr } %t56, ptr %l7, !tbaa !27
  %t58 = call ptr @__olang_scope_hold(ptr %v3)
  %t59 = ptrtoint ptr %t58 to i64
  store i64 %t59, ptr %l44, !tbaa !24
  %t60 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e5
  br i1 %t60, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_52c63b14e30804cc_be8191a117211c80)
  unreachable
bb11:
  %t62 = call ptr @__olang_region_make(ptr %v3)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l44, !tbaa !24
  br label %bb12
bb12:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l47, !tbaa !24
  %t67 = load i64, ptr %l47, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load i64, ptr %l47, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = load i64, ptr %l44
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %t73, i64 %t71)
  %t75 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t78 = call ptr @__olang_scope_hold(ptr %v3)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l50, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e6
  br i1 %t80, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_75ea3af438a3ca2f_999b6c305f7ce623)
  unreachable
bb15:
  %t82 = call ptr @__olang_region_make(ptr %v3)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l50, !tbaa !24
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l53, !tbaa !24
  %t87 = load i64, ptr %l53, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load i64, ptr %l53, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = load i64, ptr %l50
  %t93 = inttoptr i64 %t92 to ptr
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %t93, i64 %t91)
  %t95 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l9, !tbaa !27
  store i1 false, ptr %l10, !tbaa !21
  %t98 = call ptr @__olang_scope_hold(ptr %v3)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l56, !tbaa !24
  %t100 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e8
  br i1 %t100, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5a80d8a416bdb25a_ede72ef348da89ae)
  unreachable
bb19:
  %t102 = call ptr @__olang_region_make(ptr %v3)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l56, !tbaa !24
  br label %bb20
bb20:
  %t104 = load i64, ptr %l56
  %t105 = inttoptr i64 %t104 to ptr
  %t106 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ector(ptr %t105, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l58
  br label %bb21
bb21:
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e8
  br i1 %t107, label %bb22, label %bb23
bb22:
  %t109 = load i64, ptr %l56
  %t110 = inttoptr i64 %t109 to ptr
  %t111 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = call ptr @__olang_region_or(ptr %t113, ptr null)
  %t115 = call ptr @__olang_region_home(ptr %t114)
  %t116 = icmp ne ptr %t115, null
  %t117 = select i1 %t116, ptr %t115, ptr null
  call void @__olang_region_settle_in(ptr %t110, ptr %t117)
  br label %bb23
bb23:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t119 = call ptr @__olang_scope_hold(ptr %v3)
  %t120 = ptrtoint ptr %t119 to i64
  store i64 %t120, ptr %l60, !tbaa !24
  %t121 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e11
  br i1 %t121, label %bb24, label %bb25
bb24:
  %t123 = call ptr @__olang_region_make(ptr %v3)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t125 = load i64, ptr %l60
  %t126 = inttoptr i64 %t125 to ptr
  %t127 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t126)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t127, ptr %l62
  br label %bb26
bb26:
  %t128 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e11
  br i1 %t128, label %bb27, label %bb28
bb27:
  %t130 = load i64, ptr %l60
  %t131 = inttoptr i64 %t130 to ptr
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62, i32 0, i32 2
  %t133 = load { i64, ptr }, ptr %t132
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = call ptr @__olang_region_or(ptr %t134, ptr null)
  %t136 = call ptr @__olang_region_home(ptr %t135)
  %t137 = icmp ne ptr %t136, null
  %t138 = select i1 %t137, ptr %t136, ptr null
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62, i32 0, i32 1
  %t140 = load { i64, ptr }, ptr %t139
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = call ptr @__olang_region_or(ptr %t141, ptr null)
  %t143 = call ptr @__olang_region_home(ptr %t142)
  %t144 = icmp ne ptr %t143, null
  %t145 = select i1 %t144, ptr %t143, ptr %t138
  %t146 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = call ptr @__olang_region_home(ptr %t149)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr %t145
  call void @__olang_region_settle_in(ptr %t131, ptr %t152)
  br label %bb28
bb28:
  %t153 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t153, ptr %l14
  %t154 = call ptr @__olang_scope_hold(ptr %v3)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l64, !tbaa !24
  %t156 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e12
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t158 = call ptr @__olang_region_make(ptr %v3)
  %t159 = ptrtoint ptr %t158 to i64
  store i64 %t159, ptr %l64, !tbaa !24
  br label %bb30
bb30:
  %t160 = load i64, ptr %l64
  %t161 = inttoptr i64 %t160 to ptr
  %t162 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t161)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t162, ptr %l66
  br label %bb31
bb31:
  %t163 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e12
  br i1 %t163, label %bb32, label %bb33
bb32:
  %t165 = load i64, ptr %l64
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66, i32 0, i32 2
  %t168 = load { i64, ptr }, ptr %t167
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = call ptr @__olang_region_or(ptr %t169, ptr null)
  %t171 = call ptr @__olang_region_home(ptr %t170)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  %t174 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66, i32 0, i32 1
  %t175 = load { i64, ptr }, ptr %t174
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = call ptr @__olang_region_or(ptr %t176, ptr null)
  %t178 = call ptr @__olang_region_home(ptr %t177)
  %t179 = icmp ne ptr %t178, null
  %t180 = select i1 %t179, ptr %t178, ptr %t173
  %t181 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = call ptr @__olang_region_or(ptr %t183, ptr null)
  %t185 = call ptr @__olang_region_home(ptr %t184)
  %t186 = icmp ne ptr %t185, null
  %t187 = select i1 %t186, ptr %t185, ptr %t180
  call void @__olang_region_settle_in(ptr %t166, ptr %t187)
  br label %bb33
bb33:
  %t188 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l66
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t188, ptr %l15
  %t189 = call ptr @__olang_scope_hold(ptr %v3)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l68, !tbaa !24
  %t191 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e13
  br i1 %t191, label %bb34, label %bb35
bb34:
  %t193 = call ptr @__olang_region_make(ptr %v3)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l68, !tbaa !24
  br label %bb35
bb35:
  %t195 = load i64, ptr %l68
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t196, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %l70
  br label %bb36
bb36:
  %t198 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e13
  br i1 %t198, label %bb37, label %bb38
bb37:
  %t200 = load i64, ptr %l68
  %t201 = inttoptr i64 %t200 to ptr
  %t202 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 0
  %t203 = load { i64, ptr }, ptr %t202
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = call ptr @__olang_region_or(ptr %t204, ptr null)
  %t206 = call ptr @__olang_region_home(ptr %t205)
  %t207 = icmp ne ptr %t206, null
  %t208 = select i1 %t207, ptr %t206, ptr null
  call void @__olang_region_settle_in(ptr %t201, ptr %t208)
  br label %bb38
bb38:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l16
  %t210 = call ptr @__olang_scope_hold(ptr %v3)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l72, !tbaa !24
  %t212 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e14
  br i1 %t212, label %bb39, label %bb40
bb39:
  %t214 = call ptr @__olang_region_make(ptr %v3)
  %t215 = ptrtoint ptr %t214 to i64
  store i64 %t215, ptr %l72, !tbaa !24
  br label %bb40
bb40:
  %t216 = load i64, ptr %l72
  %t217 = inttoptr i64 %t216 to ptr
  %t218 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t217, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l74
  br label %bb41
bb41:
  %t219 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e14
  br i1 %t219, label %bb42, label %bb43
bb42:
  %t221 = load i64, ptr %l72
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = call ptr @__olang_region_home(ptr %t226)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr null
  call void @__olang_region_settle_in(ptr %t222, ptr %t229)
  br label %bb43
bb43:
  %t230 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l17
  %t231 = call ptr @__olang_scope_hold(ptr %v3)
  %t232 = ptrtoint ptr %t231 to i64
  store i64 %t232, ptr %l76, !tbaa !24
  %t233 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e15
  br i1 %t233, label %bb44, label %bb45
bb44:
  %t235 = call ptr @__olang_region_make(ptr %v3)
  %t236 = ptrtoint ptr %t235 to i64
  store i64 %t236, ptr %l76, !tbaa !24
  br label %bb45
bb45:
  %t237 = load i64, ptr %l76
  %t238 = inttoptr i64 %t237 to ptr
  %t239 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t238, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l78
  br label %bb46
bb46:
  %t240 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e15
  br i1 %t240, label %bb47, label %bb48
bb47:
  %t242 = load i64, ptr %l76
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78, i32 0, i32 0
  %t245 = load { i64, ptr }, ptr %t244
  %t246 = extractvalue { i64, ptr } %t245, 1
  %t247 = call ptr @__olang_region_or(ptr %t246, ptr null)
  %t248 = call ptr @__olang_region_home(ptr %t247)
  %t249 = icmp ne ptr %t248, null
  %t250 = select i1 %t249, ptr %t248, ptr null
  call void @__olang_region_settle_in(ptr %t243, ptr %t250)
  br label %bb48
bb48:
  %t251 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l18
  %t252 = call ptr @__olang_scope_hold(ptr %v3)
  %t253 = ptrtoint ptr %t252 to i64
  store i64 %t253, ptr %l80, !tbaa !24
  %t254 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e16
  br i1 %t254, label %bb49, label %bb50
bb49:
  %t256 = call ptr @__olang_region_make(ptr %v3)
  %t257 = ptrtoint ptr %t256 to i64
  store i64 %t257, ptr %l80, !tbaa !24
  br label %bb50
bb50:
  %t258 = load i64, ptr %l80
  %t259 = inttoptr i64 %t258 to ptr
  %t260 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t259, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %l82
  br label %bb51
bb51:
  %t261 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e16
  br i1 %t261, label %bb52, label %bb53
bb52:
  %t263 = load i64, ptr %l80
  %t264 = inttoptr i64 %t263 to ptr
  %t265 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82, i32 0, i32 0
  %t266 = load { i64, ptr }, ptr %t265
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = call ptr @__olang_region_or(ptr %t267, ptr null)
  %t269 = call ptr @__olang_region_home(ptr %t268)
  %t270 = icmp ne ptr %t269, null
  %t271 = select i1 %t270, ptr %t269, ptr null
  call void @__olang_region_settle_in(ptr %t264, ptr %t271)
  br label %bb53
bb53:
  %t272 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, ptr %l19
  %t273 = call ptr @__olang_scope_hold(ptr %v3)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l84, !tbaa !24
  %t275 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e17
  br i1 %t275, label %bb54, label %bb55
bb54:
  %t277 = call ptr @__olang_region_make(ptr %v3)
  %t278 = ptrtoint ptr %t277 to i64
  store i64 %t278, ptr %l84, !tbaa !24
  br label %bb55
bb55:
  %t279 = load i64, ptr %l84
  %t280 = inttoptr i64 %t279 to ptr
  %t281 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t280, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l86
  br label %bb56
bb56:
  %t282 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e17
  br i1 %t282, label %bb57, label %bb58
bb57:
  %t284 = load i64, ptr %l84
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t287 = load { i64, ptr }, ptr %t286
  %t288 = extractvalue { i64, ptr } %t287, 1
  %t289 = call ptr @__olang_region_or(ptr %t288, ptr null)
  %t290 = call ptr @__olang_region_home(ptr %t289)
  %t291 = icmp ne ptr %t290, null
  %t292 = select i1 %t291, ptr %t290, ptr null
  call void @__olang_region_settle_in(ptr %t285, ptr %t292)
  br label %bb58
bb58:
  %t293 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t293, ptr %l20
  %t294 = call ptr @__olang_scope_hold(ptr %v3)
  %t295 = ptrtoint ptr %t294 to i64
  store i64 %t295, ptr %l88, !tbaa !24
  %t296 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e18
  br i1 %t296, label %bb59, label %bb60
bb59:
  %t298 = call ptr @__olang_region_make(ptr %v3)
  %t299 = ptrtoint ptr %t298 to i64
  store i64 %t299, ptr %l88, !tbaa !24
  br label %bb60
bb60:
  %t300 = load i64, ptr %l88
  %t301 = inttoptr i64 %t300 to ptr
  %t302 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t301, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l90
  br label %bb61
bb61:
  %t303 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e18
  br i1 %t303, label %bb62, label %bb63
bb62:
  %t305 = load i64, ptr %l88
  %t306 = inttoptr i64 %t305 to ptr
  %t307 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t308 = load { i64, ptr }, ptr %t307
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = call ptr @__olang_region_or(ptr %t309, ptr null)
  %t311 = call ptr @__olang_region_home(ptr %t310)
  %t312 = icmp ne ptr %t311, null
  %t313 = select i1 %t312, ptr %t311, ptr null
  call void @__olang_region_settle_in(ptr %t306, ptr %t313)
  br label %bb63
bb63:
  %t314 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, ptr %l21
  %t315 = call ptr @__olang_scope_hold(ptr %v3)
  %t316 = ptrtoint ptr %t315 to i64
  store i64 %t316, ptr %l92, !tbaa !24
  %t317 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e19
  br i1 %t317, label %bb64, label %bb65
bb64:
  %t319 = call ptr @__olang_region_make(ptr %v3)
  %t320 = ptrtoint ptr %t319 to i64
  store i64 %t320, ptr %l92, !tbaa !24
  br label %bb65
bb65:
  %t321 = load i64, ptr %l92
  %t322 = inttoptr i64 %t321 to ptr
  %t323 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t322, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t323, ptr %l94
  br label %bb66
bb66:
  %t324 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e19
  br i1 %t324, label %bb67, label %bb68
bb67:
  %t326 = load i64, ptr %l92
  %t327 = inttoptr i64 %t326 to ptr
  %t328 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94, i32 0, i32 0
  %t329 = load { i64, ptr }, ptr %t328
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = call ptr @__olang_region_or(ptr %t330, ptr null)
  %t332 = call ptr @__olang_region_home(ptr %t331)
  %t333 = icmp ne ptr %t332, null
  %t334 = select i1 %t333, ptr %t332, ptr null
  call void @__olang_region_settle_in(ptr %t327, ptr %t334)
  br label %bb68
bb68:
  %t335 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t335, ptr %l22
  store i64 0, ptr %l23, !tbaa !24
  %t336 = call ptr @__olang_scope_hold(ptr %v3)
  %t337 = ptrtoint ptr %t336 to i64
  store i64 %t337, ptr %l96, !tbaa !24
  %t338 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e21
  br i1 %t338, label %bb69, label %bb70
bb69:
  %t340 = call ptr @__olang_region_make(ptr %v3)
  %t341 = ptrtoint ptr %t340 to i64
  store i64 %t341, ptr %l96, !tbaa !24
  br label %bb70
bb70:
  %t342 = load i64, ptr %l96
  %t343 = inttoptr i64 %t342 to ptr
  %t344 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t343, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %l98
  br label %bb71
bb71:
  %t345 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e21
  br i1 %t345, label %bb72, label %bb73
bb72:
  %t347 = load i64, ptr %l96
  %t348 = inttoptr i64 %t347 to ptr
  %t349 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98, i32 0, i32 0
  %t350 = load { i64, ptr }, ptr %t349
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = call ptr @__olang_region_or(ptr %t351, ptr null)
  %t353 = call ptr @__olang_region_home(ptr %t352)
  %t354 = icmp ne ptr %t353, null
  %t355 = select i1 %t354, ptr %t353, ptr null
  call void @__olang_region_settle_in(ptr %t348, ptr %t355)
  br label %bb73
bb73:
  %t356 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t356, ptr %l24
  %t357 = call ptr @__olang_scope_hold(ptr %v3)
  %t358 = ptrtoint ptr %t357 to i64
  store i64 %t358, ptr %l100, !tbaa !24
  %t359 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e22
  br i1 %t359, label %bb74, label %bb75
bb74:
  %t361 = call ptr @__olang_region_make(ptr %v3)
  %t362 = ptrtoint ptr %t361 to i64
  store i64 %t362, ptr %l100, !tbaa !24
  br label %bb75
bb75:
  %t363 = load i64, ptr %l100
  %t364 = inttoptr i64 %t363 to ptr
  %t365 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t364, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t365, ptr %l102
  br label %bb76
bb76:
  %t366 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e22
  br i1 %t366, label %bb77, label %bb78
bb77:
  %t368 = load i64, ptr %l100
  %t369 = inttoptr i64 %t368 to ptr
  %t370 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102, i32 0, i32 0
  %t371 = load { i64, ptr }, ptr %t370
  %t372 = extractvalue { i64, ptr } %t371, 1
  %t373 = call ptr @__olang_region_or(ptr %t372, ptr null)
  %t374 = call ptr @__olang_region_home(ptr %t373)
  %t375 = icmp ne ptr %t374, null
  %t376 = select i1 %t375, ptr %t374, ptr null
  call void @__olang_region_settle_in(ptr %t369, ptr %t376)
  br label %bb78
bb78:
  %t377 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t377, ptr %l25
  store i64 -1, ptr %l26, !tbaa !24
  %t378 = call ptr @__olang_scope_hold(ptr %v3)
  %t379 = ptrtoint ptr %t378 to i64
  store i64 %t379, ptr %l104, !tbaa !24
  %t380 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e24
  br i1 %t380, label %bb79, label %bb80
bb79:
  %t382 = call ptr @__olang_region_make(ptr %v3)
  %t383 = ptrtoint ptr %t382 to i64
  store i64 %t383, ptr %l104, !tbaa !24
  br label %bb80
bb80:
  %t384 = load i64, ptr %l104
  %t385 = inttoptr i64 %t384 to ptr
  %t386 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t385, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t386, ptr %l106
  br label %bb81
bb81:
  %t387 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLandings_2e24
  br i1 %t387, label %bb82, label %bb83
bb82:
  %t389 = load i64, ptr %l104
  %t390 = inttoptr i64 %t389 to ptr
  %t391 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106, i32 0, i32 0
  %t392 = load { i64, ptr }, ptr %t391
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = call ptr @__olang_region_or(ptr %t393, ptr null)
  %t395 = call ptr @__olang_region_home(ptr %t394)
  %t396 = icmp ne ptr %t395, null
  %t397 = select i1 %t396, ptr %t395, ptr null
  call void @__olang_region_settle_in(ptr %t390, ptr %t397)
  br label %bb83
bb83:
  %t398 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  %t399 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 0
  %t400 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t400, ptr %t399, !tbaa !27
  %t401 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 1
  %t402 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t402, ptr %t401, !tbaa !27
  %t403 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 2
  %t404 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t404, ptr %t403, !tbaa !27
  %t405 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 3
  %t406 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t406, ptr %t405, !tbaa !27
  %t407 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 4
  %t408 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t408, ptr %t407, !tbaa !27
  %t409 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 5
  %t410 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t410, ptr %t409, !tbaa !27
  %t411 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 6
  %t412 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t412, ptr %t411, !tbaa !27
  %t413 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 7
  %t414 = load i1, ptr %l10, !tbaa !21
  store i1 %t414, ptr %t413, !tbaa !21
  %t415 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 8
  %t416 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t416, ptr %t415
  %t417 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 9
  %t418 = load i64, ptr %l12, !tbaa !24
  store i64 %t418, ptr %t417, !tbaa !24
  %t419 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 10
  %t420 = load i64, ptr %l13, !tbaa !24
  store i64 %t420, ptr %t419, !tbaa !24
  %t421 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 11
  %t422 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t422, ptr %t421
  %t423 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 12
  %t424 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t424, ptr %t423
  %t425 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 13
  %t426 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t426, ptr %t425
  %t427 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 14
  %t428 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t428, ptr %t427
  %t429 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 15
  %t430 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t430, ptr %t429
  %t431 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 16
  %t432 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t432, ptr %t431
  %t433 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 17
  %t434 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t434, ptr %t433
  %t435 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 18
  %t436 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t436, ptr %t435
  %t437 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 19
  %t438 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t438, ptr %t437
  %t439 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 20
  %t440 = load i64, ptr %l23, !tbaa !24
  store i64 %t440, ptr %t439, !tbaa !24
  %t441 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 21
  %t442 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t442, ptr %t441
  %t443 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 22
  %t444 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t444, ptr %t443
  %t445 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 23
  %t446 = load i64, ptr %l26, !tbaa !24
  store i64 %t446, ptr %t445, !tbaa !24
  %t447 = getelementptr %"compiler/typed:Landings", ptr %l108, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %t447
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l108, i64 648, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aRefsKept_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"compiler/typed:RefsKept"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l7
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l5
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7, i32 0, i32 2
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  %t21 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr %t20
  %t28 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = call ptr @__olang_region_or(ptr %t30, ptr null)
  %t32 = call ptr @__olang_region_home(ptr %t31)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr %t27
  call void @__olang_region_settle_in(ptr %t13, ptr %t34)
  br label %bb5
bb5:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l0
  %t36 = call ptr @__olang_scope_hold(ptr %v0)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l9, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e1
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = call ptr @__olang_region_make(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l9
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t43)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %l11
  br label %bb8
bb8:
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e1
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l9
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr null
  %t56 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr %t55
  %t63 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr %t62
  call void @__olang_region_settle_in(ptr %t48, ptr %t69)
  br label %bb10
bb10:
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l1
  %t71 = call ptr @__olang_scope_hold(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l13, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e2
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = call ptr @__olang_region_make(ptr %v0)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l13
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t78)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %l15
  br label %bb13
bb13:
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e2
  br i1 %t80, label %bb14, label %bb15
bb14:
  %t82 = load i64, ptr %l13
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15, i32 0, i32 2
  %t85 = load { i64, ptr }, ptr %t84
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = call ptr @__olang_region_home(ptr %t87)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr null
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr %t90
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t97
  call void @__olang_region_settle_in(ptr %t83, ptr %t104)
  br label %bb15
bb15:
  %t105 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t105, ptr %l2
  store i64 9223372036854775807, ptr %l3, !tbaa !24
  %t106 = call ptr @__olang_scope_hold(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l17, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e4
  br i1 %t108, label %bb16, label %bb17
bb16:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l17, !tbaa !24
  br label %bb17
bb17:
  %t112 = load i64, ptr %l17
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t113)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %l19
  br label %bb18
bb18:
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e4
  br i1 %t115, label %bb19, label %bb20
bb19:
  %t117 = load i64, ptr %l17
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr null
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = call ptr @__olang_region_or(ptr %t128, ptr null)
  %t130 = call ptr @__olang_region_home(ptr %t129)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr %t125
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = call ptr @__olang_region_home(ptr %t136)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr %t132
  call void @__olang_region_settle_in(ptr %t118, ptr %t139)
  br label %bb20
bb20:
  %t140 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  %t141 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 0
  %t142 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t142, ptr %t141
  %t143 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 1
  %t144 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %t143
  %t145 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 2
  %t146 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %t145
  %t147 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 3
  %t148 = load i64, ptr %l3, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t140, ptr %t149
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l21, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aVersions_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l52 = alloca i64
  %l54 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca i64
  %l58 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca i64
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i64
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i64
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca %"compiler/typed:Versions"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  %t5 = call ptr @__olang_scope_hold(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l25, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v2)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l25, !tbaa !24
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l28, !tbaa !24
  %t14 = load i64, ptr %l28, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l28, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = load i64, ptr %l25
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %t20, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v2)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l31, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e3
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a650b38034a5180c_4858ad52e7b771b8)
  unreachable
bb5:
  %t29 = call ptr @__olang_region_make(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l31
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t32, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l33
  br label %bb7
bb7:
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e3
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l31
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr null)
  %t42 = call ptr @__olang_region_home(ptr %t41)
  %t43 = icmp ne ptr %t42, null
  %t44 = select i1 %t43, ptr %t42, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t44)
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l5
  %t46 = call ptr @__olang_scope_hold(ptr %v2)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l35, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e4
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = call ptr @__olang_region_make(ptr %v2)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l35, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l35
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t53, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l37
  br label %bb12
bb12:
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e4
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l35
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = call ptr @__olang_region_home(ptr %t62)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr null
  call void @__olang_region_settle_in(ptr %t58, ptr %t65)
  br label %bb14
bb14:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l6
  %t67 = call ptr @__olang_scope_hold(ptr %v2)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l39, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e5
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = call ptr @__olang_region_make(ptr %v2)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l39, !tbaa !24
  br label %bb16
bb16:
  %t73 = load i64, ptr %l39
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t74, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l41
  br label %bb17
bb17:
  %t76 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e5
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t78 = load i64, ptr %l39
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = call ptr @__olang_region_home(ptr %t83)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr null
  call void @__olang_region_settle_in(ptr %t79, ptr %t86)
  br label %bb19
bb19:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l7
  %t88 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l43
  br label %bb20
bb20:
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l8
  %t90 = call ptr @__olang_scope_hold(ptr %v2)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l44, !tbaa !24
  %t92 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e7
  br i1 %t92, label %bb21, label %bb22
bb21:
  %t94 = call ptr @__olang_region_make(ptr %v2)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l44, !tbaa !24
  br label %bb22
bb22:
  %t96 = load i64, ptr %l44
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t97, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %l46
  br label %bb23
bb23:
  %t99 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e7
  br i1 %t99, label %bb24, label %bb25
bb24:
  %t101 = load i64, ptr %l44
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = call ptr @__olang_region_or(ptr %t105, ptr null)
  %t107 = call ptr @__olang_region_home(ptr %t106)
  %t108 = icmp ne ptr %t107, null
  %t109 = select i1 %t108, ptr %t107, ptr null
  call void @__olang_region_settle_in(ptr %t102, ptr %t109)
  br label %bb25
bb25:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %l9
  %t111 = call ptr @__olang_scope_hold(ptr %v2)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l48, !tbaa !24
  %t113 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e8
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t115 = call ptr @__olang_region_make(ptr %v2)
  %t116 = ptrtoint ptr %t115 to i64
  store i64 %t116, ptr %l48, !tbaa !24
  br label %bb27
bb27:
  %t117 = load i64, ptr %l48
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t118)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t119, ptr %l50
  br label %bb28
bb28:
  %t120 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e8
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t122 = load i64, ptr %l48
  %t123 = inttoptr i64 %t122 to ptr
  %t124 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = call ptr @__olang_region_or(ptr %t126, ptr null)
  %t128 = call ptr @__olang_region_home(ptr %t127)
  %t129 = icmp ne ptr %t128, null
  %t130 = select i1 %t129, ptr %t128, ptr null
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = call ptr @__olang_region_or(ptr %t133, ptr null)
  %t135 = call ptr @__olang_region_home(ptr %t134)
  %t136 = icmp ne ptr %t135, null
  %t137 = select i1 %t136, ptr %t135, ptr %t130
  %t138 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = call ptr @__olang_region_or(ptr %t140, ptr null)
  %t142 = call ptr @__olang_region_home(ptr %t141)
  %t143 = icmp ne ptr %t142, null
  %t144 = select i1 %t143, ptr %t142, ptr %t137
  call void @__olang_region_settle_in(ptr %t123, ptr %t144)
  br label %bb30
bb30:
  %t145 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t145, ptr %l10
  %t146 = call ptr @__olang_scope_hold(ptr %v2)
  %t147 = ptrtoint ptr %t146 to i64
  store i64 %t147, ptr %l52, !tbaa !24
  %t148 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e9
  br i1 %t148, label %bb31, label %bb32
bb31:
  %t150 = call ptr @__olang_region_make(ptr %v2)
  %t151 = ptrtoint ptr %t150 to i64
  store i64 %t151, ptr %l52, !tbaa !24
  br label %bb32
bb32:
  %t152 = load i64, ptr %l52
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %t153)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t154, ptr %l54
  br label %bb33
bb33:
  %t155 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e9
  br i1 %t155, label %bb34, label %bb35
bb34:
  %t157 = load i64, ptr %l52
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = call ptr @__olang_region_or(ptr %t161, ptr null)
  %t163 = call ptr @__olang_region_home(ptr %t162)
  %t164 = icmp ne ptr %t163, null
  %t165 = select i1 %t164, ptr %t163, ptr null
  %t166 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54, i32 0, i32 1
  %t167 = load { i64, ptr }, ptr %t166
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = call ptr @__olang_region_or(ptr %t168, ptr null)
  %t170 = call ptr @__olang_region_home(ptr %t169)
  %t171 = icmp ne ptr %t170, null
  %t172 = select i1 %t171, ptr %t170, ptr %t165
  %t173 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = call ptr @__olang_region_or(ptr %t175, ptr null)
  %t177 = call ptr @__olang_region_home(ptr %t176)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr %t172
  call void @__olang_region_settle_in(ptr %t158, ptr %t179)
  br label %bb35
bb35:
  %t180 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t180, ptr %l11
  %t181 = call ptr @__olang_scope_hold(ptr %v2)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l56, !tbaa !24
  %t183 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e10
  br i1 %t183, label %bb36, label %bb37
bb36:
  %t185 = call ptr @__olang_region_make(ptr %v2)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l56, !tbaa !24
  br label %bb37
bb37:
  %t187 = load i64, ptr %l56
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t188)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t189, ptr %l58
  br label %bb38
bb38:
  %t190 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e10
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load i64, ptr %l56
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 2
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = call ptr @__olang_region_home(ptr %t197)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  %t201 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 1
  %t202 = load { i64, ptr }, ptr %t201
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = call ptr @__olang_region_or(ptr %t203, ptr null)
  %t205 = call ptr @__olang_region_home(ptr %t204)
  %t206 = icmp ne ptr %t205, null
  %t207 = select i1 %t206, ptr %t205, ptr %t200
  %t208 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = call ptr @__olang_region_or(ptr %t210, ptr null)
  %t212 = call ptr @__olang_region_home(ptr %t211)
  %t213 = icmp ne ptr %t212, null
  %t214 = select i1 %t213, ptr %t212, ptr %t207
  call void @__olang_region_settle_in(ptr %t193, ptr %t214)
  br label %bb40
bb40:
  %t215 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t215, ptr %l12
  %t216 = call ptr @__olang_scope_hold(ptr %v2)
  %t217 = ptrtoint ptr %t216 to i64
  store i64 %t217, ptr %l60, !tbaa !24
  %t218 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e11
  br i1 %t218, label %bb41, label %bb42
bb41:
  %t220 = call ptr @__olang_region_make(ptr %v2)
  %t221 = ptrtoint ptr %t220 to i64
  store i64 %t221, ptr %l60, !tbaa !24
  br label %bb42
bb42:
  %t222 = load i64, ptr %l60
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t223, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l62
  br label %bb43
bb43:
  %t225 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e11
  br i1 %t225, label %bb44, label %bb45
bb44:
  %t227 = load i64, ptr %l60
  %t228 = inttoptr i64 %t227 to ptr
  %t229 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = call ptr @__olang_region_or(ptr %t231, ptr null)
  %t233 = call ptr @__olang_region_home(ptr %t232)
  %t234 = icmp ne ptr %t233, null
  %t235 = select i1 %t234, ptr %t233, ptr null
  call void @__olang_region_settle_in(ptr %t228, ptr %t235)
  br label %bb45
bb45:
  %t236 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %l13
  %t237 = call ptr @__olang_scope_hold(ptr %v2)
  %t238 = ptrtoint ptr %t237 to i64
  store i64 %t238, ptr %l64, !tbaa !24
  %t239 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e12
  br i1 %t239, label %bb46, label %bb47
bb46:
  %t241 = call ptr @__olang_region_make(ptr %v2)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l64, !tbaa !24
  br label %bb47
bb47:
  %t243 = load i64, ptr %l64
  %t244 = inttoptr i64 %t243 to ptr
  %t245 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t244, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t245, ptr %l66
  br label %bb48
bb48:
  %t246 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e12
  br i1 %t246, label %bb49, label %bb50
bb49:
  %t248 = load i64, ptr %l64
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = call ptr @__olang_region_or(ptr %t252, ptr null)
  %t254 = call ptr @__olang_region_home(ptr %t253)
  %t255 = icmp ne ptr %t254, null
  %t256 = select i1 %t255, ptr %t254, ptr null
  call void @__olang_region_settle_in(ptr %t249, ptr %t256)
  br label %bb50
bb50:
  %t257 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t257, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t258 = call ptr @__olang_scope_hold(ptr %v2)
  %t259 = ptrtoint ptr %t258 to i64
  store i64 %t259, ptr %l68, !tbaa !24
  %t260 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e14
  br i1 %t260, label %bb51, label %bb52
bb51:
  %t262 = call ptr @__olang_region_make(ptr %v2)
  %t263 = ptrtoint ptr %t262 to i64
  store i64 %t263, ptr %l68, !tbaa !24
  br label %bb52
bb52:
  %t264 = load i64, ptr %l68
  %t265 = inttoptr i64 %t264 to ptr
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t265, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l70
  br label %bb53
bb53:
  %t267 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e14
  br i1 %t267, label %bb54, label %bb55
bb54:
  %t269 = load i64, ptr %l68
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = call ptr @__olang_region_or(ptr %t273, ptr null)
  %t275 = call ptr @__olang_region_home(ptr %t274)
  %t276 = icmp ne ptr %t275, null
  %t277 = select i1 %t276, ptr %t275, ptr null
  call void @__olang_region_settle_in(ptr %t270, ptr %t277)
  br label %bb55
bb55:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l16
  %t279 = call ptr @__olang_scope_hold(ptr %v2)
  %t280 = ptrtoint ptr %t279 to i64
  store i64 %t280, ptr %l72, !tbaa !24
  %t281 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e15
  br i1 %t281, label %bb56, label %bb57
bb56:
  %t283 = call ptr @__olang_region_make(ptr %v2)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l72, !tbaa !24
  br label %bb57
bb57:
  %t285 = load i64, ptr %l72
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t286, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t287, ptr %l74
  br label %bb58
bb58:
  %t288 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e15
  br i1 %t288, label %bb59, label %bb60
bb59:
  %t290 = load i64, ptr %l72
  %t291 = inttoptr i64 %t290 to ptr
  %t292 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74, i32 0, i32 0
  %t293 = load { i64, ptr }, ptr %t292
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = call ptr @__olang_region_or(ptr %t294, ptr null)
  %t296 = call ptr @__olang_region_home(ptr %t295)
  %t297 = icmp ne ptr %t296, null
  %t298 = select i1 %t297, ptr %t296, ptr null
  call void @__olang_region_settle_in(ptr %t291, ptr %t298)
  br label %bb60
bb60:
  %t299 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t299, ptr %l17
  %t300 = call ptr @__olang_scope_hold(ptr %v2)
  %t301 = ptrtoint ptr %t300 to i64
  store i64 %t301, ptr %l76, !tbaa !24
  %t302 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e16
  br i1 %t302, label %bb61, label %bb62
bb61:
  %t304 = call ptr @__olang_region_make(ptr %v2)
  %t305 = ptrtoint ptr %t304 to i64
  store i64 %t305, ptr %l76, !tbaa !24
  br label %bb62
bb62:
  %t306 = load i64, ptr %l76
  %t307 = inttoptr i64 %t306 to ptr
  %t308 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t307, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %l78
  br label %bb63
bb63:
  %t309 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e16
  br i1 %t309, label %bb64, label %bb65
bb64:
  %t311 = load i64, ptr %l76
  %t312 = inttoptr i64 %t311 to ptr
  %t313 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78, i32 0, i32 0
  %t314 = load { i64, ptr }, ptr %t313
  %t315 = extractvalue { i64, ptr } %t314, 1
  %t316 = call ptr @__olang_region_or(ptr %t315, ptr null)
  %t317 = call ptr @__olang_region_home(ptr %t316)
  %t318 = icmp ne ptr %t317, null
  %t319 = select i1 %t318, ptr %t317, ptr null
  call void @__olang_region_settle_in(ptr %t312, ptr %t319)
  br label %bb65
bb65:
  %t320 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %l18
  %t321 = call ptr @__olang_scope_hold(ptr %v2)
  %t322 = ptrtoint ptr %t321 to i64
  store i64 %t322, ptr %l80, !tbaa !24
  %t323 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e17
  br i1 %t323, label %bb66, label %bb67
bb66:
  %t325 = call ptr @__olang_region_make(ptr %v2)
  %t326 = ptrtoint ptr %t325 to i64
  store i64 %t326, ptr %l80, !tbaa !24
  br label %bb67
bb67:
  %t327 = load i64, ptr %l80
  %t328 = inttoptr i64 %t327 to ptr
  %t329 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t328, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t329, ptr %l82
  br label %bb68
bb68:
  %t330 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e17
  br i1 %t330, label %bb69, label %bb70
bb69:
  %t332 = load i64, ptr %l80
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = call ptr @__olang_region_or(ptr %t336, ptr null)
  %t338 = call ptr @__olang_region_home(ptr %t337)
  %t339 = icmp ne ptr %t338, null
  %t340 = select i1 %t339, ptr %t338, ptr null
  call void @__olang_region_settle_in(ptr %t333, ptr %t340)
  br label %bb70
bb70:
  %t341 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t341, ptr %l19
  %t342 = call ptr @__olang_scope_hold(ptr %v2)
  %t343 = ptrtoint ptr %t342 to i64
  store i64 %t343, ptr %l84, !tbaa !24
  %t344 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e18
  br i1 %t344, label %bb71, label %bb72
bb71:
  %t346 = call ptr @__olang_region_make(ptr %v2)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l84, !tbaa !24
  br label %bb72
bb72:
  %t348 = load i64, ptr %l84
  %t349 = inttoptr i64 %t348 to ptr
  %t350 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t349, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t350, ptr %l86
  br label %bb73
bb73:
  %t351 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e18
  br i1 %t351, label %bb74, label %bb75
bb74:
  %t353 = load i64, ptr %l84
  %t354 = inttoptr i64 %t353 to ptr
  %t355 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t356 = load { i64, ptr }, ptr %t355
  %t357 = extractvalue { i64, ptr } %t356, 1
  %t358 = call ptr @__olang_region_or(ptr %t357, ptr null)
  %t359 = call ptr @__olang_region_home(ptr %t358)
  %t360 = icmp ne ptr %t359, null
  %t361 = select i1 %t360, ptr %t359, ptr null
  call void @__olang_region_settle_in(ptr %t354, ptr %t361)
  br label %bb75
bb75:
  %t362 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t362, ptr %l20
  %t363 = call ptr @__olang_scope_hold(ptr %v2)
  %t364 = ptrtoint ptr %t363 to i64
  store i64 %t364, ptr %l88, !tbaa !24
  %t365 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e19
  br i1 %t365, label %bb76, label %bb77
bb76:
  %t367 = call ptr @__olang_region_make(ptr %v2)
  %t368 = ptrtoint ptr %t367 to i64
  store i64 %t368, ptr %l88, !tbaa !24
  br label %bb77
bb77:
  %t369 = load i64, ptr %l88
  %t370 = inttoptr i64 %t369 to ptr
  %t371 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t370, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t371, ptr %l90
  br label %bb78
bb78:
  %t372 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aVersions_2e19
  br i1 %t372, label %bb79, label %bb80
bb79:
  %t374 = load i64, ptr %l88
  %t375 = inttoptr i64 %t374 to ptr
  %t376 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t377 = load { i64, ptr }, ptr %t376
  %t378 = extractvalue { i64, ptr } %t377, 1
  %t379 = call ptr @__olang_region_or(ptr %t378, ptr null)
  %t380 = call ptr @__olang_region_home(ptr %t379)
  %t381 = icmp ne ptr %t380, null
  %t382 = select i1 %t381, ptr %t380, ptr null
  call void @__olang_region_settle_in(ptr %t375, ptr %t382)
  br label %bb80
bb80:
  %t383 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t384 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 0
  %t385 = load ptr, ptr %l2, !tbaa !29
  store ptr %t385, ptr %t384, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t387, ptr %t386, !tbaa !27
  %t388 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 2
  %t389 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t389, ptr %t388, !tbaa !27
  %t390 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 3
  %t391 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t391, ptr %t390
  %t392 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 4
  %t393 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t393, ptr %t392
  %t394 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 5
  %t395 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %t394
  %t396 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 6
  %t397 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t397, ptr %t396
  %t398 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 7
  %t399 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t399, ptr %t398
  %t400 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 8
  %t401 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t401, ptr %t400
  %t402 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 9
  %t403 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t403, ptr %t402
  %t404 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 10
  %t405 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t405, ptr %t404
  %t406 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 11
  %t407 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t407, ptr %t406
  %t408 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 12
  %t409 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t409, ptr %t408
  %t410 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 13
  %t411 = load i64, ptr %l15, !tbaa !24
  store i64 %t411, ptr %t410, !tbaa !24
  %t412 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 14
  %t413 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t413, ptr %t412
  %t414 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 15
  %t415 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t415, ptr %t414
  %t416 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 16
  %t417 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t417, ptr %t416
  %t418 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 17
  %t419 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t419, ptr %t418
  %t420 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 18
  %t421 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t421, ptr %t420
  %t422 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383, ptr %t422
  %t424 = getelementptr %"compiler/typed:Versions", ptr %l92, i32 0, i32 20
  store i1 true, ptr %t424, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l92, i64 688, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aholdWalk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i64
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca i64
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca %"compiler/typed:holdWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = call ptr @__olang_scope_hold(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l21, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v2)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l21, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l21
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %t12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e2
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l21
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l4
  store i1 false, ptr %l5, !tbaa !21
  %t26 = call ptr @__olang_scope_hold(ptr %v2)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l25, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e4
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = call ptr @__olang_region_make(ptr %v2)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l25
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %t33, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l27
  br label %bb8
bb8:
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e4
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l25
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = call ptr @__olang_region_or(ptr %t41, ptr null)
  %t43 = call ptr @__olang_region_home(ptr %t42)
  %t44 = icmp ne ptr %t43, null
  %t45 = select i1 %t44, ptr %t43, ptr null
  call void @__olang_region_settle_in(ptr %t38, ptr %t45)
  br label %bb10
bb10:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l6
  %t47 = call ptr @__olang_scope_hold(ptr %v2)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l29, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e5
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = call ptr @__olang_region_make(ptr %v2)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l29
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %t54, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l31
  br label %bb13
bb13:
  %t56 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e5
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load i64, ptr %l29
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = call ptr @__olang_region_home(ptr %t63)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t66)
  br label %bb15
bb15:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l7
  %t68 = call ptr @__olang_scope_hold(ptr %v2)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l33, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e6
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = call ptr @__olang_region_make(ptr %v2)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l33, !tbaa !24
  br label %bb17
bb17:
  %t74 = load i64, ptr %l33
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t75, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l35
  br label %bb18
bb18:
  %t77 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e6
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t79 = load i64, ptr %l33
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = call ptr @__olang_region_or(ptr %t83, ptr null)
  %t85 = call ptr @__olang_region_home(ptr %t84)
  %t86 = icmp ne ptr %t85, null
  %t87 = select i1 %t86, ptr %t85, ptr null
  call void @__olang_region_settle_in(ptr %t80, ptr %t87)
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l8
  %t89 = call ptr @__olang_scope_hold(ptr %v2)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l37, !tbaa !24
  %t91 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e7
  br i1 %t91, label %bb21, label %bb22
bb21:
  %t93 = call ptr @__olang_region_make(ptr %v2)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l37, !tbaa !24
  br label %bb22
bb22:
  %t95 = load i64, ptr %l37
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t96, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l39
  br label %bb23
bb23:
  %t98 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e7
  br i1 %t98, label %bb24, label %bb25
bb24:
  %t100 = load i64, ptr %l37
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = call ptr @__olang_region_or(ptr %t104, ptr null)
  %t106 = call ptr @__olang_region_home(ptr %t105)
  %t107 = icmp ne ptr %t106, null
  %t108 = select i1 %t107, ptr %t106, ptr null
  call void @__olang_region_settle_in(ptr %t101, ptr %t108)
  br label %bb25
bb25:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l9
  %t110 = call ptr @__olang_scope_hold(ptr %v2)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l41, !tbaa !24
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e8
  br i1 %t112, label %bb26, label %bb27
bb26:
  %t114 = call ptr @__olang_region_make(ptr %v2)
  %t115 = ptrtoint ptr %t114 to i64
  store i64 %t115, ptr %l41, !tbaa !24
  br label %bb27
bb27:
  %t116 = load i64, ptr %l41
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t117, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l43
  br label %bb28
bb28:
  %t119 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e8
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l41
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = call ptr @__olang_region_or(ptr %t125, ptr null)
  %t127 = call ptr @__olang_region_home(ptr %t126)
  %t128 = icmp ne ptr %t127, null
  %t129 = select i1 %t128, ptr %t127, ptr null
  call void @__olang_region_settle_in(ptr %t122, ptr %t129)
  br label %bb30
bb30:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l10
  %t131 = call ptr @__olang_scope_hold(ptr %v2)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l45, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e9
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t135 = call ptr @__olang_region_make(ptr %v2)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l45, !tbaa !24
  br label %bb32
bb32:
  %t137 = load i64, ptr %l45
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t138, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l47
  br label %bb33
bb33:
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e9
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load i64, ptr %l45
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  %t145 = load { i64, ptr }, ptr %t144
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_region_or(ptr %t146, ptr null)
  %t148 = call ptr @__olang_region_home(ptr %t147)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  call void @__olang_region_settle_in(ptr %t143, ptr %t150)
  br label %bb35
bb35:
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l11
  %t152 = call ptr @__olang_scope_hold(ptr %v2)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l49, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e10
  br i1 %t154, label %bb36, label %bb37
bb36:
  %t156 = call ptr @__olang_region_make(ptr %v2)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l49, !tbaa !24
  br label %bb37
bb37:
  %t158 = load i64, ptr %l49
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t159, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %l51
  br label %bb38
bb38:
  %t161 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e10
  br i1 %t161, label %bb39, label %bb40
bb39:
  %t163 = load i64, ptr %l49
  %t164 = inttoptr i64 %t163 to ptr
  %t165 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = call ptr @__olang_region_home(ptr %t168)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_settle_in(ptr %t164, ptr %t171)
  br label %bb40
bb40:
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l12
  %t173 = call ptr @__olang_scope_hold(ptr %v2)
  %t174 = ptrtoint ptr %t173 to i64
  store i64 %t174, ptr %l53, !tbaa !24
  %t175 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e11
  br i1 %t175, label %bb41, label %bb42
bb41:
  %t177 = call ptr @__olang_region_make(ptr %v2)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l53, !tbaa !24
  br label %bb42
bb42:
  %t179 = load i64, ptr %l53
  %t180 = inttoptr i64 %t179 to ptr
  %t181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t180, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l55
  br label %bb43
bb43:
  %t182 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e11
  br i1 %t182, label %bb44, label %bb45
bb44:
  %t184 = load i64, ptr %l53
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = call ptr @__olang_region_or(ptr %t188, ptr null)
  %t190 = call ptr @__olang_region_home(ptr %t189)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t185, ptr %t192)
  br label %bb45
bb45:
  %t193 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l13
  %t194 = call ptr @__olang_scope_hold(ptr %v2)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l57, !tbaa !24
  %t196 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e12
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = call ptr @__olang_region_make(ptr %v2)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l57, !tbaa !24
  br label %bb47
bb47:
  %t200 = load i64, ptr %l57
  %t201 = inttoptr i64 %t200 to ptr
  %t202 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t201, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t202, ptr %l59
  br label %bb48
bb48:
  %t203 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e12
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = load i64, ptr %l57
  %t206 = inttoptr i64 %t205 to ptr
  %t207 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = call ptr @__olang_region_home(ptr %t210)
  %t212 = icmp ne ptr %t211, null
  %t213 = select i1 %t212, ptr %t211, ptr null
  call void @__olang_region_settle_in(ptr %t206, ptr %t213)
  br label %bb50
bb50:
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %l14
  %t215 = call ptr @__olang_scope_hold(ptr %v2)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l61, !tbaa !24
  %t217 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e13
  br i1 %t217, label %bb51, label %bb52
bb51:
  %t219 = call ptr @__olang_region_make(ptr %v2)
  %t220 = ptrtoint ptr %t219 to i64
  store i64 %t220, ptr %l61, !tbaa !24
  br label %bb52
bb52:
  %t221 = load i64, ptr %l61
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t222, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l63
  br label %bb53
bb53:
  %t224 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e13
  br i1 %t224, label %bb54, label %bb55
bb54:
  %t226 = load i64, ptr %l61
  %t227 = inttoptr i64 %t226 to ptr
  %t228 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63, i32 0, i32 0
  %t229 = load { i64, ptr }, ptr %t228
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = call ptr @__olang_region_or(ptr %t230, ptr null)
  %t232 = call ptr @__olang_region_home(ptr %t231)
  %t233 = icmp ne ptr %t232, null
  %t234 = select i1 %t233, ptr %t232, ptr null
  call void @__olang_region_settle_in(ptr %t227, ptr %t234)
  br label %bb55
bb55:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l15
  %t236 = call ptr @__olang_scope_hold(ptr %v2)
  %t237 = ptrtoint ptr %t236 to i64
  store i64 %t237, ptr %l65, !tbaa !24
  %t238 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e14
  br i1 %t238, label %bb56, label %bb57
bb56:
  %t240 = call ptr @__olang_region_make(ptr %v2)
  %t241 = ptrtoint ptr %t240 to i64
  store i64 %t241, ptr %l65, !tbaa !24
  br label %bb57
bb57:
  %t242 = load i64, ptr %l65
  %t243 = inttoptr i64 %t242 to ptr
  %t244 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %t243, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l67
  br label %bb58
bb58:
  %t245 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e14
  br i1 %t245, label %bb59, label %bb60
bb59:
  %t247 = load i64, ptr %l65
  %t248 = inttoptr i64 %t247 to ptr
  %t249 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = call ptr @__olang_region_or(ptr %t251, ptr null)
  %t253 = call ptr @__olang_region_home(ptr %t252)
  %t254 = icmp ne ptr %t253, null
  %t255 = select i1 %t254, ptr %t253, ptr null
  call void @__olang_region_settle_in(ptr %t248, ptr %t255)
  br label %bb60
bb60:
  %t256 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l16
  %t257 = call ptr @__olang_scope_hold(ptr %v2)
  %t258 = ptrtoint ptr %t257 to i64
  store i64 %t258, ptr %l69, !tbaa !24
  %t259 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e15
  br i1 %t259, label %bb61, label %bb62
bb61:
  %t261 = call ptr @__olang_region_make(ptr %v2)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l69, !tbaa !24
  br label %bb62
bb62:
  %t263 = load i64, ptr %l69
  %t264 = inttoptr i64 %t263 to ptr
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t264, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l71
  br label %bb63
bb63:
  %t266 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e15
  br i1 %t266, label %bb64, label %bb65
bb64:
  %t268 = load i64, ptr %l69
  %t269 = inttoptr i64 %t268 to ptr
  %t270 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = call ptr @__olang_region_or(ptr %t272, ptr null)
  %t274 = call ptr @__olang_region_home(ptr %t273)
  %t275 = icmp ne ptr %t274, null
  %t276 = select i1 %t275, ptr %t274, ptr null
  call void @__olang_region_settle_in(ptr %t269, ptr %t276)
  br label %bb65
bb65:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l17
  %t278 = call ptr @__olang_scope_hold(ptr %v2)
  %t279 = ptrtoint ptr %t278 to i64
  store i64 %t279, ptr %l73, !tbaa !24
  %t280 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e16
  br i1 %t280, label %bb66, label %bb67
bb66:
  %t282 = call ptr @__olang_region_make(ptr %v2)
  %t283 = ptrtoint ptr %t282 to i64
  store i64 %t283, ptr %l73, !tbaa !24
  br label %bb67
bb67:
  %t284 = load i64, ptr %l73
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t285, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t286, ptr %l75
  br label %bb68
bb68:
  %t287 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e16
  br i1 %t287, label %bb69, label %bb70
bb69:
  %t289 = load i64, ptr %l73
  %t290 = inttoptr i64 %t289 to ptr
  %t291 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_region_or(ptr %t293, ptr null)
  %t295 = call ptr @__olang_region_home(ptr %t294)
  %t296 = icmp ne ptr %t295, null
  %t297 = select i1 %t296, ptr %t295, ptr null
  call void @__olang_region_settle_in(ptr %t290, ptr %t297)
  br label %bb70
bb70:
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  %t299 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 0
  %t300 = load ptr, ptr %l2, !tbaa !29
  store ptr %t300, ptr %t299, !tbaa !29
  %t301 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 1
  %t302 = load ptr, ptr %l3, !tbaa !29
  store ptr %t302, ptr %t301, !tbaa !29
  %t303 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 2
  %t304 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t304, ptr %t303
  %t305 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 3
  %t306 = load i1, ptr %l5, !tbaa !21
  store i1 %t306, ptr %t305, !tbaa !21
  %t307 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 4
  %t308 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %t307
  %t309 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 5
  %t310 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %t309
  %t311 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 6
  %t312 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %t311
  %t313 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 7
  %t314 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, ptr %t313
  %t315 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 8
  %t316 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t316, ptr %t315
  %t317 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 9
  %t318 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t318, ptr %t317
  %t319 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 10
  %t320 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %t319
  %t321 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 11
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %t321
  %t323 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 12
  %t324 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t324, ptr %t323
  %t325 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 13
  %t326 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %t325
  %t327 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 14
  %t328 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %t327
  %t329 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 15
  %t330 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t330, ptr %t329
  %t331 = getelementptr %"compiler/typed:holdWalk", ptr %l77, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %t331
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l77, i64 472, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ||" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"P" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"O" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"D" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"R" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"D" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ||" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"r" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"d" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"t" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
define internal i1 @olang_lambda_53(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
@.d59 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 2}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d61 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"dispatch " }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d63 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"let L" }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d65 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assign " }>, align 8
@.d66 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"eval " }>, align 8
@.d68 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d69 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"else" }>, align 8
@.d70 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"loop" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"post" }>, align 8
@.d72 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"break" }>, align 8
@.d73 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"continue" }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d77 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d78 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raise " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d80 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"reraise " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 2}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

@.d81 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"exit " }>, align 8
@.d82 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d83 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"defer" }>, align 8
@.d84 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" try" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
@.d87 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"spawn " }>, align 8
@.d88 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d89 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"yield " }>, align 8
@.d90 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"suspend " }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@olang_2esole_2ecompiler_2ftyped_3aBody_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aBody_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aBody_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aBody_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aBody_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aBody_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aBody_2e20 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aDropHolding_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e4 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e11 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aLandings_2e12 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aLandings_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLandings_2e24 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e9 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aVersions_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aVersions_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aholdWalk_2e16 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
@.d93 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.Helper.Equal" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d94 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Helper.Hash" }>, align 8
@.d95 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.ExitKind.Unreachable" }>, align 8
@.d96 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.ExitKind.NullReached" }>, align 8
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_9640b30413567955_c65a1e6fb20cf981 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9 = external constant [0 x i8]
@olang_loc_22aea6a044f95e17_c10e152cae22b18b = external constant [0 x i8]
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aLocalUses_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3e253382f788b905_6ccfe79f085c7c71 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ePlan_2ereadHead(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_dc214fe2b685dd28_b709a607efcfda04 = external constant [0 x i8]
@olang_loc_5740aeca99b81243_3c36ec57b5a2df6f = external constant [0 x i8]
@olang_loc_69f10c2cb664a4e6_ae008f42658ef9f2 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_6900592c315792a9_d75ca3f288cd056d = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ereadRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3c, ptr %a3e, { i64, ptr } %a4)
@olang_loc_4b5d458aacbb0718_a8ad2bd2a7dc13cc = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ecb034f719e18c1b_985175307bfdc34f = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_198aad80d0550ab5_c06608159f163401 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_28655f8a56cf669d_dc60f62ebe04c639 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d36f57f073c6a2ff_232866ca740484ab = external constant [0 x i8]
@olang_loc_faea1712f2053751_ed9fc9ee56afb56d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_dac0899521d00a27_f5966ad5b7471ec3 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v0, ptr %v1, i32 %a0, ptr %a1c, ptr %a1e)
@olang_loc_afe89d4716bb52e8_bab84d91c7a69354 = external constant [0 x i8]
@olang_loc_f34835f3d61f57d9_feeccb0fe1526945 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_fc4a9e97a0375850_6fc32d1d5d28aa84 = external constant [0 x i8]
@olang_loc_57f1440b51b1670e_340f688d6d5dc432 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4c0069332dc3373a_9f4d81ed437fa5b6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hb773ac01a07f3f9e7f749c328573d0ee(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %v0, ptr %a0)
declare %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H7ff170222aba52a9798b1085ab00b195(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fiterator_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20std_2fprelude_2fv_H35a7352784077c26387f60e3d578bee5(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H05bdc185ea10b7cb65a89c49d4b056c8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5)
declare i1 @compiler_2ftyped_2erefParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
@G_2ecompiler_2ftyped_2eHanded = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_43c6edd5f3ea6aa2_25eece1f43523776 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8a2b699ea2f67509_3bce0390ecfabbdd = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_a872ad126d8d9744_e4960385d07a8740 = external constant [0 x i8]
@olang_loc_f34031efedf98c99_ae8fa248572091b5 = external constant [0 x i8]
@olang_loc_1baf36c5dd0b9bdd_a2c9e1d98e30c571 = external constant [0 x i8]
@olang_loc_49ff4d0dc0b12b63_5e68d9fa98bc7cb7 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H6a1e9f71e6394ce7f250c1dfd2eee93e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H3f302293c6f4c07a80dfb5e30c1500bf(ptr %v0, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H1914ebd8236b397314fec30d887725e8(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4b8ddca9d8f0d204_c8cf417eb9785a78 = external constant [0 x i8]
@olang_loc_f658218d2a233859_f81a26e56b3c591d = external constant [0 x i8]
@olang_loc_4c95fac740fe18b9_da00c3dfb70c298d = external constant [0 x i8]
@olang_loc_1ae239f8e5f7a55f_790ae28d8c0cd633 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_c0631815a77772a8_ad2a1d61fb1cdf14 = external constant [0 x i8]
@olang_loc_bb3d6fb8f9a8facd_6b23a8aabab7ea69 = external constant [0 x i8]
@olang_loc_cb0f3499142fc19d_d94490f94af5f129 = external constant [0 x i8]
@olang_loc_730e5d3857c59e23_64c21f8ca2d9dbaf = external constant [0 x i8]
@olang_loc_14162ea47c0c801c_ce4205068f01e790 = external constant [0 x i8]
@olang_loc_a93f600a1cb39be1_ee16d2dfcadba585 = external constant [0 x i8]
@olang_loc_f25a0dcb15ec66ae_41d78ed91c6395da = external constant [0 x i8]
@olang_loc_8726c5b979482c78_cdee9de0701e13e4 = external constant [0 x i8]
@olang_loc_456f0c0b74db68d5_29242d1724c8a7c1 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_1a9a85648681e97_fcf9d2fab7c32a6b = external constant [0 x i8]
@olang_loc_54fd08b205476dc4_657f8db756d05b08 = external constant [0 x i8]
@olang_loc_923c0e7922172d2c_3d5b7ddd1cd85e60 = external constant [0 x i8]
@olang_loc_3398753e62525e0a_a26aec7fb7dfed8e = external constant [0 x i8]
@olang_loc_8b9fe86f9939495b_ac6312ba480f0d67 = external constant [0 x i8]
@olang_loc_3f464ddbb91b0a38_82918aeeacdcc614 = external constant [0 x i8]
@olang_loc_29167372d5c184b0_5aaac5f2b3f16f1c = external constant [0 x i8]
@olang_loc_18d2a0b724f39c7e_37ab118f04dce49a = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_fb0720d2dfee7f_1f99818eb62f02f3 = external constant [0 x i8]
@olang_loc_3cd7aa482e25463c_a46dd5e6d10de4a0 = external constant [0 x i8]
@olang_loc_65fecb72da6e9be9_e6833fce5f1f4ea5 = external constant [0 x i8]
@olang_loc_313fe9555679a06f_fa589a226c49c6eb = external constant [0 x i8]
@olang_loc_f3df993f4c7e1fd4_8419908bae6ac650 = external constant [0 x i8]
@olang_loc_e306d5ccad957c29_6b95b0de26f94a45 = external constant [0 x i8]
@olang_loc_d73b6870bbe51a4d_d845c63f23993221 = external constant [0 x i8]
@olang_loc_2545ce011bc2e3f3_a4cac8bc0a2d8747 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2cf1608fd5d1230c_1374e48cd144e348 = external constant [0 x i8]
@olang_loc_73be6a0e490978a7_b5fa18d3e7eede33 = external constant [0 x i8]
@olang_loc_2fb6091d652311b2_1c71a9a414fce87e = external constant [0 x i8]
@olang_loc_8c1b8241682c8a5c_1491e83e9da6f28 = external constant [0 x i8]
@olang_loc_4fc9df9522ae1330_697d53c50db00ce4 = external constant [0 x i8]
@olang_loc_e4195c8d52320dab_6e5abcaf8844f88f = external constant [0 x i8]
@olang_loc_6df7d27e20fc18e6_9af88db0bee394aa = external constant [0 x i8]
@olang_loc_c52364142dc414a0_4d1da6470710a144 = external constant [0 x i8]
@olang_loc_a6cbf8c37e7b58e4_127b3a96b1e2c730 = external constant [0 x i8]
@olang_loc_899e4ae5152e7c8f_c8d5ce57c54889ab = external constant [0 x i8]
@olang_loc_cdd2e50680d68485_7d51e204495f7309 = external constant [0 x i8]
@olang_loc_2ee7063c57fe9793_68bf97cc73752027 = external constant [0 x i8]
@olang_loc_be8b3c6aa0377e2b_acae2459f1c4a24f = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2676a1f2cfb255f8_2530c83c98e00394 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_10efe43793a641ac_2dabf1c43cd6a168 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b80660129801afa0_e660219d512f014 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4e96dfdde30f8206_e09e7eb6a314a8ba = external constant [0 x i8]
@olang_loc_4c49c2cc391943fc_885b7fff3b4a3180 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_7b432bbe8f05f1d7_7deffd42aa472253 = external constant [0 x i8]
@olang_loc_78afbb313fff45b8_957466907ebeb484 = external constant [0 x i8]
@olang_loc_90a2a4daf32abd74_d37804826367c570 = external constant [0 x i8]
@olang_loc_48b93bf05ad91c8c_dfcbf93f670f6050 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHeldParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f30894d45741e677_8f67e2978087020b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_6cac4c556ee1b7d9_257131421adb63ad = external constant [0 x i8]
@olang_loc_52c63b14e30804cc_be8191a117211c80 = external constant [0 x i8]
@olang_loc_75ea3af438a3ca2f_999b6c305f7ce623 = external constant [0 x i8]
@olang_loc_5a80d8a416bdb25a_ede72ef348da89ae = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_a650b38034a5180c_4858ad52e7b771b8 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
