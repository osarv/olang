; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/views:summary" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/views:place" = type { { i64, [2 x i64] }, i64, i64, i1 }
%"compiler/views:state" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/views:holding" = type { i64, %"compiler/views:view" }
%"compiler/views:view" = type { %"compiler/views:place", i64, i1, %"compiler/source:Span", i64, i64, %"compiler/source:Span", i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/views:fact" = type { i64, i64, i32, i64, i64, i1, i64, %"compiler/source:Span", i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/views:tasked" = type { %"compiler/views:view", %"compiler/source:Span" }
%"compiler/views:loopFrame" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/views:naming" = type { i64, %"compiler/views:place" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
@G_2ecompiler_2fviews_2eElemSeg = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fviews_2eElemSeg.k1 }>, align 8
@G_2ecompiler_2fviews_2eElemSeg.k1 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\5B\2E\2E\2E\5D" }>, align 8
define dso_local ptr @compiler_2fviews_2eargPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fviews_2eunAway(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb10
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l5, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a5e6daec8976db0_405389cf00db76ac)
  unreachable
bb16:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t28, ptr %a1)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Alt", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t33, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t66, ptr %t68)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Arm", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Arm", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l129 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l151 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l188 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %l245 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l257 = alloca i1
  %l270 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l297 = alloca ptr
  %l298 = alloca i1
  %l314 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l339 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca i1
  %l357 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca i1
  %l375 = alloca ptr
  %l376 = alloca i1
  %l389 = alloca { i64, ptr }
  %l392 = alloca ptr
  %l393 = alloca i1
  %l403 = alloca ptr
  %l404 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t6 = load ptr, ptr %l64, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l64, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l65, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l65, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t21 = load ptr, ptr %l70, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l70, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l71, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l71, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t36 = load ptr, ptr %l76, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l76, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l77, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l77, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t50, ptr %t52)
  br label %bb17
bb17:
  br label %bb233
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t56 = load ptr, ptr %l85, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l85, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l86, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l86, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Promote", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t73, ptr %t75)
  br label %bb24
bb24:
  br label %bb233
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t79 = load ptr, ptr %l95, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l95, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l96, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l96, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb57
bb30:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Call", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l5, !tbaa !29
  %t98 = load ptr, ptr %l5, !tbaa !29
  store ptr %t98, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t99 = load ptr, ptr %l103, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l103, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 5}
  %t105 = icmp eq i64 %t103, 0
  store i1 %t105, ptr %l104, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l104, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { i32 }, ptr %t109, i32 0, i32 0
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l6, !tbaa !23
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load i32, ptr %l6, !tbaa !23
  %t116 = sext i32 %t114 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t113, i64 %t116)
  br label %bb36
bb36:
  br label %bb49
bb37:
  %t119 = load ptr, ptr %l5, !tbaa !29
  store ptr %t119, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t120 = load ptr, ptr %l112, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l112, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 5}
  %t126 = icmp eq i64 %t124, 2
  store i1 %t126, ptr %l113, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l113, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { ptr }, ptr %t130, i32 0, i32 0
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l7, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t134 = load ptr, ptr %l7, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t134, ptr %t136)
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_3cbb6fb3b51c25bd_1e9ab5921d6290d1)
  unreachable
bb49:
  %t139 = load ptr, ptr %l4, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Call", ptr %t139, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  %t148 = load i64, ptr %l9, !tbaa !24
  %t149 = load i64, ptr %l10, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb51, label %bb52
bb51:
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t156 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t156, ptr %l129, !tbaa !27
  %t157 = load i64, ptr %l9, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr ptr, ptr %t160, i64 %t157
  %t162 = load ptr, ptr %t161, !tbaa !39
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t162, ptr %t166)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t169 = load i64, ptr %l9, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l9, !tbaa !24
  br label %bb50
bb56:
  br label %bb233
bb57:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t174 = load ptr, ptr %l137, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb58, label %bb59
bb58:
  %t177 = load ptr, ptr %l137, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 18}
  %t180 = icmp eq i64 %t178, 7
  store i1 %t180, ptr %l138, !tbaa !21
  br label %bb59
bb59:
  %t181 = load i1, ptr %l138, !tbaa !21
  br i1 %t181, label %bb60, label %bb61
bb60:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t188 = load ptr, ptr %l12, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Make", ptr %t188, i32 0, i32 2
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l15, !tbaa !24
  br label %bb63
bb63:
  %t197 = load i64, ptr %l14, !tbaa !24
  %t198 = load i64, ptr %l15, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb64, label %bb65
bb64:
  br label %bb69
bb65:
  br label %bb66
bb66:
  %t205 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t205, ptr %l151, !tbaa !27
  %t206 = load i64, ptr %l14, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t215 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t211, ptr %t215)
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t218 = load i64, ptr %l14, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l14, !tbaa !24
  br label %bb63
bb69:
  %t222 = load ptr, ptr %l12, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Make", ptr %t222, i32 0, i32 3
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t225, ptr %t226)
  br label %bb70
bb70:
  br label %bb233
bb71:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t230 = load ptr, ptr %l162, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb72, label %bb73
bb72:
  %t233 = load ptr, ptr %l162, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 18}
  %t236 = icmp eq i64 %t234, 8
  store i1 %t236, ptr %l163, !tbaa !21
  br label %bb73
bb73:
  %t237 = load i1, ptr %l163, !tbaa !21
  br i1 %t237, label %bb74, label %bb75
bb74:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l17, !tbaa !29
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t244 = load ptr, ptr %l17, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Collect", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  br label %bb77
bb77:
  %t251 = load ptr, ptr %l17, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Collect", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t254, ptr %t256)
  br label %bb78
bb78:
  br label %bb233
bb79:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t260 = load ptr, ptr %l175, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb80, label %bb81
bb80:
  %t263 = load ptr, ptr %l175, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 9
  store i1 %t266, ptr %l176, !tbaa !21
  br label %bb81
bb81:
  %t267 = load i1, ptr %l176, !tbaa !21
  br i1 %t267, label %bb82, label %bb83
bb82:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t270, i32 0, i32 4
  %t272 = load { i64, ptr }, ptr %t271
  store { i64, ptr } %t272, ptr %l18, !tbaa !27
  br label %bb84
bb83:
  br label %bb92
bb84:
  %t274 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t274, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  store i64 %t278, ptr %l21, !tbaa !24
  br label %bb85
bb85:
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = load i64, ptr %l21, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb86, label %bb87
bb86:
  br label %bb91
bb87:
  br label %bb88
bb88:
  %t288 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t288, ptr %l188, !tbaa !27
  %t289 = load i64, ptr %l20, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 %t289
  %t294 = load ptr, ptr %t293, !tbaa !39
  %t298 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t294, ptr %t298)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t301 = load i64, ptr %l20, !tbaa !24
  %t303 = add i64 %t301, 1
  store i64 %t303, ptr %l20, !tbaa !24
  br label %bb85
bb91:
  br label %bb233
bb92:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t306 = load ptr, ptr %l196, !tbaa !29
  %t307 = icmp ne ptr %t306, null
  br i1 %t307, label %bb93, label %bb94
bb93:
  %t309 = load ptr, ptr %l196, !tbaa !29
  %t310 = load i64, ptr %t309, !range !{i64 0, i64 18}
  %t312 = icmp eq i64 %t310, 10
  store i1 %t312, ptr %l197, !tbaa !21
  br label %bb94
bb94:
  %t313 = load i1, ptr %l197, !tbaa !21
  br i1 %t313, label %bb95, label %bb96
bb95:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t316, i32 0, i32 2
  %t318 = load ptr, ptr %t317
  store ptr %t318, ptr %l23, !tbaa !29
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t320 = load ptr, ptr %l23, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Slice", ptr %t320, i32 0, i32 0
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t323, ptr %t325)
  br label %bb98
bb98:
  %t328 = load ptr, ptr %l23, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Slice", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t331, ptr %t333)
  br label %bb99
bb99:
  %t336 = load ptr, ptr %l23, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Slice", ptr %t336, i32 0, i32 2
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t339, ptr %t341)
  br label %bb100
bb100:
  br label %bb233
bb101:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t345 = load ptr, ptr %l214, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb102, label %bb103
bb102:
  %t348 = load ptr, ptr %l214, !tbaa !29
  %t349 = load i64, ptr %t348, !range !{i64 0, i64 18}
  %t351 = icmp eq i64 %t349, 11
  store i1 %t351, ptr %l215, !tbaa !21
  br label %bb103
bb103:
  %t352 = load i1, ptr %l215, !tbaa !21
  br i1 %t352, label %bb104, label %bb105
bb104:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l24, !tbaa !29
  br label %bb106
bb105:
  br label %bb110
bb106:
  %t359 = load ptr, ptr %l24, !tbaa !29
  %t361 = getelementptr %"compiler/typed:Cond", ptr %t359, i32 0, i32 0
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t364 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t362, ptr %t364)
  br label %bb107
bb107:
  %t367 = load ptr, ptr %l24, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Cond", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb108
bb108:
  %t374 = load ptr, ptr %l24, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Cond", ptr %t374, i32 0, i32 2
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t377, ptr %t379)
  br label %bb109
bb109:
  br label %bb233
bb110:
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t383 = load ptr, ptr %l231, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb111, label %bb112
bb111:
  %t386 = load ptr, ptr %l231, !tbaa !29
  %t387 = load i64, ptr %t386, !range !{i64 0, i64 18}
  %t389 = icmp eq i64 %t387, 12
  store i1 %t389, ptr %l232, !tbaa !21
  br label %bb112
bb112:
  %t390 = load i1, ptr %l232, !tbaa !21
  br i1 %t390, label %bb113, label %bb114
bb113:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr { i64, [5 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t393, i32 0, i32 2
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l25, !tbaa !29
  br label %bb115
bb114:
  br label %bb124
bb115:
  %t397 = load ptr, ptr %l25, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Seq", ptr %t397, i32 0, i32 0
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  store { i64, ptr } %t400, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t402 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 0
  store i64 %t404, ptr %l28, !tbaa !24
  br label %bb116
bb116:
  %t406 = load i64, ptr %l27, !tbaa !24
  %t407 = load i64, ptr %l28, !tbaa !24
  %t410 = icmp slt i64 %t406, %t407
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb117, label %bb118
bb117:
  br label %bb122
bb118:
  br label %bb119
bb119:
  %t414 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t414, ptr %l245, !tbaa !27
  %t415 = load i64, ptr %l27, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr ptr, ptr %t418, i64 %t415
  %t420 = load ptr, ptr %t419, !tbaa !39
  %t424 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t420, ptr %t424)
  br label %bb120
bb120:
  br label %bb121
bb121:
  %t427 = load i64, ptr %l27, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l27, !tbaa !24
  br label %bb116
bb122:
  %t431 = load ptr, ptr %l25, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Seq", ptr %t431, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t435 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t434, ptr %t435)
  br label %bb123
bb123:
  br label %bb233
bb124:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t439 = load ptr, ptr %l256, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  br i1 %t440, label %bb125, label %bb126
bb125:
  %t442 = load ptr, ptr %l256, !tbaa !29
  %t443 = load i64, ptr %t442, !range !{i64 0, i64 18}
  %t445 = icmp eq i64 %t443, 13
  store i1 %t445, ptr %l257, !tbaa !21
  br label %bb126
bb126:
  %t446 = load i1, ptr %l257, !tbaa !21
  br i1 %t446, label %bb127, label %bb128
bb127:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t449, i32 0, i32 2
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l30, !tbaa !29
  br label %bb129
bb128:
  br label %bb145
bb129:
  %t453 = load ptr, ptr %l30, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Match", ptr %t453, i32 0, i32 0
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  store { i64, ptr } %t456, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t458 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  store i64 %t460, ptr %l33, !tbaa !24
  br label %bb130
bb130:
  %t462 = load i64, ptr %l32, !tbaa !24
  %t463 = load i64, ptr %l33, !tbaa !24
  %t466 = icmp slt i64 %t462, %t463
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb131, label %bb132
bb131:
  br label %bb136
bb132:
  br label %bb133
bb133:
  %t470 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t470, ptr %l270, !tbaa !27
  %t471 = load i64, ptr %l32, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr ptr, ptr %t474, i64 %t471
  %t476 = load ptr, ptr %t475, !tbaa !39
  %t480 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t476, ptr %t480)
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t483 = load i64, ptr %l32, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l32, !tbaa !24
  br label %bb130
bb136:
  %t487 = load ptr, ptr %l30, !tbaa !29
  %t489 = getelementptr %"compiler/typed:Match", ptr %t487, i32 0, i32 1
  %t490 = load { i64, ptr }, ptr %t489, !tbaa !27
  store { i64, ptr } %t490, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t492 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t492, 0
  store i64 %t494, ptr %l37, !tbaa !24
  br label %bb137
bb137:
  %t496 = load i64, ptr %l36, !tbaa !24
  %t497 = load i64, ptr %l37, !tbaa !24
  %t500 = icmp slt i64 %t496, %t497
  %t502 = xor i1 %t500, true
  br i1 %t502, label %bb138, label %bb139
bb138:
  br label %bb143
bb139:
  br label %bb140
bb140:
  %t504 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t504, ptr %l286, !tbaa !27
  %t505 = load i64, ptr %l36, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr ptr, ptr %t508, i64 %t505
  %t510 = load ptr, ptr %t509, !tbaa !39
  %t514 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %t510, ptr %t514)
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t517 = load i64, ptr %l36, !tbaa !24
  %t519 = add i64 %t517, 1
  store i64 %t519, ptr %l36, !tbaa !24
  br label %bb137
bb143:
  %t521 = load ptr, ptr %l30, !tbaa !29
  %t523 = getelementptr %"compiler/typed:Match", ptr %t521, i32 0, i32 2
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t525 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %t524, ptr %t525)
  br label %bb144
bb144:
  br label %bb233
bb145:
  %t528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t528, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t529 = load ptr, ptr %l297, !tbaa !29
  %t530 = icmp ne ptr %t529, null
  br i1 %t530, label %bb146, label %bb147
bb146:
  %t532 = load ptr, ptr %l297, !tbaa !29
  %t533 = load i64, ptr %t532, !range !{i64 0, i64 18}
  %t535 = icmp eq i64 %t533, 14
  store i1 %t535, ptr %l298, !tbaa !21
  br label %bb147
bb147:
  %t536 = load i1, ptr %l298, !tbaa !21
  br i1 %t536, label %bb148, label %bb149
bb148:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr { i64, [5 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t539, i32 0, i32 2
  %t541 = load ptr, ptr %t540
  store ptr %t541, ptr %l39, !tbaa !29
  br label %bb150
bb149:
  br label %bb166
bb150:
  %t543 = load ptr, ptr %l39, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Try", ptr %t543, i32 0, i32 0
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t547 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t546, ptr %t547)
  br label %bb151
bb151:
  %t550 = load ptr, ptr %l39, !tbaa !29
  %t552 = getelementptr %"compiler/typed:Try", ptr %t550, i32 0, i32 1
  %t553 = load { i64, ptr }, ptr %t552, !tbaa !27
  store { i64, ptr } %t553, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t555 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t555, 0
  store i64 %t557, ptr %l42, !tbaa !24
  br label %bb152
bb152:
  %t559 = load i64, ptr %l41, !tbaa !24
  %t560 = load i64, ptr %l42, !tbaa !24
  %t563 = icmp slt i64 %t559, %t560
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb153, label %bb154
bb153:
  br label %bb165
bb154:
  br label %bb155
bb155:
  %t567 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t567, ptr %l314, !tbaa !27
  %t568 = load i64, ptr %l41, !tbaa !24
  %t570 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !27
  %t572 = getelementptr ptr, ptr %t571, i64 %t568
  %t573 = load ptr, ptr %t572, !tbaa !39
  store ptr %t573, ptr %l43, !tbaa !29
  %t575 = load ptr, ptr %l43, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Clause", ptr %t575, i32 0, i32 3
  %t578 = load ptr, ptr %t577, !tbaa !29
  %t579 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t578, ptr %t579)
  br label %bb156
bb156:
  %t582 = load ptr, ptr %l43, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Clause", ptr %t582, i32 0, i32 4
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t587 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t587, 0
  store i64 %t589, ptr %l46, !tbaa !24
  br label %bb157
bb157:
  %t591 = load i64, ptr %l45, !tbaa !24
  %t592 = load i64, ptr %l46, !tbaa !24
  %t595 = icmp slt i64 %t591, %t592
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb158, label %bb159
bb158:
  br label %bb163
bb159:
  br label %bb160
bb160:
  %t599 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t599, ptr %l328, !tbaa !27
  %t600 = load i64, ptr %l45, !tbaa !24
  %t602 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr ptr, ptr %t603, i64 %t600
  %t605 = load ptr, ptr %t604, !tbaa !39
  %t609 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t605, ptr %t609)
  br label %bb161
bb161:
  br label %bb162
bb162:
  %t612 = load i64, ptr %l45, !tbaa !24
  %t614 = add i64 %t612, 1
  store i64 %t614, ptr %l45, !tbaa !24
  br label %bb157
bb163:
  br label %bb164
bb164:
  %t616 = load i64, ptr %l41, !tbaa !24
  %t618 = add i64 %t616, 1
  store i64 %t618, ptr %l41, !tbaa !24
  br label %bb152
bb165:
  br label %bb233
bb166:
  %t620 = load ptr, ptr %l0, !tbaa !29
  store ptr %t620, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t621 = load ptr, ptr %l338, !tbaa !29
  %t622 = icmp ne ptr %t621, null
  br i1 %t622, label %bb167, label %bb168
bb167:
  %t624 = load ptr, ptr %l338, !tbaa !29
  %t625 = load i64, ptr %t624, !range !{i64 0, i64 18}
  %t627 = icmp eq i64 %t625, 15
  store i1 %t627, ptr %l339, !tbaa !21
  br label %bb168
bb168:
  %t628 = load i1, ptr %l339, !tbaa !21
  br i1 %t628, label %bb169, label %bb170
bb169:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr { i64, [5 x i64] }, ptr %t629, i32 0, i32 1
  %t632 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t631, i32 0, i32 2
  %t633 = load ptr, ptr %t632
  store ptr %t633, ptr %l48, !tbaa !29
  br label %bb171
bb170:
  br label %bb197
bb171:
  %t635 = load ptr, ptr %l48, !tbaa !29
  store ptr %t635, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t636 = load ptr, ptr %l344, !tbaa !29
  %t637 = icmp ne ptr %t636, null
  br i1 %t637, label %bb172, label %bb173
bb172:
  %t639 = load ptr, ptr %l344, !tbaa !29
  %t640 = load i64, ptr %t639, !range !{i64 0, i64 3}
  %t642 = icmp eq i64 %t640, 1
  store i1 %t642, ptr %l345, !tbaa !21
  br label %bb173
bb173:
  %t643 = load i1, ptr %l345, !tbaa !21
  br i1 %t643, label %bb174, label %bb175
bb174:
  %t644 = load ptr, ptr %l48, !tbaa !29
  %t646 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  %t647 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t646, i32 0, i32 1
  %t648 = load { i64, ptr }, ptr %t647
  store { i64, ptr } %t648, ptr %l49, !tbaa !27
  br label %bb176
bb175:
  br label %bb184
bb176:
  %t650 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t650, ptr %l50, !tbaa !27
  store i64 0, ptr %l51, !tbaa !24
  %t652 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  store i64 %t654, ptr %l52, !tbaa !24
  br label %bb177
bb177:
  %t656 = load i64, ptr %l51, !tbaa !24
  %t657 = load i64, ptr %l52, !tbaa !24
  %t660 = icmp slt i64 %t656, %t657
  %t662 = xor i1 %t660, true
  br i1 %t662, label %bb178, label %bb179
bb178:
  br label %bb183
bb179:
  br label %bb180
bb180:
  %t664 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t664, ptr %l357, !tbaa !27
  %t665 = load i64, ptr %l51, !tbaa !24
  %t667 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !27
  %t669 = getelementptr ptr, ptr %t668, i64 %t665
  %t670 = load ptr, ptr %t669, !tbaa !39
  %t674 = getelementptr %"compiler/typed:Capture", ptr %t670, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !29
  %t677 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t675, ptr %t677)
  br label %bb181
bb181:
  br label %bb182
bb182:
  %t680 = load i64, ptr %l51, !tbaa !24
  %t682 = add i64 %t680, 1
  store i64 %t682, ptr %l51, !tbaa !24
  br label %bb177
bb183:
  br label %bb196
bb184:
  %t684 = load ptr, ptr %l48, !tbaa !29
  store ptr %t684, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t685 = load ptr, ptr %l366, !tbaa !29
  %t686 = icmp ne ptr %t685, null
  br i1 %t686, label %bb185, label %bb186
bb185:
  %t688 = load ptr, ptr %l366, !tbaa !29
  %t689 = load i64, ptr %t688, !range !{i64 0, i64 3}
  %t691 = icmp eq i64 %t689, 2
  store i1 %t691, ptr %l367, !tbaa !21
  br label %bb186
bb186:
  %t692 = load i1, ptr %l367, !tbaa !21
  br i1 %t692, label %bb187, label %bb188
bb187:
  %t693 = load ptr, ptr %l48, !tbaa !29
  %t695 = getelementptr { i64, [4 x i64] }, ptr %t693, i32 0, i32 1
  %t696 = getelementptr { i32, ptr, i32 }, ptr %t695, i32 0, i32 1
  %t697 = load ptr, ptr %t696
  store ptr %t697, ptr %l54, !tbaa !29
  br label %bb189
bb188:
  br label %bb191
bb189:
  %t699 = load ptr, ptr %l54, !tbaa !29
  %t701 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t699, ptr %t701)
  br label %bb190
bb190:
  br label %bb196
bb191:
  br i1 true, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @olang_loc_87083398c1f96e8c_18c50ee403fa2840)
  unreachable
bb196:
  br label %bb233
bb197:
  %t704 = load ptr, ptr %l0, !tbaa !29
  store ptr %t704, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t705 = load ptr, ptr %l375, !tbaa !29
  %t706 = icmp ne ptr %t705, null
  br i1 %t706, label %bb198, label %bb199
bb198:
  %t708 = load ptr, ptr %l375, !tbaa !29
  %t709 = load i64, ptr %t708, !range !{i64 0, i64 18}
  %t711 = icmp eq i64 %t709, 16
  store i1 %t711, ptr %l376, !tbaa !21
  br label %bb199
bb199:
  %t712 = load i1, ptr %l376, !tbaa !21
  br i1 %t712, label %bb200, label %bb201
bb200:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr { i64, [5 x i64] }, ptr %t713, i32 0, i32 1
  %t716 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t715, i32 0, i32 2
  %t717 = load ptr, ptr %t716
  store ptr %t717, ptr %l55, !tbaa !29
  br label %bb202
bb201:
  br label %bb221
bb202:
  %t719 = load ptr, ptr %l55, !tbaa !29
  %t721 = getelementptr %"compiler/typed:Text", ptr %t719, i32 0, i32 0
  %t722 = load { i64, ptr }, ptr %t721, !tbaa !27
  store { i64, ptr } %t722, ptr %l56, !tbaa !27
  store i64 0, ptr %l57, !tbaa !24
  %t724 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t724, 0
  store i64 %t726, ptr %l58, !tbaa !24
  br label %bb203
bb203:
  %t728 = load i64, ptr %l57, !tbaa !24
  %t729 = load i64, ptr %l58, !tbaa !24
  %t732 = icmp slt i64 %t728, %t729
  %t734 = xor i1 %t732, true
  br i1 %t734, label %bb204, label %bb205
bb204:
  br label %bb220
bb205:
  br label %bb206
bb206:
  %t736 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t736, ptr %l389, !tbaa !27
  %t737 = load i64, ptr %l57, !tbaa !24
  %t739 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !27
  %t741 = getelementptr ptr, ptr %t740, i64 %t737
  %t742 = load ptr, ptr %t741, !tbaa !39
  store ptr %t742, ptr %l59, !tbaa !29
  %t744 = load ptr, ptr %l59, !tbaa !29
  store ptr %t744, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t745 = load ptr, ptr %l392, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  br i1 %t746, label %bb207, label %bb208
bb207:
  %t748 = load ptr, ptr %l392, !tbaa !29
  %t749 = load i64, ptr %t748, !range !{i64 0, i64 2}
  %t751 = icmp eq i64 %t749, 1
  store i1 %t751, ptr %l393, !tbaa !21
  br label %bb208
bb208:
  %t752 = load i1, ptr %l393, !tbaa !21
  br i1 %t752, label %bb209, label %bb210
bb209:
  %t753 = load ptr, ptr %l59, !tbaa !29
  %t755 = getelementptr { i64, [2 x i64] }, ptr %t753, i32 0, i32 1
  %t756 = getelementptr { ptr }, ptr %t755, i32 0, i32 0
  %t757 = load ptr, ptr %t756
  store ptr %t757, ptr %l60, !tbaa !29
  br label %bb211
bb210:
  br label %bb213
bb211:
  %t759 = load ptr, ptr %l60, !tbaa !29
  %t761 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t759, ptr %t761)
  br label %bb212
bb212:
  br label %bb218
bb213:
  br i1 true, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb218
bb217:
  call void @__olang_check_failed(ptr @olang_loc_b5f5b909b97f4b87_db04b2c3237782bb)
  unreachable
bb218:
  br label %bb219
bb219:
  %t764 = load i64, ptr %l57, !tbaa !24
  %t766 = add i64 %t764, 1
  store i64 %t766, ptr %l57, !tbaa !24
  br label %bb203
bb220:
  br label %bb233
bb221:
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l403, !tbaa !29
  store i1 false, ptr %l404, !tbaa !21
  %t769 = load ptr, ptr %l403, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb222, label %bb223
bb222:
  %t772 = load ptr, ptr %l403, !tbaa !29
  %t773 = load i64, ptr %t772, !range !{i64 0, i64 18}
  %t775 = icmp eq i64 %t773, 17
  store i1 %t775, ptr %l404, !tbaa !21
  br label %bb223
bb223:
  %t776 = load i1, ptr %l404, !tbaa !21
  br i1 %t776, label %bb224, label %bb225
bb224:
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t779, i32 0, i32 2
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l61, !tbaa !29
  br label %bb226
bb225:
  br label %bb228
bb226:
  %t783 = load ptr, ptr %l61, !tbaa !29
  %t785 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t783, ptr %t785)
  br label %bb227
bb227:
  br label %bb233
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb233
bb232:
  call void @__olang_check_failed(ptr @olang_loc_8469b5ec09caec26_9b966bbb099df63a)
  unreachable
bb233:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t40, ptr %t42)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Elem", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t63, ptr %t65)
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Elem", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t71, ptr %t73)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Payload", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t94, ptr %t96)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 8}
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t114, ptr %t116)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_f21fc7c42b27f081_20ede69b6f10d945)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l154 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l176 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t6 = load ptr, ptr %l24, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l24, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l25, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb24
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l30, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 17}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l31, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb24
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t36 = load ptr, ptr %l36, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l36, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l37, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb24
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t51 = load ptr, ptr %l42, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l42, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 17}
  %t57 = icmp eq i64 %t55, 15
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l43, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [3 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l2, !tbaa !29
  br label %bb24
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t66 = load ptr, ptr %l48, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 17}
  %t72 = icmp eq i64 %t70, 16
  store i1 %t72, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l49, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l2, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb25
bb25:
  br label %bb110
bb26:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t85 = load ptr, ptr %l56, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l56, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 17}
  %t91 = icmp eq i64 %t89, 1
  store i1 %t91, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l57, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t95, i32 0, i32 1
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t105, ptr %t107)
  br label %bb32
bb32:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t110, ptr %t112)
  br label %bb33
bb33:
  br label %bb110
bb34:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t116 = load ptr, ptr %l70, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 17}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb36
bb36:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb37:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/typed:If", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t133, ptr %t135)
  br label %bb40
bb40:
  %t138 = load ptr, ptr %l5, !tbaa !29
  %t140 = getelementptr %"compiler/typed:If", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t141, ptr %t143)
  br label %bb41
bb41:
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  br label %bb42
bb42:
  br label %bb110
bb43:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t154 = load ptr, ptr %l87, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t157 = load ptr, ptr %l87, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 17}
  %t160 = icmp eq i64 %t158, 4
  store i1 %t160, ptr %l88, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l88, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l6, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l7, !tbaa !29
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t174 = load ptr, ptr %l6, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t174, ptr %t176)
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l7, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb50
bb50:
  br label %bb110
bb51:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t184 = load ptr, ptr %l100, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb52, label %bb53
bb52:
  %t187 = load ptr, ptr %l100, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 10
  store i1 %t190, ptr %l101, !tbaa !21
  br label %bb53
bb53:
  %t191 = load i1, ptr %l101, !tbaa !21
  br i1 %t191, label %bb54, label %bb55
bb54:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l8, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t200, i32 0, i32 2
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l9, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t204, ptr %t206)
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l9, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t209, ptr %t210)
  br label %bb58
bb58:
  br label %bb110
bb59:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t214 = load ptr, ptr %l113, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb60, label %bb61
bb60:
  %t217 = load ptr, ptr %l113, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 17}
  %t220 = icmp eq i64 %t218, 9
  store i1 %t220, ptr %l114, !tbaa !21
  br label %bb61
bb61:
  %t221 = load i1, ptr %l114, !tbaa !21
  br i1 %t221, label %bb62, label %bb63
bb62:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr { i64, [3 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l10, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t228 = load ptr, ptr %l10, !tbaa !29
  %t229 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t228, ptr %t229)
  br label %bb65
bb65:
  br label %bb110
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t233 = load ptr, ptr %l121, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l121, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 11
  store i1 %t239, ptr %l122, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l11, !tbaa !29
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t248 = load ptr, ptr %l127, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l127, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 12
  store i1 %t254, ptr %l128, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l128, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t262, ptr %t264)
  br label %bb76
bb76:
  br label %bb110
bb77:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t268 = load ptr, ptr %l136, !tbaa !29
  %t269 = icmp ne ptr %t268, null
  br i1 %t269, label %bb78, label %bb79
bb78:
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = load i64, ptr %t271, !range !{i64 0, i64 17}
  %t274 = icmp eq i64 %t272, 13
  store i1 %t274, ptr %l137, !tbaa !21
  br label %bb79
bb79:
  %t275 = load i1, ptr %l137, !tbaa !21
  br i1 %t275, label %bb80, label %bb81
bb80:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t276, i32 0, i32 1
  %t279 = getelementptr { %"compiler/source:Span", ptr }, ptr %t278, i32 0, i32 1
  %t280 = load ptr, ptr %t279
  store ptr %t280, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb91
bb82:
  %t282 = load ptr, ptr %l12, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Join", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t285, ptr %t287)
  br label %bb83
bb83:
  %t290 = load ptr, ptr %l12, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Join", ptr %t290, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  store i64 %t297, ptr %l15, !tbaa !24
  br label %bb84
bb84:
  %t299 = load i64, ptr %l14, !tbaa !24
  %t300 = load i64, ptr %l15, !tbaa !24
  %t303 = icmp slt i64 %t299, %t300
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb85, label %bb86
bb85:
  br label %bb90
bb86:
  br label %bb87
bb87:
  %t307 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t307, ptr %l154, !tbaa !27
  %t308 = load i64, ptr %l14, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr ptr, ptr %t311, i64 %t308
  %t313 = load ptr, ptr %t312, !tbaa !39
  %t317 = getelementptr %"compiler/typed:Clause", ptr %t313, i32 0, i32 3
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t318, ptr %t319)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t322 = load i64, ptr %l14, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l14, !tbaa !24
  br label %bb84
bb90:
  br label %bb110
bb91:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t327 = load ptr, ptr %l162, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb92, label %bb93
bb92:
  %t330 = load ptr, ptr %l162, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 17}
  %t333 = icmp eq i64 %t331, 14
  store i1 %t333, ptr %l163, !tbaa !21
  br label %bb93
bb93:
  %t334 = load i1, ptr %l163, !tbaa !21
  br i1 %t334, label %bb94, label %bb95
bb94:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l17, !tbaa !29
  br label %bb96
bb95:
  br label %bb105
bb96:
  %t341 = load ptr, ptr %l17, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Spawn", ptr %t341, i32 0, i32 0
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  store { i64, ptr } %t344, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t346 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  store i64 %t348, ptr %l20, !tbaa !24
  br label %bb97
bb97:
  %t350 = load i64, ptr %l19, !tbaa !24
  %t351 = load i64, ptr %l20, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t358 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t358, ptr %l176, !tbaa !27
  %t359 = load i64, ptr %l19, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr ptr, ptr %t362, i64 %t359
  %t364 = load ptr, ptr %t363, !tbaa !39
  %t367 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t364, ptr %t367)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t370 = load i64, ptr %l19, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l19, !tbaa !24
  br label %bb97
bb103:
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Spawn", ptr %t374, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t377, ptr %t379)
  br label %bb104
bb104:
  br label %bb110
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_293c6ab0a5c406c2_e9cd55f098635cb6)
  unreachable
bb110:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca i64
  %l71 = alloca i1
  %l78 = alloca i1
  %l84 = alloca i1
  %l94 = alloca i64
  %l97 = alloca i64
  %l101 = alloca i64
  %l104 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca %"compiler/views:summary"
  %l129 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca i32
  %l143 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l155 = alloca i1
  %l160 = alloca i1
  %l164 = alloca i64
  %l168 = alloca i64
  %l171 = alloca i64
  %l190 = alloca i64
  %l193 = alloca i64
  %l195 = alloca i64
  %l200 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i1
  %l212 = alloca ptr
  %l214 = alloca ptr
  %l218 = alloca i64
  %l219 = alloca i64
  %l220 = alloca i1
  %l224 = alloca i64
  %l227 = alloca i64
  %l249 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i64
  %l275 = alloca ptr
  %l279 = alloca i64
  %l285 = alloca i1
  %l293 = alloca i64
  %l298 = alloca i64
  %l301 = alloca i64
  %l319 = alloca ptr
  %l323 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t183 = alloca %"compiler/views:summary", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l43, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l45
  br label %bb2
bb2:
  %t15 = load i64, ptr %l43, !tbaa !24
  %t16 = load i64, ptr %l45, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l50
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l50, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = icmp slt i64 %t30, 0
  br i1 %t32, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb8:
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/load:Module", ptr %t34, i32 0, i32 6
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/views:Viewer", ptr %t43, i32 0, i32 5
  store ptr %t45, ptr %l59, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/load:Module", ptr %t46, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l61, !tbaa !24
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/load:Module", ptr %t50, i32 0, i32 6
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_93419e5e985e4e42_624fc7044d7cab1e)
  unreachable
bb13:
  br label %bb14
bb14:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 6
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = getelementptr %"compiler/source:Source", ptr %t60, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t65 = load ptr, ptr %l59, !tbaa !29
  %t66 = load i64, ptr %l61, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t65, i64 %t66, { i64, ptr } %t64)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/load:Module", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t73, ptr %l71
  br label %bb17
bb17:
  %t74 = load i1, ptr %l71, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/views:Viewer", ptr %t75, i32 0, i32 6
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 4
  %t81 = load i64, ptr %t80, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t77, i64 %t81, i1 true)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t87, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t89, ptr %l78
  br label %bb22
bb22:
  %t90 = load i1, ptr %l78, !tbaa !21
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t94 = getelementptr %"compiler/load:Module", ptr %t92, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  %t98 = getelementptr %"compiler/views:Viewer", ptr %t91, i32 0, i32 7
  store i64 %t95, ptr %t98, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/load:Module", ptr %t99, i32 0, i32 2
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t102, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t104, ptr %l84
  br label %bb26
bb26:
  %t105 = load i1, ptr %l84, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/load:Module", ptr %t107, i32 0, i32 4
  %t110 = load i64, ptr %t109, !tbaa !24
  %t113 = getelementptr %"compiler/views:Viewer", ptr %t106, i32 0, i32 8
  store i64 %t110, ptr %t113, !tbaa !24
  br label %bb29
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t114 = load i64, ptr %l2, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l2, !tbaa !24
  br label %bb1
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/views:Viewer", ptr %t118, i32 0, i32 7
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = icmp slt i64 %t121, 0
  br i1 %t123, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  br label %bb34
bb34:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t125, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i64 %t127, ptr %l94
  br label %bb35
bb35:
  store i64 0, ptr %l4, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/views:Viewer", ptr %t128, i32 0, i32 1
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l97
  br label %bb36
bb36:
  %t133 = load i64, ptr %l97, !tbaa !24
  store i64 %t133, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t134 = load i64, ptr %l5, !tbaa !24
  %t135 = load i64, ptr %l4, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb42
bb39:
  %t144 = load i64, ptr %l5, !tbaa !24
  %t145 = load i64, ptr %l4, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l6, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l6, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l104, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb41
bb41:
  %t160 = load i64, ptr %l104, !tbaa !24
  store i64 %t160, ptr %l101, !tbaa !24
  br label %bb42
bb42:
  %t161 = load i64, ptr %l101, !tbaa !24
  store i64 %t161, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb43
bb43:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t163 = load i64, ptr %l7, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb44, label %bb45
bb44:
  br label %bb63
bb45:
  br label %bb46
bb46:
  %t170 = load i64, ptr %l4, !tbaa !24
  %t171 = load i64, ptr %l8, !tbaa !24
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l9, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/views:Viewer", ptr %t180, i32 0, i32 2
  store ptr %t182, ptr %l123, !tbaa !29
  call void @compiler_2fviews_3asummary_2ector(ptr %t183, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l124, ptr %t183, i64 136, i1 false)
  br label %bb47
bb47:
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 136, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t184, ptr %l124, i64 136, i1 false)
  %t185 = load ptr, ptr %l123, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H23bbaa5fdc623cf1e33b32cb6290302c(ptr %v0, ptr %v0, ptr %t185, ptr %t184)
  br label %bb48
bb48:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/views:Viewer", ptr %t187, i32 0, i32 1
  %t190 = load i64, ptr %l9, !tbaa !24
  %t193 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t189, i64 %t190)
  store ptr %t193, ptr %l129
  br label %bb49
bb49:
  %t194 = load ptr, ptr %l129, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Body", ptr %t194, i32 0, i32 5
  store ptr %t196, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb50
bb50:
  %t198 = load i64, ptr %l11, !tbaa !24
  store i64 %t198, ptr %l132, !tbaa !24
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t199)
  store i64 %t201, ptr %l134
  br label %bb51
bb51:
  %t202 = load i64, ptr %l132, !tbaa !24
  %t203 = load i64, ptr %l134, !tbaa !24
  %t204 = icmp slt i64 %t202, %t203
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb52, label %bb53
bb52:
  br label %bb59
bb53:
  br label %bb54
bb54:
  %t208 = load ptr, ptr %l10, !tbaa !29
  %t209 = load i64, ptr %l11, !tbaa !24
  %t212 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t208, i64 %t209)
  store i32 %t212, ptr %l139
  br label %bb55
bb55:
  %t213 = load i32, ptr %l139, !tbaa !23
  store i32 %t213, ptr %l12, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/views:Viewer", ptr %t214, i32 0, i32 2
  %t217 = load i64, ptr %l9, !tbaa !24
  %t220 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t216, i64 %t217)
  store ptr %t220, ptr %l143
  br label %bb56
bb56:
  %t221 = load ptr, ptr %l143, !tbaa !29
  %t223 = getelementptr %"compiler/views:summary", ptr %t221, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t223, i1 false)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t225 = load i64, ptr %l11, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l11, !tbaa !24
  br label %bb50
bb59:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/views:Viewer", ptr %t229, i32 0, i32 2
  %t232 = load i64, ptr %l9, !tbaa !24
  %t235 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t231, i64 %t232)
  store ptr %t235, ptr %l151
  br label %bb60
bb60:
  %t236 = load ptr, ptr %l151, !tbaa !29
  store ptr %t236, ptr %l152, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l9, !tbaa !24
  %t241 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalkable(ptr %v0, ptr %t237, i64 %t238)
  store i1 %t241, ptr %l155
  br label %bb61
bb61:
  %t242 = load i1, ptr %l155, !tbaa !21
  %t243 = load ptr, ptr %l152, !tbaa !29
  %t244 = getelementptr %"compiler/views:summary", ptr %t243, i32 0, i32 4
  store i1 %t242, ptr %t244, !tbaa !21
  br label %bb62
bb62:
  %t245 = load i64, ptr %l8, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l8, !tbaa !24
  br label %bb43
bb63:
  %t249 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecomponents(ptr %v0, ptr %t249)
  br label %bb64
bb64:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eviewsHeld(ptr %v0, ptr %t251)
  store i1 %t253, ptr %l160
  br label %bb65
bb65:
  %t254 = load i1, ptr %l160, !tbaa !21
  %t255 = xor i1 %t254, true
  br i1 %t255, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb67:
  br label %bb68
bb68:
  store i64 0, ptr %l13, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/views:Viewer", ptr %t257, i32 0, i32 18
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l164
  br label %bb69
bb69:
  %t262 = load i64, ptr %l164, !tbaa !24
  store i64 %t262, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t263 = load i64, ptr %l14, !tbaa !24
  %t264 = load i64, ptr %l13, !tbaa !24
  %t267 = icmp sgt i64 %t263, %t264
  br i1 %t267, label %bb70, label %bb71
bb70:
  %t269 = load i64, ptr %l15, !tbaa !24
  %t271 = icmp sgt i64 %t269, 0
  br i1 %t271, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb75
bb72:
  %t273 = load i64, ptr %l14, !tbaa !24
  %t274 = load i64, ptr %l13, !tbaa !24
  %t277 = sub i64 %t273, %t274
  %t278 = load i64, ptr %l15, !tbaa !24
  %t281 = add i64 %t277, %t278
  %t283 = sub i64 %t281, 1
  %t284 = load i64, ptr %l15, !tbaa !24
  %t287 = sdiv i64 %t283, %t284
  store i64 %t287, ptr %l171, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb74
bb74:
  %t289 = load i64, ptr %l171, !tbaa !24
  store i64 %t289, ptr %l168, !tbaa !24
  br label %bb75
bb75:
  %t290 = load i64, ptr %l168, !tbaa !24
  store i64 %t290, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb76
bb76:
  %t291 = load i64, ptr %l17, !tbaa !24
  %t292 = load i64, ptr %l16, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb77, label %bb78
bb77:
  br label %bb142
bb78:
  br label %bb79
bb79:
  %t299 = load i64, ptr %l13, !tbaa !24
  %t300 = load i64, ptr %l17, !tbaa !24
  %t301 = load i64, ptr %l15, !tbaa !24
  %t304 = mul i64 %t300, %t301
  %t307 = add i64 %t299, %t304
  store i64 %t307, ptr %l18, !tbaa !24
  %t309 = load i64, ptr %l18, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l190, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/views:Viewer", ptr %t312, i32 0, i32 18
  %t316 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t314)
  store i64 %t316, ptr %l193
  br label %bb80
bb80:
  %t317 = load i64, ptr %l190, !tbaa !24
  %t318 = load i64, ptr %l193, !tbaa !24
  %t319 = icmp slt i64 %t317, %t318
  br i1 %t319, label %bb81, label %bb82
bb81:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/views:Viewer", ptr %t321, i32 0, i32 18
  %t324 = load i64, ptr %l18, !tbaa !24
  %t326 = add i64 %t324, 1
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t323, i64 %t326)
  store i64 %t329, ptr %l200
  br label %bb83
bb82:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/views:Viewer", ptr %t330, i32 0, i32 19
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t332)
  store i64 %t334, ptr %l203
  br label %bb84
bb83:
  %t335 = load i64, ptr %l200, !tbaa !24
  store i64 %t335, ptr %l195, !tbaa !24
  br label %bb85
bb84:
  %t336 = load i64, ptr %l203, !tbaa !24
  store i64 %t336, ptr %l195, !tbaa !24
  br label %bb85
bb85:
  %t337 = load i64, ptr %l195, !tbaa !24
  store i64 %t337, ptr %l19, !tbaa !24
  %t338 = load i64, ptr %l19, !tbaa !24
  store i64 %t338, ptr %l204, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/views:Viewer", ptr %t339, i32 0, i32 18
  %t342 = load i64, ptr %l18, !tbaa !24
  %t345 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t341, i64 %t342)
  store i64 %t345, ptr %l208
  br label %bb86
bb86:
  %t346 = load i64, ptr %l204, !tbaa !24
  %t347 = load i64, ptr %l208, !tbaa !24
  %t348 = sub i64 %t346, %t347
  %t350 = icmp sgt i64 %t348, 1
  br i1 %t350, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb92
bb88:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l212, !tbaa !29
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/views:Viewer", ptr %t353, i32 0, i32 19
  store ptr %t355, ptr %l214, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/views:Viewer", ptr %t356, i32 0, i32 18
  %t359 = load i64, ptr %l18, !tbaa !24
  %t362 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t358, i64 %t359)
  store i64 %t362, ptr %l218
  br label %bb89
bb89:
  %t363 = load ptr, ptr %l214, !tbaa !29
  %t364 = load i64, ptr %l218, !tbaa !24
  %t365 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t363, i64 %t364)
  store i64 %t365, ptr %l219
  br label %bb90
bb90:
  %t366 = load ptr, ptr %l212, !tbaa !29
  %t367 = load i64, ptr %l219, !tbaa !24
  %t368 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallsItself(ptr %v0, ptr %t366, i64 %t367)
  store i1 %t368, ptr %l220
  br label %bb91
bb91:
  %t369 = load i1, ptr %l220, !tbaa !21
  store i1 %t369, ptr %l211, !tbaa !21
  br label %bb92
bb92:
  %t370 = load i1, ptr %l211, !tbaa !21
  store i1 %t370, ptr %l20, !tbaa !21
  store i64 0, ptr %l21, !tbaa !24
  store i64 100, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t371 = load i64, ptr %l22, !tbaa !24
  %t372 = load i64, ptr %l21, !tbaa !24
  %t375 = icmp sgt i64 %t371, %t372
  br i1 %t375, label %bb93, label %bb94
bb93:
  %t377 = load i64, ptr %l23, !tbaa !24
  %t379 = icmp sgt i64 %t377, 0
  br i1 %t379, label %bb95, label %bb96
bb94:
  store i64 0, ptr %l224, !tbaa !24
  br label %bb98
bb95:
  %t381 = load i64, ptr %l22, !tbaa !24
  %t382 = load i64, ptr %l21, !tbaa !24
  %t385 = sub i64 %t381, %t382
  %t386 = load i64, ptr %l23, !tbaa !24
  %t389 = add i64 %t385, %t386
  %t391 = sub i64 %t389, 1
  %t392 = load i64, ptr %l23, !tbaa !24
  %t395 = sdiv i64 %t391, %t392
  store i64 %t395, ptr %l227, !tbaa !24
  br label %bb97
bb96:
  store i64 0, ptr %l227, !tbaa !24
  br label %bb97
bb97:
  %t397 = load i64, ptr %l227, !tbaa !24
  store i64 %t397, ptr %l224, !tbaa !24
  br label %bb98
bb98:
  %t398 = load i64, ptr %l224, !tbaa !24
  store i64 %t398, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb99
bb99:
  %t399 = load i64, ptr %l25, !tbaa !24
  %t400 = load i64, ptr %l24, !tbaa !24
  %t403 = icmp slt i64 %t399, %t400
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb100, label %bb101
bb100:
  br label %bb125
bb101:
  br label %bb102
bb102:
  %t407 = load i64, ptr %l21, !tbaa !24
  %t408 = load i64, ptr %l25, !tbaa !24
  %t409 = load i64, ptr %l23, !tbaa !24
  %t412 = mul i64 %t408, %t409
  %t415 = add i64 %t407, %t412
  store i64 %t415, ptr %l26, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/views:Viewer", ptr %t417, i32 0, i32 25
  store i1 false, ptr %t419, !tbaa !21
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/views:Viewer", ptr %t420, i32 0, i32 18
  %t423 = load i64, ptr %l18, !tbaa !24
  %t426 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t422, i64 %t423)
  store i64 %t426, ptr %l249
  br label %bb103
bb103:
  %t427 = load i64, ptr %l249, !tbaa !24
  store i64 %t427, ptr %l27, !tbaa !24
  %t428 = load i64, ptr %l19, !tbaa !24
  store i64 %t428, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t430 = load i64, ptr %l28, !tbaa !24
  %t431 = load i64, ptr %l27, !tbaa !24
  %t434 = icmp sgt i64 %t430, %t431
  br i1 %t434, label %bb104, label %bb105
bb104:
  %t436 = load i64, ptr %l29, !tbaa !24
  %t438 = icmp sgt i64 %t436, 0
  br i1 %t438, label %bb106, label %bb107
bb105:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb109
bb106:
  %t440 = load i64, ptr %l28, !tbaa !24
  %t441 = load i64, ptr %l27, !tbaa !24
  %t444 = sub i64 %t440, %t441
  %t445 = load i64, ptr %l29, !tbaa !24
  %t448 = add i64 %t444, %t445
  %t450 = sub i64 %t448, 1
  %t451 = load i64, ptr %l29, !tbaa !24
  %t454 = sdiv i64 %t450, %t451
  store i64 %t454, ptr %l257, !tbaa !24
  br label %bb108
bb107:
  store i64 0, ptr %l257, !tbaa !24
  br label %bb108
bb108:
  %t456 = load i64, ptr %l257, !tbaa !24
  store i64 %t456, ptr %l254, !tbaa !24
  br label %bb109
bb109:
  %t457 = load i64, ptr %l254, !tbaa !24
  store i64 %t457, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb110
bb110:
  %t458 = load i64, ptr %l31, !tbaa !24
  %t459 = load i64, ptr %l30, !tbaa !24
  %t462 = icmp slt i64 %t458, %t459
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb111, label %bb112
bb111:
  br label %bb117
bb112:
  br label %bb113
bb113:
  %t466 = load i64, ptr %l27, !tbaa !24
  %t467 = load i64, ptr %l31, !tbaa !24
  %t468 = load i64, ptr %l29, !tbaa !24
  %t471 = mul i64 %t467, %t468
  %t474 = add i64 %t466, %t471
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l275, !tbaa !29
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/views:Viewer", ptr %t477, i32 0, i32 19
  %t483 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t479, i64 %t474)
  store i64 %t483, ptr %l279
  br label %bb114
bb114:
  %t484 = load ptr, ptr %l275, !tbaa !29
  %t485 = load i64, ptr %l279, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %t484, i64 %t485, i1 false)
  br label %bb115
bb115:
  br label %bb116
bb116:
  %t486 = load i64, ptr %l31, !tbaa !24
  %t488 = add i64 %t486, 1
  store i64 %t488, ptr %l31, !tbaa !24
  br label %bb110
bb117:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/views:Viewer", ptr %t490, i32 0, i32 25
  %t493 = load i1, ptr %t492, !tbaa !21
  %t495 = xor i1 %t493, true
  br i1 %t495, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb120
bb119:
  %t497 = load i1, ptr %l20, !tbaa !21
  %t499 = xor i1 %t497, true
  store i1 %t499, ptr %l285, !tbaa !21
  br label %bb120
bb120:
  %t501 = load i1, ptr %l285, !tbaa !21
  br i1 %t501, label %bb121, label %bb122
bb121:
  br label %bb125
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t502 = load i64, ptr %l25, !tbaa !24
  %t504 = add i64 %t502, 1
  store i64 %t504, ptr %l25, !tbaa !24
  br label %bb99
bb125:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/views:Viewer", ptr %t506, i32 0, i32 18
  %t509 = load i64, ptr %l18, !tbaa !24
  %t512 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t508, i64 %t509)
  store i64 %t512, ptr %l293
  br label %bb126
bb126:
  %t513 = load i64, ptr %l293, !tbaa !24
  store i64 %t513, ptr %l33, !tbaa !24
  %t514 = load i64, ptr %l19, !tbaa !24
  store i64 %t514, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t516 = load i64, ptr %l34, !tbaa !24
  %t517 = load i64, ptr %l33, !tbaa !24
  %t520 = icmp sgt i64 %t516, %t517
  br i1 %t520, label %bb127, label %bb128
bb127:
  %t522 = load i64, ptr %l35, !tbaa !24
  %t524 = icmp sgt i64 %t522, 0
  br i1 %t524, label %bb129, label %bb130
bb128:
  store i64 0, ptr %l298, !tbaa !24
  br label %bb132
bb129:
  %t526 = load i64, ptr %l34, !tbaa !24
  %t527 = load i64, ptr %l33, !tbaa !24
  %t530 = sub i64 %t526, %t527
  %t531 = load i64, ptr %l35, !tbaa !24
  %t534 = add i64 %t530, %t531
  %t536 = sub i64 %t534, 1
  %t537 = load i64, ptr %l35, !tbaa !24
  %t540 = sdiv i64 %t536, %t537
  store i64 %t540, ptr %l301, !tbaa !24
  br label %bb131
bb130:
  store i64 0, ptr %l301, !tbaa !24
  br label %bb131
bb131:
  %t542 = load i64, ptr %l301, !tbaa !24
  store i64 %t542, ptr %l298, !tbaa !24
  br label %bb132
bb132:
  %t543 = load i64, ptr %l298, !tbaa !24
  store i64 %t543, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb133
bb133:
  %t544 = load i64, ptr %l37, !tbaa !24
  %t545 = load i64, ptr %l36, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb134, label %bb135
bb134:
  br label %bb140
bb135:
  br label %bb136
bb136:
  %t552 = load i64, ptr %l33, !tbaa !24
  %t553 = load i64, ptr %l37, !tbaa !24
  %t554 = load i64, ptr %l35, !tbaa !24
  %t557 = mul i64 %t553, %t554
  %t560 = add i64 %t552, %t557
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l319, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = getelementptr %"compiler/views:Viewer", ptr %t563, i32 0, i32 19
  %t569 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t565, i64 %t560)
  store i64 %t569, ptr %l323
  br label %bb137
bb137:
  %t570 = load ptr, ptr %l319, !tbaa !29
  %t571 = load i64, ptr %l323, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %t570, i64 %t571, i1 true)
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t572 = load i64, ptr %l37, !tbaa !24
  %t574 = add i64 %t572, 1
  store i64 %t574, ptr %l37, !tbaa !24
  br label %bb133
bb140:
  br label %bb141
bb141:
  %t576 = load i64, ptr %l17, !tbaa !24
  %t578 = add i64 %t576, 1
  store i64 %t578, ptr %l17, !tbaa !24
  br label %bb76
bb142:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i8 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i8
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i8 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i64 @compiler_2fviews_2eplaceEnd(ptr %v1, ptr %a2)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = icmp sle i64 %t5, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = icmp sge i64 %t14, %t18
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t24, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l20
  br label %bb8
bb8:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t32, i64 %t33)
  store i8 %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load i8, ptr %l3, !tbaa !22
  %t38 = load i8, ptr %l23, !tbaa !22
  %t40 = icmp ne i8 %t38, %t37
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t44 = load i8, ptr %l3, !tbaa !22
  %t46 = icmp eq i8 %t44, 46
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  %t55 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t49, i64 %t52)
  store i64 %t55, ptr %l33
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/source:Span" %t58, ptr %l34
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t59, ptr %rv
  br label %ret
bb17:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  %t67 = trunc i64 %t65 to i32
  %t70 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t62, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l40
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t71 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Arm", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l8, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Alt", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t28, ptr %t32, ptr %t34, ptr %l4)
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Alt", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l40, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  store ptr %t62, ptr %l12, !tbaa !29
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l43
  br label %bb11
bb11:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l13
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l12, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s4, ptr %t66, ptr %t70, ptr %t72, ptr %l13)
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l12, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Bind", ptr %t78, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %s4, ptr %s4, ptr %v2, ptr %t77, i64 %t83, ptr null, ptr %l13, i1 false, ptr %t84)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l10, !tbaa !24
  br label %bb7
bb15:
  br label %bb16
bb16:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb2
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Arm", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t97, ptr %t101, ptr %t102, ptr %l4)
  br label %bb18
bb18:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t107, ptr %t111, ptr %t112)
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Arm", ptr %t117, i32 0, i32 4
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t116, ptr %t120, ptr %t121, ptr %a3)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t17 = trunc i64 19 to i32
  %t18 = icmp eq i32 %t15, %t17
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l43 = alloca i64
  %l47 = alloca %"compiler/views:place"
  %l52 = alloca ptr
  %l53 = alloca i1
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca i32
  %l66 = alloca i1
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca %"compiler/views:place"
  %l81 = alloca ptr
  %l82 = alloca %"compiler/views:place"
  %l84 = alloca %"compiler/source:Span"
  %l86 = alloca i64
  %l87 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t6 = load ptr, ptr %l13, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l14, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l5, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t26 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %t20, i64 %t23)
  store i1 %t26, ptr %l22
  br label %bb9
bb9:
  %t27 = load i1, ptr %l22, !tbaa !21
  store i1 %t27, ptr %l6, !tbaa !21
  %t28 = load i1, ptr %l6, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %s3, ptr %v4, ptr %t30, ptr %t31, ptr null, ptr %t32)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t36, i64 %t39, ptr %a2, ptr %t41, i1 true, ptr %t42)
  br label %bb14
bb14:
  %t48 = load i1, ptr %l6, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t52 = load i32, ptr %l5, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t58 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v4, ptr %t50, ptr %t51, i64 %t54)
  store i1 %t58, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l39, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load ptr, ptr %l4, !tbaa !29
  store ptr %t63, ptr %l41, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l43, !tbaa !24
  %t67 = load i32, ptr %l5, !tbaa !23
  %t69 = sext i32 %t67 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 1, ptr %t71
  %t73 = insertvalue { i64 } undef, i64 %t69, 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64 } %t73, ptr %t74
  %t75 = load { i64, [2 x i64] }, ptr %t70
  %t77 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s4, { i64, [2 x i64] } %t75, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t77, ptr %l47
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t78 = load ptr, ptr %l41, !tbaa !29
  %t79 = load i64, ptr %l43, !tbaa !24
  %t80 = load %"compiler/views:place", ptr %l47
  call void @compiler_2fviews_2enameAdd(ptr %v4, ptr %t78, i64 %t79, %"compiler/views:place" %t80)
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/views:state", ptr %t81, i32 0, i32 3
  %t84 = load i32, ptr %l5, !tbaa !23
  %t86 = sext i32 %t84 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v4, ptr %t83, i64 %t86)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t90 = load ptr, ptr %l52, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l52, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 1
  store i1 %t96, ptr %l53, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l53, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eparts(ptr %v0, ptr %v1, ptr %v4, ptr %t98, ptr %t99, ptr %t100)
  br label %bb35
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_55308b3b5a1f5c1_cb52dc999ec87de5)
  unreachable
bb37:
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l59
  br label %bb38
bb38:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l7
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t108 = load ptr, ptr %l4, !tbaa !29
  %t113 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v4, ptr %s0, ptr %t106, ptr %t107, ptr %t108, ptr %l7)
  store i32 %t113, ptr %l64
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb40, label %ok.115, !prof !99
ok.115:
  br label %bb39
bb39:
  br label %bb43
bb40:
  %t116 = load i32, ptr %l64, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t120, ptr %t121, ptr %t122, ptr %t124)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb43:
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t130 = load i64, ptr %l9, !tbaa !24
  store i64 %t130, ptr %l73, !tbaa !24
  %t131 = load ptr, ptr %l8, !tbaa !29
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t131)
  store i64 %t133, ptr %l75
  br label %bb45
bb45:
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = load i64, ptr %l75, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb47:
  br label %bb48
bb48:
  %t140 = load ptr, ptr %l8, !tbaa !29
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t140, i64 %t141)
  store %"compiler/views:place" %t144, ptr %l80
  br label %bb49
bb49:
  %t145 = load %"compiler/views:place", ptr %l80
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l81, !tbaa !29
  store %"compiler/views:place" %t145, ptr %l82
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t148)
  store %"compiler/source:Span" %t150, ptr %l84
  br label %bb50
bb50:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s9, ptr %t151, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i64 %t153, ptr %l86
  br label %bb51
bb51:
  %t154 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 0, i32 0)
  store %"compiler/source:Span" %t154, ptr %l87
  br label %bb52
bb52:
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/views:place", ptr %l82
  %t158 = load %"compiler/source:Span", ptr %l84
  %t159 = load i64, ptr %l86, !tbaa !24
  %t160 = load %"compiler/source:Span", ptr %l87
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v4, ptr %t156, %"compiler/views:place" %t157, %"compiler/source:Span" %t158, i64 %t159, i64 -1, %"compiler/source:Span" %t160, ptr %t155)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l9, !tbaa !24
  br label %bb44
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %rv = alloca { i64, [3 x i64] }
  %t24 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 20
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_bb5d94b92cb03aee_965554ec574ba44a)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 20
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 0
  store i64 3, ptr %t25
  %t27 = insertvalue { i64, i64, i64 } undef, i64 %t15, 0
  %t29 = insertvalue { i64, i64, i64 } %t27, i64 %t19, 1
  %t31 = insertvalue { i64, i64, i64 } %t29, i64 %t23, 2
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  store { i64, i64, i64 } %t31, ptr %t32
  %t33 = load { i64, [3 x i64] }, ptr %t24
  store { i64, [3 x i64] } %t33, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %a0, %"compiler/views:place" %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l3 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca %"compiler/views:place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/views:place"
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 3
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = load %"compiler/views:place", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/views:place" %t4, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/views:Viewer", ptr %t10, i32 0, i32 3
  %t13 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t12, i64 %t14)
  store { i64, ptr } %t17, ptr %l14
  br label %bb6
bb5:
  %t18 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l10, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  %t29 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t30 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t30, ptr %l19
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:Viewer", ptr %t32, i32 0, i32 3
  %t35 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t34, i64 %t36)
  store { i64, ptr } %t39, ptr %l24
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/views:Viewer", ptr %t40, i32 0, i32 3
  %t46 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t42, i64 %a2)
  store { i64, ptr } %t46, ptr %l28
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t48, i64 %t49)
  %t55 = getelementptr i8, ptr %t54, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t65 = load ptr, ptr %l20, !tbaa !29
  %t67 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } %t64)
  store i64 %t67, ptr %l31
  br label %bb10
bb10:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = load { i64, [2 x i64] }, ptr %l19
  %t71 = load i64, ptr %l31, !tbaa !24
  %t74 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s0, { i64, [2 x i64] } %t70, i64 %t71, i64 %t68, i1 %a4)
  store %"compiler/views:place" %t74, ptr %l34
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load %"compiler/views:place", ptr %l34
  store %"compiler/views:place" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:place", ptr %rv
  ret %"compiler/views:place" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/views:holding"
  %l13 = alloca %"compiler/views:view"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/views:place"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca %"compiler/views:holding"
  %l59 = alloca i1
  %l68 = alloca %"compiler/views:place"
  %l70 = alloca ptr
  %l71 = alloca i64
  %l74 = alloca %"compiler/views:holding"
  %l82 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca ptr
  %l99 = alloca %"compiler/typed:Local"
  %l101 = alloca i1
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca %"compiler/views:place"
  %l119 = alloca i1
  %l126 = alloca i64
  %l128 = alloca i1
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca %"compiler/views:place"
  %l148 = alloca ptr
  %l157 = alloca %"compiler/typed:Local"
  %l159 = alloca i1
  %l162 = alloca i64
  %l164 = alloca i64
  %l169 = alloca %"compiler/views:view"
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t86 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load ptr, ptr %l5, !tbaa !29
  %t5 = getelementptr %"compiler/views:state", ptr %t3, i32 0, i32 1
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t5)
  store i64 %t7, ptr %l28
  br label %bb3
bb2:
  br label %bb76
bb3:
  %t8 = load i64, ptr %l28, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb9
bb6:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l8, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l8, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l35, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l35, !tbaa !24
  store i64 %t35, ptr %l32, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t37 = load i64, ptr %l10, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l11, !tbaa !24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t57, i64 %t58)
  store %"compiler/views:holding" %t61, ptr %l56
  br label %bb14
bb14:
  %t62 = load %"compiler/views:holding", ptr %l56
  store %"compiler/views:holding" %t62, ptr %l12
  %t63 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t64 = getelementptr %"compiler/views:view", ptr %t63, i32 0, i32 0
  %t65 = getelementptr %"compiler/views:place", ptr %t64, i32 0, i32 0
  %t66 = load { i64, [2 x i64] }, ptr %t65
  %t68 = extractvalue { i64, [2 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 1
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t72 = getelementptr %"compiler/views:view", ptr %t71, i32 0, i32 0
  %t73 = getelementptr %"compiler/views:place", ptr %t72, i32 0, i32 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { i64 }, ptr %t74, i32 0, i32 0
  %t76 = load i64, ptr %t75
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = icmp eq i64 %t76, %t77
  store i1 %t80, ptr %l59, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb17
bb17:
  %t82 = load i1, ptr %l59, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t84 = load %"compiler/views:view", ptr %t83
  store %"compiler/views:view" %t84, ptr %l13
  store { i64, [2 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t88 = load { i64, [2 x i64] }, ptr %t86
  %t89 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t90 = getelementptr %"compiler/views:place", ptr %t89, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t93 = getelementptr %"compiler/views:place", ptr %t92, i32 0, i32 2
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t96 = getelementptr %"compiler/views:place", ptr %t95, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  %t102 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s4, { i64, [2 x i64] } %t88, i64 %t91, i64 %t94, i1 %t97)
  store %"compiler/views:place" %t102, ptr %l68
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t103 = load %"compiler/views:place", ptr %l68
  %t104 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  store %"compiler/views:place" %t103, ptr %t104
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/views:state", ptr %t105, i32 0, i32 1
  store ptr %t107, ptr %l70, !tbaa !29
  %t108 = load i64, ptr %l11, !tbaa !24
  store i64 %t108, ptr %l71, !tbaa !24
  %t109 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 0
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = load %"compiler/views:view", ptr %l13
  %t114 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s4, i64 %t110, %"compiler/views:view" %t111)
  store %"compiler/views:holding" %t114, ptr %l74
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l70, !tbaa !29
  %t116 = load i64, ptr %l71, !tbaa !24
  %t117 = load %"compiler/views:holding", ptr %l74
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eSetAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t115, i64 %t116, %"compiler/views:holding" %t117)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l10, !tbaa !24
  br label %bb10
bb25:
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eforget(ptr %v3, ptr %t122, i64 %t123)
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb27, label %bb28
bb27:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l83, !tbaa !29
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t133)
  store i32 %t135, ptr %l85
  br label %bb29
bb28:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb31
bb29:
  %t136 = load ptr, ptr %l83, !tbaa !29
  %t137 = load i32, ptr %l85, !tbaa !23
  %t138 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l86
  br label %bb30
bb30:
  %t139 = load i1, ptr %l86, !tbaa !21
  store i1 %t139, ptr %l82, !tbaa !21
  br label %bb31
bb31:
  %t140 = load i1, ptr %l82, !tbaa !21
  br i1 %t140, label %bb32, label %bb33
bb32:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/views:Viewer", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  store ptr %t146, ptr %l90, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/views:Viewer", ptr %t147, i32 0, i32 20
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb39
bb34:
  call void @__olang_check_failed(ptr @olang_loc_7ef79401c16fe1d4_255ec247f03840e8)
  unreachable
bb35:
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/views:Viewer", ptr %t154, i32 0, i32 20
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Body", ptr %t157, i32 0, i32 7
  %t161 = load i64, ptr %l1, !tbaa !24
  %t164 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t160, i64 %t161)
  store %"compiler/typed:Local" %t164, ptr %l99
  br label %bb37
bb37:
  %t165 = getelementptr %"compiler/typed:Local", ptr %l99, i32 0, i32 2
  %t166 = load i32, ptr %t165, !tbaa !23
  %t167 = load ptr, ptr %l90, !tbaa !29
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t167, i32 %t166)
  store i1 %t169, ptr %l101
  br label %bb38
bb38:
  %t170 = load i1, ptr %l101, !tbaa !21
  store i1 %t170, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t172 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l102
  br label %bb42
bb41:
  br label %bb75
bb42:
  %t173 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l14
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s6, ptr %t174, ptr %t175, ptr %t177, ptr %l14)
  br label %bb43
bb43:
  store i1 false, ptr %l15, !tbaa !21
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb44
bb44:
  %t183 = load i64, ptr %l17, !tbaa !24
  store i64 %t183, ptr %l109, !tbaa !24
  %t184 = load ptr, ptr %l16, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t184)
  store i64 %t186, ptr %l111
  br label %bb45
bb45:
  %t187 = load i64, ptr %l109, !tbaa !24
  %t188 = load i64, ptr %l111, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb46, label %bb47
bb46:
  br label %bb57
bb47:
  br label %bb48
bb48:
  %t193 = load ptr, ptr %l16, !tbaa !29
  %t194 = load i64, ptr %l17, !tbaa !24
  %t197 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t193, i64 %t194)
  store %"compiler/views:place" %t197, ptr %l116
  br label %bb49
bb49:
  %t198 = load %"compiler/views:place", ptr %l116
  store %"compiler/views:place" %t198, ptr %l18
  %t199 = getelementptr %"compiler/views:place", ptr %l18, i32 0, i32 0
  %t200 = load { i64, [2 x i64] }, ptr %t199
  %t202 = extractvalue { i64, [2 x i64] } %t200, 0
  %t203 = icmp eq i64 %t202, 1
  br i1 %t203, label %bb50, label %bb51
bb50:
  %t205 = getelementptr %"compiler/views:place", ptr %l18, i32 0, i32 0
  %t206 = getelementptr { i64, [2 x i64] }, ptr %t205, i32 0, i32 1
  %t207 = getelementptr { i64 }, ptr %t206, i32 0, i32 0
  %t208 = load i64, ptr %t207
  %t209 = load i64, ptr %l1, !tbaa !24
  %t212 = icmp eq i64 %t208, %t209
  store i1 %t212, ptr %l119, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb52
bb52:
  %t214 = load i1, ptr %l119, !tbaa !21
  br i1 %t214, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t215 = load i64, ptr %l17, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l17, !tbaa !24
  br label %bb44
bb57:
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %l14)
  store i64 %t220, ptr %l126
  br label %bb58
bb58:
  %t221 = load i64, ptr %l126, !tbaa !24
  %t222 = icmp sgt i64 %t221, 0
  br i1 %t222, label %bb59, label %bb60
bb59:
  %t224 = load i1, ptr %l15, !tbaa !21
  %t226 = xor i1 %t224, true
  store i1 %t226, ptr %l128, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb61
bb61:
  %t228 = load i1, ptr %l128, !tbaa !21
  br i1 %t228, label %bb62, label %bb63
bb62:
  store ptr %l14, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb63:
  br label %bb74
bb64:
  %t230 = load i64, ptr %l20, !tbaa !24
  store i64 %t230, ptr %l132, !tbaa !24
  %t231 = load ptr, ptr %l19, !tbaa !29
  %t233 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t231)
  store i64 %t233, ptr %l134
  br label %bb65
bb65:
  %t234 = load i64, ptr %l132, !tbaa !24
  %t235 = load i64, ptr %l134, !tbaa !24
  %t236 = icmp slt i64 %t234, %t235
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb66, label %bb67
bb66:
  br label %bb72
bb67:
  br label %bb68
bb68:
  %t240 = load ptr, ptr %l19, !tbaa !29
  %t241 = load i64, ptr %l20, !tbaa !24
  %t244 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t240, i64 %t241)
  store %"compiler/views:place" %t244, ptr %l139
  br label %bb69
bb69:
  %t245 = load %"compiler/views:place", ptr %l139
  %t246 = load ptr, ptr %l5, !tbaa !29
  %t247 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2enameAdd(ptr %v3, ptr %t246, i64 %t247, %"compiler/views:place" %t245)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t252 = load i64, ptr %l20, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l20, !tbaa !24
  br label %bb64
bb72:
  %t256 = load ptr, ptr %l5, !tbaa !29
  %t258 = getelementptr %"compiler/views:state", ptr %t256, i32 0, i32 3
  %t259 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t258, i64 %t259)
  br label %bb73
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s6)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l148, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/views:Viewer", ptr %t263, i32 0, i32 20
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = icmp eq ptr %t266, null
  br i1 %t268, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_f2a9606e62f672e3_f02fc5d7c09a9e07)
  unreachable
bb78:
  br label %bb79
bb79:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/views:Viewer", ptr %t270, i32 0, i32 20
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t276 = getelementptr %"compiler/typed:Body", ptr %t273, i32 0, i32 7
  %t277 = load i64, ptr %l1, !tbaa !24
  %t280 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t276, i64 %t277)
  store %"compiler/typed:Local" %t280, ptr %l157
  br label %bb80
bb80:
  %t281 = getelementptr %"compiler/typed:Local", ptr %l157, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  %t283 = load ptr, ptr %l148, !tbaa !29
  %t285 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t283, i32 %t282)
  store i1 %t285, ptr %l159
  br label %bb81
bb81:
  %t286 = load i1, ptr %l159, !tbaa !21
  %t287 = xor i1 %t286, true
  br i1 %t287, label %bb82, label %bb83
bb82:
  br label %ret
bb83:
  br label %bb84
bb84:
  store ptr %a3, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb85
bb85:
  %t291 = load i64, ptr %l23, !tbaa !24
  store i64 %t291, ptr %l162, !tbaa !24
  %t292 = load ptr, ptr %l22, !tbaa !29
  %t294 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t292)
  store i64 %t294, ptr %l164
  br label %bb86
bb86:
  %t295 = load i64, ptr %l162, !tbaa !24
  %t296 = load i64, ptr %l164, !tbaa !24
  %t297 = icmp slt i64 %t295, %t296
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb87, label %bb88
bb87:
  br label %bb93
bb88:
  br label %bb89
bb89:
  %t301 = load ptr, ptr %l22, !tbaa !29
  %t302 = load i64, ptr %l23, !tbaa !24
  %t305 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t301, i64 %t302)
  store %"compiler/views:view" %t305, ptr %l169
  br label %bb90
bb90:
  %t306 = load %"compiler/views:view", ptr %l169
  %t307 = load ptr, ptr %l5, !tbaa !29
  %t308 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2eholdAdd(ptr %v3, ptr %t307, i64 %t308, %"compiler/views:view" %t306)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t313 = load i64, ptr %l23, !tbaa !24
  %t315 = add i64 %t313, 1
  store i64 %t315, ptr %l23, !tbaa !24
  br label %bb85
bb93:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 0
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t35, ptr %t36, ptr %t38)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb4
bb13:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/views:state", ptr %t46, i32 0, i32 0
  %t49 = load i1, ptr %t48, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Block", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp sge i64 %t60, 0
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Block", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l41, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l8, !tbaa !29
  %t77 = load ptr, ptr %l8, !tbaa !29
  store ptr %t77, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 17}
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l45, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l45, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l8, !tbaa !29
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr }, ptr %t88, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l9, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t95 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t93, ptr %t95)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_f4d9265444485b3d_7f3b362071bb80f9)
  unreachable
bb32:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = sub i64 %t99, 1
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb33
bb33:
  br label %bb17
bb34:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l18 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i1
  %l43 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Elem", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t20, ptr %t21, ptr %t22)
  store i32 %t27, ptr %l18
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  store i32 %t38, ptr %rv
  br label %ret
bb8:
  store i32 0, ptr %rv
  br label %ret
bb9:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t63 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t55, ptr %t56, ptr %t57, ptr %t58)
  store i32 %t63, ptr %l30
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb16, label %ok.65, !prof !99
ok.65:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t66 = load i32, ptr %l30, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  store i32 %t74, ptr %rv
  br label %ret
bb17:
  store i32 0, ptr %rv
  br label %ret
bb18:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t80 = load ptr, ptr %l32, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t84 = load i1, ptr %l33, !tbaa !21
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Payload", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t102 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t91, ptr %t95, ptr %t96, ptr %t97)
  store i32 %t102, ptr %l43
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb25, label %ok.104, !prof !99
ok.104:
  br label %bb24
bb24:
  br label %bb26
bb25:
  %t105 = load i32, ptr %l43, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  store i32 %t113, ptr %rv
  br label %ret
bb26:
  store i32 0, ptr %rv
  br label %ret
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_3e3606e9c916d325_999483638397109)
  unreachable
bb32:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferField(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i32
  %l13 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca i32
  %l26 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l19, !tbaa !24
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t38, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/views:Viewer", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l25
  br label %bb6
bb6:
  %t50 = load i32, ptr %l25, !tbaa !23
  store i32 %t50, ptr %l3, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l31
  br label %bb7
bb7:
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %v0, ptr %t62, i32 %t63)
  store { i64, ptr } %t64, ptr %l32
  br label %bb8
bb8:
  %t65 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t65, ptr %l4, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:Viewer", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = getelementptr %"compiler/types:Table", ptr %t71, i32 0, i32 14
  store ptr %t72, ptr %l35, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/views:Viewer", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l3, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l40
  br label %bb9
bb9:
  %t83 = load ptr, ptr %l35, !tbaa !29
  %t84 = load i64, ptr %l40, !tbaa !24
  %t85 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t85, ptr %l41
  br label %bb10
bb10:
  %t86 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t86, ptr %l5, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t89, ptr %l43
  br label %bb11
bb11:
  %t90 = load i1, ptr %l43, !tbaa !21
  br i1 %t90, label %bb12, label %bb13
bb12:
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t91, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t93, ptr %l46
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t94 = load i1, ptr %l46, !tbaa !21
  store i1 %t94, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t96, ptr %l48, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l49, !tbaa !24
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l50, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t110, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t112, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t114, ptr %l52
  br label %bb19
bb19:
  %t115 = load i1, ptr %l52, !tbaa !21
  br i1 %t115, label %bb20, label %bb21
bb20:
  %t116 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t118, ptr %l55
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  %t119 = load i1, ptr %l55, !tbaa !21
  store i1 %t119, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l53, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l58, !tbaa !24
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l59, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l58, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t135, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t137, ptr %l61, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l62, !tbaa !24
  %t140 = load i64, ptr %l62, !tbaa !24
  %t141 = mul i64 %t140, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l63, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = mul i64 %t149, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t146, ptr %t148, i64 %t150, i1 false)
  %t151 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = call ptr @compiler_2fviews_2eunAway(ptr %v1, ptr %s1, ptr %t16)
  store ptr %t18, ptr %l17
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l17, !tbaa !29
  store ptr %t19, ptr %l5, !tbaa !29
  %t20 = load ptr, ptr %l5, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t21 = load ptr, ptr %l18, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l6, !tbaa !29
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %s1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t37, ptr %t38)
  store i32 %t43, ptr %l28
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb13, label %ok.45, !prof !99
ok.45:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t46 = load i32, ptr %l28, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  call void @__olang_scope_close(ptr %s1)
  store i32 %t54, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s1)
  store i32 0, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1bacef8f79fa259f_b65daa57821eac43)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb21:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb22, label %bb23
bb22:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t64 = load i1, ptr %l31, !tbaa !21
  br i1 %t64, label %bb24, label %bb25
bb24:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t73, i32 0, i32 3
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l8, !tbaa !24
  br label %bb26
bb25:
  br label %bb41
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l38, !tbaa !29
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t78)
  store i32 %t80, ptr %l40
  br label %bb27
bb27:
  %t81 = load ptr, ptr %l38, !tbaa !29
  %t82 = load i32, ptr %l40, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferField(ptr %v0, ptr %s4, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l41
  br label %bb28
bb28:
  %t84 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t84, ptr %l9, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t87, ptr %l43
  br label %bb29
bb29:
  %t88 = load i1, ptr %l43, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb30, label %bb31
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t93)
  store i32 %t95, ptr %l49
  br label %bb32
bb31:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb36
bb32:
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load i32, ptr %l49, !tbaa !23
  %t98 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t98, ptr %l50
  br label %bb33
bb33:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load ptr, ptr %l46, !tbaa !29
  %t101 = load i32, ptr %l50, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %s4, ptr %t100, i32 %t101, i64 %t99)
  store { i64, ptr } %t103, ptr %l52
  br label %bb34
bb34:
  %t104 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t110, { i64, ptr } %t111)
  store i1 %t114, ptr %l55
  br label %bb35
bb35:
  %t115 = load i1, ptr %l55, !tbaa !21
  store i1 %t115, ptr %l45, !tbaa !21
  br label %bb36
bb36:
  %t116 = load i1, ptr %l45, !tbaa !21
  br i1 %t116, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t120 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erecordPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t117, ptr %t118, ptr %t119, ptr %t120)
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s4)
  store i32 0, ptr %rv
  br label %ret
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_b34deef82c4dbb1e_7a61043bb66e64c2)
  unreachable
bb46:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/views:fact"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"compiler/views:place"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca %"compiler/views:view"
  %l54 = alloca i64
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca %"compiler/views:fact"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca ptr
  %l77 = alloca i64
  %l79 = alloca %"compiler/views:view"
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca %"compiler/views:place"
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca %"compiler/views:fact"
  %l97 = alloca ptr
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l123 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca i64
  %l131 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l160 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca ptr
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l175 = alloca i1
  %l179 = alloca ptr
  %l182 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l184 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l189 = alloca ptr
  %l192 = alloca i64
  %l194 = alloca i64
  %l199 = alloca %"compiler/views:fact"
  %l202 = alloca ptr
  %l209 = alloca %"compiler/views:place"
  %l217 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l220 = alloca { i64, ptr }
  %l227 = alloca i64
  %l229 = alloca i64
  %l234 = alloca %"compiler/views:place"
  %l235 = alloca ptr
  %l241 = alloca %"compiler/views:place"
  %l253 = alloca ptr
  %l256 = alloca ptr
  %l259 = alloca i32
  %l260 = alloca i32
  %l261 = alloca { i64, ptr }
  %l266 = alloca i64
  %l269 = alloca i64
  %l288 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l293 = alloca i32
  %l294 = alloca i1
  %l300 = alloca i1
  %l304 = alloca { i64, ptr }
  %l307 = alloca i1
  %l308 = alloca i1
  %l312 = alloca { i64, ptr }
  %l315 = alloca i64
  %l319 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l326 = alloca i64
  %l328 = alloca i64
  %l333 = alloca %"compiler/views:place"
  %l334 = alloca ptr
  %l335 = alloca { i64, [2 x i64] }
  %l336 = alloca i64
  %l340 = alloca { i64, ptr }
  %l342 = alloca %"compiler/views:place"
  %l344 = alloca ptr
  %l345 = alloca %"compiler/source:Span"
  %l352 = alloca i1
  %l356 = alloca i1
  %l364 = alloca i64
  %l367 = alloca i64
  %l387 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l389 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l391 = alloca i64
  %l393 = alloca i64
  %l398 = alloca %"compiler/views:view"
  %l402 = alloca i64
  %l407 = alloca { i64, ptr }
  %l410 = alloca %"compiler/source:Span"
  %l413 = alloca i1
  %l415 = alloca ptr
  %l416 = alloca %"compiler/source:Span"
  %l417 = alloca %"compiler/views:place"
  %l418 = alloca i64
  %l419 = alloca i64
  %l421 = alloca i64
  %l424 = alloca i64
  %l427 = alloca %"compiler/source:Span"
  %l433 = alloca i64
  %l437 = alloca i64
  %l440 = alloca i64
  %l458 = alloca ptr
  %l461 = alloca %"compiler/views:place"
  %l462 = alloca %"compiler/source:Span"
  %l463 = alloca i64
  %l466 = alloca i64
  %l469 = alloca %"compiler/source:Span"
  %l474 = alloca i64
  %l476 = alloca i64
  %l481 = alloca %"compiler/views:view"
  %l486 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l491 = alloca i64
  %l494 = alloca i64
  %l519 = alloca ptr
  %l522 = alloca i64
  %l524 = alloca i64
  %l529 = alloca %"compiler/views:fact"
  %l532 = alloca i1
  %l538 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l541 = alloca { i64, ptr }
  %l548 = alloca i64
  %l550 = alloca i64
  %l555 = alloca %"compiler/views:place"
  %l561 = alloca %"compiler/views:place"
  %l564 = alloca %"compiler/views:view"
  %l568 = alloca ptr
  %l574 = alloca i64
  %l578 = alloca ptr
  %l584 = alloca i64
  %l593 = alloca i1
  %l598 = alloca i64
  %l601 = alloca i64
  %l621 = alloca i1
  %l623 = alloca i1
  %l626 = alloca i1
  %l629 = alloca i1
  %l630 = alloca i64
  %l634 = alloca ptr
  %l637 = alloca i64
  %l639 = alloca i1
  %l643 = alloca ptr
  %l647 = alloca i1
  %l651 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l653 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l655 = alloca i64
  %l657 = alloca i64
  %l662 = alloca %"compiler/views:view"
  %l668 = alloca i1
  %l669 = alloca ptr
  %l671 = alloca { i64, ptr }
  %l674 = alloca i32
  %l675 = alloca i1
  %l676 = alloca i1
  %l679 = alloca i1
  %l680 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l683 = alloca { i64, ptr }
  %l690 = alloca i64
  %l692 = alloca i64
  %l697 = alloca %"compiler/views:place"
  %l698 = alloca ptr
  %l699 = alloca { i64, [2 x i64] }
  %l700 = alloca i64
  %l704 = alloca { i64, ptr }
  %l706 = alloca %"compiler/views:place"
  %l709 = alloca %"compiler/views:view"
  %l715 = alloca i1
  %l722 = alloca ptr
  %l725 = alloca i64
  %l727 = alloca i64
  %l732 = alloca %"compiler/views:fact"
  %l735 = alloca i1
  %l739 = alloca i1
  %l742 = alloca i1
  %l746 = alloca i1
  %l749 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l751 = alloca i64
  %l754 = alloca { i64, ptr }
  %l757 = alloca ptr
  %l759 = alloca ptr
  %l761 = alloca i32
  %l764 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s67 = alloca %olang.scope
  %t223 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l98
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l6
  store i64 -1, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Call", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l9, !tbaa !29
  store ptr %t8, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t9 = load ptr, ptr %l101, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l101, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 5}
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l102, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l102, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = getelementptr { i64, [3 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l10, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t23 = load i32, ptr %l10, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb19
bb7:
  %t27 = load ptr, ptr %l9, !tbaa !29
  store ptr %t27, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t28 = load ptr, ptr %l109, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l109, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 5}
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l110, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l110, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l9, !tbaa !29
  %t38 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { ptr }, ptr %t38, i32 0, i32 0
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l11, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  store i1 true, ptr %l8, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t42, ptr %t43, ptr %t45, ptr %l6)
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f56dc5f524947092_cf97541144f04b56)
  unreachable
bb19:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Call", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l12, !tbaa !24
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l123
  br label %bb20
bb20:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l123
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t59 = load i64, ptr %l12, !tbaa !24
  store i64 %t59, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t61 = load i64, ptr %l15, !tbaa !24
  %t62 = load i64, ptr %l14, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load i64, ptr %l16, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb26
bb23:
  %t71 = load i64, ptr %l15, !tbaa !24
  %t72 = load i64, ptr %l14, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l16, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l16, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l131, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb25
bb25:
  %t87 = load i64, ptr %l131, !tbaa !24
  store i64 %t87, ptr %l128, !tbaa !24
  br label %bb26
bb26:
  %t88 = load i64, ptr %l128, !tbaa !24
  store i64 %t88, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load i64, ptr %l18, !tbaa !24
  %t90 = load i64, ptr %l17, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l18, !tbaa !24
  %t99 = load i64, ptr %l16, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l19, !tbaa !24
  store ptr %l13, ptr %l149, !tbaa !29
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l150
  br label %bb31
bb31:
  %t108 = load ptr, ptr %l149, !tbaa !29
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l150
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hcddb8d7004bc9cdff185b89d31641a08(ptr %s0, ptr %s5, ptr %t108, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109)
  br label %bb32
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l151, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l153, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  store ptr %t120, ptr %l156, !tbaa !29
  %t122 = load ptr, ptr %l4, !tbaa !29
  store ptr %t122, ptr %l157, !tbaa !29
  %t123 = load i64, ptr %l19, !tbaa !24
  %t126 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H5cdbeb94ae0c6e2e33fc44df03720816(ptr %s0, ptr %s0, ptr %l13, i64 %t123)
  store ptr %t126, ptr %l160
  br label %bb33
bb33:
  %t127 = load ptr, ptr %l151, !tbaa !29
  %t128 = load ptr, ptr %l156, !tbaa !29
  %t129 = load ptr, ptr %l157, !tbaa !29
  %t130 = load ptr, ptr %l160, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t127, ptr %t128, ptr %t129, ptr %t130)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t131 = load i64, ptr %l18, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l18, !tbaa !24
  br label %bb27
bb36:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t141 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %t135, %"compiler/source:Span" %a1, ptr %t137)
  store %"compiler/source:Span" %t141, ptr %l166
  br label %bb37
bb37:
  %t142 = load %"compiler/source:Span", ptr %l166
  store %"compiler/source:Span" %t142, ptr %l20
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l167, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i64, ptr %l7, !tbaa !24
  %t148 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2equoted(ptr %v0, ptr %s0, ptr %t144, i64 %t145)
  store { i64, ptr } %t148, ptr %l170
  br label %bb38
bb38:
  %t149 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t156 = load ptr, ptr %l167, !tbaa !29
  %t158 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t156, { i64, ptr } %t155)
  store i64 %t158, ptr %l172
  br label %bb39
bb39:
  %t159 = load i64, ptr %l172, !tbaa !24
  store i64 %t159, ptr %l21, !tbaa !24
  %t160 = load i64, ptr %l7, !tbaa !24
  %t162 = icmp sge i64 %t160, 0
  br i1 %t162, label %bb40, label %bb41
bb40:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/views:Viewer", ptr %t164, i32 0, i32 2
  %t167 = load i64, ptr %l7, !tbaa !24
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l179
  br label %bb42
bb41:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb43
bb42:
  %t171 = load ptr, ptr %l179, !tbaa !29
  %t173 = getelementptr %"compiler/views:summary", ptr %t171, i32 0, i32 4
  %t174 = load i1, ptr %t173, !tbaa !21
  store i1 %t174, ptr %l175, !tbaa !21
  br label %bb43
bb43:
  %t176 = load i1, ptr %l175, !tbaa !21
  store i1 %t176, ptr %l22, !tbaa !21
  %t177 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l182
  br label %bb44
bb44:
  %t178 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l182
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %l23
  %t179 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l183
  br label %bb45
bb45:
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l183
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l24
  %t181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l184
  br label %bb46
bb46:
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l184
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l25
  %t183 = load i1, ptr %l22, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 2
  %t188 = load i64, ptr %l7, !tbaa !24
  %t191 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l189
  br label %bb49
bb48:
  %t192 = load i1, ptr %l8, !tbaa !21
  br i1 %t192, label %bb82, label %bb83
bb49:
  %t194 = load ptr, ptr %l189, !tbaa !29
  %t196 = getelementptr %"compiler/views:summary", ptr %t194, i32 0, i32 0
  store ptr %t196, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t198 = load i64, ptr %l27, !tbaa !24
  store i64 %t198, ptr %l192, !tbaa !24
  %t199 = load ptr, ptr %l26, !tbaa !29
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t199)
  store i64 %t201, ptr %l194
  br label %bb51
bb51:
  %t202 = load i64, ptr %l192, !tbaa !24
  %t203 = load i64, ptr %l194, !tbaa !24
  %t204 = icmp slt i64 %t202, %t203
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb81
bb53:
  br label %bb54
bb54:
  %t208 = load ptr, ptr %l26, !tbaa !29
  %t209 = load i64, ptr %l27, !tbaa !24
  %t212 = call %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t208, i64 %t209)
  store %"compiler/views:fact" %t212, ptr %l199
  br label %bb55
bb55:
  %t213 = load %"compiler/views:fact", ptr %l199
  store %"compiler/views:fact" %t213, ptr %l28
  %t214 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 0
  %t215 = load i64, ptr %t214, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l23, ptr %l202, !tbaa !29
  %t219 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 1
  %t220 = load i64, ptr %t219, !tbaa !24
  %t221 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 2
  %t222 = load i32, ptr %t221, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 0
  store i64 3, ptr %t224
  %t226 = insertvalue { i64, i32 } undef, i64 %t220, 0
  %t228 = insertvalue { i64, i32 } %t226, i32 %t222, 1
  %t229 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 1
  store { i64, i32 } %t228, ptr %t229
  %t230 = load { i64, [2 x i64] }, ptr %t223
  %t231 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 4
  %t234 = load i64, ptr %t233, !tbaa !24
  %t235 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 5
  %t236 = load i1, ptr %t235, !tbaa !21
  %t241 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s10, { i64, [2 x i64] } %t230, i64 %t232, i64 %t234, i1 %t236)
  store %"compiler/views:place" %t241, ptr %l209
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t242 = load ptr, ptr %l202, !tbaa !29
  %t243 = load %"compiler/views:place", ptr %l209
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t242, %"compiler/views:place" %t243)
  br label %bb59
bb59:
  %t244 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 6
  %t245 = load i64, ptr %t244, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 %t245)
  br label %bb60
bb60:
  %t248 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 7
  %t249 = load %"compiler/source:Span", ptr %t248
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, %"compiler/source:Span" %t249)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  br label %bb80
bb62:
  %t252 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 0
  %t253 = load i64, ptr %t252, !tbaa !24
  %t254 = load i64, ptr %l12, !tbaa !24
  %t257 = icmp sge i64 %t253, %t254
  br i1 %t257, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb80
bb64:
  br label %bb65
bb65:
  %t259 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259, ptr %l217
  br label %bb66
bb66:
  %t260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l217
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %l29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l3, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Call", ptr %t262, i32 0, i32 1
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l220, !tbaa !27
  %t266 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 0
  %t267 = load i64, ptr %t266, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr ptr, ptr %t270, i64 %t267
  %t272 = load ptr, ptr %t271, !tbaa !39
  %t274 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s9, ptr %t261, ptr %t272, ptr %t274, ptr %l29)
  br label %bb67
bb67:
  store ptr %l29, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb68
bb68:
  %t280 = load i64, ptr %l31, !tbaa !24
  store i64 %t280, ptr %l227, !tbaa !24
  %t281 = load ptr, ptr %l30, !tbaa !29
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s9, ptr %t281)
  store i64 %t283, ptr %l229
  br label %bb69
bb69:
  %t284 = load i64, ptr %l227, !tbaa !24
  %t285 = load i64, ptr %l229, !tbaa !24
  %t286 = icmp slt i64 %t284, %t285
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb70, label %bb71
bb70:
  br label %bb79
bb71:
  br label %bb72
bb72:
  %t290 = load ptr, ptr %l30, !tbaa !29
  %t291 = load i64, ptr %l31, !tbaa !24
  %t294 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s9, ptr %t290, i64 %t291)
  store %"compiler/views:place" %t294, ptr %l234
  br label %bb73
bb73:
  %t295 = load %"compiler/views:place", ptr %l234
  store ptr %l23, ptr %l235, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 3
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 4
  %t301 = load i64, ptr %t300, !tbaa !24
  %t302 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 5
  %t303 = load i1, ptr %t302, !tbaa !21
  %t309 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t296, %"compiler/views:place" %t295, i64 %t299, i64 %t301, i1 %t303)
  store %"compiler/views:place" %t309, ptr %l241
  br label %bb74
bb74:
  %t310 = load ptr, ptr %l235, !tbaa !29
  %t311 = load %"compiler/views:place", ptr %l241
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t310, %"compiler/views:place" %t311)
  br label %bb75
bb75:
  %t312 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 6
  %t313 = load i64, ptr %t312, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 %t313)
  br label %bb76
bb76:
  %t316 = getelementptr %"compiler/views:fact", ptr %l28, i32 0, i32 7
  %t317 = load %"compiler/source:Span", ptr %t316
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, %"compiler/source:Span" %t317)
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t320 = load i64, ptr %l31, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l31, !tbaa !24
  br label %bb68
bb79:
  call void @__olang_scope_close(ptr %s9)
  br label %bb80
bb80:
  %t324 = load i64, ptr %l27, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l27, !tbaa !24
  br label %bb50
bb81:
  br label %bb132
bb82:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/views:Viewer", ptr %t328, i32 0, i32 0
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = getelementptr %"compiler/generic:Program", ptr %t331, i32 0, i32 2
  store ptr %t333, ptr %l253, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/views:Viewer", ptr %t334, i32 0, i32 0
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = getelementptr %"compiler/generic:Program", ptr %t337, i32 0, i32 2
  store ptr %t339, ptr %l256, !tbaa !29
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l3, !tbaa !29
  %t344 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecalleeType(ptr %v0, ptr %v1, ptr %t340, ptr %t341)
  store i32 %t344, ptr %l259
  br label %bb84
bb83:
  br label %bb131
bb84:
  %t345 = load ptr, ptr %l256, !tbaa !29
  %t346 = load i32, ptr %l259, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t345, i32 %t346)
  store i32 %t347, ptr %l260
  br label %bb85
bb85:
  %t348 = load ptr, ptr %l253, !tbaa !29
  %t349 = load i32, ptr %l260, !tbaa !23
  %t350 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t348, i32 %t349)
  store { i64, ptr } %t350, ptr %l261
  br label %bb86
bb86:
  %t351 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t351, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t352 = load i64, ptr %l12, !tbaa !24
  store i64 %t352, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t354 = load i64, ptr %l35, !tbaa !24
  %t355 = load i64, ptr %l34, !tbaa !24
  %t358 = icmp sgt i64 %t354, %t355
  br i1 %t358, label %bb87, label %bb88
bb87:
  %t360 = load i64, ptr %l36, !tbaa !24
  %t362 = icmp sgt i64 %t360, 0
  br i1 %t362, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l266, !tbaa !24
  br label %bb92
bb89:
  %t364 = load i64, ptr %l35, !tbaa !24
  %t365 = load i64, ptr %l34, !tbaa !24
  %t368 = sub i64 %t364, %t365
  %t369 = load i64, ptr %l36, !tbaa !24
  %t372 = add i64 %t368, %t369
  %t374 = sub i64 %t372, 1
  %t375 = load i64, ptr %l36, !tbaa !24
  %t378 = sdiv i64 %t374, %t375
  store i64 %t378, ptr %l269, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l269, !tbaa !24
  br label %bb91
bb91:
  %t380 = load i64, ptr %l269, !tbaa !24
  store i64 %t380, ptr %l266, !tbaa !24
  br label %bb92
bb92:
  %t381 = load i64, ptr %l266, !tbaa !24
  store i64 %t381, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s19
  %t382 = load i64, ptr %l38, !tbaa !24
  %t383 = load i64, ptr %l37, !tbaa !24
  %t386 = icmp slt i64 %t382, %t383
  %t388 = xor i1 %t386, true
  br i1 %t388, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s19)
  br label %bb130
bb95:
  br label %bb96
bb96:
  %t390 = load i64, ptr %l34, !tbaa !24
  %t391 = load i64, ptr %l38, !tbaa !24
  %t392 = load i64, ptr %l36, !tbaa !24
  %t395 = mul i64 %t391, %t392
  %t398 = add i64 %t390, %t395
  store i64 %t398, ptr %l39, !tbaa !24
  %t400 = load ptr, ptr %l3, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Call", ptr %t400, i32 0, i32 1
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  store { i64, ptr } %t403, ptr %l288, !tbaa !27
  %t404 = load i64, ptr %l39, !tbaa !24
  %t406 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr ptr, ptr %t407, i64 %t404
  %t409 = load ptr, ptr %t408, !tbaa !39
  store ptr %t409, ptr %l40, !tbaa !29
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l291, !tbaa !29
  %t412 = load ptr, ptr %l40, !tbaa !29
  %t414 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t412)
  store i32 %t414, ptr %l293
  br label %bb97
bb97:
  %t415 = load ptr, ptr %l291, !tbaa !29
  %t416 = load i32, ptr %l293, !tbaa !23
  %t417 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t415, i32 %t416)
  store i1 %t417, ptr %l294
  br label %bb98
bb98:
  %t418 = load i1, ptr %l294, !tbaa !21
  %t419 = xor i1 %t418, true
  br i1 %t419, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb100:
  br label %bb101
bb101:
  %t421 = load i64, ptr %l39, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t422, 0
  %t427 = icmp slt i64 %t421, %t424
  br i1 %t427, label %bb102, label %bb103
bb102:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/views:Viewer", ptr %t429, i32 0, i32 0
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = getelementptr %"compiler/generic:Program", ptr %t432, i32 0, i32 2
  %t435 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t435, ptr %l304, !tbaa !27
  %t436 = load i64, ptr %l39, !tbaa !24
  %t438 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr i32, ptr %t439, i64 %t436
  %t441 = load i32, ptr %t440, !tbaa !33
  %t444 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t434, i32 %t441)
  store i1 %t444, ptr %l307
  br label %bb104
bb103:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb105
bb104:
  %t445 = load i1, ptr %l307, !tbaa !21
  store i1 %t445, ptr %l300, !tbaa !21
  br label %bb105
bb105:
  %t446 = load i1, ptr %l300, !tbaa !21
  br i1 %t446, label %bb106, label %bb107
bb106:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/views:Viewer", ptr %t447, i32 0, i32 0
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  %t453 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t453, ptr %l312, !tbaa !27
  %t454 = load i64, ptr %l39, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i32, ptr %t457, i64 %t454
  %t459 = load i32, ptr %t458, !tbaa !33
  %t462 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t452, i32 %t459)
  store i64 %t462, ptr %l315
  br label %bb108
bb107:
  store i1 false, ptr %l308, !tbaa !21
  br label %bb109
bb108:
  %t463 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t464 = load i64, ptr %l315, !tbaa !24
  %t466 = and i64 %t464, %t463
  %t468 = icmp eq i64 %t466, 0
  store i1 %t468, ptr %l308, !tbaa !21
  br label %bb109
bb109:
  %t470 = load i1, ptr %l308, !tbaa !21
  br i1 %t470, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb111:
  br label %bb112
bb112:
  %t471 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s19, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t471, ptr %l319
  br label %bb113
bb113:
  %t472 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l319
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t472, ptr %l41
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load ptr, ptr %l40, !tbaa !29
  %t476 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s19, ptr %t473, ptr %t474, ptr %t476, ptr %l41)
  br label %bb114
bb114:
  store ptr %l41, ptr %l42, !tbaa !29
  store i64 0, ptr %l43, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s23
  %t482 = load i64, ptr %l43, !tbaa !24
  store i64 %t482, ptr %l326, !tbaa !24
  %t483 = load ptr, ptr %l42, !tbaa !29
  %t485 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s19, ptr %t483)
  store i64 %t485, ptr %l328
  br label %bb116
bb116:
  %t486 = load i64, ptr %l326, !tbaa !24
  %t487 = load i64, ptr %l328, !tbaa !24
  %t488 = icmp slt i64 %t486, %t487
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s23)
  br label %bb128
bb118:
  br label %bb119
bb119:
  %t492 = load ptr, ptr %l42, !tbaa !29
  %t493 = load i64, ptr %l43, !tbaa !24
  %t496 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s19, ptr %t492, i64 %t493)
  store %"compiler/views:place" %t496, ptr %l333
  br label %bb120
bb120:
  %t497 = load %"compiler/views:place", ptr %l333
  store %"compiler/views:place" %t497, ptr %l44
  store ptr %l23, ptr %l334, !tbaa !29
  %t498 = getelementptr %"compiler/views:place", ptr %l44, i32 0, i32 0
  %t499 = load { i64, [2 x i64] }, ptr %t498
  store { i64, [2 x i64] } %t499, ptr %l335
  %t500 = getelementptr %"compiler/views:place", ptr %l44, i32 0, i32 1
  %t501 = load i64, ptr %t500, !tbaa !24
  store i64 %t501, ptr %l336, !tbaa !24
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/views:Viewer", ptr %t502, i32 0, i32 3
  %t505 = getelementptr %"compiler/views:place", ptr %l44, i32 0, i32 1
  %t506 = load i64, ptr %t505, !tbaa !24
  %t509 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s23, ptr %t504, i64 %t506)
  store { i64, ptr } %t509, ptr %l340
  br label %bb121
bb121:
  %t510 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 0
  %t512 = load { i64, [2 x i64] }, ptr %l335
  %t513 = load i64, ptr %l336, !tbaa !24
  %t515 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s23, { i64, [2 x i64] } %t512, i64 %t513, i64 %t511, i1 true)
  store %"compiler/views:place" %t515, ptr %l342
  br label %bb122
bb122:
  %t516 = load ptr, ptr %l334, !tbaa !29
  %t517 = load %"compiler/views:place", ptr %l342
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t516, %"compiler/views:place" %t517)
  br label %bb123
bb123:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 -1)
  br label %bb124
bb124:
  store ptr %l25, ptr %l344, !tbaa !29
  %t519 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s23, i32 0, i32 0)
  store %"compiler/source:Span" %t519, ptr %l345
  br label %bb125
bb125:
  %t520 = load ptr, ptr %l344, !tbaa !29
  %t521 = load %"compiler/source:Span", ptr %l345
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %t520, %"compiler/source:Span" %t521)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s23)
  br label %bb127
bb127:
  %t522 = load i64, ptr %l43, !tbaa !24
  %t524 = add i64 %t522, 1
  store i64 %t524, ptr %l43, !tbaa !24
  br label %bb115
bb128:
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb129:
  %t526 = load i64, ptr %l38, !tbaa !24
  %t528 = add i64 %t526, 1
  store i64 %t528, ptr %l38, !tbaa !24
  br label %bb93
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/views:Viewer", ptr %t530, i32 0, i32 22
  %t533 = load i1, ptr %t532, !tbaa !21
  br i1 %t533, label %bb133, label %bb134
bb133:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/views:Viewer", ptr %t535, i32 0, i32 23
  %t538 = load i1, ptr %t537, !tbaa !21
  %t540 = xor i1 %t538, true
  store i1 %t540, ptr %l352, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l352, !tbaa !21
  br label %bb135
bb135:
  %t542 = load i1, ptr %l352, !tbaa !21
  br i1 %t542, label %bb136, label %bb137
bb136:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/views:Viewer", ptr %t543, i32 0, i32 24
  %t546 = load i1, ptr %t545, !tbaa !21
  %t548 = xor i1 %t546, true
  store i1 %t548, ptr %l356, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l356, !tbaa !21
  br label %bb138
bb138:
  %t550 = load i1, ptr %l356, !tbaa !21
  br i1 %t550, label %bb139, label %bb140
bb139:
  store i64 0, ptr %l45, !tbaa !24
  %t551 = load i64, ptr %l12, !tbaa !24
  store i64 %t551, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t553 = load i64, ptr %l46, !tbaa !24
  %t554 = load i64, ptr %l45, !tbaa !24
  %t557 = icmp sgt i64 %t553, %t554
  br i1 %t557, label %bb141, label %bb142
bb140:
  br label %bb178
bb141:
  %t559 = load i64, ptr %l47, !tbaa !24
  %t561 = icmp sgt i64 %t559, 0
  br i1 %t561, label %bb143, label %bb144
bb142:
  store i64 0, ptr %l364, !tbaa !24
  br label %bb146
bb143:
  %t563 = load i64, ptr %l46, !tbaa !24
  %t564 = load i64, ptr %l45, !tbaa !24
  %t567 = sub i64 %t563, %t564
  %t568 = load i64, ptr %l47, !tbaa !24
  %t571 = add i64 %t567, %t568
  %t573 = sub i64 %t571, 1
  %t574 = load i64, ptr %l47, !tbaa !24
  %t577 = sdiv i64 %t573, %t574
  store i64 %t577, ptr %l367, !tbaa !24
  br label %bb145
bb144:
  store i64 0, ptr %l367, !tbaa !24
  br label %bb145
bb145:
  %t579 = load i64, ptr %l367, !tbaa !24
  store i64 %t579, ptr %l364, !tbaa !24
  br label %bb146
bb146:
  %t580 = load i64, ptr %l364, !tbaa !24
  store i64 %t580, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb147
bb147:
  %t581 = load i64, ptr %l49, !tbaa !24
  %t582 = load i64, ptr %l48, !tbaa !24
  %t585 = icmp slt i64 %t581, %t582
  %t587 = xor i1 %t585, true
  br i1 %t587, label %bb148, label %bb149
bb148:
  br label %bb177
bb149:
  br label %bb150
bb150:
  %t589 = load i64, ptr %l45, !tbaa !24
  %t590 = load i64, ptr %l49, !tbaa !24
  %t591 = load i64, ptr %l47, !tbaa !24
  %t594 = mul i64 %t590, %t591
  %t597 = add i64 %t589, %t594
  store i64 %t597, ptr %l50, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s29
  %t599 = load i64, ptr %l50, !tbaa !24
  %t602 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H7aeac163056dab12c3a06ffd3ff9511b(ptr %s0, ptr %s29, ptr %l13, i64 %t599)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t602, ptr %l387
  br label %bb151
bb151:
  %t604 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e(ptr %s29, ptr %l387)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t604, ptr %l389
  br label %bb152
bb152:
  %t605 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l389
  %t606 = call ptr @__olang_scope_alloc_a(ptr %s29, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t605, ptr %t606
  store ptr %t606, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb153
bb153:
  %t608 = load i64, ptr %l52, !tbaa !24
  store i64 %t608, ptr %l391, !tbaa !24
  %t609 = load ptr, ptr %l51, !tbaa !29
  %t611 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s29, ptr %t609)
  store i64 %t611, ptr %l393
  br label %bb154
bb154:
  %t612 = load i64, ptr %l391, !tbaa !24
  %t613 = load i64, ptr %l393, !tbaa !24
  %t614 = icmp slt i64 %t612, %t613
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb155, label %bb156
bb155:
  br label %bb175
bb156:
  br label %bb157
bb157:
  %t618 = load ptr, ptr %l51, !tbaa !29
  %t619 = load i64, ptr %l52, !tbaa !24
  %t622 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s29, ptr %t618, i64 %t619)
  store %"compiler/views:view" %t622, ptr %l398
  br label %bb158
bb158:
  %t623 = load %"compiler/views:view", ptr %l398
  store %"compiler/views:view" %t623, ptr %l53
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/views:view", ptr %l53, i32 0, i32 0
  %t626 = load %"compiler/views:place", ptr %t625
  %t630 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrownAt(ptr %v0, ptr %s0, ptr %t624, %"compiler/views:place" %t626, ptr %l23)
  store i64 %t630, ptr %l402
  br label %bb159
bb159:
  %t631 = load i64, ptr %l402, !tbaa !24
  store i64 %t631, ptr %l54, !tbaa !24
  %t632 = load i64, ptr %l54, !tbaa !24
  %t634 = icmp slt i64 %t632, 0
  br i1 %t634, label %bb160, label %bb161
bb160:
  br label %bb174
bb161:
  br label %bb162
bb162:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load ptr, ptr %l3, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Call", ptr %t637, i32 0, i32 1
  %t640 = load { i64, ptr }, ptr %t639, !tbaa !27
  store { i64, ptr } %t640, ptr %l407, !tbaa !27
  %t641 = load i64, ptr %l50, !tbaa !24
  %t643 = getelementptr { i64, ptr }, ptr %l407, i32 0, i32 1
  %t644 = load ptr, ptr %t643, !tbaa !27
  %t645 = getelementptr ptr, ptr %t644, i64 %t641
  %t646 = load ptr, ptr %t645, !tbaa !39
  %t649 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t636, ptr %t646)
  store %"compiler/source:Span" %t649, ptr %l410
  br label %bb163
bb163:
  %t650 = load %"compiler/source:Span", ptr %l410
  store %"compiler/source:Span" %t650, ptr %l55
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load %"compiler/source:Span", ptr %l55
  %t655 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t651, %"compiler/source:Span" %t652)
  store i1 %t655, ptr %l413
  br label %bb164
bb164:
  %t656 = load i1, ptr %l413, !tbaa !21
  %t657 = xor i1 %t656, true
  br i1 %t657, label %bb165, label %bb166
bb165:
  %t659 = load ptr, ptr %l0, !tbaa !29
  store ptr %t659, ptr %l415, !tbaa !29
  %t660 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t660, ptr %l416
  %t661 = getelementptr %"compiler/views:view", ptr %l53, i32 0, i32 0
  %t662 = load %"compiler/views:place", ptr %t661
  store %"compiler/views:place" %t662, ptr %l417
  %t663 = getelementptr %"compiler/views:view", ptr %l53, i32 0, i32 7
  %t664 = load i64, ptr %t663, !tbaa !24
  store i64 %t664, ptr %l418, !tbaa !24
  %t665 = load i64, ptr %l21, !tbaa !24
  store i64 %t665, ptr %l419, !tbaa !24
  %t666 = load i1, ptr %l22, !tbaa !21
  br i1 %t666, label %bb167, label %bb168
bb166:
  br label %bb173
bb167:
  %t668 = load i64, ptr %l54, !tbaa !24
  %t671 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t668)
  store i64 %t671, ptr %l424
  br label %bb169
bb168:
  store i64 -1, ptr %l421, !tbaa !24
  br label %bb170
bb169:
  %t672 = load i64, ptr %l424, !tbaa !24
  store i64 %t672, ptr %l421, !tbaa !24
  br label %bb170
bb170:
  %t673 = load i64, ptr %l54, !tbaa !24
  %t676 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t673)
  store %"compiler/source:Span" %t676, ptr %l427
  br label %bb171
bb171:
  %t677 = load ptr, ptr %l415, !tbaa !29
  %t678 = load %"compiler/source:Span", ptr %l416
  %t679 = load %"compiler/views:place", ptr %l417
  %t680 = load i64, ptr %l418, !tbaa !24
  %t681 = load i64, ptr %l419, !tbaa !24
  %t682 = load i64, ptr %l421, !tbaa !24
  %t683 = load %"compiler/source:Span", ptr %l427
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egivenGrowing(ptr %v0, ptr %t677, %"compiler/source:Span" %t678, %"compiler/views:place" %t679, i64 %t680, i64 %t681, i64 %t682, %"compiler/source:Span" %t683)
  br label %bb172
bb172:
  br label %bb173
bb173:
  br label %bb175
bb174:
  %t684 = load i64, ptr %l52, !tbaa !24
  %t686 = add i64 %t684, 1
  store i64 %t686, ptr %l52, !tbaa !24
  br label %bb153
bb175:
  call void @__olang_scope_close(ptr %s29)
  br label %bb176
bb176:
  %t688 = load i64, ptr %l49, !tbaa !24
  %t690 = add i64 %t688, 1
  store i64 %t690, ptr %l49, !tbaa !24
  br label %bb147
bb177:
  br label %bb178
bb178:
  store i64 0, ptr %l56, !tbaa !24
  %t693 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23)
  store i64 %t693, ptr %l433
  br label %bb179
bb179:
  %t694 = load i64, ptr %l433, !tbaa !24
  store i64 %t694, ptr %l57, !tbaa !24
  store i64 1, ptr %l58, !tbaa !24
  %t695 = load i64, ptr %l57, !tbaa !24
  %t696 = load i64, ptr %l56, !tbaa !24
  %t699 = icmp sgt i64 %t695, %t696
  br i1 %t699, label %bb180, label %bb181
bb180:
  %t701 = load i64, ptr %l58, !tbaa !24
  %t703 = icmp sgt i64 %t701, 0
  br i1 %t703, label %bb182, label %bb183
bb181:
  store i64 0, ptr %l437, !tbaa !24
  br label %bb185
bb182:
  %t705 = load i64, ptr %l57, !tbaa !24
  %t706 = load i64, ptr %l56, !tbaa !24
  %t709 = sub i64 %t705, %t706
  %t710 = load i64, ptr %l58, !tbaa !24
  %t713 = add i64 %t709, %t710
  %t715 = sub i64 %t713, 1
  %t716 = load i64, ptr %l58, !tbaa !24
  %t719 = sdiv i64 %t715, %t716
  store i64 %t719, ptr %l440, !tbaa !24
  br label %bb184
bb183:
  store i64 0, ptr %l440, !tbaa !24
  br label %bb184
bb184:
  %t721 = load i64, ptr %l440, !tbaa !24
  store i64 %t721, ptr %l437, !tbaa !24
  br label %bb185
bb185:
  %t722 = load i64, ptr %l437, !tbaa !24
  store i64 %t722, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb186
bb186:
  %t723 = load i64, ptr %l60, !tbaa !24
  %t724 = load i64, ptr %l59, !tbaa !24
  %t727 = icmp slt i64 %t723, %t724
  %t729 = xor i1 %t727, true
  br i1 %t729, label %bb187, label %bb188
bb187:
  br label %bb195
bb188:
  br label %bb189
bb189:
  %t731 = load i64, ptr %l56, !tbaa !24
  %t732 = load i64, ptr %l60, !tbaa !24
  %t733 = load i64, ptr %l58, !tbaa !24
  %t736 = mul i64 %t732, %t733
  %t739 = add i64 %t731, %t736
  store i64 %t739, ptr %l61, !tbaa !24
  %t741 = load ptr, ptr %l0, !tbaa !29
  store ptr %t741, ptr %l458, !tbaa !29
  %t742 = load i64, ptr %l61, !tbaa !24
  %t745 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23, i64 %t742)
  store %"compiler/views:place" %t745, ptr %l461
  br label %bb190
bb190:
  %t746 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t746, ptr %l462
  %t747 = load i64, ptr %l21, !tbaa !24
  store i64 %t747, ptr %l463, !tbaa !24
  %t748 = load i64, ptr %l61, !tbaa !24
  %t751 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t748)
  store i64 %t751, ptr %l466
  br label %bb191
bb191:
  %t752 = load i64, ptr %l61, !tbaa !24
  %t755 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t752)
  store %"compiler/source:Span" %t755, ptr %l469
  br label %bb192
bb192:
  %t756 = load ptr, ptr %l4, !tbaa !29
  %t757 = load ptr, ptr %l458, !tbaa !29
  %t758 = load %"compiler/views:place", ptr %l461
  %t759 = load %"compiler/source:Span", ptr %l462
  %t760 = load i64, ptr %l463, !tbaa !24
  %t761 = load i64, ptr %l466, !tbaa !24
  %t762 = load %"compiler/source:Span", ptr %l469
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v2, ptr %t757, %"compiler/views:place" %t758, %"compiler/source:Span" %t759, i64 %t760, i64 %t761, %"compiler/source:Span" %t762, ptr %t756)
  br label %bb193
bb193:
  br label %bb194
bb194:
  %t764 = load i64, ptr %l60, !tbaa !24
  %t766 = add i64 %t764, 1
  store i64 %t766, ptr %l60, !tbaa !24
  br label %bb186
bb195:
  store ptr %l6, ptr %l62, !tbaa !29
  store i64 0, ptr %l63, !tbaa !24
  br label %bb196
bb196:
  %t769 = load i64, ptr %l63, !tbaa !24
  store i64 %t769, ptr %l474, !tbaa !24
  %t770 = load ptr, ptr %l62, !tbaa !29
  %t772 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t770)
  store i64 %t772, ptr %l476
  br label %bb197
bb197:
  %t773 = load i64, ptr %l474, !tbaa !24
  %t774 = load i64, ptr %l476, !tbaa !24
  %t775 = icmp slt i64 %t773, %t774
  %t777 = xor i1 %t775, true
  br i1 %t777, label %bb198, label %bb199
bb198:
  br label %bb204
bb199:
  br label %bb200
bb200:
  %t779 = load ptr, ptr %l62, !tbaa !29
  %t780 = load i64, ptr %l63, !tbaa !24
  %t783 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t779, i64 %t780)
  store %"compiler/views:view" %t783, ptr %l481
  br label %bb201
bb201:
  %t784 = load %"compiler/views:view", ptr %l481
  %t785 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t785, %"compiler/views:view" %t784)
  br label %bb202
bb202:
  br label %bb203
bb203:
  %t789 = load i64, ptr %l63, !tbaa !24
  %t791 = add i64 %t789, 1
  store i64 %t791, ptr %l63, !tbaa !24
  br label %bb196
bb204:
  %t793 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t793, ptr %l486
  br label %bb205
bb205:
  %t794 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l486
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t794, ptr %l65
  store i64 0, ptr %l66, !tbaa !24
  %t795 = load i64, ptr %l12, !tbaa !24
  store i64 %t795, ptr %l67, !tbaa !24
  store i64 1, ptr %l68, !tbaa !24
  %t797 = load i64, ptr %l67, !tbaa !24
  %t798 = load i64, ptr %l66, !tbaa !24
  %t801 = icmp sgt i64 %t797, %t798
  br i1 %t801, label %bb206, label %bb207
bb206:
  %t803 = load i64, ptr %l68, !tbaa !24
  %t805 = icmp sgt i64 %t803, 0
  br i1 %t805, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l491, !tbaa !24
  br label %bb211
bb208:
  %t807 = load i64, ptr %l67, !tbaa !24
  %t808 = load i64, ptr %l66, !tbaa !24
  %t811 = sub i64 %t807, %t808
  %t812 = load i64, ptr %l68, !tbaa !24
  %t815 = add i64 %t811, %t812
  %t817 = sub i64 %t815, 1
  %t818 = load i64, ptr %l68, !tbaa !24
  %t821 = sdiv i64 %t817, %t818
  store i64 %t821, ptr %l494, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l494, !tbaa !24
  br label %bb210
bb210:
  %t823 = load i64, ptr %l494, !tbaa !24
  store i64 %t823, ptr %l491, !tbaa !24
  br label %bb211
bb211:
  %t824 = load i64, ptr %l491, !tbaa !24
  store i64 %t824, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  br label %bb212
bb212:
  %t825 = load i64, ptr %l70, !tbaa !24
  %t826 = load i64, ptr %l69, !tbaa !24
  %t829 = icmp slt i64 %t825, %t826
  %t831 = xor i1 %t829, true
  br i1 %t831, label %bb213, label %bb214
bb213:
  br label %bb218
bb214:
  br label %bb215
bb215:
  %t833 = load i64, ptr %l66, !tbaa !24
  %t834 = load i64, ptr %l70, !tbaa !24
  %t835 = load i64, ptr %l68, !tbaa !24
  %t838 = mul i64 %t834, %t835
  %t841 = add i64 %t833, %t838
  store i64 %t841, ptr %l71, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l65, i1 false)
  br label %bb216
bb216:
  br label %bb217
bb217:
  %t844 = load i64, ptr %l70, !tbaa !24
  %t846 = add i64 %t844, 1
  store i64 %t846, ptr %l70, !tbaa !24
  br label %bb212
bb218:
  %t848 = load i1, ptr %l22, !tbaa !21
  br i1 %t848, label %bb219, label %bb220
bb219:
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/views:Viewer", ptr %t850, i32 0, i32 2
  %t853 = load i64, ptr %l7, !tbaa !24
  %t856 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t852, i64 %t853)
  store ptr %t856, ptr %l519
  br label %bb221
bb220:
  br label %bb258
bb221:
  %t857 = load ptr, ptr %l519, !tbaa !29
  %t859 = getelementptr %"compiler/views:summary", ptr %t857, i32 0, i32 1
  store ptr %t859, ptr %l72, !tbaa !29
  store i64 0, ptr %l73, !tbaa !24
  br label %bb222
bb222:
  store %olang.scope zeroinitializer, ptr %s46
  %t861 = load i64, ptr %l73, !tbaa !24
  store i64 %t861, ptr %l522, !tbaa !24
  %t862 = load ptr, ptr %l72, !tbaa !29
  %t864 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t862)
  store i64 %t864, ptr %l524
  br label %bb223
bb223:
  %t865 = load i64, ptr %l522, !tbaa !24
  %t866 = load i64, ptr %l524, !tbaa !24
  %t867 = icmp slt i64 %t865, %t866
  %t869 = xor i1 %t867, true
  br i1 %t869, label %bb224, label %bb225
bb224:
  call void @__olang_scope_close(ptr %s46)
  br label %bb257
bb225:
  br label %bb226
bb226:
  %t871 = load ptr, ptr %l72, !tbaa !29
  %t872 = load i64, ptr %l73, !tbaa !24
  %t875 = call %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t871, i64 %t872)
  store %"compiler/views:fact" %t875, ptr %l529
  br label %bb227
bb227:
  %t876 = load %"compiler/views:fact", ptr %l529
  store %"compiler/views:fact" %t876, ptr %l74
  %t877 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 0
  %t878 = load i64, ptr %t877, !tbaa !24
  %t880 = icmp slt i64 %t878, 0
  br i1 %t880, label %bb228, label %bb229
bb228:
  store i1 true, ptr %l532, !tbaa !21
  br label %bb230
bb229:
  %t882 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 0
  %t883 = load i64, ptr %t882, !tbaa !24
  %t884 = load i64, ptr %l12, !tbaa !24
  %t887 = icmp sge i64 %t883, %t884
  store i1 %t887, ptr %l532, !tbaa !21
  br label %bb230
bb230:
  %t889 = load i1, ptr %l532, !tbaa !21
  br i1 %t889, label %bb231, label %bb232
bb231:
  call void @__olang_scope_close(ptr %s46)
  br label %bb256
bb232:
  br label %bb233
bb233:
  %t890 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 0
  %t891 = load i64, ptr %t890, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l65, i64 %t891, i1 true)
  br label %bb234
bb234:
  %t894 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s46, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t894, ptr %l538
  br label %bb235
bb235:
  %t895 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l538
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t895, ptr %l75
  %t896 = load ptr, ptr %l0, !tbaa !29
  %t897 = load ptr, ptr %l3, !tbaa !29
  %t899 = getelementptr %"compiler/typed:Call", ptr %t897, i32 0, i32 1
  %t900 = load { i64, ptr }, ptr %t899, !tbaa !27
  store { i64, ptr } %t900, ptr %l541, !tbaa !27
  %t901 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 0
  %t902 = load i64, ptr %t901, !tbaa !24
  %t904 = getelementptr { i64, ptr }, ptr %l541, i32 0, i32 1
  %t905 = load ptr, ptr %t904, !tbaa !27
  %t906 = getelementptr ptr, ptr %t905, i64 %t902
  %t907 = load ptr, ptr %t906, !tbaa !39
  %t909 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s46, ptr %t896, ptr %t907, ptr %t909, ptr %l75)
  br label %bb236
bb236:
  store ptr %l75, ptr %l76, !tbaa !29
  store i64 0, ptr %l77, !tbaa !24
  br label %bb237
bb237:
  store %olang.scope zeroinitializer, ptr %s49
  %t915 = load i64, ptr %l77, !tbaa !24
  store i64 %t915, ptr %l548, !tbaa !24
  %t916 = load ptr, ptr %l76, !tbaa !29
  %t918 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s46, ptr %t916)
  store i64 %t918, ptr %l550
  br label %bb238
bb238:
  %t919 = load i64, ptr %l548, !tbaa !24
  %t920 = load i64, ptr %l550, !tbaa !24
  %t921 = icmp slt i64 %t919, %t920
  %t923 = xor i1 %t921, true
  br i1 %t923, label %bb239, label %bb240
bb239:
  call void @__olang_scope_close(ptr %s49)
  br label %bb255
bb240:
  br label %bb241
bb241:
  %t925 = load ptr, ptr %l76, !tbaa !29
  %t926 = load i64, ptr %l77, !tbaa !24
  %t929 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s46, ptr %t925, i64 %t926)
  store %"compiler/views:place" %t929, ptr %l555
  br label %bb242
bb242:
  %t930 = load %"compiler/views:place", ptr %l555
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t933 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 3
  %t934 = load i64, ptr %t933, !tbaa !24
  %t935 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 4
  %t936 = load i64, ptr %t935, !tbaa !24
  %t937 = getelementptr %"compiler/views:fact", ptr %l74, i32 0, i32 5
  %t938 = load i1, ptr %t937, !tbaa !21
  %t944 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t931, %"compiler/views:place" %t930, i64 %t934, i64 %t936, i1 %t938)
  store %"compiler/views:place" %t944, ptr %l561
  br label %bb243
bb243:
  %t945 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t946 = load i32, ptr %t945, !tbaa !23
  %t948 = sext i32 %t946 to i64
  %t949 = load %"compiler/views:place", ptr %l561
  %t951 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s49, %"compiler/views:place" %t949, i64 %t948)
  store %"compiler/views:view" %t951, ptr %l564
  br label %bb244
bb244:
  %t952 = load %"compiler/views:view", ptr %l564
  store %"compiler/views:view" %t952, ptr %l79
  %t953 = load ptr, ptr %l0, !tbaa !29
  %t955 = getelementptr %"compiler/views:Viewer", ptr %t953, i32 0, i32 1
  %t956 = load i64, ptr %l7, !tbaa !24
  %t959 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t955, i64 %t956)
  store ptr %t959, ptr %l568
  br label %bb245
bb245:
  %t960 = load ptr, ptr %l568, !tbaa !29
  %t962 = getelementptr %"compiler/typed:Body", ptr %t960, i32 0, i32 3
  %t963 = load i64, ptr %t962, !tbaa !24
  %t964 = load ptr, ptr %l0, !tbaa !29
  %t966 = getelementptr %"compiler/views:Viewer", ptr %t964, i32 0, i32 7
  %t967 = load i64, ptr %t966, !tbaa !24
  %t970 = icmp eq i64 %t963, %t967
  br i1 %t970, label %bb246, label %bb247
bb246:
  store i64 1, ptr %l574, !tbaa !24
  br label %bb252
bb247:
  %t972 = load ptr, ptr %l0, !tbaa !29
  %t974 = getelementptr %"compiler/views:Viewer", ptr %t972, i32 0, i32 1
  %t975 = load i64, ptr %l7, !tbaa !24
  %t978 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t974, i64 %t975)
  store ptr %t978, ptr %l578
  br label %bb248
bb248:
  %t979 = load ptr, ptr %l578, !tbaa !29
  %t981 = getelementptr %"compiler/typed:Body", ptr %t979, i32 0, i32 3
  %t982 = load i64, ptr %t981, !tbaa !24
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t985 = getelementptr %"compiler/views:Viewer", ptr %t983, i32 0, i32 8
  %t986 = load i64, ptr %t985, !tbaa !24
  %t989 = icmp eq i64 %t982, %t986
  br i1 %t989, label %bb249, label %bb250
bb249:
  store i64 2, ptr %l584, !tbaa !24
  br label %bb251
bb250:
  store i64 0, ptr %l584, !tbaa !24
  br label %bb251
bb251:
  %t991 = load i64, ptr %l584, !tbaa !24
  store i64 %t991, ptr %l574, !tbaa !24
  br label %bb252
bb252:
  %t992 = load i64, ptr %l574, !tbaa !24
  %t993 = getelementptr %"compiler/views:view", ptr %l79, i32 0, i32 7
  store i64 %t992, ptr %t993, !tbaa !24
  %t994 = load ptr, ptr %l5, !tbaa !29
  %t995 = load %"compiler/views:view", ptr %l79
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t994, %"compiler/views:view" %t995)
  br label %bb253
bb253:
  call void @__olang_scope_close(ptr %s49)
  br label %bb254
bb254:
  %t998 = load i64, ptr %l77, !tbaa !24
  %t1000 = add i64 %t998, 1
  store i64 %t1000, ptr %l77, !tbaa !24
  br label %bb237
bb255:
  call void @__olang_scope_close(ptr %s46)
  br label %bb256
bb256:
  %t1002 = load i64, ptr %l73, !tbaa !24
  %t1004 = add i64 %t1002, 1
  store i64 %t1004, ptr %l73, !tbaa !24
  br label %bb222
bb257:
  br label %bb258
bb258:
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = load i32, ptr %l2, !tbaa !23
  %t1010 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t1006, i32 %t1007)
  store i1 %t1010, ptr %l593
  br label %bb259
bb259:
  %t1011 = load i1, ptr %l593, !tbaa !21
  br i1 %t1011, label %bb260, label %bb261
bb260:
  store i64 0, ptr %l80, !tbaa !24
  %t1012 = load i64, ptr %l12, !tbaa !24
  store i64 %t1012, ptr %l81, !tbaa !24
  store i64 1, ptr %l82, !tbaa !24
  %t1014 = load i64, ptr %l81, !tbaa !24
  %t1015 = load i64, ptr %l80, !tbaa !24
  %t1018 = icmp sgt i64 %t1014, %t1015
  br i1 %t1018, label %bb262, label %bb263
bb261:
  br label %bb334
bb262:
  %t1020 = load i64, ptr %l82, !tbaa !24
  %t1022 = icmp sgt i64 %t1020, 0
  br i1 %t1022, label %bb264, label %bb265
bb263:
  store i64 0, ptr %l598, !tbaa !24
  br label %bb267
bb264:
  %t1024 = load i64, ptr %l81, !tbaa !24
  %t1025 = load i64, ptr %l80, !tbaa !24
  %t1028 = sub i64 %t1024, %t1025
  %t1029 = load i64, ptr %l82, !tbaa !24
  %t1032 = add i64 %t1028, %t1029
  %t1034 = sub i64 %t1032, 1
  %t1035 = load i64, ptr %l82, !tbaa !24
  %t1038 = sdiv i64 %t1034, %t1035
  store i64 %t1038, ptr %l601, !tbaa !24
  br label %bb266
bb265:
  store i64 0, ptr %l601, !tbaa !24
  br label %bb266
bb266:
  %t1040 = load i64, ptr %l601, !tbaa !24
  store i64 %t1040, ptr %l598, !tbaa !24
  br label %bb267
bb267:
  %t1041 = load i64, ptr %l598, !tbaa !24
  store i64 %t1041, ptr %l83, !tbaa !24
  store i64 0, ptr %l84, !tbaa !24
  br label %bb268
bb268:
  %t1042 = load i64, ptr %l84, !tbaa !24
  %t1043 = load i64, ptr %l83, !tbaa !24
  %t1046 = icmp slt i64 %t1042, %t1043
  %t1048 = xor i1 %t1046, true
  br i1 %t1048, label %bb269, label %bb270
bb269:
  br label %bb333
bb270:
  br label %bb271
bb271:
  %t1050 = load i64, ptr %l80, !tbaa !24
  %t1051 = load i64, ptr %l84, !tbaa !24
  %t1052 = load i64, ptr %l82, !tbaa !24
  %t1055 = mul i64 %t1051, %t1052
  %t1058 = add i64 %t1050, %t1055
  store i64 %t1058, ptr %l85, !tbaa !24
  %t1060 = load i64, ptr %l85, !tbaa !24
  %t1063 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l65, i64 %t1060)
  store i1 %t1063, ptr %l621
  br label %bb272
bb272:
  %t1064 = load i1, ptr %l621, !tbaa !21
  br i1 %t1064, label %bb273, label %bb274
bb273:
  br label %bb332
bb274:
  br label %bb275
bb275:
  %t1065 = load i1, ptr %l8, !tbaa !21
  br i1 %t1065, label %bb276, label %bb277
bb276:
  store i1 true, ptr %l623, !tbaa !21
  br label %bb291
bb277:
  %t1067 = load i64, ptr %l7, !tbaa !24
  %t1069 = icmp sge i64 %t1067, 0
  br i1 %t1069, label %bb278, label %bb279
bb278:
  %t1071 = load i1, ptr %l22, !tbaa !21
  %t1073 = xor i1 %t1071, true
  br i1 %t1073, label %bb280, label %bb281
bb279:
  store i1 false, ptr %l626, !tbaa !21
  br label %bb290
bb280:
  store i1 true, ptr %l629, !tbaa !21
  br label %bb289
bb281:
  %t1075 = load i64, ptr %l85, !tbaa !24
  store i64 %t1075, ptr %l630, !tbaa !24
  %t1076 = load ptr, ptr %l0, !tbaa !29
  %t1078 = getelementptr %"compiler/views:Viewer", ptr %t1076, i32 0, i32 2
  %t1079 = load i64, ptr %l7, !tbaa !24
  %t1082 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t1078, i64 %t1079)
  store ptr %t1082, ptr %l634
  br label %bb282
bb282:
  %t1083 = load ptr, ptr %l634, !tbaa !29
  %t1085 = getelementptr %"compiler/views:summary", ptr %t1083, i32 0, i32 3
  %t1087 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1085)
  store i64 %t1087, ptr %l637
  br label %bb283
bb283:
  %t1088 = load i64, ptr %l630, !tbaa !24
  %t1089 = load i64, ptr %l637, !tbaa !24
  %t1090 = icmp slt i64 %t1088, %t1089
  br i1 %t1090, label %bb284, label %bb285
bb284:
  %t1092 = load ptr, ptr %l0, !tbaa !29
  %t1094 = getelementptr %"compiler/views:Viewer", ptr %t1092, i32 0, i32 2
  %t1095 = load i64, ptr %l7, !tbaa !24
  %t1098 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t1094, i64 %t1095)
  store ptr %t1098, ptr %l643
  br label %bb286
bb285:
  store i1 false, ptr %l639, !tbaa !21
  br label %bb288
bb286:
  %t1099 = load ptr, ptr %l643, !tbaa !29
  %t1101 = getelementptr %"compiler/views:summary", ptr %t1099, i32 0, i32 3
  %t1102 = load i64, ptr %l85, !tbaa !24
  %t1105 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1101, i64 %t1102)
  store i1 %t1105, ptr %l647
  br label %bb287
bb287:
  %t1106 = load i1, ptr %l647, !tbaa !21
  store i1 %t1106, ptr %l639, !tbaa !21
  br label %bb288
bb288:
  %t1107 = load i1, ptr %l639, !tbaa !21
  store i1 %t1107, ptr %l629, !tbaa !21
  br label %bb289
bb289:
  %t1108 = load i1, ptr %l629, !tbaa !21
  store i1 %t1108, ptr %l626, !tbaa !21
  br label %bb290
bb290:
  %t1109 = load i1, ptr %l626, !tbaa !21
  store i1 %t1109, ptr %l623, !tbaa !21
  br label %bb291
bb291:
  %t1110 = load i1, ptr %l623, !tbaa !21
  br i1 %t1110, label %bb292, label %bb293
bb292:
  store %olang.scope zeroinitializer, ptr %s57
  %t1113 = load i64, ptr %l85, !tbaa !24
  %t1116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H7aeac163056dab12c3a06ffd3ff9511b(ptr %s0, ptr %s57, ptr %l13, i64 %t1113)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1116, ptr %l651
  br label %bb294
bb293:
  br label %bb305
bb294:
  %t1118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e(ptr %s57, ptr %l651)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1118, ptr %l653
  br label %bb295
bb295:
  %t1119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l653
  %t1120 = call ptr @__olang_scope_alloc_a(ptr %s57, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1119, ptr %t1120
  store ptr %t1120, ptr %l87, !tbaa !29
  store i64 0, ptr %l88, !tbaa !24
  br label %bb296
bb296:
  %t1122 = load i64, ptr %l88, !tbaa !24
  store i64 %t1122, ptr %l655, !tbaa !24
  %t1123 = load ptr, ptr %l87, !tbaa !29
  %t1125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s57, ptr %t1123)
  store i64 %t1125, ptr %l657
  br label %bb297
bb297:
  %t1126 = load i64, ptr %l655, !tbaa !24
  %t1127 = load i64, ptr %l657, !tbaa !24
  %t1128 = icmp slt i64 %t1126, %t1127
  %t1130 = xor i1 %t1128, true
  br i1 %t1130, label %bb298, label %bb299
bb298:
  br label %bb304
bb299:
  br label %bb300
bb300:
  %t1132 = load ptr, ptr %l87, !tbaa !29
  %t1133 = load i64, ptr %l88, !tbaa !24
  %t1136 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s57, ptr %t1132, i64 %t1133)
  store %"compiler/views:view" %t1136, ptr %l662
  br label %bb301
bb301:
  %t1137 = load %"compiler/views:view", ptr %l662
  %t1138 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1138, %"compiler/views:view" %t1137)
  br label %bb302
bb302:
  br label %bb303
bb303:
  %t1142 = load i64, ptr %l88, !tbaa !24
  %t1144 = add i64 %t1142, 1
  store i64 %t1144, ptr %l88, !tbaa !24
  br label %bb296
bb304:
  call void @__olang_scope_close(ptr %s57)
  br label %bb305
bb305:
  %t1146 = load i1, ptr %l8, !tbaa !21
  br i1 %t1146, label %bb306, label %bb307
bb306:
  %t1148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1148, ptr %l669, !tbaa !29
  %t1149 = load ptr, ptr %l3, !tbaa !29
  %t1151 = getelementptr %"compiler/typed:Call", ptr %t1149, i32 0, i32 1
  %t1152 = load { i64, ptr }, ptr %t1151, !tbaa !27
  store { i64, ptr } %t1152, ptr %l671, !tbaa !27
  %t1153 = load i64, ptr %l85, !tbaa !24
  %t1155 = getelementptr { i64, ptr }, ptr %l671, i32 0, i32 1
  %t1156 = load ptr, ptr %t1155, !tbaa !27
  %t1157 = getelementptr ptr, ptr %t1156, i64 %t1153
  %t1158 = load ptr, ptr %t1157, !tbaa !39
  %t1160 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1158)
  store i32 %t1160, ptr %l674
  br label %bb308
bb307:
  store i1 false, ptr %l668, !tbaa !21
  br label %bb310
bb308:
  %t1161 = load ptr, ptr %l669, !tbaa !29
  %t1162 = load i32, ptr %l674, !tbaa !23
  %t1163 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t1161, i32 %t1162)
  store i1 %t1163, ptr %l675
  br label %bb309
bb309:
  %t1164 = load i1, ptr %l675, !tbaa !21
  store i1 %t1164, ptr %l668, !tbaa !21
  br label %bb310
bb310:
  %t1165 = load i1, ptr %l668, !tbaa !21
  br i1 %t1165, label %bb311, label %bb312
bb311:
  %t1166 = load ptr, ptr %l0, !tbaa !29
  %t1167 = load i32, ptr %l2, !tbaa !23
  %t1170 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %t1166, i32 %t1167)
  store i1 %t1170, ptr %l679
  br label %bb313
bb312:
  store i1 false, ptr %l676, !tbaa !21
  br label %bb314
bb313:
  %t1171 = load i1, ptr %l679, !tbaa !21
  store i1 %t1171, ptr %l676, !tbaa !21
  br label %bb314
bb314:
  %t1172 = load i1, ptr %l676, !tbaa !21
  br i1 %t1172, label %bb315, label %bb316
bb315:
  store %olang.scope zeroinitializer, ptr %s60
  %t1173 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s60, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1173, ptr %l680
  br label %bb317
bb316:
  br label %bb331
bb317:
  %t1174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l680
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1174, ptr %l90
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1176 = load ptr, ptr %l3, !tbaa !29
  %t1178 = getelementptr %"compiler/typed:Call", ptr %t1176, i32 0, i32 1
  %t1179 = load { i64, ptr }, ptr %t1178, !tbaa !27
  store { i64, ptr } %t1179, ptr %l683, !tbaa !27
  %t1180 = load i64, ptr %l85, !tbaa !24
  %t1182 = getelementptr { i64, ptr }, ptr %l683, i32 0, i32 1
  %t1183 = load ptr, ptr %t1182, !tbaa !27
  %t1184 = getelementptr ptr, ptr %t1183, i64 %t1180
  %t1185 = load ptr, ptr %t1184, !tbaa !39
  %t1187 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s60, ptr %t1175, ptr %t1185, ptr %t1187, ptr %l90)
  br label %bb318
bb318:
  store ptr %l90, ptr %l91, !tbaa !29
  store i64 0, ptr %l92, !tbaa !24
  br label %bb319
bb319:
  store %olang.scope zeroinitializer, ptr %s62
  %t1193 = load i64, ptr %l92, !tbaa !24
  store i64 %t1193, ptr %l690, !tbaa !24
  %t1194 = load ptr, ptr %l91, !tbaa !29
  %t1196 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s60, ptr %t1194)
  store i64 %t1196, ptr %l692
  br label %bb320
bb320:
  %t1197 = load i64, ptr %l690, !tbaa !24
  %t1198 = load i64, ptr %l692, !tbaa !24
  %t1199 = icmp slt i64 %t1197, %t1198
  %t1201 = xor i1 %t1199, true
  br i1 %t1201, label %bb321, label %bb322
bb321:
  call void @__olang_scope_close(ptr %s62)
  br label %bb330
bb322:
  br label %bb323
bb323:
  %t1203 = load ptr, ptr %l91, !tbaa !29
  %t1204 = load i64, ptr %l92, !tbaa !24
  %t1207 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s60, ptr %t1203, i64 %t1204)
  store %"compiler/views:place" %t1207, ptr %l697
  br label %bb324
bb324:
  %t1208 = load %"compiler/views:place", ptr %l697
  store %"compiler/views:place" %t1208, ptr %l93
  %t1209 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1209, ptr %l698, !tbaa !29
  %t1210 = getelementptr %"compiler/views:place", ptr %l93, i32 0, i32 0
  %t1211 = load { i64, [2 x i64] }, ptr %t1210
  store { i64, [2 x i64] } %t1211, ptr %l699
  %t1212 = getelementptr %"compiler/views:place", ptr %l93, i32 0, i32 1
  %t1213 = load i64, ptr %t1212, !tbaa !24
  store i64 %t1213, ptr %l700, !tbaa !24
  %t1214 = load ptr, ptr %l0, !tbaa !29
  %t1216 = getelementptr %"compiler/views:Viewer", ptr %t1214, i32 0, i32 3
  %t1217 = getelementptr %"compiler/views:place", ptr %l93, i32 0, i32 1
  %t1218 = load i64, ptr %t1217, !tbaa !24
  %t1221 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s62, ptr %t1216, i64 %t1218)
  store { i64, ptr } %t1221, ptr %l704
  br label %bb325
bb325:
  %t1222 = load { i64, ptr }, ptr %l704, !tbaa !27
  %t1223 = extractvalue { i64, ptr } %t1222, 0
  %t1224 = load { i64, [2 x i64] }, ptr %l699
  %t1225 = load i64, ptr %l700, !tbaa !24
  %t1227 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s62, { i64, [2 x i64] } %t1224, i64 %t1225, i64 %t1223, i1 true)
  store %"compiler/views:place" %t1227, ptr %l706
  br label %bb326
bb326:
  %t1228 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t1229 = load i32, ptr %t1228, !tbaa !23
  %t1231 = sext i32 %t1229 to i64
  %t1232 = load %"compiler/views:place", ptr %l706
  %t1234 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s62, %"compiler/views:place" %t1232, i64 %t1231)
  store %"compiler/views:view" %t1234, ptr %l709
  br label %bb327
bb327:
  %t1235 = load ptr, ptr %l698, !tbaa !29
  %t1236 = load %"compiler/views:view", ptr %l709
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1235, %"compiler/views:view" %t1236)
  br label %bb328
bb328:
  call void @__olang_scope_close(ptr %s62)
  br label %bb329
bb329:
  %t1237 = load i64, ptr %l92, !tbaa !24
  %t1239 = add i64 %t1237, 1
  store i64 %t1239, ptr %l92, !tbaa !24
  br label %bb319
bb330:
  call void @__olang_scope_close(ptr %s60)
  br label %bb331
bb331:
  br label %bb332
bb332:
  %t1241 = load i64, ptr %l84, !tbaa !24
  %t1243 = add i64 %t1241, 1
  store i64 %t1243, ptr %l84, !tbaa !24
  br label %bb268
bb333:
  br label %bb334
bb334:
  %t1245 = load i1, ptr %l22, !tbaa !21
  br i1 %t1245, label %bb335, label %bb336
bb335:
  %t1247 = load ptr, ptr %l0, !tbaa !29
  %t1249 = getelementptr %"compiler/views:Viewer", ptr %t1247, i32 0, i32 23
  %t1250 = load i1, ptr %t1249, !tbaa !21
  %t1252 = xor i1 %t1250, true
  store i1 %t1252, ptr %l715, !tbaa !21
  br label %bb337
bb336:
  store i1 false, ptr %l715, !tbaa !21
  br label %bb337
bb337:
  %t1254 = load i1, ptr %l715, !tbaa !21
  br i1 %t1254, label %bb338, label %bb339
bb338:
  %t1255 = load ptr, ptr %l0, !tbaa !29
  %t1257 = getelementptr %"compiler/views:Viewer", ptr %t1255, i32 0, i32 2
  %t1258 = load i64, ptr %l7, !tbaa !24
  %t1261 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t1257, i64 %t1258)
  store ptr %t1261, ptr %l722
  br label %bb340
bb339:
  br label %bb370
bb340:
  %t1262 = load ptr, ptr %l722, !tbaa !29
  %t1264 = getelementptr %"compiler/views:summary", ptr %t1262, i32 0, i32 2
  store ptr %t1264, ptr %l94, !tbaa !29
  store i64 0, ptr %l95, !tbaa !24
  br label %bb341
bb341:
  store %olang.scope zeroinitializer, ptr %s67
  %t1266 = load i64, ptr %l95, !tbaa !24
  store i64 %t1266, ptr %l725, !tbaa !24
  %t1267 = load ptr, ptr %l94, !tbaa !29
  %t1269 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t1267)
  store i64 %t1269, ptr %l727
  br label %bb342
bb342:
  %t1270 = load i64, ptr %l725, !tbaa !24
  %t1271 = load i64, ptr %l727, !tbaa !24
  %t1272 = icmp slt i64 %t1270, %t1271
  %t1274 = xor i1 %t1272, true
  br i1 %t1274, label %bb343, label %bb344
bb343:
  call void @__olang_scope_close(ptr %s67)
  br label %bb369
bb344:
  br label %bb345
bb345:
  %t1276 = load ptr, ptr %l94, !tbaa !29
  %t1277 = load i64, ptr %l95, !tbaa !24
  %t1280 = call %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t1276, i64 %t1277)
  store %"compiler/views:fact" %t1280, ptr %l732
  br label %bb346
bb346:
  %t1281 = load %"compiler/views:fact", ptr %l732
  store %"compiler/views:fact" %t1281, ptr %l96
  %t1282 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 0
  %t1283 = load i64, ptr %t1282, !tbaa !24
  %t1285 = icmp slt i64 %t1283, 0
  br i1 %t1285, label %bb347, label %bb348
bb347:
  store i1 true, ptr %l735, !tbaa !21
  br label %bb349
bb348:
  %t1287 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 0
  %t1288 = load i64, ptr %t1287, !tbaa !24
  %t1289 = load i64, ptr %l12, !tbaa !24
  %t1292 = icmp sge i64 %t1288, %t1289
  store i1 %t1292, ptr %l735, !tbaa !21
  br label %bb349
bb349:
  %t1294 = load i1, ptr %l735, !tbaa !21
  br i1 %t1294, label %bb350, label %bb351
bb350:
  store i1 true, ptr %l739, !tbaa !21
  br label %bb352
bb351:
  %t1295 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 8
  %t1296 = load i64, ptr %t1295, !tbaa !24
  %t1298 = icmp slt i64 %t1296, 0
  store i1 %t1298, ptr %l739, !tbaa !21
  br label %bb352
bb352:
  %t1300 = load i1, ptr %l739, !tbaa !21
  br i1 %t1300, label %bb353, label %bb354
bb353:
  store i1 true, ptr %l742, !tbaa !21
  br label %bb355
bb354:
  %t1301 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 8
  %t1302 = load i64, ptr %t1301, !tbaa !24
  %t1303 = load i64, ptr %l12, !tbaa !24
  %t1306 = icmp sge i64 %t1302, %t1303
  store i1 %t1306, ptr %l742, !tbaa !21
  br label %bb355
bb355:
  %t1308 = load i1, ptr %l742, !tbaa !21
  br i1 %t1308, label %bb356, label %bb357
bb356:
  store i1 true, ptr %l746, !tbaa !21
  br label %bb360
bb357:
  %t1309 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 0
  %t1310 = load i64, ptr %t1309, !tbaa !24
  %t1313 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H7aeac163056dab12c3a06ffd3ff9511b(ptr %s0, ptr %s0, ptr %l13, i64 %t1310)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1313, ptr %l749
  br label %bb358
bb358:
  %t1315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %l749)
  store i64 %t1315, ptr %l751
  br label %bb359
bb359:
  %t1316 = load i64, ptr %l751, !tbaa !24
  %t1317 = icmp eq i64 %t1316, 0
  store i1 %t1317, ptr %l746, !tbaa !21
  br label %bb360
bb360:
  %t1319 = load i1, ptr %l746, !tbaa !21
  br i1 %t1319, label %bb361, label %bb362
bb361:
  call void @__olang_scope_close(ptr %s67)
  br label %bb368
bb362:
  br label %bb363
bb363:
  %t1320 = load ptr, ptr %l3, !tbaa !29
  %t1322 = getelementptr %"compiler/typed:Call", ptr %t1320, i32 0, i32 1
  %t1323 = load { i64, ptr }, ptr %t1322, !tbaa !27
  store { i64, ptr } %t1323, ptr %l754, !tbaa !27
  %t1324 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 8
  %t1325 = load i64, ptr %t1324, !tbaa !24
  %t1327 = getelementptr { i64, ptr }, ptr %l754, i32 0, i32 1
  %t1328 = load ptr, ptr %t1327, !tbaa !27
  %t1329 = getelementptr ptr, ptr %t1328, i64 %t1325
  %t1330 = load ptr, ptr %t1329, !tbaa !39
  store ptr %t1330, ptr %l97, !tbaa !29
  %t1332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1332, ptr %l757, !tbaa !29
  %t1333 = load ptr, ptr %l97, !tbaa !29
  %t1335 = call ptr @compiler_2fviews_2eargPlace(ptr %v1, ptr %v1, ptr %t1333)
  store ptr %t1335, ptr %l759
  br label %bb364
bb364:
  %t1336 = load ptr, ptr %l97, !tbaa !29
  %t1338 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1336)
  store i32 %t1338, ptr %l761
  br label %bb365
bb365:
  %t1339 = getelementptr %"compiler/views:fact", ptr %l96, i32 0, i32 0
  %t1340 = load i64, ptr %t1339, !tbaa !24
  %t1343 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H7aeac163056dab12c3a06ffd3ff9511b(ptr %s0, ptr %s0, ptr %l13, i64 %t1340)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1343, ptr %l764
  br label %bb366
bb366:
  %t1344 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l764
  %t1345 = call ptr @__olang_scope_alloc_a(ptr %s67, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1344, ptr %t1345
  %t1346 = load ptr, ptr %l4, !tbaa !29
  %t1347 = load ptr, ptr %l757, !tbaa !29
  %t1348 = load ptr, ptr %l759, !tbaa !29
  %t1349 = load i32, ptr %l761, !tbaa !23
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t1347, ptr %t1348, i32 %t1349, ptr %t1345, ptr %t1346)
  br label %bb367
bb367:
  call void @__olang_scope_close(ptr %s67)
  br label %bb368
bb368:
  %t1352 = load i64, ptr %l95, !tbaa !24
  %t1354 = add i64 %t1352, 1
  store i64 %t1354, ptr %l95, !tbaa !24
  br label %bb341
bb369:
  br label %bb370
bb370:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:fact"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca %"compiler/views:place"
  %l15 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l33 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca %"compiler/views:fact"
  %l53 = alloca i1
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca { i64, ptr }
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca %"compiler/views:place"
  %l82 = alloca %"compiler/views:place"
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca { i64, [2 x i64] }
  %l97 = alloca i64
  %l101 = alloca { i64, ptr }
  %l103 = alloca %"compiler/views:place"
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l5, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l18, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d33365757296ff0a_65568c4e441bc04e)
  unreachable
bb11:
  %t25 = load i64, ptr %l18, !tbaa !24
  store i64 %t25, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp slt i64 %t26, 0
  br i1 %t28, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb15
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/views:Viewer", ptr %t30, i32 0, i32 2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t32, i64 %t33)
  store ptr %t36, ptr %l33
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l33, !tbaa !29
  %t39 = getelementptr %"compiler/views:summary", ptr %t37, i32 0, i32 4
  %t40 = load i1, ptr %t39, !tbaa !21
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t44 = load i1, ptr %l29, !tbaa !21
  br i1 %t44, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/views:Viewer", ptr %t45, i32 0, i32 2
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l40
  br label %bb19
bb19:
  %t52 = load ptr, ptr %l40, !tbaa !29
  %t54 = getelementptr %"compiler/views:summary", ptr %t52, i32 0, i32 1
  store ptr %t54, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t56 = load i64, ptr %l8, !tbaa !24
  store i64 %t56, ptr %l43, !tbaa !24
  %t57 = load ptr, ptr %l7, !tbaa !29
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l45
  br label %bb21
bb21:
  %t60 = load i64, ptr %l43, !tbaa !24
  %t61 = load i64, ptr %l45, !tbaa !24
  %t62 = icmp slt i64 %t60, %t61
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb23:
  br label %bb24
bb24:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = call %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t66, i64 %t67)
  store %"compiler/views:fact" %t70, ptr %l50
  br label %bb25
bb25:
  %t71 = load %"compiler/views:fact", ptr %l50
  store %"compiler/views:fact" %t71, ptr %l9
  %t72 = getelementptr %"compiler/views:fact", ptr %l9, i32 0, i32 0
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb28
bb27:
  %t77 = getelementptr %"compiler/views:fact", ptr %l9, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Call", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t87 = icmp sge i64 %t78, %t84
  store i1 %t87, ptr %l53, !tbaa !21
  br label %bb28
bb28:
  %t89 = load i1, ptr %l53, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb30:
  br label %bb31
bb31:
  %t90 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l59
  br label %bb32
bb32:
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l10
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Call", ptr %t93, i32 0, i32 1
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l62, !tbaa !27
  %t97 = getelementptr %"compiler/views:fact", ptr %l9, i32 0, i32 0
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr ptr, ptr %t101, i64 %t98
  %t103 = load ptr, ptr %t102, !tbaa !39
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s5, ptr %t92, ptr %t103, ptr %a2, ptr %l10)
  br label %bb33
bb33:
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t111 = load i64, ptr %l12, !tbaa !24
  store i64 %t111, ptr %l69, !tbaa !24
  %t112 = load ptr, ptr %l11, !tbaa !29
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s5, ptr %t112)
  store i64 %t114, ptr %l71
  br label %bb35
bb35:
  %t115 = load i64, ptr %l69, !tbaa !24
  %t116 = load i64, ptr %l71, !tbaa !24
  %t117 = icmp slt i64 %t115, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb37:
  br label %bb38
bb38:
  %t121 = load ptr, ptr %l11, !tbaa !29
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s5, ptr %t121, i64 %t122)
  store %"compiler/views:place" %t125, ptr %l76
  br label %bb39
bb39:
  %t126 = load %"compiler/views:place", ptr %l76
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/views:fact", ptr %l9, i32 0, i32 3
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = getelementptr %"compiler/views:fact", ptr %l9, i32 0, i32 4
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = getelementptr %"compiler/views:fact", ptr %l9, i32 0, i32 5
  %t134 = load i1, ptr %t133, !tbaa !21
  %t140 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t127, %"compiler/views:place" %t126, i64 %t130, i64 %t132, i1 %t134)
  store %"compiler/views:place" %t140, ptr %l82
  br label %bb40
bb40:
  %t141 = load %"compiler/views:place", ptr %l82
  store %"compiler/views:place" %t141, ptr %l14
  %t142 = getelementptr %"compiler/views:place", ptr %l14, i32 0, i32 3
  %t143 = load i1, ptr %t142, !tbaa !21
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t145 = load ptr, ptr %l3, !tbaa !29
  %t146 = load %"compiler/views:place", ptr %l14
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t145, %"compiler/views:place" %t146)
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb44:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l86, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/views:Viewer", ptr %t150, i32 0, i32 3
  %t153 = getelementptr %"compiler/views:place", ptr %l14, i32 0, i32 1
  %t154 = load i64, ptr %t153, !tbaa !24
  %t157 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s8, ptr %t152, i64 %t154)
  store { i64, ptr } %t157, ptr %l90
  br label %bb45
bb45:
  %t158 = load { i64, ptr }, ptr @G_2ecompiler_2fviews_2eElemSeg, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t163 = extractvalue { i64, ptr } %t158, 1
  %t164 = extractvalue { i64, ptr } %t158, 0
  %t165 = add i64 %t161, %t164
  %t166 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t165)
  call void @olang_textcopy(ptr %t166, ptr %t160, i64 %t161)
  %t167 = getelementptr i8, ptr %t166, i64 %t161
  call void @olang_textcopy(ptr %t167, ptr %t163, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t177 = load ptr, ptr %l86, !tbaa !29
  %t179 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s8, ptr %t177, { i64, ptr } %t176)
  store i64 %t179, ptr %l94
  br label %bb46
bb46:
  %t180 = load i64, ptr %l94, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  %t181 = load ptr, ptr %l3, !tbaa !29
  store ptr %t181, ptr %l95, !tbaa !29
  %t182 = getelementptr %"compiler/views:place", ptr %l14, i32 0, i32 0
  %t183 = load { i64, [2 x i64] }, ptr %t182
  store { i64, [2 x i64] } %t183, ptr %l96
  %t184 = load i64, ptr %l15, !tbaa !24
  store i64 %t184, ptr %l97, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 3
  %t188 = load i64, ptr %l15, !tbaa !24
  %t191 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s8, ptr %t187, i64 %t188)
  store { i64, ptr } %t191, ptr %l101
  br label %bb47
bb47:
  %t192 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = load { i64, [2 x i64] }, ptr %l96
  %t195 = load i64, ptr %l97, !tbaa !24
  %t197 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s8, { i64, [2 x i64] } %t194, i64 %t195, i64 %t193, i1 false)
  store %"compiler/views:place" %t197, ptr %l103
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l95, !tbaa !29
  %t199 = load %"compiler/views:place", ptr %l103
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t198, %"compiler/views:place" %t199)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t200 = load i64, ptr %l12, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l12, !tbaa !24
  br label %bb34
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  %t204 = load i64, ptr %l8, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l8, !tbaa !24
  br label %bb20
bb53:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/source:Span"
  %l20 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i8
  %l32 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr ptr, ptr %t15, i64 0
  %t17 = load ptr, ptr %t16, !tbaa !39
  %t19 = call i64 @compiler_2fviews_2eexprEnd(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l12
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t37 = icmp eq i32 %t32, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = icmp slt i64 %t39, %t43
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l20, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t49, i64 %t50)
  store i64 %t53, ptr %l27
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t55, i64 %t56)
  store i8 %t59, ptr %l30
  br label %bb11
bb11:
  %t60 = load i8, ptr %l30, !tbaa !22
  %t61 = icmp eq i8 %t60, 46
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = add i64 %t65, 1
  %t70 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t64, i64 %t67)
  store i64 %t70, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t71 = load ptr, ptr %l32, !tbaa !29
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t71, i64 %t72)
  store %"compiler/source:Span" %t73, ptr %l37
  br label %bb15
bb15:
  %t74 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t74, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t75, i64 %t79)
  store %"compiler/source:Span" %t82, ptr %l41
  br label %bb19
bb19:
  %t83 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  br label %bb19
bb7:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 5}
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { i32 }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t42 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 1
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l26
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %l7, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_38f43db71f48b164_beb7f8d1a31792c8)
  unreachable
bb19:
  %t56 = load i32, ptr %l7, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 11
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/views:Viewer", ptr %t9, i32 0, i32 11
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 12
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l17 = alloca i1
  %l22 = alloca i8
  %l23 = alloca { i64, ptr }
  %rv = alloca i8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 5
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/views:Viewer", ptr %t4, i32 0, i32 20
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_66a9fc2455c15d42_1dde5b0b0f74f18e)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/views:Viewer", ptr %t11, i32 0, i32 20
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l14
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l13
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp slt i64 %t32, %t35
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l23, !tbaa !27
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  store i8 %t47, ptr %l22, !tbaa !22
  br label %bb13
bb12:
  store i8 0, ptr %l22, !tbaa !22
  br label %bb13
bb13:
  %t49 = load i8, ptr %l22, !tbaa !22
  store i8 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca %"compiler/views:state"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/views:state"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l18 = alloca %"compiler/views:state"
  %l20 = alloca %"compiler/views:state"
  %l28 = alloca { i64, ptr }
  %l32 = alloca %"compiler/views:state"
  %l34 = alloca %"compiler/views:state"
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t8 = alloca %"compiler/views:state", align 8
  %t10 = alloca %"compiler/views:state", align 8
  %t35 = alloca %"compiler/views:state", align 8
  %t37 = alloca %"compiler/views:state", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t8, ptr %v2, ptr %s0, ptr %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t8, i64 136, i1 false)
  br label %bb4
bb4:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t10, ptr %s0, ptr %l18)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t10, i64 136, i1 false)
  br label %bb5
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l20, i64 136, i1 false)
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb8:
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t26, ptr %l28, !tbaa !27
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l8, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t35, ptr %v2, ptr %s3, ptr %t34)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t35, i64 136, i1 false)
  br label %bb10
bb10:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t37, ptr %s3, ptr %l32)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t37, i64 136, i1 false)
  br label %bb11
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l34, i64 136, i1 false)
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l8, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Clause", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s3, ptr %t39, ptr %t43, ptr %l9)
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Clause", ptr %t47, i32 0, i32 4
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l8, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Clause", ptr %t56, i32 0, i32 4
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l12, !tbaa !24
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t65 = load i64, ptr %l11, !tbaa !24
  %t66 = load i64, ptr %l12, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t73 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t73, ptr %l51, !tbaa !27
  %t74 = load i64, ptr %l11, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr ptr, ptr %t77, i64 %t74
  %t79 = load ptr, ptr %t78, !tbaa !39
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %v3, ptr %t81, ptr %t79, ptr %l9, ptr %a3)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l11, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s3, ptr %l4, ptr %l9)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l6, !tbaa !24
  br label %bb6
bb25:
  %t99 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s0, ptr %t99, ptr %l4)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecomponents(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l44 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l101 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:Viewer", ptr %t55, i32 0, i32 11
  store ptr %t57, ptr %l44, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/views:Viewer", ptr %t58, i32 0, i32 12
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l47
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l44, !tbaa !29
  %t64 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l51
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l51, !tbaa !29
  store ptr %t72, ptr %l8, !tbaa !29
  %t73 = load ptr, ptr %l8, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 11
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l8, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 11
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/views:Viewer", ptr %t86, i32 0, i32 12
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v0, ptr %t85, ptr %t88)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/views:Viewer", ptr %t91, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t93, i64 -1)
  br label %bb19
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/views:Viewer", ptr %t95, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t97, i64 0)
  br label %bb20
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/views:Viewer", ptr %t99, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t101, i1 false)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb8
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/views:Viewer", ptr %t107, i32 0, i32 11
  store ptr %t109, ptr %l69, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/views:Viewer", ptr %t110, i32 0, i32 12
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l72
  br label %bb24
bb24:
  %t115 = load ptr, ptr %l69, !tbaa !29
  %t116 = load i64, ptr %l72, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t115, i64 %t116)
  br label %bb25
bb25:
  store i64 0, ptr %l9, !tbaa !24
  %t117 = load i64, ptr %l1, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb26, label %bb27
bb26:
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb28:
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l80, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t145 = load i64, ptr %l80, !tbaa !24
  store i64 %t145, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t146 = load i64, ptr %l77, !tbaa !24
  store i64 %t146, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb32
bb32:
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb33, label %bb34
bb33:
  br label %bb42
bb34:
  br label %bb35
bb35:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l14, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/views:Viewer", ptr %t165, i32 0, i32 13
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l101
  br label %bb36
bb36:
  %t172 = load i64, ptr %l101, !tbaa !24
  %t173 = icmp slt i64 %t172, 0
  br i1 %t173, label %bb37, label %bb38
bb37:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %t175, i64 %t176)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t179 = load i64, ptr %l13, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l13, !tbaa !24
  br label %bb32
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:Viewer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb4
bb3:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t24 = load i32, ptr %l12, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t25 = load i32, ptr %l7, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/views:state"
  %l44 = alloca %"compiler/views:state"
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i64
  %l71 = alloca i1
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i32
  %l107 = alloca i1
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca %"compiler/views:place"
  %l117 = alloca ptr
  %l121 = alloca %"compiler/views:view"
  %l124 = alloca ptr
  %l125 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l177 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l193 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca i1
  %l221 = alloca i64
  %l224 = alloca i64
  %l242 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l244 = alloca { i64, ptr }
  %l251 = alloca i1
  %l252 = alloca i1
  %l256 = alloca i64
  %l258 = alloca i64
  %l263 = alloca %"compiler/views:view"
  %l270 = alloca ptr
  %l271 = alloca i1
  %l296 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l302 = alloca i32
  %l304 = alloca i1
  %l306 = alloca i64
  %l308 = alloca i64
  %l313 = alloca %"compiler/views:place"
  %l314 = alloca ptr
  %l318 = alloca %"compiler/views:view"
  %l321 = alloca ptr
  %l322 = alloca i1
  %l334 = alloca %"compiler/views:state"
  %l336 = alloca %"compiler/views:state"
  %l338 = alloca %"compiler/views:state"
  %l340 = alloca %"compiler/views:state"
  %l356 = alloca ptr
  %l357 = alloca i1
  %l370 = alloca { i64, ptr }
  %l384 = alloca ptr
  %l385 = alloca i1
  %l394 = alloca ptr
  %l395 = alloca i1
  %l410 = alloca ptr
  %l411 = alloca i1
  %l416 = alloca ptr
  %l417 = alloca i1
  %l429 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l441 = alloca i1
  %l451 = alloca ptr
  %l452 = alloca i1
  %l465 = alloca { i64, ptr }
  %l468 = alloca ptr
  %l469 = alloca i1
  %l481 = alloca ptr
  %l482 = alloca i1
  %l492 = alloca ptr
  %l494 = alloca i32
  %l495 = alloca i1
  %l497 = alloca i64
  %l499 = alloca i64
  %l504 = alloca %"compiler/views:view"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %t553 = alloca %"compiler/views:state", align 8
  %t555 = alloca %"compiler/views:state", align 8
  %t558 = alloca %"compiler/views:state", align 8
  %t560 = alloca %"compiler/views:state", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l71, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l71, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l74
  br label %bb7
bb7:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l4
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l75
  br label %bb8
bb8:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l5
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t16 = load ptr, ptr %l76, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l76, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l77, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l77, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t30, ptr %t31, i1 false, ptr %t33, ptr %l4)
  br label %bb14
bb14:
  br label %bb251
bb15:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t39 = load ptr, ptr %l87, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l87, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l88, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l88, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 0
  %t51 = load %"compiler/source:Span", ptr %t50
  store %"compiler/source:Span" %t51, ptr %l7
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l8, !tbaa !29
  br label %bb20
bb19:
  br label %bb37
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t59, ptr %t60, i1 true, ptr %t62, ptr %l4)
  br label %bb21
bb21:
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l100
  br label %bb22
bb22:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l9
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t76 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferElem(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t69, ptr %t70, ptr %t71, ptr %l9)
  store i32 %t76, ptr %l105
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb24, label %ok.78, !prof !99
ok.78:
  br label %bb23
bb23:
  br label %bb26
bb24:
  %t79 = load i32, ptr %l105, !tbaa !23
  %t80 = ashr i32 %t79, 16
  %t82 = icmp eq i32 %t80, 1
  store i1 %t82, ptr %l107, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  store ptr %l9, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t84 = load i64, ptr %l11, !tbaa !24
  store i64 %t84, ptr %l109, !tbaa !24
  %t85 = load ptr, ptr %l10, !tbaa !29
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s3, ptr %t85)
  store i64 %t87, ptr %l111
  br label %bb28
bb28:
  %t88 = load i64, ptr %l109, !tbaa !24
  %t89 = load i64, ptr %l111, !tbaa !24
  %t90 = icmp slt i64 %t88, %t89
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t94 = load ptr, ptr %l10, !tbaa !29
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s3, ptr %t94, i64 %t95)
  store %"compiler/views:place" %t98, ptr %l116
  br label %bb32
bb32:
  %t99 = load %"compiler/views:place", ptr %l116
  store ptr %l4, ptr %l117, !tbaa !29
  %t101 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s6, %"compiler/views:place" %t99, i64 %t104)
  store %"compiler/views:view" %t107, ptr %l121
  br label %bb33
bb33:
  %t108 = load ptr, ptr %l117, !tbaa !29
  %t109 = load %"compiler/views:view", ptr %l121
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %t108, %"compiler/views:view" %t109)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t110 = load i64, ptr %l11, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l11, !tbaa !24
  br label %bb27
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb251
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t115 = load ptr, ptr %l124, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb38, label %bb39
bb38:
  %t118 = load ptr, ptr %l124, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 18}
  %t121 = icmp eq i64 %t119, 4
  store i1 %t121, ptr %l125, !tbaa !21
  br label %bb39
bb39:
  %t122 = load i1, ptr %l125, !tbaa !21
  br i1 %t122, label %bb40, label %bb41
bb40:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l13, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t129, ptr %t130, i1 false, ptr %t132, ptr %l4)
  br label %bb43
bb43:
  br label %bb251
bb44:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t138 = load ptr, ptr %l135, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb45, label %bb46
bb45:
  %t141 = load ptr, ptr %l135, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 18}
  %t144 = icmp eq i64 %t142, 5
  store i1 %t144, ptr %l136, !tbaa !21
  br label %bb46
bb46:
  %t145 = load i1, ptr %l136, !tbaa !21
  br i1 %t145, label %bb47, label %bb48
bb47:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l14, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Promote", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t152, ptr %t156, ptr %t158, ptr %l4)
  br label %bb50
bb50:
  br label %bb251
bb51:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t164 = load ptr, ptr %l147, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb52, label %bb53
bb52:
  %t167 = load ptr, ptr %l147, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 6
  store i1 %t170, ptr %l148, !tbaa !21
  br label %bb53
bb53:
  %t171 = load i1, ptr %l148, !tbaa !21
  br i1 %t171, label %bb54, label %bb55
bb54:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 0
  %t176 = load %"compiler/source:Span", ptr %t175
  store %"compiler/source:Span" %t176, ptr %l15
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t180, i32 0, i32 1
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l16, !tbaa !23
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t186, i32 0, i32 2
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l17, !tbaa !29
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l15
  %t192 = load i32, ptr %l16, !tbaa !23
  %t193 = load ptr, ptr %l17, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t190, %"compiler/source:Span" %t191, i32 %t192, ptr %t193, ptr %t194, ptr %l4)
  br label %bb57
bb57:
  br label %bb251
bb58:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t202 = load ptr, ptr %l163, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb59, label %bb60
bb59:
  %t205 = load ptr, ptr %l163, !tbaa !29
  %t206 = load i64, ptr %t205, !range !{i64 0, i64 18}
  %t208 = icmp eq i64 %t206, 7
  store i1 %t208, ptr %l164, !tbaa !21
  br label %bb60
bb60:
  %t209 = load i1, ptr %l164, !tbaa !21
  br i1 %t209, label %bb61, label %bb62
bb61:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l18, !tbaa !29
  br label %bb63
bb62:
  br label %bb72
bb63:
  %t216 = load ptr, ptr %l18, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Make", ptr %t216, i32 0, i32 2
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  store { i64, ptr } %t219, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  store i64 %t223, ptr %l21, !tbaa !24
  br label %bb64
bb64:
  %t225 = load i64, ptr %l20, !tbaa !24
  %t226 = load i64, ptr %l21, !tbaa !24
  %t229 = icmp slt i64 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb65, label %bb66
bb65:
  br label %bb70
bb66:
  br label %bb67
bb67:
  %t233 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t233, ptr %l177, !tbaa !27
  %t234 = load i64, ptr %l20, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr ptr, ptr %t237, i64 %t234
  %t239 = load ptr, ptr %t238, !tbaa !39
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t241, ptr %t239, ptr %t244, ptr %l4)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t249 = load i64, ptr %l20, !tbaa !24
  %t251 = add i64 %t249, 1
  store i64 %t251, ptr %l20, !tbaa !24
  br label %bb64
bb70:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l18, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 3
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t253, ptr %t257, ptr %t258, ptr %l5)
  br label %bb71
bb71:
  br label %bb251
bb72:
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t264 = load ptr, ptr %l192, !tbaa !29
  %t265 = icmp ne ptr %t264, null
  br i1 %t265, label %bb73, label %bb74
bb73:
  %t267 = load ptr, ptr %l192, !tbaa !29
  %t268 = load i64, ptr %t267, !range !{i64 0, i64 18}
  %t270 = icmp eq i64 %t268, 8
  store i1 %t270, ptr %l193, !tbaa !21
  br label %bb74
bb74:
  %t271 = load i1, ptr %l193, !tbaa !21
  br i1 %t271, label %bb75, label %bb76
bb75:
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr { i64, [5 x i64] }, ptr %t272, i32 0, i32 1
  %t275 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t274, i32 0, i32 2
  %t276 = load ptr, ptr %t275
  store ptr %t276, ptr %l23, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l23, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Collect", ptr %t279, i32 0, i32 0
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t283 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t278, ptr %t282, ptr %t283, ptr %l5)
  br label %bb78
bb78:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l23, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Collect", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t288, ptr %t292, ptr %t294)
  br label %bb79
bb79:
  br label %bb251
bb80:
  %t298 = load ptr, ptr %l1, !tbaa !29
  store ptr %t298, ptr %l208, !tbaa !29
  store i1 false, ptr %l209, !tbaa !21
  %t299 = load ptr, ptr %l208, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb81, label %bb82
bb81:
  %t302 = load ptr, ptr %l208, !tbaa !29
  %t303 = load i64, ptr %t302, !range !{i64 0, i64 18}
  %t305 = icmp eq i64 %t303, 9
  store i1 %t305, ptr %l209, !tbaa !21
  br label %bb82
bb82:
  %t306 = load i1, ptr %l209, !tbaa !21
  br i1 %t306, label %bb83, label %bb84
bb83:
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t309, i32 0, i32 2
  %t311 = load i32, ptr %t310, !range !{i32 0, i32 44}
  store i32 %t311, ptr %l24
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t315, i32 0, i32 4
  %t317 = load { i64, ptr }, ptr %t316
  store { i64, ptr } %t317, ptr %l25, !tbaa !27
  br label %bb85
bb84:
  br label %bb116
bb85:
  store i64 0, ptr %l26, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  store i64 %t321, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t323 = load i64, ptr %l27, !tbaa !24
  %t324 = load i64, ptr %l26, !tbaa !24
  %t327 = icmp sgt i64 %t323, %t324
  br i1 %t327, label %bb86, label %bb87
bb86:
  %t329 = load i64, ptr %l28, !tbaa !24
  %t331 = icmp sgt i64 %t329, 0
  br i1 %t331, label %bb88, label %bb89
bb87:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb91
bb88:
  %t333 = load i64, ptr %l27, !tbaa !24
  %t334 = load i64, ptr %l26, !tbaa !24
  %t337 = sub i64 %t333, %t334
  %t338 = load i64, ptr %l28, !tbaa !24
  %t341 = add i64 %t337, %t338
  %t343 = sub i64 %t341, 1
  %t344 = load i64, ptr %l28, !tbaa !24
  %t347 = sdiv i64 %t343, %t344
  store i64 %t347, ptr %l224, !tbaa !24
  br label %bb90
bb89:
  store i64 0, ptr %l224, !tbaa !24
  br label %bb90
bb90:
  %t349 = load i64, ptr %l224, !tbaa !24
  store i64 %t349, ptr %l221, !tbaa !24
  br label %bb91
bb91:
  %t350 = load i64, ptr %l221, !tbaa !24
  store i64 %t350, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s18
  %t351 = load i64, ptr %l30, !tbaa !24
  %t352 = load i64, ptr %l29, !tbaa !24
  %t355 = icmp slt i64 %t351, %t352
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb94:
  br label %bb95
bb95:
  %t359 = load i64, ptr %l26, !tbaa !24
  %t360 = load i64, ptr %l30, !tbaa !24
  %t361 = load i64, ptr %l28, !tbaa !24
  %t364 = mul i64 %t360, %t361
  %t367 = add i64 %t359, %t364
  store i64 %t367, ptr %l31, !tbaa !24
  %t369 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t369, ptr %l242
  br label %bb96
bb96:
  %t370 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l242
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t370, ptr %l32
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t372, ptr %l244, !tbaa !27
  %t373 = load i64, ptr %l31, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr ptr, ptr %t376, i64 %t373
  %t378 = load ptr, ptr %t377, !tbaa !39
  %t380 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s18, ptr %t371, ptr %t378, ptr %t380, ptr %l32)
  br label %bb97
bb97:
  %t385 = load i32, ptr %l24, !range !{i32 0, i32 44}
  %t387 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t385)
  store i1 %t387, ptr %l251
  br label %bb98
bb98:
  %t388 = load i1, ptr %l251, !tbaa !21
  br i1 %t388, label %bb99, label %bb100
bb99:
  %t389 = load i64, ptr %l31, !tbaa !24
  %t391 = icmp eq i64 %t389, 0
  store i1 %t391, ptr %l252, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb101
bb101:
  %t393 = load i1, ptr %l252, !tbaa !21
  br i1 %t393, label %bb102, label %bb103
bb102:
  store ptr %l32, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb104
bb103:
  br label %bb113
bb104:
  %t395 = load i64, ptr %l34, !tbaa !24
  store i64 %t395, ptr %l256, !tbaa !24
  %t396 = load ptr, ptr %l33, !tbaa !29
  %t398 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s18, ptr %t396)
  store i64 %t398, ptr %l258
  br label %bb105
bb105:
  %t399 = load i64, ptr %l256, !tbaa !24
  %t400 = load i64, ptr %l258, !tbaa !24
  %t401 = icmp slt i64 %t399, %t400
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb106, label %bb107
bb106:
  br label %bb112
bb107:
  br label %bb108
bb108:
  %t405 = load ptr, ptr %l33, !tbaa !29
  %t406 = load i64, ptr %l34, !tbaa !24
  %t409 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s18, ptr %t405, i64 %t406)
  store %"compiler/views:view" %t409, ptr %l263
  br label %bb109
bb109:
  %t410 = load %"compiler/views:view", ptr %l263
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %l4, %"compiler/views:view" %t410)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t414 = load i64, ptr %l34, !tbaa !24
  %t416 = add i64 %t414, 1
  store i64 %t416, ptr %l34, !tbaa !24
  br label %bb104
bb112:
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s18)
  br label %bb114
bb114:
  %t418 = load i64, ptr %l30, !tbaa !24
  %t420 = add i64 %t418, 1
  store i64 %t420, ptr %l30, !tbaa !24
  br label %bb92
bb115:
  br label %bb251
bb116:
  %t422 = load ptr, ptr %l1, !tbaa !29
  store ptr %t422, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t423 = load ptr, ptr %l270, !tbaa !29
  %t424 = icmp ne ptr %t423, null
  br i1 %t424, label %bb117, label %bb118
bb117:
  %t426 = load ptr, ptr %l270, !tbaa !29
  %t427 = load i64, ptr %t426, !range !{i64 0, i64 18}
  %t429 = icmp eq i64 %t427, 10
  store i1 %t429, ptr %l271, !tbaa !21
  br label %bb118
bb118:
  %t430 = load i1, ptr %l271, !tbaa !21
  br i1 %t430, label %bb119, label %bb120
bb119:
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr { i64, [5 x i64] }, ptr %t431, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t433, i32 0, i32 0
  %t435 = load %"compiler/source:Span", ptr %t434
  store %"compiler/source:Span" %t435, ptr %l36
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [5 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t439, i32 0, i32 2
  %t441 = load ptr, ptr %t440
  store ptr %t441, ptr %l37, !tbaa !29
  br label %bb121
bb120:
  br label %bb140
bb121:
  store %olang.scope zeroinitializer, ptr %s24
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l37, !tbaa !29
  %t446 = getelementptr %"compiler/typed:Slice", ptr %t444, i32 0, i32 0
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t449 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t443, ptr %t447, i1 false, ptr %t449, ptr %l4)
  br label %bb122
bb122:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %l37, !tbaa !29
  %t457 = getelementptr %"compiler/typed:Slice", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t454, ptr %t458, ptr %t460, ptr %l5)
  br label %bb123
bb123:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load ptr, ptr %l37, !tbaa !29
  %t468 = getelementptr %"compiler/typed:Slice", ptr %t466, i32 0, i32 2
  %t469 = load ptr, ptr %t468, !tbaa !29
  %t471 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t465, ptr %t469, ptr %t471, ptr %l5)
  br label %bb124
bb124:
  %t476 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s24, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t476, ptr %l296
  br label %bb125
bb125:
  %t477 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l296
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t477, ptr %l38
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l37, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Slice", ptr %t479, i32 0, i32 0
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t488 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %s24, ptr %t478, ptr %t482, ptr %t483, ptr %l38)
  store i32 %t488, ptr %l302
  %t489 = icmp ne i32 %t488, 0
  br i1 %t489, label %bb127, label %ok.490, !prof !99
ok.490:
  br label %bb126
bb126:
  br label %bb129
bb127:
  %t491 = load i32, ptr %l302, !tbaa !23
  %t492 = ashr i32 %t491, 16
  %t494 = icmp eq i32 %t492, 1
  store i1 %t494, ptr %l304, !tbaa !21
  br label %bb128
bb128:
  call void @__olang_ert_req_clear()
  br label %bb129
bb129:
  store ptr %l38, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s27
  %t496 = load i64, ptr %l40, !tbaa !24
  store i64 %t496, ptr %l306, !tbaa !24
  %t497 = load ptr, ptr %l39, !tbaa !29
  %t499 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s24, ptr %t497)
  store i64 %t499, ptr %l308
  br label %bb131
bb131:
  %t500 = load i64, ptr %l306, !tbaa !24
  %t501 = load i64, ptr %l308, !tbaa !24
  %t502 = icmp slt i64 %t500, %t501
  %t504 = xor i1 %t502, true
  br i1 %t504, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s27)
  br label %bb139
bb133:
  br label %bb134
bb134:
  %t506 = load ptr, ptr %l39, !tbaa !29
  %t507 = load i64, ptr %l40, !tbaa !24
  %t510 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s24, ptr %t506, i64 %t507)
  store %"compiler/views:place" %t510, ptr %l313
  br label %bb135
bb135:
  %t511 = load %"compiler/views:place", ptr %l313
  store ptr %l4, ptr %l314, !tbaa !29
  %t513 = getelementptr %"compiler/source:Span", ptr %l36, i32 0, i32 0
  %t514 = load i32, ptr %t513, !tbaa !23
  %t516 = sext i32 %t514 to i64
  %t519 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s27, %"compiler/views:place" %t511, i64 %t516)
  store %"compiler/views:view" %t519, ptr %l318
  br label %bb136
bb136:
  %t520 = load ptr, ptr %l314, !tbaa !29
  %t521 = load %"compiler/views:view", ptr %l318
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %t520, %"compiler/views:view" %t521)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s27)
  br label %bb138
bb138:
  %t522 = load i64, ptr %l40, !tbaa !24
  %t524 = add i64 %t522, 1
  store i64 %t524, ptr %l40, !tbaa !24
  br label %bb130
bb139:
  call void @__olang_scope_close(ptr %s24)
  br label %bb251
bb140:
  %t526 = load ptr, ptr %l1, !tbaa !29
  store ptr %t526, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t527 = load ptr, ptr %l321, !tbaa !29
  %t528 = icmp ne ptr %t527, null
  br i1 %t528, label %bb141, label %bb142
bb141:
  %t530 = load ptr, ptr %l321, !tbaa !29
  %t531 = load i64, ptr %t530, !range !{i64 0, i64 18}
  %t533 = icmp eq i64 %t531, 11
  store i1 %t533, ptr %l322, !tbaa !21
  br label %bb142
bb142:
  %t534 = load i1, ptr %l322, !tbaa !21
  br i1 %t534, label %bb143, label %bb144
bb143:
  %t535 = load ptr, ptr %l1, !tbaa !29
  %t537 = getelementptr { i64, [5 x i64] }, ptr %t535, i32 0, i32 1
  %t538 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t537, i32 0, i32 2
  %t539 = load ptr, ptr %t538
  store ptr %t539, ptr %l42, !tbaa !29
  br label %bb145
bb144:
  br label %bb155
bb145:
  store %olang.scope zeroinitializer, ptr %s29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load ptr, ptr %l42, !tbaa !29
  %t544 = getelementptr %"compiler/typed:Cond", ptr %t542, i32 0, i32 0
  %t545 = load ptr, ptr %t544, !tbaa !29
  %t547 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t541, ptr %t545, ptr %t547, ptr %l5)
  br label %bb146
bb146:
  %t552 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t553, ptr %v2, ptr %s29, ptr %t552)
  call void @llvm.memmove.p0.p0.i64(ptr %l334, ptr %t553, i64 136, i1 false)
  br label %bb147
bb147:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t555, ptr %s29, ptr %l334)
  call void @llvm.memmove.p0.p0.i64(ptr %l336, ptr %t555, i64 136, i1 false)
  br label %bb148
bb148:
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %l336, i64 136, i1 false)
  %t557 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t558, ptr %v2, ptr %s29, ptr %t557)
  call void @llvm.memmove.p0.p0.i64(ptr %l338, ptr %t558, i64 136, i1 false)
  br label %bb149
bb149:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t560, ptr %s29, ptr %l338)
  call void @llvm.memmove.p0.p0.i64(ptr %l340, ptr %t560, i64 136, i1 false)
  br label %bb150
bb150:
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %l340, i64 136, i1 false)
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = load ptr, ptr %l42, !tbaa !29
  %t565 = getelementptr %"compiler/typed:Cond", ptr %t563, i32 0, i32 1
  %t566 = load ptr, ptr %t565, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %s0, ptr %t562, ptr %t566, ptr %l43, ptr %l4)
  br label %bb151
bb151:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load ptr, ptr %l42, !tbaa !29
  %t574 = getelementptr %"compiler/typed:Cond", ptr %t572, i32 0, i32 2
  %t575 = load ptr, ptr %t574, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %s0, ptr %t571, ptr %t575, ptr %l44, ptr %l4)
  br label %bb152
bb152:
  call void @compiler_2fviews_2emerge(ptr %s29, ptr %s29, ptr %l43, ptr %l44)
  br label %bb153
bb153:
  %t583 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s29, ptr %t583, ptr %l43)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s29)
  br label %bb251
bb155:
  %t586 = load ptr, ptr %l1, !tbaa !29
  store ptr %t586, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t587 = load ptr, ptr %l356, !tbaa !29
  %t588 = icmp ne ptr %t587, null
  br i1 %t588, label %bb156, label %bb157
bb156:
  %t590 = load ptr, ptr %l356, !tbaa !29
  %t591 = load i64, ptr %t590, !range !{i64 0, i64 18}
  %t593 = icmp eq i64 %t591, 12
  store i1 %t593, ptr %l357, !tbaa !21
  br label %bb157
bb157:
  %t594 = load i1, ptr %l357, !tbaa !21
  br i1 %t594, label %bb158, label %bb159
bb158:
  %t595 = load ptr, ptr %l1, !tbaa !29
  %t597 = getelementptr { i64, [5 x i64] }, ptr %t595, i32 0, i32 1
  %t598 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t597, i32 0, i32 2
  %t599 = load ptr, ptr %t598
  store ptr %t599, ptr %l45, !tbaa !29
  br label %bb160
bb159:
  br label %bb169
bb160:
  %t601 = load ptr, ptr %l45, !tbaa !29
  %t603 = getelementptr %"compiler/typed:Seq", ptr %t601, i32 0, i32 0
  %t604 = load { i64, ptr }, ptr %t603, !tbaa !27
  store { i64, ptr } %t604, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t606 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  store i64 %t608, ptr %l48, !tbaa !24
  br label %bb161
bb161:
  %t610 = load i64, ptr %l47, !tbaa !24
  %t611 = load i64, ptr %l48, !tbaa !24
  %t614 = icmp slt i64 %t610, %t611
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb162, label %bb163
bb162:
  br label %bb167
bb163:
  br label %bb164
bb164:
  %t618 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t618, ptr %l370, !tbaa !27
  %t619 = load i64, ptr %l47, !tbaa !24
  %t621 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr ptr, ptr %t622, i64 %t619
  %t624 = load ptr, ptr %t623, !tbaa !39
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t629 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t626, ptr %t624, ptr %t629)
  br label %bb165
bb165:
  br label %bb166
bb166:
  %t633 = load i64, ptr %l47, !tbaa !24
  %t635 = add i64 %t633, 1
  store i64 %t635, ptr %l47, !tbaa !24
  br label %bb161
bb167:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load ptr, ptr %l45, !tbaa !29
  %t640 = getelementptr %"compiler/typed:Seq", ptr %t638, i32 0, i32 1
  %t641 = load ptr, ptr %t640, !tbaa !29
  %t642 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t637, ptr %t641, ptr %t642, ptr %l4)
  br label %bb168
bb168:
  br label %bb251
bb169:
  %t647 = load ptr, ptr %l1, !tbaa !29
  store ptr %t647, ptr %l384, !tbaa !29
  store i1 false, ptr %l385, !tbaa !21
  %t648 = load ptr, ptr %l384, !tbaa !29
  %t649 = icmp ne ptr %t648, null
  br i1 %t649, label %bb170, label %bb171
bb170:
  %t651 = load ptr, ptr %l384, !tbaa !29
  %t652 = load i64, ptr %t651, !range !{i64 0, i64 18}
  %t654 = icmp eq i64 %t652, 13
  store i1 %t654, ptr %l385, !tbaa !21
  br label %bb171
bb171:
  %t655 = load i1, ptr %l385, !tbaa !21
  br i1 %t655, label %bb172, label %bb173
bb172:
  %t656 = load ptr, ptr %l1, !tbaa !29
  %t658 = getelementptr { i64, [5 x i64] }, ptr %t656, i32 0, i32 1
  %t659 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t658, i32 0, i32 2
  %t660 = load ptr, ptr %t659
  store ptr %t660, ptr %l50, !tbaa !29
  br label %bb174
bb173:
  br label %bb176
bb174:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load ptr, ptr %l50, !tbaa !29
  %t664 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t662, ptr %t663, ptr %t664, ptr %l4)
  br label %bb175
bb175:
  br label %bb251
bb176:
  %t669 = load ptr, ptr %l1, !tbaa !29
  store ptr %t669, ptr %l394, !tbaa !29
  store i1 false, ptr %l395, !tbaa !21
  %t670 = load ptr, ptr %l394, !tbaa !29
  %t671 = icmp ne ptr %t670, null
  br i1 %t671, label %bb177, label %bb178
bb177:
  %t673 = load ptr, ptr %l394, !tbaa !29
  %t674 = load i64, ptr %t673, !range !{i64 0, i64 18}
  %t676 = icmp eq i64 %t674, 14
  store i1 %t676, ptr %l395, !tbaa !21
  br label %bb178
bb178:
  %t677 = load i1, ptr %l395, !tbaa !21
  br i1 %t677, label %bb179, label %bb180
bb179:
  %t678 = load ptr, ptr %l1, !tbaa !29
  %t680 = getelementptr { i64, [5 x i64] }, ptr %t678, i32 0, i32 1
  %t681 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t680, i32 0, i32 2
  %t682 = load ptr, ptr %t681
  store ptr %t682, ptr %l51, !tbaa !29
  br label %bb181
bb180:
  br label %bb184
bb181:
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l51, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Try", ptr %t685, i32 0, i32 0
  %t688 = load ptr, ptr %t687, !tbaa !29
  %t689 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t684, ptr %t688, ptr %t689, ptr %l4)
  br label %bb182
bb182:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t695 = load ptr, ptr %l51, !tbaa !29
  %t697 = getelementptr %"compiler/typed:Try", ptr %t695, i32 0, i32 1
  %t698 = load { i64, ptr }, ptr %t697, !tbaa !27
  %t699 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t694, { i64, ptr } %t698, ptr %t699, ptr %l4)
  br label %bb183
bb183:
  br label %bb251
bb184:
  %t704 = load ptr, ptr %l1, !tbaa !29
  store ptr %t704, ptr %l410, !tbaa !29
  store i1 false, ptr %l411, !tbaa !21
  %t705 = load ptr, ptr %l410, !tbaa !29
  %t706 = icmp ne ptr %t705, null
  br i1 %t706, label %bb185, label %bb186
bb185:
  %t708 = load ptr, ptr %l410, !tbaa !29
  %t709 = load i64, ptr %t708, !range !{i64 0, i64 18}
  %t711 = icmp eq i64 %t709, 15
  store i1 %t711, ptr %l411, !tbaa !21
  br label %bb186
bb186:
  %t712 = load i1, ptr %l411, !tbaa !21
  br i1 %t712, label %bb187, label %bb188
bb187:
  %t713 = load ptr, ptr %l1, !tbaa !29
  %t715 = getelementptr { i64, [5 x i64] }, ptr %t713, i32 0, i32 1
  %t716 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t715, i32 0, i32 2
  %t717 = load ptr, ptr %t716
  store ptr %t717, ptr %l52, !tbaa !29
  br label %bb189
bb188:
  br label %bb215
bb189:
  %t719 = load ptr, ptr %l52, !tbaa !29
  store ptr %t719, ptr %l416, !tbaa !29
  store i1 false, ptr %l417, !tbaa !21
  %t720 = load ptr, ptr %l416, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb190, label %bb191
bb190:
  %t723 = load ptr, ptr %l416, !tbaa !29
  %t724 = load i64, ptr %t723, !range !{i64 0, i64 3}
  %t726 = icmp eq i64 %t724, 1
  store i1 %t726, ptr %l417, !tbaa !21
  br label %bb191
bb191:
  %t727 = load i1, ptr %l417, !tbaa !21
  br i1 %t727, label %bb192, label %bb193
bb192:
  %t728 = load ptr, ptr %l52, !tbaa !29
  %t730 = getelementptr { i64, [4 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t730, i32 0, i32 1
  %t732 = load { i64, ptr }, ptr %t731
  store { i64, ptr } %t732, ptr %l53, !tbaa !27
  br label %bb194
bb193:
  br label %bb202
bb194:
  %t734 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t734, ptr %l54, !tbaa !27
  store i64 0, ptr %l55, !tbaa !24
  %t736 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t738 = extractvalue { i64, ptr } %t736, 0
  store i64 %t738, ptr %l56, !tbaa !24
  br label %bb195
bb195:
  %t740 = load i64, ptr %l55, !tbaa !24
  %t741 = load i64, ptr %l56, !tbaa !24
  %t744 = icmp slt i64 %t740, %t741
  %t746 = xor i1 %t744, true
  br i1 %t746, label %bb196, label %bb197
bb196:
  br label %bb201
bb197:
  br label %bb198
bb198:
  %t748 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t748, ptr %l429, !tbaa !27
  %t749 = load i64, ptr %l55, !tbaa !24
  %t751 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t752 = load ptr, ptr %t751, !tbaa !27
  %t753 = getelementptr ptr, ptr %t752, i64 %t749
  %t754 = load ptr, ptr %t753, !tbaa !39
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t759 = getelementptr %"compiler/typed:Capture", ptr %t754, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !29
  %t762 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t756, ptr %t760, ptr %t762, ptr %l4)
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t767 = load i64, ptr %l55, !tbaa !24
  %t769 = add i64 %t767, 1
  store i64 %t769, ptr %l55, !tbaa !24
  br label %bb195
bb201:
  br label %bb214
bb202:
  %t771 = load ptr, ptr %l52, !tbaa !29
  store ptr %t771, ptr %l440, !tbaa !29
  store i1 false, ptr %l441, !tbaa !21
  %t772 = load ptr, ptr %l440, !tbaa !29
  %t773 = icmp ne ptr %t772, null
  br i1 %t773, label %bb203, label %bb204
bb203:
  %t775 = load ptr, ptr %l440, !tbaa !29
  %t776 = load i64, ptr %t775, !range !{i64 0, i64 3}
  %t778 = icmp eq i64 %t776, 2
  store i1 %t778, ptr %l441, !tbaa !21
  br label %bb204
bb204:
  %t779 = load i1, ptr %l441, !tbaa !21
  br i1 %t779, label %bb205, label %bb206
bb205:
  %t780 = load ptr, ptr %l52, !tbaa !29
  %t782 = getelementptr { i64, [4 x i64] }, ptr %t780, i32 0, i32 1
  %t783 = getelementptr { i32, ptr, i32 }, ptr %t782, i32 0, i32 1
  %t784 = load ptr, ptr %t783
  store ptr %t784, ptr %l58, !tbaa !29
  br label %bb207
bb206:
  br label %bb209
bb207:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load ptr, ptr %l58, !tbaa !29
  %t789 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t786, ptr %t787, ptr %t789, ptr %l4)
  br label %bb208
bb208:
  br label %bb214
bb209:
  br i1 true, label %bb210, label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb214
bb213:
  call void @__olang_check_failed(ptr @olang_loc_57534b0b4c840b9f_734207cf536b370b)
  unreachable
bb214:
  br label %bb251
bb215:
  %t794 = load ptr, ptr %l1, !tbaa !29
  store ptr %t794, ptr %l451, !tbaa !29
  store i1 false, ptr %l452, !tbaa !21
  %t795 = load ptr, ptr %l451, !tbaa !29
  %t796 = icmp ne ptr %t795, null
  br i1 %t796, label %bb216, label %bb217
bb216:
  %t798 = load ptr, ptr %l451, !tbaa !29
  %t799 = load i64, ptr %t798, !range !{i64 0, i64 18}
  %t801 = icmp eq i64 %t799, 16
  store i1 %t801, ptr %l452, !tbaa !21
  br label %bb217
bb217:
  %t802 = load i1, ptr %l452, !tbaa !21
  br i1 %t802, label %bb218, label %bb219
bb218:
  %t803 = load ptr, ptr %l1, !tbaa !29
  %t805 = getelementptr { i64, [5 x i64] }, ptr %t803, i32 0, i32 1
  %t806 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t805, i32 0, i32 2
  %t807 = load ptr, ptr %t806
  store ptr %t807, ptr %l59, !tbaa !29
  br label %bb220
bb219:
  br label %bb239
bb220:
  %t809 = load ptr, ptr %l59, !tbaa !29
  %t811 = getelementptr %"compiler/typed:Text", ptr %t809, i32 0, i32 0
  %t812 = load { i64, ptr }, ptr %t811, !tbaa !27
  store { i64, ptr } %t812, ptr %l60, !tbaa !27
  store i64 0, ptr %l61, !tbaa !24
  %t814 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t816 = extractvalue { i64, ptr } %t814, 0
  store i64 %t816, ptr %l62, !tbaa !24
  br label %bb221
bb221:
  %t818 = load i64, ptr %l61, !tbaa !24
  %t819 = load i64, ptr %l62, !tbaa !24
  %t822 = icmp slt i64 %t818, %t819
  %t824 = xor i1 %t822, true
  br i1 %t824, label %bb222, label %bb223
bb222:
  br label %bb238
bb223:
  br label %bb224
bb224:
  %t826 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t826, ptr %l465, !tbaa !27
  %t827 = load i64, ptr %l61, !tbaa !24
  %t829 = getelementptr { i64, ptr }, ptr %l465, i32 0, i32 1
  %t830 = load ptr, ptr %t829, !tbaa !27
  %t831 = getelementptr ptr, ptr %t830, i64 %t827
  %t832 = load ptr, ptr %t831, !tbaa !39
  store ptr %t832, ptr %l63, !tbaa !29
  %t834 = load ptr, ptr %l63, !tbaa !29
  store ptr %t834, ptr %l468, !tbaa !29
  store i1 false, ptr %l469, !tbaa !21
  %t835 = load ptr, ptr %l468, !tbaa !29
  %t836 = icmp ne ptr %t835, null
  br i1 %t836, label %bb225, label %bb226
bb225:
  %t838 = load ptr, ptr %l468, !tbaa !29
  %t839 = load i64, ptr %t838, !range !{i64 0, i64 2}
  %t841 = icmp eq i64 %t839, 1
  store i1 %t841, ptr %l469, !tbaa !21
  br label %bb226
bb226:
  %t842 = load i1, ptr %l469, !tbaa !21
  br i1 %t842, label %bb227, label %bb228
bb227:
  %t843 = load ptr, ptr %l63, !tbaa !29
  %t845 = getelementptr { i64, [2 x i64] }, ptr %t843, i32 0, i32 1
  %t846 = getelementptr { ptr }, ptr %t845, i32 0, i32 0
  %t847 = load ptr, ptr %t846
  store ptr %t847, ptr %l64, !tbaa !29
  br label %bb229
bb228:
  br label %bb231
bb229:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t850 = load ptr, ptr %l64, !tbaa !29
  %t852 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t849, ptr %t850, ptr %t852, ptr %l5)
  br label %bb230
bb230:
  br label %bb236
bb231:
  br i1 true, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb236
bb235:
  call void @__olang_check_failed(ptr @olang_loc_eef44a73fed7a11e_ba98d4574b3cccca)
  unreachable
bb236:
  br label %bb237
bb237:
  %t857 = load i64, ptr %l61, !tbaa !24
  %t859 = add i64 %t857, 1
  store i64 %t859, ptr %l61, !tbaa !24
  br label %bb221
bb238:
  br label %bb251
bb239:
  %t861 = load ptr, ptr %l1, !tbaa !29
  store ptr %t861, ptr %l481, !tbaa !29
  store i1 false, ptr %l482, !tbaa !21
  %t862 = load ptr, ptr %l481, !tbaa !29
  %t863 = icmp ne ptr %t862, null
  br i1 %t863, label %bb240, label %bb241
bb240:
  %t865 = load ptr, ptr %l481, !tbaa !29
  %t866 = load i64, ptr %t865, !range !{i64 0, i64 18}
  %t868 = icmp eq i64 %t866, 17
  store i1 %t868, ptr %l482, !tbaa !21
  br label %bb241
bb241:
  %t869 = load i1, ptr %l482, !tbaa !21
  br i1 %t869, label %bb242, label %bb243
bb242:
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t872 = getelementptr { i64, [5 x i64] }, ptr %t870, i32 0, i32 1
  %t873 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t872, i32 0, i32 2
  %t874 = load ptr, ptr %t873
  store ptr %t874, ptr %l65, !tbaa !29
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load ptr, ptr %l65, !tbaa !29
  %t879 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t876, ptr %t877, ptr %t879, ptr %l4)
  br label %bb245
bb245:
  br label %bb251
bb246:
  br i1 true, label %bb247, label %bb248
bb247:
  br label %bb249
bb248:
  br label %bb250
bb249:
  br label %bb251
bb250:
  call void @__olang_check_failed(ptr @olang_loc_bd4e25d0ba8f3355_5d1878e7bdcf6d61)
  unreachable
bb251:
  %t884 = load ptr, ptr %l0, !tbaa !29
  store ptr %t884, ptr %l492, !tbaa !29
  %t885 = load ptr, ptr %l1, !tbaa !29
  %t887 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t885)
  store i32 %t887, ptr %l494
  br label %bb252
bb252:
  %t888 = load ptr, ptr %l492, !tbaa !29
  %t889 = load i32, ptr %l494, !tbaa !23
  %t890 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t888, i32 %t889)
  store i1 %t890, ptr %l495
  br label %bb253
bb253:
  %t891 = load i1, ptr %l495, !tbaa !21
  br i1 %t891, label %bb254, label %bb255
bb254:
  store ptr %l4, ptr %l66, !tbaa !29
  store i64 0, ptr %l67, !tbaa !24
  br label %bb256
bb255:
  br label %bb265
bb256:
  %t893 = load i64, ptr %l67, !tbaa !24
  store i64 %t893, ptr %l497, !tbaa !24
  %t894 = load ptr, ptr %l66, !tbaa !29
  %t896 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t894)
  store i64 %t896, ptr %l499
  br label %bb257
bb257:
  %t897 = load i64, ptr %l497, !tbaa !24
  %t898 = load i64, ptr %l499, !tbaa !24
  %t899 = icmp slt i64 %t897, %t898
  %t901 = xor i1 %t899, true
  br i1 %t901, label %bb258, label %bb259
bb258:
  br label %bb264
bb259:
  br label %bb260
bb260:
  %t903 = load ptr, ptr %l66, !tbaa !29
  %t904 = load i64, ptr %l67, !tbaa !24
  %t907 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t903, i64 %t904)
  store %"compiler/views:view" %t907, ptr %l504
  br label %bb261
bb261:
  %t908 = load %"compiler/views:view", ptr %l504
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %a3, %"compiler/views:view" %t908)
  br label %bb262
bb262:
  br label %bb263
bb263:
  %t913 = load i64, ptr %l67, !tbaa !24
  %t915 = add i64 %t913, 1
  store i64 %t915, ptr %l67, !tbaa !24
  br label %bb256
bb264:
  br label %bb265
bb265:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l4, !tbaa !29
  br label %bb12
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t38, ptr %t39)
  br label %bb13
bb13:
  br label %bb48
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 11
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Cond", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t59, ptr %t63, ptr %t64, ptr %t65)
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Cond", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t70, ptr %t74, ptr %t76, ptr %t77)
  br label %bb21
bb21:
  br label %bb48
bb22:
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t83 = load ptr, ptr %l45, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l45, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 18}
  %t89 = icmp eq i64 %t87, 17
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t90 = load i1, ptr %l46, !tbaa !21
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t97, ptr %t98, ptr %t100, ptr %t101)
  br label %bb28
bb28:
  br label %bb48
bb29:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t107 = load ptr, ptr %l56, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t110 = load ptr, ptr %l56, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 12
  store i1 %t113, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t114 = load i1, ptr %l57, !tbaa !21
  br i1 %t114, label %bb32, label %bb33
bb32:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l7, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Seq", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t121, ptr %t125, ptr %t126, ptr %t127)
  br label %bb35
bb35:
  br label %bb48
bb36:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t133 = load ptr, ptr %l67, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb37, label %bb38
bb37:
  %t136 = load ptr, ptr %l67, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 18}
  %t139 = icmp eq i64 %t137, 6
  store i1 %t139, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t140 = load i1, ptr %l68, !tbaa !21
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l8, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l8, !tbaa !29
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t150 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t147, ptr %t148, ptr %t149, ptr %t150)
  br label %bb42
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_a471d4cd6a39e3a7_bf796cf0b70bcd93)
  unreachable
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i32 %a4, %"compiler/views:place" %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/views:place"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:fact"
  %l24 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l53 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca %"compiler/views:fact"
  %l84 = alloca i1
  %l88 = alloca i1
  %l95 = alloca i1
  %l97 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i64
  %l112 = alloca { i64, ptr }
  %l115 = alloca i64
  %l120 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i32
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i1
  %l137 = alloca %"compiler/views:fact"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/views:place" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t3, i64 %t5)
  store { i64, ptr } %t8, ptr %l24
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t13 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l9, !tbaa !21
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb4:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = load i64, ptr %l11, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l13, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l13, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l35, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l35, !tbaa !24
  store i64 %t46, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l32, !tbaa !24
  store i64 %t47, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l15, !tbaa !24
  %t49 = load i64, ptr %l14, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t56 = load i64, ptr %l11, !tbaa !24
  %t57 = load i64, ptr %l15, !tbaa !24
  %t58 = load i64, ptr %l13, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l16, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t66, ptr %l53, !tbaa !27
  %t67 = load i64, ptr %l16, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 46
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp sgt i64 %t80, 8
  br i1 %t82, label %bb14, label %bb15
bb13:
  br label %bb24
bb14:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l61, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t85, ptr %l62, !tbaa !27
  %t86 = load i64, ptr %l16, !tbaa !24
  store i64 %t86, ptr %l63, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l64, !tbaa !24
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb16, label %bb17
bb15:
  br label %bb23
bb16:
  %t91 = load i64, ptr %l63, !tbaa !24
  %t92 = icmp sle i64 0, %t91
  br i1 %t92, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8)
  unreachable
bb18:
  %t94 = load i64, ptr %l63, !tbaa !24
  %t95 = load i64, ptr %l64, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8)
  unreachable
bb20:
  %t98 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l63, !tbaa !24
  %t101 = getelementptr i8, ptr %t99, i64 0
  %t102 = sub i64 %t100, 0
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t107 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %v0, ptr %t105, { i64, ptr } %t104)
  store i64 %t107, ptr %l69
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8)
  unreachable
bb22:
  %t108 = load i64, ptr %l69, !tbaa !24
  store i64 %t108, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  br label %bb26
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t109 = load i64, ptr %l15, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l15, !tbaa !24
  br label %bb8
bb26:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l18, !tbaa !24
  store i64 %t115, ptr %l73, !tbaa !24
  %t116 = load ptr, ptr %l17, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t116)
  store i64 %t118, ptr %l75
  br label %bb28
bb28:
  %t119 = load i64, ptr %l73, !tbaa !24
  %t120 = load i64, ptr %l75, !tbaa !24
  %t121 = icmp slt i64 %t119, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb29, label %bb30
bb29:
  br label %bb59
bb30:
  br label %bb31
bb31:
  %t125 = load ptr, ptr %l17, !tbaa !29
  %t126 = load i64, ptr %l18, !tbaa !24
  %t129 = call %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t125, i64 %t126)
  store %"compiler/views:fact" %t129, ptr %l80
  br label %bb32
bb32:
  %t130 = load %"compiler/views:fact", ptr %l80
  store %"compiler/views:fact" %t130, ptr %l19
  %t131 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 0
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i64, ptr %l2, !tbaa !24
  %t136 = icmp ne i64 %t132, %t133
  br i1 %t136, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb35
bb34:
  %t138 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i64, ptr %l3, !tbaa !24
  %t143 = icmp ne i64 %t139, %t140
  store i1 %t143, ptr %l84, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l84, !tbaa !21
  br i1 %t145, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb38
bb37:
  %t146 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 2
  %t147 = load i32, ptr %t146, !tbaa !23
  %t148 = load i32, ptr %l4, !tbaa !23
  %t151 = icmp ne i32 %t147, %t148
  store i1 %t151, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l88, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  br label %bb58
bb40:
  br label %bb41
bb41:
  %t154 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 3
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load i64, ptr %l8, !tbaa !24
  %t159 = icmp eq i64 %t155, %t156
  br i1 %t159, label %bb42, label %bb43
bb42:
  %t161 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 5
  %t162 = load i1, ptr %t161, !tbaa !21
  br i1 %t162, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb47
bb44:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb46
bb45:
  %t164 = load i1, ptr %l9, !tbaa !21
  %t166 = xor i1 %t164, true
  store i1 %t166, ptr %l97, !tbaa !21
  br label %bb46
bb46:
  %t168 = load i1, ptr %l97, !tbaa !21
  store i1 %t168, ptr %l95, !tbaa !21
  br label %bb47
bb47:
  %t169 = load i1, ptr %l95, !tbaa !21
  br i1 %t169, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br label %bb50
bb50:
  %t170 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 5
  %t171 = load i1, ptr %t170, !tbaa !21
  br i1 %t171, label %bb51, label %bb52
bb51:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/views:fact", ptr %l19, i32 0, i32 3
  %t175 = load i64, ptr %t174, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t180 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t173, i64 %t175, i64 %t176)
  store i1 %t180, ptr %l105
  br label %bb53
bb52:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb54
bb53:
  %t181 = load i1, ptr %l105, !tbaa !21
  store i1 %t181, ptr %l101, !tbaa !21
  br label %bb54
bb54:
  %t182 = load i1, ptr %l101, !tbaa !21
  br i1 %t182, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t183 = load i64, ptr %l18, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l18, !tbaa !24
  br label %bb27
bb59:
  %t187 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 2
  %t188 = load i64, ptr %t187, !tbaa !24
  store i64 %t188, ptr %l108, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/views:Viewer", ptr %t189, i32 0, i32 3
  %t192 = load i64, ptr %l8, !tbaa !24
  %t195 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t191, i64 %t192)
  store { i64, ptr } %t195, ptr %l112
  br label %bb60
bb60:
  %t196 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  %t198 = load i64, ptr %l108, !tbaa !24
  %t200 = icmp sle i64 %t198, %t197
  br i1 %t200, label %bb61, label %bb62
bb61:
  %t202 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 2
  %t203 = load i64, ptr %t202, !tbaa !24
  store i64 %t203, ptr %l115, !tbaa !24
  br label %bb64
bb62:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/views:Viewer", ptr %t205, i32 0, i32 3
  %t208 = load i64, ptr %l8, !tbaa !24
  %t211 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t207, i64 %t208)
  store { i64, ptr } %t211, ptr %l120
  br label %bb63
bb63:
  %t212 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  store i64 %t213, ptr %l115, !tbaa !24
  br label %bb64
bb64:
  %t215 = load i64, ptr %l115, !tbaa !24
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l122, !tbaa !29
  %t217 = load i64, ptr %l2, !tbaa !24
  store i64 %t217, ptr %l123, !tbaa !24
  %t218 = load i64, ptr %l3, !tbaa !24
  store i64 %t218, ptr %l124, !tbaa !24
  %t219 = load i32, ptr %l4, !tbaa !23
  store i32 %t219, ptr %l125, !tbaa !23
  %t220 = load i64, ptr %l8, !tbaa !24
  store i64 %t220, ptr %l126, !tbaa !24
  store i64 %t215, ptr %l127, !tbaa !24
  %t222 = load i1, ptr %l9, !tbaa !21
  store i1 %t222, ptr %l128, !tbaa !21
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/views:Viewer", ptr %t223, i32 0, i32 20
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  br i1 %t228, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_59f7caf9a8021923_a477b9c5c640d35f)
  unreachable
bb66:
  br label %bb67
bb67:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/views:Viewer", ptr %t230, i32 0, i32 20
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Body", ptr %t233, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  %t239 = load i64, ptr %l123, !tbaa !24
  %t240 = load i64, ptr %l124, !tbaa !24
  %t241 = load i32, ptr %l125, !tbaa !23
  %t242 = load i64, ptr %l126, !tbaa !24
  %t243 = load i64, ptr %l127, !tbaa !24
  %t244 = load i1, ptr %l128, !tbaa !21
  %t247 = call %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %s0, i64 %t239, i64 %t240, i32 %t241, i64 %t242, i64 %t243, i1 %t244, i64 %t237, %"compiler/source:Span" %a6)
  store %"compiler/views:fact" %t247, ptr %l137
  br label %bb68
bb68:
  %t248 = load ptr, ptr %l122, !tbaa !29
  %t249 = load %"compiler/views:fact", ptr %l137
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t248, %"compiler/views:fact" %t249)
  br label %bb69
bb69:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/views:Viewer", ptr %t250, i32 0, i32 25
  store i1 true, ptr %t252, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l14 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l47 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l24
  br label %bb5
bb5:
  %t36 = load i32, ptr %l24, !tbaa !23
  store i32 %t36, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/views:Viewer", ptr %t37, i32 0, i32 9
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hbdff57143197d3e3ce33a3087c05f7a0(ptr %v0, ptr %t39, i32 %t40)
  %t44 = extractvalue { i32, i64 } %t43, 1
  %t45 = extractvalue { i32, i64 } %t43, 0
  store i32 %t45, ptr %l30
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb7, label %ok.47, !prof !99
ok.47:
  store i64 %t44, ptr %l29
  br label %bb6
bb6:
  %t48 = load i64, ptr %l29, !tbaa !24
  store i64 %t48, ptr %l25, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l25, !tbaa !24
  store i64 %t49, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:Viewer", ptr %t54, i32 0, i32 10
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l35
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Ha157aa9bcf12f5157b10d592e947e165(ptr %v0, ptr %s3, ptr %t58, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59)
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/views:Viewer", ptr %t60, i32 0, i32 10
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H161a24899859b830aba89891233cbfd1(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l38
  br label %bb14
bb14:
  %t65 = load i64, ptr %l38, !tbaa !24
  %t66 = sub i64 %t65, 1
  store i64 %t66, ptr %l4, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/views:Viewer", ptr %t68, i32 0, i32 9
  %t71 = load i32, ptr %l3, !tbaa !23
  %t72 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hd7428d759783ef3a1a99ea96b3969ebe(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/views:Viewer", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s4, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l47
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 4
  %t88 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t104, ptr %l55, !tbaa !27
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  store i32 %t110, ptr %l8, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/views:Viewer", ptr %t112, i32 0, i32 10
  %t115 = load i64, ptr %l4, !tbaa !24
  %t118 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H8f04a3ce395cf5423055a0e50fbad86f(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store ptr %t118, ptr %l61
  br label %bb21
bb21:
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t120, i32 %t119)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l6, !tbaa !24
  br label %bb17
bb24:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/views:Viewer", ptr %t126, i32 0, i32 10
  %t129 = load i64, ptr %l4, !tbaa !24
  %t132 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H97e3fe71a2054fda18da5260a3d71aea(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l68
  br label %bb26
bb26:
  %t133 = load ptr, ptr %l68, !tbaa !29
  store ptr %t133, ptr %l9, !tbaa !29
  %t134 = load i64, ptr %l2, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l9, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l71
  br label %bb27
bb27:
  %t138 = load i64, ptr %l69, !tbaa !24
  %t139 = load i64, ptr %l71, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  br i1 %t140, label %bb28, label %bb29
bb28:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l74, !tbaa !29
  %t143 = load ptr, ptr %l9, !tbaa !29
  %t144 = load i64, ptr %l2, !tbaa !24
  %t147 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t143, i64 %t144)
  store i32 %t147, ptr %l77
  br label %bb30
bb29:
  %t148 = load i64, ptr %l2, !tbaa !24
  %t150 = call i64 @__olang_fmt_i64(ptr null, i64 %t148)
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  store { i64, ptr } %t154, ptr %l73, !tbaa !27
  br label %bb32
bb30:
  %t156 = load ptr, ptr %l74, !tbaa !29
  %t157 = load i32, ptr %l77, !tbaa !23
  %t158 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %s0, ptr %t156, i32 %t157)
  store { i64, ptr } %t158, ptr %l78
  br label %bb31
bb31:
  %t159 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t160, i64 %t161)
  %t163 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l73, !tbaa !27
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t166, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egivenGrowing(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/views:place" %a2, i64 %a3, i64 %a4, i64 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i64
  %l48 = alloca { i64, [3 x i64] }
  %l52 = alloca { i64, ptr }
  %l53 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %t86 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s0, ptr %t1, %"compiler/views:place" %a2)
  store { i64, ptr } %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 4
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t21 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t17, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t21, ptr %l18
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/views:Viewer", ptr %t23, i32 0, i32 3
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  store { i64, ptr } %t29, ptr %l23
  br label %bb3
bb3:
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t35 = call { i64, ptr } @compiler_2fviews_2ecopyHint(ptr %s0, ptr %s0, i64 %a3, { i64, ptr } %t32)
  store { i64, ptr } %t35, ptr %l27
  br label %bb4
bb4:
  %t36 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t43 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t47 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %s0, ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t43, { i64, ptr } %t44, { i64, ptr } %t45, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t47, ptr %l29
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l15, !tbaa !29
  %t49 = load { i64, [3 x i64] }, ptr %l18
  %t50 = load %"compiler/msgs:Msg", ptr %l29
  %t51 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s0, ptr %t48, { i64, [3 x i64] } %t49, %"compiler/msgs:Msg" %t50)
  store i64 %t51, ptr %l30
  br label %bb6
bb6:
  %t52 = load i64, ptr %l30, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp slt i64 %t53, 0
  br i1 %t55, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb10
bb8:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/views:Viewer", ptr %t57, i32 0, i32 6
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l37
  br label %bb9
bb9:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:Viewer", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 4
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l42, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t79 = load i32, ptr %t78, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t82 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 0
  store i64 3, ptr %t87
  %t89 = insertvalue { i64, i64, i64 } undef, i64 %t77, 0
  %t91 = insertvalue { i64, i64, i64 } %t89, i64 %t81, 1
  %t93 = insertvalue { i64, i64, i64 } %t91, i64 %t85, 2
  %t94 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 1
  store { i64, i64, i64 } %t93, ptr %t94
  %t95 = load { i64, [3 x i64] }, ptr %t86
  store { i64, [3 x i64] } %t95, ptr %l48
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/views:Viewer", ptr %t96, i32 0, i32 3
  %t99 = load i64, ptr %l4, !tbaa !24
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l52
  br label %bb14
bb14:
  %t103 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %s0, { i64, ptr } %t103)
  store %"compiler/msgs:Msg" %t104, ptr %l53
  br label %bb15
bb15:
  %t105 = load ptr, ptr %l41, !tbaa !29
  %t106 = load i64, ptr %l42, !tbaa !24
  %t107 = load { i64, [3 x i64] }, ptr %l48
  %t108 = load %"compiler/msgs:Msg", ptr %l53
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t105, i64 %t106, { i64, [3 x i64] } %t107, %"compiler/msgs:Msg" %t108)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/views:holding"
  %l18 = alloca %"compiler/views:view"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/views:tasked"
  %l22 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l38 = alloca ptr
  %l48 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l90 = alloca %"compiler/views:holding"
  %l92 = alloca i1
  %l96 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i64
  %l108 = alloca %"compiler/views:holding"
  %l114 = alloca i1
  %l119 = alloca i64
  %l121 = alloca i64
  %l126 = alloca %"compiler/views:tasked"
  %l130 = alloca i1
  %l132 = alloca i1
  %l135 = alloca i1
  %l138 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l145 = alloca { i64, [3 x i64] }
  %l146 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %l152 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca i64
  %l160 = alloca { i64, [3 x i64] }
  %l162 = alloca %"compiler/msgs:Msg"
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/views:Viewer", ptr %t6, i32 0, i32 22
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t14 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t14, ptr %l7
  %t16 = load { i64, [2 x i64] }, ptr %l7
  %t18 = extractvalue { i64, [2 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 2
  br i1 %t19, label %bb6, label %bb7
bb5:
  br label %bb23
bb6:
  %t21 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t22 = getelementptr { i64 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l33, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/views:Viewer", ptr %t29, i32 0, i32 21
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t28, i64 %t32)
  store ptr %t35, ptr %l38
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l38, !tbaa !29
  %t38 = getelementptr %"compiler/views:summary", ptr %t36, i32 0, i32 0
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load %"compiler/views:place", ptr %l1
  %t41 = load %"compiler/source:Span", ptr %l2
  %t42 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t42, ptr %t38, i64 %t39, i64 -1, i32 0, %"compiler/views:place" %t40, %"compiler/source:Span" %t41)
  br label %bb10
bb10:
  br label %bb22
bb11:
  %t47 = load { i64, [2 x i64] }, ptr %l7
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 3
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t53 = getelementptr { i64, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i64, ptr %t53
  store i64 %t54, ptr %l9, !tbaa !24
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t57 = getelementptr { i64, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l10, !tbaa !23
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l48, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 21
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t63, i64 %t67)
  store ptr %t70, ptr %l53
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l53, !tbaa !29
  %t73 = getelementptr %"compiler/views:summary", ptr %t71, i32 0, i32 0
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i32, ptr %l10, !tbaa !23
  %t76 = load %"compiler/views:place", ptr %l1
  %t77 = load %"compiler/source:Span", ptr %l2
  %t78 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t78, ptr %t73, i64 -1, i64 %t74, i32 %t75, %"compiler/views:place" %t76, %"compiler/source:Span" %t77)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_617a65436beb56f7_865c97eda452f2a3)
  unreachable
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l11, !tbaa !24
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t86 = getelementptr %"compiler/views:state", ptr %t84, i32 0, i32 1
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t86)
  store i64 %t88, ptr %l62
  br label %bb24
bb24:
  %t89 = load i64, ptr %l62, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb25, label %bb26
bb25:
  %t96 = load i64, ptr %l13, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb30
bb27:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l13, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l13, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l69, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l69, !tbaa !24
  store i64 %t116, ptr %l66, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l66, !tbaa !24
  store i64 %t117, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l14, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t127 = load i64, ptr %l15, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l16, !tbaa !24
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = getelementptr %"compiler/views:state", ptr %t136, i32 0, i32 1
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t138, i64 %t139)
  store %"compiler/views:holding" %t142, ptr %l90
  br label %bb35
bb35:
  %t143 = load %"compiler/views:holding", ptr %l90
  store %"compiler/views:holding" %t143, ptr %l17
  %t144 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t145 = getelementptr %"compiler/views:view", ptr %t144, i32 0, i32 2
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb39
bb37:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t150 = getelementptr %"compiler/views:view", ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/views:place", ptr %t150
  %t152 = load %"compiler/views:place", ptr %l1
  %t156 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t148, %"compiler/views:place" %t151, %"compiler/views:place" %t152)
  store i1 %t156, ptr %l96
  br label %bb38
bb38:
  %t157 = load i1, ptr %l96, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l92, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l92, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t161 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t162 = load %"compiler/views:view", ptr %t161
  store %"compiler/views:view" %t162, ptr %l18
  %t164 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 2
  store i1 true, ptr %t164, !tbaa !21
  %t165 = load %"compiler/source:Span", ptr %l2
  %t167 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 3
  store %"compiler/source:Span" %t165, ptr %t167
  %t170 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 4
  store i64 %a3, ptr %t170, !tbaa !24
  %t173 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 5
  store i64 %a4, ptr %t173, !tbaa !24
  %t176 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 6
  store %"compiler/source:Span" %a5, ptr %t176
  %t177 = load ptr, ptr %l6, !tbaa !29
  %t179 = getelementptr %"compiler/views:state", ptr %t177, i32 0, i32 1
  store ptr %t179, ptr %l104, !tbaa !29
  %t180 = load i64, ptr %l16, !tbaa !24
  store i64 %t180, ptr %l105, !tbaa !24
  %t181 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 0
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = load %"compiler/views:view", ptr %l18
  %t186 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s7, i64 %t182, %"compiler/views:view" %t183)
  store %"compiler/views:holding" %t186, ptr %l108
  br label %bb43
bb43:
  %t187 = load ptr, ptr %l104, !tbaa !29
  %t188 = load i64, ptr %l105, !tbaa !24
  %t189 = load %"compiler/views:holding", ptr %l108
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eSetAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t187, i64 %t188, %"compiler/views:holding" %t189)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l15, !tbaa !24
  br label %bb31
bb46:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/views:Viewer", ptr %t194, i32 0, i32 22
  %t197 = load i1, ptr %t196, !tbaa !21
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb49
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/views:Viewer", ptr %t201, i32 0, i32 24
  %t204 = load i1, ptr %t203, !tbaa !21
  store i1 %t204, ptr %l114, !tbaa !21
  br label %bb49
bb49:
  %t206 = load i1, ptr %l114, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  br label %ret
bb51:
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l6, !tbaa !29
  %t209 = getelementptr %"compiler/views:state", ptr %t207, i32 0, i32 4
  store ptr %t209, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t211 = load i64, ptr %l20, !tbaa !24
  store i64 %t211, ptr %l119, !tbaa !24
  %t212 = load ptr, ptr %l19, !tbaa !29
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v1, ptr %t212)
  store i64 %t214, ptr %l121
  br label %bb54
bb54:
  %t215 = load i64, ptr %l119, !tbaa !24
  %t216 = load i64, ptr %l121, !tbaa !24
  %t217 = icmp slt i64 %t215, %t216
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb56:
  br label %bb57
bb57:
  %t221 = load ptr, ptr %l19, !tbaa !29
  %t222 = load i64, ptr %l20, !tbaa !24
  %t225 = call %"compiler/views:tasked" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eAt_3ccompiler_2fviews_3atasked_3e(ptr %v1, ptr %t221, i64 %t222)
  store %"compiler/views:tasked" %t225, ptr %l126
  br label %bb58
bb58:
  %t226 = load %"compiler/views:tasked", ptr %l126
  store %"compiler/views:tasked" %t226, ptr %l21
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/views:tasked", ptr %l21, i32 0, i32 0
  %t229 = getelementptr %"compiler/views:view", ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/views:place", ptr %t229
  %t231 = load %"compiler/views:place", ptr %l1
  %t235 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t227, %"compiler/views:place" %t230, %"compiler/views:place" %t231)
  store i1 %t235, ptr %l130
  br label %bb59
bb59:
  %t236 = load i1, ptr %l130, !tbaa !21
  %t237 = xor i1 %t236, true
  br i1 %t237, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb63
bb61:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l2
  %t243 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t239, %"compiler/source:Span" %t240)
  store i1 %t243, ptr %l135
  br label %bb62
bb62:
  %t244 = load i1, ptr %l135, !tbaa !21
  store i1 %t244, ptr %l132, !tbaa !21
  br label %bb63
bb63:
  %t245 = load i1, ptr %l132, !tbaa !21
  br i1 %t245, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb75
bb65:
  br label %bb66
bb66:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/views:tasked", ptr %l21, i32 0, i32 0
  %t248 = getelementptr %"compiler/views:view", ptr %t247, i32 0, i32 0
  %t249 = load %"compiler/views:place", ptr %t248
  %t252 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s12, ptr %t246, %"compiler/views:place" %t249)
  store { i64, ptr } %t252, ptr %l138
  br label %bb67
bb67:
  %t253 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t253, ptr %l22, !tbaa !27
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/views:Viewer", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 0
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/load:Loader", ptr %t260, i32 0, i32 4
  %t263 = load ptr, ptr %t262, !tbaa !29
  store ptr %t263, ptr %l142, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l2
  %t268 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t264, %"compiler/source:Span" %t265)
  store { i64, [3 x i64] } %t268, ptr %l145
  br label %bb68
bb68:
  %t269 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t269, ptr %l146, !tbaa !27
  %t270 = getelementptr %"compiler/views:tasked", ptr %l21, i32 0, i32 0
  %t271 = getelementptr %"compiler/views:view", ptr %t270, i32 0, i32 7
  %t272 = load i64, ptr %t271, !tbaa !24
  %t273 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t276 = call { i64, ptr } @compiler_2fviews_2etaskCopy(ptr %s12, ptr %s12, i64 %t272, { i64, ptr } %t273)
  store { i64, ptr } %t276, ptr %l149
  br label %bb69
bb69:
  %t277 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  %t279 = extractvalue { i64, ptr } %t277, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  %t284 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t286 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t284, { i64, ptr } %t283)
  store %"compiler/msgs:Msg" %t286, ptr %l151
  br label %bb70
bb70:
  %t287 = load ptr, ptr %l142, !tbaa !29
  %t288 = load { i64, [3 x i64] }, ptr %l145
  %t289 = load %"compiler/msgs:Msg", ptr %l151
  %t290 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t287, { i64, [3 x i64] } %t288, %"compiler/msgs:Msg" %t289)
  store i64 %t290, ptr %l152
  br label %bb71
bb71:
  %t291 = load i64, ptr %l152, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/views:Viewer", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 0
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = getelementptr %"compiler/load:Loader", ptr %t298, i32 0, i32 4
  %t301 = load ptr, ptr %t300, !tbaa !29
  store ptr %t301, ptr %l156, !tbaa !29
  store i64 %t291, ptr %l157, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/views:tasked", ptr %l21, i32 0, i32 1
  %t305 = load %"compiler/source:Span", ptr %t304
  %t308 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t303, %"compiler/source:Span" %t305)
  store { i64, [3 x i64] } %t308, ptr %l160
  br label %bb72
bb72:
  %t309 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t311 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %s12, ptr %s12, { i64, ptr } %t309)
  store %"compiler/msgs:Msg" %t311, ptr %l162
  br label %bb73
bb73:
  %t312 = load ptr, ptr %l156, !tbaa !29
  %t313 = load i64, ptr %l157, !tbaa !24
  %t314 = load { i64, [3 x i64] }, ptr %l160
  %t315 = load %"compiler/msgs:Msg", ptr %l162
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t312, i64 %t313, { i64, [3 x i64] } %t314, %"compiler/msgs:Msg" %t315)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb75:
  %t316 = load i64, ptr %l20, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l20, !tbaa !24
  br label %bb53
bb76:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrownAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/views:place"
  %l39 = alloca %"compiler/views:place"
  %l40 = alloca i1
  %rv = alloca i64
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i64, ptr %l10, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  store ptr %a0, ptr %l35, !tbaa !29
  store %"compiler/views:place" %a1, ptr %l36
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %v1, ptr %t53, i64 %t54)
  store %"compiler/views:place" %t57, ptr %l39
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t59 = load %"compiler/views:place", ptr %l36
  %t60 = load %"compiler/views:place", ptr %l39
  %t61 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t58, %"compiler/views:place" %t59, %"compiler/views:place" %t60)
  store i1 %t61, ptr %l40
  br label %bb13
bb13:
  %t62 = load i1, ptr %l40, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t63 = load i64, ptr %l8, !tbaa !24
  store i64 %t63, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l7, !tbaa !24
  br label %bb8
bb18:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ehandOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/views:view"
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"compiler/views:view"
  %l30 = alloca ptr
  %l35 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t3, ptr %a2, ptr %a3, ptr %l4)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/views:Viewer", ptr %t10, i32 0, i32 22
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t16 = load i64, ptr %l6, !tbaa !24
  store i64 %t16, ptr %l18, !tbaa !24
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t17)
  store i64 %t19, ptr %l20
  br label %bb7
bb7:
  %t20 = load i64, ptr %l18, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb29
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t26, i64 %t27)
  store %"compiler/views:view" %t30, ptr %l25
  br label %bb11
bb11:
  %t31 = load %"compiler/views:view", ptr %l25
  store %"compiler/views:view" %t31, ptr %l7
  %t32 = getelementptr %"compiler/views:view", ptr %l7, i32 0, i32 0
  %t33 = getelementptr %"compiler/views:place", ptr %t32, i32 0, i32 0
  %t34 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t34, ptr %l8
  %t36 = load { i64, [2 x i64] }, ptr %l8
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t42 = getelementptr { i64 }, ptr %t41, i32 0, i32 0
  %t43 = load i64, ptr %t42
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l30, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:Viewer", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/views:Viewer", ptr %t49, i32 0, i32 21
  %t52 = load i64, ptr %t51, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t48, i64 %t52)
  store ptr %t55, ptr %l35
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t58 = getelementptr %"compiler/views:summary", ptr %t56, i32 0, i32 1
  %t59 = load i64, ptr %l9, !tbaa !24
  %t60 = getelementptr %"compiler/views:view", ptr %l7, i32 0, i32 0
  %t61 = load %"compiler/views:place", ptr %t60
  %t63 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t63, ptr %t58, i64 %t59, i64 -1, i32 0, %"compiler/views:place" %t61, %"compiler/source:Span" %a1)
  br label %bb16
bb16:
  br label %bb27
bb17:
  %t68 = load { i64, [2 x i64] }, ptr %l8
  %t70 = extractvalue { i64, [2 x i64] } %t68, 0
  %t71 = icmp eq i64 %t70, 4
  br i1 %t71, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/views:view", ptr %l7
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t73, %"compiler/views:view" %t74)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c0119a910aee1fe3_5ce99f5c7dc6e127)
  unreachable
bb27:
  br label %bb28
bb28:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb6
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eholdsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/views:holding"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca %"compiler/views:holding"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:state", ptr %a1, i32 0, i32 1
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/views:holding" %t19, ptr %l16
  br label %bb6
bb6:
  %t20 = load %"compiler/views:holding", ptr %l16
  store %"compiler/views:holding" %t20, ptr %l6
  %t21 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = icmp eq i64 %t22, %a2
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t29 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t30 = load %"compiler/views:view", ptr %t29
  call void @compiler_2fviews_2eviewAdd(ptr %v2, ptr %a3, %"compiler/views:view" %t30)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l5, !tbaa !24
  br label %bb1
bb12:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 26
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  store i64 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferField(ptr %v0, ptr %s0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t14, ptr %l6
  br label %bb2
bb2:
  %t15 = load i1, ptr %l6, !tbaa !21
  %t16 = xor i1 %t15, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/views:place"
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:view"
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/views:fact"
  %l27 = alloca %"compiler/views:fact"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca %"compiler/views:view"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca %"compiler/views:place"
  %l78 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca %"compiler/views:view"
  %l95 = alloca i64
  %l102 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca %"compiler/views:fact"
  %l124 = alloca i1
  %l131 = alloca i64
  %l138 = alloca i64
  %l143 = alloca %"compiler/source:Span"
  %l144 = alloca %"compiler/views:fact"
  %l150 = alloca ptr
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t5, i32 %a2)
  store i1 %t9, ptr %l33
  br label %bb3
bb3:
  %t10 = load i1, ptr %l33, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l30, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l30, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l37
  br label %bb8
bb8:
  %t19 = load i64, ptr %l37, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l3, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t26 = load i64, ptr %l7, !tbaa !24
  store i64 %t26, ptr %l41, !tbaa !24
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t27)
  store i64 %t29, ptr %l43
  br label %bb12
bb12:
  %t30 = load i64, ptr %l41, !tbaa !24
  %t31 = load i64, ptr %l43, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t36, i64 %t37)
  store %"compiler/views:view" %t40, ptr %l48
  br label %bb16
bb16:
  %t41 = load %"compiler/views:view", ptr %l48
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fviews_2eholdAdd(ptr %v3, ptr %t42, i64 %t43, %"compiler/views:view" %t41)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l7, !tbaa !24
  br label %bb11
bb19:
  br label %bb20
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 22
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l56
  br label %bb24
bb24:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l9
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t63 = call ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %v1, ptr %t59, ptr %t60)
  store ptr %t63, ptr %l59
  br label %bb25
bb25:
  %t64 = load ptr, ptr %l59, !tbaa !29
  store ptr %t64, ptr %l10, !tbaa !29
  %t65 = load ptr, ptr %l10, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb26, label %bb27
bb26:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l10, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t71, ptr %t72, ptr %t74, ptr %l9)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  store ptr %l9, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  %t80 = load i64, ptr %l12, !tbaa !24
  store i64 %t80, ptr %l69, !tbaa !24
  %t81 = load ptr, ptr %l11, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t81)
  store i64 %t83, ptr %l71
  br label %bb31
bb31:
  %t84 = load i64, ptr %l69, !tbaa !24
  %t85 = load i64, ptr %l71, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb32, label %bb33
bb32:
  br label %bb97
bb33:
  br label %bb34
bb34:
  %t90 = load ptr, ptr %l11, !tbaa !29
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t90, i64 %t91)
  store %"compiler/views:place" %t94, ptr %l76
  br label %bb35
bb35:
  %t95 = load %"compiler/views:place", ptr %l76
  store %"compiler/views:place" %t95, ptr %l13
  %t96 = getelementptr %"compiler/views:place", ptr %l13, i32 0, i32 0
  %t97 = load { i64, [2 x i64] }, ptr %t96
  store { i64, [2 x i64] } %t97, ptr %l14
  %t99 = load { i64, [2 x i64] }, ptr %l14
  %t101 = extractvalue { i64, [2 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 2
  br i1 %t102, label %bb36, label %bb37
bb36:
  %t104 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t105 = getelementptr { i64 }, ptr %t104, i32 0, i32 0
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l15, !tbaa !24
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t108 = load i64, ptr %l15, !tbaa !24
  store i64 %t108, ptr %l78, !tbaa !24
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i64 -1, ptr %l78, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_a9709b8d7599af1c_938b49c1f1943728)
  unreachable
bb44:
  %t110 = load i64, ptr %l78, !tbaa !24
  store i64 %t110, ptr %l16, !tbaa !24
  %t111 = load i64, ptr %l16, !tbaa !24
  %t113 = icmp slt i64 %t111, 0
  br i1 %t113, label %bb45, label %bb46
bb45:
  br label %bb96
bb46:
  br label %bb47
bb47:
  %t115 = load ptr, ptr %l3, !tbaa !29
  store ptr %t115, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s14
  %t117 = load i64, ptr %l18, !tbaa !24
  store i64 %t117, ptr %l86, !tbaa !24
  %t118 = load ptr, ptr %l17, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t118)
  store i64 %t120, ptr %l88
  br label %bb49
bb49:
  %t121 = load i64, ptr %l86, !tbaa !24
  %t122 = load i64, ptr %l88, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s14)
  br label %bb95
bb51:
  br label %bb52
bb52:
  %t127 = load ptr, ptr %l17, !tbaa !29
  %t128 = load i64, ptr %l18, !tbaa !24
  %t131 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t127, i64 %t128)
  store %"compiler/views:view" %t131, ptr %l93
  br label %bb53
bb53:
  %t132 = load %"compiler/views:view", ptr %l93
  store %"compiler/views:view" %t132, ptr %l19
  %t133 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t134 = getelementptr %"compiler/views:place", ptr %t133, i32 0, i32 0
  %t135 = load { i64, [2 x i64] }, ptr %t134
  store { i64, [2 x i64] } %t135, ptr %l20
  %t137 = load { i64, [2 x i64] }, ptr %l20
  %t139 = extractvalue { i64, [2 x i64] } %t137, 0
  %t140 = icmp eq i64 %t139, 4
  br i1 %t140, label %bb54, label %bb55
bb54:
  %t142 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t143 = getelementptr { i64 }, ptr %t142, i32 0, i32 0
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l21, !tbaa !24
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t146 = load i64, ptr %l21, !tbaa !24
  store i64 %t146, ptr %l95, !tbaa !24
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i64 -1, ptr %l95, !tbaa !24
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_5a02dfa0eab0974d_8c564576f095f5f9)
  unreachable
bb62:
  %t148 = load i64, ptr %l95, !tbaa !24
  store i64 %t148, ptr %l22, !tbaa !24
  %t149 = load i64, ptr %l22, !tbaa !24
  %t151 = icmp slt i64 %t149, 0
  br i1 %t151, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb65
bb64:
  %t153 = load i64, ptr %l22, !tbaa !24
  %t154 = load i64, ptr %l16, !tbaa !24
  %t157 = icmp eq i64 %t153, %t154
  store i1 %t157, ptr %l102, !tbaa !21
  br label %bb65
bb65:
  %t159 = load i1, ptr %l102, !tbaa !21
  br i1 %t159, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb67:
  br label %bb68
bb68:
  store i1 false, ptr %l23, !tbaa !21
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/views:Viewer", ptr %t160, i32 0, i32 2
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/views:Viewer", ptr %t163, i32 0, i32 21
  %t166 = load i64, ptr %t165, !tbaa !24
  %t169 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t162, i64 %t166)
  store ptr %t169, ptr %l110
  br label %bb69
bb69:
  %t170 = load ptr, ptr %l110, !tbaa !29
  %t172 = getelementptr %"compiler/views:summary", ptr %t170, i32 0, i32 2
  store ptr %t172, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb70
bb70:
  %t174 = load i64, ptr %l25, !tbaa !24
  store i64 %t174, ptr %l113, !tbaa !24
  %t175 = load ptr, ptr %l24, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l115
  br label %bb71
bb71:
  %t178 = load i64, ptr %l113, !tbaa !24
  %t179 = load i64, ptr %l115, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb72, label %bb73
bb72:
  br label %bb83
bb73:
  br label %bb74
bb74:
  %t184 = load ptr, ptr %l24, !tbaa !29
  %t185 = load i64, ptr %l25, !tbaa !24
  %t188 = call %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t184, i64 %t185)
  store %"compiler/views:fact" %t188, ptr %l120
  br label %bb75
bb75:
  %t189 = load %"compiler/views:fact", ptr %l120
  store %"compiler/views:fact" %t189, ptr %l26
  %t190 = getelementptr %"compiler/views:fact", ptr %l26, i32 0, i32 0
  %t191 = load i64, ptr %t190, !tbaa !24
  %t192 = load i64, ptr %l22, !tbaa !24
  %t195 = icmp eq i64 %t191, %t192
  br i1 %t195, label %bb76, label %bb77
bb76:
  %t197 = getelementptr %"compiler/views:fact", ptr %l26, i32 0, i32 8
  %t198 = load i64, ptr %t197, !tbaa !24
  %t199 = load i64, ptr %l16, !tbaa !24
  %t202 = icmp eq i64 %t198, %t199
  store i1 %t202, ptr %l124, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb78
bb78:
  %t204 = load i1, ptr %l124, !tbaa !21
  br i1 %t204, label %bb79, label %bb80
bb79:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb81
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t205 = load i64, ptr %l25, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l25, !tbaa !24
  br label %bb70
bb83:
  %t209 = load i1, ptr %l23, !tbaa !21
  br i1 %t209, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb85:
  br label %bb86
bb86:
  %t211 = load i64, ptr %l22, !tbaa !24
  store i64 %t211, ptr %l131, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/views:Viewer", ptr %t212, i32 0, i32 20
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb87, label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_d83b4460c5b9ac6f_e5ae66818951545b)
  unreachable
bb88:
  br label %bb89
bb89:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/views:Viewer", ptr %t219, i32 0, i32 20
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Body", ptr %t222, i32 0, i32 3
  %t226 = load i64, ptr %t225, !tbaa !24
  store i64 %t226, ptr %l138, !tbaa !24
  %t227 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = trunc i64 %t228 to i32
  %t231 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  %t234 = trunc i64 %t232 to i32
  %t237 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s14, i32 %t230, i32 %t234)
  store %"compiler/source:Span" %t237, ptr %l143
  br label %bb90
bb90:
  %t238 = load i64, ptr %l131, !tbaa !24
  %t239 = load i64, ptr %l138, !tbaa !24
  %t240 = load %"compiler/source:Span", ptr %l143
  %t241 = call %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %s14, i64 %t238, i64 -1, i32 0, i64 0, i64 0, i1 false, i64 %t239, %"compiler/source:Span" %t240)
  store %"compiler/views:fact" %t241, ptr %l144
  br label %bb91
bb91:
  %t242 = load %"compiler/views:fact", ptr %l144
  store %"compiler/views:fact" %t242, ptr %l27
  %t243 = load i64, ptr %l16, !tbaa !24
  %t245 = getelementptr %"compiler/views:fact", ptr %l27, i32 0, i32 8
  store i64 %t243, ptr %t245, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/views:Viewer", ptr %t246, i32 0, i32 2
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/views:Viewer", ptr %t249, i32 0, i32 21
  %t252 = load i64, ptr %t251, !tbaa !24
  %t255 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t248, i64 %t252)
  store ptr %t255, ptr %l150
  br label %bb92
bb92:
  %t256 = load ptr, ptr %l150, !tbaa !29
  %t258 = getelementptr %"compiler/views:summary", ptr %t256, i32 0, i32 2
  %t259 = load %"compiler/views:fact", ptr %l27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t258, %"compiler/views:fact" %t259)
  br label %bb93
bb93:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/views:Viewer", ptr %t262, i32 0, i32 25
  store i1 true, ptr %t264, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb94:
  %t265 = load i64, ptr %l18, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l18, !tbaa !24
  br label %bb48
bb95:
  br label %bb96
bb96:
  %t269 = load i64, ptr %l12, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l12, !tbaa !24
  br label %bb30
bb97:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/views:state"
  %l6 = alloca %"compiler/views:state"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/views:state"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:state"
  %l20 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca %"compiler/views:loopFrame"
  %l28 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca %"compiler/views:state"
  %l37 = alloca %"compiler/views:state"
  %l38 = alloca %"compiler/views:state"
  %l42 = alloca i64
  %l45 = alloca i64
  %l68 = alloca %"compiler/views:state"
  %l70 = alloca %"compiler/views:state"
  %l77 = alloca i64
  %l79 = alloca i64
  %l84 = alloca %"compiler/views:state"
  %l86 = alloca %"compiler/views:state"
  %l96 = alloca i64
  %l98 = alloca i64
  %l103 = alloca %"compiler/views:state"
  %l105 = alloca %"compiler/views:state"
  %l111 = alloca i64
  %l115 = alloca i64
  %l120 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t29 = alloca %"compiler/views:state", align 8
  %t31 = alloca %"compiler/views:state", align 8
  %t33 = alloca %"compiler/views:state", align 8
  %t88 = alloca %"compiler/views:state", align 8
  %t90 = alloca %"compiler/views:state", align 8
  %t114 = alloca %"compiler/views:state", align 8
  %t117 = alloca %"compiler/views:state", align 8
  %t146 = alloca %"compiler/views:state", align 8
  %t149 = alloca %"compiler/views:state", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 27
  store ptr %t3, ptr %l22, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Block", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = call %"compiler/views:loopFrame" @compiler_2fviews_3aloopFrame_2ector(ptr %v0, i32 %t7)
  store %"compiler/views:loopFrame" %t9, ptr %l25
  br label %bb1
bb1:
  %t10 = load %"compiler/views:loopFrame", ptr %l25
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/views:loopFrame" %t10, ptr %t11
  %t12 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H473e76678ba49e15aac3621516ab9c7a(ptr %v0, ptr %v0, ptr %t12, ptr %t11)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 27
  store ptr %t16, ptr %l28, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/views:Viewer", ptr %t17, i32 0, i32 27
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H1e03e4f3e9fd2c184a7d157dcdc4524e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l31
  br label %bb3
bb3:
  %t22 = load i64, ptr %l31, !tbaa !24
  %t23 = sub i64 %t22, 1
  %t24 = load ptr, ptr %l28, !tbaa !29
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H778376aca07487ba188a916552f34a0e(ptr %v0, ptr %v0, ptr %t24, i64 %t23)
  store ptr %t26, ptr %l33
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l33, !tbaa !29
  store ptr %t27, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t29, ptr %v3, ptr %s0, ptr %t28)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t29, i64 136, i1 false)
  br label %bb5
bb5:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t31, ptr %s0, ptr %l35)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t31, i64 136, i1 false)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l37, i64 136, i1 false)
  call void @compiler_2fviews_2edead(ptr %t33, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t33, i64 136, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l38, i64 136, i1 false)
  store i64 0, ptr %l7, !tbaa !24
  store i64 12, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l45, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l45, !tbaa !24
  store i64 %t60, ptr %l42, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l42, !tbaa !24
  store i64 %t61, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load i64, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l12, !tbaa !24
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/views:loopFrame", ptr %t80, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t82)
  br label %bb18
bb18:
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/views:loopFrame", ptr %t84, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t86)
  br label %bb19
bb19:
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t88, ptr %s0, ptr %s2, ptr %l5)
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t88, i64 136, i1 false)
  br label %bb20
bb20:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t90, ptr %s2, ptr %l68)
  call void @llvm.memmove.p0.p0.i64(ptr %l70, ptr %t90, i64 136, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l70, i64 136, i1 false)
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s2, ptr %t92, ptr %t93, ptr %l13)
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = getelementptr %"compiler/views:loopFrame", ptr %t98, i32 0, i32 2
  store ptr %t100, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load i64, ptr %l15, !tbaa !24
  store i64 %t102, ptr %l77, !tbaa !24
  %t103 = load ptr, ptr %l14, !tbaa !29
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eLen_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l79
  br label %bb24
bb24:
  %t106 = load i64, ptr %l77, !tbaa !24
  %t107 = load i64, ptr %l79, !tbaa !24
  %t108 = icmp slt i64 %t106, %t107
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb26:
  br label %bb27
bb27:
  %t112 = load ptr, ptr %l14, !tbaa !29
  %t113 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eAt_3ccompiler_2fviews_3astate_3e(ptr %t114, ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  call void @llvm.memmove.p0.p0.i64(ptr %l84, ptr %t114, i64 136, i1 false)
  br label %bb28
bb28:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t117, ptr %s4, ptr %l84)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t117, i64 136, i1 false)
  br label %bb29
bb29:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l86, i64 136, i1 false)
  call void @compiler_2fviews_2emerge(ptr %s2, ptr %s4, ptr %l13, ptr %l16)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t121 = load i64, ptr %l15, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l15, !tbaa !24
  br label %bb23
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v2, ptr %s2, ptr %t125, ptr %a2, ptr %l13)
  br label %bb33
bb33:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = getelementptr %"compiler/views:loopFrame", ptr %t130, i32 0, i32 1
  store ptr %t132, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t134 = load i64, ptr %l18, !tbaa !24
  store i64 %t134, ptr %l96, !tbaa !24
  %t135 = load ptr, ptr %l17, !tbaa !29
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eLen_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l98
  br label %bb35
bb35:
  %t138 = load i64, ptr %l96, !tbaa !24
  %t139 = load i64, ptr %l98, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t144 = load ptr, ptr %l17, !tbaa !29
  %t145 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eAt_3ccompiler_2fviews_3astate_3e(ptr %t146, ptr %v0, ptr %v0, ptr %t144, i64 %t145)
  call void @llvm.memmove.p0.p0.i64(ptr %l103, ptr %t146, i64 136, i1 false)
  br label %bb39
bb39:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t149, ptr %s7, ptr %l103)
  call void @llvm.memmove.p0.p0.i64(ptr %l105, ptr %t149, i64 136, i1 false)
  br label %bb40
bb40:
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %l105, i64 136, i1 false)
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s7, ptr %l6, ptr %l19)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t153 = load i64, ptr %l18, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l18, !tbaa !24
  br label %bb34
bb43:
  %t158 = call i64 @compiler_2fviews_2eweight(ptr %s0, ptr %l5)
  store i64 %t158, ptr %l111
  br label %bb44
bb44:
  %t159 = load i64, ptr %l111, !tbaa !24
  store i64 %t159, ptr %l20, !tbaa !24
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s2, ptr %l5, ptr %l13)
  br label %bb45
bb45:
  %t163 = call i64 @compiler_2fviews_2eweight(ptr %s0, ptr %l5)
  store i64 %t163, ptr %l115
  br label %bb46
bb46:
  %t164 = load i64, ptr %l20, !tbaa !24
  %t165 = load i64, ptr %l115, !tbaa !24
  %t167 = icmp eq i64 %t165, %t164
  br i1 %t167, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb50:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l11, !tbaa !24
  br label %bb14
bb51:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/views:Viewer", ptr %t173, i32 0, i32 27
  %t177 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H2424d6cf963333801588b77238bf827f(ptr %v0, ptr %v0, ptr %t175)
  %t178 = extractvalue { i32, ptr } %t177, 1
  %t179 = extractvalue { i32, ptr } %t177, 0
  store i32 %t179, ptr %l124
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb53, label %ok.181, !prof !99
ok.181:
  store ptr %t178, ptr %l123
  br label %bb52
bb52:
  %t182 = load ptr, ptr %l123, !tbaa !29
  store ptr %t182, ptr %l120, !tbaa !29
  br label %bb55
bb53:
  br label %bb54
bb54:
  call void @__olang_ert_req_clear()
  br label %bb55
bb55:
  %t183 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v3, ptr %s0, ptr %t183, ptr %l6)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/views:state"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca %"compiler/views:state"
  %l23 = alloca { i64, ptr }
  %l32 = alloca %"compiler/views:state"
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/views:state"
  %l47 = alloca %"compiler/views:state"
  %l61 = alloca %"compiler/views:state"
  %l63 = alloca %"compiler/views:state"
  %l64 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t37 = alloca %"compiler/views:state", align 8
  %t64 = alloca %"compiler/views:state", align 8
  %t66 = alloca %"compiler/views:state", align 8
  %t91 = alloca %"compiler/views:state", align 8
  %t96 = alloca %"compiler/views:state", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l23, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t24, ptr %t29)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l5, !tbaa !24
  br label %bb1
bb7:
  call void @compiler_2fviews_2edead(ptr %t37, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t37, i64 136, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l32, i64 136, i1 false)
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Match", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l41, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l12, !tbaa !29
  %t63 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t64, ptr %v2, ptr %s5, ptr %t63)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t64, i64 136, i1 false)
  br label %bb13
bb13:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t66, ptr %s5, ptr %l45)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t66, i64 136, i1 false)
  br label %bb14
bb14:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l47, i64 136, i1 false)
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l12, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %s5, ptr %v3, ptr %t68, ptr %t69, ptr %l13, ptr %t70)
  br label %bb15
bb15:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s5, ptr %l8, ptr %l13)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb9
bb18:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Match", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t90 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t91, ptr %v2, ptr %s7, ptr %t90)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t91, i64 136, i1 false)
  br label %bb21
bb20:
  %t93 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %v2, ptr %l8, ptr %t93)
  br label %bb28
bb21:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t96, ptr %s7, ptr %l61)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t96, i64 136, i1 false)
  br label %bb22
bb22:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l63, i64 136, i1 false)
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l64, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Match", ptr %t99, i32 0, i32 2
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2d854533e388acf3_9bd384635a298ef)
  unreachable
bb24:
  br label %bb25
bb25:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Match", ptr %t106, i32 0, i32 2
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t111 = load ptr, ptr %l64, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %s7, ptr %v3, ptr %t111, ptr %t109, ptr %l14, ptr %t110)
  br label %bb26
bb26:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s7, ptr %l8, ptr %l14)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t117 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s0, ptr %t117, ptr %l8)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %a0, %"compiler/views:place" %a1, %"compiler/views:place" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca %"compiler/views:place"
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l11 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store %"compiler/views:place" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t2)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb3:
  %t8 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l7
  %t10 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l9
  %t14 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l7, ptr %l9)
  store i1 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i1, ptr %l11, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l6, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = icmp eq i64 %t21, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t32, i64 %t34, i64 %t36)
  store i1 %t40, ptr %l23
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l19, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t44 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 3
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t51 = load i64, ptr %t50, !tbaa !24
  %t55 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t47, i64 %t49, i64 %t51)
  store i1 %t55, ptr %l30
  br label %bb21
bb20:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb22
bb21:
  %t56 = load i1, ptr %l30, !tbaa !21
  store i1 %t56, ptr %l26, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l26, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i8
  %l22 = alloca i32
  %l26 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t3, i64 %t4)
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t8)
  store i1 %t9, ptr %l7
  br label %bb3
bb3:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t11, i64 %t12)
  store i8 %t15, ptr %l11
  br label %bb6
bb6:
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t16)
  store i1 %t17, ptr %l12
  br label %bb7
bb7:
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t20, i64 %t21)
  store i8 %t24, ptr %l16
  br label %bb11
bb11:
  %t25 = load i8, ptr %l16, !tbaa !22
  %t26 = icmp eq i8 %t25, 95
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  br label %bb1
bb17:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store i32 %t37, ptr %l22, !tbaa !23
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb20
bb19:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l26, !tbaa !24
  br label %bb20
bb20:
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = trunc i64 %t50 to i32
  %t52 = load i32, ptr %l22, !tbaa !23
  %t54 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t52, i32 %t51)
  store %"compiler/source:Span" %t54, ptr %l31
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t5 = getelementptr %"compiler/views:state", ptr %a1, i32 0, i32 3
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %a2)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t4 = load ptr, ptr %l10, !tbaa !29
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = load i64, ptr %t7, !range !{i64 0, i64 8}
  %t10 = icmp eq i64 %t8, 3
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t12, i32 0, i32 1
  %t15 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t18, ptr %t19, i1 false, ptr %t21, ptr %l3)
  br label %bb7
bb7:
  br label %bb42
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 4
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Elem", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t41, ptr %t45, i1 false, ptr %t47, ptr %l3)
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t52, ptr %t56, ptr %t58, ptr %l3)
  br label %bb15
bb15:
  br label %bb42
bb16:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Payload", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t78, ptr %t82, i1 false, ptr %t84, ptr %l3)
  br label %bb22
bb22:
  br label %bb42
bb23:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t97 = load i1, ptr %l52, !tbaa !21
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l7, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t104, ptr %t105, ptr %t107, ptr %l3)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t113 = load ptr, ptr %l62, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb31, label %bb32
bb31:
  %t116 = load ptr, ptr %l62, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 8}
  %t119 = icmp eq i64 %t117, 6
  store i1 %t119, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t120 = load i1, ptr %l63, !tbaa !21
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l8, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t127, ptr %t128, ptr %t130, ptr %l3)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_2a4a8b72a379b770_7cdc66c7220ef344)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %a0, %"compiler/views:view" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:view"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/views:view" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 0
  %t2 = getelementptr %"compiler/views:place", ptr %t1, i32 0, i32 0
  %t3 = load { i64, [2 x i64] }, ptr %t2
  store { i64, [2 x i64] } %t3, ptr %l2
  %t5 = load { i64, [2 x i64] }, ptr %l2
  %t7 = extractvalue { i64, [2 x i64] } %t5, 0
  %t8 = icmp eq i64 %t7, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i64 }, ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/views:Viewer", ptr %t17, i32 0, i32 21
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l12
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t26 = getelementptr %"compiler/views:summary", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l16
  br label %bb5
bb5:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/views:Viewer", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/views:Viewer", ptr %t37, i32 0, i32 21
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t36, i64 %t40)
  store ptr %t43, ptr %l22
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t46 = getelementptr %"compiler/views:summary", ptr %t44, i32 0, i32 3
  %t47 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t46, i64 %t47, i1 true)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/views:Viewer", ptr %t50, i32 0, i32 25
  store i1 true, ptr %t52, !tbaa !21
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b373ce5e6fb0acb1_b981b0fdcb20f7cd)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/views:naming"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:place"
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/views:naming"
  %l56 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca { i64, [2 x i64] }
  %l66 = alloca %"compiler/views:place"
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca ptr
  %l79 = alloca %"compiler/views:place"
  %l80 = alloca ptr
  %l81 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca ptr
  %l118 = alloca i32
  %l120 = alloca { i64, ptr }
  %l123 = alloca i64
  %l125 = alloca i64
  %l130 = alloca %"compiler/views:place"
  %l134 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca { i64, [2 x i64] }
  %l145 = alloca i64
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/views:place"
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t84 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [2 x i64] }, align 8
  %t129 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t6 = load ptr, ptr %l23, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l23, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l24, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb31
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t28 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v2, ptr %t20, ptr %t21, i64 %t24)
  store i1 %t28, ptr %l33
  br label %bb9
bb9:
  %t29 = load i1, ptr %l33, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  br label %bb24
bb12:
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l36, !tbaa !24
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v2, ptr %t35)
  store i64 %t37, ptr %l38
  br label %bb13
bb13:
  %t38 = load i64, ptr %l36, !tbaa !24
  %t39 = load i64, ptr %l38, !tbaa !24
  %t40 = icmp slt i64 %t38, %t39
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb14, label %bb15
bb14:
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = call %"compiler/views:naming" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eAt_3ccompiler_2fviews_3anaming_3e(ptr %v2, ptr %t44, i64 %t45)
  store %"compiler/views:naming" %t48, ptr %l43
  br label %bb17
bb17:
  %t49 = load %"compiler/views:naming", ptr %l43
  store %"compiler/views:naming" %t49, ptr %l7
  %t50 = getelementptr %"compiler/views:naming", ptr %l7, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load i32, ptr %l4, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t57 = icmp eq i64 %t51, %t54
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/views:naming", ptr %l7, i32 0, i32 1
  %t61 = load %"compiler/views:place", ptr %t60
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t59, %"compiler/views:place" %t61)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb12
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb24:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/views:Viewer", ptr %t68, i32 0, i32 26
  %t71 = load i32, ptr %l4, !tbaa !23
  %t73 = sext i32 %t71 to i64
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t70, i64 %t73)
  store i64 %t76, ptr %l56
  br label %bb25
bb25:
  %t77 = load i64, ptr %l56, !tbaa !24
  store i64 %t77, ptr %l8, !tbaa !24
  %t78 = load ptr, ptr %l3, !tbaa !29
  store ptr %t78, ptr %l57, !tbaa !29
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp sge i64 %t79, 0
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load i64, ptr %l8, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [2 x i64] }, ptr %t84, i32 0, i32 0
  store i64 2, ptr %t85
  %t87 = insertvalue { i64 } undef, i64 %t83, 0
  %t88 = getelementptr { i64, [2 x i64] }, ptr %t84, i32 0, i32 1
  store { i64 } %t87, ptr %t88
  %t89 = load { i64, [2 x i64] }, ptr %t84
  store { i64, [2 x i64] } %t89, ptr %l60
  br label %bb28
bb27:
  %t91 = load i32, ptr %l4, !tbaa !23
  %t93 = sext i32 %t91 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 0
  store i64 1, ptr %t95
  %t97 = insertvalue { i64 } undef, i64 %t93, 0
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  store { i64 } %t97, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t94
  store { i64, [2 x i64] } %t99, ptr %l60
  br label %bb28
bb28:
  %t101 = load { i64, [2 x i64] }, ptr %l60
  %t102 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s2, { i64, [2 x i64] } %t101, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t102, ptr %l66
  br label %bb29
bb29:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load %"compiler/views:place", ptr %l66
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t103, %"compiler/views:place" %t104)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb31:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t106 = load ptr, ptr %l67, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t109 = load ptr, ptr %l67, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 8}
  %t112 = icmp eq i64 %t110, 1
  store i1 %t112, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t113 = load i1, ptr %l68, !tbaa !21
  br i1 %t113, label %bb34, label %bb35
bb34:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t116, i32 0, i32 2
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l9, !tbaa !24
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t122, i32 0, i32 3
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l10, !tbaa !23
  br label %bb36
bb35:
  br label %bb39
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t126 = load ptr, ptr %l3, !tbaa !29
  store ptr %t126, ptr %l75, !tbaa !29
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load i32, ptr %l10, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 0
  store i64 3, ptr %t130
  %t132 = insertvalue { i64, i32 } undef, i64 %t127, 0
  %t134 = insertvalue { i64, i32 } %t132, i32 %t128, 1
  %t135 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 1
  store { i64, i32 } %t134, ptr %t135
  %t136 = load { i64, [2 x i64] }, ptr %t129
  %t138 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s8, { i64, [2 x i64] } %t136, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t138, ptr %l79
  br label %bb37
bb37:
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t140 = load %"compiler/views:place", ptr %l79
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t139, %"compiler/views:place" %t140)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb85
bb39:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t142 = load ptr, ptr %l80, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l80, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 8}
  %t148 = icmp eq i64 %t146, 2
  store i1 %t148, ptr %l81, !tbaa !21
  br label %bb41
bb41:
  %t149 = load i1, ptr %l81, !tbaa !21
  br i1 %t149, label %bb42, label %bb43
bb42:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t152, i32 0, i32 2
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l11, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l11, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t160 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t156, ptr %t157, ptr %t159, ptr %t160)
  br label %bb45
bb45:
  br label %bb85
bb46:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t166 = load ptr, ptr %l91, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t169 = load ptr, ptr %l91, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 8}
  %t172 = icmp eq i64 %t170, 6
  store i1 %t172, ptr %l92, !tbaa !21
  br label %bb48
bb48:
  %t173 = load i1, ptr %l92, !tbaa !21
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t176, i32 0, i32 2
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l12, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t184 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t180, ptr %t181, ptr %t183, ptr %t184)
  br label %bb52
bb52:
  br label %bb85
bb53:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t190 = load ptr, ptr %l102, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb54, label %bb55
bb54:
  %t193 = load ptr, ptr %l102, !tbaa !29
  %t194 = load i64, ptr %t193, !range !{i64 0, i64 8}
  %t196 = icmp eq i64 %t194, 3
  store i1 %t196, ptr %l103, !tbaa !21
  br label %bb55
bb55:
  %t197 = load i1, ptr %l103, !tbaa !21
  br i1 %t197, label %bb56, label %bb57
bb56:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t200, i32 0, i32 2
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l13, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t206, i32 0, i32 3
  %t208 = load i64, ptr %t207
  store i64 %t208, ptr %l14, !tbaa !24
  br label %bb58
bb57:
  br label %bb80
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t210 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s11, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %l110
  br label %bb59
bb59:
  %t211 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t211, ptr %l15
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l13, !tbaa !29
  %t215 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s11, ptr %t212, ptr %t213, ptr %t215, ptr %l15)
  br label %bb60
bb60:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l116, !tbaa !29
  %t221 = load ptr, ptr %l13, !tbaa !29
  %t223 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t221)
  store i32 %t223, ptr %l118
  br label %bb61
bb61:
  %t224 = load i64, ptr %l14, !tbaa !24
  %t225 = load ptr, ptr %l116, !tbaa !29
  %t226 = load i32, ptr %l118, !tbaa !23
  %t228 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %s11, ptr %t225, i32 %t226, i64 %t224)
  store { i64, ptr } %t228, ptr %l120
  br label %bb62
bb62:
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t231 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = add i64 %t230, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t229, i64 %t230)
  %t236 = getelementptr i8, ptr %t235, i64 %t230
  call void @olang_textcopy(ptr %t236, ptr %t232, i64 %t233)
  %t237 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t235, 1
  store { i64, ptr } %t238, ptr %l16, !tbaa !27
  store ptr %l15, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t241 = load i64, ptr %l18, !tbaa !24
  store i64 %t241, ptr %l123, !tbaa !24
  %t242 = load ptr, ptr %l17, !tbaa !29
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s11, ptr %t242)
  store i64 %t244, ptr %l125
  br label %bb64
bb64:
  %t245 = load i64, ptr %l123, !tbaa !24
  %t246 = load i64, ptr %l125, !tbaa !24
  %t247 = icmp slt i64 %t245, %t246
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb66:
  br label %bb67
bb67:
  %t251 = load ptr, ptr %l17, !tbaa !29
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s11, ptr %t251, i64 %t252)
  store %"compiler/views:place" %t255, ptr %l130
  br label %bb68
bb68:
  %t256 = load %"compiler/views:place", ptr %l130
  store %"compiler/views:place" %t256, ptr %l19
  %t257 = getelementptr %"compiler/views:place", ptr %l19, i32 0, i32 3
  %t258 = load i1, ptr %t257, !tbaa !21
  br i1 %t258, label %bb69, label %bb70
bb69:
  %t260 = load ptr, ptr %l3, !tbaa !29
  %t261 = load %"compiler/views:place", ptr %l19
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t260, %"compiler/views:place" %t261)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb72:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l134, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/views:Viewer", ptr %t265, i32 0, i32 3
  %t268 = getelementptr %"compiler/views:place", ptr %l19, i32 0, i32 1
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s14, ptr %t267, i64 %t269)
  store { i64, ptr } %t272, ptr %l138
  br label %bb73
bb73:
  %t273 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 1
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t278 = extractvalue { i64, ptr } %t273, 1
  %t279 = extractvalue { i64, ptr } %t273, 0
  %t280 = add i64 %t276, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t275, i64 %t276)
  %t282 = getelementptr i8, ptr %t281, i64 %t276
  call void @olang_textcopy(ptr %t282, ptr %t278, i64 %t279)
  %t283 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t281, 1
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t287 = extractvalue { i64, ptr } %t284, 1
  %t288 = mul i64 %t286, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t288)
  call void @llvm.memcpy.p0.p0.i64(ptr %t289, ptr %t287, i64 %t288, i1 false)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  %t292 = load ptr, ptr %l134, !tbaa !29
  %t294 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s14, ptr %t292, { i64, ptr } %t291)
  store i64 %t294, ptr %l142
  br label %bb74
bb74:
  %t295 = load i64, ptr %l142, !tbaa !24
  store i64 %t295, ptr %l20, !tbaa !24
  %t296 = load ptr, ptr %l3, !tbaa !29
  store ptr %t296, ptr %l143, !tbaa !29
  %t297 = getelementptr %"compiler/views:place", ptr %l19, i32 0, i32 0
  %t298 = load { i64, [2 x i64] }, ptr %t297
  store { i64, [2 x i64] } %t298, ptr %l144
  %t299 = load i64, ptr %l20, !tbaa !24
  store i64 %t299, ptr %l145, !tbaa !24
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/views:Viewer", ptr %t300, i32 0, i32 3
  %t303 = load i64, ptr %l20, !tbaa !24
  %t306 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s14, ptr %t302, i64 %t303)
  store { i64, ptr } %t306, ptr %l149
  br label %bb75
bb75:
  %t307 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 0
  %t309 = load { i64, [2 x i64] }, ptr %l144
  %t310 = load i64, ptr %l145, !tbaa !24
  %t312 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s14, { i64, [2 x i64] } %t309, i64 %t310, i64 %t308, i1 false)
  store %"compiler/views:place" %t312, ptr %l151
  br label %bb76
bb76:
  %t313 = load ptr, ptr %l143, !tbaa !29
  %t314 = load %"compiler/views:place", ptr %l151
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t313, %"compiler/views:place" %t314)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  %t315 = load i64, ptr %l18, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l18, !tbaa !24
  br label %bb63
bb79:
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_dcfb2f8bfac0bc7f_4146aca391677efb)
  unreachable
bb85:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i1
  %l75 = alloca i1
  %l77 = alloca i64
  %l79 = alloca i64
  %l84 = alloca %"compiler/views:view"
  %l89 = alloca ptr
  %l90 = alloca i1
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l111 = alloca i64
  %l113 = alloca i64
  %l118 = alloca %"compiler/views:view"
  %l123 = alloca ptr
  %l124 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l152 = alloca i64
  %l157 = alloca ptr
  %l159 = alloca ptr
  %l162 = alloca i64
  %l164 = alloca ptr
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l25, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t12 = load ptr, ptr %l28, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l28, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l29, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l5
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l6, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load %"compiler/source:Span", ptr %l5
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2euse(ptr %v0, ptr %v2, ptr %t32, i64 %t35, %"compiler/source:Span" %t36, ptr %t37)
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l6, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t47 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eholdsOf(ptr %v0, ptr %v2, ptr %v3, ptr %t42, ptr %t43, i64 %t46, ptr %t47)
  br label %bb13
bb13:
  br label %bb99
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t53 = load ptr, ptr %l46, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l46, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 8}
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l47, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l7, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t67, ptr %t68, ptr %t70, ptr %t71)
  br label %bb20
bb20:
  br label %bb99
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t77 = load ptr, ptr %l57, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l57, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l58, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l8, !tbaa !23
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb45
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l65
  br label %bb27
bb27:
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %l10
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l9, !tbaa !29
  %t102 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s4, ptr %t99, ptr %t100, i1 false, ptr %t102, ptr %l10)
  br label %bb28
bb28:
  %t107 = load i1, ptr %l2, !tbaa !21
  br i1 %t107, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb32
bb30:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l8, !tbaa !23
  %t113 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t109, i32 %t110)
  store i1 %t113, ptr %l75
  br label %bb31
bb31:
  %t114 = load i1, ptr %l75, !tbaa !21
  store i1 %t114, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t115 = load i1, ptr %l72, !tbaa !21
  br i1 %t115, label %bb33, label %bb34
bb33:
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb34:
  br label %bb44
bb35:
  %t117 = load i64, ptr %l12, !tbaa !24
  store i64 %t117, ptr %l77, !tbaa !24
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s4, ptr %t118)
  store i64 %t120, ptr %l79
  br label %bb36
bb36:
  %t121 = load i64, ptr %l77, !tbaa !24
  %t122 = load i64, ptr %l79, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  br label %bb39
bb39:
  %t127 = load ptr, ptr %l11, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s4, ptr %t127, i64 %t128)
  store %"compiler/views:view" %t131, ptr %l84
  br label %bb40
bb40:
  %t132 = load %"compiler/views:view", ptr %l84
  %t133 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t133, %"compiler/views:view" %t132)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l12, !tbaa !24
  br label %bb35
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb99
bb45:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t142 = load ptr, ptr %l89, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb46, label %bb47
bb46:
  %t145 = load ptr, ptr %l89, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 8}
  %t148 = icmp eq i64 %t146, 4
  store i1 %t148, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t149 = load i1, ptr %l90, !tbaa !21
  br i1 %t149, label %bb48, label %bb49
bb48:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t152, i32 0, i32 2
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l14, !tbaa !29
  br label %bb50
bb49:
  br label %bb67
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t156 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %l95
  br label %bb51
bb51:
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l15
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l14, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Elem", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s9, ptr %t158, ptr %t162, i1 false, ptr %t164, ptr %l15)
  br label %bb52
bb52:
  %t169 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l102
  br label %bb53
bb53:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l16
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l14, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Elem", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s9, ptr %t171, ptr %t175, ptr %t177, ptr %l16)
  br label %bb54
bb54:
  %t182 = load i1, ptr %l2, !tbaa !21
  br i1 %t182, label %bb55, label %bb56
bb55:
  store ptr %l15, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb57
bb56:
  br label %bb66
bb57:
  %t185 = load i64, ptr %l18, !tbaa !24
  store i64 %t185, ptr %l111, !tbaa !24
  %t186 = load ptr, ptr %l17, !tbaa !29
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s9, ptr %t186)
  store i64 %t188, ptr %l113
  br label %bb58
bb58:
  %t189 = load i64, ptr %l111, !tbaa !24
  %t190 = load i64, ptr %l113, !tbaa !24
  %t191 = icmp slt i64 %t189, %t190
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb59, label %bb60
bb59:
  br label %bb65
bb60:
  br label %bb61
bb61:
  %t195 = load ptr, ptr %l17, !tbaa !29
  %t196 = load i64, ptr %l18, !tbaa !24
  %t199 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s9, ptr %t195, i64 %t196)
  store %"compiler/views:view" %t199, ptr %l118
  br label %bb62
bb62:
  %t200 = load %"compiler/views:view", ptr %l118
  %t201 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t201, %"compiler/views:view" %t200)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t205 = load i64, ptr %l18, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l18, !tbaa !24
  br label %bb57
bb65:
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s9)
  br label %bb99
bb67:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t210 = load ptr, ptr %l123, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l123, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 8}
  %t216 = icmp eq i64 %t214, 5
  store i1 %t216, ptr %l124, !tbaa !21
  br label %bb69
bb69:
  %t217 = load i1, ptr %l124, !tbaa !21
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l20, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l20, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Payload", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = load ptr, ptr %l3, !tbaa !29
  %t231 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t224, ptr %t228, i1 false, ptr %t230, ptr %t231)
  br label %bb73
bb73:
  br label %bb99
bb74:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t237 = load ptr, ptr %l135, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb75, label %bb76
bb75:
  %t240 = load ptr, ptr %l135, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 8}
  %t243 = icmp eq i64 %t241, 6
  store i1 %t243, ptr %l136, !tbaa !21
  br label %bb76
bb76:
  %t244 = load i1, ptr %l136, !tbaa !21
  br i1 %t244, label %bb77, label %bb78
bb77:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l21, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l21, !tbaa !29
  %t254 = load ptr, ptr %l3, !tbaa !29
  %t255 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t251, ptr %t252, ptr %t254, ptr %t255)
  br label %bb80
bb80:
  br label %bb99
bb81:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t261 = load ptr, ptr %l146, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb82, label %bb83
bb82:
  %t264 = load ptr, ptr %l146, !tbaa !29
  %t265 = load i64, ptr %t264, !range !{i64 0, i64 8}
  %t267 = icmp eq i64 %t265, 7
  store i1 %t267, ptr %l147, !tbaa !21
  br label %bb83
bb83:
  %t268 = load i1, ptr %l147, !tbaa !21
  br i1 %t268, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb94
bb86:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/views:Viewer", ptr %t269, i32 0, i32 28
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l152
  br label %bb87
bb87:
  %t274 = load i64, ptr %l152, !tbaa !24
  %t275 = icmp sgt i64 %t274, 0
  br i1 %t275, label %bb88, label %bb89
bb88:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/views:Viewer", ptr %t277, i32 0, i32 23
  %t280 = load i1, ptr %t279, !tbaa !21
  store i1 %t280, ptr %l22, !tbaa !21
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/views:Viewer", ptr %t282, i32 0, i32 23
  store i1 true, ptr %t284, !tbaa !21
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l157, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/views:Viewer", ptr %t286, i32 0, i32 28
  store ptr %t288, ptr %l159, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/views:Viewer", ptr %t289, i32 0, i32 28
  %t293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t291)
  store i64 %t293, ptr %l162
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t294 = load i64, ptr %l162, !tbaa !24
  %t295 = sub i64 %t294, 1
  %t296 = load ptr, ptr %l159, !tbaa !29
  %t298 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t296, i64 %t295)
  store ptr %t298, ptr %l164
  br label %bb91
bb91:
  %t299 = load ptr, ptr %l164, !tbaa !29
  %t300 = load i1, ptr %l2, !tbaa !21
  %t301 = load ptr, ptr %l3, !tbaa !29
  %t302 = load ptr, ptr %l4, !tbaa !29
  %t303 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t303, ptr %t299, i1 %t300, ptr %t301, ptr %t302)
  br label %bb92
bb92:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i1, ptr %l22, !tbaa !21
  %t312 = getelementptr %"compiler/views:Viewer", ptr %t308, i32 0, i32 23
  store i1 %t309, ptr %t312, !tbaa !21
  br label %bb93
bb93:
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_7b1b67136b76c79_188c2ea4ec84d8a5)
  unreachable
bb99:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Elem", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t27, i8 91)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t32, ptr %l6
  br label %bb20
bb7:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 3
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l4
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t60 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, ptr %t56, i8 46)
  store %"compiler/source:Span" %t60, ptr %l31
  br label %bb13
bb13:
  %t61 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t62)
  store %"compiler/source:Span" %t64, ptr %l33
  br label %bb18
bb18:
  %t65 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t65, ptr %l6
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_26b1312863f2c2c7_c8d66606dd24933b)
  unreachable
bb20:
  %t66 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 3
  %t7 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/views:Viewer", ptr %t9, i32 0, i32 3
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t11, i64 %a2)
  store { i64, ptr } %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v0, { i64, ptr } %t17, { i64, ptr } %t18)
  store i1 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp eq i64 %t25, %t28
  br i1 %t31, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb12
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 46
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = icmp eq i8 %t54, 91
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t58 = load i1, ptr %l28, !tbaa !21
  store i1 %t58, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l16, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2equoted(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/views:Viewer", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l14
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 1
  %t31 = load { i64, [2 x i64] }, ptr %t30
  store { i64, [2 x i64] } %t31, ptr %l2
  %t33 = load { i64, [2 x i64] }, ptr %l2
  %t35 = extractvalue { i64, [2 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 0
  br i1 %t36, label %bb5, label %bb6
bb5:
  %t38 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t39 = getelementptr { i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb11
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/views:Viewer", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/views:Viewer", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l27
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l27, !tbaa !24
  %t57 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t57, ptr %l28
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load ptr, ptr %l21, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %s2, ptr %t62, i32 %t61)
  store { i64, ptr } %t64, ptr %l31
  br label %bb10
bb10:
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t75, ptr %t68, i64 %t69)
  %t76 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t76, ptr %t71, i64 %t72)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t74, 1
  store { i64, ptr } %t78, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb11:
  %t80 = load { i64, [2 x i64] }, ptr %l2
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 1
  br i1 %t83, label %bb12, label %bb13
bb12:
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t86 = getelementptr { i32, i32 }, ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb18
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l36, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/views:Viewer", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l39, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/views:Viewer", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l4, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l44
  br label %bb15
bb15:
  %t106 = load ptr, ptr %l39, !tbaa !29
  %t107 = load i32, ptr %l44, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t108, ptr %l45
  br label %bb16
bb16:
  %t109 = load ptr, ptr %l36, !tbaa !29
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %s4, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l46
  br label %bb17
bb17:
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t114 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t112, i64 %t113)
  %t122 = getelementptr i8, ptr %t121, i64 %t113
  call void @olang_textcopy(ptr %t122, ptr %t115, i64 %t116)
  %t123 = getelementptr i8, ptr %t122, i64 %t116
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t121, 1
  store { i64, ptr } %t125, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t127, ptr %l17, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_52eb4a404ee8e2f2_daf885f9c5247eae)
  unreachable
bb23:
  %t129 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l50, !tbaa !24
  %t131 = load i64, ptr %l50, !tbaa !24
  %t132 = mul i64 %t131, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l51, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = mul i64 %t140, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %t139, i64 %t141, i1 false)
  %t142 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t142, ptr %l17, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erecordPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i32, ptr %l7, !tbaa !23
  %t7 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t7, ptr %l8
  br label %bb2
bb2:
  %t8 = load i1, ptr %l8, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 2
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t26, ptr %t27, ptr %t29, ptr %t30)
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t38, ptr %t39)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_24f4045ab8cbf215_2ef83d27164e37c1)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 8}
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %t27, i64 %t30)
  store i1 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb13
bb12:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l10, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_40eaf25cbb0521a7_3d2a576ac0c8b0f3)
  unreachable
bb19:
  %t40 = load i64, ptr %l10, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  store i64 64, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l23, !tbaa !24
  store i64 %t30, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb70
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l8, !tbaa !24
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb11, label %bb12
bb11:
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l2, !tbaa !29
  store ptr %t55, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t56 = load ptr, ptr %l44, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l44, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 3
  store i1 %t62, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l45, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l9, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t70 = load ptr, ptr %l9, !tbaa !29
  store ptr %t70, ptr %l2, !tbaa !29
  br label %bb68
bb19:
  %t73 = load ptr, ptr %l2, !tbaa !29
  store ptr %t73, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t74 = load ptr, ptr %l52, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l52, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 4
  store i1 %t80, ptr %l53, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l53, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l10, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Elem", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l2, !tbaa !29
  br label %bb68
bb25:
  %t94 = load ptr, ptr %l2, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t98 = load ptr, ptr %l61, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 8}
  %t101 = icmp eq i64 %t99, 5
  store i1 %t101, ptr %l62, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l11, !tbaa !29
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t109 = load ptr, ptr %l11, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Payload", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l2, !tbaa !29
  br label %bb68
bb31:
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t116 = load ptr, ptr %l70, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 8}
  %t122 = icmp eq i64 %t120, 2
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb34, label %bb35
bb34:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l12, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t132 = call ptr @compiler_2fviews_2eunAway(ptr %v1, ptr %v1, ptr %t130)
  store ptr %t132, ptr %l77
  br label %bb37
bb37:
  %t133 = load ptr, ptr %l77, !tbaa !29
  store ptr %t133, ptr %l13, !tbaa !29
  %t134 = load ptr, ptr %l13, !tbaa !29
  store ptr %t134, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t135 = load ptr, ptr %l78, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l78, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 2
  store i1 %t141, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t142 = load i1, ptr %l79, !tbaa !21
  br i1 %t142, label %bb40, label %bb41
bb40:
  %t143 = load ptr, ptr %l13, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l14, !tbaa !29
  br label %bb46
bb41:
  %t149 = load ptr, ptr %l13, !tbaa !29
  store ptr %t149, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t150 = load ptr, ptr %l84, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb42, label %bb43
bb42:
  %t153 = load ptr, ptr %l84, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 18}
  %t156 = icmp eq i64 %t154, 3
  store i1 %t156, ptr %l85, !tbaa !21
  br label %bb43
bb43:
  %t157 = load i1, ptr %l85, !tbaa !21
  br i1 %t157, label %bb44, label %bb45
bb44:
  %t158 = load ptr, ptr %l13, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l14, !tbaa !29
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l2, !tbaa !29
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store ptr null, ptr %rv
  br label %ret
bb51:
  call void @__olang_check_failed(ptr @olang_loc_945ffbf6072962e3_f3ad5bbe10c5f487)
  unreachable
bb52:
  br label %bb68
bb53:
  %t168 = load ptr, ptr %l2, !tbaa !29
  store ptr %t168, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t169 = load ptr, ptr %l93, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb54, label %bb55
bb54:
  %t172 = load ptr, ptr %l93, !tbaa !29
  %t173 = load i64, ptr %t172, !range !{i64 0, i64 8}
  %t175 = icmp eq i64 %t173, 0
  store i1 %t175, ptr %l94, !tbaa !21
  br label %bb55
bb55:
  %t176 = load i1, ptr %l94, !tbaa !21
  br i1 %t176, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t177 = load ptr, ptr %l2, !tbaa !29
  store ptr %t177, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t178 = load ptr, ptr %l97, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb58, label %bb59
bb58:
  %t181 = load ptr, ptr %l97, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 8}
  %t184 = icmp eq i64 %t182, 1
  store i1 %t184, ptr %l98, !tbaa !21
  br label %bb59
bb59:
  %t185 = load i1, ptr %l98, !tbaa !21
  br i1 %t185, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t186 = load ptr, ptr %l2, !tbaa !29
  store ptr %t186, ptr %rv
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store ptr null, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @olang_loc_f83bd81acd9884e2_c22158a061119526)
  unreachable
bb68:
  br label %bb69
bb69:
  %t189 = load i64, ptr %l7, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l7, !tbaa !24
  br label %bb7
bb70:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 20
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_5699d6f0b9487a4c_f8171e4e8a154888)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 20
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = shl i64 %t15, 32
  %t18 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = or i64 %t17, %t21
  store i64 %t24, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 29
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t28, i64 %t29)
  store i1 %t32, ptr %l17
  br label %bb4
bb4:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/views:Viewer", ptr %t35, i32 0, i32 29
  %t38 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t37, i64 %t38, i1 true)
  br label %bb8
bb8:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i8
  %l8 = alloca i1
  %l11 = alloca i8
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t3, i64 %t4)
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = icmp eq i8 %t8, 32
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t11, i64 %t12)
  store i8 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = icmp eq i8 %t16, 9
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l8, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = add i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb1
bb11:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l49 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca %"compiler/views:view"
  %l84 = alloca ptr
  %l87 = alloca %"compiler/views:tasked"
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Spawn", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t3, ptr %t7, ptr %t9, ptr %l4)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 23
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l5, !tbaa !21
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/views:Viewer", ptr %t19, i32 0, i32 23
  store i1 true, ptr %t21, !tbaa !21
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l32
  br label %bb3
bb3:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l6
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Spawn", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l7, !tbaa !29
  %t29 = load ptr, ptr %l7, !tbaa !29
  store ptr %t29, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t30 = load ptr, ptr %l35, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = load ptr, ptr %l35, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 6
  store i1 %t36, ptr %l36, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l36, !tbaa !21
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l7, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l8, !tbaa !29
  br label %bb8
bb7:
  br label %bb28
bb8:
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t61 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t61, ptr %l49, !tbaa !27
  %t62 = load i64, ptr %l10, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t69, ptr %t67, ptr %t72, ptr %l6)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb9
bb15:
  %t81 = load ptr, ptr %l8, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Call", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l13, !tbaa !29
  %t86 = load ptr, ptr %l13, !tbaa !29
  store ptr %t86, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t87 = load ptr, ptr %l61, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t90 = load ptr, ptr %l61, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 5}
  %t93 = icmp eq i64 %t91, 2
  store i1 %t93, ptr %l62, !tbaa !21
  br label %bb17
bb17:
  %t94 = load i1, ptr %l62, !tbaa !21
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %l13, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { ptr }, ptr %t97, i32 0, i32 0
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l14, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l14, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t101, ptr %t102, ptr %t104, ptr %l6)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ef97709dce49d3b_530bdd1db1d3a0b7)
  unreachable
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_cf8b3001c30b10ba_435a3683731d1196)
  unreachable
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i1, ptr %l5, !tbaa !21
  %t113 = getelementptr %"compiler/views:Viewer", ptr %t109, i32 0, i32 23
  store i1 %t110, ptr %t113, !tbaa !21
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t115 = load i64, ptr %l16, !tbaa !24
  store i64 %t115, ptr %l75, !tbaa !24
  %t116 = load ptr, ptr %l15, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t116)
  store i64 %t118, ptr %l77
  br label %bb35
bb35:
  %t119 = load i64, ptr %l75, !tbaa !24
  %t120 = load i64, ptr %l77, !tbaa !24
  %t121 = icmp slt i64 %t119, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t125 = load ptr, ptr %l15, !tbaa !29
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t125, i64 %t126)
  store %"compiler/views:view" %t129, ptr %l82
  br label %bb39
bb39:
  %t130 = load %"compiler/views:view", ptr %l82
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t133 = getelementptr %"compiler/views:state", ptr %t131, i32 0, i32 4
  store ptr %t133, ptr %l84, !tbaa !29
  %t138 = call %"compiler/views:tasked" @compiler_2fviews_3atasked_2ector(ptr %s9, %"compiler/views:view" %t130, %"compiler/source:Span" %a1)
  store %"compiler/views:tasked" %t138, ptr %l87
  br label %bb40
bb40:
  %t139 = load ptr, ptr %l84, !tbaa !29
  %t140 = load %"compiler/views:tasked", ptr %l87
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t139, %"compiler/views:tasked" %t140)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s9)
  br label %bb42
bb42:
  %t141 = load i64, ptr %l16, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l16, !tbaa !24
  br label %bb34
bb43:
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Spawn", ptr %t145, i32 0, i32 0
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s12
  %t154 = load i64, ptr %l19, !tbaa !24
  %t155 = load i64, ptr %l20, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t162 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t162, ptr %l98, !tbaa !27
  %t163 = load i64, ptr %l19, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %s12, ptr %s0, ptr %v2, ptr %t170, ptr %t168, ptr null, ptr %l4, ptr %t172)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb49:
  %t177 = load i64, ptr %l19, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l19, !tbaa !24
  br label %bb44
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/views:state"
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"compiler/views:state"
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l61 = alloca i1
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l113 = alloca %"compiler/views:state"
  %l115 = alloca %"compiler/views:state"
  %l117 = alloca %"compiler/views:state"
  %l119 = alloca %"compiler/views:state"
  %l133 = alloca ptr
  %l134 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l155 = alloca i64
  %l159 = alloca i1
  %l163 = alloca ptr
  %l178 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca %"compiler/views:state"
  %l184 = alloca %"compiler/views:state"
  %l188 = alloca ptr
  %l190 = alloca ptr
  %l192 = alloca %"compiler/views:state"
  %l194 = alloca %"compiler/views:state"
  %l196 = alloca ptr
  %l197 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca i1
  %l230 = alloca ptr
  %l231 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca i1
  %l262 = alloca %"compiler/views:state"
  %l264 = alloca %"compiler/views:state"
  %l270 = alloca ptr
  %l271 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  %l284 = alloca ptr
  %l285 = alloca i1
  %l292 = alloca i64
  %l301 = alloca i1
  %l304 = alloca i64
  %l315 = alloca ptr
  %l316 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t164 = alloca %"compiler/views:state", align 8
  %t166 = alloca %"compiler/views:state", align 8
  %t169 = alloca %"compiler/views:state", align 8
  %t171 = alloca %"compiler/views:state", align 8
  %t307 = alloca %"compiler/views:state", align 8
  %t309 = alloca %"compiler/views:state", align 8
  %t312 = alloca %"compiler/views:state", align 8
  %t317 = alloca %"compiler/views:state", align 8
  %t319 = alloca %"compiler/views:state", align 8
  %t322 = alloca %"compiler/views:state", align 8
  %t476 = alloca %"compiler/views:state", align 8
  %t478 = alloca %"compiler/views:state", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l35, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l38
  br label %bb7
bb7:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l3
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t14 = load ptr, ptr %l39, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l39, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 17}
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l40, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l40, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l47
  br label %bb13
bb13:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l6
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t36, ptr %t37, ptr %t39, ptr %l6)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l4, !tbaa !23
  %t47 = sext i32 %t45 to i64
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v1, ptr %s2, ptr %v2, ptr %t44, i64 %t47, ptr %t48, ptr %l6, i1 true, ptr %t50)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb182
bb16:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t57 = load ptr, ptr %l60, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l60, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 17}
  %t63 = icmp eq i64 %t61, 1
  store i1 %t63, ptr %l61, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l61, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l8, !tbaa !29
  br label %bb21
bb20:
  br label %bb30
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l68
  br label %bb22
bb22:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l9
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/views:Viewer", ptr %t79, i32 0, i32 28
  %t82 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  br label %bb23
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l8, !tbaa !29
  %t88 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t85, ptr %t86, ptr %t88, ptr %l9)
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/views:Viewer", ptr %t93, i32 0, i32 28
  %t97 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s3, ptr %t95)
  %t98 = extractvalue { i32, ptr } %t97, 1
  %t99 = extractvalue { i32, ptr } %t97, 0
  store i32 %t99, ptr %l81
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb26, label %ok.101, !prof !99
ok.101:
  store ptr %t98, ptr %l80
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l80, !tbaa !29
  store ptr %t102, ptr %l77, !tbaa !29
  br label %bb28
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %s3, ptr %v2, ptr %t103, ptr %t104, ptr %t106, ptr %l9, ptr %t108)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb182
bb30:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t115 = load ptr, ptr %l89, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l89, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 17}
  %t121 = icmp eq i64 %t119, 2
  store i1 %t121, ptr %l90, !tbaa !21
  br label %bb32
bb32:
  %t122 = load i1, ptr %l90, !tbaa !21
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t129, ptr %t130, ptr %t132, ptr %l3)
  br label %bb36
bb36:
  br label %bb182
bb37:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t138 = load ptr, ptr %l100, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb38, label %bb39
bb38:
  %t141 = load ptr, ptr %l100, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 17}
  %t144 = icmp eq i64 %t142, 3
  store i1 %t144, ptr %l101, !tbaa !21
  br label %bb39
bb39:
  %t145 = load i1, ptr %l101, !tbaa !21
  br i1 %t145, label %bb40, label %bb41
bb40:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l11, !tbaa !29
  br label %bb42
bb41:
  br label %bb52
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/typed:If", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t152, ptr %t156, ptr %t158, ptr %l3)
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t164, ptr %v2, ptr %s6, ptr %t163)
  call void @llvm.memmove.p0.p0.i64(ptr %l113, ptr %t164, i64 136, i1 false)
  br label %bb44
bb44:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t166, ptr %s6, ptr %l113)
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %t166, i64 136, i1 false)
  br label %bb45
bb45:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l115, i64 136, i1 false)
  %t168 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t169, ptr %v2, ptr %s6, ptr %t168)
  call void @llvm.memmove.p0.p0.i64(ptr %l117, ptr %t169, i64 136, i1 false)
  br label %bb46
bb46:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t171, ptr %s6, ptr %l117)
  call void @llvm.memmove.p0.p0.i64(ptr %l119, ptr %t171, i64 136, i1 false)
  br label %bb47
bb47:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l119, i64 136, i1 false)
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l11, !tbaa !29
  %t176 = getelementptr %"compiler/typed:If", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s6, ptr %t173, ptr %t177, ptr %l12)
  br label %bb48
bb48:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l11, !tbaa !29
  %t185 = getelementptr %"compiler/typed:If", ptr %t183, i32 0, i32 2
  %t186 = load ptr, ptr %t185, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s6, ptr %t182, ptr %t186, ptr %l13)
  br label %bb49
bb49:
  call void @compiler_2fviews_2emerge(ptr %s6, ptr %s6, ptr %l12, ptr %l13)
  br label %bb50
bb50:
  %t192 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s6, ptr %t192, ptr %l12)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s6)
  br label %bb182
bb52:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t196 = load ptr, ptr %l133, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb53, label %bb54
bb53:
  %t199 = load ptr, ptr %l133, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 17}
  %t202 = icmp eq i64 %t200, 4
  store i1 %t202, ptr %l134, !tbaa !21
  br label %bb54
bb54:
  %t203 = load i1, ptr %l134, !tbaa !21
  br i1 %t203, label %bb55, label %bb56
bb55:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t206, i32 0, i32 1
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l14, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l15, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l14, !tbaa !29
  %t218 = load ptr, ptr %l15, !tbaa !29
  %t219 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t216, ptr %t217, ptr %t218, ptr %t219)
  br label %bb58
bb58:
  br label %bb182
bb59:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t225 = load ptr, ptr %l145, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb60, label %bb61
bb60:
  %t228 = load ptr, ptr %l145, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 17}
  %t231 = icmp eq i64 %t229, 5
  store i1 %t231, ptr %l146, !tbaa !21
  br label %bb61
bb61:
  %t232 = load i1, ptr %l146, !tbaa !21
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [3 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t235, i32 0, i32 1
  %t237 = load i32, ptr %t236, !range !{i32 0, i32 2}
  store i32 %t237, ptr %l16
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [3 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t241, i32 0, i32 2
  %t243 = load i32, ptr %t242
  store i32 %t243, ptr %l17, !tbaa !23
  br label %bb64
bb63:
  br label %bb90
bb64:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/views:Viewer", ptr %t245, i32 0, i32 27
  %t249 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H1e03e4f3e9fd2c184a7d157dcdc4524e(ptr %v0, ptr %t247)
  store i64 %t249, ptr %l155
  br label %bb65
bb65:
  %t250 = load i64, ptr %l155, !tbaa !24
  %t251 = sub i64 %t250, 1
  store i64 %t251, ptr %l18, !tbaa !24
  br label %bb66
bb66:
  %t253 = load i64, ptr %l18, !tbaa !24
  %t255 = icmp sge i64 %t253, 0
  br i1 %t255, label %bb67, label %bb68
bb67:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/views:Viewer", ptr %t257, i32 0, i32 27
  %t260 = load i64, ptr %l18, !tbaa !24
  %t263 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H778376aca07487ba188a916552f34a0e(ptr %v0, ptr %v0, ptr %t259, i64 %t260)
  store ptr %t263, ptr %l163
  br label %bb69
bb68:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb70
bb69:
  %t264 = load ptr, ptr %l163, !tbaa !29
  %t266 = getelementptr %"compiler/views:loopFrame", ptr %t264, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t268 = load i32, ptr %l17, !tbaa !23
  %t271 = icmp ne i32 %t267, %t268
  store i1 %t271, ptr %l159, !tbaa !21
  br label %bb70
bb70:
  %t273 = load i1, ptr %l159, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  br label %bb73
bb73:
  %t276 = load i64, ptr %l18, !tbaa !24
  %t278 = sub i64 %t276, 1
  store i64 %t278, ptr %l18, !tbaa !24
  br label %bb74
bb74:
  br label %bb66
bb75:
  %t280 = load i64, ptr %l18, !tbaa !24
  %t282 = icmp sge i64 %t280, 0
  br i1 %t282, label %bb76, label %bb77
bb76:
  %t284 = load i32, ptr %l16, !range !{i32 0, i32 2}
  %t286 = trunc i64 0 to i32
  %t287 = icmp eq i32 %t284, %t286
  br i1 %t287, label %bb78, label %bb79
bb77:
  br label %bb89
bb78:
  store %olang.scope zeroinitializer, ptr %s11
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/views:Viewer", ptr %t289, i32 0, i32 27
  %t292 = load i64, ptr %l18, !tbaa !24
  %t295 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H778376aca07487ba188a916552f34a0e(ptr %v0, ptr %v0, ptr %t291, i64 %t292)
  store ptr %t295, ptr %l178
  br label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s12
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/views:Viewer", ptr %t296, i32 0, i32 27
  %t299 = load i64, ptr %l18, !tbaa !24
  %t302 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H778376aca07487ba188a916552f34a0e(ptr %v0, ptr %v0, ptr %t298, i64 %t299)
  store ptr %t302, ptr %l188
  br label %bb84
bb80:
  %t303 = load ptr, ptr %l178, !tbaa !29
  %t305 = getelementptr %"compiler/views:loopFrame", ptr %t303, i32 0, i32 1
  store ptr %t305, ptr %l180, !tbaa !29
  %t306 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t307, ptr %v2, ptr %s11, ptr %t306)
  call void @llvm.memmove.p0.p0.i64(ptr %l182, ptr %t307, i64 136, i1 false)
  br label %bb81
bb81:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t309, ptr %s11, ptr %l182)
  call void @llvm.memmove.p0.p0.i64(ptr %l184, ptr %t309, i64 136, i1 false)
  br label %bb82
bb82:
  %t311 = load ptr, ptr %l180, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %l184, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %s11, ptr %t311, ptr %t312)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s11)
  br label %bb88
bb84:
  %t313 = load ptr, ptr %l188, !tbaa !29
  %t315 = getelementptr %"compiler/views:loopFrame", ptr %t313, i32 0, i32 2
  store ptr %t315, ptr %l190, !tbaa !29
  %t316 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t317, ptr %v2, ptr %s12, ptr %t316)
  call void @llvm.memmove.p0.p0.i64(ptr %l192, ptr %t317, i64 136, i1 false)
  br label %bb85
bb85:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t319, ptr %s12, ptr %l192)
  call void @llvm.memmove.p0.p0.i64(ptr %l194, ptr %t319, i64 136, i1 false)
  br label %bb86
bb86:
  %t321 = load ptr, ptr %l190, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t322, ptr %l194, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %s12, ptr %t321, ptr %t322)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s12)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t323 = load ptr, ptr %l2, !tbaa !29
  %t325 = getelementptr %"compiler/views:state", ptr %t323, i32 0, i32 0
  store i1 true, ptr %t325, !tbaa !21
  br label %bb182
bb90:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t327 = load ptr, ptr %l196, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb91, label %bb92
bb91:
  %t330 = load ptr, ptr %l196, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 17}
  %t333 = icmp eq i64 %t331, 6
  store i1 %t333, ptr %l197, !tbaa !21
  br label %bb92
bb92:
  %t334 = load i1, ptr %l197, !tbaa !21
  br i1 %t334, label %bb93, label %bb94
bb93:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 0
  %t339 = load %"compiler/source:Span", ptr %t338
  store %"compiler/source:Span" %t339, ptr %l19
  %t341 = load ptr, ptr %l1, !tbaa !29
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 1
  %t344 = getelementptr { %"compiler/source:Span", ptr }, ptr %t343, i32 0, i32 1
  %t345 = load ptr, ptr %t344
  store ptr %t345, ptr %l20, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l19
  %t349 = load ptr, ptr %l20, !tbaa !29
  %t350 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ehandOut(ptr %v0, ptr %v1, ptr %v2, ptr %t347, %"compiler/source:Span" %t348, ptr %t349, ptr %t350)
  br label %bb96
bb96:
  %t355 = load ptr, ptr %l2, !tbaa !29
  %t357 = getelementptr %"compiler/views:state", ptr %t355, i32 0, i32 0
  store i1 true, ptr %t357, !tbaa !21
  br label %bb182
bb97:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t359 = load ptr, ptr %l209, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb98, label %bb99
bb98:
  %t362 = load ptr, ptr %l209, !tbaa !29
  %t363 = load i64, ptr %t362, !range !{i64 0, i64 17}
  %t365 = icmp eq i64 %t363, 16
  store i1 %t365, ptr %l210, !tbaa !21
  br label %bb99
bb99:
  %t366 = load i1, ptr %l210, !tbaa !21
  br i1 %t366, label %bb100, label %bb101
bb100:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [3 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr }, ptr %t369, i32 0, i32 0
  %t371 = load %"compiler/source:Span", ptr %t370
  store %"compiler/source:Span" %t371, ptr %l21
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [3 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", ptr }, ptr %t375, i32 0, i32 1
  %t377 = load ptr, ptr %t376
  store ptr %t377, ptr %l22, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load %"compiler/source:Span", ptr %l21
  %t381 = load ptr, ptr %l22, !tbaa !29
  %t382 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ehandOut(ptr %v0, ptr %v1, ptr %v2, ptr %t379, %"compiler/source:Span" %t380, ptr %t381, ptr %t382)
  br label %bb103
bb103:
  br label %bb182
bb104:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t388 = load ptr, ptr %l221, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb105, label %bb106
bb105:
  %t391 = load ptr, ptr %l221, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 17}
  %t394 = icmp eq i64 %t392, 7
  store i1 %t394, ptr %l222, !tbaa !21
  br label %bb106
bb106:
  %t395 = load i1, ptr %l222, !tbaa !21
  br i1 %t395, label %bb107, label %bb108
bb107:
  br label %bb113
bb108:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t397 = load ptr, ptr %l225, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb109, label %bb110
bb109:
  %t400 = load ptr, ptr %l225, !tbaa !29
  %t401 = load i64, ptr %t400, !range !{i64 0, i64 17}
  %t403 = icmp eq i64 %t401, 8
  store i1 %t403, ptr %l226, !tbaa !21
  br label %bb110
bb110:
  %t404 = load i1, ptr %l226, !tbaa !21
  br i1 %t404, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t407 = getelementptr %"compiler/views:state", ptr %t405, i32 0, i32 0
  store i1 true, ptr %t407, !tbaa !21
  br label %bb182
bb114:
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t409 = load ptr, ptr %l230, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb115, label %bb116
bb115:
  %t412 = load ptr, ptr %l230, !tbaa !29
  %t413 = load i64, ptr %t412, !range !{i64 0, i64 17}
  %t415 = icmp eq i64 %t413, 9
  store i1 %t415, ptr %l231, !tbaa !21
  br label %bb116
bb116:
  %t416 = load i1, ptr %l231, !tbaa !21
  br i1 %t416, label %bb117, label %bb118
bb117:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [3 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t419, i32 0, i32 2
  %t421 = load ptr, ptr %t420
  store ptr %t421, ptr %l23, !tbaa !29
  br label %bb119
bb118:
  br label %bb124
bb119:
  %t423 = load ptr, ptr %l23, !tbaa !29
  %t425 = icmp eq ptr %t423, null
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb120, label %bb121
bb120:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load ptr, ptr %l23, !tbaa !29
  %t432 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t429, ptr %t430, ptr %t432, ptr %l3)
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb123
bb123:
  %t437 = load ptr, ptr %l2, !tbaa !29
  %t439 = getelementptr %"compiler/views:state", ptr %t437, i32 0, i32 0
  store i1 true, ptr %t439, !tbaa !21
  br label %bb182
bb124:
  %t440 = load ptr, ptr %l1, !tbaa !29
  store ptr %t440, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t441 = load ptr, ptr %l245, !tbaa !29
  %t442 = icmp ne ptr %t441, null
  br i1 %t442, label %bb125, label %bb126
bb125:
  %t444 = load ptr, ptr %l245, !tbaa !29
  %t445 = load i64, ptr %t444, !range !{i64 0, i64 17}
  %t447 = icmp eq i64 %t445, 10
  store i1 %t447, ptr %l246, !tbaa !21
  br label %bb126
bb126:
  %t448 = load i1, ptr %l246, !tbaa !21
  br i1 %t448, label %bb127, label %bb128
bb127:
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t451 = getelementptr { i64, [3 x i64] }, ptr %t449, i32 0, i32 1
  %t452 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t451, i32 0, i32 1
  %t453 = load ptr, ptr %t452
  store ptr %t453, ptr %l24, !tbaa !29
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr { i64, [3 x i64] }, ptr %t455, i32 0, i32 1
  %t458 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t457, i32 0, i32 2
  %t459 = load ptr, ptr %t458
  store ptr %t459, ptr %l25, !tbaa !29
  br label %bb129
bb128:
  br label %bb137
bb129:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l24, !tbaa !29
  %t464 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t461, ptr %t462, ptr %t464, ptr %l3)
  br label %bb130
bb130:
  %t469 = load ptr, ptr %l25, !tbaa !29
  %t471 = icmp eq ptr %t469, null
  %t473 = xor i1 %t471, true
  br i1 %t473, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s19
  %t475 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %t476, ptr %v2, ptr %s19, ptr %t475)
  call void @llvm.memmove.p0.p0.i64(ptr %l262, ptr %t476, i64 136, i1 false)
  br label %bb133
bb132:
  br label %bb136
bb133:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %t478, ptr %s19, ptr %l262)
  call void @llvm.memmove.p0.p0.i64(ptr %l264, ptr %t478, i64 136, i1 false)
  br label %bb134
bb134:
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l264, i64 136, i1 false)
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %s0, ptr %t480, ptr %t481, ptr %l26, ptr %l3)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s19)
  br label %bb136
bb136:
  br label %bb182
bb137:
  %t487 = load ptr, ptr %l1, !tbaa !29
  store ptr %t487, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t488 = load ptr, ptr %l270, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb138, label %bb139
bb138:
  %t491 = load ptr, ptr %l270, !tbaa !29
  %t492 = load i64, ptr %t491, !range !{i64 0, i64 17}
  %t494 = icmp eq i64 %t492, 11
  store i1 %t494, ptr %l271, !tbaa !21
  br label %bb139
bb139:
  %t495 = load i1, ptr %l271, !tbaa !21
  br i1 %t495, label %bb140, label %bb141
bb140:
  %t496 = load ptr, ptr %l1, !tbaa !29
  %t498 = getelementptr { i64, [3 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", ptr }, ptr %t498, i32 0, i32 1
  %t500 = load ptr, ptr %t499
  store ptr %t500, ptr %l27, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l27, !tbaa !29
  %t505 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t502, ptr %t503, ptr %t505)
  br label %bb143
bb143:
  br label %bb182
bb144:
  %t509 = load ptr, ptr %l1, !tbaa !29
  store ptr %t509, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t510 = load ptr, ptr %l280, !tbaa !29
  %t511 = icmp ne ptr %t510, null
  br i1 %t511, label %bb145, label %bb146
bb145:
  %t513 = load ptr, ptr %l280, !tbaa !29
  %t514 = load i64, ptr %t513, !range !{i64 0, i64 17}
  %t516 = icmp eq i64 %t514, 12
  store i1 %t516, ptr %l281, !tbaa !21
  br label %bb146
bb146:
  %t517 = load i1, ptr %l281, !tbaa !21
  br i1 %t517, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb182
bb150:
  %t518 = load ptr, ptr %l1, !tbaa !29
  store ptr %t518, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t519 = load ptr, ptr %l284, !tbaa !29
  %t520 = icmp ne ptr %t519, null
  br i1 %t520, label %bb151, label %bb152
bb151:
  %t522 = load ptr, ptr %l284, !tbaa !29
  %t523 = load i64, ptr %t522, !range !{i64 0, i64 17}
  %t525 = icmp eq i64 %t523, 13
  store i1 %t525, ptr %l285, !tbaa !21
  br label %bb152
bb152:
  %t526 = load i1, ptr %l285, !tbaa !21
  br i1 %t526, label %bb153, label %bb154
bb153:
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr { i64, [3 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr }, ptr %t529, i32 0, i32 1
  %t531 = load ptr, ptr %t530
  store ptr %t531, ptr %l28, !tbaa !29
  br label %bb155
bb154:
  br label %bb167
bb155:
  %t533 = load ptr, ptr %l2, !tbaa !29
  %t535 = getelementptr %"compiler/views:state", ptr %t533, i32 0, i32 4
  %t537 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t535)
  store i64 %t537, ptr %l292
  br label %bb156
bb156:
  %t538 = load i64, ptr %l292, !tbaa !24
  store i64 %t538, ptr %l29, !tbaa !24
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load ptr, ptr %l28, !tbaa !29
  %t542 = getelementptr %"compiler/typed:Join", ptr %t540, i32 0, i32 0
  %t543 = load ptr, ptr %t542, !tbaa !29
  %t545 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t539, ptr %t543, ptr %t545)
  br label %bb157
bb157:
  %t549 = load ptr, ptr %l2, !tbaa !29
  %t551 = getelementptr %"compiler/views:state", ptr %t549, i32 0, i32 0
  %t552 = load i1, ptr %t551, !tbaa !21
  %t554 = xor i1 %t552, true
  br i1 %t554, label %bb158, label %bb159
bb158:
  %t556 = load ptr, ptr %l2, !tbaa !29
  %t558 = getelementptr %"compiler/views:state", ptr %t556, i32 0, i32 4
  %t560 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t558)
  store i64 %t560, ptr %l304
  br label %bb160
bb159:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb161
bb160:
  %t561 = load i64, ptr %l29, !tbaa !24
  %t562 = load i64, ptr %l304, !tbaa !24
  %t564 = icmp sgt i64 %t562, %t561
  store i1 %t564, ptr %l301, !tbaa !21
  br label %bb161
bb161:
  %t566 = load i1, ptr %l301, !tbaa !21
  br i1 %t566, label %bb162, label %bb163
bb162:
  %t567 = load ptr, ptr %l2, !tbaa !29
  %t569 = getelementptr %"compiler/views:state", ptr %t567, i32 0, i32 4
  %t570 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eTruncate_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t569, i64 %t570)
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load ptr, ptr %l28, !tbaa !29
  %t576 = getelementptr %"compiler/typed:Join", ptr %t574, i32 0, i32 2
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !27
  %t578 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t573, { i64, ptr } %t577, ptr %t578, ptr %l3)
  br label %bb166
bb166:
  br label %bb182
bb167:
  %t583 = load ptr, ptr %l1, !tbaa !29
  store ptr %t583, ptr %l315, !tbaa !29
  store i1 false, ptr %l316, !tbaa !21
  %t584 = load ptr, ptr %l315, !tbaa !29
  %t585 = icmp ne ptr %t584, null
  br i1 %t585, label %bb168, label %bb169
bb168:
  %t587 = load ptr, ptr %l315, !tbaa !29
  %t588 = load i64, ptr %t587, !range !{i64 0, i64 17}
  %t590 = icmp eq i64 %t588, 14
  store i1 %t590, ptr %l316, !tbaa !21
  br label %bb169
bb169:
  %t591 = load i1, ptr %l316, !tbaa !21
  br i1 %t591, label %bb170, label %bb171
bb170:
  %t592 = load ptr, ptr %l1, !tbaa !29
  %t594 = getelementptr { i64, [3 x i64] }, ptr %t592, i32 0, i32 1
  %t595 = getelementptr { %"compiler/source:Span", ptr }, ptr %t594, i32 0, i32 0
  %t596 = load %"compiler/source:Span", ptr %t595
  store %"compiler/source:Span" %t596, ptr %l30
  %t598 = load ptr, ptr %l1, !tbaa !29
  %t600 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 1
  %t601 = getelementptr { %"compiler/source:Span", ptr }, ptr %t600, i32 0, i32 1
  %t602 = load ptr, ptr %t601
  store ptr %t602, ptr %l31, !tbaa !29
  br label %bb172
bb171:
  br label %bb174
bb172:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t605 = load %"compiler/source:Span", ptr %l30
  %t606 = load ptr, ptr %l31, !tbaa !29
  %t607 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %t604, %"compiler/source:Span" %t605, ptr %t606, ptr %t607)
  br label %bb173
bb173:
  br label %bb182
bb174:
  %t612 = load ptr, ptr %l1, !tbaa !29
  store ptr %t612, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t613 = load ptr, ptr %l327, !tbaa !29
  %t614 = icmp ne ptr %t613, null
  br i1 %t614, label %bb175, label %bb176
bb175:
  %t616 = load ptr, ptr %l327, !tbaa !29
  %t617 = load i64, ptr %t616, !range !{i64 0, i64 17}
  %t619 = icmp eq i64 %t617, 15
  store i1 %t619, ptr %l328, !tbaa !21
  br label %bb176
bb176:
  %t620 = load i1, ptr %l328, !tbaa !21
  br i1 %t620, label %bb177, label %bb178
bb177:
  %t621 = load ptr, ptr %l1, !tbaa !29
  %t623 = getelementptr { i64, [3 x i64] }, ptr %t621, i32 0, i32 1
  %t624 = getelementptr { %"compiler/source:Span", ptr }, ptr %t623, i32 0, i32 1
  %t625 = load ptr, ptr %t624
  store ptr %t625, ptr %l32, !tbaa !29
  br label %bb179
bb178:
  br label %bb181
bb179:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load ptr, ptr %l32, !tbaa !29
  %t630 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t627, ptr %t628, ptr %t630, ptr %l3)
  br label %bb180
bb180:
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_1e57e3539652abf4_8f970453f904e310)
  unreachable
bb182:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/views:holding"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/views:place"
  %l16 = alloca %"compiler/views:view"
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca %"compiler/views:holding"
  %l58 = alloca i64
  %l60 = alloca i64
  %l65 = alloca %"compiler/views:place"
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, [2 x i64] }
  %l71 = alloca { i64, [2 x i64] }
  %l73 = alloca i1
  %l74 = alloca i1
  %l78 = alloca i1
  %l84 = alloca %"compiler/views:place"
  %l86 = alloca ptr
  %l87 = alloca i64
  %l90 = alloca %"compiler/views:holding"
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca i1
  %l114 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t128 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l20
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t9, ptr %t10, ptr %t12, ptr %l5)
  br label %bb3
bb3:
  store i64 0, ptr %l6, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/views:state", ptr %t17, i32 0, i32 1
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t19)
  store i64 %t21, ptr %l28
  br label %bb4
bb4:
  %t22 = load i64, ptr %l28, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb10
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l35, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l35, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l32, !tbaa !24
  store i64 %t50, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  br label %bb40
bb13:
  br label %bb14
bb14:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l11, !tbaa !24
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/views:state", ptr %t69, i32 0, i32 1
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t71, i64 %t72)
  store %"compiler/views:holding" %t75, ptr %l56
  br label %bb15
bb15:
  %t76 = load %"compiler/views:holding", ptr %l56
  store %"compiler/views:holding" %t76, ptr %l12
  store ptr %l5, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb16
bb16:
  %t78 = load i64, ptr %l14, !tbaa !24
  store i64 %t78, ptr %l58, !tbaa !24
  %t79 = load ptr, ptr %l13, !tbaa !29
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t79)
  store i64 %t81, ptr %l60
  br label %bb17
bb17:
  %t82 = load i64, ptr %l58, !tbaa !24
  %t83 = load i64, ptr %l60, !tbaa !24
  %t84 = icmp slt i64 %t82, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb18, label %bb19
bb18:
  br label %bb38
bb19:
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t89 = load i64, ptr %l14, !tbaa !24
  %t92 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t88, i64 %t89)
  store %"compiler/views:place" %t92, ptr %l65
  br label %bb21
bb21:
  %t93 = load %"compiler/views:place", ptr %l65
  store %"compiler/views:place" %t93, ptr %l15
  %t94 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t95 = getelementptr %"compiler/views:view", ptr %t94, i32 0, i32 0
  %t96 = getelementptr %"compiler/views:place", ptr %t95, i32 0, i32 0
  %t97 = load { i64, [2 x i64] }, ptr %t96
  %t99 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t97)
  store i1 %t99, ptr %l67
  br label %bb22
bb22:
  %t100 = load i1, ptr %l67, !tbaa !21
  br i1 %t100, label %bb23, label %bb24
bb23:
  %t101 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t102 = getelementptr %"compiler/views:view", ptr %t101, i32 0, i32 0
  %t103 = getelementptr %"compiler/views:place", ptr %t102, i32 0, i32 0
  %t104 = load { i64, [2 x i64] }, ptr %t103
  store { i64, [2 x i64] } %t104, ptr %l69
  %t105 = getelementptr %"compiler/views:place", ptr %l15, i32 0, i32 0
  %t106 = load { i64, [2 x i64] }, ptr %t105
  store { i64, [2 x i64] } %t106, ptr %l71
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l69, ptr %l71)
  store i1 %t109, ptr %l73
  br label %bb25
bb24:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb26
bb25:
  %t110 = load i1, ptr %l73, !tbaa !21
  store i1 %t110, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t111 = load i1, ptr %l68, !tbaa !21
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/views:place", ptr %l15, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t116 = getelementptr %"compiler/views:view", ptr %t115, i32 0, i32 0
  %t117 = getelementptr %"compiler/views:place", ptr %t116, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  %t122 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t112, i64 %t114, i64 %t118)
  store i1 %t122, ptr %l78
  br label %bb29
bb28:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb30
bb29:
  %t123 = load i1, ptr %l78, !tbaa !21
  store i1 %t123, ptr %l74, !tbaa !21
  br label %bb30
bb30:
  %t124 = load i1, ptr %l74, !tbaa !21
  br i1 %t124, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t126 = load %"compiler/views:view", ptr %t125
  store %"compiler/views:view" %t126, ptr %l16
  store { i64, [2 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [2 x i64] }, ptr %t128, i32 0, i32 0
  store i64 0, ptr %t129
  %t130 = load { i64, [2 x i64] }, ptr %t128
  %t131 = getelementptr %"compiler/views:view", ptr %l16, i32 0, i32 0
  %t132 = getelementptr %"compiler/views:place", ptr %t131, i32 0, i32 1
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = getelementptr %"compiler/views:view", ptr %l16, i32 0, i32 0
  %t135 = getelementptr %"compiler/views:place", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/views:view", ptr %l16, i32 0, i32 0
  %t138 = getelementptr %"compiler/views:place", ptr %t137, i32 0, i32 3
  %t139 = load i1, ptr %t138, !tbaa !21
  %t144 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s5, { i64, [2 x i64] } %t130, i64 %t133, i64 %t136, i1 %t139)
  store %"compiler/views:place" %t144, ptr %l84
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t145 = load %"compiler/views:place", ptr %l84
  %t146 = getelementptr %"compiler/views:view", ptr %l16, i32 0, i32 0
  store %"compiler/views:place" %t145, ptr %t146
  %t147 = load ptr, ptr %l3, !tbaa !29
  %t149 = getelementptr %"compiler/views:state", ptr %t147, i32 0, i32 1
  store ptr %t149, ptr %l86, !tbaa !29
  %t150 = load i64, ptr %l11, !tbaa !24
  store i64 %t150, ptr %l87, !tbaa !24
  %t151 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = load %"compiler/views:view", ptr %l16
  %t156 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s5, i64 %t152, %"compiler/views:view" %t153)
  store %"compiler/views:holding" %t156, ptr %l90
  br label %bb34
bb34:
  %t157 = load ptr, ptr %l86, !tbaa !29
  %t158 = load i64, ptr %l87, !tbaa !24
  %t159 = load %"compiler/views:holding", ptr %l90
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eSetAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t157, i64 %t158, %"compiler/views:holding" %t159)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb36:
  br label %bb37
bb37:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l14, !tbaa !24
  br label %bb16
bb38:
  br label %bb39
bb39:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l10, !tbaa !24
  br label %bb11
bb40:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb41, label %bb42
bb41:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l98, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  store ptr %t175, ptr %l100, !tbaa !29
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t177)
  store i32 %t179, ptr %l102
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t182 = load ptr, ptr %l98, !tbaa !29
  %t183 = load ptr, ptr %l100, !tbaa !29
  %t184 = load i32, ptr %l102, !tbaa !23
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t182, ptr %t183, i32 %t184, ptr %t180, ptr %t181)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t187 = load i64, ptr %l4, !tbaa !24
  %t189 = icmp slt i64 %t187, 0
  br i1 %t189, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb47:
  br label %bb48
bb48:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb49, label %bb50
bb49:
  %t195 = load ptr, ptr %l107, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 8}
  %t198 = icmp eq i64 %t196, 3
  store i1 %t198, ptr %l108, !tbaa !21
  br label %bb50
bb50:
  %t199 = load i1, ptr %l108, !tbaa !21
  br i1 %t199, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t202 = load i64, ptr %l4, !tbaa !24
  %t206 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v3, ptr %t200, ptr %t201, i64 %t202)
  store i1 %t206, ptr %l114
  br label %bb54
bb54:
  %t207 = load i1, ptr %l114, !tbaa !21
  br i1 %t207, label %bb55, label %bb56
bb55:
  %t208 = load ptr, ptr %l3, !tbaa !29
  %t209 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v3, ptr %t208, i64 %t209)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_551fdf32d31d54b_8fb5917c27ba1e87)
  unreachable
bb64:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/views:Viewer", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t36)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/views:Viewer", ptr %t39, i32 0, i32 4
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l21, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/views:Viewer", ptr %t56, i32 0, i32 3
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load ptr, ptr %l18, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64, i64 %t62)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:Viewer", ptr %t66, i32 0, i32 3
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l28
  br label %bb11
bb11:
  %t71 = load i64, ptr %l28, !tbaa !24
  %t72 = sub i64 %t71, 1
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i1
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/views:Viewer", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l16, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:Viewer", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb5:
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = load i32, ptr %l21, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l22
  br label %bb6
bb6:
  %t41 = load i32, ptr %l22, !range !{i32 0, i32 6}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i1, ptr %l13, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t24)
  store %"compiler/source:Span" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t29, ptr %l7
  br label %bb38
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb16
bb11:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceTok(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/source:Span" %t64, ptr %l34
  br label %bb17
bb17:
  %t65 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t65, ptr %l7
  br label %bb38
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 5
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l36, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Promote", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  store %"compiler/source:Span" %t88, ptr %l44
  br label %bb24
bb24:
  %t89 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t89, ptr %l7
  br label %bb38
bb25:
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i64, ptr %t94, !range !{i64 0, i64 18}
  %t97 = icmp eq i64 %t95, 17
  store i1 %t97, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l6, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t105, ptr %t106)
  store %"compiler/source:Span" %t109, ptr %l53
  br label %bb31
bb31:
  %t110 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t110, ptr %l7
  br label %bb38
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t111)
  store %"compiler/source:Span" %t113, ptr %l55
  br label %bb36
bb36:
  %t114 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t114, ptr %l7
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a630935aa2e7253f_7098fd3403d75c2b)
  unreachable
bb38:
  %t115 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2euse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/views:holding"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca %"compiler/msgs:Msg"
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/views:holding"
  %l36 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l60 = alloca i1
  %l83 = alloca i1
  %l89 = alloca i1
  %l92 = alloca { i64, ptr }
  %l101 = alloca %"compiler/typed:Local"
  %l105 = alloca %"compiler/msgs:Msg"
  %l108 = alloca %"compiler/msgs:Msg"
  %l111 = alloca { i64, ptr }
  %l114 = alloca %"compiler/msgs:Msg"
  %l118 = alloca ptr
  %l121 = alloca { i64, [3 x i64] }
  %l123 = alloca i64
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca i64
  %l135 = alloca { i64, [3 x i64] }
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i1
  %l149 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i64
  %l161 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/msgs:Msg"
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t340 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 23
  %t11 = load i1, ptr %t10, !tbaa !21
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 24
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l20, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = getelementptr %"compiler/views:state", ptr %a3, i32 0, i32 1
  store ptr %t22, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l25, !tbaa !24
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t25)
  store i64 %t27, ptr %l27
  br label %bb11
bb11:
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = load i64, ptr %l27, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb74
bb13:
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t34, i64 %t35)
  store %"compiler/views:holding" %t38, ptr %l32
  br label %bb15
bb15:
  %t39 = load %"compiler/views:holding", ptr %l32
  store %"compiler/views:holding" %t39, ptr %l6
  %t40 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb18
bb17:
  %t47 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t48 = getelementptr %"compiler/views:view", ptr %t47, i32 0, i32 2
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l36, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb22
bb20:
  %t54 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t55 = getelementptr %"compiler/views:view", ptr %t54, i32 0, i32 0
  %t56 = getelementptr %"compiler/views:place", ptr %t55, i32 0, i32 0
  %t57 = load { i64, [2 x i64] }, ptr %t56
  %t59 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t57)
  store i1 %t59, ptr %l41
  br label %bb21
bb21:
  %t60 = load i1, ptr %l41, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb73
bb24:
  br label %bb25
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 20
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f889b3d9696b6a08_112f010babbc7bb4)
  unreachable
bb27:
  br label %bb28
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/views:Viewer", ptr %t71, i32 0, i32 20
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 3
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = shl i64 %t78, 40
  %t81 = load i64, ptr %l1, !tbaa !24
  %t83 = shl i64 %t81, 24
  %t86 = or i64 %t80, %t83
  %t87 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t88 = getelementptr %"compiler/views:view", ptr %t87, i32 0, i32 3
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  %t95 = or i64 %t86, %t92
  store i64 %t95, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/views:Viewer", ptr %t97, i32 0, i32 30
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t99, i64 %t100)
  store i1 %t103, ptr %l60
  br label %bb29
bb29:
  %t104 = load i1, ptr %l60, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/views:Viewer", ptr %t105, i32 0, i32 30
  %t108 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t107, i64 %t108, i1 true)
  br label %bb33
bb33:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/views:Viewer", ptr %t111, i32 0, i32 20
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_fbef590508ae9827_444bd78203178143)
  unreachable
bb35:
  br label %bb36
bb36:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/views:Viewer", ptr %t118, i32 0, i32 20
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Body", ptr %t121, i32 0, i32 3
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = shl i64 %t125, 48
  %t128 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t129 = getelementptr %"compiler/views:view", ptr %t128, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = and i64 %t130, 16777215
  %t134 = shl i64 %t132, 24
  %t137 = or i64 %t127, %t134
  %t138 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t139 = getelementptr %"compiler/views:view", ptr %t138, i32 0, i32 3
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t145 = and i64 %t143, 16777215
  %t148 = or i64 %t137, %t145
  store i64 %t148, ptr %l8, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/views:Viewer", ptr %t150, i32 0, i32 31
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t152, i64 %t153)
  store i1 %t156, ptr %l83
  br label %bb37
bb37:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/views:Viewer", ptr %t158, i32 0, i32 31
  %t161 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t160, i64 %t161, i1 true)
  br label %bb41
bb41:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load %"compiler/source:Span", ptr %l2
  %t168 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t164, %"compiler/source:Span" %t165)
  store i1 %t168, ptr %l89
  br label %bb42
bb42:
  %t169 = load i1, ptr %l89, !tbaa !21
  br i1 %t169, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb44:
  br label %bb45
bb45:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t172 = getelementptr %"compiler/views:view", ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/views:place", ptr %t172
  %t176 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s3, ptr %t170, %"compiler/views:place" %t173)
  store { i64, ptr } %t176, ptr %l92
  br label %bb46
bb46:
  %t177 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t177, ptr %l9, !tbaa !27
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/views:Viewer", ptr %t178, i32 0, i32 20
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = icmp eq ptr %t181, null
  br i1 %t183, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_d673b6bd3b875b76_a50d9e4884ce91c2)
  unreachable
bb48:
  br label %bb49
bb49:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 20
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Body", ptr %t188, i32 0, i32 7
  %t192 = load i64, ptr %l1, !tbaa !24
  %t195 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t191, i64 %t192)
  store %"compiler/typed:Local" %t195, ptr %l101
  br label %bb50
bb50:
  %t196 = getelementptr %"compiler/typed:Local", ptr %l101, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  store i32 %t197, ptr %l10, !tbaa !23
  %t199 = load i32, ptr %l10, !tbaa !23
  %t201 = icmp eq i32 %t199, 0
  br i1 %t201, label %bb51, label %bb52
bb51:
  %t203 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t203, { i64, ptr } %t204)
  store %"compiler/msgs:Msg" %t207, ptr %l108
  br label %bb53
bb52:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l10, !tbaa !23
  %t212 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %v0, ptr %t208, i32 %t209)
  store { i64, ptr } %t212, ptr %l111
  br label %bb54
bb53:
  %t213 = load %"compiler/msgs:Msg", ptr %l108
  store %"compiler/msgs:Msg" %t213, ptr %l105
  br label %bb56
bb54:
  %t214 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t219 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t216, { i64, ptr } %t214, { i64, ptr } %t215)
  store %"compiler/msgs:Msg" %t219, ptr %l114
  br label %bb55
bb55:
  %t220 = load %"compiler/msgs:Msg", ptr %l114
  store %"compiler/msgs:Msg" %t220, ptr %l105
  br label %bb56
bb56:
  %t221 = load %"compiler/msgs:Msg", ptr %l105
  store %"compiler/msgs:Msg" %t221, ptr %l11
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/views:Viewer", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/load:Loader", ptr %t228, i32 0, i32 4
  %t231 = load ptr, ptr %t230, !tbaa !29
  store ptr %t231, ptr %l118, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l2
  %t236 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  store { i64, [3 x i64] } %t236, ptr %l121
  br label %bb57
bb57:
  %t237 = load %"compiler/msgs:Msg", ptr %l11
  %t238 = load ptr, ptr %l118, !tbaa !29
  %t239 = load { i64, [3 x i64] }, ptr %l121
  %t241 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t238, { i64, [3 x i64] } %t239, %"compiler/msgs:Msg" %t237)
  store i64 %t241, ptr %l123
  br label %bb58
bb58:
  %t242 = load i64, ptr %l123, !tbaa !24
  store i64 %t242, ptr %l12, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/views:Viewer", ptr %t243, i32 0, i32 3
  %t246 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t247 = getelementptr %"compiler/views:view", ptr %t246, i32 0, i32 4
  %t248 = load i64, ptr %t247, !tbaa !24
  %t251 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t245, i64 %t248)
  store { i64, ptr } %t251, ptr %l127
  br label %bb59
bb59:
  %t252 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t252, ptr %l13, !tbaa !27
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/views:Viewer", ptr %t253, i32 0, i32 0
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 0
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/load:Loader", ptr %t259, i32 0, i32 4
  %t262 = load ptr, ptr %t261, !tbaa !29
  store ptr %t262, ptr %l131, !tbaa !29
  %t263 = load i64, ptr %l12, !tbaa !24
  store i64 %t263, ptr %l132, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t266 = getelementptr %"compiler/views:view", ptr %t265, i32 0, i32 3
  %t267 = load %"compiler/source:Span", ptr %t266
  %t270 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t264, %"compiler/source:Span" %t267)
  store { i64, [3 x i64] } %t270, ptr %l135
  br label %bb60
bb60:
  %t271 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t271, ptr %l136, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t272, ptr %l137, !tbaa !27
  %t273 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t274 = getelementptr %"compiler/views:view", ptr %t273, i32 0, i32 7
  %t275 = load i64, ptr %t274, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t279 = call { i64, ptr } @compiler_2fviews_2ecopyHint(ptr %s3, ptr %s3, i64 %t275, { i64, ptr } %t276)
  store { i64, ptr } %t279, ptr %l140
  br label %bb61
bb61:
  %t280 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t282 = extractvalue { i64, ptr } %t280, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t287 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t290 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %s3, ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t287, { i64, ptr } %t288, { i64, ptr } %t286)
  store %"compiler/msgs:Msg" %t290, ptr %l142
  br label %bb62
bb62:
  %t291 = load ptr, ptr %l131, !tbaa !29
  %t292 = load i64, ptr %l132, !tbaa !24
  %t293 = load { i64, [3 x i64] }, ptr %l135
  %t294 = load %"compiler/msgs:Msg", ptr %l142
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t291, i64 %t292, { i64, [3 x i64] } %t293, %"compiler/msgs:Msg" %t294)
  br label %bb63
bb63:
  %t295 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t296 = getelementptr %"compiler/views:view", ptr %t295, i32 0, i32 5
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = icmp sge i64 %t297, 0
  br i1 %t299, label %bb64, label %bb65
bb64:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/views:Viewer", ptr %t301, i32 0, i32 6
  %t304 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t305 = getelementptr %"compiler/views:view", ptr %t304, i32 0, i32 5
  %t306 = load i64, ptr %t305, !tbaa !24
  %t309 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t303, i64 %t306)
  store i1 %t309, ptr %l149
  br label %bb66
bb65:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb67
bb66:
  %t310 = load i1, ptr %l149, !tbaa !21
  %t311 = xor i1 %t310, true
  store i1 %t311, ptr %l145, !tbaa !21
  br label %bb67
bb67:
  %t313 = load i1, ptr %l145, !tbaa !21
  br i1 %t313, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s8
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/views:Viewer", ptr %t314, i32 0, i32 0
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = getelementptr %"compiler/generic:Program", ptr %t317, i32 0, i32 0
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/load:Loader", ptr %t320, i32 0, i32 4
  %t323 = load ptr, ptr %t322, !tbaa !29
  store ptr %t323, ptr %l154, !tbaa !29
  %t324 = load i64, ptr %l12, !tbaa !24
  store i64 %t324, ptr %l155, !tbaa !24
  %t325 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t326 = getelementptr %"compiler/views:view", ptr %t325, i32 0, i32 5
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t329 = getelementptr %"compiler/views:view", ptr %t328, i32 0, i32 6
  %t330 = getelementptr %"compiler/source:Span", ptr %t329, i32 0, i32 0
  %t331 = load i32, ptr %t330, !tbaa !23
  %t333 = sext i32 %t331 to i64
  %t334 = getelementptr %"compiler/views:holding", ptr %l6, i32 0, i32 1
  %t335 = getelementptr %"compiler/views:view", ptr %t334, i32 0, i32 6
  %t336 = getelementptr %"compiler/source:Span", ptr %t335, i32 0, i32 1
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = sext i32 %t337 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t340
  %t341 = getelementptr { i64, [3 x i64] }, ptr %t340, i32 0, i32 0
  store i64 3, ptr %t341
  %t343 = insertvalue { i64, i64, i64 } undef, i64 %t327, 0
  %t345 = insertvalue { i64, i64, i64 } %t343, i64 %t333, 1
  %t347 = insertvalue { i64, i64, i64 } %t345, i64 %t339, 2
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t340, i32 0, i32 1
  store { i64, i64, i64 } %t347, ptr %t348
  %t349 = load { i64, [3 x i64] }, ptr %t340
  store { i64, [3 x i64] } %t349, ptr %l161
  %t350 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t352 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %s8, { i64, ptr } %t350)
  store %"compiler/msgs:Msg" %t352, ptr %l163
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t353 = load ptr, ptr %l154, !tbaa !29
  %t354 = load i64, ptr %l155, !tbaa !24
  %t355 = load { i64, [3 x i64] }, ptr %l161
  %t356 = load %"compiler/msgs:Msg", ptr %l163
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t353, i64 %t354, { i64, [3 x i64] } %t355, %"compiler/msgs:Msg" %t356)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb73:
  %t357 = load i64, ptr %l5, !tbaa !24
  %t359 = add i64 %t357, 1
  store i64 %t359, ptr %l5, !tbaa !24
  br label %bb10
bb74:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eviewsHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca ptr
  %l54 = alloca i1
  %l58 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l100 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l113 = alloca ptr
  %l119 = alloca i1
  %l123 = alloca ptr
  %l131 = alloca ptr
  %l135 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l151 = alloca i1
  %l152 = alloca i1
  %l157 = alloca i32
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l27, !tbaa !24
  store i64 %t33, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l24, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb67
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:Viewer", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l48
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 3
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 7
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = icmp eq i64 %t63, %t67
  br i1 %t70, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb16
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/views:Viewer", ptr %t72, i32 0, i32 1
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l58
  br label %bb15
bb15:
  %t79 = load ptr, ptr %l58, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/views:Viewer", ptr %t83, i32 0, i32 8
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = icmp eq i64 %t82, %t86
  store i1 %t89, ptr %l54, !tbaa !21
  br label %bb16
bb16:
  %t91 = load i1, ptr %l54, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  br label %bb66
bb18:
  br label %bb19
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/views:Viewer", ptr %t92, i32 0, i32 11
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l67
  br label %bb20
bb20:
  %t99 = load i64, ptr %l67, !tbaa !24
  store i64 %t99, ptr %l7, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/views:Viewer", ptr %t100, i32 0, i32 11
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t102, i64 %t105)
  store i64 %t108, ptr %l72
  br label %bb21
bb21:
  %t109 = load i64, ptr %l72, !tbaa !24
  store i64 %t109, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb27
bb24:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l79, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb26
bb26:
  %t136 = load i64, ptr %l79, !tbaa !24
  store i64 %t136, ptr %l76, !tbaa !24
  br label %bb27
bb27:
  %t137 = load i64, ptr %l76, !tbaa !24
  store i64 %t137, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb29, label %bb30
bb29:
  br label %bb65
bb30:
  br label %bb31
bb31:
  %t146 = load i64, ptr %l7, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/views:Viewer", ptr %t156, i32 0, i32 12
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t158, i64 %t154)
  store i64 %t162, ptr %l100
  br label %bb32
bb32:
  %t163 = load i64, ptr %l100, !tbaa !24
  store i64 %t163, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = icmp slt i64 %t164, 0
  br i1 %t166, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb36
bb34:
  %t168 = load i64, ptr %l13, !tbaa !24
  store i64 %t168, ptr %l104, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/views:Viewer", ptr %t169, i32 0, i32 1
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l107
  br label %bb35
bb35:
  %t174 = load i64, ptr %l104, !tbaa !24
  %t175 = load i64, ptr %l107, !tbaa !24
  %t176 = icmp sge i64 %t174, %t175
  store i1 %t176, ptr %l103, !tbaa !21
  br label %bb36
bb36:
  %t178 = load i1, ptr %l103, !tbaa !21
  br i1 %t178, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb44
bb38:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/views:Viewer", ptr %t179, i32 0, i32 1
  %t182 = load i64, ptr %l13, !tbaa !24
  %t185 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t181, i64 %t182)
  store ptr %t185, ptr %l113
  br label %bb39
bb39:
  %t186 = load ptr, ptr %l113, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t186, i32 0, i32 3
  %t189 = load i64, ptr %t188, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/views:Viewer", ptr %t190, i32 0, i32 7
  %t193 = load i64, ptr %t192, !tbaa !24
  %t196 = icmp ne i64 %t189, %t193
  br i1 %t196, label %bb40, label %bb41
bb40:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/views:Viewer", ptr %t198, i32 0, i32 1
  %t201 = load i64, ptr %l13, !tbaa !24
  %t204 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t200, i64 %t201)
  store ptr %t204, ptr %l123
  br label %bb42
bb41:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb43
bb42:
  %t205 = load ptr, ptr %l123, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Body", ptr %t205, i32 0, i32 3
  %t208 = load i64, ptr %t207, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/views:Viewer", ptr %t209, i32 0, i32 8
  %t212 = load i64, ptr %t211, !tbaa !24
  %t215 = icmp ne i64 %t208, %t212
  store i1 %t215, ptr %l119, !tbaa !21
  br label %bb43
bb43:
  %t217 = load i1, ptr %l119, !tbaa !21
  store i1 %t217, ptr %l109, !tbaa !21
  br label %bb44
bb44:
  %t218 = load i1, ptr %l109, !tbaa !21
  br i1 %t218, label %bb45, label %bb46
bb45:
  br label %bb64
bb46:
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/views:Viewer", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  store ptr %t224, ptr %l131, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/views:Viewer", ptr %t225, i32 0, i32 1
  %t228 = load i64, ptr %l13, !tbaa !24
  %t231 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t227, i64 %t228)
  store ptr %t231, ptr %l135
  br label %bb48
bb48:
  %t232 = load ptr, ptr %l135, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Body", ptr %t232, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = load ptr, ptr %l131, !tbaa !29
  %t238 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s7, ptr %t236, i32 %t235)
  store { i64, ptr } %t238, ptr %l138
  br label %bb49
bb49:
  %t239 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = extractvalue { i64, ptr } %t239, 1
  %t242 = mul i64 %t240, 4
  %t243 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, ptr } %t245, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l16, !tbaa !24
  br label %bb50
bb50:
  %t251 = load i64, ptr %l15, !tbaa !24
  %t252 = load i64, ptr %l16, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb51, label %bb52
bb51:
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t259 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t259, ptr %l146, !tbaa !27
  %t260 = load i64, ptr %l15, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  store i32 %t265, ptr %l17, !tbaa !23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l17, !tbaa !23
  %t271 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %t267, i32 %t268)
  store i1 %t271, ptr %l151
  br label %bb54
bb54:
  %t272 = load i1, ptr %l151, !tbaa !21
  br i1 %t272, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb58
bb56:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/views:Viewer", ptr %t273, i32 0, i32 0
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l17, !tbaa !23
  %t282 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t278, i32 %t279)
  store i32 %t282, ptr %l157
  br label %bb57
bb57:
  %t283 = load i32, ptr %l157, !range !{i32 0, i32 33}
  %t285 = trunc i64 20 to i32
  %t286 = icmp eq i32 %t283, %t285
  store i1 %t286, ptr %l152, !tbaa !21
  br label %bb58
bb58:
  %t288 = load i1, ptr %l152, !tbaa !21
  br i1 %t288, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t290 = load i64, ptr %l15, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l15, !tbaa !24
  br label %bb50
bb63:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb64:
  %t294 = load i64, ptr %l11, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l11, !tbaa !24
  br label %bb28
bb65:
  br label %bb66
bb66:
  %t298 = load i64, ptr %l5, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l5, !tbaa !24
  br label %bb8
bb67:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l20 = alloca ptr
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca i64
  %l117 = alloca i64
  %l123 = alloca i64
  %l127 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 13
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/views:Viewer", ptr %t5, i32 0, i32 17
  %t8 = load i64, ptr %t7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 %t8)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:Viewer", ptr %t12, i32 0, i32 14
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/views:Viewer", ptr %t16, i32 0, i32 17
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t15, i64 %t19)
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l20, !tbaa !29
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = getelementptr %"compiler/views:Viewer", ptr %t24, i32 0, i32 17
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = add i64 %t26, 1
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/views:Viewer", ptr %t30, i32 0, i32 17
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:Viewer", ptr %t32, i32 0, i32 16
  %t35 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/views:Viewer", ptr %t38, i32 0, i32 15
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41, i1 true)
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/views:Viewer", ptr %t44, i32 0, i32 11
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb5
bb5:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 11
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = add i64 %t55, 1
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb6
bb6:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb7, label %bb8
bb7:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb14, label %bb15
bb14:
  br label %bb49
bb15:
  br label %bb16
bb16:
  %t98 = load i64, ptr %l2, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/views:Viewer", ptr %t108, i32 0, i32 12
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t106)
  store i64 %t114, ptr %l65
  br label %bb17
bb17:
  %t115 = load i64, ptr %l65, !tbaa !24
  store i64 %t115, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb21
bb19:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/views:Viewer", ptr %t121, i32 0, i32 13
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l72
  br label %bb20
bb20:
  %t126 = load i64, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l72, !tbaa !24
  %t128 = icmp sge i64 %t126, %t127
  store i1 %t128, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l68, !tbaa !21
  br i1 %t130, label %bb22, label %bb23
bb22:
  br label %bb48
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/views:Viewer", ptr %t131, i32 0, i32 13
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l77
  br label %bb25
bb25:
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = icmp slt i64 %t138, 0
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %t141, i64 %t142)
  br label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/views:Viewer", ptr %t145, i32 0, i32 15
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t147, i64 %t148)
  store i1 %t151, ptr %l100
  br label %bb36
bb28:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/views:Viewer", ptr %t152, i32 0, i32 14
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l84
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/views:Viewer", ptr %t159, i32 0, i32 14
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l88
  br label %bb30
bb30:
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  br i1 %t168, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/views:Viewer", ptr %t170, i32 0, i32 14
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load i64, ptr %l1, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/views:Viewer", ptr %t174, i32 0, i32 14
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  store i64 %t180, ptr %l96
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t181 = load ptr, ptr %l91, !tbaa !29
  %t182 = load i64, ptr %l92, !tbaa !24
  %t183 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182, i64 %t183)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 13
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l105
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/views:Viewer", ptr %t192, i32 0, i32 14
  %t195 = load i64, ptr %l1, !tbaa !24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l109
  br label %bb40
bb40:
  %t199 = load i64, ptr %l105, !tbaa !24
  %t200 = load i64, ptr %l109, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  store i1 %t201, ptr %l101, !tbaa !21
  br label %bb41
bb41:
  %t203 = load i1, ptr %l101, !tbaa !21
  br i1 %t203, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/views:Viewer", ptr %t204, i32 0, i32 14
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  store i64 %t207, ptr %l113, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/views:Viewer", ptr %t208, i32 0, i32 13
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l117
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = load i64, ptr %l113, !tbaa !24
  %t217 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216, i64 %t217)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb13
bb49:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/views:Viewer", ptr %t222, i32 0, i32 14
  %t225 = load i64, ptr %l1, !tbaa !24
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  store i64 %t228, ptr %l123
  br label %bb50
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/views:Viewer", ptr %t229, i32 0, i32 13
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t232)
  store i64 %t235, ptr %l127
  br label %bb51
bb51:
  %t236 = load i64, ptr %l123, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = icmp eq i64 %t236, %t237
  br i1 %t238, label %bb52, label %bb53
bb52:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/views:Viewer", ptr %t240, i32 0, i32 18
  store ptr %t242, ptr %l130, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/views:Viewer", ptr %t243, i32 0, i32 19
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l133
  br label %bb54
bb53:
  br label %bb68
bb54:
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t249 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t248, i64 %t249)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/views:Viewer", ptr %t250, i32 0, i32 16
  %t254 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t252)
  %t255 = extractvalue { i32, i64 } %t254, 1
  %t256 = extractvalue { i32, i64 } %t254, 0
  store i32 %t256, ptr %l138
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb58, label %ok.258, !prof !99
ok.258:
  store i64 %t255, ptr %l137
  br label %bb57
bb57:
  %t259 = load i64, ptr %l137, !tbaa !24
  store i64 %t259, ptr %l134, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  br label %bb67
bb60:
  %t260 = load i64, ptr %l134, !tbaa !24
  store i64 %t260, ptr %l9, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/views:Viewer", ptr %t261, i32 0, i32 15
  %t264 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t263, i64 %t264, i1 false)
  br label %bb61
bb61:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/views:Viewer", ptr %t267, i32 0, i32 19
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t269, i64 %t270)
  br label %bb62
bb62:
  %t273 = load i64, ptr %l9, !tbaa !24
  %t274 = load i64, ptr %l1, !tbaa !24
  %t277 = icmp eq i64 %t273, %t274
  br i1 %t277, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb56
bb67:
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca %"compiler/views:holding"
  %l31 = alloca ptr
  %l38 = alloca ptr
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca %"compiler/typed:Local"
  %l75 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i64
  %l101 = alloca ptr
  %l105 = alloca i32
  %l110 = alloca %"compiler/views:state"
  %l115 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i64
  %l143 = alloca i32
  %l145 = alloca ptr
  %l149 = alloca %"compiler/typed:Local"
  %l151 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l156 = alloca %"compiler/views:place"
  %l160 = alloca %"compiler/typed:Local"
  %l163 = alloca %"compiler/views:view"
  %l164 = alloca %"compiler/views:holding"
  %l172 = alloca i1
  %l180 = alloca i64
  %l182 = alloca i64
  %l187 = alloca i32
  %l189 = alloca i64
  %l191 = alloca i64
  %l196 = alloca %"compiler/views:holding"
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %t169 = alloca %"compiler/views:state", align 8
  %t253 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l31
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l31, !tbaa !29
  %t10 = getelementptr %"compiler/views:summary", ptr %t8, i32 0, i32 4
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/views:Viewer", ptr %t15, i32 0, i32 1
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l38
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l38, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t23, i32 0, i32 20
  store ptr %t24, ptr %t28, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr %"compiler/views:Viewer", ptr %t29, i32 0, i32 21
  store i64 %t30, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i1, ptr %l2, !tbaa !21
  %t38 = getelementptr %"compiler/views:Viewer", ptr %t34, i32 0, i32 22
  store i1 %t35, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/views:Viewer", ptr %t39, i32 0, i32 23
  store i1 false, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/views:Viewer", ptr %t47, i32 0, i32 7
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = icmp eq i64 %t46, %t50
  %t56 = getelementptr %"compiler/views:Viewer", ptr %t42, i32 0, i32 24
  store i1 %t53, ptr %t56, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/views:Viewer", ptr %t57, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__Hfc8ba67df4afabc6715fbd3122f62db9(ptr %v0, ptr %t59)
  br label %bb6
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %t63)
  br label %bb7
bb7:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t67)
  br label %bb8
bb8:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  store ptr %t71, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t73 = load i64, ptr %l5, !tbaa !24
  store i64 %t73, ptr %l61, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t74)
  store i64 %t76, ptr %l63
  br label %bb10
bb10:
  %t77 = load i64, ptr %l61, !tbaa !24
  %t78 = load i64, ptr %l63, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t83, i64 %t84)
  store %"compiler/typed:Local" %t87, ptr %l68
  br label %bb14
bb14:
  %t88 = load %"compiler/typed:Local", ptr %l68
  store %"compiler/typed:Local" %t88, ptr %l6
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/views:Viewer", ptr %t89, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t91, i64 -1)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t93 = load i64, ptr %l5, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l5, !tbaa !24
  br label %bb9
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Body", ptr %t97, i32 0, i32 5
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l75
  br label %bb18
bb18:
  %t102 = load i64, ptr %l75, !tbaa !24
  store i64 %t102, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp sgt i64 %t103, %t104
  br i1 %t107, label %bb19, label %bb20
bb19:
  %t109 = load i64, ptr %l9, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb24
bb21:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t113, %t114
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t123 = sub i64 %t121, 1
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = sdiv i64 %t123, %t124
  store i64 %t127, ptr %l82, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb23
bb23:
  %t129 = load i64, ptr %l82, !tbaa !24
  store i64 %t129, ptr %l79, !tbaa !24
  br label %bb24
bb24:
  %t130 = load i64, ptr %l79, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t131 = load i64, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = mul i64 %t140, %t141
  %t147 = add i64 %t139, %t144
  store i64 %t147, ptr %l12, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/views:Viewer", ptr %t149, i32 0, i32 26
  store ptr %t151, ptr %l101, !tbaa !29
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Body", ptr %t152, i32 0, i32 5
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t154, i64 %t155)
  store i32 %t158, ptr %l105
  br label %bb29
bb29:
  %t159 = load i32, ptr %l105, !tbaa !23
  %t160 = sext i32 %t159 to i64
  %t161 = load i64, ptr %l12, !tbaa !24
  %t162 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t160, i64 %t161)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l11, !tbaa !24
  br label %bb25
bb32:
  call void @compiler_2fviews_3astate_2ector(ptr %t169, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l110, ptr %t169, i64 136, i1 false)
  br label %bb33
bb33:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l110, i64 136, i1 false)
  %t170 = load i1, ptr %l2, !tbaa !21
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb34, label %bb35
bb34:
  store i64 0, ptr %l14, !tbaa !24
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Body", ptr %t174, i32 0, i32 5
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l115
  br label %bb36
bb35:
  br label %bb60
bb36:
  %t179 = load i64, ptr %l115, !tbaa !24
  store i64 %t179, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t180 = load i64, ptr %l15, !tbaa !24
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = icmp sgt i64 %t180, %t181
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t186 = load i64, ptr %l16, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  br i1 %t188, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb42
bb39:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t191 = load i64, ptr %l14, !tbaa !24
  %t194 = sub i64 %t190, %t191
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = add i64 %t194, %t195
  %t200 = sub i64 %t198, 1
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = sdiv i64 %t200, %t201
  store i64 %t204, ptr %l122, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb41
bb41:
  %t206 = load i64, ptr %l122, !tbaa !24
  store i64 %t206, ptr %l119, !tbaa !24
  br label %bb42
bb42:
  %t207 = load i64, ptr %l119, !tbaa !24
  store i64 %t207, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb43
bb43:
  %t208 = load i64, ptr %l18, !tbaa !24
  %t209 = load i64, ptr %l17, !tbaa !24
  %t212 = icmp slt i64 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t216 = load i64, ptr %l14, !tbaa !24
  %t217 = load i64, ptr %l18, !tbaa !24
  %t218 = load i64, ptr %l16, !tbaa !24
  %t221 = mul i64 %t217, %t218
  %t224 = add i64 %t216, %t221
  store i64 %t224, ptr %l19, !tbaa !24
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Body", ptr %t226, i32 0, i32 5
  %t229 = load i64, ptr %l19, !tbaa !24
  %t232 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t228, i64 %t229)
  store i32 %t232, ptr %l143
  br label %bb47
bb47:
  %t233 = load i32, ptr %l143, !tbaa !23
  %t234 = sext i32 %t233 to i64
  store i64 %t234, ptr %l20, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l145, !tbaa !29
  %t237 = load ptr, ptr %l3, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Body", ptr %t237, i32 0, i32 7
  %t240 = load i64, ptr %l20, !tbaa !24
  %t243 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t239, i64 %t240)
  store %"compiler/typed:Local" %t243, ptr %l149
  br label %bb48
bb48:
  %t244 = getelementptr %"compiler/typed:Local", ptr %l149, i32 0, i32 2
  %t245 = load i32, ptr %t244, !tbaa !23
  %t246 = load ptr, ptr %l145, !tbaa !29
  %t248 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t246, i32 %t245)
  store i1 %t248, ptr %l151
  br label %bb49
bb49:
  %t249 = load i1, ptr %l151, !tbaa !21
  br i1 %t249, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t250 = getelementptr %"compiler/views:state", ptr %l13, i32 0, i32 1
  store ptr %t250, ptr %l152, !tbaa !29
  %t251 = load i64, ptr %l20, !tbaa !24
  store i64 %t251, ptr %l153, !tbaa !24
  %t252 = load i64, ptr %l19, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [2 x i64] }, ptr %t253, i32 0, i32 0
  store i64 4, ptr %t254
  %t256 = insertvalue { i64 } undef, i64 %t252, 0
  %t257 = getelementptr { i64, [2 x i64] }, ptr %t253, i32 0, i32 1
  store { i64 } %t256, ptr %t257
  %t258 = load { i64, [2 x i64] }, ptr %t253
  %t260 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s11, { i64, [2 x i64] } %t258, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t260, ptr %l156
  br label %bb52
bb51:
  br label %bb57
bb52:
  %t261 = load ptr, ptr %l3, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Body", ptr %t261, i32 0, i32 7
  %t264 = load i64, ptr %l20, !tbaa !24
  %t267 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t263, i64 %t264)
  store %"compiler/typed:Local" %t267, ptr %l160
  br label %bb53
bb53:
  %t268 = getelementptr %"compiler/typed:Local", ptr %l160, i32 0, i32 1
  %t269 = getelementptr %"compiler/source:Span", ptr %t268, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t272 = sext i32 %t270 to i64
  %t273 = load %"compiler/views:place", ptr %l156
  %t275 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s11, %"compiler/views:place" %t273, i64 %t272)
  store %"compiler/views:view" %t275, ptr %l163
  br label %bb54
bb54:
  %t276 = load i64, ptr %l153, !tbaa !24
  %t277 = load %"compiler/views:view", ptr %l163
  %t278 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s11, i64 %t276, %"compiler/views:view" %t277)
  store %"compiler/views:holding" %t278, ptr %l164
  br label %bb55
bb55:
  %t279 = load ptr, ptr %l152, !tbaa !29
  %t280 = load %"compiler/views:holding", ptr %l164
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2ePush_3ccompiler_2fviews_3aholding_3e(ptr %s0, ptr %t279, %"compiler/views:holding" %t280)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t281 = load i64, ptr %l18, !tbaa !24
  %t283 = add i64 %t281, 1
  store i64 %t283, ptr %l18, !tbaa !24
  br label %bb43
bb59:
  br label %bb60
bb60:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l3, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Body", ptr %t286, i32 0, i32 11
  %t289 = load ptr, ptr %t288, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v0, ptr %s0, ptr %t285, ptr %t289, ptr %l13)
  br label %bb61
bb61:
  %t293 = load i1, ptr %l2, !tbaa !21
  br i1 %t293, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb64
bb63:
  %t295 = getelementptr %"compiler/views:state", ptr %l13, i32 0, i32 0
  %t296 = load i1, ptr %t295, !tbaa !21
  store i1 %t296, ptr %l172, !tbaa !21
  br label %bb64
bb64:
  %t298 = load i1, ptr %l172, !tbaa !21
  br i1 %t298, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  br label %bb67
bb67:
  %t299 = load ptr, ptr %l3, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Body", ptr %t299, i32 0, i32 1
  %t302 = load { i64, [2 x i64] }, ptr %t301
  %t306 = extractvalue { i64, [2 x i64] } %t302, 0
  %t307 = icmp eq i64 %t306, 1
  br i1 %t307, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb91
bb70:
  %t309 = load ptr, ptr %l3, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Body", ptr %t309, i32 0, i32 10
  store ptr %t311, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb71
bb71:
  %t313 = load i64, ptr %l23, !tbaa !24
  store i64 %t313, ptr %l180, !tbaa !24
  %t314 = load ptr, ptr %l22, !tbaa !29
  %t316 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t314)
  store i64 %t316, ptr %l182
  br label %bb72
bb72:
  %t317 = load i64, ptr %l180, !tbaa !24
  %t318 = load i64, ptr %l182, !tbaa !24
  %t319 = icmp slt i64 %t317, %t318
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb73, label %bb74
bb73:
  br label %bb90
bb74:
  br label %bb75
bb75:
  %t323 = load ptr, ptr %l22, !tbaa !29
  %t324 = load i64, ptr %l23, !tbaa !24
  %t327 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t323, i64 %t324)
  store i32 %t327, ptr %l187
  br label %bb76
bb76:
  %t328 = load i32, ptr %l187, !tbaa !23
  store i32 %t328, ptr %l24, !tbaa !23
  %t329 = getelementptr %"compiler/views:state", ptr %l13, i32 0, i32 1
  store ptr %t329, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb77
bb77:
  %t331 = load i64, ptr %l26, !tbaa !24
  store i64 %t331, ptr %l189, !tbaa !24
  %t332 = load ptr, ptr %l25, !tbaa !29
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %s0, ptr %t332)
  store i64 %t334, ptr %l191
  br label %bb78
bb78:
  %t335 = load i64, ptr %l189, !tbaa !24
  %t336 = load i64, ptr %l191, !tbaa !24
  %t337 = icmp slt i64 %t335, %t336
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb79, label %bb80
bb79:
  br label %bb88
bb80:
  br label %bb81
bb81:
  %t341 = load ptr, ptr %l25, !tbaa !29
  %t342 = load i64, ptr %l26, !tbaa !24
  %t345 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %s0, ptr %t341, i64 %t342)
  store %"compiler/views:holding" %t345, ptr %l196
  br label %bb82
bb82:
  %t346 = load %"compiler/views:holding", ptr %l196
  store %"compiler/views:holding" %t346, ptr %l27
  %t347 = getelementptr %"compiler/views:holding", ptr %l27, i32 0, i32 0
  %t348 = load i64, ptr %t347, !tbaa !24
  %t349 = load i32, ptr %l24, !tbaa !23
  %t351 = sext i32 %t349 to i64
  %t354 = icmp eq i64 %t348, %t351
  br i1 %t354, label %bb83, label %bb84
bb83:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/views:holding", ptr %l27, i32 0, i32 1
  %t358 = load %"compiler/views:view", ptr %t357
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t356, %"compiler/views:view" %t358)
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t361 = load i64, ptr %l26, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l26, !tbaa !24
  br label %bb77
bb88:
  br label %bb89
bb89:
  %t365 = load i64, ptr %l23, !tbaa !24
  %t367 = add i64 %t365, 1
  store i64 %t367, ptr %l23, !tbaa !24
  br label %bb71
bb90:
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_58304325d16d56e1_1ac2a884e74450d5)
  unreachable
bb96:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalkable(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %l10 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/typed:Local"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t24 = extractvalue { i64, [2 x i64] } %t20, 0
  %t25 = icmp eq i64 %t24, 7
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_f882b6801a6cfe65_db0a8f546b27139)
  unreachable
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 7
  store ptr %t30, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  %t32 = load i64, ptr %l5, !tbaa !24
  store i64 %t32, ptr %l22, !tbaa !24
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l24
  br label %bb15
bb15:
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t42, i64 %t43)
  store %"compiler/typed:Local" %t46, ptr %l29
  br label %bb19
bb19:
  %t47 = load %"compiler/typed:Local", ptr %l29
  store %"compiler/typed:Local" %t47, ptr %l6
  %t48 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp eq i32 %t49, %t50
  br i1 %t53, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb14
bb24:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca %"compiler/typed:Local"
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l74 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 20
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4283dbd3668d18ac_9869995bfb9a4270)
  unreachable
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/views:Viewer", ptr %t21, i32 0, i32 20
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 7
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t27, i64 %t28)
  store %"compiler/typed:Local" %t31, ptr %l23
  br label %bb7
bb7:
  %t32 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %s1, ptr %t34, i32 %t33)
  store { i64, ptr } %t36, ptr %l25
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb32
bb9:
  %t44 = load { i64, [2 x i64] }, ptr %l2
  %t46 = extractvalue { i64, [2 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t50 = getelementptr { i64 }, ptr %t49, i32 0, i32 0
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb22
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:Viewer", ptr %t54, i32 0, i32 20
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7a5a13ecbea84e9b_d0d616c1e5cf6f4f)
  unreachable
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 20
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 7
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/views:Viewer", ptr %t68, i32 0, i32 20
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7a5a13ecbea84e9b_d0d616c1e5cf6f4f)
  unreachable
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/views:Viewer", ptr %t75, i32 0, i32 20
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t78, i32 0, i32 5
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l46
  br label %bb19
bb19:
  %t86 = load i32, ptr %l46, !tbaa !23
  %t87 = sext i32 %t86 to i64
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t90 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t88, i64 %t87)
  store %"compiler/typed:Local" %t90, ptr %l48
  br label %bb20
bb20:
  %t91 = getelementptr %"compiler/typed:Local", ptr %l48, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load ptr, ptr %l30, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %s3, ptr %t93, i32 %t92)
  store { i64, ptr } %t95, ptr %l50
  br label %bb21
bb21:
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t97, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb22:
  %t103 = load { i64, [2 x i64] }, ptr %l2
  %t105 = extractvalue { i64, [2 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 3
  br i1 %t106, label %bb23, label %bb24
bb23:
  %t108 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t109 = getelementptr { i64, i32 }, ptr %t108, i32 0, i32 1
  %t110 = load i32, ptr %t109
  store i32 %t110, ptr %l5, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %s5, ptr %t112, i32 %t113)
  store { i64, ptr } %t116, ptr %l57
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t118, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l59, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t124, ptr %l10, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e23614535e762839_a3c52bd11c6a8cad)
  unreachable
bb32:
  %t126 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l61, !tbaa !24
  %t128 = load i64, ptr %l61, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l62, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t139, ptr %l6, !tbaa !27
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/views:Viewer", ptr %t140, i32 0, i32 3
  %t143 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t144 = load i64, ptr %t143, !tbaa !24
  %t147 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t142, i64 %t144)
  store { i64, ptr } %t147, ptr %l66
  br label %bb33
bb33:
  %t148 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t148, ptr %l7, !tbaa !27
  %t149 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t150 = load i64, ptr %t149, !tbaa !24
  %t152 = icmp sge i64 %t150, 0
  br i1 %t152, label %bb34, label %bb35
bb34:
  %t154 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t161 = icmp sle i64 %t155, %t158
  store i1 %t161, ptr %l69, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb36
bb36:
  %t163 = load i1, ptr %l69, !tbaa !21
  br i1 %t163, label %bb37, label %bb38
bb37:
  %t164 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l74, !tbaa !24
  br label %bb39
bb38:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l74, !tbaa !24
  br label %bb39
bb39:
  %t171 = load i64, ptr %l74, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t172, ptr %l78, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t173, ptr %l79, !tbaa !27
  store i64 %t171, ptr %l80, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  store i64 %t176, ptr %l81, !tbaa !24
  %t177 = icmp sge i64 0, 0
  br i1 %t177, label %bb40, label %bb41
bb40:
  %t179 = load i64, ptr %l80, !tbaa !24
  %t180 = icmp sle i64 0, %t179
  br i1 %t180, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173)
  unreachable
bb42:
  %t182 = load i64, ptr %l80, !tbaa !24
  %t183 = load i64, ptr %l81, !tbaa !24
  %t184 = icmp sle i64 %t182, %t183
  br i1 %t184, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173)
  unreachable
bb44:
  %t186 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = load i64, ptr %l80, !tbaa !24
  %t189 = getelementptr i8, ptr %t187, i64 0
  %t190 = sub i64 %t188, 0
  %t191 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t189, 1
  %t193 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t197 = extractvalue { i64, ptr } %t192, 1
  %t198 = extractvalue { i64, ptr } %t192, 0
  %t199 = add i64 %t195, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t194, i64 %t195)
  %t201 = getelementptr i8, ptr %t200, i64 %t195
  call void @olang_textcopy(ptr %t201, ptr %t197, i64 %t198)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t200, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t203, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/views:state"
  %l13 = alloca %"compiler/views:state"
  %t1 = alloca %"compiler/views:state", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fviews_3astate_2ector(ptr %t1, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %t1, i64 136, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 136, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l2, i64 136, i1 false)
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/views:state", ptr %t4, i32 0, i32 0
  %t7 = load i1, ptr %t6, !tbaa !21
  %t9 = load ptr, ptr %lp1
  %t10 = getelementptr %"compiler/views:state", ptr %t9, i32 0, i32 0
  store i1 %t7, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/views:state", ptr %t11, i32 0, i32 1
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t13
  %t16 = load ptr, ptr %lp1
  %t17 = getelementptr %"compiler/views:state", ptr %t16, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t17
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/views:state", ptr %t18, i32 0, i32 2
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t20
  %t23 = load ptr, ptr %lp1
  %t24 = getelementptr %"compiler/views:state", ptr %t23, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/views:state", ptr %t25, i32 0, i32 3
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t27
  %t30 = load ptr, ptr %lp1
  %t31 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %t31
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:state", ptr %t32, i32 0, i32 4
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t34
  %t37 = load ptr, ptr %lp1
  %t38 = getelementptr %"compiler/views:state", ptr %t37, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t38
  %t39 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t39, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l13, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eforget(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/views:holding"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/views:holding"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 1
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l7
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e(ptr %s0, ptr %l7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l2
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:state", ptr %t8, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eClear_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t10)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l13, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %s0, ptr %t14)
  store i64 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %s0, ptr %t23, i64 %t24)
  store %"compiler/views:holding" %t27, ptr %l20
  br label %bb8
bb8:
  %t28 = load %"compiler/views:holding", ptr %l20
  store %"compiler/views:holding" %t28, ptr %l5
  %t29 = getelementptr %"compiler/views:holding", ptr %l5, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = icmp ne i64 %t30, %t31
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/views:state", ptr %t36, i32 0, i32 1
  %t39 = load %"compiler/views:holding", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2ePush_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t38, %"compiler/views:holding" %t39)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v0, ptr %t46, i64 %t47)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/views:state", ptr %t2, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  %t8 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  store i1 %t5, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/views:state", ptr %t10, i32 0, i32 1
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l7
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %l7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l9
  br label %bb1
bb1:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = getelementptr %"compiler/views:state", ptr %t17, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t18
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/views:state", ptr %t20, i32 0, i32 2
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l12
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %l12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l14
  br label %bb2
bb2:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = getelementptr %"compiler/views:state", ptr %t27, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t28
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l15, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 3
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l17
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l19
  br label %bb3
bb3:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t37 = load ptr, ptr %l15, !tbaa !29
  %t38 = getelementptr %"compiler/views:state", ptr %t37, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %t38
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/views:state", ptr %t40, i32 0, i32 4
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l22
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %l22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l24
  br label %bb4
bb4:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t47 = load ptr, ptr %l20, !tbaa !29
  %t48 = getelementptr %"compiler/views:state", ptr %t47, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t48
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/views:naming"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/views:naming"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 2
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l11
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e(ptr %s0, ptr %l11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l2
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:state", ptr %t8, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eClear_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t10)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l17, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %s0, ptr %t14)
  store i64 %t16, ptr %l19
  br label %bb4
bb4:
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call %"compiler/views:naming" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eAt_3ccompiler_2fviews_3anaming_3e(ptr %s0, ptr %t23, i64 %t24)
  store %"compiler/views:naming" %t27, ptr %l24
  br label %bb8
bb8:
  %t28 = load %"compiler/views:naming", ptr %l24
  store %"compiler/views:naming" %t28, ptr %l5
  %t29 = getelementptr %"compiler/views:naming", ptr %l5, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = icmp ne i64 %t30, %t31
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/views:state", ptr %t36, i32 0, i32 2
  %t39 = load %"compiler/views:naming", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t38, %"compiler/views:naming" %t39)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:state", ptr %t46, i32 0, i32 3
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l34
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l34)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l36
  br label %bb15
bb15:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l6
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:state", ptr %t53, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t55)
  br label %bb16
bb16:
  store ptr %l6, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l8, !tbaa !24
  store i64 %t58, ptr %l40, !tbaa !24
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t59)
  store i64 %t61, ptr %l42
  br label %bb18
bb18:
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l42, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb19, label %bb20
bb19:
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l7, !tbaa !29
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb22
bb22:
  %t73 = load i64, ptr %l47, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = icmp ne i64 %t74, %t75
  br i1 %t78, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/views:state", ptr %t80, i32 0, i32 3
  %t83 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t82, i64 %t83)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb17
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fviews_2ecopyHint(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = icmp eq i64 %a0, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } %t5, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t25 = extractvalue { i64, ptr } %t21, 1
  %t26 = extractvalue { i64, ptr } %t21, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = getelementptr i8, ptr %t31, i64 %t23
  call void @olang_textcopy(ptr %t32, ptr %t25, i64 %t26)
  %t33 = getelementptr i8, ptr %t32, i64 %t26
  call void @olang_textcopy(ptr %t33, ptr %t28, i64 %t29)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  store { i64, ptr } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2edead(ptr %out, ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca %"compiler/views:state"
  %l2 = alloca %"compiler/views:state"
  %t1 = alloca %"compiler/views:state", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fviews_3astate_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %t1, i64 136, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 136, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load ptr, ptr %lp0
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l1, i64 136, i1 false)
  %t4 = load ptr, ptr %lp0
  %t5 = getelementptr %"compiler/views:state", ptr %t4, i32 0, i32 0
  store i1 true, ptr %t5, !tbaa !21
  %t6 = load ptr, ptr %lp0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %t6, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l2, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/source:Span", ptr %t34
  store %"compiler/source:Span" %t35, ptr %l1
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i64 @compiler_2fviews_2eplaceEnd(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l22
  br label %bb10
bb10:
  %t46 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = load i64, ptr %l22, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t50, i64 %t49)
  store i64 %t52, ptr %l25
  br label %bb11
bb11:
  %t53 = load i64, ptr %l25, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb25
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l26, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 17
  store i1 %t61, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l33
  br label %bb18
bb18:
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t73)
  store %"compiler/source:Span" %t75, ptr %l35
  br label %bb23
bb23:
  %t76 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_26ef299dad5cdbef_4a7142c0b9c90bab)
  unreachable
bb25:
  %t81 = load i64, ptr %l4, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_2eholdAdd(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:view" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/views:view"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca %"compiler/views:holding"
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca %"compiler/views:place"
  %l51 = alloca %"compiler/views:place"
  %l53 = alloca i1
  %l56 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca %"compiler/views:holding"
  %l68 = alloca ptr
  %l71 = alloca %"compiler/views:holding"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/views:view" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:state", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/views:holding" %t59, ptr %l40
  br label %bb12
bb12:
  %t60 = load %"compiler/views:holding", ptr %l40
  store %"compiler/views:holding" %t60, ptr %l9
  %t61 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t68 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t69 = getelementptr %"compiler/views:view", ptr %t68, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = icmp ne i64 %t70, %t72
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t78 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t79 = getelementptr %"compiler/views:view", ptr %t78, i32 0, i32 0
  %t80 = load %"compiler/views:place", ptr %t79
  store %"compiler/views:place" %t80, ptr %l49
  %t81 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 0
  %t82 = load %"compiler/views:place", ptr %t81
  store %"compiler/views:place" %t82, ptr %l51
  %t85 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l49, ptr %l51)
  store i1 %t85, ptr %l53
  br label %bb18
bb18:
  %t86 = load i1, ptr %l53, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb31
bb21:
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 2
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t94 = getelementptr %"compiler/views:view", ptr %t93, i32 0, i32 2
  %t95 = load i1, ptr %t94, !tbaa !21
  %t97 = xor i1 %t95, true
  store i1 %t97, ptr %l56, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l56, !tbaa !21
  br i1 %t99, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/views:state", ptr %t100, i32 0, i32 1
  store ptr %t102, ptr %l60, !tbaa !29
  %t103 = load i64, ptr %l8, !tbaa !24
  store i64 %t103, ptr %l61, !tbaa !24
  %t104 = load i64, ptr %l1, !tbaa !24
  %t105 = load %"compiler/views:view", ptr %l2
  %t108 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s4, i64 %t104, %"compiler/views:view" %t105)
  store %"compiler/views:holding" %t108, ptr %l64
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = load i64, ptr %l61, !tbaa !24
  %t111 = load %"compiler/views:holding", ptr %l64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eSetAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t109, i64 %t110, %"compiler/views:holding" %t111)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l7, !tbaa !24
  br label %bb8
bb32:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/views:state", ptr %t116, i32 0, i32 1
  store ptr %t118, ptr %l68, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  %t120 = load %"compiler/views:view", ptr %l2
  %t123 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s0, i64 %t119, %"compiler/views:view" %t120)
  store %"compiler/views:holding" %t123, ptr %l71
  br label %bb33
bb33:
  %t124 = load ptr, ptr %l68, !tbaa !29
  %t125 = load %"compiler/views:holding", ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2ePush_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t124, %"compiler/views:holding" %t125)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2emerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/views:holding"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/views:holding"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/views:naming"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/views:tasked"
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca %"compiler/views:tasked"
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca %"compiler/views:holding"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i64
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i64
  %l83 = alloca i64
  %l88 = alloca %"compiler/views:holding"
  %l95 = alloca i1
  %l99 = alloca i1
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca i64
  %l118 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i64
  %l124 = alloca %"compiler/views:place"
  %l129 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i64
  %l135 = alloca %"compiler/views:place"
  %l138 = alloca i64
  %l140 = alloca i64
  %l145 = alloca %"compiler/views:naming"
  %l158 = alloca i1
  %l167 = alloca i64
  %l169 = alloca i64
  %l174 = alloca %"compiler/views:tasked"
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca %"compiler/views:tasked"
  %l188 = alloca i1
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/source:Span"
  %l193 = alloca i1
  %l194 = alloca i1
  %l195 = alloca %"compiler/views:place"
  %l197 = alloca %"compiler/views:place"
  %l199 = alloca i1
  %s0 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t178 = alloca { i64, [2 x i64] }, align 8
  %t204 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/views:state", ptr %t6, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/views:state", ptr %t15, i32 0, i32 1
  store ptr %t17, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l41, !tbaa !24
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t20)
  store i64 %t22, ptr %l43
  br label %bb9
bb9:
  %t23 = load i64, ptr %l41, !tbaa !24
  %t24 = load i64, ptr %l43, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t29, i64 %t30)
  store %"compiler/views:holding" %t33, ptr %l48
  br label %bb13
bb13:
  %t34 = load %"compiler/views:holding", ptr %l48
  store %"compiler/views:holding" %t34, ptr %l4
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/views:holding", ptr %l4, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = getelementptr %"compiler/views:holding", ptr %l4, i32 0, i32 1
  %t39 = load %"compiler/views:view", ptr %t38
  call void @compiler_2fviews_2eholdAdd(ptr %v0, ptr %t35, i64 %t37, %"compiler/views:view" %t39)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb8
bb16:
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l54
  br label %bb17
bb17:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l5
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/views:state", ptr %t49, i32 0, i32 3
  store ptr %t51, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l57, !tbaa !24
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t54)
  store i64 %t56, ptr %l59
  br label %bb19
bb19:
  %t57 = load i64, ptr %l57, !tbaa !24
  %t58 = load i64, ptr %l59, !tbaa !24
  %t59 = icmp slt i64 %t57, %t58
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t63 = load ptr, ptr %l6, !tbaa !29
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l64
  br label %bb23
bb23:
  %t68 = load i64, ptr %l64, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t68)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l7, !tbaa !24
  br label %bb18
bb26:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/views:state", ptr %t76, i32 0, i32 3
  store ptr %t78, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t80 = load i64, ptr %l10, !tbaa !24
  store i64 %t80, ptr %l71, !tbaa !24
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l73
  br label %bb28
bb28:
  %t84 = load i64, ptr %l71, !tbaa !24
  %t85 = load i64, ptr %l73, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb29, label %bb30
bb29:
  br label %bb53
bb30:
  br label %bb31
bb31:
  %t90 = load ptr, ptr %l9, !tbaa !29
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l78
  br label %bb32
bb32:
  %t95 = load i64, ptr %l78, !tbaa !24
  store i64 %t95, ptr %l11, !tbaa !24
  store i1 false, ptr %l12, !tbaa !21
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/views:state", ptr %t96, i32 0, i32 1
  store ptr %t98, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t100 = load i64, ptr %l14, !tbaa !24
  store i64 %t100, ptr %l81, !tbaa !24
  %t101 = load ptr, ptr %l13, !tbaa !29
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t101)
  store i64 %t103, ptr %l83
  br label %bb34
bb34:
  %t104 = load i64, ptr %l81, !tbaa !24
  %t105 = load i64, ptr %l83, !tbaa !24
  %t106 = icmp slt i64 %t104, %t105
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t110 = load ptr, ptr %l13, !tbaa !29
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t110, i64 %t111)
  store %"compiler/views:holding" %t114, ptr %l88
  br label %bb38
bb38:
  %t115 = load %"compiler/views:holding", ptr %l88
  store %"compiler/views:holding" %t115, ptr %l15
  %t116 = getelementptr %"compiler/views:holding", ptr %l15, i32 0, i32 0
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t123 = load i64, ptr %l14, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l14, !tbaa !24
  br label %bb33
bb43:
  %t127 = load i1, ptr %l12, !tbaa !21
  br i1 %t127, label %bb44, label %bb45
bb44:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t134 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l5, i64 %t129)
  store i1 %t134, ptr %l99
  br label %bb46
bb45:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb47
bb46:
  %t135 = load i1, ptr %l99, !tbaa !21
  %t136 = xor i1 %t135, true
  store i1 %t136, ptr %l95, !tbaa !21
  br label %bb47
bb47:
  %t138 = load i1, ptr %l95, !tbaa !21
  br i1 %t138, label %bb48, label %bb49
bb48:
  %t139 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t139)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l10, !tbaa !24
  br label %bb27
bb53:
  store ptr %l5, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb54
bb54:
  %t147 = load i64, ptr %l18, !tbaa !24
  store i64 %t147, ptr %l106, !tbaa !24
  %t148 = load ptr, ptr %l17, !tbaa !29
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t148)
  store i64 %t150, ptr %l108
  br label %bb55
bb55:
  %t151 = load i64, ptr %l106, !tbaa !24
  %t152 = load i64, ptr %l108, !tbaa !24
  %t153 = icmp slt i64 %t151, %t152
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb56, label %bb57
bb56:
  br label %bb90
bb57:
  br label %bb58
bb58:
  %t157 = load ptr, ptr %l17, !tbaa !29
  %t158 = load i64, ptr %l18, !tbaa !24
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t157, i64 %t158)
  store i64 %t161, ptr %l113
  br label %bb59
bb59:
  %t162 = load i64, ptr %l113, !tbaa !24
  store i64 %t162, ptr %l19, !tbaa !24
  %t163 = load i64, ptr %l19, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/views:state", ptr %t165, i32 0, i32 3
  %t171 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t167, i64 %t163)
  store i1 %t171, ptr %l118
  br label %bb60
bb60:
  %t172 = load i1, ptr %l118, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s19
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l120, !tbaa !29
  %t176 = load i64, ptr %l19, !tbaa !24
  store i64 %t176, ptr %l121, !tbaa !24
  %t177 = load i64, ptr %l19, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 1, ptr %t179
  %t181 = insertvalue { i64 } undef, i64 %t177, 0
  %t182 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  store { i64 } %t181, ptr %t182
  %t183 = load { i64, [2 x i64] }, ptr %t178
  %t185 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s19, { i64, [2 x i64] } %t183, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t185, ptr %l124
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t186 = load ptr, ptr %l120, !tbaa !29
  %t187 = load i64, ptr %l121, !tbaa !24
  %t188 = load %"compiler/views:place", ptr %l124
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t186, i64 %t187, %"compiler/views:place" %t188)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s19)
  br label %bb65
bb65:
  %t189 = load i64, ptr %l19, !tbaa !24
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr %"compiler/views:state", ptr %t191, i32 0, i32 3
  %t197 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t193, i64 %t189)
  store i1 %t197, ptr %l129
  br label %bb66
bb66:
  %t198 = load i1, ptr %l129, !tbaa !21
  %t199 = xor i1 %t198, true
  br i1 %t199, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s20
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l131, !tbaa !29
  %t202 = load i64, ptr %l19, !tbaa !24
  store i64 %t202, ptr %l132, !tbaa !24
  %t203 = load i64, ptr %l19, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [2 x i64] }, ptr %t204, i32 0, i32 0
  store i64 1, ptr %t205
  %t207 = insertvalue { i64 } undef, i64 %t203, 0
  %t208 = getelementptr { i64, [2 x i64] }, ptr %t204, i32 0, i32 1
  store { i64 } %t207, ptr %t208
  %t209 = load { i64, [2 x i64] }, ptr %t204
  %t211 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s20, { i64, [2 x i64] } %t209, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t211, ptr %l135
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t212 = load ptr, ptr %l131, !tbaa !29
  %t213 = load i64, ptr %l132, !tbaa !24
  %t214 = load %"compiler/views:place", ptr %l135
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t212, i64 %t213, %"compiler/views:place" %t214)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s20)
  br label %bb71
bb71:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/views:state", ptr %t215, i32 0, i32 2
  store ptr %t217, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb72
bb72:
  %t219 = load i64, ptr %l23, !tbaa !24
  store i64 %t219, ptr %l138, !tbaa !24
  %t220 = load ptr, ptr %l22, !tbaa !29
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v1, ptr %t220)
  store i64 %t222, ptr %l140
  br label %bb73
bb73:
  %t223 = load i64, ptr %l138, !tbaa !24
  %t224 = load i64, ptr %l140, !tbaa !24
  %t225 = icmp slt i64 %t223, %t224
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb74, label %bb75
bb74:
  br label %bb83
bb75:
  br label %bb76
bb76:
  %t229 = load ptr, ptr %l22, !tbaa !29
  %t230 = load i64, ptr %l23, !tbaa !24
  %t233 = call %"compiler/views:naming" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eAt_3ccompiler_2fviews_3anaming_3e(ptr %v1, ptr %t229, i64 %t230)
  store %"compiler/views:naming" %t233, ptr %l145
  br label %bb77
bb77:
  %t234 = load %"compiler/views:naming", ptr %l145
  store %"compiler/views:naming" %t234, ptr %l24
  %t235 = getelementptr %"compiler/views:naming", ptr %l24, i32 0, i32 0
  %t236 = load i64, ptr %t235, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = icmp eq i64 %t236, %t237
  br i1 %t240, label %bb78, label %bb79
bb78:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i64, ptr %l19, !tbaa !24
  %t244 = getelementptr %"compiler/views:naming", ptr %l24, i32 0, i32 1
  %t245 = load %"compiler/views:place", ptr %t244
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t242, i64 %t243, %"compiler/views:place" %t245)
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t249 = load i64, ptr %l23, !tbaa !24
  %t251 = add i64 %t249, 1
  store i64 %t251, ptr %l23, !tbaa !24
  br label %bb72
bb83:
  %t253 = load i64, ptr %l19, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/views:state", ptr %t255, i32 0, i32 3
  %t261 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t257, i64 %t253)
  store i1 %t261, ptr %l158
  br label %bb84
bb84:
  %t262 = load i1, ptr %l158, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb85, label %bb86
bb85:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/views:state", ptr %t265, i32 0, i32 3
  %t268 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t267, i64 %t268)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t271 = load i64, ptr %l18, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l18, !tbaa !24
  br label %bb54
bb90:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr %"compiler/views:state", ptr %t275, i32 0, i32 4
  store ptr %t277, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb91
bb91:
  %t279 = load i64, ptr %l27, !tbaa !24
  store i64 %t279, ptr %l167, !tbaa !24
  %t280 = load ptr, ptr %l26, !tbaa !29
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v1, ptr %t280)
  store i64 %t282, ptr %l169
  br label %bb92
bb92:
  %t283 = load i64, ptr %l167, !tbaa !24
  %t284 = load i64, ptr %l169, !tbaa !24
  %t285 = icmp slt i64 %t283, %t284
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb93, label %bb94
bb93:
  br label %bb121
bb94:
  br label %bb95
bb95:
  %t289 = load ptr, ptr %l26, !tbaa !29
  %t290 = load i64, ptr %l27, !tbaa !24
  %t293 = call %"compiler/views:tasked" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eAt_3ccompiler_2fviews_3atasked_3e(ptr %v1, ptr %t289, i64 %t290)
  store %"compiler/views:tasked" %t293, ptr %l174
  br label %bb96
bb96:
  %t294 = load %"compiler/views:tasked", ptr %l174
  store %"compiler/views:tasked" %t294, ptr %l28
  store i1 false, ptr %l29, !tbaa !21
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/views:state", ptr %t295, i32 0, i32 4
  store ptr %t297, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb97
bb97:
  %t299 = load i64, ptr %l31, !tbaa !24
  store i64 %t299, ptr %l177, !tbaa !24
  %t300 = load ptr, ptr %l30, !tbaa !29
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t300)
  store i64 %t302, ptr %l179
  br label %bb98
bb98:
  %t303 = load i64, ptr %l177, !tbaa !24
  %t304 = load i64, ptr %l179, !tbaa !24
  %t305 = icmp slt i64 %t303, %t304
  %t307 = xor i1 %t305, true
  br i1 %t307, label %bb99, label %bb100
bb99:
  br label %bb115
bb100:
  br label %bb101
bb101:
  %t309 = load ptr, ptr %l30, !tbaa !29
  %t310 = load i64, ptr %l31, !tbaa !24
  %t313 = call %"compiler/views:tasked" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eAt_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t309, i64 %t310)
  store %"compiler/views:tasked" %t313, ptr %l184
  br label %bb102
bb102:
  %t314 = load %"compiler/views:tasked", ptr %l184
  store %"compiler/views:tasked" %t314, ptr %l32
  %t315 = getelementptr %"compiler/views:tasked", ptr %l32, i32 0, i32 0
  %t316 = getelementptr %"compiler/views:view", ptr %t315, i32 0, i32 1
  %t317 = load i64, ptr %t316, !tbaa !24
  %t318 = getelementptr %"compiler/views:tasked", ptr %l28, i32 0, i32 0
  %t319 = getelementptr %"compiler/views:view", ptr %t318, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  %t323 = icmp eq i64 %t317, %t320
  br i1 %t323, label %bb103, label %bb104
bb103:
  %t325 = getelementptr %"compiler/views:tasked", ptr %l32, i32 0, i32 1
  %t326 = load %"compiler/source:Span", ptr %t325
  store %"compiler/source:Span" %t326, ptr %l189
  %t327 = getelementptr %"compiler/views:tasked", ptr %l28, i32 0, i32 1
  %t328 = load %"compiler/source:Span", ptr %t327
  store %"compiler/source:Span" %t328, ptr %l191
  %t331 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l189, ptr %l191)
  store i1 %t331, ptr %l193
  br label %bb105
bb104:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb106
bb105:
  %t332 = load i1, ptr %l193, !tbaa !21
  store i1 %t332, ptr %l188, !tbaa !21
  br label %bb106
bb106:
  %t333 = load i1, ptr %l188, !tbaa !21
  br i1 %t333, label %bb107, label %bb108
bb107:
  %t334 = getelementptr %"compiler/views:tasked", ptr %l32, i32 0, i32 0
  %t335 = getelementptr %"compiler/views:view", ptr %t334, i32 0, i32 0
  %t336 = load %"compiler/views:place", ptr %t335
  store %"compiler/views:place" %t336, ptr %l195
  %t337 = getelementptr %"compiler/views:tasked", ptr %l28, i32 0, i32 0
  %t338 = getelementptr %"compiler/views:view", ptr %t337, i32 0, i32 0
  %t339 = load %"compiler/views:place", ptr %t338
  store %"compiler/views:place" %t339, ptr %l197
  %t342 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l195, ptr %l197)
  store i1 %t342, ptr %l199
  br label %bb109
bb108:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb110
bb109:
  %t343 = load i1, ptr %l199, !tbaa !21
  store i1 %t343, ptr %l194, !tbaa !21
  br label %bb110
bb110:
  %t344 = load i1, ptr %l194, !tbaa !21
  br i1 %t344, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb113
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t345 = load i64, ptr %l31, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l31, !tbaa !24
  br label %bb97
bb115:
  %t349 = load i1, ptr %l29, !tbaa !21
  %t351 = xor i1 %t349, true
  br i1 %t351, label %bb116, label %bb117
bb116:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/views:state", ptr %t353, i32 0, i32 4
  %t356 = load %"compiler/views:tasked", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t355, %"compiler/views:tasked" %t356)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t359 = load i64, ptr %l27, !tbaa !24
  %t361 = add i64 %t359, 1
  store i64 %t361, ptr %l27, !tbaa !24
  br label %bb91
bb121:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2enameAdd(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:place" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/views:place"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/views:naming"
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"compiler/views:naming"
  %l19 = alloca i1
  %l20 = alloca %"compiler/views:place"
  %l22 = alloca %"compiler/views:place"
  %l24 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca %"compiler/views:naming"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/views:place" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call %"compiler/views:naming" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eAt_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/views:naming" %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load %"compiler/views:naming", ptr %l15
  store %"compiler/views:naming" %t20, ptr %l5
  %t21 = getelementptr %"compiler/views:naming", ptr %l5, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = getelementptr %"compiler/views:naming", ptr %l5, i32 0, i32 1
  %t29 = load %"compiler/views:place", ptr %t28
  store %"compiler/views:place" %t29, ptr %l20
  %t30 = load %"compiler/views:place", ptr %l2
  store %"compiler/views:place" %t30, ptr %l22
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l20, ptr %l22)
  store i1 %t33, ptr %l24
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t34 = load i1, ptr %l24, !tbaa !21
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb1
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/views:state", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l28, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load %"compiler/views:place", ptr %l2
  %t47 = call %"compiler/views:naming" @compiler_2fviews_3anaming_2ector(ptr %s0, i64 %t43, %"compiler/views:place" %t44)
  store %"compiler/views:naming" %t47, ptr %l31
  br label %bb16
bb16:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = load %"compiler/views:naming", ptr %l31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t48, %"compiler/views:naming" %t49)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2eplaceAdd(ptr %v0, ptr %a0, %"compiler/views:place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/views:place"
  %l14 = alloca %"compiler/views:place"
  %l16 = alloca %"compiler/views:place"
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/views:place" %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load %"compiler/views:place", ptr %l13
  store %"compiler/views:place" %t18, ptr %l14
  %t20 = load %"compiler/views:place", ptr %l1
  store %"compiler/views:place" %t20, ptr %l16
  %t23 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l14, ptr %l16)
  store i1 %t23, ptr %l18
  br label %bb7
bb7:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l3, !tbaa !24
  br label %bb1
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load %"compiler/views:place", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t29, %"compiler/views:place" %t30)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eplaceEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i64
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l11
  br label %bb6
bb6:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb20
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb13
bb13:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb18
bb18:
  %t42 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f3a6d7e7b6ee655_a5694061fe6eb811)
  unreachable
bb20:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cc40afa1f47574c5_1b87777640286ce9)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2etaskCopy(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = icmp eq i64 %a0, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } %t5, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t25 = extractvalue { i64, ptr } %t21, 1
  %t26 = extractvalue { i64, ptr } %t21, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = getelementptr i8, ptr %t31, i64 %t23
  call void @olang_textcopy(ptr %t32, ptr %t25, i64 %t26)
  %t33 = getelementptr i8, ptr %t32, i64 %t26
  call void @olang_textcopy(ptr %t33, ptr %t28, i64 %t29)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  store { i64, ptr } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fviews_2eunAway(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  store i64 16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb23
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l7, !tbaa !24
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 17
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l8, !tbaa !29
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t64 = load ptr, ptr %l8, !tbaa !29
  store ptr %t64, ptr %l1, !tbaa !29
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c6dbc1b994c66c62_e0c1acfc7721040e)
  unreachable
bb21:
  br label %bb22
bb22:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l6, !tbaa !24
  br label %bb7
bb23:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fviews_2eviewAdd(ptr %v0, ptr %a0, %"compiler/views:view" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:view"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:view"
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca %"compiler/views:view"
  %l41 = alloca i1
  %l42 = alloca %"compiler/views:place"
  %l44 = alloca %"compiler/views:place"
  %l46 = alloca i1
  %l49 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/views:view" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i64, ptr %l10, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb28
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = call %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/views:view" %t55, ptr %l37
  br label %bb12
bb12:
  %t56 = load %"compiler/views:view", ptr %l37
  store %"compiler/views:view" %t56, ptr %l8
  %t57 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = icmp ne i64 %t58, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb16
bb14:
  %t65 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 0
  %t66 = load %"compiler/views:place", ptr %t65
  store %"compiler/views:place" %t66, ptr %l42
  %t67 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 0
  %t68 = load %"compiler/views:place", ptr %t67
  store %"compiler/views:place" %t68, ptr %l44
  %t71 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l42, ptr %l44)
  store i1 %t71, ptr %l46
  br label %bb15
bb15:
  %t72 = load i1, ptr %l46, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l41, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t76 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 2
  %t80 = load i1, ptr %t79, !tbaa !21
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l49, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load %"compiler/views:view", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eSetAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t85, i64 %t86, %"compiler/views:view" %t87)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %ret
bb27:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb8
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/views:view", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ePush_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t95, %"compiler/views:view" %t96)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eweight(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/views:holding"
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca %"compiler/views:holding"
  %l31 = alloca i64
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 4
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = add i64 1, %t12
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:state", ptr %t14, i32 0, i32 2
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = mul i64 2, %t19
  %t21 = load i64, ptr %l11, !tbaa !24
  %t23 = add i64 %t21, %t20
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/views:state", ptr %t24, i32 0, i32 3
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load i64, ptr %l16, !tbaa !24
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = add i64 %t29, %t30
  store i64 %t31, ptr %l1, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/views:state", ptr %t33, i32 0, i32 1
  store ptr %t35, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l25
  br label %bb8
bb8:
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t47, i64 %t48)
  store %"compiler/views:holding" %t51, ptr %l30
  br label %bb12
bb12:
  %t52 = load %"compiler/views:holding", ptr %l30
  store %"compiler/views:holding" %t52, ptr %l4
  %t53 = load i64, ptr %l1, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = getelementptr %"compiler/views:holding", ptr %l4, i32 0, i32 1
  %t55 = getelementptr %"compiler/views:view", ptr %t54, i32 0, i32 2
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  store i64 5, ptr %l33, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb15
bb15:
  %t58 = load i64, ptr %l33, !tbaa !24
  %t59 = add i64 3, %t58
  %t60 = load i64, ptr %l31, !tbaa !24
  %t62 = add i64 %t60, %t59
  store i64 %t62, ptr %l1, !tbaa !24
  br label %bb16
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l3, !tbaa !24
  br label %bb7
bb17:
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l55 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l57 = alloca %"compiler/views:Viewer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l36
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l37
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l38
  br label %bb3
bb3:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l6
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l39
  br label %bb4
bb4:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %l7
  %t13 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t13, ptr %l40
  br label %bb5
bb5:
  %t14 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t14, ptr %l8
  store i64 -1, ptr %l9, !tbaa !24
  store i64 -1, ptr %l10, !tbaa !24
  %t15 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t15, ptr %l41
  br label %bb6
bb6:
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l11
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l42
  br label %bb7
bb7:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l12
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l43
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l44
  br label %bb9
bb9:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l14
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l45
  br label %bb10
bb10:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l15
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l46
  br label %bb11
bb11:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l16
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l47
  br label %bb12
bb12:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l17
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l48
  br label %bb13
bb13:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l18
  store i64 0, ptr %l19, !tbaa !24
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l49
  br label %bb14
bb14:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l20
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l50
  br label %bb15
bb15:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l21
  store ptr null, ptr %l22, !tbaa !29
  store i64 -1, ptr %l23, !tbaa !24
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i1 false, ptr %l26, !tbaa !21
  store i1 false, ptr %l27, !tbaa !21
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l51
  br label %bb16
bb16:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l28
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l52
  br label %bb17
bb17:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l29
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l53
  br label %bb18
bb18:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l30
  %t41 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %l54
  br label %bb19
bb19:
  %t42 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l54
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %l31
  %t43 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %l55
  br label %bb20
bb20:
  %t44 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l55
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %l32
  %t45 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t45, ptr %l56
  br label %bb21
bb21:
  %t46 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l56
  %t47 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 0
  %t48 = load ptr, ptr %l2, !tbaa !29
  store ptr %t48, ptr %t47, !tbaa !29
  %t49 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 1
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 2
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 3
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t53
  %t55 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 4
  %t56 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t56, ptr %t55
  %t57 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 5
  %t58 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t58, ptr %t57
  %t59 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 6
  %t60 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t60, ptr %t59
  %t61 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 7
  %t62 = load i64, ptr %l9, !tbaa !24
  store i64 %t62, ptr %t61, !tbaa !24
  %t63 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 8
  %t64 = load i64, ptr %l10, !tbaa !24
  store i64 %t64, ptr %t63, !tbaa !24
  %t65 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 9
  %t66 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t66, ptr %t65
  %t67 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 10
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t67
  %t69 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 11
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t69
  %t71 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 12
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t71
  %t73 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 13
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t73
  %t75 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 14
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %t75
  %t77 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 15
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t77
  %t79 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 16
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t79
  %t81 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 17
  %t82 = load i64, ptr %l19, !tbaa !24
  store i64 %t82, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 18
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t83
  %t85 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 19
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t85
  %t87 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 20
  %t88 = load ptr, ptr %l22, !tbaa !29
  store ptr %t88, ptr %t87, !tbaa !29
  %t89 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 21
  %t90 = load i64, ptr %l23, !tbaa !24
  store i64 %t90, ptr %t89, !tbaa !24
  %t91 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 22
  %t92 = load i1, ptr %l24, !tbaa !21
  store i1 %t92, ptr %t91, !tbaa !21
  %t93 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 23
  %t94 = load i1, ptr %l25, !tbaa !21
  store i1 %t94, ptr %t93, !tbaa !21
  %t95 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 24
  %t96 = load i1, ptr %l26, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 25
  %t98 = load i1, ptr %l27, !tbaa !21
  store i1 %t98, ptr %t97, !tbaa !21
  %t99 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 26
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t99
  %t101 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 27
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %t101
  %t103 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 28
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t103
  %t105 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 29
  %t106 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t106, ptr %t105
  %t107 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 30
  %t108 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t108, ptr %t107
  %t109 = getelementptr %"compiler/views:Viewer", ptr %l57, i32 0, i32 31
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t46, ptr %t109
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l57, i64 1040, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5, i64 %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %rv = alloca %"compiler/views:fact"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/views:fact" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/views:fact" %t18, i64 %a1, 1
  %t22 = insertvalue %"compiler/views:fact" %t20, i32 %a2, 2
  %t24 = insertvalue %"compiler/views:fact" %t22, i64 %a3, 3
  %t26 = insertvalue %"compiler/views:fact" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/views:fact" %t26, i1 %a5, 5
  %t30 = insertvalue %"compiler/views:fact" %t28, i64 %a6, 6
  %t32 = insertvalue %"compiler/views:fact" %t30, %"compiler/source:Span" %a7, 7
  %t34 = insertvalue %"compiler/views:fact" %t32, i64 -1, 8
  store %"compiler/views:fact" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:fact", ptr %rv
  ret %"compiler/views:fact" %rr
}

define dso_local %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %v0, i64 %a0, %"compiler/views:view" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:holding"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:holding" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/views:holding" %t6, %"compiler/views:view" %a1, 1
  store %"compiler/views:holding" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:holding", ptr %rv
  ret %"compiler/views:holding" %rr
}

define dso_local %"compiler/views:loopFrame" @compiler_2fviews_3aloopFrame_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/views:loopFrame"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l1, !tbaa !23
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = insertvalue %"compiler/views:loopFrame" undef, i32 %t7, 0
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t10 = insertvalue %"compiler/views:loopFrame" %t8, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, 1
  %t12 = insertvalue %"compiler/views:loopFrame" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, 2
  store %"compiler/views:loopFrame" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:loopFrame", ptr %rv
  ret %"compiler/views:loopFrame" %rr
}

define dso_local %"compiler/views:naming" @compiler_2fviews_3anaming_2ector(ptr %v0, i64 %a0, %"compiler/views:place" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:naming"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:naming" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/views:naming" %t6, %"compiler/views:place" %a1, 1
  store %"compiler/views:naming" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:naming", ptr %rv
  ret %"compiler/views:naming" %rr
}

define dso_local %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %v0, { i64, [2 x i64] } %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/views:place"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/views:place" undef, { i64, [2 x i64] } %a0, 0
  %t12 = insertvalue %"compiler/views:place" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/views:place" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/views:place" %t14, i1 %a3, 3
  store %"compiler/views:place" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:place", ptr %rv
  ret %"compiler/views:place" %rr
}

define dso_local void @compiler_2fviews_3astate_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"compiler/views:state"
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l0, !tbaa !21
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l7
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t9 = getelementptr %"compiler/views:state", ptr %l9, i32 0, i32 0
  %t10 = load i1, ptr %l0, !tbaa !21
  store i1 %t10, ptr %t9, !tbaa !21
  %t11 = getelementptr %"compiler/views:state", ptr %l9, i32 0, i32 1
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t11
  %t13 = getelementptr %"compiler/views:state", ptr %l9, i32 0, i32 2
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t13
  %t15 = getelementptr %"compiler/views:state", ptr %l9, i32 0, i32 3
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t15
  %t17 = getelementptr %"compiler/views:state", ptr %l9, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t17
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l9, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_3asummary_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"compiler/views:summary"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l7
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t9 = getelementptr %"compiler/views:summary", ptr %l9, i32 0, i32 0
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t9
  %t11 = getelementptr %"compiler/views:summary", ptr %l9, i32 0, i32 1
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t11
  %t13 = getelementptr %"compiler/views:summary", ptr %l9, i32 0, i32 2
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t13
  %t15 = getelementptr %"compiler/views:summary", ptr %l9, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t15
  %t17 = getelementptr %"compiler/views:summary", ptr %l9, i32 0, i32 4
  store i1 false, ptr %t17, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l9, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/views:tasked" @compiler_2fviews_3atasked_2ector(ptr %v0, %"compiler/views:view" %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:tasked"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:tasked" undef, %"compiler/views:view" %a0, 0
  %t8 = insertvalue %"compiler/views:tasked" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/views:tasked" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:tasked", ptr %rv
  ret %"compiler/views:tasked" %rr
}

define dso_local %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %v0, %"compiler/views:place" %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"compiler/views:place"
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/views:view"
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/views:place" %a0, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t6, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  store i64 -1, ptr %l7, !tbaa !24
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load %"compiler/source:Span", ptr %l13
  %t9 = load %"compiler/views:place", ptr %l2
  %t10 = insertvalue %"compiler/views:view" undef, %"compiler/views:place" %t9, 0
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = insertvalue %"compiler/views:view" %t10, i64 %t11, 1
  %t13 = load i1, ptr %l4, !tbaa !21
  %t14 = insertvalue %"compiler/views:view" %t12, i1 %t13, 2
  %t15 = load %"compiler/source:Span", ptr %l5
  %t16 = insertvalue %"compiler/views:view" %t14, %"compiler/source:Span" %t15, 3
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = insertvalue %"compiler/views:view" %t16, i64 %t17, 4
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = insertvalue %"compiler/views:view" %t18, i64 %t19, 5
  %t22 = insertvalue %"compiler/views:view" %t20, %"compiler/source:Span" %t8, 6
  %t24 = insertvalue %"compiler/views:view" %t22, i64 0, 7
  store %"compiler/views:view" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:view", ptr %rv
  ret %"compiler/views:view" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d1 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/vec" }>, align 8
@.d2 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/map" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_ert_req_clear()
@.d4 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'Push'" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Vec" }>, align 8
@.d7 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/vec" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Map" }>, align 8
@.d10 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/map" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ents" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 104
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 104
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fviews_3astate(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/views:state"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 136, i1 false)
  %t2 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 1
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 3
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 4
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/views:state", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

declare i64 @__olang_fmt_i64(ptr, i64)
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 5}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 5}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 i64 4, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  %t68 = icmp eq i32 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d17 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a call through a function value" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d20 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a lambda" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 112
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 112
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 56
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 112
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 112
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d22 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"copy the value first ('" }>, align 8
@.d23 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c".Get(k)')" }>, align 8
@.d24 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"copy the elements first ('" }>, align 8
@.d25 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c".ToArray()')" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/views:place", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/views:place", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:place", ptr %t9, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/views:place", ptr %t12, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp eq i64 %t11, %t14
  br i1 %t17, label %bb4, label %bb1
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/views:place", ptr %t19, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/views:place", ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = icmp eq i64 %t21, %t24
  br i1 %t27, label %bb5, label %bb1
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:place", ptr %t29, i32 0, i32 3
  %t31 = load i1, ptr %t30, !tbaa !21
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/views:place", ptr %t32, i32 0, i32 3
  %t34 = load i1, ptr %t33, !tbaa !21
  %t37 = icmp eq i1 %t31, %t34
  br i1 %t37, label %bb6, label %bb1
bb6:
  br label %bb7
bb7:
  %t39 = load i1, ptr %l2, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a copy of the value: '" }>, align 8
@.d27 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".Get(k)'" }>, align 8
@.d28 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"a copy: '" }>, align 8
@.d29 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".ToArray()'" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_loc_a5e6daec8976db0_405389cf00db76ac = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3cbb6fb3b51c25bd_1e9ab5921d6290d1 = external constant [0 x i8]
@olang_loc_87083398c1f96e8c_18c50ee403fa2840 = external constant [0 x i8]
@olang_loc_b5f5b909b97f4b87_db04b2c3237782bb = external constant [0 x i8]
@olang_loc_8469b5ec09caec26_9b966bbb099df63a = external constant [0 x i8]
@olang_loc_f21fc7c42b27f081_20ede69b6f10d945 = external constant [0 x i8]
@olang_loc_293c6ab0a5c406c2_e9cd55f098635cb6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_93419e5e985e4e42_624fc7044d7cab1e = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H23bbaa5fdc623cf1e33b32cb6290302c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_H7470b4df369a56161d16f5548d1940b6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_55308b3b5a1f5c1_cb52dc999ec87de5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0)
declare %"compiler/views:place" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_bb5d94b92cb03aee_965554ec574ba44a = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0)
declare %"compiler/views:holding" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eSetAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:holding" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_7ef79401c16fe1d4_255ec247f03840e8 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f2a9606e62f672e3_f02fc5d7c09a9e07 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0)
declare %"compiler/views:view" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f4d9265444485b3d_7f3b362071bb80f9 = external constant [0 x i8]
@olang_loc_3e3606e9c916d325_999483638397109 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1bacef8f79fa259f_b65daa57821eac43 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_b34deef82c4dbb1e_7a61043bb66e64c2 = external constant [0 x i8]
@olang_loc_f56dc5f524947092_cf97541144f04b56 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hcddb8d7004bc9cdff185b89d31641a08(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H5cdbeb94ae0c6e2e33fc44df03720816(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eLen_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0)
declare %"compiler/views:fact" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2eAt_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, %"compiler/views:place" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H7aeac163056dab12c3a06ffd3ff9511b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_d33365757296ff0a_65568c4e441bc04e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_38f43db71f48b164_beb7f8d1a31792c8 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_66a9fc2455c15d42_1dde5b0b0f74f18e = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_57534b0b4c840b9f_734207cf536b370b = external constant [0 x i8]
@olang_loc_eef44a73fed7a11e_ba98d4574b3cccca = external constant [0 x i8]
@olang_loc_bd4e25d0ba8f3355_5d1878e7bdcf6d61 = external constant [0 x i8]
@olang_loc_a471d4cd6a39e3a7_bf796cf0b70bcd93 = external constant [0 x i8]
@olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8 = external constant [0 x i8]
@olang_loc_59f7caf9a8021923_a477b9c5c640d35f = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0, %"compiler/views:fact" %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hbdff57143197d3e3ce33a3087c05f7a0(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Ha157aa9bcf12f5157b10d592e947e165(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H161a24899859b830aba89891233cbfd1(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hd7428d759783ef3a1a99ea96b3969ebe(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H8f04a3ce395cf5423055a0e50fbad86f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H97e3fe71a2054fda18da5260a3d71aea(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_617a65436beb56f7_865c97eda452f2a3 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0)
declare %"compiler/views:tasked" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eAt_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_c0119a910aee1fe3_5ce99f5c7dc6e127 = external constant [0 x i8]
@olang_loc_a9709b8d7599af1c_938b49c1f1943728 = external constant [0 x i8]
@olang_loc_5a02dfa0eab0974d_8c564576f095f5f9 = external constant [0 x i8]
@olang_loc_d83b4460c5b9ac6f_e5ae66818951545b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H473e76678ba49e15aac3621516ab9c7a(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H1e03e4f3e9fd2c184a7d157dcdc4524e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H778376aca07487ba188a916552f34a0e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eLen_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2eAt_3ccompiler_2fviews_3astate_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__H2424d6cf963333801588b77238bf827f(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2d854533e388acf3_9bd384635a298ef = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2a4a8b72a379b770_7cdc66c7220ef344 = external constant [0 x i8]
@olang_loc_b373ce5e6fb0acb1_b981b0fdcb20f7cd = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0)
declare %"compiler/views:naming" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eAt_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_dcfb2f8bfac0bc7f_4146aca391677efb = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7b1b67136b76c79_188c2ea4ec84d8a5 = external constant [0 x i8]
@olang_loc_26b1312863f2c2c7_c8d66606dd24933b = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_52eb4a404ee8e2f2_daf885f9c5247eae = external constant [0 x i8]
@olang_loc_24f4045ab8cbf215_2ef83d27164e37c1 = external constant [0 x i8]
@olang_loc_40eaf25cbb0521a7_3d2a576ac0c8b0f3 = external constant [0 x i8]
@olang_loc_945ffbf6072962e3_f3ad5bbe10c5f487 = external constant [0 x i8]
@olang_loc_f83bd81acd9884e2_c22158a061119526 = external constant [0 x i8]
@olang_loc_5699d6f0b9487a4c_f8171e4e8a154888 = external constant [0 x i8]
@olang_loc_ef97709dce49d3b_530bdd1db1d3a0b7 = external constant [0 x i8]
@olang_loc_cf8b3001c30b10ba_435a3683731d1196 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0, %"compiler/views:tasked" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2eTruncate_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1e57e3539652abf4_8f970453f904e310 = external constant [0 x i8]
@olang_loc_551fdf32d31d54b_8fb5917c27ba1e87 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a630935aa2e7253f_7098fd3403d75c2b = external constant [0 x i8]
@olang_loc_f889b3d9696b6a08_112f010babbc7bb4 = external constant [0 x i8]
@olang_loc_fbef590508ae9827_444bd78203178143 = external constant [0 x i8]
@olang_loc_d673b6bd3b875b76_a50d9e4884ce91c2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26__Hfc8ba67df4afabc6715fbd3122f62db9(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2ePush_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0, %"compiler/views:holding" %a1)
@olang_loc_58304325d16d56e1_1ac2a884e74450d5 = external constant [0 x i8]
@olang_loc_f882b6801a6cfe65_db0a8f546b27139 = external constant [0 x i8]
@olang_loc_4283dbd3668d18ac_9869995bfb9a4270 = external constant [0 x i8]
@olang_loc_7a5a13ecbea84e9b_d0d616c1e5cf6f4f = external constant [0 x i8]
@olang_loc_e23614535e762839_a3c52bd11c6a8cad = external constant [0 x i8]
@olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2eClear_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2eClear_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0, %"compiler/views:naming" %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_26ef299dad5cdbef_4a7142c0b9c90bab = external constant [0 x i8]
@olang_loc_f3a6d7e7b6ee655_a5694061fe6eb811 = external constant [0 x i8]
@olang_loc_cc40afa1f47574c5_1b87777640286ce9 = external constant [0 x i8]
@olang_loc_c6dbc1b994c66c62_e0c1acfc7721040e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2eSetAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:view" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aview_3e_2ePush_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, %"compiler/views:view" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3asummary_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fviews_3aloopFrame_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3astate_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3aholding_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3anaming_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3atasked_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
