; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/views:summary" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/views:place" = type { { i64, [2 x i64] }, i64, i64, i1 }
%"compiler/views:state" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/views:holding" = type { i64, %"compiler/views:view" }
%"compiler/views:view" = type { %"compiler/views:place", i64, i1, %"compiler/source:Span", i64, i64, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/views:fact" = type { i64, i64, i32, i64, i64, i1, i64, %"compiler/source:Span", i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/views:tasked" = type { %"compiler/views:view", %"compiler/source:Span" }
%"compiler/views:loopFrame" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/views:naming" = type { i64, %"compiler/views:place" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
define dso_local ptr @compiler_2fviews_2eargPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fviews_2eunAway(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb10
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l5, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a5e6daec8976db0_405389cf00db76ac)
  unreachable
bb16:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t28, ptr %a1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Alt", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t33, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t66, ptr %t68)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb14:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Arm", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Arm", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l129 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l151 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l188 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %l245 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l257 = alloca i1
  %l270 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l297 = alloca ptr
  %l298 = alloca i1
  %l314 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l339 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca i1
  %l357 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca i1
  %l375 = alloca ptr
  %l376 = alloca i1
  %l389 = alloca { i64, ptr }
  %l392 = alloca ptr
  %l393 = alloca i1
  %l403 = alloca ptr
  %l404 = alloca i1
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s49 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t6 = load ptr, ptr %l64, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l64, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l65, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l65, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t21 = load ptr, ptr %l70, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l70, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l71, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l71, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t36 = load ptr, ptr %l76, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l76, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l77, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l77, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t50, ptr %t52)
  br label %bb17
bb17:
  br label %bb233
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t56 = load ptr, ptr %l85, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l85, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l86, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l86, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Promote", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t73, ptr %t75)
  br label %bb24
bb24:
  br label %bb233
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t79 = load ptr, ptr %l95, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l95, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l96, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l96, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb57
bb30:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Call", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l5, !tbaa !29
  %t98 = load ptr, ptr %l5, !tbaa !29
  store ptr %t98, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t99 = load ptr, ptr %l103, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l103, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 0
  store i1 %t105, ptr %l104, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l104, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { i32 }, ptr %t109, i32 0, i32 0
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l6, !tbaa !23
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t114 = load i32, ptr %l6, !tbaa !23
  %t116 = sext i32 %t114 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t113, i64 %t116)
  br label %bb36
bb36:
  br label %bb49
bb37:
  %t119 = load ptr, ptr %l5, !tbaa !29
  store ptr %t119, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t120 = load ptr, ptr %l112, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l112, !tbaa !29
  %t124 = load i64, ptr %t123
  %t126 = icmp eq i64 %t124, 2
  store i1 %t126, ptr %l113, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l113, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { ptr }, ptr %t130, i32 0, i32 0
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l7, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t134 = load ptr, ptr %l7, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t134, ptr %t136)
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_3cbb6fb3b51c25bd_1e9ab5921d6290d1)
  unreachable
bb49:
  %t139 = load ptr, ptr %l4, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Call", ptr %t139, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t148 = load i64, ptr %l9, !tbaa !24
  %t149 = load i64, ptr %l10, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t156 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t156, ptr %l129, !tbaa !27
  %t157 = load i64, ptr %l9, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr ptr, ptr %t160, i64 %t157
  %t162 = load ptr, ptr %t161, !tbaa !39
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t162, ptr %t166)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t169 = load i64, ptr %l9, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l9, !tbaa !24
  br label %bb50
bb56:
  br label %bb233
bb57:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t174 = load ptr, ptr %l137, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb58, label %bb59
bb58:
  %t177 = load ptr, ptr %l137, !tbaa !29
  %t178 = load i64, ptr %t177
  %t180 = icmp eq i64 %t178, 7
  store i1 %t180, ptr %l138, !tbaa !21
  br label %bb59
bb59:
  %t181 = load i1, ptr %l138, !tbaa !21
  br i1 %t181, label %bb60, label %bb61
bb60:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t188 = load ptr, ptr %l12, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Make", ptr %t188, i32 0, i32 2
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l15, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t197 = load i64, ptr %l14, !tbaa !24
  %t198 = load i64, ptr %l15, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb65:
  br label %bb66
bb66:
  %t205 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t205, ptr %l151, !tbaa !27
  %t206 = load i64, ptr %l14, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t215 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t211, ptr %t215)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t218 = load i64, ptr %l14, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l14, !tbaa !24
  br label %bb63
bb69:
  %t222 = load ptr, ptr %l12, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Make", ptr %t222, i32 0, i32 3
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t225, ptr %t226)
  br label %bb70
bb70:
  br label %bb233
bb71:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t230 = load ptr, ptr %l162, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb72, label %bb73
bb72:
  %t233 = load ptr, ptr %l162, !tbaa !29
  %t234 = load i64, ptr %t233
  %t236 = icmp eq i64 %t234, 8
  store i1 %t236, ptr %l163, !tbaa !21
  br label %bb73
bb73:
  %t237 = load i1, ptr %l163, !tbaa !21
  br i1 %t237, label %bb74, label %bb75
bb74:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l17, !tbaa !29
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t244 = load ptr, ptr %l17, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Collect", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  br label %bb77
bb77:
  %t251 = load ptr, ptr %l17, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Collect", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t254, ptr %t256)
  br label %bb78
bb78:
  br label %bb233
bb79:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t260 = load ptr, ptr %l175, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb80, label %bb81
bb80:
  %t263 = load ptr, ptr %l175, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 9
  store i1 %t266, ptr %l176, !tbaa !21
  br label %bb81
bb81:
  %t267 = load i1, ptr %l176, !tbaa !21
  br i1 %t267, label %bb82, label %bb83
bb82:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t270, i32 0, i32 4
  %t272 = load { i64, ptr }, ptr %t271
  store { i64, ptr } %t272, ptr %l18, !tbaa !27
  br label %bb84
bb83:
  br label %bb92
bb84:
  %t274 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t274, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  store i64 %t278, ptr %l21, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s18
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = load i64, ptr %l21, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb87:
  br label %bb88
bb88:
  %t288 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t288, ptr %l188, !tbaa !27
  %t289 = load i64, ptr %l20, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 %t289
  %t294 = load ptr, ptr %t293, !tbaa !39
  %t298 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t294, ptr %t298)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb90:
  %t301 = load i64, ptr %l20, !tbaa !24
  %t303 = add i64 %t301, 1
  store i64 %t303, ptr %l20, !tbaa !24
  br label %bb85
bb91:
  br label %bb233
bb92:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t306 = load ptr, ptr %l196, !tbaa !29
  %t307 = icmp ne ptr %t306, null
  br i1 %t307, label %bb93, label %bb94
bb93:
  %t309 = load ptr, ptr %l196, !tbaa !29
  %t310 = load i64, ptr %t309
  %t312 = icmp eq i64 %t310, 10
  store i1 %t312, ptr %l197, !tbaa !21
  br label %bb94
bb94:
  %t313 = load i1, ptr %l197, !tbaa !21
  br i1 %t313, label %bb95, label %bb96
bb95:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t316, i32 0, i32 2
  %t318 = load ptr, ptr %t317
  store ptr %t318, ptr %l23, !tbaa !29
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t320 = load ptr, ptr %l23, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Slice", ptr %t320, i32 0, i32 0
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t323, ptr %t325)
  br label %bb98
bb98:
  %t328 = load ptr, ptr %l23, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Slice", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t331, ptr %t333)
  br label %bb99
bb99:
  %t336 = load ptr, ptr %l23, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Slice", ptr %t336, i32 0, i32 2
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t339, ptr %t341)
  br label %bb100
bb100:
  br label %bb233
bb101:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t345 = load ptr, ptr %l214, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb102, label %bb103
bb102:
  %t348 = load ptr, ptr %l214, !tbaa !29
  %t349 = load i64, ptr %t348
  %t351 = icmp eq i64 %t349, 11
  store i1 %t351, ptr %l215, !tbaa !21
  br label %bb103
bb103:
  %t352 = load i1, ptr %l215, !tbaa !21
  br i1 %t352, label %bb104, label %bb105
bb104:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l24, !tbaa !29
  br label %bb106
bb105:
  br label %bb110
bb106:
  %t359 = load ptr, ptr %l24, !tbaa !29
  %t361 = getelementptr %"compiler/typed:Cond", ptr %t359, i32 0, i32 0
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t364 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t362, ptr %t364)
  br label %bb107
bb107:
  %t367 = load ptr, ptr %l24, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Cond", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb108
bb108:
  %t374 = load ptr, ptr %l24, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Cond", ptr %t374, i32 0, i32 2
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t377, ptr %t379)
  br label %bb109
bb109:
  br label %bb233
bb110:
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t383 = load ptr, ptr %l231, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb111, label %bb112
bb111:
  %t386 = load ptr, ptr %l231, !tbaa !29
  %t387 = load i64, ptr %t386
  %t389 = icmp eq i64 %t387, 12
  store i1 %t389, ptr %l232, !tbaa !21
  br label %bb112
bb112:
  %t390 = load i1, ptr %l232, !tbaa !21
  br i1 %t390, label %bb113, label %bb114
bb113:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr { i64, [5 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t393, i32 0, i32 2
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l25, !tbaa !29
  br label %bb115
bb114:
  br label %bb124
bb115:
  %t397 = load ptr, ptr %l25, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Seq", ptr %t397, i32 0, i32 0
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  store { i64, ptr } %t400, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t402 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 0
  store i64 %t404, ptr %l28, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s24
  %t406 = load i64, ptr %l27, !tbaa !24
  %t407 = load i64, ptr %l28, !tbaa !24
  %t410 = icmp slt i64 %t406, %t407
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s24)
  br label %bb122
bb118:
  br label %bb119
bb119:
  %t414 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t414, ptr %l245, !tbaa !27
  %t415 = load i64, ptr %l27, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr ptr, ptr %t418, i64 %t415
  %t420 = load ptr, ptr %t419, !tbaa !39
  %t424 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t420, ptr %t424)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s24)
  br label %bb121
bb121:
  %t427 = load i64, ptr %l27, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l27, !tbaa !24
  br label %bb116
bb122:
  %t431 = load ptr, ptr %l25, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Seq", ptr %t431, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t435 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t434, ptr %t435)
  br label %bb123
bb123:
  br label %bb233
bb124:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t439 = load ptr, ptr %l256, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  br i1 %t440, label %bb125, label %bb126
bb125:
  %t442 = load ptr, ptr %l256, !tbaa !29
  %t443 = load i64, ptr %t442
  %t445 = icmp eq i64 %t443, 13
  store i1 %t445, ptr %l257, !tbaa !21
  br label %bb126
bb126:
  %t446 = load i1, ptr %l257, !tbaa !21
  br i1 %t446, label %bb127, label %bb128
bb127:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t449, i32 0, i32 2
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l30, !tbaa !29
  br label %bb129
bb128:
  br label %bb145
bb129:
  %t453 = load ptr, ptr %l30, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Match", ptr %t453, i32 0, i32 0
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  store { i64, ptr } %t456, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t458 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  store i64 %t460, ptr %l33, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s28
  %t462 = load i64, ptr %l32, !tbaa !24
  %t463 = load i64, ptr %l33, !tbaa !24
  %t466 = icmp slt i64 %t462, %t463
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s28)
  br label %bb136
bb132:
  br label %bb133
bb133:
  %t470 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t470, ptr %l270, !tbaa !27
  %t471 = load i64, ptr %l32, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr ptr, ptr %t474, i64 %t471
  %t476 = load ptr, ptr %t475, !tbaa !39
  %t480 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t476, ptr %t480)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s28)
  br label %bb135
bb135:
  %t483 = load i64, ptr %l32, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l32, !tbaa !24
  br label %bb130
bb136:
  %t487 = load ptr, ptr %l30, !tbaa !29
  %t489 = getelementptr %"compiler/typed:Match", ptr %t487, i32 0, i32 1
  %t490 = load { i64, ptr }, ptr %t489, !tbaa !27
  store { i64, ptr } %t490, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t492 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t492, 0
  store i64 %t494, ptr %l37, !tbaa !24
  br label %bb137
bb137:
  store %olang.scope zeroinitializer, ptr %s31
  %t496 = load i64, ptr %l36, !tbaa !24
  %t497 = load i64, ptr %l37, !tbaa !24
  %t500 = icmp slt i64 %t496, %t497
  %t502 = xor i1 %t500, true
  br i1 %t502, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb139:
  br label %bb140
bb140:
  %t504 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t504, ptr %l286, !tbaa !27
  %t505 = load i64, ptr %l36, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr ptr, ptr %t508, i64 %t505
  %t510 = load ptr, ptr %t509, !tbaa !39
  %t514 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %t510, ptr %t514)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s31)
  br label %bb142
bb142:
  %t517 = load i64, ptr %l36, !tbaa !24
  %t519 = add i64 %t517, 1
  store i64 %t519, ptr %l36, !tbaa !24
  br label %bb137
bb143:
  %t521 = load ptr, ptr %l30, !tbaa !29
  %t523 = getelementptr %"compiler/typed:Match", ptr %t521, i32 0, i32 2
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t525 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %t524, ptr %t525)
  br label %bb144
bb144:
  br label %bb233
bb145:
  %t528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t528, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t529 = load ptr, ptr %l297, !tbaa !29
  %t530 = icmp ne ptr %t529, null
  br i1 %t530, label %bb146, label %bb147
bb146:
  %t532 = load ptr, ptr %l297, !tbaa !29
  %t533 = load i64, ptr %t532
  %t535 = icmp eq i64 %t533, 14
  store i1 %t535, ptr %l298, !tbaa !21
  br label %bb147
bb147:
  %t536 = load i1, ptr %l298, !tbaa !21
  br i1 %t536, label %bb148, label %bb149
bb148:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr { i64, [5 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t539, i32 0, i32 2
  %t541 = load ptr, ptr %t540
  store ptr %t541, ptr %l39, !tbaa !29
  br label %bb150
bb149:
  br label %bb166
bb150:
  %t543 = load ptr, ptr %l39, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Try", ptr %t543, i32 0, i32 0
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t547 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t546, ptr %t547)
  br label %bb151
bb151:
  %t550 = load ptr, ptr %l39, !tbaa !29
  %t552 = getelementptr %"compiler/typed:Try", ptr %t550, i32 0, i32 1
  %t553 = load { i64, ptr }, ptr %t552, !tbaa !27
  store { i64, ptr } %t553, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t555 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t555, 0
  store i64 %t557, ptr %l42, !tbaa !24
  br label %bb152
bb152:
  store %olang.scope zeroinitializer, ptr %s35
  %t559 = load i64, ptr %l41, !tbaa !24
  %t560 = load i64, ptr %l42, !tbaa !24
  %t563 = icmp slt i64 %t559, %t560
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s35)
  br label %bb165
bb154:
  br label %bb155
bb155:
  %t567 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t567, ptr %l314, !tbaa !27
  %t568 = load i64, ptr %l41, !tbaa !24
  %t570 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !27
  %t572 = getelementptr ptr, ptr %t571, i64 %t568
  %t573 = load ptr, ptr %t572, !tbaa !39
  store ptr %t573, ptr %l43, !tbaa !29
  %t575 = load ptr, ptr %l43, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Clause", ptr %t575, i32 0, i32 3
  %t578 = load ptr, ptr %t577, !tbaa !29
  %t579 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t578, ptr %t579)
  br label %bb156
bb156:
  %t582 = load ptr, ptr %l43, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Clause", ptr %t582, i32 0, i32 4
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t587 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t587, 0
  store i64 %t589, ptr %l46, !tbaa !24
  br label %bb157
bb157:
  store %olang.scope zeroinitializer, ptr %s37
  %t591 = load i64, ptr %l45, !tbaa !24
  %t592 = load i64, ptr %l46, !tbaa !24
  %t595 = icmp slt i64 %t591, %t592
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s37)
  br label %bb163
bb159:
  br label %bb160
bb160:
  %t599 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t599, ptr %l328, !tbaa !27
  %t600 = load i64, ptr %l45, !tbaa !24
  %t602 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr ptr, ptr %t603, i64 %t600
  %t605 = load ptr, ptr %t604, !tbaa !39
  %t609 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t605, ptr %t609)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s37)
  br label %bb162
bb162:
  %t612 = load i64, ptr %l45, !tbaa !24
  %t614 = add i64 %t612, 1
  store i64 %t614, ptr %l45, !tbaa !24
  br label %bb157
bb163:
  call void @__olang_scope_close(ptr %s35)
  br label %bb164
bb164:
  %t616 = load i64, ptr %l41, !tbaa !24
  %t618 = add i64 %t616, 1
  store i64 %t618, ptr %l41, !tbaa !24
  br label %bb152
bb165:
  br label %bb233
bb166:
  %t620 = load ptr, ptr %l0, !tbaa !29
  store ptr %t620, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t621 = load ptr, ptr %l338, !tbaa !29
  %t622 = icmp ne ptr %t621, null
  br i1 %t622, label %bb167, label %bb168
bb167:
  %t624 = load ptr, ptr %l338, !tbaa !29
  %t625 = load i64, ptr %t624
  %t627 = icmp eq i64 %t625, 15
  store i1 %t627, ptr %l339, !tbaa !21
  br label %bb168
bb168:
  %t628 = load i1, ptr %l339, !tbaa !21
  br i1 %t628, label %bb169, label %bb170
bb169:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr { i64, [5 x i64] }, ptr %t629, i32 0, i32 1
  %t632 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t631, i32 0, i32 2
  %t633 = load ptr, ptr %t632
  store ptr %t633, ptr %l48, !tbaa !29
  br label %bb171
bb170:
  br label %bb197
bb171:
  %t635 = load ptr, ptr %l48, !tbaa !29
  store ptr %t635, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t636 = load ptr, ptr %l344, !tbaa !29
  %t637 = icmp ne ptr %t636, null
  br i1 %t637, label %bb172, label %bb173
bb172:
  %t639 = load ptr, ptr %l344, !tbaa !29
  %t640 = load i64, ptr %t639
  %t642 = icmp eq i64 %t640, 1
  store i1 %t642, ptr %l345, !tbaa !21
  br label %bb173
bb173:
  %t643 = load i1, ptr %l345, !tbaa !21
  br i1 %t643, label %bb174, label %bb175
bb174:
  %t644 = load ptr, ptr %l48, !tbaa !29
  %t646 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  %t647 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t646, i32 0, i32 1
  %t648 = load { i64, ptr }, ptr %t647
  store { i64, ptr } %t648, ptr %l49, !tbaa !27
  br label %bb176
bb175:
  br label %bb184
bb176:
  %t650 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t650, ptr %l50, !tbaa !27
  store i64 0, ptr %l51, !tbaa !24
  %t652 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  store i64 %t654, ptr %l52, !tbaa !24
  br label %bb177
bb177:
  store %olang.scope zeroinitializer, ptr %s43
  %t656 = load i64, ptr %l51, !tbaa !24
  %t657 = load i64, ptr %l52, !tbaa !24
  %t660 = icmp slt i64 %t656, %t657
  %t662 = xor i1 %t660, true
  br i1 %t662, label %bb178, label %bb179
bb178:
  call void @__olang_scope_close(ptr %s43)
  br label %bb183
bb179:
  br label %bb180
bb180:
  %t664 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t664, ptr %l357, !tbaa !27
  %t665 = load i64, ptr %l51, !tbaa !24
  %t667 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !27
  %t669 = getelementptr ptr, ptr %t668, i64 %t665
  %t670 = load ptr, ptr %t669, !tbaa !39
  %t674 = getelementptr %"compiler/typed:Capture", ptr %t670, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !29
  %t677 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t675, ptr %t677)
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s43)
  br label %bb182
bb182:
  %t680 = load i64, ptr %l51, !tbaa !24
  %t682 = add i64 %t680, 1
  store i64 %t682, ptr %l51, !tbaa !24
  br label %bb177
bb183:
  br label %bb196
bb184:
  %t684 = load ptr, ptr %l48, !tbaa !29
  store ptr %t684, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t685 = load ptr, ptr %l366, !tbaa !29
  %t686 = icmp ne ptr %t685, null
  br i1 %t686, label %bb185, label %bb186
bb185:
  %t688 = load ptr, ptr %l366, !tbaa !29
  %t689 = load i64, ptr %t688
  %t691 = icmp eq i64 %t689, 2
  store i1 %t691, ptr %l367, !tbaa !21
  br label %bb186
bb186:
  %t692 = load i1, ptr %l367, !tbaa !21
  br i1 %t692, label %bb187, label %bb188
bb187:
  %t693 = load ptr, ptr %l48, !tbaa !29
  %t695 = getelementptr { i64, [4 x i64] }, ptr %t693, i32 0, i32 1
  %t696 = getelementptr { i32, ptr, i32 }, ptr %t695, i32 0, i32 1
  %t697 = load ptr, ptr %t696
  store ptr %t697, ptr %l54, !tbaa !29
  br label %bb189
bb188:
  br label %bb191
bb189:
  %t699 = load ptr, ptr %l54, !tbaa !29
  %t701 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t699, ptr %t701)
  br label %bb190
bb190:
  br label %bb196
bb191:
  br i1 true, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @olang_loc_87083398c1f96e8c_18c50ee403fa2840)
  unreachable
bb196:
  br label %bb233
bb197:
  %t704 = load ptr, ptr %l0, !tbaa !29
  store ptr %t704, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t705 = load ptr, ptr %l375, !tbaa !29
  %t706 = icmp ne ptr %t705, null
  br i1 %t706, label %bb198, label %bb199
bb198:
  %t708 = load ptr, ptr %l375, !tbaa !29
  %t709 = load i64, ptr %t708
  %t711 = icmp eq i64 %t709, 16
  store i1 %t711, ptr %l376, !tbaa !21
  br label %bb199
bb199:
  %t712 = load i1, ptr %l376, !tbaa !21
  br i1 %t712, label %bb200, label %bb201
bb200:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr { i64, [5 x i64] }, ptr %t713, i32 0, i32 1
  %t716 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t715, i32 0, i32 2
  %t717 = load ptr, ptr %t716
  store ptr %t717, ptr %l55, !tbaa !29
  br label %bb202
bb201:
  br label %bb221
bb202:
  %t719 = load ptr, ptr %l55, !tbaa !29
  %t721 = getelementptr %"compiler/typed:Text", ptr %t719, i32 0, i32 0
  %t722 = load { i64, ptr }, ptr %t721, !tbaa !27
  store { i64, ptr } %t722, ptr %l56, !tbaa !27
  store i64 0, ptr %l57, !tbaa !24
  %t724 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t724, 0
  store i64 %t726, ptr %l58, !tbaa !24
  br label %bb203
bb203:
  store %olang.scope zeroinitializer, ptr %s49
  %t728 = load i64, ptr %l57, !tbaa !24
  %t729 = load i64, ptr %l58, !tbaa !24
  %t732 = icmp slt i64 %t728, %t729
  %t734 = xor i1 %t732, true
  br i1 %t734, label %bb204, label %bb205
bb204:
  call void @__olang_scope_close(ptr %s49)
  br label %bb220
bb205:
  br label %bb206
bb206:
  %t736 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t736, ptr %l389, !tbaa !27
  %t737 = load i64, ptr %l57, !tbaa !24
  %t739 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !27
  %t741 = getelementptr ptr, ptr %t740, i64 %t737
  %t742 = load ptr, ptr %t741, !tbaa !39
  store ptr %t742, ptr %l59, !tbaa !29
  %t744 = load ptr, ptr %l59, !tbaa !29
  store ptr %t744, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t745 = load ptr, ptr %l392, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  br i1 %t746, label %bb207, label %bb208
bb207:
  %t748 = load ptr, ptr %l392, !tbaa !29
  %t749 = load i64, ptr %t748
  %t751 = icmp eq i64 %t749, 1
  store i1 %t751, ptr %l393, !tbaa !21
  br label %bb208
bb208:
  %t752 = load i1, ptr %l393, !tbaa !21
  br i1 %t752, label %bb209, label %bb210
bb209:
  %t753 = load ptr, ptr %l59, !tbaa !29
  %t755 = getelementptr { i64, [2 x i64] }, ptr %t753, i32 0, i32 1
  %t756 = getelementptr { ptr }, ptr %t755, i32 0, i32 0
  %t757 = load ptr, ptr %t756
  store ptr %t757, ptr %l60, !tbaa !29
  br label %bb211
bb210:
  br label %bb213
bb211:
  %t759 = load ptr, ptr %l60, !tbaa !29
  %t761 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t759, ptr %t761)
  br label %bb212
bb212:
  br label %bb218
bb213:
  br i1 true, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb218
bb217:
  call void @__olang_check_failed(ptr @olang_loc_b5f5b909b97f4b87_db04b2c3237782bb)
  unreachable
bb218:
  call void @__olang_scope_close(ptr %s49)
  br label %bb219
bb219:
  %t764 = load i64, ptr %l57, !tbaa !24
  %t766 = add i64 %t764, 1
  store i64 %t766, ptr %l57, !tbaa !24
  br label %bb203
bb220:
  br label %bb233
bb221:
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l403, !tbaa !29
  store i1 false, ptr %l404, !tbaa !21
  %t769 = load ptr, ptr %l403, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb222, label %bb223
bb222:
  %t772 = load ptr, ptr %l403, !tbaa !29
  %t773 = load i64, ptr %t772
  %t775 = icmp eq i64 %t773, 17
  store i1 %t775, ptr %l404, !tbaa !21
  br label %bb223
bb223:
  %t776 = load i1, ptr %l404, !tbaa !21
  br i1 %t776, label %bb224, label %bb225
bb224:
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t779, i32 0, i32 2
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l61, !tbaa !29
  br label %bb226
bb225:
  br label %bb228
bb226:
  %t783 = load ptr, ptr %l61, !tbaa !29
  %t785 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t783, ptr %t785)
  br label %bb227
bb227:
  br label %bb233
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb233
bb232:
  call void @__olang_check_failed(ptr @olang_loc_8469b5ec09caec26_9b966bbb099df63a)
  unreachable
bb233:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t40, ptr %t42)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Elem", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t63, ptr %t65)
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Elem", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t71, ptr %t73)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Payload", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t94, ptr %t96)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t114, ptr %t116)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_f21fc7c42b27f081_20ede69b6f10d945)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l154 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l176 = alloca { i64, ptr }
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t6 = load ptr, ptr %l24, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l24, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l25, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb24
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l30, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l31, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb24
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t36 = load ptr, ptr %l36, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l36, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l37, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb24
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t51 = load ptr, ptr %l42, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l42, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 15
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l43, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [3 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l2, !tbaa !29
  br label %bb24
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t66 = load ptr, ptr %l48, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 16
  store i1 %t72, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l49, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l2, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb25
bb25:
  br label %bb110
bb26:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t85 = load ptr, ptr %l56, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l56, !tbaa !29
  %t89 = load i64, ptr %t88
  %t91 = icmp eq i64 %t89, 1
  store i1 %t91, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l57, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t95, i32 0, i32 1
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t105, ptr %t107)
  br label %bb32
bb32:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t110, ptr %t112)
  br label %bb33
bb33:
  br label %bb110
bb34:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t116 = load ptr, ptr %l70, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb36
bb36:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb37:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/typed:If", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t133, ptr %t135)
  br label %bb40
bb40:
  %t138 = load ptr, ptr %l5, !tbaa !29
  %t140 = getelementptr %"compiler/typed:If", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t141, ptr %t143)
  br label %bb41
bb41:
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  br label %bb42
bb42:
  br label %bb110
bb43:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t154 = load ptr, ptr %l87, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t157 = load ptr, ptr %l87, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 4
  store i1 %t160, ptr %l88, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l88, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l6, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l7, !tbaa !29
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t174 = load ptr, ptr %l6, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t174, ptr %t176)
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l7, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb50
bb50:
  br label %bb110
bb51:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t184 = load ptr, ptr %l100, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb52, label %bb53
bb52:
  %t187 = load ptr, ptr %l100, !tbaa !29
  %t188 = load i64, ptr %t187
  %t190 = icmp eq i64 %t188, 10
  store i1 %t190, ptr %l101, !tbaa !21
  br label %bb53
bb53:
  %t191 = load i1, ptr %l101, !tbaa !21
  br i1 %t191, label %bb54, label %bb55
bb54:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l8, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t200, i32 0, i32 2
  %t202 = load ptr, ptr %t201
  store ptr %t202, ptr %l9, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t204, ptr %t206)
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l9, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t209, ptr %t210)
  br label %bb58
bb58:
  br label %bb110
bb59:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t214 = load ptr, ptr %l113, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb60, label %bb61
bb60:
  %t217 = load ptr, ptr %l113, !tbaa !29
  %t218 = load i64, ptr %t217
  %t220 = icmp eq i64 %t218, 9
  store i1 %t220, ptr %l114, !tbaa !21
  br label %bb61
bb61:
  %t221 = load i1, ptr %l114, !tbaa !21
  br i1 %t221, label %bb62, label %bb63
bb62:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr { i64, [3 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l10, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t228 = load ptr, ptr %l10, !tbaa !29
  %t229 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t228, ptr %t229)
  br label %bb65
bb65:
  br label %bb110
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t233 = load ptr, ptr %l121, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l121, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 11
  store i1 %t239, ptr %l122, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l11, !tbaa !29
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t248 = load ptr, ptr %l127, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l127, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 12
  store i1 %t254, ptr %l128, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l128, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t262, ptr %t264)
  br label %bb76
bb76:
  br label %bb110
bb77:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t268 = load ptr, ptr %l136, !tbaa !29
  %t269 = icmp ne ptr %t268, null
  br i1 %t269, label %bb78, label %bb79
bb78:
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = load i64, ptr %t271
  %t274 = icmp eq i64 %t272, 13
  store i1 %t274, ptr %l137, !tbaa !21
  br label %bb79
bb79:
  %t275 = load i1, ptr %l137, !tbaa !21
  br i1 %t275, label %bb80, label %bb81
bb80:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t276, i32 0, i32 1
  %t279 = getelementptr { %"compiler/source:Span", ptr }, ptr %t278, i32 0, i32 1
  %t280 = load ptr, ptr %t279
  store ptr %t280, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb91
bb82:
  %t282 = load ptr, ptr %l12, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Join", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t285, ptr %t287)
  br label %bb83
bb83:
  %t290 = load ptr, ptr %l12, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Join", ptr %t290, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  store i64 %t297, ptr %l15, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s11
  %t299 = load i64, ptr %l14, !tbaa !24
  %t300 = load i64, ptr %l15, !tbaa !24
  %t303 = icmp slt i64 %t299, %t300
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb90
bb86:
  br label %bb87
bb87:
  %t307 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t307, ptr %l154, !tbaa !27
  %t308 = load i64, ptr %l14, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr ptr, ptr %t311, i64 %t308
  %t313 = load ptr, ptr %t312, !tbaa !39
  %t317 = getelementptr %"compiler/typed:Clause", ptr %t313, i32 0, i32 3
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t318, ptr %t319)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s11)
  br label %bb89
bb89:
  %t322 = load i64, ptr %l14, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l14, !tbaa !24
  br label %bb84
bb90:
  br label %bb110
bb91:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t327 = load ptr, ptr %l162, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb92, label %bb93
bb92:
  %t330 = load ptr, ptr %l162, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 14
  store i1 %t333, ptr %l163, !tbaa !21
  br label %bb93
bb93:
  %t334 = load i1, ptr %l163, !tbaa !21
  br i1 %t334, label %bb94, label %bb95
bb94:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l17, !tbaa !29
  br label %bb96
bb95:
  br label %bb105
bb96:
  %t341 = load ptr, ptr %l17, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Spawn", ptr %t341, i32 0, i32 0
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  store { i64, ptr } %t344, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t346 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  store i64 %t348, ptr %l20, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s15
  %t350 = load i64, ptr %l19, !tbaa !24
  %t351 = load i64, ptr %l20, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s15)
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t358 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t358, ptr %l176, !tbaa !27
  %t359 = load i64, ptr %l19, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr ptr, ptr %t362, i64 %t359
  %t364 = load ptr, ptr %t363, !tbaa !39
  %t367 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t364, ptr %t367)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s15)
  br label %bb102
bb102:
  %t370 = load i64, ptr %l19, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l19, !tbaa !24
  br label %bb97
bb103:
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Spawn", ptr %t374, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t377, ptr %t379)
  br label %bb104
bb104:
  br label %bb110
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_293c6ab0a5c406c2_e9cd55f098635cb6)
  unreachable
bb110:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l62 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca i64
  %l85 = alloca i1
  %l92 = alloca i1
  %l105 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i64
  %l115 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/views:summary"
  %l140 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i32
  %l156 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l177 = alloca i1
  %l182 = alloca i1
  %l186 = alloca i64
  %l190 = alloca i64
  %l193 = alloca i64
  %l212 = alloca i64
  %l215 = alloca i64
  %l217 = alloca i64
  %l222 = alloca i64
  %l225 = alloca i64
  %l226 = alloca i64
  %l230 = alloca i64
  %l233 = alloca i1
  %l234 = alloca ptr
  %l236 = alloca ptr
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca i1
  %l246 = alloca i64
  %l249 = alloca i64
  %l271 = alloca i64
  %l276 = alloca i64
  %l279 = alloca i64
  %l297 = alloca ptr
  %l301 = alloca i64
  %l307 = alloca i1
  %l315 = alloca i64
  %l320 = alloca i64
  %l323 = alloca i64
  %l341 = alloca ptr
  %l345 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l53
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l52
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t20, ptr %l49, !tbaa !27
  br label %bb7
bb3:
  %t21 = load i32, ptr %l53, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_7c6f17176a51aa71_b3e719a904165ead)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb7:
  %t26 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t39, ptr %l62, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l6, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 4
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 6
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/views:Viewer", ptr %t63, i32 0, i32 5
  store ptr %t65, ptr %l73, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 4
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l75, !tbaa !24
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 6
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb17, label %bb18
bb16:
  br label %bb21
bb17:
  call void @__olang_check_failed(ptr @olang_loc_c1486460ddc03a29_b5b65c437008efc5)
  unreachable
bb18:
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = getelementptr %"compiler/load:Module", ptr %t77, i32 0, i32 6
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = getelementptr %"compiler/source:Source", ptr %t80, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t85 = load ptr, ptr %l73, !tbaa !29
  %t86 = load i64, ptr %l75, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t85, i64 %t86, { i64, ptr } %t84)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/load:Module", ptr %t88, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t91, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t93, ptr %l85
  br label %bb22
bb22:
  %t94 = load i1, ptr %l85, !tbaa !21
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/views:Viewer", ptr %t95, i32 0, i32 6
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = getelementptr %"compiler/load:Module", ptr %t98, i32 0, i32 4
  %t101 = load i64, ptr %t100, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t97, i64 %t101, i1 true)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/load:Module", ptr %t104, i32 0, i32 2
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t107, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t109, ptr %l92
  br label %bb27
bb27:
  %t110 = load i1, ptr %l92, !tbaa !21
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = getelementptr %"compiler/load:Module", ptr %t112, i32 0, i32 4
  %t115 = load i64, ptr %t114, !tbaa !24
  %t118 = getelementptr %"compiler/views:Viewer", ptr %t111, i32 0, i32 7
  store i64 %t115, ptr %t118, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t119 = load i64, ptr %l5, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l5, !tbaa !24
  br label %bb8
bb32:
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t123, %t124
  store i64 %t127, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  br label %bb1
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/views:Viewer", ptr %t129, i32 0, i32 7
  %t132 = load i64, ptr %t131, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  br label %bb37
bb37:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t136, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i64 %t138, ptr %l105
  br label %bb38
bb38:
  store i64 0, ptr %l7, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/views:Viewer", ptr %t139, i32 0, i32 1
  %t143 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l108
  br label %bb39
bb39:
  %t144 = load i64, ptr %l108, !tbaa !24
  store i64 %t144, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb40, label %bb41
bb40:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb45
bb42:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t156 = load i64, ptr %l7, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l9, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l9, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l115, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb44
bb44:
  %t171 = load i64, ptr %l115, !tbaa !24
  store i64 %t171, ptr %l112, !tbaa !24
  br label %bb45
bb45:
  %t172 = load i64, ptr %l112, !tbaa !24
  store i64 %t172, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb48:
  br label %bb49
bb49:
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l11, !tbaa !24
  %t183 = load i64, ptr %l9, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l12, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/views:Viewer", ptr %t191, i32 0, i32 2
  store ptr %t193, ptr %l134, !tbaa !29
  %t194 = call %"compiler/views:summary" @compiler_2fviews_3asummary_2ector(ptr %v0)
  store %"compiler/views:summary" %t194, ptr %l135
  br label %bb50
bb50:
  %t195 = load %"compiler/views:summary", ptr %l135
  %t196 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/views:summary" %t195, ptr %t196
  %t197 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_Hc36d700dbc0d7c55fb879f7e6bb38bd0(ptr %v0, ptr %v0, ptr %t197, ptr %t196)
  br label %bb51
bb51:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/views:Viewer", ptr %t199, i32 0, i32 1
  %t202 = load i64, ptr %l12, !tbaa !24
  %t205 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t201, i64 %t202)
  store ptr %t205, ptr %l140
  br label %bb52
bb52:
  %t206 = load ptr, ptr %l140, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Body", ptr %t206, i32 0, i32 5
  store ptr %t208, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t210 = load ptr, ptr %l13, !tbaa !29
  %t211 = load i64, ptr %l14, !tbaa !24
  %t214 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t210, i64 %t211)
  %t215 = extractvalue { i32, { i64, ptr } } %t214, 1
  %t216 = extractvalue { i32, { i64, ptr } } %t214, 0
  store i32 %t216, ptr %l147
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb55, label %ok.218
ok.218:
  store { i64, ptr } %t215, ptr %l146
  br label %bb54
bb54:
  %t219 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t219, ptr %l143, !tbaa !27
  br label %bb59
bb55:
  %t220 = load i32, ptr %l147, !tbaa !23
  %t221 = ashr i32 %t220, 16
  %t223 = icmp eq i32 %t221, 1
  br i1 %t223, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_25fbb0065c7b3b5b_3189e80820eb64b7)
  unreachable
bb58:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb59:
  %t225 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t225, ptr %l15, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  store i64 %t228, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t230 = load i64, ptr %l17, !tbaa !24
  %t231 = load i64, ptr %l16, !tbaa !24
  %t234 = icmp slt i64 %t230, %t231
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t238 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t238, ptr %l156, !tbaa !27
  %t239 = load i64, ptr %l17, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  store i32 %t244, ptr %l18, !tbaa !23
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/views:Viewer", ptr %t246, i32 0, i32 2
  %t249 = load i64, ptr %l12, !tbaa !24
  %t252 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t248, i64 %t249)
  store ptr %t252, ptr %l162
  br label %bb64
bb64:
  %t253 = load ptr, ptr %l162, !tbaa !29
  %t255 = getelementptr %"compiler/views:summary", ptr %t253, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t255, i1 false)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s14)
  br label %bb66
bb66:
  %t257 = load i64, ptr %l17, !tbaa !24
  %t259 = add i64 %t257, 1
  store i64 %t259, ptr %l17, !tbaa !24
  br label %bb60
bb67:
  %t261 = load i64, ptr %l14, !tbaa !24
  %t262 = load i64, ptr %l16, !tbaa !24
  %t265 = add i64 %t261, %t262
  store i64 %t265, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  br label %bb53
bb69:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/views:Viewer", ptr %t267, i32 0, i32 2
  %t270 = load i64, ptr %l12, !tbaa !24
  %t273 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t269, i64 %t270)
  store ptr %t273, ptr %l173
  br label %bb70
bb70:
  %t274 = load ptr, ptr %l173, !tbaa !29
  store ptr %t274, ptr %l174, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i64, ptr %l12, !tbaa !24
  %t279 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalkable(ptr %v0, ptr %t275, i64 %t276)
  store i1 %t279, ptr %l177
  br label %bb71
bb71:
  %t280 = load i1, ptr %l177, !tbaa !21
  %t281 = load ptr, ptr %l174, !tbaa !29
  %t282 = getelementptr %"compiler/views:summary", ptr %t281, i32 0, i32 4
  store i1 %t280, ptr %t282, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  %t283 = load i64, ptr %l11, !tbaa !24
  %t285 = add i64 %t283, 1
  store i64 %t285, ptr %l11, !tbaa !24
  br label %bb46
bb73:
  %t287 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecomponents(ptr %v0, ptr %t287)
  br label %bb74
bb74:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eviewsHeld(ptr %v0, ptr %t289)
  store i1 %t291, ptr %l182
  br label %bb75
bb75:
  %t292 = load i1, ptr %l182, !tbaa !21
  %t293 = xor i1 %t292, true
  br i1 %t293, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb77:
  br label %bb78
bb78:
  store i64 0, ptr %l19, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/views:Viewer", ptr %t295, i32 0, i32 17
  %t299 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t297)
  store i64 %t299, ptr %l186
  br label %bb79
bb79:
  %t300 = load i64, ptr %l186, !tbaa !24
  store i64 %t300, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t301 = load i64, ptr %l20, !tbaa !24
  %t302 = load i64, ptr %l19, !tbaa !24
  %t305 = icmp sgt i64 %t301, %t302
  br i1 %t305, label %bb80, label %bb81
bb80:
  %t307 = load i64, ptr %l21, !tbaa !24
  %t309 = icmp sgt i64 %t307, 0
  br i1 %t309, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb85
bb82:
  %t311 = load i64, ptr %l20, !tbaa !24
  %t312 = load i64, ptr %l19, !tbaa !24
  %t315 = sub i64 %t311, %t312
  %t316 = load i64, ptr %l21, !tbaa !24
  %t319 = add i64 %t315, %t316
  %t321 = sub i64 %t319, 1
  %t322 = load i64, ptr %l21, !tbaa !24
  %t325 = sdiv i64 %t321, %t322
  store i64 %t325, ptr %l193, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb84
bb84:
  %t327 = load i64, ptr %l193, !tbaa !24
  store i64 %t327, ptr %l190, !tbaa !24
  br label %bb85
bb85:
  %t328 = load i64, ptr %l190, !tbaa !24
  store i64 %t328, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s19
  %t329 = load i64, ptr %l23, !tbaa !24
  %t330 = load i64, ptr %l22, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s19)
  br label %bb152
bb88:
  br label %bb89
bb89:
  %t337 = load i64, ptr %l19, !tbaa !24
  %t338 = load i64, ptr %l23, !tbaa !24
  %t339 = load i64, ptr %l21, !tbaa !24
  %t342 = mul i64 %t338, %t339
  %t345 = add i64 %t337, %t342
  store i64 %t345, ptr %l24, !tbaa !24
  %t347 = load i64, ptr %l24, !tbaa !24
  %t349 = add i64 %t347, 1
  store i64 %t349, ptr %l212, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/views:Viewer", ptr %t350, i32 0, i32 17
  %t354 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t352)
  store i64 %t354, ptr %l215
  br label %bb90
bb90:
  %t355 = load i64, ptr %l212, !tbaa !24
  %t356 = load i64, ptr %l215, !tbaa !24
  %t357 = icmp slt i64 %t355, %t356
  br i1 %t357, label %bb91, label %bb92
bb91:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/views:Viewer", ptr %t359, i32 0, i32 17
  %t362 = load i64, ptr %l24, !tbaa !24
  %t364 = add i64 %t362, 1
  %t367 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t361, i64 %t364)
  store i64 %t367, ptr %l222
  br label %bb93
bb92:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/views:Viewer", ptr %t368, i32 0, i32 18
  %t372 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t370)
  store i64 %t372, ptr %l225
  br label %bb94
bb93:
  %t373 = load i64, ptr %l222, !tbaa !24
  store i64 %t373, ptr %l217, !tbaa !24
  br label %bb95
bb94:
  %t374 = load i64, ptr %l225, !tbaa !24
  store i64 %t374, ptr %l217, !tbaa !24
  br label %bb95
bb95:
  %t375 = load i64, ptr %l217, !tbaa !24
  store i64 %t375, ptr %l25, !tbaa !24
  %t376 = load i64, ptr %l25, !tbaa !24
  store i64 %t376, ptr %l226, !tbaa !24
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/views:Viewer", ptr %t377, i32 0, i32 17
  %t380 = load i64, ptr %l24, !tbaa !24
  %t383 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t379, i64 %t380)
  store i64 %t383, ptr %l230
  br label %bb96
bb96:
  %t384 = load i64, ptr %l226, !tbaa !24
  %t385 = load i64, ptr %l230, !tbaa !24
  %t386 = sub i64 %t384, %t385
  %t388 = icmp sgt i64 %t386, 1
  br i1 %t388, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l233, !tbaa !21
  br label %bb102
bb98:
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l234, !tbaa !29
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/views:Viewer", ptr %t391, i32 0, i32 18
  store ptr %t393, ptr %l236, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/views:Viewer", ptr %t394, i32 0, i32 17
  %t397 = load i64, ptr %l24, !tbaa !24
  %t400 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t396, i64 %t397)
  store i64 %t400, ptr %l240
  br label %bb99
bb99:
  %t401 = load ptr, ptr %l236, !tbaa !29
  %t402 = load i64, ptr %l240, !tbaa !24
  %t403 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t401, i64 %t402)
  store i64 %t403, ptr %l241
  br label %bb100
bb100:
  %t404 = load ptr, ptr %l234, !tbaa !29
  %t405 = load i64, ptr %l241, !tbaa !24
  %t406 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallsItself(ptr %v0, ptr %t404, i64 %t405)
  store i1 %t406, ptr %l242
  br label %bb101
bb101:
  %t407 = load i1, ptr %l242, !tbaa !21
  store i1 %t407, ptr %l233, !tbaa !21
  br label %bb102
bb102:
  %t408 = load i1, ptr %l233, !tbaa !21
  store i1 %t408, ptr %l26, !tbaa !21
  store i64 0, ptr %l27, !tbaa !24
  store i64 100, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t409 = load i64, ptr %l28, !tbaa !24
  %t410 = load i64, ptr %l27, !tbaa !24
  %t413 = icmp sgt i64 %t409, %t410
  br i1 %t413, label %bb103, label %bb104
bb103:
  %t415 = load i64, ptr %l29, !tbaa !24
  %t417 = icmp sgt i64 %t415, 0
  br i1 %t417, label %bb105, label %bb106
bb104:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb108
bb105:
  %t419 = load i64, ptr %l28, !tbaa !24
  %t420 = load i64, ptr %l27, !tbaa !24
  %t423 = sub i64 %t419, %t420
  %t424 = load i64, ptr %l29, !tbaa !24
  %t427 = add i64 %t423, %t424
  %t429 = sub i64 %t427, 1
  %t430 = load i64, ptr %l29, !tbaa !24
  %t433 = sdiv i64 %t429, %t430
  store i64 %t433, ptr %l249, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb107
bb107:
  %t435 = load i64, ptr %l249, !tbaa !24
  store i64 %t435, ptr %l246, !tbaa !24
  br label %bb108
bb108:
  %t436 = load i64, ptr %l246, !tbaa !24
  store i64 %t436, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb109
bb109:
  store %olang.scope zeroinitializer, ptr %s21
  %t437 = load i64, ptr %l31, !tbaa !24
  %t438 = load i64, ptr %l30, !tbaa !24
  %t441 = icmp slt i64 %t437, %t438
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s21)
  br label %bb135
bb111:
  br label %bb112
bb112:
  %t445 = load i64, ptr %l27, !tbaa !24
  %t446 = load i64, ptr %l31, !tbaa !24
  %t447 = load i64, ptr %l29, !tbaa !24
  %t450 = mul i64 %t446, %t447
  %t453 = add i64 %t445, %t450
  store i64 %t453, ptr %l32, !tbaa !24
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/views:Viewer", ptr %t455, i32 0, i32 24
  store i1 false, ptr %t457, !tbaa !21
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/views:Viewer", ptr %t458, i32 0, i32 17
  %t461 = load i64, ptr %l24, !tbaa !24
  %t464 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t460, i64 %t461)
  store i64 %t464, ptr %l271
  br label %bb113
bb113:
  %t465 = load i64, ptr %l271, !tbaa !24
  store i64 %t465, ptr %l33, !tbaa !24
  %t466 = load i64, ptr %l25, !tbaa !24
  store i64 %t466, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t468 = load i64, ptr %l34, !tbaa !24
  %t469 = load i64, ptr %l33, !tbaa !24
  %t472 = icmp sgt i64 %t468, %t469
  br i1 %t472, label %bb114, label %bb115
bb114:
  %t474 = load i64, ptr %l35, !tbaa !24
  %t476 = icmp sgt i64 %t474, 0
  br i1 %t476, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb119
bb116:
  %t478 = load i64, ptr %l34, !tbaa !24
  %t479 = load i64, ptr %l33, !tbaa !24
  %t482 = sub i64 %t478, %t479
  %t483 = load i64, ptr %l35, !tbaa !24
  %t486 = add i64 %t482, %t483
  %t488 = sub i64 %t486, 1
  %t489 = load i64, ptr %l35, !tbaa !24
  %t492 = sdiv i64 %t488, %t489
  store i64 %t492, ptr %l279, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb118
bb118:
  %t494 = load i64, ptr %l279, !tbaa !24
  store i64 %t494, ptr %l276, !tbaa !24
  br label %bb119
bb119:
  %t495 = load i64, ptr %l276, !tbaa !24
  store i64 %t495, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s23
  %t496 = load i64, ptr %l37, !tbaa !24
  %t497 = load i64, ptr %l36, !tbaa !24
  %t500 = icmp slt i64 %t496, %t497
  %t502 = xor i1 %t500, true
  br i1 %t502, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s23)
  br label %bb127
bb122:
  br label %bb123
bb123:
  %t504 = load i64, ptr %l33, !tbaa !24
  %t505 = load i64, ptr %l37, !tbaa !24
  %t506 = load i64, ptr %l35, !tbaa !24
  %t509 = mul i64 %t505, %t506
  %t512 = add i64 %t504, %t509
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l297, !tbaa !29
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/views:Viewer", ptr %t515, i32 0, i32 18
  %t521 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t517, i64 %t512)
  store i64 %t521, ptr %l301
  br label %bb124
bb124:
  %t522 = load ptr, ptr %l297, !tbaa !29
  %t523 = load i64, ptr %l301, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %t522, i64 %t523, i1 false)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s23)
  br label %bb126
bb126:
  %t524 = load i64, ptr %l37, !tbaa !24
  %t526 = add i64 %t524, 1
  store i64 %t526, ptr %l37, !tbaa !24
  br label %bb120
bb127:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/views:Viewer", ptr %t528, i32 0, i32 24
  %t531 = load i1, ptr %t530, !tbaa !21
  %t533 = xor i1 %t531, true
  br i1 %t533, label %bb128, label %bb129
bb128:
  store i1 true, ptr %l307, !tbaa !21
  br label %bb130
bb129:
  %t535 = load i1, ptr %l26, !tbaa !21
  %t537 = xor i1 %t535, true
  store i1 %t537, ptr %l307, !tbaa !21
  br label %bb130
bb130:
  %t539 = load i1, ptr %l307, !tbaa !21
  br i1 %t539, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s21)
  br label %bb135
bb132:
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s21)
  br label %bb134
bb134:
  %t540 = load i64, ptr %l31, !tbaa !24
  %t542 = add i64 %t540, 1
  store i64 %t542, ptr %l31, !tbaa !24
  br label %bb109
bb135:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/views:Viewer", ptr %t544, i32 0, i32 17
  %t547 = load i64, ptr %l24, !tbaa !24
  %t550 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t546, i64 %t547)
  store i64 %t550, ptr %l315
  br label %bb136
bb136:
  %t551 = load i64, ptr %l315, !tbaa !24
  store i64 %t551, ptr %l39, !tbaa !24
  %t552 = load i64, ptr %l25, !tbaa !24
  store i64 %t552, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t554 = load i64, ptr %l40, !tbaa !24
  %t555 = load i64, ptr %l39, !tbaa !24
  %t558 = icmp sgt i64 %t554, %t555
  br i1 %t558, label %bb137, label %bb138
bb137:
  %t560 = load i64, ptr %l41, !tbaa !24
  %t562 = icmp sgt i64 %t560, 0
  br i1 %t562, label %bb139, label %bb140
bb138:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb142
bb139:
  %t564 = load i64, ptr %l40, !tbaa !24
  %t565 = load i64, ptr %l39, !tbaa !24
  %t568 = sub i64 %t564, %t565
  %t569 = load i64, ptr %l41, !tbaa !24
  %t572 = add i64 %t568, %t569
  %t574 = sub i64 %t572, 1
  %t575 = load i64, ptr %l41, !tbaa !24
  %t578 = sdiv i64 %t574, %t575
  store i64 %t578, ptr %l323, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb141
bb141:
  %t580 = load i64, ptr %l323, !tbaa !24
  store i64 %t580, ptr %l320, !tbaa !24
  br label %bb142
bb142:
  %t581 = load i64, ptr %l320, !tbaa !24
  store i64 %t581, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb143
bb143:
  store %olang.scope zeroinitializer, ptr %s28
  %t582 = load i64, ptr %l43, !tbaa !24
  %t583 = load i64, ptr %l42, !tbaa !24
  %t586 = icmp slt i64 %t582, %t583
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb144, label %bb145
bb144:
  call void @__olang_scope_close(ptr %s28)
  br label %bb150
bb145:
  br label %bb146
bb146:
  %t590 = load i64, ptr %l39, !tbaa !24
  %t591 = load i64, ptr %l43, !tbaa !24
  %t592 = load i64, ptr %l41, !tbaa !24
  %t595 = mul i64 %t591, %t592
  %t598 = add i64 %t590, %t595
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l341, !tbaa !29
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = getelementptr %"compiler/views:Viewer", ptr %t601, i32 0, i32 18
  %t607 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t603, i64 %t598)
  store i64 %t607, ptr %l345
  br label %bb147
bb147:
  %t608 = load ptr, ptr %l341, !tbaa !29
  %t609 = load i64, ptr %l345, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %t608, i64 %t609, i1 true)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s28)
  br label %bb149
bb149:
  %t610 = load i64, ptr %l43, !tbaa !24
  %t612 = add i64 %t610, 1
  store i64 %t612, ptr %l43, !tbaa !24
  br label %bb143
bb150:
  call void @__olang_scope_close(ptr %s19)
  br label %bb151
bb151:
  %t614 = load i64, ptr %l23, !tbaa !24
  %t616 = add i64 %t614, 1
  store i64 %t616, ptr %l23, !tbaa !24
  br label %bb86
bb152:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i8 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i8
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i8 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i64 @compiler_2fviews_2eplaceEnd(ptr %v1, ptr %a2)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = icmp sle i64 %t5, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = icmp sge i64 %t14, %t18
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t24, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l20
  br label %bb8
bb8:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t32, i64 %t33)
  store i8 %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load i8, ptr %l3, !tbaa !22
  %t38 = load i8, ptr %l23, !tbaa !22
  %t40 = icmp ne i8 %t38, %t37
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t44 = load i8, ptr %l3, !tbaa !22
  %t46 = icmp eq i8 %t44, 46
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  %t55 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t49, i64 %t52)
  store i64 %t55, ptr %l33
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/source:Span" %t58, ptr %l34
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t59, ptr %rv
  br label %ret
bb17:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  %t67 = trunc i64 %t65 to i32
  %t70 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t62, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l40
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t71 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Arm", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l8, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Alt", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t28, ptr %t32, ptr %t34, ptr %l4)
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l8, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Alt", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l40, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  store ptr %t62, ptr %l12, !tbaa !29
  %t64 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l43
  br label %bb11
bb11:
  %t65 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l13
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l12, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s4, ptr %t66, ptr %t70, ptr %t72, ptr %l13)
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l12, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Bind", ptr %t78, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %s4, ptr %s4, ptr %v2, ptr %t77, i64 %t83, ptr null, ptr %l13, i1 false, ptr %t84)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l10, !tbaa !24
  br label %bb7
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb2
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Arm", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t97, ptr %t101, ptr %t102, ptr %l4)
  br label %bb18
bb18:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t107, ptr %t111, ptr %t112)
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Arm", ptr %t117, i32 0, i32 4
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t116, ptr %t120, ptr %t121, ptr %a3)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i32, ptr %l8
  %t17 = trunc i64 19 to i32
  %t18 = icmp eq i32 %t15, %t17
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca i1
  %l37 = alloca i1
  %l42 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca %"compiler/views:place"
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca %"compiler/views:place"
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca i64
  %l91 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l5, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t26 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %t20, i64 %t23)
  store i1 %t26, ptr %l25
  br label %bb9
bb9:
  %t27 = load i1, ptr %l25, !tbaa !21
  store i1 %t27, ptr %l6, !tbaa !21
  %t28 = load i1, ptr %l6, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %s3, ptr %v4, ptr %t30, ptr %t31, ptr null, ptr %t32)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t36, i64 %t39, ptr %a2, ptr %t41, i1 true, ptr %t42)
  br label %bb14
bb14:
  %t48 = load i1, ptr %l6, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t52 = load i32, ptr %l5, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t58 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v4, ptr %t50, ptr %t51, i64 %t54)
  store i1 %t58, ptr %l42
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l42, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l37, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load ptr, ptr %l4, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l46, !tbaa !24
  %t67 = load i32, ptr %l5, !tbaa !23
  %t69 = sext i32 %t67 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 1, ptr %t71
  %t73 = insertvalue { i64 } undef, i64 %t69, 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64 } %t73, ptr %t74
  %t75 = load { i64, [2 x i64] }, ptr %t70
  %t77 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s4, { i64, [2 x i64] } %t75, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t77, ptr %l50
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = load %"compiler/views:place", ptr %l50
  call void @compiler_2fviews_2enameAdd(ptr %v4, ptr %t78, i64 %t79, %"compiler/views:place" %t80)
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/views:state", ptr %t81, i32 0, i32 3
  %t84 = load i32, ptr %l5, !tbaa !23
  %t86 = sext i32 %t84 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v4, ptr %t83, i64 %t86)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l55, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 1
  store i1 %t96, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l56, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eparts(ptr %v0, ptr %v1, ptr %v4, ptr %t98, ptr %t99, ptr %t100)
  br label %bb35
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_55308b3b5a1f5c1_cb52dc999ec87de5)
  unreachable
bb37:
  %t104 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l62
  br label %bb38
bb38:
  %t105 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l7
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t108 = load ptr, ptr %l4, !tbaa !29
  %t113 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v4, ptr %s0, ptr %t106, ptr %t107, ptr %t108, ptr %l7)
  store i1 %t113, ptr %l67
  br label %bb39
bb39:
  %t114 = load i1, ptr %l67, !tbaa !21
  br i1 %t114, label %bb40, label %bb41
bb40:
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb42
bb41:
  br label %bb61
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t117 = load i64, ptr %l9, !tbaa !24
  %t120 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t116, i64 %t117)
  %t121 = extractvalue { i32, { i64, ptr } } %t120, 1
  %t122 = extractvalue { i32, { i64, ptr } } %t120, 0
  store i32 %t122, ptr %l73
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb44, label %ok.124
ok.124:
  store { i64, ptr } %t121, ptr %l72
  br label %bb43
bb43:
  %t125 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t125, ptr %l69, !tbaa !27
  br label %bb48
bb44:
  %t126 = load i32, ptr %l73, !tbaa !23
  %t127 = ashr i32 %t126, 16
  %t129 = icmp eq i32 %t127, 1
  br i1 %t129, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_f1fdfe9ad717b630_76506b271b9576b4)
  unreachable
bb47:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb48:
  %t131 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t131, ptr %l10, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t136 = load i64, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t144, ptr %l82, !tbaa !27
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr %"compiler/views:place", ptr %t148, i64 %t145
  %t150 = load %"compiler/views:place", ptr %t149
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l85, !tbaa !29
  store %"compiler/views:place" %t150, ptr %l86
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t154)
  store %"compiler/source:Span" %t156, ptr %l88
  br label %bb53
bb53:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s10, ptr %t157, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i64 %t159, ptr %l90
  br label %bb54
bb54:
  %t160 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 0, i32 0)
  store %"compiler/source:Span" %t160, ptr %l91
  br label %bb55
bb55:
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t162 = load ptr, ptr %l85, !tbaa !29
  %t163 = load %"compiler/views:place", ptr %l86
  %t164 = load %"compiler/source:Span", ptr %l88
  %t165 = load i64, ptr %l90, !tbaa !24
  %t166 = load %"compiler/source:Span", ptr %l91
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v4, ptr %t162, %"compiler/views:place" %t163, %"compiler/source:Span" %t164, i64 %t165, i64 -1, %"compiler/source:Span" %t166, ptr %t161)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l12, !tbaa !24
  br label %bb49
bb58:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load i64, ptr %l11, !tbaa !24
  %t176 = add i64 %t172, %t173
  store i64 %t176, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  br label %bb42
bb60:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t180 = load ptr, ptr %l3, !tbaa !29
  %t182 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t178, ptr %t179, ptr %t180, ptr %t182)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %rv = alloca { i64, [3 x i64] }
  %t24 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 19
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_bb5d94b92cb03aee_965554ec574ba44a)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 19
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 0
  store i64 3, ptr %t25
  %t27 = insertvalue { i64, i64, i64 } undef, i64 %t15, 0
  %t29 = insertvalue { i64, i64, i64 } %t27, i64 %t19, 1
  %t31 = insertvalue { i64, i64, i64 } %t29, i64 %t23, 2
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  store { i64, i64, i64 } %t31, ptr %t32
  %t33 = load { i64, [3 x i64] }, ptr %t24
  store { i64, [3 x i64] } %t33, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %a0, %"compiler/views:place" %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l3 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca %"compiler/views:place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/views:place"
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 3
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = load %"compiler/views:place", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/views:place" %t4, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/views:Viewer", ptr %t10, i32 0, i32 3
  %t13 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t12, i64 %t14)
  store { i64, ptr } %t17, ptr %l14
  br label %bb6
bb5:
  %t18 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l10, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  %t29 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t30 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t30, ptr %l19
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:Viewer", ptr %t32, i32 0, i32 3
  %t35 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t34, i64 %t36)
  store { i64, ptr } %t39, ptr %l24
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/views:Viewer", ptr %t40, i32 0, i32 3
  %t46 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t42, i64 %a2)
  store { i64, ptr } %t46, ptr %l28
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t48, i64 %t49)
  %t55 = getelementptr i8, ptr %t54, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t65 = load ptr, ptr %l20, !tbaa !29
  %t67 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } %t64)
  store i64 %t67, ptr %l31
  br label %bb10
bb10:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = load { i64, [2 x i64] }, ptr %l19
  %t71 = load i64, ptr %l31, !tbaa !24
  %t74 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s0, { i64, [2 x i64] } %t70, i64 %t71, i64 %t68, i1 %a4)
  store %"compiler/views:place" %t74, ptr %l34
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load %"compiler/views:place", ptr %l34
  store %"compiler/views:place" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:place", ptr %rv
  ret %"compiler/views:place" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/views:holding"
  %l13 = alloca %"compiler/views:view"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/views:place"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca %"compiler/views:holding"
  %l68 = alloca i1
  %l77 = alloca %"compiler/views:place"
  %l79 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca %"compiler/views:holding"
  %l91 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i1
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l116 = alloca { i64, ptr }
  %l121 = alloca i1
  %l131 = alloca i64
  %l133 = alloca i1
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i32
  %l150 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l173 = alloca %"compiler/typed:Local"
  %l175 = alloca i1
  %l178 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i32
  %l191 = alloca { i64, ptr }
  %l197 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t86 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load ptr, ptr %l5, !tbaa !29
  %t5 = getelementptr %"compiler/views:state", ptr %t3, i32 0, i32 1
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t5)
  store i64 %t7, ptr %l37
  br label %bb3
bb2:
  br label %bb82
bb3:
  %t8 = load i64, ptr %l37, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb9
bb6:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l8, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l8, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l44, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l44, !tbaa !24
  store i64 %t35, ptr %l41, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l41, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load i64, ptr %l10, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l11, !tbaa !24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t57, i64 %t58)
  store %"compiler/views:holding" %t61, ptr %l65
  br label %bb14
bb14:
  %t62 = load %"compiler/views:holding", ptr %l65
  store %"compiler/views:holding" %t62, ptr %l12
  %t63 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t64 = getelementptr %"compiler/views:view", ptr %t63, i32 0, i32 0
  %t65 = getelementptr %"compiler/views:place", ptr %t64, i32 0, i32 0
  %t66 = load { i64, [2 x i64] }, ptr %t65
  %t68 = extractvalue { i64, [2 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 1
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t72 = getelementptr %"compiler/views:view", ptr %t71, i32 0, i32 0
  %t73 = getelementptr %"compiler/views:place", ptr %t72, i32 0, i32 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { i64 }, ptr %t74, i32 0, i32 0
  %t76 = load i64, ptr %t75
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = icmp eq i64 %t76, %t77
  store i1 %t80, ptr %l68, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb17
bb17:
  %t82 = load i1, ptr %l68, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t84 = load %"compiler/views:view", ptr %t83
  store %"compiler/views:view" %t84, ptr %l13
  store { i64, [2 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 0
  store i64 0, ptr %t87
  %t88 = load { i64, [2 x i64] }, ptr %t86
  %t89 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t90 = getelementptr %"compiler/views:place", ptr %t89, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t93 = getelementptr %"compiler/views:place", ptr %t92, i32 0, i32 2
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t96 = getelementptr %"compiler/views:place", ptr %t95, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  %t102 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s4, { i64, [2 x i64] } %t88, i64 %t91, i64 %t94, i1 %t97)
  store %"compiler/views:place" %t102, ptr %l77
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t103 = load %"compiler/views:place", ptr %l77
  %t104 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  store %"compiler/views:place" %t103, ptr %t104
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/views:state", ptr %t105, i32 0, i32 1
  store ptr %t107, ptr %l79, !tbaa !29
  %t108 = load i64, ptr %l11, !tbaa !24
  store i64 %t108, ptr %l80, !tbaa !24
  %t109 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 0
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = load %"compiler/views:view", ptr %l13
  %t114 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s4, i64 %t110, %"compiler/views:view" %t111)
  store %"compiler/views:holding" %t114, ptr %l83
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l79, !tbaa !29
  %t116 = load i64, ptr %l80, !tbaa !24
  %t117 = load %"compiler/views:holding", ptr %l83
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v3, ptr %t115, i64 %t116, %"compiler/views:holding" %t117)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l10, !tbaa !24
  br label %bb10
bb25:
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eforget(ptr %v3, ptr %t122, i64 %t123)
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb27, label %bb28
bb27:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l92, !tbaa !29
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t133)
  store i32 %t135, ptr %l94
  br label %bb29
bb28:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb31
bb29:
  %t136 = load ptr, ptr %l92, !tbaa !29
  %t137 = load i32, ptr %l94, !tbaa !23
  %t138 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load i1, ptr %l95, !tbaa !21
  store i1 %t139, ptr %l91, !tbaa !21
  br label %bb31
bb31:
  %t140 = load i1, ptr %l91, !tbaa !21
  br i1 %t140, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %l96
  br label %bb34
bb33:
  br label %bb81
bb34:
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %l14
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l2, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s6, ptr %t143, ptr %t144, ptr %t146, ptr %l14)
  br label %bb35
bb35:
  store i1 false, ptr %l15, !tbaa !21
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t152 = load ptr, ptr %l16, !tbaa !29
  %t153 = load i64, ptr %l17, !tbaa !24
  %t156 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t152, i64 %t153)
  %t157 = extractvalue { i32, { i64, ptr } } %t156, 1
  %t158 = extractvalue { i32, { i64, ptr } } %t156, 0
  store i32 %t158, ptr %l107
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb38, label %ok.160
ok.160:
  store { i64, ptr } %t157, ptr %l106
  br label %bb37
bb37:
  %t161 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t161, ptr %l103, !tbaa !27
  br label %bb42
bb38:
  %t162 = load i32, ptr %l107, !tbaa !23
  %t163 = ashr i32 %t162, 16
  %t165 = icmp eq i32 %t163, 1
  br i1 %t165, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4fa08be5080f30fb_a534acff1333321f)
  unreachable
bb41:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb42:
  %t167 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t167, ptr %l18, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t172 = load i64, ptr %l20, !tbaa !24
  %t173 = load i64, ptr %l19, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb45:
  br label %bb46
bb46:
  %t180 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t180, ptr %l116, !tbaa !27
  %t181 = load i64, ptr %l20, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/views:place", ptr %t184, i64 %t181
  %t186 = load %"compiler/views:place", ptr %t185
  store %"compiler/views:place" %t186, ptr %l21
  %t188 = getelementptr %"compiler/views:place", ptr %l21, i32 0, i32 0
  %t189 = load { i64, [2 x i64] }, ptr %t188
  %t191 = extractvalue { i64, [2 x i64] } %t189, 0
  %t192 = icmp eq i64 %t191, 1
  br i1 %t192, label %bb47, label %bb48
bb47:
  %t194 = getelementptr %"compiler/views:place", ptr %l21, i32 0, i32 0
  %t195 = getelementptr { i64, [2 x i64] }, ptr %t194, i32 0, i32 1
  %t196 = getelementptr { i64 }, ptr %t195, i32 0, i32 0
  %t197 = load i64, ptr %t196
  %t198 = load i64, ptr %l1, !tbaa !24
  %t201 = icmp eq i64 %t197, %t198
  store i1 %t201, ptr %l121, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb49
bb49:
  %t203 = load i1, ptr %l121, !tbaa !21
  br i1 %t203, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb52
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  %t204 = load i64, ptr %l20, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l20, !tbaa !24
  br label %bb43
bb54:
  %t208 = load i64, ptr %l17, !tbaa !24
  %t209 = load i64, ptr %l19, !tbaa !24
  %t212 = add i64 %t208, %t209
  store i64 %t212, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb36
bb56:
  %t215 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %l14)
  store i64 %t215, ptr %l131
  br label %bb57
bb57:
  %t216 = load i64, ptr %l131, !tbaa !24
  %t217 = icmp sgt i64 %t216, 0
  br i1 %t217, label %bb58, label %bb59
bb58:
  %t219 = load i1, ptr %l15, !tbaa !21
  %t221 = xor i1 %t219, true
  store i1 %t221, ptr %l133, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb60
bb60:
  %t223 = load i1, ptr %l133, !tbaa !21
  br i1 %t223, label %bb61, label %bb62
bb61:
  store ptr %l14, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb63
bb62:
  br label %bb80
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t225 = load ptr, ptr %l22, !tbaa !29
  %t226 = load i64, ptr %l23, !tbaa !24
  %t229 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t225, i64 %t226)
  %t230 = extractvalue { i32, { i64, ptr } } %t229, 1
  %t231 = extractvalue { i32, { i64, ptr } } %t229, 0
  store i32 %t231, ptr %l141
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb65, label %ok.233
ok.233:
  store { i64, ptr } %t230, ptr %l140
  br label %bb64
bb64:
  %t234 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t234, ptr %l137, !tbaa !27
  br label %bb69
bb65:
  %t235 = load i32, ptr %l141, !tbaa !23
  %t236 = ashr i32 %t235, 16
  %t238 = icmp eq i32 %t236, 1
  br i1 %t238, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_a1022307f3790c7a_3cd5ac67c586c79e)
  unreachable
bb68:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb69:
  %t240 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t240, ptr %l24, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  store i64 %t243, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s15
  %t245 = load i64, ptr %l26, !tbaa !24
  %t246 = load i64, ptr %l25, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s15)
  br label %bb76
bb72:
  br label %bb73
bb73:
  %t253 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t253, ptr %l150, !tbaa !27
  %t254 = load i64, ptr %l26, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr %"compiler/views:place", ptr %t257, i64 %t254
  %t259 = load %"compiler/views:place", ptr %t258
  %t261 = load ptr, ptr %l5, !tbaa !29
  %t262 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2enameAdd(ptr %v3, ptr %t261, i64 %t262, %"compiler/views:place" %t259)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s15)
  br label %bb75
bb75:
  %t267 = load i64, ptr %l26, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l26, !tbaa !24
  br label %bb70
bb76:
  %t271 = load i64, ptr %l23, !tbaa !24
  %t272 = load i64, ptr %l25, !tbaa !24
  %t275 = add i64 %t271, %t272
  store i64 %t275, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb77:
  br label %bb63
bb78:
  %t277 = load ptr, ptr %l5, !tbaa !29
  %t279 = getelementptr %"compiler/views:state", ptr %t277, i32 0, i32 3
  %t280 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t279, i64 %t280)
  br label %bb79
bb79:
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s6)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l164, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/views:Viewer", ptr %t284, i32 0, i32 19
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  br i1 %t289, label %bb83, label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_c9ea8b11de61d962_c452a48e933af9d6)
  unreachable
bb84:
  br label %bb85
bb85:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/views:Viewer", ptr %t291, i32 0, i32 19
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Body", ptr %t294, i32 0, i32 7
  %t298 = load i64, ptr %l1, !tbaa !24
  %t301 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t297, i64 %t298)
  store %"compiler/typed:Local" %t301, ptr %l173
  br label %bb86
bb86:
  %t302 = getelementptr %"compiler/typed:Local", ptr %l173, i32 0, i32 2
  %t303 = load i32, ptr %t302, !tbaa !23
  %t304 = load ptr, ptr %l164, !tbaa !29
  %t306 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t304, i32 %t303)
  store i1 %t306, ptr %l175
  br label %bb87
bb87:
  %t307 = load i1, ptr %l175, !tbaa !21
  %t308 = xor i1 %t307, true
  br i1 %t308, label %bb88, label %bb89
bb88:
  br label %ret
bb89:
  br label %bb90
bb90:
  store ptr %a3, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s19
  %t312 = load ptr, ptr %l28, !tbaa !29
  %t313 = load i64, ptr %l29, !tbaa !24
  %t316 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t312, i64 %t313)
  %t317 = extractvalue { i32, { i64, ptr } } %t316, 1
  %t318 = extractvalue { i32, { i64, ptr } } %t316, 0
  store i32 %t318, ptr %l182
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb93, label %ok.320
ok.320:
  store { i64, ptr } %t317, ptr %l181
  br label %bb92
bb92:
  %t321 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t321, ptr %l178, !tbaa !27
  br label %bb97
bb93:
  %t322 = load i32, ptr %l182, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  br i1 %t325, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_50963a3b337a0d80_c66eda0c55543fe4)
  unreachable
bb96:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s19)
  br label %bb106
bb97:
  %t327 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t327, ptr %l30, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  store i64 %t330, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s20
  %t332 = load i64, ptr %l32, !tbaa !24
  %t333 = load i64, ptr %l31, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s20)
  br label %bb104
bb100:
  br label %bb101
bb101:
  %t340 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t340, ptr %l191, !tbaa !27
  %t341 = load i64, ptr %l32, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr %"compiler/views:view", ptr %t344, i64 %t341
  %t346 = load %"compiler/views:view", ptr %t345
  %t348 = load ptr, ptr %l5, !tbaa !29
  %t349 = load i64, ptr %l1, !tbaa !24
  %t354 = call i1 @compiler_2fviews_2eholdAdd(ptr %v3, ptr %t348, i64 %t349, %"compiler/views:view" %t346)
  store i1 %t354, ptr %l197
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s20)
  br label %bb103
bb103:
  %t355 = load i64, ptr %l32, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l32, !tbaa !24
  br label %bb98
bb104:
  %t359 = load i64, ptr %l29, !tbaa !24
  %t360 = load i64, ptr %l31, !tbaa !24
  %t363 = add i64 %t359, %t360
  store i64 %t363, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb105
bb105:
  br label %bb91
bb106:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i1
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 0
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t35, ptr %t36, ptr %t38)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb4
bb13:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/views:state", ptr %t46, i32 0, i32 0
  %t49 = load i1, ptr %t48, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Block", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp sge i64 %t60, 0
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Block", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l41, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l8, !tbaa !29
  %t77 = load ptr, ptr %l8, !tbaa !29
  store ptr %t77, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l45, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l45, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l8, !tbaa !29
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr }, ptr %t88, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l9, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t95 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t93, ptr %t95)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_f4d9265444485b3d_7f3b362071bb80f9)
  unreachable
bb32:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = sub i64 %t99, 1
  store i64 %t101, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  br label %bb17
bb34:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = call ptr @compiler_2fviews_2eunAway(ptr %v1, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  store ptr %t19, ptr %l5, !tbaa !29
  %t20 = load ptr, ptr %l5, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l6, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t37, ptr %t38)
  store i1 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1bacef8f79fa259f_b65daa57821eac43)
  unreachable
bb18:
  br label %bb43
bb19:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l7, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t62, i32 0, i32 3
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb24
bb23:
  br label %bb38
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l36, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t67)
  store i32 %t69, ptr %l38
  br label %bb25
bb25:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l38, !tbaa !23
  %t72 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t72, ptr %l39
  br label %bb26
bb26:
  %t73 = load i1, ptr %l39, !tbaa !21
  br i1 %t73, label %bb27, label %bb28
bb27:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l42, !tbaa !29
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t76)
  store i32 %t78, ptr %l44
  br label %bb29
bb28:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb33
bb29:
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = load i32, ptr %l44, !tbaa !23
  %t81 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t81, ptr %l45
  br label %bb30
bb30:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t84 = load i32, ptr %l45, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %s4, ptr %t83, i32 %t84, i64 %t82)
  store { i64, ptr } %t86, ptr %l47
  br label %bb31
bb31:
  %t87 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t93, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t95, ptr %l49
  br label %bb32
bb32:
  %t96 = load i1, ptr %l49, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l7, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erecordPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t98, ptr %t99, ptr %t100, ptr %t101)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_b34deef82c4dbb1e_7a61043bb66e64c2)
  unreachable
bb43:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/views:fact"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca %"compiler/views:place"
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca %"compiler/views:view"
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/views:fact"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca i64
  %l121 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca %"compiler/views:place"
  %l128 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca %"compiler/views:fact"
  %l134 = alloca ptr
  %l135 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca ptr
  %l139 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l160 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l165 = alloca i64
  %l168 = alloca i64
  %l186 = alloca ptr
  %l187 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l188 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l197 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca ptr
  %l208 = alloca { i64, ptr }
  %l210 = alloca i64
  %l213 = alloca i1
  %l217 = alloca ptr
  %l220 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l221 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l222 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l227 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l234 = alloca i32
  %l243 = alloca { i64, ptr }
  %l248 = alloca ptr
  %l255 = alloca %"compiler/views:place"
  %l263 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l266 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l277 = alloca i32
  %l286 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l295 = alloca %"compiler/views:place"
  %l313 = alloca ptr
  %l316 = alloca ptr
  %l319 = alloca i32
  %l320 = alloca i32
  %l321 = alloca { i64, ptr }
  %l326 = alloca i64
  %l329 = alloca i64
  %l348 = alloca { i64, ptr }
  %l351 = alloca ptr
  %l353 = alloca i32
  %l354 = alloca i1
  %l360 = alloca i1
  %l364 = alloca { i64, ptr }
  %l367 = alloca i1
  %l368 = alloca i1
  %l372 = alloca { i64, ptr }
  %l375 = alloca i64
  %l379 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l386 = alloca { i64, ptr }
  %l389 = alloca { i64, ptr }
  %l390 = alloca i32
  %l399 = alloca { i64, ptr }
  %l402 = alloca ptr
  %l403 = alloca { i64, [2 x i64] }
  %l404 = alloca i64
  %l408 = alloca { i64, ptr }
  %l410 = alloca %"compiler/views:place"
  %l412 = alloca ptr
  %l413 = alloca %"compiler/source:Span"
  %l423 = alloca i1
  %l427 = alloca i1
  %l435 = alloca i64
  %l438 = alloca i64
  %l458 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l460 = alloca { i64, ptr }
  %l463 = alloca { i64, ptr }
  %l464 = alloca i32
  %l473 = alloca { i64, ptr }
  %l478 = alloca i64
  %l482 = alloca i64
  %l485 = alloca i64
  %l503 = alloca ptr
  %l504 = alloca %"compiler/views:place"
  %l507 = alloca %"compiler/views:place"
  %l508 = alloca i1
  %l512 = alloca { i64, ptr }
  %l515 = alloca %"compiler/source:Span"
  %l518 = alloca i1
  %l521 = alloca { i64, ptr }
  %l525 = alloca ptr
  %l528 = alloca { i64, [3 x i64] }
  %l529 = alloca { i64, ptr }
  %l533 = alloca { i64, ptr }
  %l536 = alloca %"compiler/msgs:Msg"
  %l537 = alloca i64
  %l539 = alloca i1
  %l542 = alloca i64
  %l544 = alloca i1
  %l546 = alloca ptr
  %l549 = alloca i64
  %l550 = alloca i1
  %l555 = alloca ptr
  %l556 = alloca i64
  %l559 = alloca i64
  %l562 = alloca %"compiler/source:Span"
  %l564 = alloca i64
  %l567 = alloca %"compiler/source:Span"
  %l570 = alloca { i64, [3 x i64] }
  %l574 = alloca { i64, ptr }
  %l575 = alloca %"compiler/msgs:Msg"
  %l586 = alloca i64
  %l590 = alloca i64
  %l593 = alloca i64
  %l611 = alloca ptr
  %l614 = alloca %"compiler/views:place"
  %l615 = alloca %"compiler/source:Span"
  %l616 = alloca i64
  %l619 = alloca i64
  %l622 = alloca %"compiler/source:Span"
  %l627 = alloca { i64, ptr }
  %l630 = alloca { i64, ptr }
  %l631 = alloca i32
  %l640 = alloca { i64, ptr }
  %l650 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l655 = alloca i64
  %l658 = alloca i64
  %l683 = alloca ptr
  %l686 = alloca { i64, ptr }
  %l689 = alloca { i64, ptr }
  %l690 = alloca i32
  %l699 = alloca { i64, ptr }
  %l704 = alloca i1
  %l710 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l713 = alloca { i64, ptr }
  %l720 = alloca { i64, ptr }
  %l723 = alloca { i64, ptr }
  %l724 = alloca i32
  %l733 = alloca { i64, ptr }
  %l736 = alloca ptr
  %l742 = alloca %"compiler/views:place"
  %l745 = alloca %"compiler/views:view"
  %l758 = alloca i1
  %l763 = alloca i64
  %l766 = alloca i64
  %l786 = alloca i1
  %l788 = alloca i1
  %l791 = alloca i1
  %l794 = alloca i1
  %l795 = alloca i64
  %l799 = alloca ptr
  %l802 = alloca i64
  %l804 = alloca i1
  %l808 = alloca ptr
  %l812 = alloca i1
  %l816 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l818 = alloca { i64, ptr }
  %l821 = alloca { i64, ptr }
  %l822 = alloca i32
  %l831 = alloca { i64, ptr }
  %l842 = alloca i1
  %l843 = alloca ptr
  %l845 = alloca { i64, ptr }
  %l848 = alloca i32
  %l849 = alloca i1
  %l850 = alloca i1
  %l853 = alloca i1
  %l854 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l857 = alloca { i64, ptr }
  %l864 = alloca { i64, ptr }
  %l867 = alloca { i64, ptr }
  %l868 = alloca i32
  %l877 = alloca { i64, ptr }
  %l880 = alloca ptr
  %l881 = alloca { i64, [2 x i64] }
  %l882 = alloca i64
  %l886 = alloca { i64, ptr }
  %l888 = alloca %"compiler/views:place"
  %l891 = alloca %"compiler/views:view"
  %l900 = alloca i1
  %l907 = alloca ptr
  %l910 = alloca { i64, ptr }
  %l913 = alloca { i64, ptr }
  %l914 = alloca i32
  %l923 = alloca { i64, ptr }
  %l928 = alloca i1
  %l932 = alloca i1
  %l935 = alloca i1
  %l939 = alloca i1
  %l942 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l944 = alloca i64
  %l947 = alloca { i64, ptr }
  %l950 = alloca ptr
  %l952 = alloca ptr
  %l954 = alloca i32
  %l957 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s69 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s76 = alloca %olang.scope
  %s81 = alloca %olang.scope
  %s82 = alloca %olang.scope
  %t245 = alloca { i64, [2 x i64] }, align 8
  %t905 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l135
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  store i64 -1, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Call", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l9, !tbaa !29
  store ptr %t8, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t9 = load ptr, ptr %l138, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l138, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l139, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l139, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = getelementptr { i64, [3 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l10, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t23 = load i32, ptr %l10, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb19
bb7:
  %t27 = load ptr, ptr %l9, !tbaa !29
  store ptr %t27, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t28 = load ptr, ptr %l146, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l146, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l147, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l147, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l9, !tbaa !29
  %t38 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { ptr }, ptr %t38, i32 0, i32 0
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l11, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  store i1 true, ptr %l8, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t42, ptr %t43, ptr %t45, ptr %l6)
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f56dc5f524947092_cf97541144f04b56)
  unreachable
bb19:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Call", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l12, !tbaa !24
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l160
  br label %bb20
bb20:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l160
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t59 = load i64, ptr %l12, !tbaa !24
  store i64 %t59, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t61 = load i64, ptr %l15, !tbaa !24
  %t62 = load i64, ptr %l14, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load i64, ptr %l16, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb26
bb23:
  %t71 = load i64, ptr %l15, !tbaa !24
  %t72 = load i64, ptr %l14, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l16, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l16, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l168, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb25
bb25:
  %t87 = load i64, ptr %l168, !tbaa !24
  store i64 %t87, ptr %l165, !tbaa !24
  br label %bb26
bb26:
  %t88 = load i64, ptr %l165, !tbaa !24
  store i64 %t88, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load i64, ptr %l18, !tbaa !24
  %t90 = load i64, ptr %l17, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l18, !tbaa !24
  %t99 = load i64, ptr %l16, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l19, !tbaa !24
  store ptr %l13, ptr %l186, !tbaa !29
  %t107 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l187
  br label %bb31
bb31:
  %t108 = load ptr, ptr %l186, !tbaa !29
  %t109 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H9aa2f94df86a2febe7e9c453722bc668(ptr %s0, ptr %s0, ptr %t108, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t109)
  br label %bb32
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l188, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l190, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  store ptr %t120, ptr %l193, !tbaa !29
  %t122 = load ptr, ptr %l4, !tbaa !29
  store ptr %t122, ptr %l194, !tbaa !29
  %t123 = load i64, ptr %l19, !tbaa !24
  %t126 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t123)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %l197
  br label %bb33
bb33:
  %t127 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l197
  %t128 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %t128
  %t129 = load ptr, ptr %l188, !tbaa !29
  %t130 = load ptr, ptr %l193, !tbaa !29
  %t131 = load ptr, ptr %l194, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t129, ptr %t130, ptr %t131, ptr %t128)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t133 = load i64, ptr %l18, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l18, !tbaa !24
  br label %bb27
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t143 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %t137, %"compiler/source:Span" %a1, ptr %t139)
  store %"compiler/source:Span" %t143, ptr %l204
  br label %bb37
bb37:
  %t144 = load %"compiler/source:Span", ptr %l204
  store %"compiler/source:Span" %t144, ptr %l20
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l205, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i64, ptr %l7, !tbaa !24
  %t150 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2equoted(ptr %v0, ptr %s0, ptr %t146, i64 %t147)
  store { i64, ptr } %t150, ptr %l208
  br label %bb38
bb38:
  %t151 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr %l205, !tbaa !29
  %t160 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t158, { i64, ptr } %t157)
  store i64 %t160, ptr %l210
  br label %bb39
bb39:
  %t161 = load i64, ptr %l210, !tbaa !24
  store i64 %t161, ptr %l21, !tbaa !24
  %t162 = load i64, ptr %l7, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/views:Viewer", ptr %t166, i32 0, i32 2
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t168, i64 %t169)
  store ptr %t172, ptr %l217
  br label %bb42
bb41:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb43
bb42:
  %t173 = load ptr, ptr %l217, !tbaa !29
  %t175 = getelementptr %"compiler/views:summary", ptr %t173, i32 0, i32 4
  %t176 = load i1, ptr %t175, !tbaa !21
  store i1 %t176, ptr %l213, !tbaa !21
  br label %bb43
bb43:
  %t178 = load i1, ptr %l213, !tbaa !21
  store i1 %t178, ptr %l22, !tbaa !21
  %t179 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l220
  br label %bb44
bb44:
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l220
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l23
  %t181 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t181, ptr %l221
  br label %bb45
bb45:
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l221
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l24
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l222
  br label %bb46
bb46:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l222
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %l25
  %t185 = load i1, ptr %l22, !tbaa !21
  br i1 %t185, label %bb47, label %bb48
bb47:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/views:Viewer", ptr %t187, i32 0, i32 2
  %t190 = load i64, ptr %l7, !tbaa !24
  %t193 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t189, i64 %t190)
  store ptr %t193, ptr %l227
  br label %bb49
bb48:
  %t194 = load i1, ptr %l8, !tbaa !21
  br i1 %t194, label %bb96, label %bb97
bb49:
  %t196 = load ptr, ptr %l227, !tbaa !29
  %t198 = getelementptr %"compiler/views:summary", ptr %t196, i32 0, i32 0
  store ptr %t198, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t200 = load ptr, ptr %l26, !tbaa !29
  %t201 = load i64, ptr %l27, !tbaa !24
  %t204 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t200, i64 %t201)
  %t205 = extractvalue { i32, { i64, ptr } } %t204, 1
  %t206 = extractvalue { i32, { i64, ptr } } %t204, 0
  store i32 %t206, ptr %l234
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb52, label %ok.208
ok.208:
  store { i64, ptr } %t205, ptr %l233
  br label %bb51
bb51:
  %t209 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t209, ptr %l230, !tbaa !27
  br label %bb56
bb52:
  %t210 = load i32, ptr %l234, !tbaa !23
  %t211 = ashr i32 %t210, 16
  %t213 = icmp eq i32 %t211, 1
  br i1 %t213, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_32ad0239e45c9a93_b06e8acfe17eaf77)
  unreachable
bb55:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb95
bb56:
  %t215 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t215, ptr %l28, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 0
  store i64 %t218, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  %t220 = load i64, ptr %l30, !tbaa !24
  %t221 = load i64, ptr %l29, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb93
bb59:
  br label %bb60
bb60:
  %t228 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t228, ptr %l243, !tbaa !27
  %t229 = load i64, ptr %l30, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr %"compiler/views:fact", ptr %t232, i64 %t229
  %t234 = load %"compiler/views:fact", ptr %t233
  store %"compiler/views:fact" %t234, ptr %l31
  %t236 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 0
  %t237 = load i64, ptr %t236, !tbaa !24
  %t239 = icmp slt i64 %t237, 0
  br i1 %t239, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l23, ptr %l248, !tbaa !29
  %t241 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 1
  %t242 = load i64, ptr %t241, !tbaa !24
  %t243 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 2
  %t244 = load i32, ptr %t243, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t245
  %t246 = getelementptr { i64, [2 x i64] }, ptr %t245, i32 0, i32 0
  store i64 3, ptr %t246
  %t248 = insertvalue { i64, i32 } undef, i64 %t242, 0
  %t250 = insertvalue { i64, i32 } %t248, i32 %t244, 1
  %t251 = getelementptr { i64, [2 x i64] }, ptr %t245, i32 0, i32 1
  store { i64, i32 } %t250, ptr %t251
  %t252 = load { i64, [2 x i64] }, ptr %t245
  %t253 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 3
  %t254 = load i64, ptr %t253, !tbaa !24
  %t255 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 4
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 5
  %t258 = load i1, ptr %t257, !tbaa !21
  %t263 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s11, { i64, [2 x i64] } %t252, i64 %t254, i64 %t256, i1 %t258)
  store %"compiler/views:place" %t263, ptr %l255
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t264 = load ptr, ptr %l248, !tbaa !29
  %t265 = load %"compiler/views:place", ptr %l255
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t264, %"compiler/views:place" %t265)
  br label %bb64
bb64:
  %t266 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 6
  %t267 = load i64, ptr %t266, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 %t267)
  br label %bb65
bb65:
  %t270 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 7
  %t271 = load %"compiler/source:Span", ptr %t270
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, %"compiler/source:Span" %t271)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  br label %bb92
bb67:
  %t274 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 0
  %t275 = load i64, ptr %t274, !tbaa !24
  %t276 = load i64, ptr %l12, !tbaa !24
  %t279 = icmp sge i64 %t275, %t276
  br i1 %t279, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb92
bb69:
  br label %bb70
bb70:
  %t281 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t281, ptr %l263
  br label %bb71
bb71:
  %t282 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l263
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t282, ptr %l32
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l3, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Call", ptr %t284, i32 0, i32 1
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  store { i64, ptr } %t287, ptr %l266, !tbaa !27
  %t288 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 0
  %t289 = load i64, ptr %t288, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 %t289
  %t294 = load ptr, ptr %t293, !tbaa !39
  %t296 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s10, ptr %t283, ptr %t294, ptr %t296, ptr %l32)
  br label %bb72
bb72:
  store ptr %l32, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t302 = load ptr, ptr %l33, !tbaa !29
  %t303 = load i64, ptr %l34, !tbaa !24
  %t306 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s10, ptr %t302, i64 %t303)
  %t307 = extractvalue { i32, { i64, ptr } } %t306, 1
  %t308 = extractvalue { i32, { i64, ptr } } %t306, 0
  store i32 %t308, ptr %l277
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb75, label %ok.310
ok.310:
  store { i64, ptr } %t307, ptr %l276
  br label %bb74
bb74:
  %t311 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t311, ptr %l273, !tbaa !27
  br label %bb79
bb75:
  %t312 = load i32, ptr %l277, !tbaa !23
  %t313 = ashr i32 %t312, 16
  %t315 = icmp eq i32 %t313, 1
  br i1 %t315, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_4a2a6e3b3b101678_6265cdfc823cfbbc)
  unreachable
bb78:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb91
bb79:
  %t317 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t317, ptr %l35, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  store i64 %t320, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s15
  %t322 = load i64, ptr %l37, !tbaa !24
  %t323 = load i64, ptr %l36, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s15)
  br label %bb89
bb82:
  br label %bb83
bb83:
  %t330 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t330, ptr %l286, !tbaa !27
  %t331 = load i64, ptr %l37, !tbaa !24
  %t333 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr %"compiler/views:place", ptr %t334, i64 %t331
  %t336 = load %"compiler/views:place", ptr %t335
  store ptr %l23, ptr %l289, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 3
  %t341 = load i64, ptr %t340, !tbaa !24
  %t342 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 4
  %t343 = load i64, ptr %t342, !tbaa !24
  %t344 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 5
  %t345 = load i1, ptr %t344, !tbaa !21
  %t351 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t338, %"compiler/views:place" %t336, i64 %t341, i64 %t343, i1 %t345)
  store %"compiler/views:place" %t351, ptr %l295
  br label %bb84
bb84:
  %t352 = load ptr, ptr %l289, !tbaa !29
  %t353 = load %"compiler/views:place", ptr %l295
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t352, %"compiler/views:place" %t353)
  br label %bb85
bb85:
  %t354 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 6
  %t355 = load i64, ptr %t354, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 %t355)
  br label %bb86
bb86:
  %t358 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 7
  %t359 = load %"compiler/source:Span", ptr %t358
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, %"compiler/source:Span" %t359)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb88:
  %t362 = load i64, ptr %l37, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l37, !tbaa !24
  br label %bb80
bb89:
  %t366 = load i64, ptr %l34, !tbaa !24
  %t367 = load i64, ptr %l36, !tbaa !24
  %t370 = add i64 %t366, %t367
  store i64 %t370, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb90:
  br label %bb73
bb91:
  call void @__olang_scope_close(ptr %s10)
  br label %bb92
bb92:
  %t372 = load i64, ptr %l30, !tbaa !24
  %t374 = add i64 %t372, 1
  store i64 %t374, ptr %l30, !tbaa !24
  br label %bb57
bb93:
  %t376 = load i64, ptr %l27, !tbaa !24
  %t377 = load i64, ptr %l29, !tbaa !24
  %t380 = add i64 %t376, %t377
  store i64 %t380, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb94
bb94:
  br label %bb50
bb95:
  br label %bb153
bb96:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/views:Viewer", ptr %t382, i32 0, i32 0
  %t385 = load ptr, ptr %t384, !tbaa !29
  %t387 = getelementptr %"compiler/generic:Program", ptr %t385, i32 0, i32 2
  store ptr %t387, ptr %l313, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/views:Viewer", ptr %t388, i32 0, i32 0
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  store ptr %t393, ptr %l316, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load ptr, ptr %l3, !tbaa !29
  %t398 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecalleeType(ptr %v0, ptr %v1, ptr %t394, ptr %t395)
  store i32 %t398, ptr %l319
  br label %bb98
bb97:
  br label %bb152
bb98:
  %t399 = load ptr, ptr %l316, !tbaa !29
  %t400 = load i32, ptr %l319, !tbaa !23
  %t401 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t399, i32 %t400)
  store i32 %t401, ptr %l320
  br label %bb99
bb99:
  %t402 = load ptr, ptr %l313, !tbaa !29
  %t403 = load i32, ptr %l320, !tbaa !23
  %t404 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t402, i32 %t403)
  store { i64, ptr } %t404, ptr %l321
  br label %bb100
bb100:
  %t405 = load { i64, ptr }, ptr %l321, !tbaa !27
  store { i64, ptr } %t405, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t406 = load i64, ptr %l12, !tbaa !24
  store i64 %t406, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t408 = load i64, ptr %l41, !tbaa !24
  %t409 = load i64, ptr %l40, !tbaa !24
  %t412 = icmp sgt i64 %t408, %t409
  br i1 %t412, label %bb101, label %bb102
bb101:
  %t414 = load i64, ptr %l42, !tbaa !24
  %t416 = icmp sgt i64 %t414, 0
  br i1 %t416, label %bb103, label %bb104
bb102:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb106
bb103:
  %t418 = load i64, ptr %l41, !tbaa !24
  %t419 = load i64, ptr %l40, !tbaa !24
  %t422 = sub i64 %t418, %t419
  %t423 = load i64, ptr %l42, !tbaa !24
  %t426 = add i64 %t422, %t423
  %t428 = sub i64 %t426, 1
  %t429 = load i64, ptr %l42, !tbaa !24
  %t432 = sdiv i64 %t428, %t429
  store i64 %t432, ptr %l329, !tbaa !24
  br label %bb105
bb104:
  store i64 0, ptr %l329, !tbaa !24
  br label %bb105
bb105:
  %t434 = load i64, ptr %l329, !tbaa !24
  store i64 %t434, ptr %l326, !tbaa !24
  br label %bb106
bb106:
  %t435 = load i64, ptr %l326, !tbaa !24
  store i64 %t435, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s21
  %t436 = load i64, ptr %l44, !tbaa !24
  %t437 = load i64, ptr %l43, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s21)
  br label %bb151
bb109:
  br label %bb110
bb110:
  %t444 = load i64, ptr %l40, !tbaa !24
  %t445 = load i64, ptr %l44, !tbaa !24
  %t446 = load i64, ptr %l42, !tbaa !24
  %t449 = mul i64 %t445, %t446
  %t452 = add i64 %t444, %t449
  store i64 %t452, ptr %l45, !tbaa !24
  %t454 = load ptr, ptr %l3, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Call", ptr %t454, i32 0, i32 1
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l348, !tbaa !27
  %t458 = load i64, ptr %l45, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr ptr, ptr %t461, i64 %t458
  %t463 = load ptr, ptr %t462, !tbaa !39
  store ptr %t463, ptr %l46, !tbaa !29
  %t465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t465, ptr %l351, !tbaa !29
  %t466 = load ptr, ptr %l46, !tbaa !29
  %t468 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t466)
  store i32 %t468, ptr %l353
  br label %bb111
bb111:
  %t469 = load ptr, ptr %l351, !tbaa !29
  %t470 = load i32, ptr %l353, !tbaa !23
  %t471 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t469, i32 %t470)
  store i1 %t471, ptr %l354
  br label %bb112
bb112:
  %t472 = load i1, ptr %l354, !tbaa !21
  %t473 = xor i1 %t472, true
  br i1 %t473, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb114:
  br label %bb115
bb115:
  %t475 = load i64, ptr %l45, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t481 = icmp slt i64 %t475, %t478
  br i1 %t481, label %bb116, label %bb117
bb116:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/views:Viewer", ptr %t483, i32 0, i32 0
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t488 = getelementptr %"compiler/generic:Program", ptr %t486, i32 0, i32 2
  %t489 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t489, ptr %l364, !tbaa !27
  %t490 = load i64, ptr %l45, !tbaa !24
  %t492 = getelementptr { i64, ptr }, ptr %l364, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr i32, ptr %t493, i64 %t490
  %t495 = load i32, ptr %t494, !tbaa !33
  %t498 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t488, i32 %t495)
  store i1 %t498, ptr %l367
  br label %bb118
bb117:
  store i1 false, ptr %l360, !tbaa !21
  br label %bb119
bb118:
  %t499 = load i1, ptr %l367, !tbaa !21
  store i1 %t499, ptr %l360, !tbaa !21
  br label %bb119
bb119:
  %t500 = load i1, ptr %l360, !tbaa !21
  br i1 %t500, label %bb120, label %bb121
bb120:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/views:Viewer", ptr %t501, i32 0, i32 0
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t506 = getelementptr %"compiler/generic:Program", ptr %t504, i32 0, i32 2
  %t507 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t507, ptr %l372, !tbaa !27
  %t508 = load i64, ptr %l45, !tbaa !24
  %t510 = getelementptr { i64, ptr }, ptr %l372, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr i32, ptr %t511, i64 %t508
  %t513 = load i32, ptr %t512, !tbaa !33
  %t516 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t506, i32 %t513)
  store i64 %t516, ptr %l375
  br label %bb122
bb121:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb123
bb122:
  %t517 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t518 = load i64, ptr %l375, !tbaa !24
  %t520 = and i64 %t518, %t517
  %t522 = icmp eq i64 %t520, 0
  store i1 %t522, ptr %l368, !tbaa !21
  br label %bb123
bb123:
  %t524 = load i1, ptr %l368, !tbaa !21
  br i1 %t524, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb125:
  br label %bb126
bb126:
  %t525 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t525, ptr %l379
  br label %bb127
bb127:
  %t526 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l379
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t526, ptr %l47
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load ptr, ptr %l46, !tbaa !29
  %t530 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s21, ptr %t527, ptr %t528, ptr %t530, ptr %l47)
  br label %bb128
bb128:
  store ptr %l47, ptr %l48, !tbaa !29
  store i64 0, ptr %l49, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s25
  %t536 = load ptr, ptr %l48, !tbaa !29
  %t537 = load i64, ptr %l49, !tbaa !24
  %t540 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s21, ptr %t536, i64 %t537)
  %t541 = extractvalue { i32, { i64, ptr } } %t540, 1
  %t542 = extractvalue { i32, { i64, ptr } } %t540, 0
  store i32 %t542, ptr %l390
  %t543 = icmp ne i32 %t542, 0
  br i1 %t543, label %bb131, label %ok.544
ok.544:
  store { i64, ptr } %t541, ptr %l389
  br label %bb130
bb130:
  %t545 = load { i64, ptr }, ptr %l389, !tbaa !27
  store { i64, ptr } %t545, ptr %l386, !tbaa !27
  br label %bb135
bb131:
  %t546 = load i32, ptr %l390, !tbaa !23
  %t547 = ashr i32 %t546, 16
  %t549 = icmp eq i32 %t547, 1
  br i1 %t549, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_44a8ae07879ec149_8b2f3e17da0f076d)
  unreachable
bb134:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s25)
  br label %bb149
bb135:
  %t551 = load { i64, ptr }, ptr %l386, !tbaa !27
  store { i64, ptr } %t551, ptr %l50, !tbaa !27
  %t552 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t554 = extractvalue { i64, ptr } %t552, 0
  store i64 %t554, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s26
  %t556 = load i64, ptr %l52, !tbaa !24
  %t557 = load i64, ptr %l51, !tbaa !24
  %t560 = icmp slt i64 %t556, %t557
  %t562 = xor i1 %t560, true
  br i1 %t562, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s26)
  br label %bb147
bb138:
  br label %bb139
bb139:
  %t564 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t564, ptr %l399, !tbaa !27
  %t565 = load i64, ptr %l52, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l399, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr %"compiler/views:place", ptr %t568, i64 %t565
  %t570 = load %"compiler/views:place", ptr %t569
  store %"compiler/views:place" %t570, ptr %l53
  store ptr %l23, ptr %l402, !tbaa !29
  %t572 = getelementptr %"compiler/views:place", ptr %l53, i32 0, i32 0
  %t573 = load { i64, [2 x i64] }, ptr %t572
  store { i64, [2 x i64] } %t573, ptr %l403
  %t574 = getelementptr %"compiler/views:place", ptr %l53, i32 0, i32 1
  %t575 = load i64, ptr %t574, !tbaa !24
  store i64 %t575, ptr %l404, !tbaa !24
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/views:Viewer", ptr %t576, i32 0, i32 3
  %t579 = getelementptr %"compiler/views:place", ptr %l53, i32 0, i32 1
  %t580 = load i64, ptr %t579, !tbaa !24
  %t583 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s26, ptr %t578, i64 %t580)
  store { i64, ptr } %t583, ptr %l408
  br label %bb140
bb140:
  %t584 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t584, 0
  %t586 = load { i64, [2 x i64] }, ptr %l403
  %t587 = load i64, ptr %l404, !tbaa !24
  %t589 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s26, { i64, [2 x i64] } %t586, i64 %t587, i64 %t585, i1 true)
  store %"compiler/views:place" %t589, ptr %l410
  br label %bb141
bb141:
  %t590 = load ptr, ptr %l402, !tbaa !29
  %t591 = load %"compiler/views:place", ptr %l410
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t590, %"compiler/views:place" %t591)
  br label %bb142
bb142:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 -1)
  br label %bb143
bb143:
  store ptr %l25, ptr %l412, !tbaa !29
  %t593 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s26, i32 0, i32 0)
  store %"compiler/source:Span" %t593, ptr %l413
  br label %bb144
bb144:
  %t594 = load ptr, ptr %l412, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l413
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %t594, %"compiler/source:Span" %t595)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s26)
  br label %bb146
bb146:
  %t596 = load i64, ptr %l52, !tbaa !24
  %t598 = add i64 %t596, 1
  store i64 %t598, ptr %l52, !tbaa !24
  br label %bb136
bb147:
  %t600 = load i64, ptr %l49, !tbaa !24
  %t601 = load i64, ptr %l51, !tbaa !24
  %t604 = add i64 %t600, %t601
  store i64 %t604, ptr %l49, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb148
bb148:
  br label %bb129
bb149:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb150:
  %t606 = load i64, ptr %l44, !tbaa !24
  %t608 = add i64 %t606, 1
  store i64 %t608, ptr %l44, !tbaa !24
  br label %bb107
bb151:
  br label %bb152
bb152:
  br label %bb153
bb153:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/views:Viewer", ptr %t610, i32 0, i32 21
  %t613 = load i1, ptr %t612, !tbaa !21
  br i1 %t613, label %bb154, label %bb155
bb154:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/views:Viewer", ptr %t615, i32 0, i32 22
  %t618 = load i1, ptr %t617, !tbaa !21
  %t620 = xor i1 %t618, true
  store i1 %t620, ptr %l423, !tbaa !21
  br label %bb156
bb155:
  store i1 false, ptr %l423, !tbaa !21
  br label %bb156
bb156:
  %t622 = load i1, ptr %l423, !tbaa !21
  br i1 %t622, label %bb157, label %bb158
bb157:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/views:Viewer", ptr %t623, i32 0, i32 23
  %t626 = load i1, ptr %t625, !tbaa !21
  %t628 = xor i1 %t626, true
  store i1 %t628, ptr %l427, !tbaa !21
  br label %bb159
bb158:
  store i1 false, ptr %l427, !tbaa !21
  br label %bb159
bb159:
  %t630 = load i1, ptr %l427, !tbaa !21
  br i1 %t630, label %bb160, label %bb161
bb160:
  store i64 0, ptr %l54, !tbaa !24
  %t631 = load i64, ptr %l12, !tbaa !24
  store i64 %t631, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t633 = load i64, ptr %l55, !tbaa !24
  %t634 = load i64, ptr %l54, !tbaa !24
  %t637 = icmp sgt i64 %t633, %t634
  br i1 %t637, label %bb162, label %bb163
bb161:
  br label %bb239
bb162:
  %t639 = load i64, ptr %l56, !tbaa !24
  %t641 = icmp sgt i64 %t639, 0
  br i1 %t641, label %bb164, label %bb165
bb163:
  store i64 0, ptr %l435, !tbaa !24
  br label %bb167
bb164:
  %t643 = load i64, ptr %l55, !tbaa !24
  %t644 = load i64, ptr %l54, !tbaa !24
  %t647 = sub i64 %t643, %t644
  %t648 = load i64, ptr %l56, !tbaa !24
  %t651 = add i64 %t647, %t648
  %t653 = sub i64 %t651, 1
  %t654 = load i64, ptr %l56, !tbaa !24
  %t657 = sdiv i64 %t653, %t654
  store i64 %t657, ptr %l438, !tbaa !24
  br label %bb166
bb165:
  store i64 0, ptr %l438, !tbaa !24
  br label %bb166
bb166:
  %t659 = load i64, ptr %l438, !tbaa !24
  store i64 %t659, ptr %l435, !tbaa !24
  br label %bb167
bb167:
  %t660 = load i64, ptr %l435, !tbaa !24
  store i64 %t660, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb168
bb168:
  store %olang.scope zeroinitializer, ptr %s31
  %t661 = load i64, ptr %l58, !tbaa !24
  %t662 = load i64, ptr %l57, !tbaa !24
  %t665 = icmp slt i64 %t661, %t662
  %t667 = xor i1 %t665, true
  br i1 %t667, label %bb169, label %bb170
bb169:
  call void @__olang_scope_close(ptr %s31)
  br label %bb238
bb170:
  br label %bb171
bb171:
  %t669 = load i64, ptr %l54, !tbaa !24
  %t670 = load i64, ptr %l58, !tbaa !24
  %t671 = load i64, ptr %l56, !tbaa !24
  %t674 = mul i64 %t670, %t671
  %t677 = add i64 %t669, %t674
  store i64 %t677, ptr %l59, !tbaa !24
  store i1 false, ptr %l60, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s32
  %t679 = load i64, ptr %l59, !tbaa !24
  %t682 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t679)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t682, ptr %l458
  br label %bb172
bb172:
  %t683 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l458
  %t684 = call ptr @__olang_scope_alloc_a(ptr %s32, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t683, ptr %t684
  store ptr %t684, ptr %l61, !tbaa !29
  store i64 0, ptr %l62, !tbaa !24
  br label %bb173
bb173:
  store %olang.scope zeroinitializer, ptr %s33
  %t686 = load ptr, ptr %l61, !tbaa !29
  %t687 = load i64, ptr %l62, !tbaa !24
  %t690 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t686, i64 %t687)
  %t691 = extractvalue { i32, { i64, ptr } } %t690, 1
  %t692 = extractvalue { i32, { i64, ptr } } %t690, 0
  store i32 %t692, ptr %l464
  %t693 = icmp ne i32 %t692, 0
  br i1 %t693, label %bb175, label %ok.694
ok.694:
  store { i64, ptr } %t691, ptr %l463
  br label %bb174
bb174:
  %t695 = load { i64, ptr }, ptr %l463, !tbaa !27
  store { i64, ptr } %t695, ptr %l460, !tbaa !27
  br label %bb179
bb175:
  %t696 = load i32, ptr %l464, !tbaa !23
  %t697 = ashr i32 %t696, 16
  %t699 = icmp eq i32 %t697, 1
  br i1 %t699, label %bb176, label %bb177
bb176:
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_76a82bee87fafbee_805dfafaf92c82da)
  unreachable
bb178:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s33)
  br label %bb236
bb179:
  %t701 = load { i64, ptr }, ptr %l460, !tbaa !27
  store { i64, ptr } %t701, ptr %l63, !tbaa !27
  %t702 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t704 = extractvalue { i64, ptr } %t702, 0
  store i64 %t704, ptr %l64, !tbaa !24
  store i64 0, ptr %l65, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s34
  %t706 = load i64, ptr %l65, !tbaa !24
  %t707 = load i64, ptr %l64, !tbaa !24
  %t710 = icmp slt i64 %t706, %t707
  %t712 = xor i1 %t710, true
  br i1 %t712, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s34)
  br label %bb234
bb182:
  br label %bb183
bb183:
  %t714 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t714, ptr %l473, !tbaa !27
  %t715 = load i64, ptr %l65, !tbaa !24
  %t717 = getelementptr { i64, ptr }, ptr %l473, i32 0, i32 1
  %t718 = load ptr, ptr %t717, !tbaa !27
  %t719 = getelementptr %"compiler/views:view", ptr %t718, i64 %t715
  %t720 = load %"compiler/views:view", ptr %t719
  store %"compiler/views:view" %t720, ptr %l66
  %t722 = load i1, ptr %l60, !tbaa !21
  br i1 %t722, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s33)
  br label %bb236
bb185:
  br label %bb186
bb186:
  store i64 0, ptr %l67, !tbaa !24
  %t725 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23)
  store i64 %t725, ptr %l478
  br label %bb187
bb187:
  %t726 = load i64, ptr %l478, !tbaa !24
  store i64 %t726, ptr %l68, !tbaa !24
  store i64 1, ptr %l69, !tbaa !24
  %t727 = load i64, ptr %l68, !tbaa !24
  %t728 = load i64, ptr %l67, !tbaa !24
  %t731 = icmp sgt i64 %t727, %t728
  br i1 %t731, label %bb188, label %bb189
bb188:
  %t733 = load i64, ptr %l69, !tbaa !24
  %t735 = icmp sgt i64 %t733, 0
  br i1 %t735, label %bb190, label %bb191
bb189:
  store i64 0, ptr %l482, !tbaa !24
  br label %bb193
bb190:
  %t737 = load i64, ptr %l68, !tbaa !24
  %t738 = load i64, ptr %l67, !tbaa !24
  %t741 = sub i64 %t737, %t738
  %t742 = load i64, ptr %l69, !tbaa !24
  %t745 = add i64 %t741, %t742
  %t747 = sub i64 %t745, 1
  %t748 = load i64, ptr %l69, !tbaa !24
  %t751 = sdiv i64 %t747, %t748
  store i64 %t751, ptr %l485, !tbaa !24
  br label %bb192
bb191:
  store i64 0, ptr %l485, !tbaa !24
  br label %bb192
bb192:
  %t753 = load i64, ptr %l485, !tbaa !24
  store i64 %t753, ptr %l482, !tbaa !24
  br label %bb193
bb193:
  %t754 = load i64, ptr %l482, !tbaa !24
  store i64 %t754, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb194
bb194:
  store %olang.scope zeroinitializer, ptr %s37
  %t755 = load i64, ptr %l71, !tbaa !24
  %t756 = load i64, ptr %l70, !tbaa !24
  %t759 = icmp slt i64 %t755, %t756
  %t761 = xor i1 %t759, true
  br i1 %t761, label %bb195, label %bb196
bb195:
  call void @__olang_scope_close(ptr %s37)
  br label %bb232
bb196:
  br label %bb197
bb197:
  %t763 = load i64, ptr %l67, !tbaa !24
  %t764 = load i64, ptr %l71, !tbaa !24
  %t765 = load i64, ptr %l69, !tbaa !24
  %t768 = mul i64 %t764, %t765
  %t771 = add i64 %t763, %t768
  store i64 %t771, ptr %l72, !tbaa !24
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l503, !tbaa !29
  %t774 = getelementptr %"compiler/views:view", ptr %l66, i32 0, i32 0
  %t775 = load %"compiler/views:place", ptr %t774
  store %"compiler/views:place" %t775, ptr %l504
  %t776 = load i64, ptr %l72, !tbaa !24
  %t779 = call %"compiler/views:place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23, i64 %t776)
  store %"compiler/views:place" %t779, ptr %l507
  br label %bb198
bb198:
  %t780 = load ptr, ptr %l503, !tbaa !29
  %t781 = load %"compiler/views:place", ptr %l504
  %t782 = load %"compiler/views:place", ptr %l507
  %t783 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t780, %"compiler/views:place" %t781, %"compiler/views:place" %t782)
  store i1 %t783, ptr %l508
  br label %bb199
bb199:
  %t784 = load i1, ptr %l508, !tbaa !21
  %t785 = xor i1 %t784, true
  br i1 %t785, label %bb200, label %bb201
bb200:
  call void @__olang_scope_close(ptr %s37)
  br label %bb231
bb201:
  br label %bb202
bb202:
  store i1 true, ptr %l60, !tbaa !21
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load ptr, ptr %l3, !tbaa !29
  %t790 = getelementptr %"compiler/typed:Call", ptr %t788, i32 0, i32 1
  %t791 = load { i64, ptr }, ptr %t790, !tbaa !27
  store { i64, ptr } %t791, ptr %l512, !tbaa !27
  %t792 = load i64, ptr %l59, !tbaa !24
  %t794 = getelementptr { i64, ptr }, ptr %l512, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !27
  %t796 = getelementptr ptr, ptr %t795, i64 %t792
  %t797 = load ptr, ptr %t796, !tbaa !39
  %t800 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t787, ptr %t797)
  store %"compiler/source:Span" %t800, ptr %l515
  br label %bb203
bb203:
  %t801 = load %"compiler/source:Span", ptr %l515
  store %"compiler/source:Span" %t801, ptr %l73
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t803 = load %"compiler/source:Span", ptr %l73
  %t806 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t802, %"compiler/source:Span" %t803)
  store i1 %t806, ptr %l518
  br label %bb204
bb204:
  %t807 = load i1, ptr %l518, !tbaa !21
  br i1 %t807, label %bb205, label %bb206
bb205:
  call void @__olang_scope_close(ptr %s37)
  br label %bb232
bb206:
  br label %bb207
bb207:
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t809 = getelementptr %"compiler/views:view", ptr %l66, i32 0, i32 0
  %t810 = load %"compiler/views:place", ptr %t809
  %t813 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s37, ptr %t808, %"compiler/views:place" %t810)
  store { i64, ptr } %t813, ptr %l521
  br label %bb208
bb208:
  %t814 = load { i64, ptr }, ptr %l521, !tbaa !27
  store { i64, ptr } %t814, ptr %l74, !tbaa !27
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/views:Viewer", ptr %t815, i32 0, i32 0
  %t818 = load ptr, ptr %t817, !tbaa !29
  %t820 = getelementptr %"compiler/generic:Program", ptr %t818, i32 0, i32 0
  %t821 = load ptr, ptr %t820, !tbaa !29
  %t823 = getelementptr %"compiler/load:Loader", ptr %t821, i32 0, i32 4
  %t824 = load ptr, ptr %t823, !tbaa !29
  store ptr %t824, ptr %l525, !tbaa !29
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load %"compiler/source:Span", ptr %l73
  %t829 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t825, %"compiler/source:Span" %t826)
  store { i64, [3 x i64] } %t829, ptr %l528
  br label %bb209
bb209:
  %t830 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t830, ptr %l529, !tbaa !27
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t833 = getelementptr %"compiler/views:Viewer", ptr %t831, i32 0, i32 3
  %t834 = load i64, ptr %l21, !tbaa !24
  %t837 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t833, i64 %t834)
  store { i64, ptr } %t837, ptr %l533
  br label %bb210
bb210:
  %t838 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t839 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t840 = load { i64, ptr }, ptr %l529, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l533, !tbaa !27
  %t844 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %s37, ptr %v0, ptr %s37, ptr %s37, ptr %s37, { i64, ptr } %t840, { i64, ptr } %t841, { i64, ptr } %t838, { i64, ptr } %t839)
  store %"compiler/msgs:Msg" %t844, ptr %l536
  br label %bb211
bb211:
  %t845 = load ptr, ptr %l525, !tbaa !29
  %t846 = load { i64, [3 x i64] }, ptr %l528
  %t847 = load %"compiler/msgs:Msg", ptr %l536
  %t848 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s37, ptr %t845, { i64, [3 x i64] } %t846, %"compiler/msgs:Msg" %t847)
  store i64 %t848, ptr %l537
  br label %bb212
bb212:
  %t849 = load i64, ptr %l537, !tbaa !24
  store i64 %t849, ptr %l75, !tbaa !24
  %t850 = load i1, ptr %l22, !tbaa !21
  br i1 %t850, label %bb213, label %bb214
bb213:
  %t852 = load i64, ptr %l72, !tbaa !24
  %t855 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t852)
  store i64 %t855, ptr %l542
  br label %bb215
bb214:
  store i1 false, ptr %l539, !tbaa !21
  br label %bb216
bb215:
  %t856 = load i64, ptr %l542, !tbaa !24
  %t857 = icmp sge i64 %t856, 0
  store i1 %t857, ptr %l539, !tbaa !21
  br label %bb216
bb216:
  %t859 = load i1, ptr %l539, !tbaa !21
  br i1 %t859, label %bb217, label %bb218
bb217:
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t862 = getelementptr %"compiler/views:Viewer", ptr %t860, i32 0, i32 6
  store ptr %t862, ptr %l546, !tbaa !29
  %t863 = load i64, ptr %l72, !tbaa !24
  %t866 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t863)
  store i64 %t866, ptr %l549
  br label %bb219
bb218:
  store i1 false, ptr %l544, !tbaa !21
  br label %bb221
bb219:
  %t867 = load ptr, ptr %l546, !tbaa !29
  %t868 = load i64, ptr %l549, !tbaa !24
  %t869 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t867, i64 %t868)
  store i1 %t869, ptr %l550
  br label %bb220
bb220:
  %t870 = load i1, ptr %l550, !tbaa !21
  %t871 = xor i1 %t870, true
  store i1 %t871, ptr %l544, !tbaa !21
  br label %bb221
bb221:
  %t873 = load i1, ptr %l544, !tbaa !21
  br i1 %t873, label %bb222, label %bb223
bb222:
  store %olang.scope zeroinitializer, ptr %s40
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t876 = getelementptr %"compiler/views:Viewer", ptr %t874, i32 0, i32 0
  %t877 = load ptr, ptr %t876, !tbaa !29
  %t879 = getelementptr %"compiler/generic:Program", ptr %t877, i32 0, i32 0
  %t880 = load ptr, ptr %t879, !tbaa !29
  %t882 = getelementptr %"compiler/load:Loader", ptr %t880, i32 0, i32 4
  %t883 = load ptr, ptr %t882, !tbaa !29
  store ptr %t883, ptr %l555, !tbaa !29
  %t884 = load i64, ptr %l75, !tbaa !24
  store i64 %t884, ptr %l556, !tbaa !24
  %t885 = load i64, ptr %l72, !tbaa !24
  %t888 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t885)
  store i64 %t888, ptr %l559
  br label %bb224
bb223:
  br label %bb230
bb224:
  %t889 = load i64, ptr %l72, !tbaa !24
  %t892 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t889)
  store %"compiler/source:Span" %t892, ptr %l562
  br label %bb225
bb225:
  %t893 = getelementptr %"compiler/source:Span", ptr %l562, i32 0, i32 0
  %t894 = load i32, ptr %t893, !tbaa !23
  %t896 = sext i32 %t894 to i64
  store i64 %t896, ptr %l564, !tbaa !24
  %t897 = load i64, ptr %l72, !tbaa !24
  %t900 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t897)
  store %"compiler/source:Span" %t900, ptr %l567
  br label %bb226
bb226:
  %t901 = getelementptr %"compiler/source:Span", ptr %l567, i32 0, i32 1
  %t902 = load i32, ptr %t901, !tbaa !23
  %t904 = sext i32 %t902 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t905
  %t906 = getelementptr { i64, [3 x i64] }, ptr %t905, i32 0, i32 0
  store i64 3, ptr %t906
  %t907 = load i64, ptr %l559, !tbaa !24
  %t908 = insertvalue { i64, i64, i64 } undef, i64 %t907, 0
  %t909 = load i64, ptr %l564, !tbaa !24
  %t910 = insertvalue { i64, i64, i64 } %t908, i64 %t909, 1
  %t912 = insertvalue { i64, i64, i64 } %t910, i64 %t904, 2
  %t913 = getelementptr { i64, [3 x i64] }, ptr %t905, i32 0, i32 1
  store { i64, i64, i64 } %t912, ptr %t913
  %t914 = load { i64, [3 x i64] }, ptr %t905
  store { i64, [3 x i64] } %t914, ptr %l570
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t917 = getelementptr %"compiler/views:Viewer", ptr %t915, i32 0, i32 3
  %t918 = load i64, ptr %l21, !tbaa !24
  %t921 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t917, i64 %t918)
  store { i64, ptr } %t921, ptr %l574
  br label %bb227
bb227:
  %t922 = load { i64, ptr }, ptr %l574, !tbaa !27
  %t923 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %s40, { i64, ptr } %t922)
  store %"compiler/msgs:Msg" %t923, ptr %l575
  br label %bb228
bb228:
  %t924 = load ptr, ptr %l555, !tbaa !29
  %t925 = load i64, ptr %l556, !tbaa !24
  %t926 = load { i64, [3 x i64] }, ptr %l570
  %t927 = load %"compiler/msgs:Msg", ptr %l575
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s40, ptr %t924, i64 %t925, { i64, [3 x i64] } %t926, %"compiler/msgs:Msg" %t927)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s40)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s37)
  br label %bb232
bb231:
  %t928 = load i64, ptr %l71, !tbaa !24
  %t930 = add i64 %t928, 1
  store i64 %t930, ptr %l71, !tbaa !24
  br label %bb194
bb232:
  call void @__olang_scope_close(ptr %s34)
  br label %bb233
bb233:
  %t932 = load i64, ptr %l65, !tbaa !24
  %t934 = add i64 %t932, 1
  store i64 %t934, ptr %l65, !tbaa !24
  br label %bb180
bb234:
  %t936 = load i64, ptr %l62, !tbaa !24
  %t937 = load i64, ptr %l64, !tbaa !24
  %t940 = add i64 %t936, %t937
  store i64 %t940, ptr %l62, !tbaa !24
  call void @__olang_scope_close(ptr %s33)
  br label %bb235
bb235:
  br label %bb173
bb236:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  br label %bb237
bb237:
  %t942 = load i64, ptr %l58, !tbaa !24
  %t944 = add i64 %t942, 1
  store i64 %t944, ptr %l58, !tbaa !24
  br label %bb168
bb238:
  br label %bb239
bb239:
  store i64 0, ptr %l76, !tbaa !24
  %t947 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23)
  store i64 %t947, ptr %l586
  br label %bb240
bb240:
  %t948 = load i64, ptr %l586, !tbaa !24
  store i64 %t948, ptr %l77, !tbaa !24
  store i64 1, ptr %l78, !tbaa !24
  %t949 = load i64, ptr %l77, !tbaa !24
  %t950 = load i64, ptr %l76, !tbaa !24
  %t953 = icmp sgt i64 %t949, %t950
  br i1 %t953, label %bb241, label %bb242
bb241:
  %t955 = load i64, ptr %l78, !tbaa !24
  %t957 = icmp sgt i64 %t955, 0
  br i1 %t957, label %bb243, label %bb244
bb242:
  store i64 0, ptr %l590, !tbaa !24
  br label %bb246
bb243:
  %t959 = load i64, ptr %l77, !tbaa !24
  %t960 = load i64, ptr %l76, !tbaa !24
  %t963 = sub i64 %t959, %t960
  %t964 = load i64, ptr %l78, !tbaa !24
  %t967 = add i64 %t963, %t964
  %t969 = sub i64 %t967, 1
  %t970 = load i64, ptr %l78, !tbaa !24
  %t973 = sdiv i64 %t969, %t970
  store i64 %t973, ptr %l593, !tbaa !24
  br label %bb245
bb244:
  store i64 0, ptr %l593, !tbaa !24
  br label %bb245
bb245:
  %t975 = load i64, ptr %l593, !tbaa !24
  store i64 %t975, ptr %l590, !tbaa !24
  br label %bb246
bb246:
  %t976 = load i64, ptr %l590, !tbaa !24
  store i64 %t976, ptr %l79, !tbaa !24
  store i64 0, ptr %l80, !tbaa !24
  br label %bb247
bb247:
  store %olang.scope zeroinitializer, ptr %s45
  %t977 = load i64, ptr %l80, !tbaa !24
  %t978 = load i64, ptr %l79, !tbaa !24
  %t981 = icmp slt i64 %t977, %t978
  %t983 = xor i1 %t981, true
  br i1 %t983, label %bb248, label %bb249
bb248:
  call void @__olang_scope_close(ptr %s45)
  br label %bb256
bb249:
  br label %bb250
bb250:
  %t985 = load i64, ptr %l76, !tbaa !24
  %t986 = load i64, ptr %l80, !tbaa !24
  %t987 = load i64, ptr %l78, !tbaa !24
  %t990 = mul i64 %t986, %t987
  %t993 = add i64 %t985, %t990
  store i64 %t993, ptr %l81, !tbaa !24
  %t995 = load ptr, ptr %l0, !tbaa !29
  store ptr %t995, ptr %l611, !tbaa !29
  %t996 = load i64, ptr %l81, !tbaa !24
  %t999 = call %"compiler/views:place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23, i64 %t996)
  store %"compiler/views:place" %t999, ptr %l614
  br label %bb251
bb251:
  %t1000 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t1000, ptr %l615
  %t1001 = load i64, ptr %l21, !tbaa !24
  store i64 %t1001, ptr %l616, !tbaa !24
  %t1002 = load i64, ptr %l81, !tbaa !24
  %t1005 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t1002)
  store i64 %t1005, ptr %l619
  br label %bb252
bb252:
  %t1006 = load i64, ptr %l81, !tbaa !24
  %t1009 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t1006)
  store %"compiler/source:Span" %t1009, ptr %l622
  br label %bb253
bb253:
  %t1010 = load ptr, ptr %l4, !tbaa !29
  %t1011 = load ptr, ptr %l611, !tbaa !29
  %t1012 = load %"compiler/views:place", ptr %l614
  %t1013 = load %"compiler/source:Span", ptr %l615
  %t1014 = load i64, ptr %l616, !tbaa !24
  %t1015 = load i64, ptr %l619, !tbaa !24
  %t1016 = load %"compiler/source:Span", ptr %l622
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v2, ptr %t1011, %"compiler/views:place" %t1012, %"compiler/source:Span" %t1013, i64 %t1014, i64 %t1015, %"compiler/source:Span" %t1016, ptr %t1010)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s45)
  br label %bb255
bb255:
  %t1018 = load i64, ptr %l80, !tbaa !24
  %t1020 = add i64 %t1018, 1
  store i64 %t1020, ptr %l80, !tbaa !24
  br label %bb247
bb256:
  store ptr %l6, ptr %l82, !tbaa !29
  store i64 0, ptr %l83, !tbaa !24
  br label %bb257
bb257:
  store %olang.scope zeroinitializer, ptr %s48
  %t1023 = load ptr, ptr %l82, !tbaa !29
  %t1024 = load i64, ptr %l83, !tbaa !24
  %t1027 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t1023, i64 %t1024)
  %t1028 = extractvalue { i32, { i64, ptr } } %t1027, 1
  %t1029 = extractvalue { i32, { i64, ptr } } %t1027, 0
  store i32 %t1029, ptr %l631
  %t1030 = icmp ne i32 %t1029, 0
  br i1 %t1030, label %bb259, label %ok.1031
ok.1031:
  store { i64, ptr } %t1028, ptr %l630
  br label %bb258
bb258:
  %t1032 = load { i64, ptr }, ptr %l630, !tbaa !27
  store { i64, ptr } %t1032, ptr %l627, !tbaa !27
  br label %bb263
bb259:
  %t1033 = load i32, ptr %l631, !tbaa !23
  %t1034 = ashr i32 %t1033, 16
  %t1036 = icmp eq i32 %t1034, 1
  br i1 %t1036, label %bb260, label %bb261
bb260:
  br label %bb262
bb261:
  call void @__olang_check_failed(ptr @olang_loc_ec5a55ed5d3c9caf_79dd336489dd21db)
  unreachable
bb262:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s48)
  br label %bb272
bb263:
  %t1038 = load { i64, ptr }, ptr %l627, !tbaa !27
  store { i64, ptr } %t1038, ptr %l84, !tbaa !27
  %t1039 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t1041 = extractvalue { i64, ptr } %t1039, 0
  store i64 %t1041, ptr %l85, !tbaa !24
  store i64 0, ptr %l86, !tbaa !24
  br label %bb264
bb264:
  store %olang.scope zeroinitializer, ptr %s49
  %t1043 = load i64, ptr %l86, !tbaa !24
  %t1044 = load i64, ptr %l85, !tbaa !24
  %t1047 = icmp slt i64 %t1043, %t1044
  %t1049 = xor i1 %t1047, true
  br i1 %t1049, label %bb265, label %bb266
bb265:
  call void @__olang_scope_close(ptr %s49)
  br label %bb270
bb266:
  br label %bb267
bb267:
  %t1051 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t1051, ptr %l640, !tbaa !27
  %t1052 = load i64, ptr %l86, !tbaa !24
  %t1054 = getelementptr { i64, ptr }, ptr %l640, i32 0, i32 1
  %t1055 = load ptr, ptr %t1054, !tbaa !27
  %t1056 = getelementptr %"compiler/views:view", ptr %t1055, i64 %t1052
  %t1057 = load %"compiler/views:view", ptr %t1056
  %t1059 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1059, %"compiler/views:view" %t1057)
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s49)
  br label %bb269
bb269:
  %t1063 = load i64, ptr %l86, !tbaa !24
  %t1065 = add i64 %t1063, 1
  store i64 %t1065, ptr %l86, !tbaa !24
  br label %bb264
bb270:
  %t1067 = load i64, ptr %l83, !tbaa !24
  %t1068 = load i64, ptr %l85, !tbaa !24
  %t1071 = add i64 %t1067, %t1068
  store i64 %t1071, ptr %l83, !tbaa !24
  call void @__olang_scope_close(ptr %s48)
  br label %bb271
bb271:
  br label %bb257
bb272:
  %t1073 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1073, ptr %l650
  br label %bb273
bb273:
  %t1074 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l650
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1074, ptr %l88
  store i64 0, ptr %l89, !tbaa !24
  %t1075 = load i64, ptr %l12, !tbaa !24
  store i64 %t1075, ptr %l90, !tbaa !24
  store i64 1, ptr %l91, !tbaa !24
  %t1077 = load i64, ptr %l90, !tbaa !24
  %t1078 = load i64, ptr %l89, !tbaa !24
  %t1081 = icmp sgt i64 %t1077, %t1078
  br i1 %t1081, label %bb274, label %bb275
bb274:
  %t1083 = load i64, ptr %l91, !tbaa !24
  %t1085 = icmp sgt i64 %t1083, 0
  br i1 %t1085, label %bb276, label %bb277
bb275:
  store i64 0, ptr %l655, !tbaa !24
  br label %bb279
bb276:
  %t1087 = load i64, ptr %l90, !tbaa !24
  %t1088 = load i64, ptr %l89, !tbaa !24
  %t1091 = sub i64 %t1087, %t1088
  %t1092 = load i64, ptr %l91, !tbaa !24
  %t1095 = add i64 %t1091, %t1092
  %t1097 = sub i64 %t1095, 1
  %t1098 = load i64, ptr %l91, !tbaa !24
  %t1101 = sdiv i64 %t1097, %t1098
  store i64 %t1101, ptr %l658, !tbaa !24
  br label %bb278
bb277:
  store i64 0, ptr %l658, !tbaa !24
  br label %bb278
bb278:
  %t1103 = load i64, ptr %l658, !tbaa !24
  store i64 %t1103, ptr %l655, !tbaa !24
  br label %bb279
bb279:
  %t1104 = load i64, ptr %l655, !tbaa !24
  store i64 %t1104, ptr %l92, !tbaa !24
  store i64 0, ptr %l93, !tbaa !24
  br label %bb280
bb280:
  store %olang.scope zeroinitializer, ptr %s52
  %t1105 = load i64, ptr %l93, !tbaa !24
  %t1106 = load i64, ptr %l92, !tbaa !24
  %t1109 = icmp slt i64 %t1105, %t1106
  %t1111 = xor i1 %t1109, true
  br i1 %t1111, label %bb281, label %bb282
bb281:
  call void @__olang_scope_close(ptr %s52)
  br label %bb286
bb282:
  br label %bb283
bb283:
  %t1113 = load i64, ptr %l89, !tbaa !24
  %t1114 = load i64, ptr %l93, !tbaa !24
  %t1115 = load i64, ptr %l91, !tbaa !24
  %t1118 = mul i64 %t1114, %t1115
  %t1121 = add i64 %t1113, %t1118
  store i64 %t1121, ptr %l94, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l88, i1 false)
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s52)
  br label %bb285
bb285:
  %t1124 = load i64, ptr %l93, !tbaa !24
  %t1126 = add i64 %t1124, 1
  store i64 %t1126, ptr %l93, !tbaa !24
  br label %bb280
bb286:
  %t1128 = load i1, ptr %l22, !tbaa !21
  br i1 %t1128, label %bb287, label %bb288
bb287:
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1132 = getelementptr %"compiler/views:Viewer", ptr %t1130, i32 0, i32 2
  %t1133 = load i64, ptr %l7, !tbaa !24
  %t1136 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1132, i64 %t1133)
  store ptr %t1136, ptr %l683
  br label %bb289
bb288:
  br label %bb332
bb289:
  %t1137 = load ptr, ptr %l683, !tbaa !29
  %t1139 = getelementptr %"compiler/views:summary", ptr %t1137, i32 0, i32 1
  store ptr %t1139, ptr %l95, !tbaa !29
  store i64 0, ptr %l96, !tbaa !24
  br label %bb290
bb290:
  store %olang.scope zeroinitializer, ptr %s56
  %t1141 = load ptr, ptr %l95, !tbaa !29
  %t1142 = load i64, ptr %l96, !tbaa !24
  %t1145 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t1141, i64 %t1142)
  %t1146 = extractvalue { i32, { i64, ptr } } %t1145, 1
  %t1147 = extractvalue { i32, { i64, ptr } } %t1145, 0
  store i32 %t1147, ptr %l690
  %t1148 = icmp ne i32 %t1147, 0
  br i1 %t1148, label %bb292, label %ok.1149
ok.1149:
  store { i64, ptr } %t1146, ptr %l689
  br label %bb291
bb291:
  %t1150 = load { i64, ptr }, ptr %l689, !tbaa !27
  store { i64, ptr } %t1150, ptr %l686, !tbaa !27
  br label %bb296
bb292:
  %t1151 = load i32, ptr %l690, !tbaa !23
  %t1152 = ashr i32 %t1151, 16
  %t1154 = icmp eq i32 %t1152, 1
  br i1 %t1154, label %bb293, label %bb294
bb293:
  br label %bb295
bb294:
  call void @__olang_check_failed(ptr @olang_loc_b4b39a7a8799bd74_cd2c4d49ead70ce0)
  unreachable
bb295:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s56)
  br label %bb331
bb296:
  %t1156 = load { i64, ptr }, ptr %l686, !tbaa !27
  store { i64, ptr } %t1156, ptr %l97, !tbaa !27
  %t1157 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t1159 = extractvalue { i64, ptr } %t1157, 0
  store i64 %t1159, ptr %l98, !tbaa !24
  store i64 0, ptr %l99, !tbaa !24
  br label %bb297
bb297:
  store %olang.scope zeroinitializer, ptr %s57
  %t1161 = load i64, ptr %l99, !tbaa !24
  %t1162 = load i64, ptr %l98, !tbaa !24
  %t1165 = icmp slt i64 %t1161, %t1162
  %t1167 = xor i1 %t1165, true
  br i1 %t1167, label %bb298, label %bb299
bb298:
  call void @__olang_scope_close(ptr %s57)
  br label %bb329
bb299:
  br label %bb300
bb300:
  %t1169 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t1169, ptr %l699, !tbaa !27
  %t1170 = load i64, ptr %l99, !tbaa !24
  %t1172 = getelementptr { i64, ptr }, ptr %l699, i32 0, i32 1
  %t1173 = load ptr, ptr %t1172, !tbaa !27
  %t1174 = getelementptr %"compiler/views:fact", ptr %t1173, i64 %t1170
  %t1175 = load %"compiler/views:fact", ptr %t1174
  store %"compiler/views:fact" %t1175, ptr %l100
  %t1177 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1178 = load i64, ptr %t1177, !tbaa !24
  %t1180 = icmp slt i64 %t1178, 0
  br i1 %t1180, label %bb301, label %bb302
bb301:
  store i1 true, ptr %l704, !tbaa !21
  br label %bb303
bb302:
  %t1182 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1183 = load i64, ptr %t1182, !tbaa !24
  %t1184 = load i64, ptr %l12, !tbaa !24
  %t1187 = icmp sge i64 %t1183, %t1184
  store i1 %t1187, ptr %l704, !tbaa !21
  br label %bb303
bb303:
  %t1189 = load i1, ptr %l704, !tbaa !21
  br i1 %t1189, label %bb304, label %bb305
bb304:
  call void @__olang_scope_close(ptr %s57)
  br label %bb328
bb305:
  br label %bb306
bb306:
  %t1190 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1191 = load i64, ptr %t1190, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l88, i64 %t1191, i1 true)
  br label %bb307
bb307:
  %t1194 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1194, ptr %l710
  br label %bb308
bb308:
  %t1195 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l710
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1195, ptr %l101
  %t1196 = load ptr, ptr %l0, !tbaa !29
  %t1197 = load ptr, ptr %l3, !tbaa !29
  %t1199 = getelementptr %"compiler/typed:Call", ptr %t1197, i32 0, i32 1
  %t1200 = load { i64, ptr }, ptr %t1199, !tbaa !27
  store { i64, ptr } %t1200, ptr %l713, !tbaa !27
  %t1201 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1202 = load i64, ptr %t1201, !tbaa !24
  %t1204 = getelementptr { i64, ptr }, ptr %l713, i32 0, i32 1
  %t1205 = load ptr, ptr %t1204, !tbaa !27
  %t1206 = getelementptr ptr, ptr %t1205, i64 %t1202
  %t1207 = load ptr, ptr %t1206, !tbaa !39
  %t1209 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s57, ptr %t1196, ptr %t1207, ptr %t1209, ptr %l101)
  br label %bb309
bb309:
  store ptr %l101, ptr %l102, !tbaa !29
  store i64 0, ptr %l103, !tbaa !24
  br label %bb310
bb310:
  store %olang.scope zeroinitializer, ptr %s60
  %t1215 = load ptr, ptr %l102, !tbaa !29
  %t1216 = load i64, ptr %l103, !tbaa !24
  %t1219 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s57, ptr %t1215, i64 %t1216)
  %t1220 = extractvalue { i32, { i64, ptr } } %t1219, 1
  %t1221 = extractvalue { i32, { i64, ptr } } %t1219, 0
  store i32 %t1221, ptr %l724
  %t1222 = icmp ne i32 %t1221, 0
  br i1 %t1222, label %bb312, label %ok.1223
ok.1223:
  store { i64, ptr } %t1220, ptr %l723
  br label %bb311
bb311:
  %t1224 = load { i64, ptr }, ptr %l723, !tbaa !27
  store { i64, ptr } %t1224, ptr %l720, !tbaa !27
  br label %bb316
bb312:
  %t1225 = load i32, ptr %l724, !tbaa !23
  %t1226 = ashr i32 %t1225, 16
  %t1228 = icmp eq i32 %t1226, 1
  br i1 %t1228, label %bb313, label %bb314
bb313:
  br label %bb315
bb314:
  call void @__olang_check_failed(ptr @olang_loc_ad107d2d4e78d7a5_d0509a7597b390f1)
  unreachable
bb315:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s60)
  br label %bb327
bb316:
  %t1230 = load { i64, ptr }, ptr %l720, !tbaa !27
  store { i64, ptr } %t1230, ptr %l104, !tbaa !27
  %t1231 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t1233 = extractvalue { i64, ptr } %t1231, 0
  store i64 %t1233, ptr %l105, !tbaa !24
  store i64 0, ptr %l106, !tbaa !24
  br label %bb317
bb317:
  store %olang.scope zeroinitializer, ptr %s61
  %t1235 = load i64, ptr %l106, !tbaa !24
  %t1236 = load i64, ptr %l105, !tbaa !24
  %t1239 = icmp slt i64 %t1235, %t1236
  %t1241 = xor i1 %t1239, true
  br i1 %t1241, label %bb318, label %bb319
bb318:
  call void @__olang_scope_close(ptr %s61)
  br label %bb325
bb319:
  br label %bb320
bb320:
  %t1243 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t1243, ptr %l733, !tbaa !27
  %t1244 = load i64, ptr %l106, !tbaa !24
  %t1246 = getelementptr { i64, ptr }, ptr %l733, i32 0, i32 1
  %t1247 = load ptr, ptr %t1246, !tbaa !27
  %t1248 = getelementptr %"compiler/views:place", ptr %t1247, i64 %t1244
  %t1249 = load %"compiler/views:place", ptr %t1248
  %t1251 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1251, ptr %l736, !tbaa !29
  %t1252 = load ptr, ptr %l0, !tbaa !29
  %t1254 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 3
  %t1255 = load i64, ptr %t1254, !tbaa !24
  %t1256 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 4
  %t1257 = load i64, ptr %t1256, !tbaa !24
  %t1258 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 5
  %t1259 = load i1, ptr %t1258, !tbaa !21
  %t1265 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t1252, %"compiler/views:place" %t1249, i64 %t1255, i64 %t1257, i1 %t1259)
  store %"compiler/views:place" %t1265, ptr %l742
  br label %bb321
bb321:
  %t1266 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t1267 = load i32, ptr %t1266, !tbaa !23
  %t1269 = sext i32 %t1267 to i64
  %t1270 = load %"compiler/views:place", ptr %l742
  %t1272 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s61, %"compiler/views:place" %t1270, i64 %t1269)
  store %"compiler/views:view" %t1272, ptr %l745
  br label %bb322
bb322:
  %t1273 = load ptr, ptr %l736, !tbaa !29
  %t1274 = load %"compiler/views:view", ptr %l745
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1273, %"compiler/views:view" %t1274)
  br label %bb323
bb323:
  call void @__olang_scope_close(ptr %s61)
  br label %bb324
bb324:
  %t1275 = load i64, ptr %l106, !tbaa !24
  %t1277 = add i64 %t1275, 1
  store i64 %t1277, ptr %l106, !tbaa !24
  br label %bb317
bb325:
  %t1279 = load i64, ptr %l103, !tbaa !24
  %t1280 = load i64, ptr %l105, !tbaa !24
  %t1283 = add i64 %t1279, %t1280
  store i64 %t1283, ptr %l103, !tbaa !24
  call void @__olang_scope_close(ptr %s60)
  br label %bb326
bb326:
  br label %bb310
bb327:
  call void @__olang_scope_close(ptr %s57)
  br label %bb328
bb328:
  %t1285 = load i64, ptr %l99, !tbaa !24
  %t1287 = add i64 %t1285, 1
  store i64 %t1287, ptr %l99, !tbaa !24
  br label %bb297
bb329:
  %t1289 = load i64, ptr %l96, !tbaa !24
  %t1290 = load i64, ptr %l98, !tbaa !24
  %t1293 = add i64 %t1289, %t1290
  store i64 %t1293, ptr %l96, !tbaa !24
  call void @__olang_scope_close(ptr %s56)
  br label %bb330
bb330:
  br label %bb290
bb331:
  br label %bb332
bb332:
  %t1295 = load ptr, ptr %l0, !tbaa !29
  %t1296 = load i32, ptr %l2, !tbaa !23
  %t1299 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t1295, i32 %t1296)
  store i1 %t1299, ptr %l758
  br label %bb333
bb333:
  %t1300 = load i1, ptr %l758, !tbaa !21
  br i1 %t1300, label %bb334, label %bb335
bb334:
  store i64 0, ptr %l108, !tbaa !24
  %t1301 = load i64, ptr %l12, !tbaa !24
  store i64 %t1301, ptr %l109, !tbaa !24
  store i64 1, ptr %l110, !tbaa !24
  %t1303 = load i64, ptr %l109, !tbaa !24
  %t1304 = load i64, ptr %l108, !tbaa !24
  %t1307 = icmp sgt i64 %t1303, %t1304
  br i1 %t1307, label %bb336, label %bb337
bb335:
  br label %bb421
bb336:
  %t1309 = load i64, ptr %l110, !tbaa !24
  %t1311 = icmp sgt i64 %t1309, 0
  br i1 %t1311, label %bb338, label %bb339
bb337:
  store i64 0, ptr %l763, !tbaa !24
  br label %bb341
bb338:
  %t1313 = load i64, ptr %l109, !tbaa !24
  %t1314 = load i64, ptr %l108, !tbaa !24
  %t1317 = sub i64 %t1313, %t1314
  %t1318 = load i64, ptr %l110, !tbaa !24
  %t1321 = add i64 %t1317, %t1318
  %t1323 = sub i64 %t1321, 1
  %t1324 = load i64, ptr %l110, !tbaa !24
  %t1327 = sdiv i64 %t1323, %t1324
  store i64 %t1327, ptr %l766, !tbaa !24
  br label %bb340
bb339:
  store i64 0, ptr %l766, !tbaa !24
  br label %bb340
bb340:
  %t1329 = load i64, ptr %l766, !tbaa !24
  store i64 %t1329, ptr %l763, !tbaa !24
  br label %bb341
bb341:
  %t1330 = load i64, ptr %l763, !tbaa !24
  store i64 %t1330, ptr %l111, !tbaa !24
  store i64 0, ptr %l112, !tbaa !24
  br label %bb342
bb342:
  store %olang.scope zeroinitializer, ptr %s66
  %t1331 = load i64, ptr %l112, !tbaa !24
  %t1332 = load i64, ptr %l111, !tbaa !24
  %t1335 = icmp slt i64 %t1331, %t1332
  %t1337 = xor i1 %t1335, true
  br i1 %t1337, label %bb343, label %bb344
bb343:
  call void @__olang_scope_close(ptr %s66)
  br label %bb420
bb344:
  br label %bb345
bb345:
  %t1339 = load i64, ptr %l108, !tbaa !24
  %t1340 = load i64, ptr %l112, !tbaa !24
  %t1341 = load i64, ptr %l110, !tbaa !24
  %t1344 = mul i64 %t1340, %t1341
  %t1347 = add i64 %t1339, %t1344
  store i64 %t1347, ptr %l113, !tbaa !24
  %t1349 = load i64, ptr %l113, !tbaa !24
  %t1352 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l88, i64 %t1349)
  store i1 %t1352, ptr %l786
  br label %bb346
bb346:
  %t1353 = load i1, ptr %l786, !tbaa !21
  br i1 %t1353, label %bb347, label %bb348
bb347:
  call void @__olang_scope_close(ptr %s66)
  br label %bb419
bb348:
  br label %bb349
bb349:
  %t1354 = load i1, ptr %l8, !tbaa !21
  br i1 %t1354, label %bb350, label %bb351
bb350:
  store i1 true, ptr %l788, !tbaa !21
  br label %bb365
bb351:
  %t1356 = load i64, ptr %l7, !tbaa !24
  %t1358 = icmp sge i64 %t1356, 0
  br i1 %t1358, label %bb352, label %bb353
bb352:
  %t1360 = load i1, ptr %l22, !tbaa !21
  %t1362 = xor i1 %t1360, true
  br i1 %t1362, label %bb354, label %bb355
bb353:
  store i1 false, ptr %l791, !tbaa !21
  br label %bb364
bb354:
  store i1 true, ptr %l794, !tbaa !21
  br label %bb363
bb355:
  %t1364 = load i64, ptr %l113, !tbaa !24
  store i64 %t1364, ptr %l795, !tbaa !24
  %t1365 = load ptr, ptr %l0, !tbaa !29
  %t1367 = getelementptr %"compiler/views:Viewer", ptr %t1365, i32 0, i32 2
  %t1368 = load i64, ptr %l7, !tbaa !24
  %t1371 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1367, i64 %t1368)
  store ptr %t1371, ptr %l799
  br label %bb356
bb356:
  %t1372 = load ptr, ptr %l799, !tbaa !29
  %t1374 = getelementptr %"compiler/views:summary", ptr %t1372, i32 0, i32 3
  %t1376 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1374)
  store i64 %t1376, ptr %l802
  br label %bb357
bb357:
  %t1377 = load i64, ptr %l795, !tbaa !24
  %t1378 = load i64, ptr %l802, !tbaa !24
  %t1379 = icmp slt i64 %t1377, %t1378
  br i1 %t1379, label %bb358, label %bb359
bb358:
  %t1381 = load ptr, ptr %l0, !tbaa !29
  %t1383 = getelementptr %"compiler/views:Viewer", ptr %t1381, i32 0, i32 2
  %t1384 = load i64, ptr %l7, !tbaa !24
  %t1387 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1383, i64 %t1384)
  store ptr %t1387, ptr %l808
  br label %bb360
bb359:
  store i1 false, ptr %l804, !tbaa !21
  br label %bb362
bb360:
  %t1388 = load ptr, ptr %l808, !tbaa !29
  %t1390 = getelementptr %"compiler/views:summary", ptr %t1388, i32 0, i32 3
  %t1391 = load i64, ptr %l113, !tbaa !24
  %t1394 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1390, i64 %t1391)
  store i1 %t1394, ptr %l812
  br label %bb361
bb361:
  %t1395 = load i1, ptr %l812, !tbaa !21
  store i1 %t1395, ptr %l804, !tbaa !21
  br label %bb362
bb362:
  %t1396 = load i1, ptr %l804, !tbaa !21
  store i1 %t1396, ptr %l794, !tbaa !21
  br label %bb363
bb363:
  %t1397 = load i1, ptr %l794, !tbaa !21
  store i1 %t1397, ptr %l791, !tbaa !21
  br label %bb364
bb364:
  %t1398 = load i1, ptr %l791, !tbaa !21
  store i1 %t1398, ptr %l788, !tbaa !21
  br label %bb365
bb365:
  %t1399 = load i1, ptr %l788, !tbaa !21
  br i1 %t1399, label %bb366, label %bb367
bb366:
  store %olang.scope zeroinitializer, ptr %s69
  %t1402 = load i64, ptr %l113, !tbaa !24
  %t1405 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t1402)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1405, ptr %l816
  br label %bb368
bb367:
  br label %bb385
bb368:
  %t1406 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l816
  %t1407 = call ptr @__olang_scope_alloc_a(ptr %s69, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1406, ptr %t1407
  store ptr %t1407, ptr %l115, !tbaa !29
  store i64 0, ptr %l116, !tbaa !24
  br label %bb369
bb369:
  store %olang.scope zeroinitializer, ptr %s70
  %t1409 = load ptr, ptr %l115, !tbaa !29
  %t1410 = load i64, ptr %l116, !tbaa !24
  %t1413 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t1409, i64 %t1410)
  %t1414 = extractvalue { i32, { i64, ptr } } %t1413, 1
  %t1415 = extractvalue { i32, { i64, ptr } } %t1413, 0
  store i32 %t1415, ptr %l822
  %t1416 = icmp ne i32 %t1415, 0
  br i1 %t1416, label %bb371, label %ok.1417
ok.1417:
  store { i64, ptr } %t1414, ptr %l821
  br label %bb370
bb370:
  %t1418 = load { i64, ptr }, ptr %l821, !tbaa !27
  store { i64, ptr } %t1418, ptr %l818, !tbaa !27
  br label %bb375
bb371:
  %t1419 = load i32, ptr %l822, !tbaa !23
  %t1420 = ashr i32 %t1419, 16
  %t1422 = icmp eq i32 %t1420, 1
  br i1 %t1422, label %bb372, label %bb373
bb372:
  br label %bb374
bb373:
  call void @__olang_check_failed(ptr @olang_loc_6c927a3cb50e0c6a_17c3e17799f249e)
  unreachable
bb374:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s70)
  br label %bb384
bb375:
  %t1424 = load { i64, ptr }, ptr %l818, !tbaa !27
  store { i64, ptr } %t1424, ptr %l117, !tbaa !27
  %t1425 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t1427 = extractvalue { i64, ptr } %t1425, 0
  store i64 %t1427, ptr %l118, !tbaa !24
  store i64 0, ptr %l119, !tbaa !24
  br label %bb376
bb376:
  store %olang.scope zeroinitializer, ptr %s71
  %t1429 = load i64, ptr %l119, !tbaa !24
  %t1430 = load i64, ptr %l118, !tbaa !24
  %t1433 = icmp slt i64 %t1429, %t1430
  %t1435 = xor i1 %t1433, true
  br i1 %t1435, label %bb377, label %bb378
bb377:
  call void @__olang_scope_close(ptr %s71)
  br label %bb382
bb378:
  br label %bb379
bb379:
  %t1437 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t1437, ptr %l831, !tbaa !27
  %t1438 = load i64, ptr %l119, !tbaa !24
  %t1440 = getelementptr { i64, ptr }, ptr %l831, i32 0, i32 1
  %t1441 = load ptr, ptr %t1440, !tbaa !27
  %t1442 = getelementptr %"compiler/views:view", ptr %t1441, i64 %t1438
  %t1443 = load %"compiler/views:view", ptr %t1442
  %t1445 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1445, %"compiler/views:view" %t1443)
  br label %bb380
bb380:
  call void @__olang_scope_close(ptr %s71)
  br label %bb381
bb381:
  %t1449 = load i64, ptr %l119, !tbaa !24
  %t1451 = add i64 %t1449, 1
  store i64 %t1451, ptr %l119, !tbaa !24
  br label %bb376
bb382:
  %t1453 = load i64, ptr %l116, !tbaa !24
  %t1454 = load i64, ptr %l118, !tbaa !24
  %t1457 = add i64 %t1453, %t1454
  store i64 %t1457, ptr %l116, !tbaa !24
  call void @__olang_scope_close(ptr %s70)
  br label %bb383
bb383:
  br label %bb369
bb384:
  call void @__olang_scope_close(ptr %s69)
  br label %bb385
bb385:
  %t1459 = load i1, ptr %l8, !tbaa !21
  br i1 %t1459, label %bb386, label %bb387
bb386:
  %t1461 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1461, ptr %l843, !tbaa !29
  %t1462 = load ptr, ptr %l3, !tbaa !29
  %t1464 = getelementptr %"compiler/typed:Call", ptr %t1462, i32 0, i32 1
  %t1465 = load { i64, ptr }, ptr %t1464, !tbaa !27
  store { i64, ptr } %t1465, ptr %l845, !tbaa !27
  %t1466 = load i64, ptr %l113, !tbaa !24
  %t1468 = getelementptr { i64, ptr }, ptr %l845, i32 0, i32 1
  %t1469 = load ptr, ptr %t1468, !tbaa !27
  %t1470 = getelementptr ptr, ptr %t1469, i64 %t1466
  %t1471 = load ptr, ptr %t1470, !tbaa !39
  %t1473 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1471)
  store i32 %t1473, ptr %l848
  br label %bb388
bb387:
  store i1 false, ptr %l842, !tbaa !21
  br label %bb390
bb388:
  %t1474 = load ptr, ptr %l843, !tbaa !29
  %t1475 = load i32, ptr %l848, !tbaa !23
  %t1476 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t1474, i32 %t1475)
  store i1 %t1476, ptr %l849
  br label %bb389
bb389:
  %t1477 = load i1, ptr %l849, !tbaa !21
  store i1 %t1477, ptr %l842, !tbaa !21
  br label %bb390
bb390:
  %t1478 = load i1, ptr %l842, !tbaa !21
  br i1 %t1478, label %bb391, label %bb392
bb391:
  %t1479 = load ptr, ptr %l0, !tbaa !29
  %t1480 = load i32, ptr %l2, !tbaa !23
  %t1483 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %t1479, i32 %t1480)
  store i1 %t1483, ptr %l853
  br label %bb393
bb392:
  store i1 false, ptr %l850, !tbaa !21
  br label %bb394
bb393:
  %t1484 = load i1, ptr %l853, !tbaa !21
  store i1 %t1484, ptr %l850, !tbaa !21
  br label %bb394
bb394:
  %t1485 = load i1, ptr %l850, !tbaa !21
  br i1 %t1485, label %bb395, label %bb396
bb395:
  store %olang.scope zeroinitializer, ptr %s73
  %t1486 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s73)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1486, ptr %l854
  br label %bb397
bb396:
  br label %bb418
bb397:
  %t1487 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l854
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1487, ptr %l121
  %t1488 = load ptr, ptr %l0, !tbaa !29
  %t1489 = load ptr, ptr %l3, !tbaa !29
  %t1491 = getelementptr %"compiler/typed:Call", ptr %t1489, i32 0, i32 1
  %t1492 = load { i64, ptr }, ptr %t1491, !tbaa !27
  store { i64, ptr } %t1492, ptr %l857, !tbaa !27
  %t1493 = load i64, ptr %l113, !tbaa !24
  %t1495 = getelementptr { i64, ptr }, ptr %l857, i32 0, i32 1
  %t1496 = load ptr, ptr %t1495, !tbaa !27
  %t1497 = getelementptr ptr, ptr %t1496, i64 %t1493
  %t1498 = load ptr, ptr %t1497, !tbaa !39
  %t1500 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s73, ptr %t1488, ptr %t1498, ptr %t1500, ptr %l121)
  br label %bb398
bb398:
  store ptr %l121, ptr %l122, !tbaa !29
  store i64 0, ptr %l123, !tbaa !24
  br label %bb399
bb399:
  store %olang.scope zeroinitializer, ptr %s75
  %t1506 = load ptr, ptr %l122, !tbaa !29
  %t1507 = load i64, ptr %l123, !tbaa !24
  %t1510 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s73, ptr %t1506, i64 %t1507)
  %t1511 = extractvalue { i32, { i64, ptr } } %t1510, 1
  %t1512 = extractvalue { i32, { i64, ptr } } %t1510, 0
  store i32 %t1512, ptr %l868
  %t1513 = icmp ne i32 %t1512, 0
  br i1 %t1513, label %bb401, label %ok.1514
ok.1514:
  store { i64, ptr } %t1511, ptr %l867
  br label %bb400
bb400:
  %t1515 = load { i64, ptr }, ptr %l867, !tbaa !27
  store { i64, ptr } %t1515, ptr %l864, !tbaa !27
  br label %bb405
bb401:
  %t1516 = load i32, ptr %l868, !tbaa !23
  %t1517 = ashr i32 %t1516, 16
  %t1519 = icmp eq i32 %t1517, 1
  br i1 %t1519, label %bb402, label %bb403
bb402:
  br label %bb404
bb403:
  call void @__olang_check_failed(ptr @olang_loc_1538af23905b892b_69db3eaec74b8f1f)
  unreachable
bb404:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s75)
  br label %bb417
bb405:
  %t1521 = load { i64, ptr }, ptr %l864, !tbaa !27
  store { i64, ptr } %t1521, ptr %l124, !tbaa !27
  %t1522 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t1524 = extractvalue { i64, ptr } %t1522, 0
  store i64 %t1524, ptr %l125, !tbaa !24
  store i64 0, ptr %l126, !tbaa !24
  br label %bb406
bb406:
  store %olang.scope zeroinitializer, ptr %s76
  %t1526 = load i64, ptr %l126, !tbaa !24
  %t1527 = load i64, ptr %l125, !tbaa !24
  %t1530 = icmp slt i64 %t1526, %t1527
  %t1532 = xor i1 %t1530, true
  br i1 %t1532, label %bb407, label %bb408
bb407:
  call void @__olang_scope_close(ptr %s76)
  br label %bb415
bb408:
  br label %bb409
bb409:
  %t1534 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t1534, ptr %l877, !tbaa !27
  %t1535 = load i64, ptr %l126, !tbaa !24
  %t1537 = getelementptr { i64, ptr }, ptr %l877, i32 0, i32 1
  %t1538 = load ptr, ptr %t1537, !tbaa !27
  %t1539 = getelementptr %"compiler/views:place", ptr %t1538, i64 %t1535
  %t1540 = load %"compiler/views:place", ptr %t1539
  store %"compiler/views:place" %t1540, ptr %l127
  %t1542 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1542, ptr %l880, !tbaa !29
  %t1543 = getelementptr %"compiler/views:place", ptr %l127, i32 0, i32 0
  %t1544 = load { i64, [2 x i64] }, ptr %t1543
  store { i64, [2 x i64] } %t1544, ptr %l881
  %t1545 = getelementptr %"compiler/views:place", ptr %l127, i32 0, i32 1
  %t1546 = load i64, ptr %t1545, !tbaa !24
  store i64 %t1546, ptr %l882, !tbaa !24
  %t1547 = load ptr, ptr %l0, !tbaa !29
  %t1549 = getelementptr %"compiler/views:Viewer", ptr %t1547, i32 0, i32 3
  %t1550 = getelementptr %"compiler/views:place", ptr %l127, i32 0, i32 1
  %t1551 = load i64, ptr %t1550, !tbaa !24
  %t1554 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s76, ptr %t1549, i64 %t1551)
  store { i64, ptr } %t1554, ptr %l886
  br label %bb410
bb410:
  %t1555 = load { i64, ptr }, ptr %l886, !tbaa !27
  %t1556 = extractvalue { i64, ptr } %t1555, 0
  %t1557 = load { i64, [2 x i64] }, ptr %l881
  %t1558 = load i64, ptr %l882, !tbaa !24
  %t1560 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s76, { i64, [2 x i64] } %t1557, i64 %t1558, i64 %t1556, i1 true)
  store %"compiler/views:place" %t1560, ptr %l888
  br label %bb411
bb411:
  %t1561 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t1562 = load i32, ptr %t1561, !tbaa !23
  %t1564 = sext i32 %t1562 to i64
  %t1565 = load %"compiler/views:place", ptr %l888
  %t1567 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s76, %"compiler/views:place" %t1565, i64 %t1564)
  store %"compiler/views:view" %t1567, ptr %l891
  br label %bb412
bb412:
  %t1568 = load ptr, ptr %l880, !tbaa !29
  %t1569 = load %"compiler/views:view", ptr %l891
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1568, %"compiler/views:view" %t1569)
  br label %bb413
bb413:
  call void @__olang_scope_close(ptr %s76)
  br label %bb414
bb414:
  %t1570 = load i64, ptr %l126, !tbaa !24
  %t1572 = add i64 %t1570, 1
  store i64 %t1572, ptr %l126, !tbaa !24
  br label %bb406
bb415:
  %t1574 = load i64, ptr %l123, !tbaa !24
  %t1575 = load i64, ptr %l125, !tbaa !24
  %t1578 = add i64 %t1574, %t1575
  store i64 %t1578, ptr %l123, !tbaa !24
  call void @__olang_scope_close(ptr %s75)
  br label %bb416
bb416:
  br label %bb399
bb417:
  call void @__olang_scope_close(ptr %s73)
  br label %bb418
bb418:
  call void @__olang_scope_close(ptr %s66)
  br label %bb419
bb419:
  %t1580 = load i64, ptr %l112, !tbaa !24
  %t1582 = add i64 %t1580, 1
  store i64 %t1582, ptr %l112, !tbaa !24
  br label %bb342
bb420:
  br label %bb421
bb421:
  %t1584 = load i1, ptr %l22, !tbaa !21
  br i1 %t1584, label %bb422, label %bb423
bb422:
  %t1586 = load ptr, ptr %l0, !tbaa !29
  %t1588 = getelementptr %"compiler/views:Viewer", ptr %t1586, i32 0, i32 22
  %t1589 = load i1, ptr %t1588, !tbaa !21
  %t1591 = xor i1 %t1589, true
  store i1 %t1591, ptr %l900, !tbaa !21
  br label %bb424
bb423:
  store i1 false, ptr %l900, !tbaa !21
  br label %bb424
bb424:
  %t1593 = load i1, ptr %l900, !tbaa !21
  br i1 %t1593, label %bb425, label %bb426
bb425:
  %t1594 = load ptr, ptr %l0, !tbaa !29
  %t1596 = getelementptr %"compiler/views:Viewer", ptr %t1594, i32 0, i32 2
  %t1597 = load i64, ptr %l7, !tbaa !24
  %t1600 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1596, i64 %t1597)
  store ptr %t1600, ptr %l907
  br label %bb427
bb426:
  br label %bb464
bb427:
  %t1601 = load ptr, ptr %l907, !tbaa !29
  %t1603 = getelementptr %"compiler/views:summary", ptr %t1601, i32 0, i32 2
  store ptr %t1603, ptr %l128, !tbaa !29
  store i64 0, ptr %l129, !tbaa !24
  br label %bb428
bb428:
  store %olang.scope zeroinitializer, ptr %s81
  %t1605 = load ptr, ptr %l128, !tbaa !29
  %t1606 = load i64, ptr %l129, !tbaa !24
  %t1609 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t1605, i64 %t1606)
  %t1610 = extractvalue { i32, { i64, ptr } } %t1609, 1
  %t1611 = extractvalue { i32, { i64, ptr } } %t1609, 0
  store i32 %t1611, ptr %l914
  %t1612 = icmp ne i32 %t1611, 0
  br i1 %t1612, label %bb430, label %ok.1613
ok.1613:
  store { i64, ptr } %t1610, ptr %l913
  br label %bb429
bb429:
  %t1614 = load { i64, ptr }, ptr %l913, !tbaa !27
  store { i64, ptr } %t1614, ptr %l910, !tbaa !27
  br label %bb434
bb430:
  %t1615 = load i32, ptr %l914, !tbaa !23
  %t1616 = ashr i32 %t1615, 16
  %t1618 = icmp eq i32 %t1616, 1
  br i1 %t1618, label %bb431, label %bb432
bb431:
  br label %bb433
bb432:
  call void @__olang_check_failed(ptr @olang_loc_a3500c8c48c46ea1_9f190e145f72346d)
  unreachable
bb433:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s81)
  br label %bb463
bb434:
  %t1620 = load { i64, ptr }, ptr %l910, !tbaa !27
  store { i64, ptr } %t1620, ptr %l130, !tbaa !27
  %t1621 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t1623 = extractvalue { i64, ptr } %t1621, 0
  store i64 %t1623, ptr %l131, !tbaa !24
  store i64 0, ptr %l132, !tbaa !24
  br label %bb435
bb435:
  store %olang.scope zeroinitializer, ptr %s82
  %t1625 = load i64, ptr %l132, !tbaa !24
  %t1626 = load i64, ptr %l131, !tbaa !24
  %t1629 = icmp slt i64 %t1625, %t1626
  %t1631 = xor i1 %t1629, true
  br i1 %t1631, label %bb436, label %bb437
bb436:
  call void @__olang_scope_close(ptr %s82)
  br label %bb461
bb437:
  br label %bb438
bb438:
  %t1633 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t1633, ptr %l923, !tbaa !27
  %t1634 = load i64, ptr %l132, !tbaa !24
  %t1636 = getelementptr { i64, ptr }, ptr %l923, i32 0, i32 1
  %t1637 = load ptr, ptr %t1636, !tbaa !27
  %t1638 = getelementptr %"compiler/views:fact", ptr %t1637, i64 %t1634
  %t1639 = load %"compiler/views:fact", ptr %t1638
  store %"compiler/views:fact" %t1639, ptr %l133
  %t1641 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1642 = load i64, ptr %t1641, !tbaa !24
  %t1644 = icmp slt i64 %t1642, 0
  br i1 %t1644, label %bb439, label %bb440
bb439:
  store i1 true, ptr %l928, !tbaa !21
  br label %bb441
bb440:
  %t1646 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1647 = load i64, ptr %t1646, !tbaa !24
  %t1648 = load i64, ptr %l12, !tbaa !24
  %t1651 = icmp sge i64 %t1647, %t1648
  store i1 %t1651, ptr %l928, !tbaa !21
  br label %bb441
bb441:
  %t1653 = load i1, ptr %l928, !tbaa !21
  br i1 %t1653, label %bb442, label %bb443
bb442:
  store i1 true, ptr %l932, !tbaa !21
  br label %bb444
bb443:
  %t1654 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 8
  %t1655 = load i64, ptr %t1654, !tbaa !24
  %t1657 = icmp slt i64 %t1655, 0
  store i1 %t1657, ptr %l932, !tbaa !21
  br label %bb444
bb444:
  %t1659 = load i1, ptr %l932, !tbaa !21
  br i1 %t1659, label %bb445, label %bb446
bb445:
  store i1 true, ptr %l935, !tbaa !21
  br label %bb447
bb446:
  %t1660 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 8
  %t1661 = load i64, ptr %t1660, !tbaa !24
  %t1662 = load i64, ptr %l12, !tbaa !24
  %t1665 = icmp sge i64 %t1661, %t1662
  store i1 %t1665, ptr %l935, !tbaa !21
  br label %bb447
bb447:
  %t1667 = load i1, ptr %l935, !tbaa !21
  br i1 %t1667, label %bb448, label %bb449
bb448:
  store i1 true, ptr %l939, !tbaa !21
  br label %bb452
bb449:
  %t1668 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1669 = load i64, ptr %t1668, !tbaa !24
  %t1672 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t1669)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1672, ptr %l942
  br label %bb450
bb450:
  %t1673 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l942
  %t1674 = call ptr @__olang_scope_alloc_a(ptr %s82, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1673, ptr %t1674
  %t1676 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t1674)
  store i64 %t1676, ptr %l944
  br label %bb451
bb451:
  %t1677 = load i64, ptr %l944, !tbaa !24
  %t1678 = icmp eq i64 %t1677, 0
  store i1 %t1678, ptr %l939, !tbaa !21
  br label %bb452
bb452:
  %t1680 = load i1, ptr %l939, !tbaa !21
  br i1 %t1680, label %bb453, label %bb454
bb453:
  call void @__olang_scope_close(ptr %s82)
  br label %bb460
bb454:
  br label %bb455
bb455:
  %t1681 = load ptr, ptr %l3, !tbaa !29
  %t1683 = getelementptr %"compiler/typed:Call", ptr %t1681, i32 0, i32 1
  %t1684 = load { i64, ptr }, ptr %t1683, !tbaa !27
  store { i64, ptr } %t1684, ptr %l947, !tbaa !27
  %t1685 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 8
  %t1686 = load i64, ptr %t1685, !tbaa !24
  %t1688 = getelementptr { i64, ptr }, ptr %l947, i32 0, i32 1
  %t1689 = load ptr, ptr %t1688, !tbaa !27
  %t1690 = getelementptr ptr, ptr %t1689, i64 %t1686
  %t1691 = load ptr, ptr %t1690, !tbaa !39
  store ptr %t1691, ptr %l134, !tbaa !29
  %t1693 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1693, ptr %l950, !tbaa !29
  %t1694 = load ptr, ptr %l134, !tbaa !29
  %t1696 = call ptr @compiler_2fviews_2eargPlace(ptr %v1, ptr %t1694)
  store ptr %t1696, ptr %l952
  br label %bb456
bb456:
  %t1697 = load ptr, ptr %l134, !tbaa !29
  %t1699 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1697)
  store i32 %t1699, ptr %l954
  br label %bb457
bb457:
  %t1700 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1701 = load i64, ptr %t1700, !tbaa !24
  %t1704 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t1701)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1704, ptr %l957
  br label %bb458
bb458:
  %t1705 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l957
  %t1706 = call ptr @__olang_scope_alloc_a(ptr %s82, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1705, ptr %t1706
  %t1707 = load ptr, ptr %l4, !tbaa !29
  %t1708 = load ptr, ptr %l950, !tbaa !29
  %t1709 = load ptr, ptr %l952, !tbaa !29
  %t1710 = load i32, ptr %l954, !tbaa !23
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t1708, ptr %t1709, i32 %t1710, ptr %t1706, ptr %t1707)
  br label %bb459
bb459:
  call void @__olang_scope_close(ptr %s82)
  br label %bb460
bb460:
  %t1713 = load i64, ptr %l132, !tbaa !24
  %t1715 = add i64 %t1713, 1
  store i64 %t1715, ptr %l132, !tbaa !24
  br label %bb435
bb461:
  %t1717 = load i64, ptr %l129, !tbaa !24
  %t1718 = load i64, ptr %l131, !tbaa !24
  %t1721 = add i64 %t1717, %t1718
  store i64 %t1721, ptr %l129, !tbaa !24
  call void @__olang_scope_close(ptr %s81)
  br label %bb462
bb462:
  br label %bb428
bb463:
  br label %bb464
bb464:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/source:Span"
  %l20 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i8
  %l32 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr ptr, ptr %t15, i64 0
  %t17 = load ptr, ptr %t16, !tbaa !39
  %t19 = call i64 @compiler_2fviews_2eexprEnd(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l12
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t37 = icmp eq i32 %t32, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = icmp slt i64 %t39, %t43
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l20, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t49, i64 %t50)
  store i64 %t53, ptr %l27
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t55, i64 %t56)
  store i8 %t59, ptr %l30
  br label %bb11
bb11:
  %t60 = load i8, ptr %l30, !tbaa !22
  %t61 = icmp eq i8 %t60, 46
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = add i64 %t65, 1
  %t70 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t64, i64 %t67)
  store i64 %t70, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t71 = load ptr, ptr %l32, !tbaa !29
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t71, i64 %t72)
  store %"compiler/source:Span" %t73, ptr %l37
  br label %bb15
bb15:
  %t74 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t74, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t75, i64 %t79)
  store %"compiler/source:Span" %t82, ptr %l41
  br label %bb19
bb19:
  %t83 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  br label %bb19
bb7:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { i32 }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t42 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 1
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l26
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %l7, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_38f43db71f48b164_beb7f8d1a31792c8)
  unreachable
bb19:
  %t56 = load i32, ptr %l7, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/views:Viewer", ptr %t9, i32 0, i32 10
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 11
  %t71 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l17 = alloca i1
  %l22 = alloca i8
  %l23 = alloca { i64, ptr }
  %rv = alloca i8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 5
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/views:Viewer", ptr %t4, i32 0, i32 19
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_66a9fc2455c15d42_1dde5b0b0f74f18e)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/views:Viewer", ptr %t11, i32 0, i32 19
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l14
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25
ok.25:
  store { i64, ptr } %t22, ptr %l13
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp slt i64 %t32, %t35
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l23, !tbaa !27
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  store i8 %t47, ptr %l22, !tbaa !22
  br label %bb13
bb12:
  store i8 0, ptr %l22, !tbaa !22
  br label %bb13
bb13:
  %t49 = load i8, ptr %l22, !tbaa !22
  store i8 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca %"compiler/views:state"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/views:state"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l18 = alloca %"compiler/views:state"
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"compiler/views:state"
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s0, ptr %t7)
  store %"compiler/views:state" %t9, ptr %l18
  br label %bb4
bb4:
  %t10 = load %"compiler/views:state", ptr %l18
  store %"compiler/views:state" %t10, ptr %l4
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb7:
  br label %bb8
bb8:
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t25, ptr %l26, !tbaa !27
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l8, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s3, ptr %t33)
  store %"compiler/views:state" %t35, ptr %l30
  br label %bb9
bb9:
  %t36 = load %"compiler/views:state", ptr %l30
  store %"compiler/views:state" %t36, ptr %l9
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Clause", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s3, ptr %t37, ptr %t41, ptr %l9)
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l8, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Clause", ptr %t45, i32 0, i32 4
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l8, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Clause", ptr %t54, i32 0, i32 4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l12, !tbaa !24
  br label %bb13
bb12:
  br label %bb20
bb13:
  store %olang.scope zeroinitializer, ptr %s6
  %t63 = load i64, ptr %l11, !tbaa !24
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t71 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t71, ptr %l47, !tbaa !27
  %t72 = load i64, ptr %l11, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %v3, ptr %t79, ptr %t77, ptr %l9, ptr %a3)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l11, !tbaa !24
  br label %bb13
bb19:
  br label %bb20
bb20:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s3, ptr %l4, ptr %l9)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb5
bb23:
  %t97 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s0, ptr %t97, ptr %l4)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecomponents(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l44 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l101 = alloca i64
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:Viewer", ptr %t55, i32 0, i32 10
  store ptr %t57, ptr %l44, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/views:Viewer", ptr %t58, i32 0, i32 11
  %t62 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l47
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l44, !tbaa !29
  %t64 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l51
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l51, !tbaa !29
  store ptr %t72, ptr %l8, !tbaa !29
  %t73 = load ptr, ptr %l8, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 11
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l8, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 11
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/views:Viewer", ptr %t86, i32 0, i32 11
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v0, ptr %t85, ptr %t88)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/views:Viewer", ptr %t91, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t93, i64 -1)
  br label %bb19
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/views:Viewer", ptr %t95, i32 0, i32 13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t97, i64 0)
  br label %bb20
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/views:Viewer", ptr %t99, i32 0, i32 14
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t101, i1 false)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb8
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/views:Viewer", ptr %t107, i32 0, i32 10
  store ptr %t109, ptr %l69, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/views:Viewer", ptr %t110, i32 0, i32 11
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l72
  br label %bb24
bb24:
  %t115 = load ptr, ptr %l69, !tbaa !29
  %t116 = load i64, ptr %l72, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t115, i64 %t116)
  br label %bb25
bb25:
  store i64 0, ptr %l9, !tbaa !24
  %t117 = load i64, ptr %l1, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb26, label %bb27
bb26:
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb28:
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l80, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t145 = load i64, ptr %l80, !tbaa !24
  store i64 %t145, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t146 = load i64, ptr %l77, !tbaa !24
  store i64 %t146, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb34:
  br label %bb35
bb35:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l14, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/views:Viewer", ptr %t165, i32 0, i32 12
  %t168 = load i64, ptr %l14, !tbaa !24
  %t171 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l101
  br label %bb36
bb36:
  %t172 = load i64, ptr %l101, !tbaa !24
  %t173 = icmp slt i64 %t172, 0
  br i1 %t173, label %bb37, label %bb38
bb37:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %t175, i64 %t176)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t179 = load i64, ptr %l13, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l13, !tbaa !24
  br label %bb32
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:Viewer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb4
bb3:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t24 = load i32, ptr %l12, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t25 = load i32, ptr %l7, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca %"compiler/views:state"
  %l45 = alloca %"compiler/views:state"
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i64
  %l75 = alloca i1
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca ptr
  %l81 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l155 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l171 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca i1
  %l199 = alloca i64
  %l202 = alloca i64
  %l220 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l222 = alloca { i64, ptr }
  %l229 = alloca i1
  %l230 = alloca i1
  %l234 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l247 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l285 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l291 = alloca i1
  %l293 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l297 = alloca i32
  %l306 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l313 = alloca %"compiler/views:view"
  %l319 = alloca ptr
  %l320 = alloca i1
  %l332 = alloca %"compiler/views:state"
  %l334 = alloca %"compiler/views:state"
  %l350 = alloca ptr
  %l351 = alloca i1
  %l364 = alloca { i64, ptr }
  %l378 = alloca ptr
  %l379 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca i1
  %l404 = alloca ptr
  %l405 = alloca i1
  %l410 = alloca ptr
  %l411 = alloca i1
  %l423 = alloca { i64, ptr }
  %l434 = alloca ptr
  %l435 = alloca i1
  %l445 = alloca ptr
  %l446 = alloca i1
  %l459 = alloca { i64, ptr }
  %l462 = alloca ptr
  %l463 = alloca i1
  %l475 = alloca ptr
  %l476 = alloca i1
  %l486 = alloca ptr
  %l488 = alloca i32
  %l489 = alloca i1
  %l491 = alloca { i64, ptr }
  %l494 = alloca { i64, ptr }
  %l495 = alloca i32
  %l504 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l75, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l75, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l78
  br label %bb7
bb7:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l4
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l79
  br label %bb8
bb8:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l5
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t16 = load ptr, ptr %l80, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l80, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l81, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l81, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t30, ptr %t31, i1 false, ptr %t33, ptr %l4)
  br label %bb14
bb14:
  br label %bb248
bb15:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t39 = load ptr, ptr %l91, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l91, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l92, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l92, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t53, ptr %t54, i1 true, ptr %t56, ptr %l4)
  br label %bb21
bb21:
  br label %bb248
bb22:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t62 = load ptr, ptr %l102, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l102, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l103, !tbaa !21
  br label %bb24
bb24:
  %t69 = load i1, ptr %l103, !tbaa !21
  br i1 %t69, label %bb25, label %bb26
bb25:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l8, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t76, ptr %t77, i1 false, ptr %t79, ptr %l4)
  br label %bb28
bb28:
  br label %bb248
bb29:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t85 = load ptr, ptr %l113, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l113, !tbaa !29
  %t89 = load i64, ptr %t88
  %t91 = icmp eq i64 %t89, 5
  store i1 %t91, ptr %l114, !tbaa !21
  br label %bb31
bb31:
  %t92 = load i1, ptr %l114, !tbaa !21
  br i1 %t92, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l9, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l9, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t99, ptr %t103, ptr %t105, ptr %l4)
  br label %bb35
bb35:
  br label %bb248
bb36:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t111 = load ptr, ptr %l125, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l125, !tbaa !29
  %t115 = load i64, ptr %t114
  %t117 = icmp eq i64 %t115, 6
  store i1 %t117, ptr %l126, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l126, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t121, i32 0, i32 0
  %t123 = load %"compiler/source:Span", ptr %t122
  store %"compiler/source:Span" %t123, ptr %l10
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t127, i32 0, i32 1
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l11, !tbaa !23
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t133, i32 0, i32 2
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l12, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l10
  %t139 = load i32, ptr %l11, !tbaa !23
  %t140 = load ptr, ptr %l12, !tbaa !29
  %t141 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t137, %"compiler/source:Span" %t138, i32 %t139, ptr %t140, ptr %t141, ptr %l4)
  br label %bb42
bb42:
  br label %bb248
bb43:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t149 = load ptr, ptr %l141, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = load ptr, ptr %l141, !tbaa !29
  %t153 = load i64, ptr %t152
  %t155 = icmp eq i64 %t153, 7
  store i1 %t155, ptr %l142, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l142, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l13, !tbaa !29
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t163 = load ptr, ptr %l13, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Make", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l16, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t172 = load i64, ptr %l15, !tbaa !24
  %t173 = load i64, ptr %l16, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t180 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t180, ptr %l155, !tbaa !27
  %t181 = load i64, ptr %l15, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 %t181
  %t186 = load ptr, ptr %t185, !tbaa !39
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t188, ptr %t186, ptr %t191, ptr %l4)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t196 = load i64, ptr %l15, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l15, !tbaa !24
  br label %bb49
bb55:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l13, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Make", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t200, ptr %t204, ptr %t205, ptr %l5)
  br label %bb56
bb56:
  br label %bb248
bb57:
  %t210 = load ptr, ptr %l1, !tbaa !29
  store ptr %t210, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t211 = load ptr, ptr %l170, !tbaa !29
  %t212 = icmp ne ptr %t211, null
  br i1 %t212, label %bb58, label %bb59
bb58:
  %t214 = load ptr, ptr %l170, !tbaa !29
  %t215 = load i64, ptr %t214
  %t217 = icmp eq i64 %t215, 8
  store i1 %t217, ptr %l171, !tbaa !21
  br label %bb59
bb59:
  %t218 = load i1, ptr %l171, !tbaa !21
  br i1 %t218, label %bb60, label %bb61
bb60:
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr { i64, [5 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t221, i32 0, i32 2
  %t223 = load ptr, ptr %t222
  store ptr %t223, ptr %l18, !tbaa !29
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l18, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Collect", ptr %t226, i32 0, i32 0
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t230 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t225, ptr %t229, ptr %t230, ptr %l5)
  br label %bb63
bb63:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l18, !tbaa !29
  %t238 = getelementptr %"compiler/typed:Collect", ptr %t236, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !29
  %t241 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t235, ptr %t239, ptr %t241)
  br label %bb64
bb64:
  br label %bb248
bb65:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t246 = load ptr, ptr %l186, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb66, label %bb67
bb66:
  %t249 = load ptr, ptr %l186, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 9
  store i1 %t252, ptr %l187, !tbaa !21
  br label %bb67
bb67:
  %t253 = load i1, ptr %l187, !tbaa !21
  br i1 %t253, label %bb68, label %bb69
bb68:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t256, i32 0, i32 2
  %t258 = load i32, ptr %t257
  store i32 %t258, ptr %l19
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = getelementptr { i64, [5 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t262, i32 0, i32 4
  %t264 = load { i64, ptr }, ptr %t263
  store { i64, ptr } %t264, ptr %l20, !tbaa !27
  br label %bb70
bb69:
  br label %bb108
bb70:
  store i64 0, ptr %l21, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  store i64 %t268, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t270 = load i64, ptr %l22, !tbaa !24
  %t271 = load i64, ptr %l21, !tbaa !24
  %t274 = icmp sgt i64 %t270, %t271
  br i1 %t274, label %bb71, label %bb72
bb71:
  %t276 = load i64, ptr %l23, !tbaa !24
  %t278 = icmp sgt i64 %t276, 0
  br i1 %t278, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb76
bb73:
  %t280 = load i64, ptr %l22, !tbaa !24
  %t281 = load i64, ptr %l21, !tbaa !24
  %t284 = sub i64 %t280, %t281
  %t285 = load i64, ptr %l23, !tbaa !24
  %t288 = add i64 %t284, %t285
  %t290 = sub i64 %t288, 1
  %t291 = load i64, ptr %l23, !tbaa !24
  %t294 = sdiv i64 %t290, %t291
  store i64 %t294, ptr %l202, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb75
bb75:
  %t296 = load i64, ptr %l202, !tbaa !24
  store i64 %t296, ptr %l199, !tbaa !24
  br label %bb76
bb76:
  %t297 = load i64, ptr %l199, !tbaa !24
  store i64 %t297, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t298 = load i64, ptr %l25, !tbaa !24
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb107
bb79:
  br label %bb80
bb80:
  %t306 = load i64, ptr %l21, !tbaa !24
  %t307 = load i64, ptr %l25, !tbaa !24
  %t308 = load i64, ptr %l23, !tbaa !24
  %t311 = mul i64 %t307, %t308
  %t314 = add i64 %t306, %t311
  store i64 %t314, ptr %l26, !tbaa !24
  %t316 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t316, ptr %l220
  br label %bb81
bb81:
  %t317 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l220
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t317, ptr %l27
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t319, ptr %l222, !tbaa !27
  %t320 = load i64, ptr %l26, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr ptr, ptr %t323, i64 %t320
  %t325 = load ptr, ptr %t324, !tbaa !39
  %t327 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s14, ptr %t318, ptr %t325, ptr %t327, ptr %l27)
  br label %bb82
bb82:
  %t332 = load i32, ptr %l19
  %t334 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t332)
  store i1 %t334, ptr %l229
  br label %bb83
bb83:
  %t335 = load i1, ptr %l229, !tbaa !21
  br i1 %t335, label %bb84, label %bb85
bb84:
  %t336 = load i64, ptr %l26, !tbaa !24
  %t338 = icmp eq i64 %t336, 0
  store i1 %t338, ptr %l230, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb86
bb86:
  %t340 = load i1, ptr %l230, !tbaa !21
  br i1 %t340, label %bb87, label %bb88
bb87:
  store ptr %l27, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb89
bb88:
  br label %bb105
bb89:
  store %olang.scope zeroinitializer, ptr %s17
  %t342 = load ptr, ptr %l28, !tbaa !29
  %t343 = load i64, ptr %l29, !tbaa !24
  %t346 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s14, ptr %t342, i64 %t343)
  %t347 = extractvalue { i32, { i64, ptr } } %t346, 1
  %t348 = extractvalue { i32, { i64, ptr } } %t346, 0
  store i32 %t348, ptr %l238
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb91, label %ok.350
ok.350:
  store { i64, ptr } %t347, ptr %l237
  br label %bb90
bb90:
  %t351 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t351, ptr %l234, !tbaa !27
  br label %bb95
bb91:
  %t352 = load i32, ptr %l238, !tbaa !23
  %t353 = ashr i32 %t352, 16
  %t355 = icmp eq i32 %t353, 1
  br i1 %t355, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_57534b0b4c840b9f_734207cf536b370b)
  unreachable
bb94:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb95:
  %t357 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t357, ptr %l30, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t358, 0
  store i64 %t360, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s18
  %t362 = load i64, ptr %l32, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t370 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t370, ptr %l247, !tbaa !27
  %t371 = load i64, ptr %l32, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr %"compiler/views:view", ptr %t374, i64 %t371
  %t376 = load %"compiler/views:view", ptr %t375
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %l4, %"compiler/views:view" %t376)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  %t381 = load i64, ptr %l32, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l32, !tbaa !24
  br label %bb96
bb102:
  %t385 = load i64, ptr %l29, !tbaa !24
  %t386 = load i64, ptr %l31, !tbaa !24
  %t389 = add i64 %t385, %t386
  store i64 %t389, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb103:
  br label %bb89
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s14)
  br label %bb106
bb106:
  %t391 = load i64, ptr %l25, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l25, !tbaa !24
  br label %bb77
bb107:
  br label %bb248
bb108:
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t396 = load ptr, ptr %l259, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb109, label %bb110
bb109:
  %t399 = load ptr, ptr %l259, !tbaa !29
  %t400 = load i64, ptr %t399
  %t402 = icmp eq i64 %t400, 10
  store i1 %t402, ptr %l260, !tbaa !21
  br label %bb110
bb110:
  %t403 = load i1, ptr %l260, !tbaa !21
  br i1 %t403, label %bb111, label %bb112
bb111:
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t406, i32 0, i32 0
  %t408 = load %"compiler/source:Span", ptr %t407
  store %"compiler/source:Span" %t408, ptr %l34
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t412, i32 0, i32 2
  %t414 = load ptr, ptr %t413
  store ptr %t414, ptr %l35, !tbaa !29
  br label %bb113
bb112:
  br label %bb139
bb113:
  store %olang.scope zeroinitializer, ptr %s21
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l35, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Slice", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t416, ptr %t420, i1 false, ptr %t422, ptr %l4)
  br label %bb114
bb114:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load ptr, ptr %l35, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Slice", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t427, ptr %t431, ptr %t433, ptr %l5)
  br label %bb115
bb115:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l35, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Slice", ptr %t439, i32 0, i32 2
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t438, ptr %t442, ptr %t444, ptr %l5)
  br label %bb116
bb116:
  %t449 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t449, ptr %l285
  br label %bb117
bb117:
  %t450 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l285
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t450, ptr %l36
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load ptr, ptr %l35, !tbaa !29
  %t454 = getelementptr %"compiler/typed:Slice", ptr %t452, i32 0, i32 0
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t456 = load ptr, ptr %l2, !tbaa !29
  %t461 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %s21, ptr %t451, ptr %t455, ptr %t456, ptr %l36)
  store i1 %t461, ptr %l291
  br label %bb118
bb118:
  %t462 = load i1, ptr %l291, !tbaa !21
  br i1 %t462, label %bb119, label %bb120
bb119:
  store ptr %l36, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb121
bb120:
  br label %bb138
bb121:
  store %olang.scope zeroinitializer, ptr %s24
  %t464 = load ptr, ptr %l37, !tbaa !29
  %t465 = load i64, ptr %l38, !tbaa !24
  %t468 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s21, ptr %t464, i64 %t465)
  %t469 = extractvalue { i32, { i64, ptr } } %t468, 1
  %t470 = extractvalue { i32, { i64, ptr } } %t468, 0
  store i32 %t470, ptr %l297
  %t471 = icmp ne i32 %t470, 0
  br i1 %t471, label %bb123, label %ok.472
ok.472:
  store { i64, ptr } %t469, ptr %l296
  br label %bb122
bb122:
  %t473 = load { i64, ptr }, ptr %l296, !tbaa !27
  store { i64, ptr } %t473, ptr %l293, !tbaa !27
  br label %bb127
bb123:
  %t474 = load i32, ptr %l297, !tbaa !23
  %t475 = ashr i32 %t474, 16
  %t477 = icmp eq i32 %t475, 1
  br i1 %t477, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_eef44a73fed7a11e_ba98d4574b3cccca)
  unreachable
bb126:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s24)
  br label %bb137
bb127:
  %t479 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t479, ptr %l39, !tbaa !27
  %t480 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  store i64 %t482, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s25
  %t484 = load i64, ptr %l41, !tbaa !24
  %t485 = load i64, ptr %l40, !tbaa !24
  %t488 = icmp slt i64 %t484, %t485
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s25)
  br label %bb135
bb130:
  br label %bb131
bb131:
  %t492 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t492, ptr %l306, !tbaa !27
  %t493 = load i64, ptr %l41, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr %"compiler/views:place", ptr %t496, i64 %t493
  %t498 = load %"compiler/views:place", ptr %t497
  store ptr %l4, ptr %l309, !tbaa !29
  %t501 = getelementptr %"compiler/source:Span", ptr %l34, i32 0, i32 0
  %t502 = load i32, ptr %t501, !tbaa !23
  %t504 = sext i32 %t502 to i64
  %t507 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s25, %"compiler/views:place" %t498, i64 %t504)
  store %"compiler/views:view" %t507, ptr %l313
  br label %bb132
bb132:
  %t508 = load ptr, ptr %l309, !tbaa !29
  %t509 = load %"compiler/views:view", ptr %l313
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %t508, %"compiler/views:view" %t509)
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s25)
  br label %bb134
bb134:
  %t510 = load i64, ptr %l41, !tbaa !24
  %t512 = add i64 %t510, 1
  store i64 %t512, ptr %l41, !tbaa !24
  br label %bb128
bb135:
  %t514 = load i64, ptr %l38, !tbaa !24
  %t515 = load i64, ptr %l40, !tbaa !24
  %t518 = add i64 %t514, %t515
  store i64 %t518, ptr %l38, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb136
bb136:
  br label %bb121
bb137:
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s21)
  br label %bb248
bb139:
  %t520 = load ptr, ptr %l1, !tbaa !29
  store ptr %t520, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t521 = load ptr, ptr %l319, !tbaa !29
  %t522 = icmp ne ptr %t521, null
  br i1 %t522, label %bb140, label %bb141
bb140:
  %t524 = load ptr, ptr %l319, !tbaa !29
  %t525 = load i64, ptr %t524
  %t527 = icmp eq i64 %t525, 11
  store i1 %t527, ptr %l320, !tbaa !21
  br label %bb141
bb141:
  %t528 = load i1, ptr %l320, !tbaa !21
  br i1 %t528, label %bb142, label %bb143
bb142:
  %t529 = load ptr, ptr %l1, !tbaa !29
  %t531 = getelementptr { i64, [5 x i64] }, ptr %t529, i32 0, i32 1
  %t532 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t531, i32 0, i32 2
  %t533 = load ptr, ptr %t532
  store ptr %t533, ptr %l43, !tbaa !29
  br label %bb144
bb143:
  br label %bb152
bb144:
  store %olang.scope zeroinitializer, ptr %s27
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l43, !tbaa !29
  %t538 = getelementptr %"compiler/typed:Cond", ptr %t536, i32 0, i32 0
  %t539 = load ptr, ptr %t538, !tbaa !29
  %t541 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t535, ptr %t539, ptr %t541, ptr %l5)
  br label %bb145
bb145:
  %t546 = load ptr, ptr %l2, !tbaa !29
  %t548 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s27, ptr %t546)
  store %"compiler/views:state" %t548, ptr %l332
  br label %bb146
bb146:
  %t549 = load %"compiler/views:state", ptr %l332
  store %"compiler/views:state" %t549, ptr %l44
  %t550 = load ptr, ptr %l2, !tbaa !29
  %t552 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s27, ptr %t550)
  store %"compiler/views:state" %t552, ptr %l334
  br label %bb147
bb147:
  %t553 = load %"compiler/views:state", ptr %l334
  store %"compiler/views:state" %t553, ptr %l45
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l43, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Cond", ptr %t555, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %s0, ptr %t554, ptr %t558, ptr %l44, ptr %l4)
  br label %bb148
bb148:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l43, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Cond", ptr %t564, i32 0, i32 2
  %t567 = load ptr, ptr %t566, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %s0, ptr %t563, ptr %t567, ptr %l45, ptr %l4)
  br label %bb149
bb149:
  call void @compiler_2fviews_2emerge(ptr %s27, ptr %s27, ptr %l44, ptr %l45)
  br label %bb150
bb150:
  %t575 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s27, ptr %t575, ptr %l44)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s27)
  br label %bb248
bb152:
  %t578 = load ptr, ptr %l1, !tbaa !29
  store ptr %t578, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t579 = load ptr, ptr %l350, !tbaa !29
  %t580 = icmp ne ptr %t579, null
  br i1 %t580, label %bb153, label %bb154
bb153:
  %t582 = load ptr, ptr %l350, !tbaa !29
  %t583 = load i64, ptr %t582
  %t585 = icmp eq i64 %t583, 12
  store i1 %t585, ptr %l351, !tbaa !21
  br label %bb154
bb154:
  %t586 = load i1, ptr %l351, !tbaa !21
  br i1 %t586, label %bb155, label %bb156
bb155:
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t589 = getelementptr { i64, [5 x i64] }, ptr %t587, i32 0, i32 1
  %t590 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t589, i32 0, i32 2
  %t591 = load ptr, ptr %t590
  store ptr %t591, ptr %l46, !tbaa !29
  br label %bb157
bb156:
  br label %bb166
bb157:
  %t593 = load ptr, ptr %l46, !tbaa !29
  %t595 = getelementptr %"compiler/typed:Seq", ptr %t593, i32 0, i32 0
  %t596 = load { i64, ptr }, ptr %t595, !tbaa !27
  store { i64, ptr } %t596, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t598 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t598, 0
  store i64 %t600, ptr %l49, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s30
  %t602 = load i64, ptr %l48, !tbaa !24
  %t603 = load i64, ptr %l49, !tbaa !24
  %t606 = icmp slt i64 %t602, %t603
  %t608 = xor i1 %t606, true
  br i1 %t608, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s30)
  br label %bb164
bb160:
  br label %bb161
bb161:
  %t610 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t610, ptr %l364, !tbaa !27
  %t611 = load i64, ptr %l48, !tbaa !24
  %t613 = getelementptr { i64, ptr }, ptr %l364, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr ptr, ptr %t614, i64 %t611
  %t616 = load ptr, ptr %t615, !tbaa !39
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t621 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t618, ptr %t616, ptr %t621)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s30)
  br label %bb163
bb163:
  %t625 = load i64, ptr %l48, !tbaa !24
  %t627 = add i64 %t625, 1
  store i64 %t627, ptr %l48, !tbaa !24
  br label %bb158
bb164:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load ptr, ptr %l46, !tbaa !29
  %t632 = getelementptr %"compiler/typed:Seq", ptr %t630, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !29
  %t634 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t629, ptr %t633, ptr %t634, ptr %l4)
  br label %bb165
bb165:
  br label %bb248
bb166:
  %t639 = load ptr, ptr %l1, !tbaa !29
  store ptr %t639, ptr %l378, !tbaa !29
  store i1 false, ptr %l379, !tbaa !21
  %t640 = load ptr, ptr %l378, !tbaa !29
  %t641 = icmp ne ptr %t640, null
  br i1 %t641, label %bb167, label %bb168
bb167:
  %t643 = load ptr, ptr %l378, !tbaa !29
  %t644 = load i64, ptr %t643
  %t646 = icmp eq i64 %t644, 13
  store i1 %t646, ptr %l379, !tbaa !21
  br label %bb168
bb168:
  %t647 = load i1, ptr %l379, !tbaa !21
  br i1 %t647, label %bb169, label %bb170
bb169:
  %t648 = load ptr, ptr %l1, !tbaa !29
  %t650 = getelementptr { i64, [5 x i64] }, ptr %t648, i32 0, i32 1
  %t651 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t650, i32 0, i32 2
  %t652 = load ptr, ptr %t651
  store ptr %t652, ptr %l51, !tbaa !29
  br label %bb171
bb170:
  br label %bb173
bb171:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load ptr, ptr %l51, !tbaa !29
  %t656 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t654, ptr %t655, ptr %t656, ptr %l4)
  br label %bb172
bb172:
  br label %bb248
bb173:
  %t661 = load ptr, ptr %l1, !tbaa !29
  store ptr %t661, ptr %l388, !tbaa !29
  store i1 false, ptr %l389, !tbaa !21
  %t662 = load ptr, ptr %l388, !tbaa !29
  %t663 = icmp ne ptr %t662, null
  br i1 %t663, label %bb174, label %bb175
bb174:
  %t665 = load ptr, ptr %l388, !tbaa !29
  %t666 = load i64, ptr %t665
  %t668 = icmp eq i64 %t666, 14
  store i1 %t668, ptr %l389, !tbaa !21
  br label %bb175
bb175:
  %t669 = load i1, ptr %l389, !tbaa !21
  br i1 %t669, label %bb176, label %bb177
bb176:
  %t670 = load ptr, ptr %l1, !tbaa !29
  %t672 = getelementptr { i64, [5 x i64] }, ptr %t670, i32 0, i32 1
  %t673 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t672, i32 0, i32 2
  %t674 = load ptr, ptr %t673
  store ptr %t674, ptr %l52, !tbaa !29
  br label %bb178
bb177:
  br label %bb181
bb178:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load ptr, ptr %l52, !tbaa !29
  %t679 = getelementptr %"compiler/typed:Try", ptr %t677, i32 0, i32 0
  %t680 = load ptr, ptr %t679, !tbaa !29
  %t681 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t676, ptr %t680, ptr %t681, ptr %l4)
  br label %bb179
bb179:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load ptr, ptr %l52, !tbaa !29
  %t689 = getelementptr %"compiler/typed:Try", ptr %t687, i32 0, i32 1
  %t690 = load { i64, ptr }, ptr %t689, !tbaa !27
  %t691 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t686, { i64, ptr } %t690, ptr %t691, ptr %l4)
  br label %bb180
bb180:
  br label %bb248
bb181:
  %t696 = load ptr, ptr %l1, !tbaa !29
  store ptr %t696, ptr %l404, !tbaa !29
  store i1 false, ptr %l405, !tbaa !21
  %t697 = load ptr, ptr %l404, !tbaa !29
  %t698 = icmp ne ptr %t697, null
  br i1 %t698, label %bb182, label %bb183
bb182:
  %t700 = load ptr, ptr %l404, !tbaa !29
  %t701 = load i64, ptr %t700
  %t703 = icmp eq i64 %t701, 15
  store i1 %t703, ptr %l405, !tbaa !21
  br label %bb183
bb183:
  %t704 = load i1, ptr %l405, !tbaa !21
  br i1 %t704, label %bb184, label %bb185
bb184:
  %t705 = load ptr, ptr %l1, !tbaa !29
  %t707 = getelementptr { i64, [5 x i64] }, ptr %t705, i32 0, i32 1
  %t708 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t707, i32 0, i32 2
  %t709 = load ptr, ptr %t708
  store ptr %t709, ptr %l53, !tbaa !29
  br label %bb186
bb185:
  br label %bb212
bb186:
  %t711 = load ptr, ptr %l53, !tbaa !29
  store ptr %t711, ptr %l410, !tbaa !29
  store i1 false, ptr %l411, !tbaa !21
  %t712 = load ptr, ptr %l410, !tbaa !29
  %t713 = icmp ne ptr %t712, null
  br i1 %t713, label %bb187, label %bb188
bb187:
  %t715 = load ptr, ptr %l410, !tbaa !29
  %t716 = load i64, ptr %t715
  %t718 = icmp eq i64 %t716, 1
  store i1 %t718, ptr %l411, !tbaa !21
  br label %bb188
bb188:
  %t719 = load i1, ptr %l411, !tbaa !21
  br i1 %t719, label %bb189, label %bb190
bb189:
  %t720 = load ptr, ptr %l53, !tbaa !29
  %t722 = getelementptr { i64, [4 x i64] }, ptr %t720, i32 0, i32 1
  %t723 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t722, i32 0, i32 1
  %t724 = load { i64, ptr }, ptr %t723
  store { i64, ptr } %t724, ptr %l54, !tbaa !27
  br label %bb191
bb190:
  br label %bb199
bb191:
  %t726 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t726, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t728 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t730 = extractvalue { i64, ptr } %t728, 0
  store i64 %t730, ptr %l57, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s37
  %t732 = load i64, ptr %l56, !tbaa !24
  %t733 = load i64, ptr %l57, !tbaa !24
  %t736 = icmp slt i64 %t732, %t733
  %t738 = xor i1 %t736, true
  br i1 %t738, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s37)
  br label %bb198
bb194:
  br label %bb195
bb195:
  %t740 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t740, ptr %l423, !tbaa !27
  %t741 = load i64, ptr %l56, !tbaa !24
  %t743 = getelementptr { i64, ptr }, ptr %l423, i32 0, i32 1
  %t744 = load ptr, ptr %t743, !tbaa !27
  %t745 = getelementptr ptr, ptr %t744, i64 %t741
  %t746 = load ptr, ptr %t745, !tbaa !39
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t751 = getelementptr %"compiler/typed:Capture", ptr %t746, i32 0, i32 1
  %t752 = load ptr, ptr %t751, !tbaa !29
  %t754 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t748, ptr %t752, ptr %t754, ptr %l4)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s37)
  br label %bb197
bb197:
  %t759 = load i64, ptr %l56, !tbaa !24
  %t761 = add i64 %t759, 1
  store i64 %t761, ptr %l56, !tbaa !24
  br label %bb192
bb198:
  br label %bb211
bb199:
  %t763 = load ptr, ptr %l53, !tbaa !29
  store ptr %t763, ptr %l434, !tbaa !29
  store i1 false, ptr %l435, !tbaa !21
  %t764 = load ptr, ptr %l434, !tbaa !29
  %t765 = icmp ne ptr %t764, null
  br i1 %t765, label %bb200, label %bb201
bb200:
  %t767 = load ptr, ptr %l434, !tbaa !29
  %t768 = load i64, ptr %t767
  %t770 = icmp eq i64 %t768, 2
  store i1 %t770, ptr %l435, !tbaa !21
  br label %bb201
bb201:
  %t771 = load i1, ptr %l435, !tbaa !21
  br i1 %t771, label %bb202, label %bb203
bb202:
  %t772 = load ptr, ptr %l53, !tbaa !29
  %t774 = getelementptr { i64, [4 x i64] }, ptr %t772, i32 0, i32 1
  %t775 = getelementptr { i32, ptr, i32 }, ptr %t774, i32 0, i32 1
  %t776 = load ptr, ptr %t775
  store ptr %t776, ptr %l59, !tbaa !29
  br label %bb204
bb203:
  br label %bb206
bb204:
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t779 = load ptr, ptr %l59, !tbaa !29
  %t781 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t778, ptr %t779, ptr %t781, ptr %l4)
  br label %bb205
bb205:
  br label %bb211
bb206:
  br i1 true, label %bb207, label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb210
bb209:
  br label %bb211
bb210:
  call void @__olang_check_failed(ptr @olang_loc_bd4e25d0ba8f3355_5d1878e7bdcf6d61)
  unreachable
bb211:
  br label %bb248
bb212:
  %t786 = load ptr, ptr %l1, !tbaa !29
  store ptr %t786, ptr %l445, !tbaa !29
  store i1 false, ptr %l446, !tbaa !21
  %t787 = load ptr, ptr %l445, !tbaa !29
  %t788 = icmp ne ptr %t787, null
  br i1 %t788, label %bb213, label %bb214
bb213:
  %t790 = load ptr, ptr %l445, !tbaa !29
  %t791 = load i64, ptr %t790
  %t793 = icmp eq i64 %t791, 16
  store i1 %t793, ptr %l446, !tbaa !21
  br label %bb214
bb214:
  %t794 = load i1, ptr %l446, !tbaa !21
  br i1 %t794, label %bb215, label %bb216
bb215:
  %t795 = load ptr, ptr %l1, !tbaa !29
  %t797 = getelementptr { i64, [5 x i64] }, ptr %t795, i32 0, i32 1
  %t798 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t797, i32 0, i32 2
  %t799 = load ptr, ptr %t798
  store ptr %t799, ptr %l60, !tbaa !29
  br label %bb217
bb216:
  br label %bb236
bb217:
  %t801 = load ptr, ptr %l60, !tbaa !29
  %t803 = getelementptr %"compiler/typed:Text", ptr %t801, i32 0, i32 0
  %t804 = load { i64, ptr }, ptr %t803, !tbaa !27
  store { i64, ptr } %t804, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t806 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t806, 0
  store i64 %t808, ptr %l63, !tbaa !24
  br label %bb218
bb218:
  store %olang.scope zeroinitializer, ptr %s43
  %t810 = load i64, ptr %l62, !tbaa !24
  %t811 = load i64, ptr %l63, !tbaa !24
  %t814 = icmp slt i64 %t810, %t811
  %t816 = xor i1 %t814, true
  br i1 %t816, label %bb219, label %bb220
bb219:
  call void @__olang_scope_close(ptr %s43)
  br label %bb235
bb220:
  br label %bb221
bb221:
  %t818 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t818, ptr %l459, !tbaa !27
  %t819 = load i64, ptr %l62, !tbaa !24
  %t821 = getelementptr { i64, ptr }, ptr %l459, i32 0, i32 1
  %t822 = load ptr, ptr %t821, !tbaa !27
  %t823 = getelementptr ptr, ptr %t822, i64 %t819
  %t824 = load ptr, ptr %t823, !tbaa !39
  store ptr %t824, ptr %l64, !tbaa !29
  %t826 = load ptr, ptr %l64, !tbaa !29
  store ptr %t826, ptr %l462, !tbaa !29
  store i1 false, ptr %l463, !tbaa !21
  %t827 = load ptr, ptr %l462, !tbaa !29
  %t828 = icmp ne ptr %t827, null
  br i1 %t828, label %bb222, label %bb223
bb222:
  %t830 = load ptr, ptr %l462, !tbaa !29
  %t831 = load i64, ptr %t830
  %t833 = icmp eq i64 %t831, 1
  store i1 %t833, ptr %l463, !tbaa !21
  br label %bb223
bb223:
  %t834 = load i1, ptr %l463, !tbaa !21
  br i1 %t834, label %bb224, label %bb225
bb224:
  %t835 = load ptr, ptr %l64, !tbaa !29
  %t837 = getelementptr { i64, [2 x i64] }, ptr %t835, i32 0, i32 1
  %t838 = getelementptr { ptr }, ptr %t837, i32 0, i32 0
  %t839 = load ptr, ptr %t838
  store ptr %t839, ptr %l65, !tbaa !29
  br label %bb226
bb225:
  br label %bb228
bb226:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t842 = load ptr, ptr %l65, !tbaa !29
  %t844 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t841, ptr %t842, ptr %t844, ptr %l5)
  br label %bb227
bb227:
  br label %bb233
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb233
bb232:
  call void @__olang_check_failed(ptr @olang_loc_788d78188ea51964_a780363d8c64d7d0)
  unreachable
bb233:
  call void @__olang_scope_close(ptr %s43)
  br label %bb234
bb234:
  %t849 = load i64, ptr %l62, !tbaa !24
  %t851 = add i64 %t849, 1
  store i64 %t851, ptr %l62, !tbaa !24
  br label %bb218
bb235:
  br label %bb248
bb236:
  %t853 = load ptr, ptr %l1, !tbaa !29
  store ptr %t853, ptr %l475, !tbaa !29
  store i1 false, ptr %l476, !tbaa !21
  %t854 = load ptr, ptr %l475, !tbaa !29
  %t855 = icmp ne ptr %t854, null
  br i1 %t855, label %bb237, label %bb238
bb237:
  %t857 = load ptr, ptr %l475, !tbaa !29
  %t858 = load i64, ptr %t857
  %t860 = icmp eq i64 %t858, 17
  store i1 %t860, ptr %l476, !tbaa !21
  br label %bb238
bb238:
  %t861 = load i1, ptr %l476, !tbaa !21
  br i1 %t861, label %bb239, label %bb240
bb239:
  %t862 = load ptr, ptr %l1, !tbaa !29
  %t864 = getelementptr { i64, [5 x i64] }, ptr %t862, i32 0, i32 1
  %t865 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t864, i32 0, i32 2
  %t866 = load ptr, ptr %t865
  store ptr %t866, ptr %l66, !tbaa !29
  br label %bb241
bb240:
  br label %bb243
bb241:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t869 = load ptr, ptr %l66, !tbaa !29
  %t871 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t868, ptr %t869, ptr %t871, ptr %l4)
  br label %bb242
bb242:
  br label %bb248
bb243:
  br i1 true, label %bb244, label %bb245
bb244:
  br label %bb246
bb245:
  br label %bb247
bb246:
  br label %bb248
bb247:
  call void @__olang_check_failed(ptr @olang_loc_9261c738df5c5703_df7f72a5455de2e7)
  unreachable
bb248:
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l486, !tbaa !29
  %t877 = load ptr, ptr %l1, !tbaa !29
  %t879 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t877)
  store i32 %t879, ptr %l488
  br label %bb249
bb249:
  %t880 = load ptr, ptr %l486, !tbaa !29
  %t881 = load i32, ptr %l488, !tbaa !23
  %t882 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t880, i32 %t881)
  store i1 %t882, ptr %l489
  br label %bb250
bb250:
  %t883 = load i1, ptr %l489, !tbaa !21
  br i1 %t883, label %bb251, label %bb252
bb251:
  store ptr %l4, ptr %l67, !tbaa !29
  store i64 0, ptr %l68, !tbaa !24
  br label %bb253
bb252:
  br label %bb269
bb253:
  store %olang.scope zeroinitializer, ptr %s51
  %t885 = load ptr, ptr %l67, !tbaa !29
  %t886 = load i64, ptr %l68, !tbaa !24
  %t889 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t885, i64 %t886)
  %t890 = extractvalue { i32, { i64, ptr } } %t889, 1
  %t891 = extractvalue { i32, { i64, ptr } } %t889, 0
  store i32 %t891, ptr %l495
  %t892 = icmp ne i32 %t891, 0
  br i1 %t892, label %bb255, label %ok.893
ok.893:
  store { i64, ptr } %t890, ptr %l494
  br label %bb254
bb254:
  %t894 = load { i64, ptr }, ptr %l494, !tbaa !27
  store { i64, ptr } %t894, ptr %l491, !tbaa !27
  br label %bb259
bb255:
  %t895 = load i32, ptr %l495, !tbaa !23
  %t896 = ashr i32 %t895, 16
  %t898 = icmp eq i32 %t896, 1
  br i1 %t898, label %bb256, label %bb257
bb256:
  br label %bb258
bb257:
  call void @__olang_check_failed(ptr @olang_loc_ce0fda4981aea582_2b2a2501d91dd806)
  unreachable
bb258:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s51)
  br label %bb268
bb259:
  %t900 = load { i64, ptr }, ptr %l491, !tbaa !27
  store { i64, ptr } %t900, ptr %l69, !tbaa !27
  %t901 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t901, 0
  store i64 %t903, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb260
bb260:
  store %olang.scope zeroinitializer, ptr %s52
  %t905 = load i64, ptr %l71, !tbaa !24
  %t906 = load i64, ptr %l70, !tbaa !24
  %t909 = icmp slt i64 %t905, %t906
  %t911 = xor i1 %t909, true
  br i1 %t911, label %bb261, label %bb262
bb261:
  call void @__olang_scope_close(ptr %s52)
  br label %bb266
bb262:
  br label %bb263
bb263:
  %t913 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t913, ptr %l504, !tbaa !27
  %t914 = load i64, ptr %l71, !tbaa !24
  %t916 = getelementptr { i64, ptr }, ptr %l504, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !27
  %t918 = getelementptr %"compiler/views:view", ptr %t917, i64 %t914
  %t919 = load %"compiler/views:view", ptr %t918
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %a3, %"compiler/views:view" %t919)
  br label %bb264
bb264:
  call void @__olang_scope_close(ptr %s52)
  br label %bb265
bb265:
  %t925 = load i64, ptr %l71, !tbaa !24
  %t927 = add i64 %t925, 1
  store i64 %t927, ptr %l71, !tbaa !24
  br label %bb260
bb266:
  %t929 = load i64, ptr %l68, !tbaa !24
  %t930 = load i64, ptr %l70, !tbaa !24
  %t933 = add i64 %t929, %t930
  store i64 %t933, ptr %l68, !tbaa !24
  call void @__olang_scope_close(ptr %s51)
  br label %bb267
bb267:
  br label %bb253
bb268:
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l4, !tbaa !29
  br label %bb12
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t38, ptr %t39)
  br label %bb13
bb13:
  br label %bb34
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 11
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Cond", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t59, ptr %t63, ptr %t64, ptr %t65)
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Cond", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t70, ptr %t74, ptr %t76, ptr %t77)
  br label %bb21
bb21:
  br label %bb34
bb22:
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t83 = load ptr, ptr %l43, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = load i64, ptr %t86
  %t89 = icmp eq i64 %t87, 17
  store i1 %t89, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t90 = load i1, ptr %l44, !tbaa !21
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t97, ptr %t98, ptr %t100, ptr %t101)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a471d4cd6a39e3a7_bf796cf0b70bcd93)
  unreachable
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i32 %a4, %"compiler/views:place" %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/views:place"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/views:fact"
  %l27 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l89 = alloca { i64, ptr }
  %l95 = alloca i1
  %l99 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i1
  %l122 = alloca i64
  %l126 = alloca { i64, ptr }
  %l129 = alloca i64
  %l134 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i32
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i1
  %l151 = alloca %"compiler/views:fact"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/views:place" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %t5)
  store { i64, ptr } %t8, ptr %l27
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t13 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l9, !tbaa !21
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb7
bb4:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = load i64, ptr %l11, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l13, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l13, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l38, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l38, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l35, !tbaa !24
  store i64 %t47, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l15, !tbaa !24
  %t49 = load i64, ptr %l14, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t56 = load i64, ptr %l11, !tbaa !24
  %t57 = load i64, ptr %l15, !tbaa !24
  %t58 = load i64, ptr %l13, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l16, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t66, ptr %l56, !tbaa !27
  %t67 = load i64, ptr %l16, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 46
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp sgt i64 %t80, 8
  br i1 %t82, label %bb14, label %bb15
bb13:
  br label %bb24
bb14:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l64, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t85, ptr %l65, !tbaa !27
  %t86 = load i64, ptr %l16, !tbaa !24
  store i64 %t86, ptr %l66, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l67, !tbaa !24
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb16, label %bb17
bb15:
  br label %bb23
bb16:
  %t91 = load i64, ptr %l66, !tbaa !24
  %t92 = icmp sle i64 0, %t91
  br i1 %t92, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8)
  unreachable
bb18:
  %t94 = load i64, ptr %l66, !tbaa !24
  %t95 = load i64, ptr %l67, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8)
  unreachable
bb20:
  %t98 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l66, !tbaa !24
  %t101 = getelementptr i8, ptr %t99, i64 0
  %t102 = sub i64 %t100, 0
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %v0, ptr %t105, { i64, ptr } %t104)
  store i64 %t107, ptr %l72
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8)
  unreachable
bb22:
  %t108 = load i64, ptr %l72, !tbaa !24
  store i64 %t108, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t109 = load i64, ptr %l15, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l15, !tbaa !24
  br label %bb8
bb26:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = load ptr, ptr %l17, !tbaa !29
  %t116 = load i64, ptr %l18, !tbaa !24
  %t119 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t115, i64 %t116)
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l80
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb29, label %ok.123
ok.123:
  store { i64, ptr } %t120, ptr %l79
  br label %bb28
bb28:
  %t124 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  br label %bb33
bb29:
  %t125 = load i32, ptr %l80, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  br i1 %t128, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_9134020f70d092ba_383f6adc32770fa6)
  unreachable
bb32:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb33:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l19, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t135 = load i64, ptr %l21, !tbaa !24
  %t136 = load i64, ptr %l20, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb36:
  br label %bb37
bb37:
  %t143 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t143, ptr %l89, !tbaa !27
  %t144 = load i64, ptr %l21, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr %"compiler/views:fact", ptr %t147, i64 %t144
  %t149 = load %"compiler/views:fact", ptr %t148
  store %"compiler/views:fact" %t149, ptr %l22
  %t151 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = icmp ne i64 %t152, %t153
  br i1 %t156, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb40
bb39:
  %t158 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 1
  %t159 = load i64, ptr %t158, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t163 = icmp ne i64 %t159, %t160
  store i1 %t163, ptr %l95, !tbaa !21
  br label %bb40
bb40:
  %t165 = load i1, ptr %l95, !tbaa !21
  br i1 %t165, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb43
bb42:
  %t166 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 2
  %t167 = load i32, ptr %t166, !tbaa !23
  %t168 = load i32, ptr %l4, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  store i1 %t171, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l99, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb63
bb45:
  br label %bb46
bb46:
  %t174 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 3
  %t175 = load i64, ptr %t174, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t179 = icmp eq i64 %t175, %t176
  br i1 %t179, label %bb47, label %bb48
bb47:
  %t181 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 5
  %t182 = load i1, ptr %t181, !tbaa !21
  br i1 %t182, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb52
bb49:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb51
bb50:
  %t184 = load i1, ptr %l9, !tbaa !21
  %t186 = xor i1 %t184, true
  store i1 %t186, ptr %l108, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l108, !tbaa !21
  store i1 %t188, ptr %l106, !tbaa !21
  br label %bb52
bb52:
  %t189 = load i1, ptr %l106, !tbaa !21
  br i1 %t189, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  br label %bb55
bb55:
  %t190 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 5
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb56:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 3
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load i64, ptr %l8, !tbaa !24
  %t200 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t193, i64 %t195, i64 %t196)
  store i1 %t200, ptr %l116
  br label %bb58
bb57:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb59
bb58:
  %t201 = load i1, ptr %l116, !tbaa !21
  store i1 %t201, ptr %l112, !tbaa !21
  br label %bb59
bb59:
  %t202 = load i1, ptr %l112, !tbaa !21
  br i1 %t202, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb63
bb63:
  %t203 = load i64, ptr %l21, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l21, !tbaa !24
  br label %bb34
bb64:
  %t207 = load i64, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t207, %t208
  store i64 %t211, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  br label %bb27
bb66:
  %t213 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 2
  %t214 = load i64, ptr %t213, !tbaa !24
  store i64 %t214, ptr %l122, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/views:Viewer", ptr %t215, i32 0, i32 3
  %t218 = load i64, ptr %l8, !tbaa !24
  %t221 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t217, i64 %t218)
  store { i64, ptr } %t221, ptr %l126
  br label %bb67
bb67:
  %t222 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = load i64, ptr %l122, !tbaa !24
  %t226 = icmp sle i64 %t224, %t223
  br i1 %t226, label %bb68, label %bb69
bb68:
  %t228 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 2
  %t229 = load i64, ptr %t228, !tbaa !24
  store i64 %t229, ptr %l129, !tbaa !24
  br label %bb71
bb69:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/views:Viewer", ptr %t231, i32 0, i32 3
  %t234 = load i64, ptr %l8, !tbaa !24
  %t237 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t233, i64 %t234)
  store { i64, ptr } %t237, ptr %l134
  br label %bb70
bb70:
  %t238 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  store i64 %t239, ptr %l129, !tbaa !24
  br label %bb71
bb71:
  %t241 = load i64, ptr %l129, !tbaa !24
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l136, !tbaa !29
  %t243 = load i64, ptr %l2, !tbaa !24
  store i64 %t243, ptr %l137, !tbaa !24
  %t244 = load i64, ptr %l3, !tbaa !24
  store i64 %t244, ptr %l138, !tbaa !24
  %t245 = load i32, ptr %l4, !tbaa !23
  store i32 %t245, ptr %l139, !tbaa !23
  %t246 = load i64, ptr %l8, !tbaa !24
  store i64 %t246, ptr %l140, !tbaa !24
  store i64 %t241, ptr %l141, !tbaa !24
  %t248 = load i1, ptr %l9, !tbaa !21
  store i1 %t248, ptr %l142, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/views:Viewer", ptr %t249, i32 0, i32 19
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = icmp eq ptr %t252, null
  br i1 %t254, label %bb72, label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_960025b02095f4a2_7b552e5bb757722e)
  unreachable
bb73:
  br label %bb74
bb74:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/views:Viewer", ptr %t256, i32 0, i32 19
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Body", ptr %t259, i32 0, i32 3
  %t263 = load i64, ptr %t262, !tbaa !24
  %t265 = load i64, ptr %l137, !tbaa !24
  %t266 = load i64, ptr %l138, !tbaa !24
  %t267 = load i32, ptr %l139, !tbaa !23
  %t268 = load i64, ptr %l140, !tbaa !24
  %t269 = load i64, ptr %l141, !tbaa !24
  %t270 = load i1, ptr %l142, !tbaa !21
  %t273 = call %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %s0, i64 %t265, i64 %t266, i32 %t267, i64 %t268, i64 %t269, i1 %t270, i64 %t263, %"compiler/source:Span" %a6)
  store %"compiler/views:fact" %t273, ptr %l151
  br label %bb75
bb75:
  %t274 = load ptr, ptr %l136, !tbaa !29
  %t275 = load %"compiler/views:fact", ptr %l151
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t274, %"compiler/views:fact" %t275)
  br label %bb76
bb76:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/views:Viewer", ptr %t276, i32 0, i32 24
  store i1 true, ptr %t278, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l84 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca i1
  %l103 = alloca { i64, ptr }
  %l109 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca i64
  %l122 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca { i64, ptr }
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l22
  br label %bb1
bb1:
  %t11 = load i32, ptr %l22
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l32
  br label %bb5
bb5:
  %t36 = load i32, ptr %l32, !tbaa !23
  store i32 %t36, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/views:Viewer", ptr %t37, i32 0, i32 8
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hbdff57143197d3e3ce33a3087c05f7a0(ptr %v0, ptr %t39, i32 %t40)
  %t44 = extractvalue { i32, i64 } %t43, 1
  %t45 = extractvalue { i32, i64 } %t43, 0
  store i32 %t45, ptr %l38
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb7, label %ok.47
ok.47:
  store i64 %t44, ptr %l37
  br label %bb6
bb6:
  %t48 = load i64, ptr %l37, !tbaa !24
  store i64 %t48, ptr %l33, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l33, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l33, !tbaa !24
  store i64 %t49, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:Viewer", ptr %t54, i32 0, i32 9
  store ptr %t56, ptr %l42, !tbaa !29
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l43
  br label %bb12
bb11:
  br label %bb57
bb12:
  %t58 = load ptr, ptr %l42, !tbaa !29
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H10b97bb675358eb10150edb21083f11d(ptr %v0, ptr %v0, ptr %t58, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59)
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/views:Viewer", ptr %t60, i32 0, i32 9
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_He143de49e62ad88ca82ea9d42e5a34cc(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l46
  br label %bb14
bb14:
  %t65 = load i64, ptr %l46, !tbaa !24
  %t66 = sub i64 %t65, 1
  store i64 %t66, ptr %l4, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/views:Viewer", ptr %t68, i32 0, i32 8
  %t71 = load i32, ptr %l3, !tbaa !23
  %t72 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hd7428d759783ef3a1a99ea96b3969ebe(ptr %v0, ptr %t70, i32 %t71, i64 %t72)
  br label %bb15
bb15:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/views:Viewer", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t79, i32 %t80)
  store ptr %t83, ptr %l55
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l55, !tbaa !29
  store ptr %t84, ptr %l5, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TypeDecl", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l59, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb19
bb19:
  %t100 = load i1, ptr %l59, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr %"compiler/ast:TypeDecl", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %l6, !tbaa !29
  %t106 = load ptr, ptr %l6, !tbaa !29
  store ptr %t106, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t107 = load ptr, ptr %l66, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb22, label %bb23
bb21:
  br label %bb56
bb22:
  %t110 = load ptr, ptr %l66, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 0
  store i1 %t113, ptr %l67, !tbaa !21
  br label %bb23
bb23:
  %t114 = load i1, ptr %l67, !tbaa !21
  br i1 %t114, label %bb24, label %bb25
bb24:
  %t115 = load ptr, ptr %l6, !tbaa !29
  %t117 = getelementptr { i64, [6 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { ptr }, ptr %t117, i32 0, i32 0
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l7, !tbaa !29
  br label %bb26
bb25:
  br label %bb54
bb26:
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t123 = getelementptr %"compiler/ast:StructBody", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb27, label %bb28
bb27:
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t132 = getelementptr %"compiler/ast:StructBody", ptr %t130, i32 0, i32 2
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l10, !tbaa !24
  br label %bb29
bb28:
  br label %bb53
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb31:
  br label %bb32
bb32:
  %t147 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t147, ptr %l84, !tbaa !27
  %t148 = load i64, ptr %l9, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr ptr, ptr %t151, i64 %t148
  %t153 = load ptr, ptr %t152, !tbaa !39
  store ptr %t153, ptr %l11, !tbaa !29
  %t155 = load ptr, ptr %l11, !tbaa !29
  store ptr %t155, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t156 = load ptr, ptr %l87, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb33, label %bb34
bb33:
  %t159 = load ptr, ptr %l87, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 1
  store i1 %t162, ptr %l88, !tbaa !21
  br label %bb34
bb34:
  %t163 = load i1, ptr %l88, !tbaa !21
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t164 = load ptr, ptr %l11, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 1
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l12, !tbaa !29
  br label %bb37
bb36:
  br label %bb49
bb37:
  %t170 = load ptr, ptr %l12, !tbaa !29
  %t172 = getelementptr %"compiler/ast:VarDecl", ptr %t170, i32 0, i32 5
  %t173 = load i1, ptr %t172, !tbaa !21
  br i1 %t173, label %bb38, label %bb39
bb38:
  %t175 = load ptr, ptr %l12, !tbaa !29
  %t177 = getelementptr %"compiler/ast:VarDecl", ptr %t175, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l15, !tbaa !24
  br label %bb40
bb39:
  br label %bb48
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t184 = load i64, ptr %l14, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s12)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t192 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t192, ptr %l103, !tbaa !27
  %t193 = load i64, ptr %l14, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  store i32 %t198, ptr %l16, !tbaa !23
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/views:Viewer", ptr %t200, i32 0, i32 9
  %t203 = load i64, ptr %l4, !tbaa !24
  %t206 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H63170323aaa56032a7f198353006b630(ptr %v0, ptr %v0, ptr %t202, i64 %t203)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l109
  br label %bb44
bb44:
  %t207 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  %t208 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %t208
  %t209 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t208, i32 %t209)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb46:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l14, !tbaa !24
  br label %bb40
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb51:
  %t216 = load i64, ptr %l9, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l9, !tbaa !24
  br label %bb29
bb52:
  br label %bb53
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/views:Viewer", ptr %t220, i32 0, i32 9
  %t223 = load i64, ptr %l4, !tbaa !24
  %t226 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H63170323aaa56032a7f198353006b630(ptr %v0, ptr %v0, ptr %t222, i64 %t223)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %l119
  br label %bb58
bb58:
  %t227 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t227, ptr %l17
  %t228 = load i64, ptr %l2, !tbaa !24
  store i64 %t228, ptr %l120, !tbaa !24
  %t230 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %l17)
  store i64 %t230, ptr %l122
  br label %bb59
bb59:
  %t231 = load i64, ptr %l120, !tbaa !24
  %t232 = load i64, ptr %l122, !tbaa !24
  %t233 = icmp slt i64 %t231, %t232
  br i1 %t233, label %bb60, label %bb61
bb60:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l125, !tbaa !29
  %t236 = load i64, ptr %l2, !tbaa !24
  %t239 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %l17, i64 %t236)
  store i32 %t239, ptr %l128
  br label %bb62
bb61:
  %t240 = load i64, ptr %l2, !tbaa !24
  %t242 = call i64 @__olang_fmt_i64(ptr null, i64 %t240)
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  %t244 = call i64 @__olang_fmt_i64(ptr %t243, i64 %t240)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  store { i64, ptr } %t246, ptr %l124, !tbaa !27
  br label %bb64
bb62:
  %t248 = load ptr, ptr %l125, !tbaa !29
  %t249 = load i32, ptr %l128, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l129
  br label %bb63
bb63:
  %t251 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t252, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l124, !tbaa !27
  br label %bb64
bb64:
  %t258 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t258, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/views:holding"
  %l18 = alloca %"compiler/views:view"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/views:tasked"
  %l25 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l41 = alloca ptr
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l93 = alloca %"compiler/views:holding"
  %l95 = alloca i1
  %l99 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i64
  %l111 = alloca %"compiler/views:holding"
  %l117 = alloca i1
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l135 = alloca { i64, ptr }
  %l141 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l156 = alloca { i64, [3 x i64] }
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l168 = alloca { i64, [3 x i64] }
  %l170 = alloca %"compiler/msgs:Msg"
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/views:Viewer", ptr %t6, i32 0, i32 21
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t14 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t14, ptr %l7
  %t16 = load { i64, [2 x i64] }, ptr %l7
  %t18 = extractvalue { i64, [2 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 2
  br i1 %t19, label %bb6, label %bb7
bb5:
  br label %bb23
bb6:
  %t21 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t22 = getelementptr { i64 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l36, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/views:Viewer", ptr %t29, i32 0, i32 20
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t28, i64 %t32)
  store ptr %t35, ptr %l41
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l41, !tbaa !29
  %t38 = getelementptr %"compiler/views:summary", ptr %t36, i32 0, i32 0
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load %"compiler/views:place", ptr %l1
  %t41 = load %"compiler/source:Span", ptr %l2
  %t42 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t42, ptr %t38, i64 %t39, i64 -1, i32 0, %"compiler/views:place" %t40, %"compiler/source:Span" %t41)
  br label %bb10
bb10:
  br label %bb22
bb11:
  %t47 = load { i64, [2 x i64] }, ptr %l7
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 3
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t53 = getelementptr { i64, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i64, ptr %t53
  store i64 %t54, ptr %l9, !tbaa !24
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t57 = getelementptr { i64, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l10, !tbaa !23
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l51, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 20
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t63, i64 %t67)
  store ptr %t70, ptr %l56
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l56, !tbaa !29
  %t73 = getelementptr %"compiler/views:summary", ptr %t71, i32 0, i32 0
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i32, ptr %l10, !tbaa !23
  %t76 = load %"compiler/views:place", ptr %l1
  %t77 = load %"compiler/source:Span", ptr %l2
  %t78 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t78, ptr %t73, i64 -1, i64 %t74, i32 %t75, %"compiler/views:place" %t76, %"compiler/source:Span" %t77)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_617a65436beb56f7_865c97eda452f2a3)
  unreachable
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l11, !tbaa !24
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t86 = getelementptr %"compiler/views:state", ptr %t84, i32 0, i32 1
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t86)
  store i64 %t88, ptr %l65
  br label %bb24
bb24:
  %t89 = load i64, ptr %l65, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb25, label %bb26
bb25:
  %t96 = load i64, ptr %l13, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb30
bb27:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l13, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l13, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l72, !tbaa !24
  store i64 %t116, ptr %l69, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l69, !tbaa !24
  store i64 %t117, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l14, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t127 = load i64, ptr %l15, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l16, !tbaa !24
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = getelementptr %"compiler/views:state", ptr %t136, i32 0, i32 1
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t138, i64 %t139)
  store %"compiler/views:holding" %t142, ptr %l93
  br label %bb35
bb35:
  %t143 = load %"compiler/views:holding", ptr %l93
  store %"compiler/views:holding" %t143, ptr %l17
  %t144 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t145 = getelementptr %"compiler/views:view", ptr %t144, i32 0, i32 2
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb39
bb37:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t150 = getelementptr %"compiler/views:view", ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/views:place", ptr %t150
  %t152 = load %"compiler/views:place", ptr %l1
  %t156 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t148, %"compiler/views:place" %t151, %"compiler/views:place" %t152)
  store i1 %t156, ptr %l99
  br label %bb38
bb38:
  %t157 = load i1, ptr %l99, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l95, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t161 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t162 = load %"compiler/views:view", ptr %t161
  store %"compiler/views:view" %t162, ptr %l18
  %t164 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 2
  store i1 true, ptr %t164, !tbaa !21
  %t165 = load %"compiler/source:Span", ptr %l2
  %t167 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 3
  store %"compiler/source:Span" %t165, ptr %t167
  %t170 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 4
  store i64 %a3, ptr %t170, !tbaa !24
  %t173 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 5
  store i64 %a4, ptr %t173, !tbaa !24
  %t176 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 6
  store %"compiler/source:Span" %a5, ptr %t176
  %t177 = load ptr, ptr %l6, !tbaa !29
  %t179 = getelementptr %"compiler/views:state", ptr %t177, i32 0, i32 1
  store ptr %t179, ptr %l107, !tbaa !29
  %t180 = load i64, ptr %l16, !tbaa !24
  store i64 %t180, ptr %l108, !tbaa !24
  %t181 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 0
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = load %"compiler/views:view", ptr %l18
  %t186 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s7, i64 %t182, %"compiler/views:view" %t183)
  store %"compiler/views:holding" %t186, ptr %l111
  br label %bb43
bb43:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load i64, ptr %l108, !tbaa !24
  %t189 = load %"compiler/views:holding", ptr %l111
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v1, ptr %t187, i64 %t188, %"compiler/views:holding" %t189)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l15, !tbaa !24
  br label %bb31
bb46:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/views:Viewer", ptr %t194, i32 0, i32 21
  %t197 = load i1, ptr %t196, !tbaa !21
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb49
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/views:Viewer", ptr %t201, i32 0, i32 23
  %t204 = load i1, ptr %t203, !tbaa !21
  store i1 %t204, ptr %l117, !tbaa !21
  br label %bb49
bb49:
  %t206 = load i1, ptr %l117, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  br label %ret
bb51:
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l6, !tbaa !29
  %t209 = getelementptr %"compiler/views:state", ptr %t207, i32 0, i32 4
  store ptr %t209, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t211 = load ptr, ptr %l19, !tbaa !29
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v1, ptr %t211, i64 %t212)
  %t216 = extractvalue { i32, { i64, ptr } } %t215, 1
  %t217 = extractvalue { i32, { i64, ptr } } %t215, 0
  store i32 %t217, ptr %l126
  %t218 = icmp ne i32 %t217, 0
  br i1 %t218, label %bb55, label %ok.219
ok.219:
  store { i64, ptr } %t216, ptr %l125
  br label %bb54
bb54:
  %t220 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t220, ptr %l122, !tbaa !27
  br label %bb59
bb55:
  %t221 = load i32, ptr %l126, !tbaa !23
  %t222 = ashr i32 %t221, 16
  %t224 = icmp eq i32 %t222, 1
  br i1 %t224, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_80a32e84cf5cf2d6_d2f28a7009f6d1a2)
  unreachable
bb58:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb59:
  %t226 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t226, ptr %l21, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s13
  %t231 = load i64, ptr %l23, !tbaa !24
  %t232 = load i64, ptr %l22, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb62:
  br label %bb63
bb63:
  %t239 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t239, ptr %l135, !tbaa !27
  %t240 = load i64, ptr %l23, !tbaa !24
  %t242 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr %"compiler/views:tasked", ptr %t243, i64 %t240
  %t245 = load %"compiler/views:tasked", ptr %t244
  store %"compiler/views:tasked" %t245, ptr %l24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/views:tasked", ptr %l24, i32 0, i32 0
  %t249 = getelementptr %"compiler/views:view", ptr %t248, i32 0, i32 0
  %t250 = load %"compiler/views:place", ptr %t249
  %t251 = load %"compiler/views:place", ptr %l1
  %t255 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t247, %"compiler/views:place" %t250, %"compiler/views:place" %t251)
  store i1 %t255, ptr %l141
  br label %bb64
bb64:
  %t256 = load i1, ptr %l141, !tbaa !21
  %t257 = xor i1 %t256, true
  br i1 %t257, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb68
bb66:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l2
  %t263 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t259, %"compiler/source:Span" %t260)
  store i1 %t263, ptr %l146
  br label %bb67
bb67:
  %t264 = load i1, ptr %l146, !tbaa !21
  store i1 %t264, ptr %l143, !tbaa !21
  br label %bb68
bb68:
  %t265 = load i1, ptr %l143, !tbaa !21
  br i1 %t265, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb70:
  br label %bb71
bb71:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/views:tasked", ptr %l24, i32 0, i32 0
  %t268 = getelementptr %"compiler/views:view", ptr %t267, i32 0, i32 0
  %t269 = load %"compiler/views:place", ptr %t268
  %t272 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s13, ptr %t266, %"compiler/views:place" %t269)
  store { i64, ptr } %t272, ptr %l149
  br label %bb72
bb72:
  %t273 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t273, ptr %l25, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/views:Viewer", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  store ptr %t283, ptr %l153, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l2
  %t288 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t284, %"compiler/source:Span" %t285)
  store { i64, [3 x i64] } %t288, ptr %l156
  br label %bb73
bb73:
  %t289 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t289, { i64, ptr } %t290)
  store %"compiler/msgs:Msg" %t293, ptr %l159
  br label %bb74
bb74:
  %t294 = load ptr, ptr %l153, !tbaa !29
  %t295 = load { i64, [3 x i64] }, ptr %l156
  %t296 = load %"compiler/msgs:Msg", ptr %l159
  %t297 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t294, { i64, [3 x i64] } %t295, %"compiler/msgs:Msg" %t296)
  store i64 %t297, ptr %l160
  br label %bb75
bb75:
  %t298 = load i64, ptr %l160, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/views:Viewer", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = getelementptr %"compiler/load:Loader", ptr %t305, i32 0, i32 4
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l164, !tbaa !29
  store i64 %t298, ptr %l165, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/views:tasked", ptr %l24, i32 0, i32 1
  %t312 = load %"compiler/source:Span", ptr %t311
  %t315 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t310, %"compiler/source:Span" %t312)
  store { i64, [3 x i64] } %t315, ptr %l168
  br label %bb76
bb76:
  %t316 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t318 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %s13, ptr %s13, { i64, ptr } %t316)
  store %"compiler/msgs:Msg" %t318, ptr %l170
  br label %bb77
bb77:
  %t319 = load ptr, ptr %l164, !tbaa !29
  %t320 = load i64, ptr %l165, !tbaa !24
  %t321 = load { i64, [3 x i64] }, ptr %l168
  %t322 = load %"compiler/msgs:Msg", ptr %l170
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s13, ptr %t319, i64 %t320, { i64, [3 x i64] } %t321, %"compiler/msgs:Msg" %t322)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb79:
  %t323 = load i64, ptr %l23, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l23, !tbaa !24
  br label %bb60
bb80:
  %t327 = load i64, ptr %l20, !tbaa !24
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = add i64 %t327, %t328
  store i64 %t331, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb81:
  br label %bb53
bb82:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eholdsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:state", ptr %a1, i32 0, i32 1
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l12, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d88fa77248fe9e33_2d427ecad2833217)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/views:holding", ptr %t37, i64 %t34
  %t39 = load %"compiler/views:holding", ptr %t38
  store %"compiler/views:holding" %t39, ptr %l9
  %t41 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t46 = icmp eq i64 %t42, %a2
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t49 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t50 = load %"compiler/views:view", ptr %t49
  call void @compiler_2fviews_2eviewAdd(ptr %v2, ptr %a3, %"compiler/views:view" %t50)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l8, !tbaa !24
  br label %bb8
bb17:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t57, %t58
  store i64 %t61, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 25
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  store i64 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/views:Viewer", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l20
  br label %bb6
bb6:
  %t35 = load i32, ptr %l20, !tbaa !23
  store i32 %t35, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l21, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/views:Viewer", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l26
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i32, ptr %l26, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t49, ptr %l27
  br label %bb8
bb8:
  %t50 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t51, ptr %l28
  br label %bb9
bb9:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:Viewer", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = getelementptr %"compiler/types:Table", ptr %t58, i32 0, i32 14
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/views:Viewer", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l37
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb15
bb12:
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load i64, ptr %l37, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store { i64, ptr } %t72, ptr %l38
  br label %bb13
bb13:
  %t73 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t74, ptr %l39
  br label %bb14
bb14:
  %t75 = load i1, ptr %l39, !tbaa !21
  store i1 %t75, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load i1, ptr %l29, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:place"
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/views:view"
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/views:fact"
  %l39 = alloca %"compiler/views:fact"
  %l42 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l66 = alloca { i64, ptr }
  %l72 = alloca i1
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l106 = alloca { i64, ptr }
  %l110 = alloca i64
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l131 = alloca { i64, ptr }
  %l135 = alloca i64
  %l142 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i32
  %l166 = alloca { i64, ptr }
  %l172 = alloca i1
  %l182 = alloca i64
  %l189 = alloca i64
  %l194 = alloca %"compiler/source:Span"
  %l195 = alloca %"compiler/views:fact"
  %l201 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t5, i32 %a2)
  store i1 %t9, ptr %l45
  br label %bb3
bb3:
  %t10 = load i1, ptr %l45, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l42, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l42, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l49
  br label %bb8
bb8:
  %t19 = load i64, ptr %l49, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l3, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb10:
  br label %bb27
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t26, i64 %t27)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l57
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb13, label %ok.34
ok.34:
  store { i64, ptr } %t31, ptr %l56
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t35, ptr %l53, !tbaa !27
  br label %bb17
bb13:
  %t36 = load i32, ptr %l57, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a9709b8d7599af1c_938b49c1f1943728)
  unreachable
bb16:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb17:
  %t41 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t54, ptr %l66, !tbaa !27
  %t55 = load i64, ptr %l10, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/views:view", ptr %t58, i64 %t55
  %t60 = load %"compiler/views:view", ptr %t59
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i64, ptr %l5, !tbaa !24
  %t68 = call i1 @compiler_2fviews_2eholdAdd(ptr %v3, ptr %t62, i64 %t63, %"compiler/views:view" %t60)
  store i1 %t68, ptr %l72
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb23:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l10, !tbaa !24
  br label %bb18
bb24:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = add i64 %t73, %t74
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  br label %bb11
bb26:
  br label %bb27
bb27:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/views:Viewer", ptr %t79, i32 0, i32 21
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t84 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l80
  br label %bb31
bb31:
  %t85 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l12
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t90 = call ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store ptr %t90, ptr %l83
  br label %bb32
bb32:
  %t91 = load ptr, ptr %l83, !tbaa !29
  store ptr %t91, ptr %l13, !tbaa !29
  %t92 = load ptr, ptr %l13, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l13, !tbaa !29
  %t101 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t98, ptr %t99, ptr %t101, ptr %l12)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  store ptr %l12, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t107 = load ptr, ptr %l14, !tbaa !29
  %t108 = load i64, ptr %l15, !tbaa !24
  %t111 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t107, i64 %t108)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l97
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb39, label %ok.115
ok.115:
  store { i64, ptr } %t112, ptr %l96
  br label %bb38
bb38:
  %t116 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t116, ptr %l93, !tbaa !27
  br label %bb43
bb39:
  %t117 = load i32, ptr %l97, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  br i1 %t120, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_5a02dfa0eab0974d_8c564576f095f5f9)
  unreachable
bb42:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb125
bb43:
  %t122 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t122, ptr %l16, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t127 = load i64, ptr %l18, !tbaa !24
  %t128 = load i64, ptr %l17, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb123
bb46:
  br label %bb47
bb47:
  %t135 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t135, ptr %l106, !tbaa !27
  %t136 = load i64, ptr %l18, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/views:place", ptr %t139, i64 %t136
  %t141 = load %"compiler/views:place", ptr %t140
  store %"compiler/views:place" %t141, ptr %l19
  %t143 = getelementptr %"compiler/views:place", ptr %l19, i32 0, i32 0
  %t144 = load { i64, [2 x i64] }, ptr %t143
  store { i64, [2 x i64] } %t144, ptr %l20
  %t146 = load { i64, [2 x i64] }, ptr %l20
  %t148 = extractvalue { i64, [2 x i64] } %t146, 0
  %t149 = icmp eq i64 %t148, 2
  br i1 %t149, label %bb48, label %bb49
bb48:
  %t151 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t152 = getelementptr { i64 }, ptr %t151, i32 0, i32 0
  %t153 = load i64, ptr %t152
  store i64 %t153, ptr %l21, !tbaa !24
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t155 = load i64, ptr %l21, !tbaa !24
  store i64 %t155, ptr %l110, !tbaa !24
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i64 -1, ptr %l110, !tbaa !24
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_7a8d60d7f0d90b6_ecc0a280768e582)
  unreachable
bb56:
  %t157 = load i64, ptr %l110, !tbaa !24
  store i64 %t157, ptr %l22, !tbaa !24
  %t158 = load i64, ptr %l22, !tbaa !24
  %t160 = icmp slt i64 %t158, 0
  br i1 %t160, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb122
bb58:
  br label %bb59
bb59:
  %t162 = load ptr, ptr %l3, !tbaa !29
  store ptr %t162, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s16
  %t164 = load ptr, ptr %l23, !tbaa !29
  %t165 = load i64, ptr %l24, !tbaa !24
  %t168 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t164, i64 %t165)
  %t169 = extractvalue { i32, { i64, ptr } } %t168, 1
  %t170 = extractvalue { i32, { i64, ptr } } %t168, 0
  store i32 %t170, ptr %l122
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb62, label %ok.172
ok.172:
  store { i64, ptr } %t169, ptr %l121
  br label %bb61
bb61:
  %t173 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t173, ptr %l118, !tbaa !27
  br label %bb66
bb62:
  %t174 = load i32, ptr %l122, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  br i1 %t177, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_ea9f86d593e82457_d31df71765169703)
  unreachable
bb65:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s16)
  br label %bb121
bb66:
  %t179 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t179, ptr %l25, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s17
  %t184 = load i64, ptr %l27, !tbaa !24
  %t185 = load i64, ptr %l26, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s17)
  br label %bb119
bb69:
  br label %bb70
bb70:
  %t192 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t192, ptr %l131, !tbaa !27
  %t193 = load i64, ptr %l27, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr %"compiler/views:view", ptr %t196, i64 %t193
  %t198 = load %"compiler/views:view", ptr %t197
  store %"compiler/views:view" %t198, ptr %l28
  %t200 = getelementptr %"compiler/views:view", ptr %l28, i32 0, i32 0
  %t201 = getelementptr %"compiler/views:place", ptr %t200, i32 0, i32 0
  %t202 = load { i64, [2 x i64] }, ptr %t201
  store { i64, [2 x i64] } %t202, ptr %l29
  %t204 = load { i64, [2 x i64] }, ptr %l29
  %t206 = extractvalue { i64, [2 x i64] } %t204, 0
  %t207 = icmp eq i64 %t206, 4
  br i1 %t207, label %bb71, label %bb72
bb71:
  %t209 = getelementptr { i64, [2 x i64] }, ptr %l29, i32 0, i32 1
  %t210 = getelementptr { i64 }, ptr %t209, i32 0, i32 0
  %t211 = load i64, ptr %t210
  store i64 %t211, ptr %l30, !tbaa !24
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t213 = load i64, ptr %l30, !tbaa !24
  store i64 %t213, ptr %l135, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i64 -1, ptr %l135, !tbaa !24
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_87a52582f4438a40_b949a7f7145f5964)
  unreachable
bb79:
  %t215 = load i64, ptr %l135, !tbaa !24
  store i64 %t215, ptr %l31, !tbaa !24
  %t216 = load i64, ptr %l31, !tbaa !24
  %t218 = icmp slt i64 %t216, 0
  br i1 %t218, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb82
bb81:
  %t220 = load i64, ptr %l31, !tbaa !24
  %t221 = load i64, ptr %l22, !tbaa !24
  %t224 = icmp eq i64 %t220, %t221
  store i1 %t224, ptr %l142, !tbaa !21
  br label %bb82
bb82:
  %t226 = load i1, ptr %l142, !tbaa !21
  br i1 %t226, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb118
bb84:
  br label %bb85
bb85:
  store i1 false, ptr %l32, !tbaa !21
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/views:Viewer", ptr %t227, i32 0, i32 2
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/views:Viewer", ptr %t230, i32 0, i32 20
  %t233 = load i64, ptr %t232, !tbaa !24
  %t236 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t229, i64 %t233)
  store ptr %t236, ptr %l150
  br label %bb86
bb86:
  %t237 = load ptr, ptr %l150, !tbaa !29
  %t239 = getelementptr %"compiler/views:summary", ptr %t237, i32 0, i32 2
  store ptr %t239, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s22
  %t241 = load ptr, ptr %l33, !tbaa !29
  %t242 = load i64, ptr %l34, !tbaa !24
  %t245 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t241, i64 %t242)
  %t246 = extractvalue { i32, { i64, ptr } } %t245, 1
  %t247 = extractvalue { i32, { i64, ptr } } %t245, 0
  store i32 %t247, ptr %l157
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb89, label %ok.249
ok.249:
  store { i64, ptr } %t246, ptr %l156
  br label %bb88
bb88:
  %t250 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t250, ptr %l153, !tbaa !27
  br label %bb93
bb89:
  %t251 = load i32, ptr %l157, !tbaa !23
  %t252 = ashr i32 %t251, 16
  %t254 = icmp eq i32 %t252, 1
  br i1 %t254, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_8d7acc310dabf2d1_fe0a55af40497355)
  unreachable
bb92:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb107
bb93:
  %t256 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t256, ptr %l35, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t257, 0
  store i64 %t259, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s23
  %t261 = load i64, ptr %l37, !tbaa !24
  %t262 = load i64, ptr %l36, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s23)
  br label %bb105
bb96:
  br label %bb97
bb97:
  %t269 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t269, ptr %l166, !tbaa !27
  %t270 = load i64, ptr %l37, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr %"compiler/views:fact", ptr %t273, i64 %t270
  %t275 = load %"compiler/views:fact", ptr %t274
  store %"compiler/views:fact" %t275, ptr %l38
  %t277 = getelementptr %"compiler/views:fact", ptr %l38, i32 0, i32 0
  %t278 = load i64, ptr %t277, !tbaa !24
  %t279 = load i64, ptr %l31, !tbaa !24
  %t282 = icmp eq i64 %t278, %t279
  br i1 %t282, label %bb98, label %bb99
bb98:
  %t284 = getelementptr %"compiler/views:fact", ptr %l38, i32 0, i32 8
  %t285 = load i64, ptr %t284, !tbaa !24
  %t286 = load i64, ptr %l22, !tbaa !24
  %t289 = icmp eq i64 %t285, %t286
  store i1 %t289, ptr %l172, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb100
bb100:
  %t291 = load i1, ptr %l172, !tbaa !21
  br i1 %t291, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s23)
  br label %bb104
bb104:
  %t292 = load i64, ptr %l37, !tbaa !24
  %t294 = add i64 %t292, 1
  store i64 %t294, ptr %l37, !tbaa !24
  br label %bb94
bb105:
  %t296 = load i64, ptr %l34, !tbaa !24
  %t297 = load i64, ptr %l36, !tbaa !24
  %t300 = add i64 %t296, %t297
  store i64 %t300, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb106:
  br label %bb87
bb107:
  %t302 = load i1, ptr %l32, !tbaa !21
  br i1 %t302, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s17)
  br label %bb118
bb109:
  br label %bb110
bb110:
  %t304 = load i64, ptr %l31, !tbaa !24
  store i64 %t304, ptr %l182, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/views:Viewer", ptr %t305, i32 0, i32 19
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = icmp eq ptr %t308, null
  br i1 %t310, label %bb111, label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_155b02aaeb4da1a3_5b82cd4f01516287)
  unreachable
bb112:
  br label %bb113
bb113:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/views:Viewer", ptr %t312, i32 0, i32 19
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Body", ptr %t315, i32 0, i32 3
  %t319 = load i64, ptr %t318, !tbaa !24
  store i64 %t319, ptr %l189, !tbaa !24
  %t320 = getelementptr %"compiler/views:view", ptr %l28, i32 0, i32 1
  %t321 = load i64, ptr %t320, !tbaa !24
  %t323 = trunc i64 %t321 to i32
  %t324 = getelementptr %"compiler/views:view", ptr %l28, i32 0, i32 1
  %t325 = load i64, ptr %t324, !tbaa !24
  %t327 = trunc i64 %t325 to i32
  %t330 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s17, i32 %t323, i32 %t327)
  store %"compiler/source:Span" %t330, ptr %l194
  br label %bb114
bb114:
  %t331 = load i64, ptr %l182, !tbaa !24
  %t332 = load i64, ptr %l189, !tbaa !24
  %t333 = load %"compiler/source:Span", ptr %l194
  %t334 = call %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %s17, i64 %t331, i64 -1, i32 0, i64 0, i64 0, i1 false, i64 %t332, %"compiler/source:Span" %t333)
  store %"compiler/views:fact" %t334, ptr %l195
  br label %bb115
bb115:
  %t335 = load %"compiler/views:fact", ptr %l195
  store %"compiler/views:fact" %t335, ptr %l39
  %t336 = load i64, ptr %l22, !tbaa !24
  %t338 = getelementptr %"compiler/views:fact", ptr %l39, i32 0, i32 8
  store i64 %t336, ptr %t338, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/views:Viewer", ptr %t339, i32 0, i32 2
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/views:Viewer", ptr %t342, i32 0, i32 20
  %t345 = load i64, ptr %t344, !tbaa !24
  %t348 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t341, i64 %t345)
  store ptr %t348, ptr %l201
  br label %bb116
bb116:
  %t349 = load ptr, ptr %l201, !tbaa !29
  %t351 = getelementptr %"compiler/views:summary", ptr %t349, i32 0, i32 2
  %t352 = load %"compiler/views:fact", ptr %l39
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t351, %"compiler/views:fact" %t352)
  br label %bb117
bb117:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/views:Viewer", ptr %t355, i32 0, i32 24
  store i1 true, ptr %t357, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb118
bb118:
  %t358 = load i64, ptr %l27, !tbaa !24
  %t360 = add i64 %t358, 1
  store i64 %t360, ptr %l27, !tbaa !24
  br label %bb67
bb119:
  %t362 = load i64, ptr %l24, !tbaa !24
  %t363 = load i64, ptr %l26, !tbaa !24
  %t366 = add i64 %t362, %t363
  store i64 %t366, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb120
bb120:
  br label %bb60
bb121:
  call void @__olang_scope_close(ptr %s11)
  br label %bb122
bb122:
  %t368 = load i64, ptr %l18, !tbaa !24
  %t370 = add i64 %t368, 1
  store i64 %t370, ptr %l18, !tbaa !24
  br label %bb44
bb123:
  %t372 = load i64, ptr %l15, !tbaa !24
  %t373 = load i64, ptr %l17, !tbaa !24
  %t376 = add i64 %t372, %t373
  store i64 %t376, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb124
bb124:
  br label %bb37
bb125:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/views:state"
  %l6 = alloca %"compiler/views:state"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:state"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/views:state"
  %l26 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca %"compiler/views:loopFrame"
  %l34 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca %"compiler/views:state"
  %l42 = alloca %"compiler/views:state"
  %l46 = alloca i64
  %l49 = alloca i64
  %l72 = alloca %"compiler/views:state"
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l92 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l120 = alloca { i64, ptr }
  %l131 = alloca i64
  %l135 = alloca i64
  %l140 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l28, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Block", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = call %"compiler/views:loopFrame" @compiler_2fviews_3aloopFrame_2ector(ptr %v0, i32 %t7)
  store %"compiler/views:loopFrame" %t9, ptr %l31
  br label %bb1
bb1:
  %t10 = load %"compiler/views:loopFrame", ptr %l31
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/views:loopFrame" %t10, ptr %t11
  %t12 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__He2aba1703ae07509d487434bdc4dbdab(ptr %v0, ptr %v0, ptr %t12, ptr %t11)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 26
  store ptr %t16, ptr %l34, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/views:Viewer", ptr %t17, i32 0, i32 26
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H9b6ab774c92f21a4ef5a53265d5b9504(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l37
  br label %bb3
bb3:
  %t22 = load i64, ptr %l37, !tbaa !24
  %t23 = sub i64 %t22, 1
  %t24 = load ptr, ptr %l34, !tbaa !29
  %t26 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t24, i64 %t23)
  store ptr %t26, ptr %l39
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l39, !tbaa !29
  store ptr %t27, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v3, ptr %s0, ptr %t28)
  store %"compiler/views:state" %t30, ptr %l41
  br label %bb5
bb5:
  %t31 = load %"compiler/views:state", ptr %l41
  store %"compiler/views:state" %t31, ptr %l5
  %t32 = call %"compiler/views:state" @compiler_2fviews_2edead(ptr %s0)
  store %"compiler/views:state" %t32, ptr %l42
  br label %bb6
bb6:
  %t33 = load %"compiler/views:state", ptr %l42
  store %"compiler/views:state" %t33, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  store i64 12, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb12
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l49, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb11
bb11:
  %t60 = load i64, ptr %l49, !tbaa !24
  store i64 %t60, ptr %l46, !tbaa !24
  br label %bb12
bb12:
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load i64, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb15:
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l12, !tbaa !24
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/views:loopFrame", ptr %t80, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t82)
  br label %bb17
bb17:
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/views:loopFrame", ptr %t84, i32 0, i32 2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t86)
  br label %bb18
bb18:
  %t89 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %s0, ptr %s2, ptr %l5)
  store %"compiler/views:state" %t89, ptr %l72
  br label %bb19
bb19:
  %t90 = load %"compiler/views:state", ptr %l72
  store %"compiler/views:state" %t90, ptr %l13
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s2, ptr %t91, ptr %t92, ptr %l13)
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = getelementptr %"compiler/views:loopFrame", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l14, !tbaa !29
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eRunFrom_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t101, i64 %t102)
  %t106 = extractvalue { i32, { i64, ptr } } %t105, 1
  %t107 = extractvalue { i32, { i64, ptr } } %t105, 0
  store i32 %t107, ptr %l83
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb23, label %ok.109
ok.109:
  store { i64, ptr } %t106, ptr %l82
  br label %bb22
bb22:
  %t110 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t110, ptr %l79, !tbaa !27
  br label %bb27
bb23:
  %t111 = load i32, ptr %l83, !tbaa !23
  %t112 = ashr i32 %t111, 16
  %t114 = icmp eq i32 %t112, 1
  br i1 %t114, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_bafc93f6dfe0eed8_a0f473e6bdc32d74)
  unreachable
bb26:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb27:
  %t116 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t116, ptr %l16, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t121 = load i64, ptr %l18, !tbaa !24
  %t122 = load i64, ptr %l17, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t129 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t129, ptr %l92, !tbaa !27
  %t130 = load i64, ptr %l18, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr %"compiler/views:state", ptr %t133, i64 %t130
  %t135 = load %"compiler/views:state", ptr %t134
  store %"compiler/views:state" %t135, ptr %l19
  call void @compiler_2fviews_2emerge(ptr %s2, ptr %s5, ptr %l13, ptr %l19)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t139 = load i64, ptr %l18, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l18, !tbaa !24
  br label %bb28
bb34:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = add i64 %t143, %t144
  store i64 %t147, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  br label %bb21
bb36:
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v2, ptr %s2, ptr %t149, ptr %a2, ptr %l13)
  br label %bb37
bb37:
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/views:loopFrame", ptr %t154, i32 0, i32 1
  store ptr %t156, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = load ptr, ptr %l20, !tbaa !29
  %t159 = load i64, ptr %l21, !tbaa !24
  %t162 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eRunFrom_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t158, i64 %t159)
  %t163 = extractvalue { i32, { i64, ptr } } %t162, 1
  %t164 = extractvalue { i32, { i64, ptr } } %t162, 0
  store i32 %t164, ptr %l111
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb40, label %ok.166
ok.166:
  store { i64, ptr } %t163, ptr %l110
  br label %bb39
bb39:
  %t167 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t167, ptr %l107, !tbaa !27
  br label %bb44
bb40:
  %t168 = load i32, ptr %l111, !tbaa !23
  %t169 = ashr i32 %t168, 16
  %t171 = icmp eq i32 %t169, 1
  br i1 %t171, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_2a3f27cfff39c1a9_9951569984a247a5)
  unreachable
bb43:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb44:
  %t173 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t173, ptr %l22, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  store i64 %t176, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t178 = load i64, ptr %l24, !tbaa !24
  %t179 = load i64, ptr %l23, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t186 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t186, ptr %l120, !tbaa !27
  %t187 = load i64, ptr %l24, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr %"compiler/views:state", ptr %t190, i64 %t187
  %t192 = load %"compiler/views:state", ptr %t191
  store %"compiler/views:state" %t192, ptr %l25
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s9, ptr %l6, ptr %l25)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  %t196 = load i64, ptr %l24, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l24, !tbaa !24
  br label %bb45
bb51:
  %t200 = load i64, ptr %l21, !tbaa !24
  %t201 = load i64, ptr %l23, !tbaa !24
  %t204 = add i64 %t200, %t201
  store i64 %t204, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  br label %bb38
bb53:
  %t207 = call i64 @compiler_2fviews_2eweight(ptr %s0, ptr %l5)
  store i64 %t207, ptr %l131
  br label %bb54
bb54:
  %t208 = load i64, ptr %l131, !tbaa !24
  store i64 %t208, ptr %l26, !tbaa !24
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s2, ptr %l5, ptr %l13)
  br label %bb55
bb55:
  %t212 = call i64 @compiler_2fviews_2eweight(ptr %s0, ptr %l5)
  store i64 %t212, ptr %l135
  br label %bb56
bb56:
  %t213 = load i64, ptr %l26, !tbaa !24
  %t214 = load i64, ptr %l135, !tbaa !24
  %t216 = icmp eq i64 %t214, %t213
  br i1 %t216, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb60:
  %t218 = load i64, ptr %l11, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l11, !tbaa !24
  br label %bb13
bb61:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/views:Viewer", ptr %t222, i32 0, i32 26
  %t226 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Haabd632b519baafc45866c30c5849be1(ptr %v0, ptr %v0, ptr %t224)
  %t227 = extractvalue { i32, ptr } %t226, 1
  %t228 = extractvalue { i32, ptr } %t226, 0
  store i32 %t228, ptr %l144
  %t229 = icmp ne i32 %t228, 0
  br i1 %t229, label %bb63, label %ok.230
ok.230:
  store ptr %t227, ptr %l143
  br label %bb62
bb62:
  %t231 = load ptr, ptr %l143, !tbaa !29
  store ptr %t231, ptr %l140, !tbaa !29
  br label %bb65
bb63:
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  br label %bb65
bb65:
  %t232 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v3, ptr %s0, ptr %t232, ptr %l6)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/views:state"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca %"compiler/views:state"
  %l23 = alloca { i64, ptr }
  %l32 = alloca %"compiler/views:state"
  %l41 = alloca { i64, ptr }
  %l45 = alloca %"compiler/views:state"
  %l59 = alloca %"compiler/views:state"
  %l60 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l23, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t24, ptr %t29)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l5, !tbaa !24
  br label %bb1
bb7:
  %t37 = call %"compiler/views:state" @compiler_2fviews_2edead(ptr %s0)
  store %"compiler/views:state" %t37, ptr %l32
  br label %bb8
bb8:
  %t38 = load %"compiler/views:state", ptr %l32
  store %"compiler/views:state" %t38, ptr %l8
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Match", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l41, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  store ptr %t62, ptr %l12, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s5, ptr %t64)
  store %"compiler/views:state" %t66, ptr %l45
  br label %bb13
bb13:
  %t67 = load %"compiler/views:state", ptr %l45
  store %"compiler/views:state" %t67, ptr %l13
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l12, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %s5, ptr %v3, ptr %t68, ptr %t69, ptr %l13, ptr %t70)
  br label %bb14
bb14:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s5, ptr %l8, ptr %l13)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb16:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb9
bb17:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Match", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s7, ptr %t90)
  store %"compiler/views:state" %t92, ptr %l59
  br label %bb20
bb19:
  %t93 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %v2, ptr %l8, ptr %t93)
  br label %bb26
bb20:
  %t96 = load %"compiler/views:state", ptr %l59
  store %"compiler/views:state" %t96, ptr %l14
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l60, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2d854533e388acf3_9bd384635a298ef)
  unreachable
bb22:
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Match", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t110 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %s7, ptr %v3, ptr %t110, ptr %t108, ptr %l14, ptr %t109)
  br label %bb24
bb24:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s7, ptr %l8, ptr %l14)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s0, ptr %t116, ptr %l8)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %a0, %"compiler/views:place" %a1, %"compiler/views:place" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca %"compiler/views:place"
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l11 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store %"compiler/views:place" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t2)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb3:
  %t8 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l7
  %t10 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l9
  %t14 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l7, ptr %l9)
  store i1 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i1, ptr %l11, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l6, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = icmp eq i64 %t21, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t32, i64 %t34, i64 %t36)
  store i1 %t40, ptr %l23
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l19, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t44 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 3
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t51 = load i64, ptr %t50, !tbaa !24
  %t55 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t47, i64 %t49, i64 %t51)
  store i1 %t55, ptr %l30
  br label %bb21
bb20:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb22
bb21:
  %t56 = load i1, ptr %l30, !tbaa !21
  store i1 %t56, ptr %l26, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l26, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i8
  %l22 = alloca i32
  %l26 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t3, i64 %t4)
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t8)
  store i1 %t9, ptr %l7
  br label %bb3
bb3:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t11, i64 %t12)
  store i8 %t15, ptr %l11
  br label %bb6
bb6:
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t16)
  store i1 %t17, ptr %l12
  br label %bb7
bb7:
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t20, i64 %t21)
  store i8 %t24, ptr %l16
  br label %bb11
bb11:
  %t25 = load i8, ptr %l16, !tbaa !22
  %t26 = icmp eq i8 %t25, 95
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb1
bb17:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store i32 %t37, ptr %l22, !tbaa !23
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb20
bb19:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l26, !tbaa !24
  br label %bb20
bb20:
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = trunc i64 %t50 to i32
  %t52 = load i32, ptr %l22, !tbaa !23
  %t54 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t52, i32 %t51)
  store %"compiler/source:Span" %t54, ptr %l31
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t5 = getelementptr %"compiler/views:state", ptr %a1, i32 0, i32 3
  %t9 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %a2)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t4 = load ptr, ptr %l10, !tbaa !29
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = load i64, ptr %t7
  %t10 = icmp eq i64 %t8, 3
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t12, i32 0, i32 1
  %t15 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t18, ptr %t19, i1 false, ptr %t21, ptr %l3)
  br label %bb7
bb7:
  br label %bb42
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 4
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Elem", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t41, ptr %t45, i1 false, ptr %t47, ptr %l3)
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t52, ptr %t56, ptr %t58, ptr %l3)
  br label %bb15
bb15:
  br label %bb42
bb16:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Payload", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t78, ptr %t82, i1 false, ptr %t84, ptr %l3)
  br label %bb22
bb22:
  br label %bb42
bb23:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t97 = load i1, ptr %l52, !tbaa !21
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l7, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t104, ptr %t105, ptr %t107, ptr %l3)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t113 = load ptr, ptr %l62, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb31, label %bb32
bb31:
  %t116 = load ptr, ptr %l62, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 6
  store i1 %t119, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t120 = load i1, ptr %l63, !tbaa !21
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l8, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t127, ptr %t128, ptr %t130, ptr %l3)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_2a4a8b72a379b770_7cdc66c7220ef344)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %a0, %"compiler/views:view" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:view"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/views:view" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 0
  %t2 = getelementptr %"compiler/views:place", ptr %t1, i32 0, i32 0
  %t3 = load { i64, [2 x i64] }, ptr %t2
  store { i64, [2 x i64] } %t3, ptr %l2
  %t5 = load { i64, [2 x i64] }, ptr %l2
  %t7 = extractvalue { i64, [2 x i64] } %t5, 0
  %t8 = icmp eq i64 %t7, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i64 }, ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/views:Viewer", ptr %t17, i32 0, i32 20
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l12
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t26 = getelementptr %"compiler/views:summary", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l16
  br label %bb5
bb5:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/views:Viewer", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/views:Viewer", ptr %t37, i32 0, i32 20
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t36, i64 %t40)
  store ptr %t43, ptr %l22
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t46 = getelementptr %"compiler/views:summary", ptr %t44, i32 0, i32 3
  %t47 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t46, i64 %t47, i1 true)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/views:Viewer", ptr %t50, i32 0, i32 24
  store i1 true, ptr %t52, !tbaa !21
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b373ce5e6fb0acb1_b981b0fdcb20f7cd)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/views:naming"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/views:place"
  %l26 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l56 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca { i64, [2 x i64] }
  %l84 = alloca %"compiler/views:place"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l93 = alloca ptr
  %l97 = alloca %"compiler/views:place"
  %l98 = alloca ptr
  %l99 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l119 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l125 = alloca ptr
  %l127 = alloca i32
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i32
  %l145 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l159 = alloca i64
  %l162 = alloca i1
  %l163 = alloca i64
  %l168 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l174 = alloca %"compiler/views:place"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %t110 = alloca { i64, [2 x i64] }, align 8
  %t120 = alloca { i64, [2 x i64] }, align 8
  %t155 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t6 = load ptr, ptr %l30, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l30, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l31, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l31, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb38
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t28 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v2, ptr %t20, ptr %t21, i64 %t24)
  store i1 %t28, ptr %l40
  br label %bb9
bb9:
  %t29 = load i1, ptr %l40, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  br label %bb31
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v2, ptr %t34, i64 %t35)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l47
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb14, label %ok.42
ok.42:
  store { i64, ptr } %t39, ptr %l46
  br label %bb13
bb13:
  %t43 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t43, ptr %l43, !tbaa !27
  br label %bb18
bb14:
  %t44 = load i32, ptr %l47, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  br i1 %t47, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_dcfb2f8bfac0bc7f_4146aca391677efb)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb18:
  %t49 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t62 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t62, ptr %l56, !tbaa !27
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/views:naming", ptr %t66, i64 %t63
  %t68 = load %"compiler/views:naming", ptr %t67
  store %"compiler/views:naming" %t68, ptr %l10
  %t70 = getelementptr %"compiler/views:naming", ptr %l10, i32 0, i32 0
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load i32, ptr %l4, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = icmp eq i64 %t71, %t74
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/views:naming", ptr %l10, i32 0, i32 1
  %t81 = load %"compiler/views:place", ptr %t80
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t79, %"compiler/views:place" %t81)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l9, !tbaa !24
  br label %bb19
bb28:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = add i64 %t88, %t89
  store i64 %t92, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  br label %bb12
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb31:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/views:Viewer", ptr %t94, i32 0, i32 25
  %t97 = load i32, ptr %l4, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t96, i64 %t99)
  store i64 %t102, ptr %l74
  br label %bb32
bb32:
  %t103 = load i64, ptr %l74, !tbaa !24
  store i64 %t103, ptr %l11, !tbaa !24
  %t104 = load ptr, ptr %l3, !tbaa !29
  store ptr %t104, ptr %l75, !tbaa !29
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = icmp sge i64 %t105, 0
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t109 = load i64, ptr %l11, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 0
  store i64 2, ptr %t111
  %t113 = insertvalue { i64 } undef, i64 %t109, 0
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  store { i64 } %t113, ptr %t114
  %t115 = load { i64, [2 x i64] }, ptr %t110
  store { i64, [2 x i64] } %t115, ptr %l78
  br label %bb35
bb34:
  %t117 = load i32, ptr %l4, !tbaa !23
  %t119 = sext i32 %t117 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 0
  store i64 1, ptr %t121
  %t123 = insertvalue { i64 } undef, i64 %t119, 0
  %t124 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 1
  store { i64 } %t123, ptr %t124
  %t125 = load { i64, [2 x i64] }, ptr %t120
  store { i64, [2 x i64] } %t125, ptr %l78
  br label %bb35
bb35:
  %t127 = load { i64, [2 x i64] }, ptr %l78
  %t128 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s2, { i64, [2 x i64] } %t127, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t128, ptr %l84
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t130 = load %"compiler/views:place", ptr %l84
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t129, %"compiler/views:place" %t130)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb38:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t132 = load ptr, ptr %l85, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t135 = load ptr, ptr %l85, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 1
  store i1 %t138, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l86, !tbaa !21
  br i1 %t139, label %bb41, label %bb42
bb41:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l12, !tbaa !24
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t148, i32 0, i32 3
  %t150 = load i32, ptr %t149
  store i32 %t150, ptr %l13, !tbaa !23
  br label %bb43
bb42:
  br label %bb46
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t152 = load ptr, ptr %l3, !tbaa !29
  store ptr %t152, ptr %l93, !tbaa !29
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i32, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 0
  store i64 3, ptr %t156
  %t158 = insertvalue { i64, i32 } undef, i64 %t153, 0
  %t160 = insertvalue { i64, i32 } %t158, i32 %t154, 1
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 1
  store { i64, i32 } %t160, ptr %t161
  %t162 = load { i64, [2 x i64] }, ptr %t155
  %t164 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s9, { i64, [2 x i64] } %t162, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t164, ptr %l97
  br label %bb44
bb44:
  %t165 = load ptr, ptr %l93, !tbaa !29
  %t166 = load %"compiler/views:place", ptr %l97
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t165, %"compiler/views:place" %t166)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb96
bb46:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t168 = load ptr, ptr %l98, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb47, label %bb48
bb47:
  %t171 = load ptr, ptr %l98, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 2
  store i1 %t174, ptr %l99, !tbaa !21
  br label %bb48
bb48:
  %t175 = load i1, ptr %l99, !tbaa !21
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l14, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t186 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t182, ptr %t183, ptr %t185, ptr %t186)
  br label %bb52
bb52:
  br label %bb96
bb53:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t192 = load ptr, ptr %l109, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb54, label %bb55
bb54:
  %t195 = load ptr, ptr %l109, !tbaa !29
  %t196 = load i64, ptr %t195
  %t198 = icmp eq i64 %t196, 3
  store i1 %t198, ptr %l110, !tbaa !21
  br label %bb55
bb55:
  %t199 = load i1, ptr %l110, !tbaa !21
  br i1 %t199, label %bb56, label %bb57
bb56:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t202, i32 0, i32 1
  %t204 = load i32, ptr %t203
  store i32 %t204, ptr %l15, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l16, !tbaa !29
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t214, i32 0, i32 3
  %t216 = load i64, ptr %t215
  store i64 %t216, ptr %l17, !tbaa !24
  br label %bb58
bb57:
  br label %bb91
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t218 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t218, ptr %l119
  br label %bb59
bb59:
  %t219 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l18
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l16, !tbaa !29
  %t223 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s11, ptr %t220, ptr %t221, ptr %t223, ptr %l18)
  br label %bb60
bb60:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l125, !tbaa !29
  %t229 = load ptr, ptr %l16, !tbaa !29
  %t231 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t229)
  store i32 %t231, ptr %l127
  br label %bb61
bb61:
  %t232 = load i64, ptr %l17, !tbaa !24
  %t233 = load ptr, ptr %l125, !tbaa !29
  %t234 = load i32, ptr %l127, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %s11, ptr %t233, i32 %t234, i64 %t232)
  store { i64, ptr } %t236, ptr %l129
  br label %bb62
bb62:
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t239 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = getelementptr i8, ptr %t243, i64 %t238
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  store { i64, ptr } %t246, ptr %l19, !tbaa !27
  store ptr %l18, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t249 = load ptr, ptr %l20, !tbaa !29
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s11, ptr %t249, i64 %t250)
  %t254 = extractvalue { i32, { i64, ptr } } %t253, 1
  %t255 = extractvalue { i32, { i64, ptr } } %t253, 0
  store i32 %t255, ptr %l136
  %t256 = icmp ne i32 %t255, 0
  br i1 %t256, label %bb65, label %ok.257
ok.257:
  store { i64, ptr } %t254, ptr %l135
  br label %bb64
bb64:
  %t258 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t258, ptr %l132, !tbaa !27
  br label %bb69
bb65:
  %t259 = load i32, ptr %l136, !tbaa !23
  %t260 = ashr i32 %t259, 16
  %t262 = icmp eq i32 %t260, 1
  br i1 %t262, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_e4d7bfaf376e867e_92a843c67cd15a7a)
  unreachable
bb68:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb69:
  %t264 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t264, ptr %l22, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  store i64 %t267, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s15
  %t269 = load i64, ptr %l24, !tbaa !24
  %t270 = load i64, ptr %l23, !tbaa !24
  %t273 = icmp slt i64 %t269, %t270
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb72:
  br label %bb73
bb73:
  %t277 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t277, ptr %l145, !tbaa !27
  %t278 = load i64, ptr %l24, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr %"compiler/views:place", ptr %t281, i64 %t278
  %t283 = load %"compiler/views:place", ptr %t282
  store %"compiler/views:place" %t283, ptr %l25
  %t285 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 3
  %t286 = load i1, ptr %t285, !tbaa !21
  br i1 %t286, label %bb74, label %bb75
bb74:
  %t288 = load ptr, ptr %l3, !tbaa !29
  %t289 = load %"compiler/views:place", ptr %l25
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t288, %"compiler/views:place" %t289)
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb77:
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l151, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/views:Viewer", ptr %t293, i32 0, i32 3
  %t296 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  %t300 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s15, ptr %t295, i64 %t297)
  store { i64, ptr } %t300, ptr %l155
  br label %bb78
bb78:
  %t301 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t306 = extractvalue { i64, ptr } %t301, 1
  %t307 = extractvalue { i64, ptr } %t301, 0
  %t308 = add i64 %t304, %t307
  %t309 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t308)
  call void @olang_textcopy(ptr %t309, ptr %t303, i64 %t304)
  %t310 = getelementptr i8, ptr %t309, i64 %t304
  call void @olang_textcopy(ptr %t310, ptr %t306, i64 %t307)
  %t311 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t309, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = extractvalue { i64, ptr } %t312, 1
  %t316 = mul i64 %t314, 1
  %t317 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t316)
  call void @llvm.memcpy.p0.p0.i64(ptr %t317, ptr %t315, i64 %t316, i1 false)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  %t320 = load ptr, ptr %l151, !tbaa !29
  %t322 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s15, ptr %t320, { i64, ptr } %t319)
  store i64 %t322, ptr %l159
  br label %bb79
bb79:
  %t323 = load i64, ptr %l159, !tbaa !24
  store i64 %t323, ptr %l26, !tbaa !24
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l15, !tbaa !23
  %t328 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t324, i32 %t325)
  store i1 %t328, ptr %l162
  br label %bb80
bb80:
  %t329 = load i1, ptr %l162, !tbaa !21
  br i1 %t329, label %bb81, label %bb82
bb81:
  %t330 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 2
  %t331 = load i64, ptr %t330, !tbaa !24
  store i64 %t331, ptr %l163, !tbaa !24
  br label %bb84
bb82:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/views:Viewer", ptr %t333, i32 0, i32 3
  %t336 = load i64, ptr %l26, !tbaa !24
  %t339 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s15, ptr %t335, i64 %t336)
  store { i64, ptr } %t339, ptr %l168
  br label %bb83
bb83:
  %t340 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  store i64 %t341, ptr %l163, !tbaa !24
  br label %bb84
bb84:
  %t343 = load i64, ptr %l163, !tbaa !24
  %t344 = load ptr, ptr %l3, !tbaa !29
  store ptr %t344, ptr %l170, !tbaa !29
  %t345 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 0
  %t346 = load { i64, [2 x i64] }, ptr %t345
  %t347 = load i64, ptr %l26, !tbaa !24
  %t352 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s15, { i64, [2 x i64] } %t346, i64 %t347, i64 %t343, i1 false)
  store %"compiler/views:place" %t352, ptr %l174
  br label %bb85
bb85:
  %t353 = load ptr, ptr %l170, !tbaa !29
  %t354 = load %"compiler/views:place", ptr %l174
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t353, %"compiler/views:place" %t354)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb87:
  %t355 = load i64, ptr %l24, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l24, !tbaa !24
  br label %bb70
bb88:
  %t359 = load i64, ptr %l21, !tbaa !24
  %t360 = load i64, ptr %l23, !tbaa !24
  %t363 = add i64 %t359, %t360
  store i64 %t363, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb89:
  br label %bb63
bb90:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_2316851c574f2435_c433b61b556d3c11)
  unreachable
bb96:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca i1
  %l81 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i32
  %l96 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca i1
  %l112 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca i32
  %l141 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i1
  %l180 = alloca i64
  %l185 = alloca ptr
  %l187 = alloca ptr
  %l190 = alloca i64
  %l192 = alloca ptr
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l31, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t12 = load ptr, ptr %l34, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l34, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l35, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l5
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l6, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load %"compiler/source:Span", ptr %l5
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2euse(ptr %v0, ptr %v2, ptr %t32, i64 %t35, %"compiler/source:Span" %t36, ptr %t37)
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l6, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t47 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eholdsOf(ptr %v0, ptr %v2, ptr %v3, ptr %t42, ptr %t43, i64 %t46, ptr %t47)
  br label %bb13
bb13:
  br label %bb113
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t53 = load ptr, ptr %l52, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l52, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l53, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l7, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t67, ptr %t68, ptr %t70, ptr %t71)
  br label %bb20
bb20:
  br label %bb113
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t77 = load ptr, ptr %l63, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l63, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l64, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l64, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l8, !tbaa !23
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb52
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l71
  br label %bb27
bb27:
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %l10
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l9, !tbaa !29
  %t102 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s4, ptr %t99, ptr %t100, i1 false, ptr %t102, ptr %l10)
  br label %bb28
bb28:
  %t107 = load i1, ptr %l2, !tbaa !21
  br i1 %t107, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb32
bb30:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l8, !tbaa !23
  %t113 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t109, i32 %t110)
  store i1 %t113, ptr %l81
  br label %bb31
bb31:
  %t114 = load i1, ptr %l81, !tbaa !21
  store i1 %t114, ptr %l78, !tbaa !21
  br label %bb32
bb32:
  %t115 = load i1, ptr %l78, !tbaa !21
  br i1 %t115, label %bb33, label %bb34
bb33:
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb34:
  br label %bb51
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load ptr, ptr %l11, !tbaa !29
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s4, ptr %t117, i64 %t118)
  %t122 = extractvalue { i32, { i64, ptr } } %t121, 1
  %t123 = extractvalue { i32, { i64, ptr } } %t121, 0
  store i32 %t123, ptr %l87
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb37, label %ok.125
ok.125:
  store { i64, ptr } %t122, ptr %l86
  br label %bb36
bb36:
  %t126 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t126, ptr %l83, !tbaa !27
  br label %bb41
bb37:
  %t127 = load i32, ptr %l87, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  br i1 %t130, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_7b1b67136b76c79_188c2ea4ec84d8a5)
  unreachable
bb40:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb41:
  %t132 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t132, ptr %l13, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t145 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t145, ptr %l96, !tbaa !27
  %t146 = load i64, ptr %l15, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr %"compiler/views:view", ptr %t149, i64 %t146
  %t151 = load %"compiler/views:view", ptr %t150
  %t153 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t153, %"compiler/views:view" %t151)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb47:
  %t157 = load i64, ptr %l15, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l15, !tbaa !24
  br label %bb42
bb48:
  %t161 = load i64, ptr %l12, !tbaa !24
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = add i64 %t161, %t162
  store i64 %t165, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  br label %bb35
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb113
bb52:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t168 = load ptr, ptr %l106, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t171 = load ptr, ptr %l106, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l107, !tbaa !21
  br label %bb54
bb54:
  %t175 = load i1, ptr %l107, !tbaa !21
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l17, !tbaa !29
  br label %bb57
bb56:
  br label %bb81
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  %t182 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l112
  br label %bb58
bb58:
  %t183 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l18
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l17, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Elem", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s10, ptr %t184, ptr %t188, i1 false, ptr %t190, ptr %l18)
  br label %bb59
bb59:
  %t195 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t195, ptr %l119
  br label %bb60
bb60:
  %t196 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %l19
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l17, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Elem", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s10, ptr %t197, ptr %t201, ptr %t203, ptr %l19)
  br label %bb61
bb61:
  %t208 = load i1, ptr %l2, !tbaa !21
  br i1 %t208, label %bb62, label %bb63
bb62:
  store ptr %l18, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb64
bb63:
  br label %bb80
bb64:
  store %olang.scope zeroinitializer, ptr %s13
  %t211 = load ptr, ptr %l20, !tbaa !29
  %t212 = load i64, ptr %l21, !tbaa !24
  %t215 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s10, ptr %t211, i64 %t212)
  %t216 = extractvalue { i32, { i64, ptr } } %t215, 1
  %t217 = extractvalue { i32, { i64, ptr } } %t215, 0
  store i32 %t217, ptr %l132
  %t218 = icmp ne i32 %t217, 0
  br i1 %t218, label %bb66, label %ok.219
ok.219:
  store { i64, ptr } %t216, ptr %l131
  br label %bb65
bb65:
  %t220 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t220, ptr %l128, !tbaa !27
  br label %bb70
bb66:
  %t221 = load i32, ptr %l132, !tbaa !23
  %t222 = ashr i32 %t221, 16
  %t224 = icmp eq i32 %t222, 1
  br i1 %t224, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_ee6babc37b5ada8_202f4bf225a5be74)
  unreachable
bb69:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb70:
  %t226 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t226, ptr %l22, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t231 = load i64, ptr %l24, !tbaa !24
  %t232 = load i64, ptr %l23, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb73:
  br label %bb74
bb74:
  %t239 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t239, ptr %l141, !tbaa !27
  %t240 = load i64, ptr %l24, !tbaa !24
  %t242 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr %"compiler/views:view", ptr %t243, i64 %t240
  %t245 = load %"compiler/views:view", ptr %t244
  %t247 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t247, %"compiler/views:view" %t245)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb76
bb76:
  %t251 = load i64, ptr %l24, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l24, !tbaa !24
  br label %bb71
bb77:
  %t255 = load i64, ptr %l21, !tbaa !24
  %t256 = load i64, ptr %l23, !tbaa !24
  %t259 = add i64 %t255, %t256
  store i64 %t259, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb78
bb78:
  br label %bb64
bb79:
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s10)
  br label %bb113
bb81:
  %t261 = load ptr, ptr %l1, !tbaa !29
  store ptr %t261, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t262 = load ptr, ptr %l151, !tbaa !29
  %t263 = icmp ne ptr %t262, null
  br i1 %t263, label %bb82, label %bb83
bb82:
  %t265 = load ptr, ptr %l151, !tbaa !29
  %t266 = load i64, ptr %t265
  %t268 = icmp eq i64 %t266, 5
  store i1 %t268, ptr %l152, !tbaa !21
  br label %bb83
bb83:
  %t269 = load i1, ptr %l152, !tbaa !21
  br i1 %t269, label %bb84, label %bb85
bb84:
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr { i64, [4 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t272, i32 0, i32 2
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l26, !tbaa !29
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l26, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Payload", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = load ptr, ptr %l3, !tbaa !29
  %t283 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t276, ptr %t280, i1 false, ptr %t282, ptr %t283)
  br label %bb87
bb87:
  br label %bb113
bb88:
  %t288 = load ptr, ptr %l1, !tbaa !29
  store ptr %t288, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t289 = load ptr, ptr %l163, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb89, label %bb90
bb89:
  %t292 = load ptr, ptr %l163, !tbaa !29
  %t293 = load i64, ptr %t292
  %t295 = icmp eq i64 %t293, 6
  store i1 %t295, ptr %l164, !tbaa !21
  br label %bb90
bb90:
  %t296 = load i1, ptr %l164, !tbaa !21
  br i1 %t296, label %bb91, label %bb92
bb91:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [4 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t299, i32 0, i32 2
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l27, !tbaa !29
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l27, !tbaa !29
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t307 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t303, ptr %t304, ptr %t306, ptr %t307)
  br label %bb94
bb94:
  br label %bb113
bb95:
  %t312 = load ptr, ptr %l1, !tbaa !29
  store ptr %t312, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t313 = load ptr, ptr %l174, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb96, label %bb97
bb96:
  %t316 = load ptr, ptr %l174, !tbaa !29
  %t317 = load i64, ptr %t316
  %t319 = icmp eq i64 %t317, 7
  store i1 %t319, ptr %l175, !tbaa !21
  br label %bb97
bb97:
  %t320 = load i1, ptr %l175, !tbaa !21
  br i1 %t320, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb108
bb100:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/views:Viewer", ptr %t321, i32 0, i32 27
  %t325 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t323)
  store i64 %t325, ptr %l180
  br label %bb101
bb101:
  %t326 = load i64, ptr %l180, !tbaa !24
  %t327 = icmp sgt i64 %t326, 0
  br i1 %t327, label %bb102, label %bb103
bb102:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/views:Viewer", ptr %t329, i32 0, i32 22
  %t332 = load i1, ptr %t331, !tbaa !21
  store i1 %t332, ptr %l28, !tbaa !21
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/views:Viewer", ptr %t334, i32 0, i32 22
  store i1 true, ptr %t336, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l185, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/views:Viewer", ptr %t338, i32 0, i32 27
  store ptr %t340, ptr %l187, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/views:Viewer", ptr %t341, i32 0, i32 27
  %t345 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t343)
  store i64 %t345, ptr %l190
  br label %bb104
bb103:
  br label %bb107
bb104:
  %t346 = load i64, ptr %l190, !tbaa !24
  %t347 = sub i64 %t346, 1
  %t348 = load ptr, ptr %l187, !tbaa !29
  %t350 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v0, ptr %t348, i64 %t347)
  store ptr %t350, ptr %l192
  br label %bb105
bb105:
  %t351 = load ptr, ptr %l192, !tbaa !29
  %t352 = load i1, ptr %l2, !tbaa !21
  %t353 = load ptr, ptr %l3, !tbaa !29
  %t354 = load ptr, ptr %l4, !tbaa !29
  %t355 = load ptr, ptr %l185, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t355, ptr %t351, i1 %t352, ptr %t353, ptr %t354)
  br label %bb106
bb106:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load i1, ptr %l28, !tbaa !21
  %t364 = getelementptr %"compiler/views:Viewer", ptr %t360, i32 0, i32 22
  store i1 %t361, ptr %t364, !tbaa !21
  br label %bb107
bb107:
  br label %bb113
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_4e796811ab380d83_57d60764fb489daf)
  unreachable
bb113:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Elem", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t27, i8 91)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t32, ptr %l6
  br label %bb20
bb7:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 3
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l4
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t60 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, ptr %t56, i8 46)
  store %"compiler/source:Span" %t60, ptr %l31
  br label %bb13
bb13:
  %t61 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t62)
  store %"compiler/source:Span" %t64, ptr %l33
  br label %bb18
bb18:
  %t65 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t65, ptr %l6
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_26b1312863f2c2c7_c8d66606dd24933b)
  unreachable
bb20:
  %t66 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 3
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/views:Viewer", ptr %t9, i32 0, i32 3
  %t15 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t11, i64 %a2)
  store { i64, ptr } %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v0, { i64, ptr } %t17, { i64, ptr } %t18)
  store i1 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp eq i64 %t25, %t28
  br i1 %t31, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 46
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l22, !tbaa !21
  store i1 %t45, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l16, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2equoted(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/views:Viewer", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l14
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 1
  %t31 = load { i64, [2 x i64] }, ptr %t30
  store { i64, [2 x i64] } %t31, ptr %l2
  %t33 = load { i64, [2 x i64] }, ptr %l2
  %t35 = extractvalue { i64, [2 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 0
  br i1 %t36, label %bb5, label %bb6
bb5:
  %t38 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t39 = getelementptr { i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/views:Viewer", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/views:Viewer", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l27
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l27, !tbaa !24
  %t57 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t55, i64 %t56)
  store ptr %t57, ptr %l28
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load ptr, ptr %l21, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t62, i32 %t61)
  store { i64, ptr } %t64, ptr %l31
  br label %bb10
bb10:
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t75, ptr %t68, i64 %t69)
  %t76 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t76, ptr %t71, i64 %t72)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t74, 1
  store { i64, ptr } %t78, ptr %l17, !tbaa !27
  br label %bb23
bb11:
  %t80 = load { i64, [2 x i64] }, ptr %l2
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 1
  br i1 %t83, label %bb12, label %bb13
bb12:
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t86 = getelementptr { i32, i32 }, ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l36, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/views:Viewer", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l39, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/views:Viewer", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l4, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l44
  br label %bb15
bb15:
  %t106 = load ptr, ptr %l39, !tbaa !29
  %t107 = load i32, ptr %l44, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t108, ptr %l45
  br label %bb16
bb16:
  %t109 = load ptr, ptr %l36, !tbaa !29
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l46
  br label %bb17
bb17:
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t114 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t112, i64 %t113)
  %t122 = getelementptr i8, ptr %t121, i64 %t113
  call void @olang_textcopy(ptr %t122, ptr %t115, i64 %t116)
  %t123 = getelementptr i8, ptr %t122, i64 %t116
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t121, 1
  store { i64, ptr } %t125, ptr %l17, !tbaa !27
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t127, ptr %l17, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_52eb4a404ee8e2f2_daf885f9c5247eae)
  unreachable
bb23:
  %t129 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l50, !tbaa !24
  %t131 = load i64, ptr %l50, !tbaa !24
  %t132 = mul i64 %t131, 1
  %t133 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l51, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = mul i64 %t140, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %t139, i64 %t141, i1 false)
  %t142 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t142, ptr %l17, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erecordPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i32, ptr %l7, !tbaa !23
  %t7 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t7, ptr %l8
  br label %bb2
bb2:
  %t8 = load i1, ptr %l8, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 2
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t26, ptr %t27, ptr %t29, ptr %t30)
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t38, ptr %t39)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_24f4045ab8cbf215_2ef83d27164e37c1)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %t27, i64 %t30)
  store i1 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb13
bb12:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l10, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_40eaf25cbb0521a7_3d2a576ac0c8b0f3)
  unreachable
bb19:
  %t40 = load i64, ptr %l10, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  store i64 64, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l23, !tbaa !24
  store i64 %t30, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l8, !tbaa !24
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l2, !tbaa !29
  store ptr %t55, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t56 = load ptr, ptr %l44, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l44, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 3
  store i1 %t62, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l45, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l9, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t70 = load ptr, ptr %l9, !tbaa !29
  store ptr %t70, ptr %l2, !tbaa !29
  br label %bb68
bb19:
  %t73 = load ptr, ptr %l2, !tbaa !29
  store ptr %t73, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t74 = load ptr, ptr %l52, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l52, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 4
  store i1 %t80, ptr %l53, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l53, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l10, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Elem", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l2, !tbaa !29
  br label %bb68
bb25:
  %t94 = load ptr, ptr %l2, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t98 = load ptr, ptr %l61, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 5
  store i1 %t101, ptr %l62, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l11, !tbaa !29
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t109 = load ptr, ptr %l11, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Payload", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l2, !tbaa !29
  br label %bb68
bb31:
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t116 = load ptr, ptr %l70, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 2
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb34, label %bb35
bb34:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l12, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t132 = call ptr @compiler_2fviews_2eunAway(ptr %v1, ptr %t130)
  store ptr %t132, ptr %l77
  br label %bb37
bb37:
  %t133 = load ptr, ptr %l77, !tbaa !29
  store ptr %t133, ptr %l13, !tbaa !29
  %t134 = load ptr, ptr %l13, !tbaa !29
  store ptr %t134, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t135 = load ptr, ptr %l78, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l78, !tbaa !29
  %t139 = load i64, ptr %t138
  %t141 = icmp eq i64 %t139, 2
  store i1 %t141, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t142 = load i1, ptr %l79, !tbaa !21
  br i1 %t142, label %bb40, label %bb41
bb40:
  %t143 = load ptr, ptr %l13, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l14, !tbaa !29
  br label %bb46
bb41:
  %t149 = load ptr, ptr %l13, !tbaa !29
  store ptr %t149, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t150 = load ptr, ptr %l84, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb42, label %bb43
bb42:
  %t153 = load ptr, ptr %l84, !tbaa !29
  %t154 = load i64, ptr %t153
  %t156 = icmp eq i64 %t154, 3
  store i1 %t156, ptr %l85, !tbaa !21
  br label %bb43
bb43:
  %t157 = load i1, ptr %l85, !tbaa !21
  br i1 %t157, label %bb44, label %bb45
bb44:
  %t158 = load ptr, ptr %l13, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l14, !tbaa !29
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l2, !tbaa !29
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb51:
  call void @__olang_check_failed(ptr @olang_loc_945ffbf6072962e3_f3ad5bbe10c5f487)
  unreachable
bb52:
  br label %bb68
bb53:
  %t168 = load ptr, ptr %l2, !tbaa !29
  store ptr %t168, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t169 = load ptr, ptr %l93, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb54, label %bb55
bb54:
  %t172 = load ptr, ptr %l93, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 0
  store i1 %t175, ptr %l94, !tbaa !21
  br label %bb55
bb55:
  %t176 = load i1, ptr %l94, !tbaa !21
  br i1 %t176, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t177 = load ptr, ptr %l2, !tbaa !29
  store ptr %t177, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t178 = load ptr, ptr %l97, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb58, label %bb59
bb58:
  %t181 = load ptr, ptr %l97, !tbaa !29
  %t182 = load i64, ptr %t181
  %t184 = icmp eq i64 %t182, 1
  store i1 %t184, ptr %l98, !tbaa !21
  br label %bb59
bb59:
  %t185 = load i1, ptr %l98, !tbaa !21
  br i1 %t185, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t186 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t186, ptr %rv
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @olang_loc_f83bd81acd9884e2_c22158a061119526)
  unreachable
bb68:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb69:
  %t189 = load i64, ptr %l7, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l7, !tbaa !24
  br label %bb7
bb70:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 19
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_5699d6f0b9487a4c_f8171e4e8a154888)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 19
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = shl i64 %t15, 32
  %t18 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = or i64 %t17, %t21
  store i64 %t24, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 28
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t28, i64 %t29)
  store i1 %t32, ptr %l17
  br label %bb4
bb4:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/views:Viewer", ptr %t35, i32 0, i32 28
  %t38 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t37, i64 %t38, i1 true)
  br label %bb8
bb8:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i8
  %l8 = alloca i1
  %l11 = alloca i8
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t3, i64 %t4)
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = icmp eq i8 %t8, 32
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t11, i64 %t12)
  store i8 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = icmp eq i8 %t16, 9
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l8, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = add i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb1
bb11:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l52 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l91 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l98 = alloca %"compiler/views:tasked"
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Spawn", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t3, ptr %t7, ptr %t9, ptr %l4)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 22
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l5, !tbaa !21
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/views:Viewer", ptr %t19, i32 0, i32 22
  store i1 true, ptr %t21, !tbaa !21
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l35
  br label %bb3
bb3:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l6
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Spawn", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l7, !tbaa !29
  %t29 = load ptr, ptr %l7, !tbaa !29
  store ptr %t29, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t30 = load ptr, ptr %l38, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = load ptr, ptr %l38, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 6
  store i1 %t36, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l39, !tbaa !21
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l7, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l8, !tbaa !29
  br label %bb8
bb7:
  br label %bb28
bb8:
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t61 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t61, ptr %l52, !tbaa !27
  %t62 = load i64, ptr %l10, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t69, ptr %t67, ptr %t72, ptr %l6)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l10, !tbaa !24
  br label %bb9
bb15:
  %t81 = load ptr, ptr %l8, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Call", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l13, !tbaa !29
  %t86 = load ptr, ptr %l13, !tbaa !29
  store ptr %t86, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t87 = load ptr, ptr %l64, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t90 = load ptr, ptr %l64, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 2
  store i1 %t93, ptr %l65, !tbaa !21
  br label %bb17
bb17:
  %t94 = load i1, ptr %l65, !tbaa !21
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t95 = load ptr, ptr %l13, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { ptr }, ptr %t97, i32 0, i32 0
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l14, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l14, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t101, ptr %t102, ptr %t104, ptr %l6)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ef97709dce49d3b_530bdd1db1d3a0b7)
  unreachable
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_cf8b3001c30b10ba_435a3683731d1196)
  unreachable
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i1, ptr %l5, !tbaa !21
  %t113 = getelementptr %"compiler/views:Viewer", ptr %t109, i32 0, i32 22
  store i1 %t110, ptr %t113, !tbaa !21
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t115 = load ptr, ptr %l15, !tbaa !29
  %t116 = load i64, ptr %l16, !tbaa !24
  %t119 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t115, i64 %t116)
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l82
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb36, label %ok.123
ok.123:
  store { i64, ptr } %t120, ptr %l81
  br label %bb35
bb35:
  %t124 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t124, ptr %l78, !tbaa !27
  br label %bb40
bb36:
  %t125 = load i32, ptr %l82, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  br i1 %t128, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_528f79d8d6cfab51_d5690ebe94fe9aad)
  unreachable
bb39:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb40:
  %t130 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t130, ptr %l17, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t135 = load i64, ptr %l19, !tbaa !24
  %t136 = load i64, ptr %l18, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t143 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t143, ptr %l91, !tbaa !27
  %t144 = load i64, ptr %l19, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr %"compiler/views:view", ptr %t147, i64 %t144
  %t149 = load %"compiler/views:view", ptr %t148
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t153 = getelementptr %"compiler/views:state", ptr %t151, i32 0, i32 4
  store ptr %t153, ptr %l95, !tbaa !29
  %t158 = call %"compiler/views:tasked" @compiler_2fviews_3atasked_2ector(ptr %s10, %"compiler/views:view" %t149, %"compiler/source:Span" %a1)
  store %"compiler/views:tasked" %t158, ptr %l98
  br label %bb45
bb45:
  %t159 = load ptr, ptr %l95, !tbaa !29
  %t160 = load %"compiler/views:tasked", ptr %l98
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t159, %"compiler/views:tasked" %t160)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t161 = load i64, ptr %l19, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l19, !tbaa !24
  br label %bb41
bb48:
  %t165 = load i64, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l18, !tbaa !24
  %t169 = add i64 %t165, %t166
  store i64 %t169, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb49:
  br label %bb34
bb50:
  %t171 = load ptr, ptr %l2, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Spawn", ptr %t171, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  store { i64, ptr } %t174, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  store i64 %t178, ptr %l23, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s13
  %t180 = load i64, ptr %l22, !tbaa !24
  %t181 = load i64, ptr %l23, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t188 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t188, ptr %l112, !tbaa !27
  %t189 = load i64, ptr %l22, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr ptr, ptr %t192, i64 %t189
  %t194 = load ptr, ptr %t193, !tbaa !39
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %s13, ptr %s0, ptr %v2, ptr %t196, ptr %t194, ptr null, ptr %l4, ptr %t198)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb56
bb56:
  %t203 = load i64, ptr %l22, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l22, !tbaa !24
  br label %bb51
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/views:state"
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/views:view"
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/views:view"
  %l39 = alloca { i64, [2 x i64] }
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca %"compiler/views:state"
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca ptr
  %l79 = alloca i1
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca %"compiler/views:state"
  %l133 = alloca %"compiler/views:state"
  %l147 = alloca ptr
  %l148 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %l169 = alloca i64
  %l173 = alloca i1
  %l177 = alloca ptr
  %l192 = alloca ptr
  %l194 = alloca ptr
  %l196 = alloca %"compiler/views:state"
  %l200 = alloca ptr
  %l202 = alloca ptr
  %l204 = alloca %"compiler/views:state"
  %l206 = alloca ptr
  %l207 = alloca i1
  %l214 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l223 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l227 = alloca i32
  %l236 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l248 = alloca ptr
  %l264 = alloca ptr
  %l265 = alloca i1
  %l272 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l281 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l285 = alloca i32
  %l294 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l306 = alloca ptr
  %l321 = alloca ptr
  %l322 = alloca i1
  %l325 = alloca ptr
  %l326 = alloca i1
  %l330 = alloca ptr
  %l331 = alloca i1
  %l345 = alloca ptr
  %l346 = alloca i1
  %l362 = alloca %"compiler/views:state"
  %l368 = alloca ptr
  %l369 = alloca i1
  %l378 = alloca ptr
  %l379 = alloca i1
  %l382 = alloca ptr
  %l383 = alloca i1
  %l390 = alloca i64
  %l399 = alloca i1
  %l402 = alloca i64
  %l413 = alloca ptr
  %l414 = alloca i1
  %l425 = alloca ptr
  %l426 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s35 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l53, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l53, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l56
  br label %bb7
bb7:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l3
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t14 = load ptr, ptr %l57, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l57, !tbaa !29
  %t18 = load i64, ptr %t17
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l58, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l58, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l65
  br label %bb13
bb13:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l6
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t36, ptr %t37, ptr %t39, ptr %l6)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l4, !tbaa !23
  %t47 = sext i32 %t45 to i64
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v1, ptr %s2, ptr %v2, ptr %t44, i64 %t47, ptr %t48, ptr %l6, i1 true, ptr %t50)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb247
bb16:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t57 = load ptr, ptr %l78, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l78, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 1
  store i1 %t63, ptr %l79, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l79, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l8, !tbaa !29
  br label %bb21
bb20:
  br label %bb30
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l86
  br label %bb22
bb22:
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l9
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/views:Viewer", ptr %t79, i32 0, i32 27
  %t82 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  br label %bb23
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l8, !tbaa !29
  %t88 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t85, ptr %t86, ptr %t88, ptr %l9)
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/views:Viewer", ptr %t93, i32 0, i32 27
  %t97 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePo_H0db9b8972766e5b481cadc211ca24c07(ptr %v0, ptr %s3, ptr %t95)
  %t98 = extractvalue { i32, ptr } %t97, 1
  %t99 = extractvalue { i32, ptr } %t97, 0
  store i32 %t99, ptr %l99
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb26, label %ok.101
ok.101:
  store ptr %t98, ptr %l98
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l98, !tbaa !29
  store ptr %t102, ptr %l95, !tbaa !29
  br label %bb28
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %s3, ptr %v2, ptr %t103, ptr %t104, ptr %t106, ptr %l9, ptr %t108)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb247
bb30:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t115 = load ptr, ptr %l107, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l107, !tbaa !29
  %t119 = load i64, ptr %t118
  %t121 = icmp eq i64 %t119, 2
  store i1 %t121, ptr %l108, !tbaa !21
  br label %bb32
bb32:
  %t122 = load i1, ptr %l108, !tbaa !21
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t129, ptr %t130, ptr %t132, ptr %l3)
  br label %bb36
bb36:
  br label %bb247
bb37:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t138 = load ptr, ptr %l118, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb38, label %bb39
bb38:
  %t141 = load ptr, ptr %l118, !tbaa !29
  %t142 = load i64, ptr %t141
  %t144 = icmp eq i64 %t142, 3
  store i1 %t144, ptr %l119, !tbaa !21
  br label %bb39
bb39:
  %t145 = load i1, ptr %l119, !tbaa !21
  br i1 %t145, label %bb40, label %bb41
bb40:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l11, !tbaa !29
  br label %bb42
bb41:
  br label %bb50
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/typed:If", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t152, ptr %t156, ptr %t158, ptr %l3)
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t165 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s6, ptr %t163)
  store %"compiler/views:state" %t165, ptr %l131
  br label %bb44
bb44:
  %t166 = load %"compiler/views:state", ptr %l131
  store %"compiler/views:state" %t166, ptr %l12
  %t167 = load ptr, ptr %l2, !tbaa !29
  %t169 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s6, ptr %t167)
  store %"compiler/views:state" %t169, ptr %l133
  br label %bb45
bb45:
  %t170 = load %"compiler/views:state", ptr %l133
  store %"compiler/views:state" %t170, ptr %l13
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t174 = getelementptr %"compiler/typed:If", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s6, ptr %t171, ptr %t175, ptr %l12)
  br label %bb46
bb46:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l11, !tbaa !29
  %t183 = getelementptr %"compiler/typed:If", ptr %t181, i32 0, i32 2
  %t184 = load ptr, ptr %t183, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s6, ptr %t180, ptr %t184, ptr %l13)
  br label %bb47
bb47:
  call void @compiler_2fviews_2emerge(ptr %s6, ptr %s6, ptr %l12, ptr %l13)
  br label %bb48
bb48:
  %t190 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s6, ptr %t190, ptr %l12)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb247
bb50:
  %t193 = load ptr, ptr %l1, !tbaa !29
  store ptr %t193, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t194 = load ptr, ptr %l147, !tbaa !29
  %t195 = icmp ne ptr %t194, null
  br i1 %t195, label %bb51, label %bb52
bb51:
  %t197 = load ptr, ptr %l147, !tbaa !29
  %t198 = load i64, ptr %t197
  %t200 = icmp eq i64 %t198, 4
  store i1 %t200, ptr %l148, !tbaa !21
  br label %bb52
bb52:
  %t201 = load i1, ptr %l148, !tbaa !21
  br i1 %t201, label %bb53, label %bb54
bb53:
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t204, i32 0, i32 1
  %t206 = load ptr, ptr %t205
  store ptr %t206, ptr %l14, !tbaa !29
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr { i64, [3 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t210, i32 0, i32 2
  %t212 = load ptr, ptr %t211
  store ptr %t212, ptr %l15, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l14, !tbaa !29
  %t216 = load ptr, ptr %l15, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t214, ptr %t215, ptr %t216, ptr %t217)
  br label %bb56
bb56:
  br label %bb247
bb57:
  %t222 = load ptr, ptr %l1, !tbaa !29
  store ptr %t222, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t223 = load ptr, ptr %l159, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb58, label %bb59
bb58:
  %t226 = load ptr, ptr %l159, !tbaa !29
  %t227 = load i64, ptr %t226
  %t229 = icmp eq i64 %t227, 5
  store i1 %t229, ptr %l160, !tbaa !21
  br label %bb59
bb59:
  %t230 = load i1, ptr %l160, !tbaa !21
  br i1 %t230, label %bb60, label %bb61
bb60:
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t233, i32 0, i32 1
  %t235 = load i32, ptr %t234
  store i32 %t235, ptr %l16
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t239, i32 0, i32 2
  %t241 = load i32, ptr %t240
  store i32 %t241, ptr %l17, !tbaa !23
  br label %bb62
bb61:
  br label %bb86
bb62:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/views:Viewer", ptr %t243, i32 0, i32 26
  %t247 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H9b6ab774c92f21a4ef5a53265d5b9504(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l169
  br label %bb63
bb63:
  %t248 = load i64, ptr %l169, !tbaa !24
  %t249 = sub i64 %t248, 1
  store i64 %t249, ptr %l18, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t251 = load i64, ptr %l18, !tbaa !24
  %t253 = icmp sge i64 %t251, 0
  br i1 %t253, label %bb65, label %bb66
bb65:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/views:Viewer", ptr %t255, i32 0, i32 26
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t257, i64 %t258)
  store ptr %t261, ptr %l177
  br label %bb67
bb66:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb68
bb67:
  %t262 = load ptr, ptr %l177, !tbaa !29
  %t264 = getelementptr %"compiler/views:loopFrame", ptr %t262, i32 0, i32 0
  %t265 = load i32, ptr %t264, !tbaa !23
  %t266 = load i32, ptr %l17, !tbaa !23
  %t269 = icmp ne i32 %t265, %t266
  store i1 %t269, ptr %l173, !tbaa !21
  br label %bb68
bb68:
  %t271 = load i1, ptr %l173, !tbaa !21
  %t272 = xor i1 %t271, true
  br i1 %t272, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb73
bb70:
  br label %bb71
bb71:
  %t274 = load i64, ptr %l18, !tbaa !24
  %t276 = sub i64 %t274, 1
  store i64 %t276, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb72:
  br label %bb64
bb73:
  %t278 = load i64, ptr %l18, !tbaa !24
  %t280 = icmp sge i64 %t278, 0
  br i1 %t280, label %bb74, label %bb75
bb74:
  %t282 = load i32, ptr %l16
  %t284 = trunc i64 0 to i32
  %t285 = icmp eq i32 %t282, %t284
  br i1 %t285, label %bb76, label %bb77
bb75:
  br label %bb85
bb76:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/views:Viewer", ptr %t287, i32 0, i32 26
  %t290 = load i64, ptr %l18, !tbaa !24
  %t293 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l192
  br label %bb78
bb77:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/views:Viewer", ptr %t294, i32 0, i32 26
  %t297 = load i64, ptr %l18, !tbaa !24
  %t300 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t296, i64 %t297)
  store ptr %t300, ptr %l200
  br label %bb81
bb78:
  %t301 = load ptr, ptr %l192, !tbaa !29
  %t303 = getelementptr %"compiler/views:loopFrame", ptr %t301, i32 0, i32 1
  store ptr %t303, ptr %l194, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %v0, ptr %t304)
  store %"compiler/views:state" %t306, ptr %l196
  br label %bb79
bb79:
  %t307 = load ptr, ptr %l194, !tbaa !29
  %t308 = load %"compiler/views:state", ptr %l196
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v0, ptr %t307, %"compiler/views:state" %t308)
  br label %bb80
bb80:
  br label %bb84
bb81:
  %t309 = load ptr, ptr %l200, !tbaa !29
  %t311 = getelementptr %"compiler/views:loopFrame", ptr %t309, i32 0, i32 2
  store ptr %t311, ptr %l202, !tbaa !29
  %t312 = load ptr, ptr %l2, !tbaa !29
  %t314 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %v0, ptr %t312)
  store %"compiler/views:state" %t314, ptr %l204
  br label %bb82
bb82:
  %t315 = load ptr, ptr %l202, !tbaa !29
  %t316 = load %"compiler/views:state", ptr %l204
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v0, ptr %t315, %"compiler/views:state" %t316)
  br label %bb83
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr %"compiler/views:state", ptr %t317, i32 0, i32 0
  store i1 true, ptr %t319, !tbaa !21
  br label %bb247
bb86:
  %t320 = load ptr, ptr %l1, !tbaa !29
  store ptr %t320, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t321 = load ptr, ptr %l206, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb87, label %bb88
bb87:
  %t324 = load ptr, ptr %l206, !tbaa !29
  %t325 = load i64, ptr %t324
  %t327 = icmp eq i64 %t325, 6
  store i1 %t327, ptr %l207, !tbaa !21
  br label %bb88
bb88:
  %t328 = load i1, ptr %l207, !tbaa !21
  br i1 %t328, label %bb89, label %bb90
bb89:
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [3 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", ptr }, ptr %t331, i32 0, i32 0
  %t333 = load %"compiler/source:Span", ptr %t332
  store %"compiler/source:Span" %t333, ptr %l19
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l20, !tbaa !29
  br label %bb91
bb90:
  br label %bb128
bb91:
  store %olang.scope zeroinitializer, ptr %s13
  %t341 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t341, ptr %l214
  br label %bb92
bb92:
  %t342 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l214
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t342, ptr %l21
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l20, !tbaa !29
  %t345 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s13, ptr %t343, ptr %t344, ptr %t345, ptr %l21)
  br label %bb93
bb93:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/views:Viewer", ptr %t350, i32 0, i32 21
  %t353 = load i1, ptr %t352, !tbaa !21
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb94, label %bb95
bb94:
  store ptr %l21, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb96
bb95:
  br label %bb127
bb96:
  store %olang.scope zeroinitializer, ptr %s16
  %t358 = load ptr, ptr %l22, !tbaa !29
  %t359 = load i64, ptr %l23, !tbaa !24
  %t362 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s13, ptr %t358, i64 %t359)
  %t363 = extractvalue { i32, { i64, ptr } } %t362, 1
  %t364 = extractvalue { i32, { i64, ptr } } %t362, 0
  store i32 %t364, ptr %l227
  %t365 = icmp ne i32 %t364, 0
  br i1 %t365, label %bb98, label %ok.366
ok.366:
  store { i64, ptr } %t363, ptr %l226
  br label %bb97
bb97:
  %t367 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t367, ptr %l223, !tbaa !27
  br label %bb102
bb98:
  %t368 = load i32, ptr %l227, !tbaa !23
  %t369 = ashr i32 %t368, 16
  %t371 = icmp eq i32 %t369, 1
  br i1 %t371, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_1e57e3539652abf4_8f970453f904e310)
  unreachable
bb101:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s16)
  br label %bb126
bb102:
  %t373 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t373, ptr %l24, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb103
bb103:
  store %olang.scope zeroinitializer, ptr %s17
  %t378 = load i64, ptr %l26, !tbaa !24
  %t379 = load i64, ptr %l25, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s17)
  br label %bb124
bb105:
  br label %bb106
bb106:
  %t386 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t386, ptr %l236, !tbaa !27
  %t387 = load i64, ptr %l26, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr %"compiler/views:view", ptr %t390, i64 %t387
  %t392 = load %"compiler/views:view", ptr %t391
  store %"compiler/views:view" %t392, ptr %l27
  %t394 = getelementptr %"compiler/views:view", ptr %l27, i32 0, i32 0
  %t395 = getelementptr %"compiler/views:place", ptr %t394, i32 0, i32 0
  %t396 = load { i64, [2 x i64] }, ptr %t395
  store { i64, [2 x i64] } %t396, ptr %l28
  %t398 = load { i64, [2 x i64] }, ptr %l28
  %t400 = extractvalue { i64, [2 x i64] } %t398, 0
  %t401 = icmp eq i64 %t400, 2
  br i1 %t401, label %bb107, label %bb108
bb107:
  %t403 = getelementptr { i64, [2 x i64] }, ptr %l28, i32 0, i32 1
  %t404 = getelementptr { i64 }, ptr %t403, i32 0, i32 0
  %t405 = load i64, ptr %t404
  store i64 %t405, ptr %l29, !tbaa !24
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l243, !tbaa !29
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/views:Viewer", ptr %t408, i32 0, i32 2
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/views:Viewer", ptr %t411, i32 0, i32 20
  %t414 = load i64, ptr %t413, !tbaa !24
  %t417 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t410, i64 %t414)
  store ptr %t417, ptr %l248
  br label %bb110
bb110:
  %t418 = load ptr, ptr %l248, !tbaa !29
  %t420 = getelementptr %"compiler/views:summary", ptr %t418, i32 0, i32 1
  %t421 = load i64, ptr %l29, !tbaa !24
  %t422 = getelementptr %"compiler/views:view", ptr %l27, i32 0, i32 0
  %t423 = load %"compiler/views:place", ptr %t422
  %t424 = load %"compiler/source:Span", ptr %l19
  %t425 = load ptr, ptr %l243, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t425, ptr %t420, i64 %t421, i64 -1, i32 0, %"compiler/views:place" %t423, %"compiler/source:Span" %t424)
  br label %bb111
bb111:
  br label %bb122
bb112:
  %t430 = load { i64, [2 x i64] }, ptr %l28
  %t432 = extractvalue { i64, [2 x i64] } %t430, 0
  %t433 = icmp eq i64 %t432, 4
  br i1 %t433, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load %"compiler/views:view", ptr %l27
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t435, %"compiler/views:view" %t436)
  br label %bb116
bb116:
  br label %bb122
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_16b4c6065d31c625_db15f6d21a68dda1)
  unreachable
bb122:
  call void @__olang_scope_close(ptr %s17)
  br label %bb123
bb123:
  %t439 = load i64, ptr %l26, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l26, !tbaa !24
  br label %bb103
bb124:
  %t443 = load i64, ptr %l23, !tbaa !24
  %t444 = load i64, ptr %l25, !tbaa !24
  %t447 = add i64 %t443, %t444
  store i64 %t447, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb125
bb125:
  br label %bb96
bb126:
  br label %bb127
bb127:
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t451 = getelementptr %"compiler/views:state", ptr %t449, i32 0, i32 0
  store i1 true, ptr %t451, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb247
bb128:
  %t452 = load ptr, ptr %l1, !tbaa !29
  store ptr %t452, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t453 = load ptr, ptr %l264, !tbaa !29
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %bb129, label %bb130
bb129:
  %t456 = load ptr, ptr %l264, !tbaa !29
  %t457 = load i64, ptr %t456
  %t459 = icmp eq i64 %t457, 16
  store i1 %t459, ptr %l265, !tbaa !21
  br label %bb130
bb130:
  %t460 = load i1, ptr %l265, !tbaa !21
  br i1 %t460, label %bb131, label %bb132
bb131:
  %t461 = load ptr, ptr %l1, !tbaa !29
  %t463 = getelementptr { i64, [3 x i64] }, ptr %t461, i32 0, i32 1
  %t464 = getelementptr { %"compiler/source:Span", ptr }, ptr %t463, i32 0, i32 0
  %t465 = load %"compiler/source:Span", ptr %t464
  store %"compiler/source:Span" %t465, ptr %l30
  %t467 = load ptr, ptr %l1, !tbaa !29
  %t469 = getelementptr { i64, [3 x i64] }, ptr %t467, i32 0, i32 1
  %t470 = getelementptr { %"compiler/source:Span", ptr }, ptr %t469, i32 0, i32 1
  %t471 = load ptr, ptr %t470
  store ptr %t471, ptr %l31, !tbaa !29
  br label %bb133
bb132:
  br label %bb170
bb133:
  store %olang.scope zeroinitializer, ptr %s22
  %t473 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t473, ptr %l272
  br label %bb134
bb134:
  %t474 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l272
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t474, ptr %l32
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l31, !tbaa !29
  %t477 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s22, ptr %t475, ptr %t476, ptr %t477, ptr %l32)
  br label %bb135
bb135:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/views:Viewer", ptr %t482, i32 0, i32 21
  %t485 = load i1, ptr %t484, !tbaa !21
  %t487 = xor i1 %t485, true
  br i1 %t487, label %bb136, label %bb137
bb136:
  store ptr %l32, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb138
bb137:
  br label %bb169
bb138:
  store %olang.scope zeroinitializer, ptr %s25
  %t490 = load ptr, ptr %l33, !tbaa !29
  %t491 = load i64, ptr %l34, !tbaa !24
  %t494 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s22, ptr %t490, i64 %t491)
  %t495 = extractvalue { i32, { i64, ptr } } %t494, 1
  %t496 = extractvalue { i32, { i64, ptr } } %t494, 0
  store i32 %t496, ptr %l285
  %t497 = icmp ne i32 %t496, 0
  br i1 %t497, label %bb140, label %ok.498
ok.498:
  store { i64, ptr } %t495, ptr %l284
  br label %bb139
bb139:
  %t499 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t499, ptr %l281, !tbaa !27
  br label %bb144
bb140:
  %t500 = load i32, ptr %l285, !tbaa !23
  %t501 = ashr i32 %t500, 16
  %t503 = icmp eq i32 %t501, 1
  br i1 %t503, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_e04c74c796b3ea6e_c4eff31c835dc20a)
  unreachable
bb143:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s25)
  br label %bb168
bb144:
  %t505 = load { i64, ptr }, ptr %l281, !tbaa !27
  store { i64, ptr } %t505, ptr %l35, !tbaa !27
  %t506 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t506, 0
  store i64 %t508, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb145
bb145:
  store %olang.scope zeroinitializer, ptr %s26
  %t510 = load i64, ptr %l37, !tbaa !24
  %t511 = load i64, ptr %l36, !tbaa !24
  %t514 = icmp slt i64 %t510, %t511
  %t516 = xor i1 %t514, true
  br i1 %t516, label %bb146, label %bb147
bb146:
  call void @__olang_scope_close(ptr %s26)
  br label %bb166
bb147:
  br label %bb148
bb148:
  %t518 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t518, ptr %l294, !tbaa !27
  %t519 = load i64, ptr %l37, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr %"compiler/views:view", ptr %t522, i64 %t519
  %t524 = load %"compiler/views:view", ptr %t523
  store %"compiler/views:view" %t524, ptr %l38
  %t526 = getelementptr %"compiler/views:view", ptr %l38, i32 0, i32 0
  %t527 = getelementptr %"compiler/views:place", ptr %t526, i32 0, i32 0
  %t528 = load { i64, [2 x i64] }, ptr %t527
  store { i64, [2 x i64] } %t528, ptr %l39
  %t530 = load { i64, [2 x i64] }, ptr %l39
  %t532 = extractvalue { i64, [2 x i64] } %t530, 0
  %t533 = icmp eq i64 %t532, 2
  br i1 %t533, label %bb149, label %bb150
bb149:
  %t535 = getelementptr { i64, [2 x i64] }, ptr %l39, i32 0, i32 1
  %t536 = getelementptr { i64 }, ptr %t535, i32 0, i32 0
  %t537 = load i64, ptr %t536
  store i64 %t537, ptr %l40, !tbaa !24
  br label %bb151
bb150:
  br label %bb154
bb151:
  %t539 = load ptr, ptr %l0, !tbaa !29
  store ptr %t539, ptr %l301, !tbaa !29
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/views:Viewer", ptr %t540, i32 0, i32 2
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/views:Viewer", ptr %t543, i32 0, i32 20
  %t546 = load i64, ptr %t545, !tbaa !24
  %t549 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t542, i64 %t546)
  store ptr %t549, ptr %l306
  br label %bb152
bb152:
  %t550 = load ptr, ptr %l306, !tbaa !29
  %t552 = getelementptr %"compiler/views:summary", ptr %t550, i32 0, i32 1
  %t553 = load i64, ptr %l40, !tbaa !24
  %t554 = getelementptr %"compiler/views:view", ptr %l38, i32 0, i32 0
  %t555 = load %"compiler/views:place", ptr %t554
  %t556 = load %"compiler/source:Span", ptr %l30
  %t557 = load ptr, ptr %l301, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t557, ptr %t552, i64 %t553, i64 -1, i32 0, %"compiler/views:place" %t555, %"compiler/source:Span" %t556)
  br label %bb153
bb153:
  br label %bb164
bb154:
  %t562 = load { i64, [2 x i64] }, ptr %l39
  %t564 = extractvalue { i64, [2 x i64] } %t562, 0
  %t565 = icmp eq i64 %t564, 4
  br i1 %t565, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load %"compiler/views:view", ptr %l38
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t567, %"compiler/views:view" %t568)
  br label %bb158
bb158:
  br label %bb164
bb159:
  br i1 true, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb164
bb163:
  call void @__olang_check_failed(ptr @olang_loc_55fe9ec66bf58b2f_2b15eb81744064b)
  unreachable
bb164:
  call void @__olang_scope_close(ptr %s26)
  br label %bb165
bb165:
  %t571 = load i64, ptr %l37, !tbaa !24
  %t573 = add i64 %t571, 1
  store i64 %t573, ptr %l37, !tbaa !24
  br label %bb145
bb166:
  %t575 = load i64, ptr %l34, !tbaa !24
  %t576 = load i64, ptr %l36, !tbaa !24
  %t579 = add i64 %t575, %t576
  store i64 %t579, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb167
bb167:
  br label %bb138
bb168:
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s22)
  br label %bb247
bb170:
  %t581 = load ptr, ptr %l1, !tbaa !29
  store ptr %t581, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t582 = load ptr, ptr %l321, !tbaa !29
  %t583 = icmp ne ptr %t582, null
  br i1 %t583, label %bb171, label %bb172
bb171:
  %t585 = load ptr, ptr %l321, !tbaa !29
  %t586 = load i64, ptr %t585
  %t588 = icmp eq i64 %t586, 7
  store i1 %t588, ptr %l322, !tbaa !21
  br label %bb172
bb172:
  %t589 = load i1, ptr %l322, !tbaa !21
  br i1 %t589, label %bb173, label %bb174
bb173:
  br label %bb179
bb174:
  %t590 = load ptr, ptr %l1, !tbaa !29
  store ptr %t590, ptr %l325, !tbaa !29
  store i1 false, ptr %l326, !tbaa !21
  %t591 = load ptr, ptr %l325, !tbaa !29
  %t592 = icmp ne ptr %t591, null
  br i1 %t592, label %bb175, label %bb176
bb175:
  %t594 = load ptr, ptr %l325, !tbaa !29
  %t595 = load i64, ptr %t594
  %t597 = icmp eq i64 %t595, 8
  store i1 %t597, ptr %l326, !tbaa !21
  br label %bb176
bb176:
  %t598 = load i1, ptr %l326, !tbaa !21
  br i1 %t598, label %bb177, label %bb178
bb177:
  br label %bb179
bb178:
  br label %bb180
bb179:
  %t599 = load ptr, ptr %l2, !tbaa !29
  %t601 = getelementptr %"compiler/views:state", ptr %t599, i32 0, i32 0
  store i1 true, ptr %t601, !tbaa !21
  br label %bb247
bb180:
  %t602 = load ptr, ptr %l1, !tbaa !29
  store ptr %t602, ptr %l330, !tbaa !29
  store i1 false, ptr %l331, !tbaa !21
  %t603 = load ptr, ptr %l330, !tbaa !29
  %t604 = icmp ne ptr %t603, null
  br i1 %t604, label %bb181, label %bb182
bb181:
  %t606 = load ptr, ptr %l330, !tbaa !29
  %t607 = load i64, ptr %t606
  %t609 = icmp eq i64 %t607, 9
  store i1 %t609, ptr %l331, !tbaa !21
  br label %bb182
bb182:
  %t610 = load i1, ptr %l331, !tbaa !21
  br i1 %t610, label %bb183, label %bb184
bb183:
  %t611 = load ptr, ptr %l1, !tbaa !29
  %t613 = getelementptr { i64, [3 x i64] }, ptr %t611, i32 0, i32 1
  %t614 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t613, i32 0, i32 2
  %t615 = load ptr, ptr %t614
  store ptr %t615, ptr %l41, !tbaa !29
  br label %bb185
bb184:
  br label %bb190
bb185:
  %t617 = load ptr, ptr %l41, !tbaa !29
  %t619 = icmp eq ptr %t617, null
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb186, label %bb187
bb186:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load ptr, ptr %l41, !tbaa !29
  %t626 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t623, ptr %t624, ptr %t626, ptr %l3)
  br label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb189
bb189:
  %t631 = load ptr, ptr %l2, !tbaa !29
  %t633 = getelementptr %"compiler/views:state", ptr %t631, i32 0, i32 0
  store i1 true, ptr %t633, !tbaa !21
  br label %bb247
bb190:
  %t634 = load ptr, ptr %l1, !tbaa !29
  store ptr %t634, ptr %l345, !tbaa !29
  store i1 false, ptr %l346, !tbaa !21
  %t635 = load ptr, ptr %l345, !tbaa !29
  %t636 = icmp ne ptr %t635, null
  br i1 %t636, label %bb191, label %bb192
bb191:
  %t638 = load ptr, ptr %l345, !tbaa !29
  %t639 = load i64, ptr %t638
  %t641 = icmp eq i64 %t639, 10
  store i1 %t641, ptr %l346, !tbaa !21
  br label %bb192
bb192:
  %t642 = load i1, ptr %l346, !tbaa !21
  br i1 %t642, label %bb193, label %bb194
bb193:
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [3 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t645, i32 0, i32 1
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l42, !tbaa !29
  %t649 = load ptr, ptr %l1, !tbaa !29
  %t651 = getelementptr { i64, [3 x i64] }, ptr %t649, i32 0, i32 1
  %t652 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t651, i32 0, i32 2
  %t653 = load ptr, ptr %t652
  store ptr %t653, ptr %l43, !tbaa !29
  br label %bb195
bb194:
  br label %bb202
bb195:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = load ptr, ptr %l42, !tbaa !29
  %t658 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t655, ptr %t656, ptr %t658, ptr %l3)
  br label %bb196
bb196:
  %t663 = load ptr, ptr %l43, !tbaa !29
  %t665 = icmp eq ptr %t663, null
  %t667 = xor i1 %t665, true
  br i1 %t667, label %bb197, label %bb198
bb197:
  store %olang.scope zeroinitializer, ptr %s35
  %t669 = load ptr, ptr %l2, !tbaa !29
  %t671 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s35, ptr %t669)
  store %"compiler/views:state" %t671, ptr %l362
  br label %bb199
bb198:
  br label %bb201
bb199:
  %t672 = load %"compiler/views:state", ptr %l362
  store %"compiler/views:state" %t672, ptr %l44
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s35, ptr %s0, ptr %t673, ptr %t674, ptr %l44, ptr %l3)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s35)
  br label %bb201
bb201:
  br label %bb247
bb202:
  %t680 = load ptr, ptr %l1, !tbaa !29
  store ptr %t680, ptr %l368, !tbaa !29
  store i1 false, ptr %l369, !tbaa !21
  %t681 = load ptr, ptr %l368, !tbaa !29
  %t682 = icmp ne ptr %t681, null
  br i1 %t682, label %bb203, label %bb204
bb203:
  %t684 = load ptr, ptr %l368, !tbaa !29
  %t685 = load i64, ptr %t684
  %t687 = icmp eq i64 %t685, 11
  store i1 %t687, ptr %l369, !tbaa !21
  br label %bb204
bb204:
  %t688 = load i1, ptr %l369, !tbaa !21
  br i1 %t688, label %bb205, label %bb206
bb205:
  %t689 = load ptr, ptr %l1, !tbaa !29
  %t691 = getelementptr { i64, [3 x i64] }, ptr %t689, i32 0, i32 1
  %t692 = getelementptr { %"compiler/source:Span", ptr }, ptr %t691, i32 0, i32 1
  %t693 = load ptr, ptr %t692
  store ptr %t693, ptr %l45, !tbaa !29
  br label %bb207
bb206:
  br label %bb209
bb207:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load ptr, ptr %l45, !tbaa !29
  %t698 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t695, ptr %t696, ptr %t698)
  br label %bb208
bb208:
  br label %bb247
bb209:
  %t702 = load ptr, ptr %l1, !tbaa !29
  store ptr %t702, ptr %l378, !tbaa !29
  store i1 false, ptr %l379, !tbaa !21
  %t703 = load ptr, ptr %l378, !tbaa !29
  %t704 = icmp ne ptr %t703, null
  br i1 %t704, label %bb210, label %bb211
bb210:
  %t706 = load ptr, ptr %l378, !tbaa !29
  %t707 = load i64, ptr %t706
  %t709 = icmp eq i64 %t707, 12
  store i1 %t709, ptr %l379, !tbaa !21
  br label %bb211
bb211:
  %t710 = load i1, ptr %l379, !tbaa !21
  br i1 %t710, label %bb212, label %bb213
bb212:
  br label %bb214
bb213:
  br label %bb215
bb214:
  br label %bb247
bb215:
  %t711 = load ptr, ptr %l1, !tbaa !29
  store ptr %t711, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t712 = load ptr, ptr %l382, !tbaa !29
  %t713 = icmp ne ptr %t712, null
  br i1 %t713, label %bb216, label %bb217
bb216:
  %t715 = load ptr, ptr %l382, !tbaa !29
  %t716 = load i64, ptr %t715
  %t718 = icmp eq i64 %t716, 13
  store i1 %t718, ptr %l383, !tbaa !21
  br label %bb217
bb217:
  %t719 = load i1, ptr %l383, !tbaa !21
  br i1 %t719, label %bb218, label %bb219
bb218:
  %t720 = load ptr, ptr %l1, !tbaa !29
  %t722 = getelementptr { i64, [3 x i64] }, ptr %t720, i32 0, i32 1
  %t723 = getelementptr { %"compiler/source:Span", ptr }, ptr %t722, i32 0, i32 1
  %t724 = load ptr, ptr %t723
  store ptr %t724, ptr %l46, !tbaa !29
  br label %bb220
bb219:
  br label %bb232
bb220:
  %t726 = load ptr, ptr %l2, !tbaa !29
  %t728 = getelementptr %"compiler/views:state", ptr %t726, i32 0, i32 4
  %t730 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t728)
  store i64 %t730, ptr %l390
  br label %bb221
bb221:
  %t731 = load i64, ptr %l390, !tbaa !24
  store i64 %t731, ptr %l47, !tbaa !24
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t733 = load ptr, ptr %l46, !tbaa !29
  %t735 = getelementptr %"compiler/typed:Join", ptr %t733, i32 0, i32 0
  %t736 = load ptr, ptr %t735, !tbaa !29
  %t738 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t732, ptr %t736, ptr %t738)
  br label %bb222
bb222:
  %t742 = load ptr, ptr %l2, !tbaa !29
  %t744 = getelementptr %"compiler/views:state", ptr %t742, i32 0, i32 0
  %t745 = load i1, ptr %t744, !tbaa !21
  %t747 = xor i1 %t745, true
  br i1 %t747, label %bb223, label %bb224
bb223:
  %t749 = load ptr, ptr %l2, !tbaa !29
  %t751 = getelementptr %"compiler/views:state", ptr %t749, i32 0, i32 4
  %t753 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t751)
  store i64 %t753, ptr %l402
  br label %bb225
bb224:
  store i1 false, ptr %l399, !tbaa !21
  br label %bb226
bb225:
  %t754 = load i64, ptr %l47, !tbaa !24
  %t755 = load i64, ptr %l402, !tbaa !24
  %t757 = icmp sgt i64 %t755, %t754
  store i1 %t757, ptr %l399, !tbaa !21
  br label %bb226
bb226:
  %t759 = load i1, ptr %l399, !tbaa !21
  br i1 %t759, label %bb227, label %bb228
bb227:
  %t760 = load ptr, ptr %l2, !tbaa !29
  %t762 = getelementptr %"compiler/views:state", ptr %t760, i32 0, i32 4
  %t763 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eTrun_Hcf69da14cf76298bedfa6131a657bae8(ptr %v2, ptr %t762, i64 %t763)
  br label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb230
bb230:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load ptr, ptr %l46, !tbaa !29
  %t769 = getelementptr %"compiler/typed:Join", ptr %t767, i32 0, i32 2
  %t770 = load { i64, ptr }, ptr %t769, !tbaa !27
  %t771 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t766, { i64, ptr } %t770, ptr %t771, ptr %l3)
  br label %bb231
bb231:
  br label %bb247
bb232:
  %t776 = load ptr, ptr %l1, !tbaa !29
  store ptr %t776, ptr %l413, !tbaa !29
  store i1 false, ptr %l414, !tbaa !21
  %t777 = load ptr, ptr %l413, !tbaa !29
  %t778 = icmp ne ptr %t777, null
  br i1 %t778, label %bb233, label %bb234
bb233:
  %t780 = load ptr, ptr %l413, !tbaa !29
  %t781 = load i64, ptr %t780
  %t783 = icmp eq i64 %t781, 14
  store i1 %t783, ptr %l414, !tbaa !21
  br label %bb234
bb234:
  %t784 = load i1, ptr %l414, !tbaa !21
  br i1 %t784, label %bb235, label %bb236
bb235:
  %t785 = load ptr, ptr %l1, !tbaa !29
  %t787 = getelementptr { i64, [3 x i64] }, ptr %t785, i32 0, i32 1
  %t788 = getelementptr { %"compiler/source:Span", ptr }, ptr %t787, i32 0, i32 0
  %t789 = load %"compiler/source:Span", ptr %t788
  store %"compiler/source:Span" %t789, ptr %l48
  %t791 = load ptr, ptr %l1, !tbaa !29
  %t793 = getelementptr { i64, [3 x i64] }, ptr %t791, i32 0, i32 1
  %t794 = getelementptr { %"compiler/source:Span", ptr }, ptr %t793, i32 0, i32 1
  %t795 = load ptr, ptr %t794
  store ptr %t795, ptr %l49, !tbaa !29
  br label %bb237
bb236:
  br label %bb239
bb237:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load %"compiler/source:Span", ptr %l48
  %t799 = load ptr, ptr %l49, !tbaa !29
  %t800 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %t797, %"compiler/source:Span" %t798, ptr %t799, ptr %t800)
  br label %bb238
bb238:
  br label %bb247
bb239:
  %t805 = load ptr, ptr %l1, !tbaa !29
  store ptr %t805, ptr %l425, !tbaa !29
  store i1 false, ptr %l426, !tbaa !21
  %t806 = load ptr, ptr %l425, !tbaa !29
  %t807 = icmp ne ptr %t806, null
  br i1 %t807, label %bb240, label %bb241
bb240:
  %t809 = load ptr, ptr %l425, !tbaa !29
  %t810 = load i64, ptr %t809
  %t812 = icmp eq i64 %t810, 15
  store i1 %t812, ptr %l426, !tbaa !21
  br label %bb241
bb241:
  %t813 = load i1, ptr %l426, !tbaa !21
  br i1 %t813, label %bb242, label %bb243
bb242:
  %t814 = load ptr, ptr %l1, !tbaa !29
  %t816 = getelementptr { i64, [3 x i64] }, ptr %t814, i32 0, i32 1
  %t817 = getelementptr { %"compiler/source:Span", ptr }, ptr %t816, i32 0, i32 1
  %t818 = load ptr, ptr %t817
  store ptr %t818, ptr %l50, !tbaa !29
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t821 = load ptr, ptr %l50, !tbaa !29
  %t823 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t820, ptr %t821, ptr %t823, ptr %l3)
  br label %bb245
bb245:
  br label %bb247
bb246:
  call void @__olang_check_failed(ptr @olang_loc_b3ceb71449c904f8_7e3a160ac7181fac)
  unreachable
bb247:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/views:holding"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/views:place"
  %l19 = alloca %"compiler/views:view"
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l59 = alloca %"compiler/views:holding"
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l74 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, [2 x i64] }
  %l82 = alloca { i64, [2 x i64] }
  %l84 = alloca i1
  %l85 = alloca i1
  %l89 = alloca i1
  %l95 = alloca %"compiler/views:place"
  %l97 = alloca ptr
  %l98 = alloca i64
  %l101 = alloca %"compiler/views:holding"
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l116 = alloca i32
  %l121 = alloca ptr
  %l122 = alloca i1
  %l128 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t148 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l23
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t9, ptr %t10, ptr %t12, ptr %l5)
  br label %bb3
bb3:
  store i64 0, ptr %l6, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/views:state", ptr %t17, i32 0, i32 1
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t19)
  store i64 %t21, ptr %l31
  br label %bb4
bb4:
  %t22 = load i64, ptr %l31, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb10
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l38, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l38, !tbaa !24
  store i64 %t49, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l35, !tbaa !24
  store i64 %t50, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb13:
  br label %bb14
bb14:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l11, !tbaa !24
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/views:state", ptr %t69, i32 0, i32 1
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t71, i64 %t72)
  store %"compiler/views:holding" %t75, ptr %l59
  br label %bb15
bb15:
  %t76 = load %"compiler/views:holding", ptr %l59
  store %"compiler/views:holding" %t76, ptr %l12
  store ptr %l5, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load ptr, ptr %l13, !tbaa !29
  %t79 = load i64, ptr %l14, !tbaa !24
  %t82 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, { i64, ptr } } %t82, 1
  %t84 = extractvalue { i32, { i64, ptr } } %t82, 0
  store i32 %t84, ptr %l65
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb18, label %ok.86
ok.86:
  store { i64, ptr } %t83, ptr %l64
  br label %bb17
bb17:
  %t87 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t87, ptr %l61, !tbaa !27
  br label %bb22
bb18:
  %t88 = load i32, ptr %l65, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  br i1 %t91, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_551fdf32d31d54b_8fb5917c27ba1e87)
  unreachable
bb21:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb22:
  %t93 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t93, ptr %l15, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l17, !tbaa !24
  %t99 = load i64, ptr %l16, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb25:
  br label %bb26
bb26:
  %t106 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t106, ptr %l74, !tbaa !27
  %t107 = load i64, ptr %l17, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/views:place", ptr %t110, i64 %t107
  %t112 = load %"compiler/views:place", ptr %t111
  store %"compiler/views:place" %t112, ptr %l18
  %t114 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t115 = getelementptr %"compiler/views:view", ptr %t114, i32 0, i32 0
  %t116 = getelementptr %"compiler/views:place", ptr %t115, i32 0, i32 0
  %t117 = load { i64, [2 x i64] }, ptr %t116
  %t119 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t117)
  store i1 %t119, ptr %l78
  br label %bb27
bb27:
  %t120 = load i1, ptr %l78, !tbaa !21
  br i1 %t120, label %bb28, label %bb29
bb28:
  %t121 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t122 = getelementptr %"compiler/views:view", ptr %t121, i32 0, i32 0
  %t123 = getelementptr %"compiler/views:place", ptr %t122, i32 0, i32 0
  %t124 = load { i64, [2 x i64] }, ptr %t123
  store { i64, [2 x i64] } %t124, ptr %l80
  %t125 = getelementptr %"compiler/views:place", ptr %l18, i32 0, i32 0
  %t126 = load { i64, [2 x i64] }, ptr %t125
  store { i64, [2 x i64] } %t126, ptr %l82
  %t129 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l80, ptr %l82)
  store i1 %t129, ptr %l84
  br label %bb30
bb29:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb31
bb30:
  %t130 = load i1, ptr %l84, !tbaa !21
  store i1 %t130, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t131 = load i1, ptr %l79, !tbaa !21
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/views:place", ptr %l18, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t136 = getelementptr %"compiler/views:view", ptr %t135, i32 0, i32 0
  %t137 = getelementptr %"compiler/views:place", ptr %t136, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t142 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t132, i64 %t134, i64 %t138)
  store i1 %t142, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb35
bb34:
  %t143 = load i1, ptr %l89, !tbaa !21
  store i1 %t143, ptr %l85, !tbaa !21
  br label %bb35
bb35:
  %t144 = load i1, ptr %l85, !tbaa !21
  br i1 %t144, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t146 = load %"compiler/views:view", ptr %t145
  store %"compiler/views:view" %t146, ptr %l19
  store { i64, [2 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [2 x i64] }, ptr %t148, i32 0, i32 0
  store i64 0, ptr %t149
  %t150 = load { i64, [2 x i64] }, ptr %t148
  %t151 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t152 = getelementptr %"compiler/views:place", ptr %t151, i32 0, i32 1
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t155 = getelementptr %"compiler/views:place", ptr %t154, i32 0, i32 2
  %t156 = load i64, ptr %t155, !tbaa !24
  %t157 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t158 = getelementptr %"compiler/views:place", ptr %t157, i32 0, i32 3
  %t159 = load i1, ptr %t158, !tbaa !21
  %t164 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s6, { i64, [2 x i64] } %t150, i64 %t153, i64 %t156, i1 %t159)
  store %"compiler/views:place" %t164, ptr %l95
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t165 = load %"compiler/views:place", ptr %l95
  %t166 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  store %"compiler/views:place" %t165, ptr %t166
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = getelementptr %"compiler/views:state", ptr %t167, i32 0, i32 1
  store ptr %t169, ptr %l97, !tbaa !29
  %t170 = load i64, ptr %l11, !tbaa !24
  store i64 %t170, ptr %l98, !tbaa !24
  %t171 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 0
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = load %"compiler/views:view", ptr %l19
  %t176 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s6, i64 %t172, %"compiler/views:view" %t173)
  store %"compiler/views:holding" %t176, ptr %l101
  br label %bb39
bb39:
  %t177 = load ptr, ptr %l97, !tbaa !29
  %t178 = load i64, ptr %l98, !tbaa !24
  %t179 = load %"compiler/views:holding", ptr %l101
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v3, ptr %t177, i64 %t178, %"compiler/views:holding" %t179)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb23
bb43:
  %t184 = load i64, ptr %l14, !tbaa !24
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = add i64 %t184, %t185
  store i64 %t188, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %bb16
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb46:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l10, !tbaa !24
  br label %bb11
bb47:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb48, label %bb49
bb48:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l112, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l114, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t203)
  store i32 %t205, ptr %l116
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load ptr, ptr %l114, !tbaa !29
  %t210 = load i32, ptr %l116, !tbaa !23
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t208, ptr %t209, i32 %t210, ptr %t206, ptr %t207)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t213 = load i64, ptr %l4, !tbaa !24
  %t215 = icmp slt i64 %t213, 0
  br i1 %t215, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  br label %bb55
bb55:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t218 = load ptr, ptr %l121, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb56, label %bb57
bb56:
  %t221 = load ptr, ptr %l121, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 3
  store i1 %t224, ptr %l122, !tbaa !21
  br label %bb57
bb57:
  %t225 = load i1, ptr %l122, !tbaa !21
  br i1 %t225, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb66
bb60:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load ptr, ptr %l3, !tbaa !29
  %t228 = load i64, ptr %l4, !tbaa !24
  %t232 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v3, ptr %t226, ptr %t227, i64 %t228)
  store i1 %t232, ptr %l128
  br label %bb61
bb61:
  %t233 = load i1, ptr %l128, !tbaa !21
  br i1 %t233, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l3, !tbaa !29
  %t235 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v3, ptr %t234, i64 %t235)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_c7909257994b910a_5e298e5e7805bf26)
  unreachable
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/views:Viewer", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t36)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/views:Viewer", ptr %t39, i32 0, i32 4
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l21, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/views:Viewer", ptr %t56, i32 0, i32 3
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load ptr, ptr %l18, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64, i64 %t62)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:Viewer", ptr %t66, i32 0, i32 3
  %t70 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l28
  br label %bb11
bb11:
  %t71 = load i64, ptr %l28, !tbaa !24
  %t72 = sub i64 %t71, 1
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i1
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i32, ptr %l10
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/views:Viewer", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l16, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:Viewer", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb5:
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = load i32, ptr %l21, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l22
  br label %bb6
bb6:
  %t41 = load i32, ptr %l22
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i1, ptr %l13, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t24)
  store %"compiler/source:Span" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t29, ptr %l7
  br label %bb38
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb16
bb11:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceTok(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/source:Span" %t64, ptr %l34
  br label %bb17
bb17:
  %t65 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t65, ptr %l7
  br label %bb38
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 5
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l36, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Promote", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  store %"compiler/source:Span" %t88, ptr %l44
  br label %bb24
bb24:
  %t89 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t89, ptr %l7
  br label %bb38
bb25:
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i64, ptr %t94
  %t97 = icmp eq i64 %t95, 17
  store i1 %t97, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l6, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t105, ptr %t106)
  store %"compiler/source:Span" %t109, ptr %l53
  br label %bb31
bb31:
  %t110 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t110, ptr %l7
  br label %bb38
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t111)
  store %"compiler/source:Span" %t113, ptr %l55
  br label %bb36
bb36:
  %t114 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t114, ptr %l7
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a630935aa2e7253f_7098fd3403d75c2b)
  unreachable
bb38:
  %t115 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2euse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/msgs:Msg"
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca { i64, ptr }
  %l46 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l70 = alloca i1
  %l76 = alloca i1
  %l79 = alloca { i64, ptr }
  %l88 = alloca %"compiler/typed:Local"
  %l92 = alloca %"compiler/msgs:Msg"
  %l95 = alloca %"compiler/msgs:Msg"
  %l98 = alloca { i64, ptr }
  %l101 = alloca %"compiler/msgs:Msg"
  %l105 = alloca ptr
  %l108 = alloca { i64, [3 x i64] }
  %l110 = alloca i64
  %l114 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l119 = alloca i64
  %l122 = alloca { i64, [3 x i64] }
  %l126 = alloca %"compiler/msgs:Msg"
  %l129 = alloca i1
  %l133 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l147 = alloca %"compiler/msgs:Msg"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t294 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 21
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 22
  %t11 = load i1, ptr %t10, !tbaa !21
  store i1 %t11, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 23
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = getelementptr %"compiler/views:state", ptr %a3, i32 0, i32 1
  store ptr %t22, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l31
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb12, label %ok.32
ok.32:
  store { i64, ptr } %t29, ptr %l30
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  br label %bb16
bb12:
  %t34 = load i32, ptr %l31, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c9aa123fef6d1a3f_2cfdc9fada63f9db)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb16:
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb19:
  br label %bb20
bb20:
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l40, !tbaa !27
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr %"compiler/views:holding", ptr %t56, i64 %t53
  %t58 = load %"compiler/views:holding", ptr %t57
  store %"compiler/views:holding" %t58, ptr %l9
  %t60 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = icmp ne i64 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  %t67 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t68 = getelementptr %"compiler/views:view", ptr %t67, i32 0, i32 2
  %t69 = load i1, ptr %t68, !tbaa !21
  %t71 = xor i1 %t69, true
  store i1 %t71, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l46, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb27
bb25:
  %t74 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t75 = getelementptr %"compiler/views:view", ptr %t74, i32 0, i32 0
  %t76 = getelementptr %"compiler/views:place", ptr %t75, i32 0, i32 0
  %t77 = load { i64, [2 x i64] }, ptr %t76
  %t79 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t77)
  store i1 %t79, ptr %l51
  br label %bb26
bb26:
  %t80 = load i1, ptr %l51, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l49, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb69
bb29:
  br label %bb30
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/views:Viewer", ptr %t84, i32 0, i32 19
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  br i1 %t89, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fbef590508ae9827_444bd78203178143)
  unreachable
bb32:
  br label %bb33
bb33:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/views:Viewer", ptr %t91, i32 0, i32 19
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 3
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = shl i64 %t98, 40
  %t101 = load i64, ptr %l1, !tbaa !24
  %t103 = shl i64 %t101, 24
  %t106 = or i64 %t100, %t103
  %t107 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t108 = getelementptr %"compiler/views:view", ptr %t107, i32 0, i32 3
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t115 = or i64 %t106, %t112
  store i64 %t115, ptr %l10, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/views:Viewer", ptr %t117, i32 0, i32 29
  %t120 = load i64, ptr %l10, !tbaa !24
  %t123 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t119, i64 %t120)
  store i1 %t123, ptr %l70
  br label %bb34
bb34:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb36:
  br label %bb37
bb37:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/views:Viewer", ptr %t125, i32 0, i32 29
  %t128 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t127, i64 %t128, i1 true)
  br label %bb38
bb38:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l2
  %t135 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t131, %"compiler/source:Span" %t132)
  store i1 %t135, ptr %l76
  br label %bb39
bb39:
  %t136 = load i1, ptr %l76, !tbaa !21
  br i1 %t136, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb41:
  br label %bb42
bb42:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t139 = getelementptr %"compiler/views:view", ptr %t138, i32 0, i32 0
  %t140 = load %"compiler/views:place", ptr %t139
  %t143 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s4, ptr %t137, %"compiler/views:place" %t140)
  store { i64, ptr } %t143, ptr %l79
  br label %bb43
bb43:
  %t144 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t144, ptr %l11, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/views:Viewer", ptr %t145, i32 0, i32 19
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  br i1 %t150, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_d673b6bd3b875b76_a50d9e4884ce91c2)
  unreachable
bb45:
  br label %bb46
bb46:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/views:Viewer", ptr %t152, i32 0, i32 19
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Body", ptr %t155, i32 0, i32 7
  %t159 = load i64, ptr %l1, !tbaa !24
  %t162 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t158, i64 %t159)
  store %"compiler/typed:Local" %t162, ptr %l88
  br label %bb47
bb47:
  %t163 = getelementptr %"compiler/typed:Local", ptr %l88, i32 0, i32 0
  %t164 = load i32, ptr %t163, !tbaa !23
  store i32 %t164, ptr %l12, !tbaa !23
  %t166 = load i32, ptr %l12, !tbaa !23
  %t168 = icmp eq i32 %t166, 0
  br i1 %t168, label %bb48, label %bb49
bb48:
  %t170 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t174 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t170, { i64, ptr } %t171)
  store %"compiler/msgs:Msg" %t174, ptr %l95
  br label %bb50
bb49:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l12, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l98
  br label %bb51
bb50:
  %t180 = load %"compiler/msgs:Msg", ptr %l95
  store %"compiler/msgs:Msg" %t180, ptr %l92
  br label %bb53
bb51:
  %t181 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t186 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t183, { i64, ptr } %t181, { i64, ptr } %t182)
  store %"compiler/msgs:Msg" %t186, ptr %l101
  br label %bb52
bb52:
  %t187 = load %"compiler/msgs:Msg", ptr %l101
  store %"compiler/msgs:Msg" %t187, ptr %l92
  br label %bb53
bb53:
  %t188 = load %"compiler/msgs:Msg", ptr %l92
  store %"compiler/msgs:Msg" %t188, ptr %l13
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/views:Viewer", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/load:Loader", ptr %t195, i32 0, i32 4
  %t198 = load ptr, ptr %t197, !tbaa !29
  store ptr %t198, ptr %l105, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l2
  %t203 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t199, %"compiler/source:Span" %t200)
  store { i64, [3 x i64] } %t203, ptr %l108
  br label %bb54
bb54:
  %t204 = load %"compiler/msgs:Msg", ptr %l13
  %t205 = load ptr, ptr %l105, !tbaa !29
  %t206 = load { i64, [3 x i64] }, ptr %l108
  %t208 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t205, { i64, [3 x i64] } %t206, %"compiler/msgs:Msg" %t204)
  store i64 %t208, ptr %l110
  br label %bb55
bb55:
  %t209 = load i64, ptr %l110, !tbaa !24
  store i64 %t209, ptr %l14, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/views:Viewer", ptr %t210, i32 0, i32 3
  %t213 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t214 = getelementptr %"compiler/views:view", ptr %t213, i32 0, i32 4
  %t215 = load i64, ptr %t214, !tbaa !24
  %t218 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t212, i64 %t215)
  store { i64, ptr } %t218, ptr %l114
  br label %bb56
bb56:
  %t219 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t219, ptr %l15, !tbaa !27
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/views:Viewer", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 0
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/load:Loader", ptr %t226, i32 0, i32 4
  %t229 = load ptr, ptr %t228, !tbaa !29
  store ptr %t229, ptr %l118, !tbaa !29
  %t230 = load i64, ptr %l14, !tbaa !24
  store i64 %t230, ptr %l119, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t233 = getelementptr %"compiler/views:view", ptr %t232, i32 0, i32 3
  %t234 = load %"compiler/source:Span", ptr %t233
  %t237 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t231, %"compiler/source:Span" %t234)
  store { i64, [3 x i64] } %t237, ptr %l122
  br label %bb57
bb57:
  %t238 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t244 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %s4, ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t238, { i64, ptr } %t239, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t244, ptr %l126
  br label %bb58
bb58:
  %t245 = load ptr, ptr %l118, !tbaa !29
  %t246 = load i64, ptr %l119, !tbaa !24
  %t247 = load { i64, [3 x i64] }, ptr %l122
  %t248 = load %"compiler/msgs:Msg", ptr %l126
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t245, i64 %t246, { i64, [3 x i64] } %t247, %"compiler/msgs:Msg" %t248)
  br label %bb59
bb59:
  %t249 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t250 = getelementptr %"compiler/views:view", ptr %t249, i32 0, i32 5
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = icmp sge i64 %t251, 0
  br i1 %t253, label %bb60, label %bb61
bb60:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/views:Viewer", ptr %t255, i32 0, i32 6
  %t258 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t259 = getelementptr %"compiler/views:view", ptr %t258, i32 0, i32 5
  %t260 = load i64, ptr %t259, !tbaa !24
  %t263 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t257, i64 %t260)
  store i1 %t263, ptr %l133
  br label %bb62
bb61:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb63
bb62:
  %t264 = load i1, ptr %l133, !tbaa !21
  %t265 = xor i1 %t264, true
  store i1 %t265, ptr %l129, !tbaa !21
  br label %bb63
bb63:
  %t267 = load i1, ptr %l129, !tbaa !21
  br i1 %t267, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/views:Viewer", ptr %t268, i32 0, i32 0
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/load:Loader", ptr %t274, i32 0, i32 4
  %t277 = load ptr, ptr %t276, !tbaa !29
  store ptr %t277, ptr %l138, !tbaa !29
  %t278 = load i64, ptr %l14, !tbaa !24
  store i64 %t278, ptr %l139, !tbaa !24
  %t279 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t280 = getelementptr %"compiler/views:view", ptr %t279, i32 0, i32 5
  %t281 = load i64, ptr %t280, !tbaa !24
  %t282 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t283 = getelementptr %"compiler/views:view", ptr %t282, i32 0, i32 6
  %t284 = getelementptr %"compiler/source:Span", ptr %t283, i32 0, i32 0
  %t285 = load i32, ptr %t284, !tbaa !23
  %t287 = sext i32 %t285 to i64
  %t288 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t289 = getelementptr %"compiler/views:view", ptr %t288, i32 0, i32 6
  %t290 = getelementptr %"compiler/source:Span", ptr %t289, i32 0, i32 1
  %t291 = load i32, ptr %t290, !tbaa !23
  %t293 = sext i32 %t291 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t294
  %t295 = getelementptr { i64, [3 x i64] }, ptr %t294, i32 0, i32 0
  store i64 3, ptr %t295
  %t297 = insertvalue { i64, i64, i64 } undef, i64 %t281, 0
  %t299 = insertvalue { i64, i64, i64 } %t297, i64 %t287, 1
  %t301 = insertvalue { i64, i64, i64 } %t299, i64 %t293, 2
  %t302 = getelementptr { i64, [3 x i64] }, ptr %t294, i32 0, i32 1
  store { i64, i64, i64 } %t301, ptr %t302
  %t303 = load { i64, [3 x i64] }, ptr %t294
  store { i64, [3 x i64] } %t303, ptr %l145
  %t304 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t306 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %s8, { i64, ptr } %t304)
  store %"compiler/msgs:Msg" %t306, ptr %l147
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t307 = load ptr, ptr %l138, !tbaa !29
  %t308 = load i64, ptr %l139, !tbaa !24
  %t309 = load { i64, [3 x i64] }, ptr %l145
  %t310 = load %"compiler/msgs:Msg", ptr %l147
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t307, i64 %t308, { i64, [3 x i64] } %t309, %"compiler/msgs:Msg" %t310)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb69:
  %t311 = load i64, ptr %l8, !tbaa !24
  %t313 = add i64 %t311, 1
  store i64 %t313, ptr %l8, !tbaa !24
  br label %bb17
bb70:
  %t315 = load i64, ptr %l5, !tbaa !24
  %t316 = load i64, ptr %l7, !tbaa !24
  %t319 = add i64 %t315, %t316
  store i64 %t319, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb71:
  br label %bb10
bb72:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eviewsHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca ptr
  %l57 = alloca i64
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i64
  %l97 = alloca i64
  %l99 = alloca i1
  %l103 = alloca ptr
  %l111 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l131 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l27, !tbaa !24
  store i64 %t33, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l24, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:Viewer", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l48
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 3
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 7
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = icmp eq i64 %t63, %t67
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb14:
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/views:Viewer", ptr %t72, i32 0, i32 10
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l57
  br label %bb16
bb16:
  %t79 = load i64, ptr %l57, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/views:Viewer", ptr %t80, i32 0, i32 10
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t82, i64 %t85)
  store i64 %t88, ptr %l62
  br label %bb17
bb17:
  %t89 = load i64, ptr %l62, !tbaa !24
  store i64 %t89, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb23
bb20:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l69, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l69, !tbaa !24
  store i64 %t116, ptr %l66, !tbaa !24
  br label %bb23
bb23:
  %t117 = load i64, ptr %l66, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load i64, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb26:
  br label %bb27
bb27:
  %t126 = load i64, ptr %l7, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/views:Viewer", ptr %t136, i32 0, i32 11
  %t142 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t138, i64 %t134)
  store i64 %t142, ptr %l90
  br label %bb28
bb28:
  %t143 = load i64, ptr %l90, !tbaa !24
  store i64 %t143, ptr %l13, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp slt i64 %t144, 0
  br i1 %t146, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb32
bb30:
  %t148 = load i64, ptr %l13, !tbaa !24
  store i64 %t148, ptr %l94, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/views:Viewer", ptr %t149, i32 0, i32 1
  %t153 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t151)
  store i64 %t153, ptr %l97
  br label %bb31
bb31:
  %t154 = load i64, ptr %l94, !tbaa !24
  %t155 = load i64, ptr %l97, !tbaa !24
  %t156 = icmp sge i64 %t154, %t155
  store i1 %t156, ptr %l93, !tbaa !21
  br label %bb32
bb32:
  %t158 = load i1, ptr %l93, !tbaa !21
  br i1 %t158, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb36
bb34:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/views:Viewer", ptr %t159, i32 0, i32 1
  %t162 = load i64, ptr %l13, !tbaa !24
  %t165 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t161, i64 %t162)
  store ptr %t165, ptr %l103
  br label %bb35
bb35:
  %t166 = load ptr, ptr %l103, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Body", ptr %t166, i32 0, i32 3
  %t169 = load i64, ptr %t168, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/views:Viewer", ptr %t170, i32 0, i32 7
  %t173 = load i64, ptr %t172, !tbaa !24
  %t176 = icmp ne i64 %t169, %t173
  store i1 %t176, ptr %l99, !tbaa !21
  br label %bb36
bb36:
  %t178 = load i1, ptr %l99, !tbaa !21
  br i1 %t178, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb38:
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/views:Viewer", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  store ptr %t184, ptr %l111, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 1
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l115
  br label %bb40
bb40:
  %t192 = load ptr, ptr %l115, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Body", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s7, ptr %t196, i32 %t195)
  store { i64, ptr } %t198, ptr %l118
  br label %bb41
bb41:
  %t199 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  %t202 = mul i64 %t200, 4
  %t203 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  store { i64, ptr } %t205, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  store i64 %t209, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t215 = icmp slt i64 %t211, %t212
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb44:
  br label %bb45
bb45:
  %t219 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t219, ptr %l126, !tbaa !27
  %t220 = load i64, ptr %l15, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 %t220
  %t225 = load i32, ptr %t224, !tbaa !33
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t231 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %t227, i32 %t225)
  store i1 %t231, ptr %l131
  br label %bb46
bb46:
  %t232 = load i1, ptr %l131, !tbaa !21
  br i1 %t232, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t234 = load i64, ptr %l15, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l15, !tbaa !24
  br label %bb42
bb51:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  %t238 = load i64, ptr %l11, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l11, !tbaa !24
  br label %bb24
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  %t242 = load i64, ptr %l5, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l5, !tbaa !24
  br label %bb8
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l20 = alloca ptr
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca i64
  %l117 = alloca i64
  %l123 = alloca i64
  %l127 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/views:Viewer", ptr %t5, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 %t8)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:Viewer", ptr %t12, i32 0, i32 13
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/views:Viewer", ptr %t16, i32 0, i32 16
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t15, i64 %t19)
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l20, !tbaa !29
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = getelementptr %"compiler/views:Viewer", ptr %t24, i32 0, i32 16
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = add i64 %t26, 1
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/views:Viewer", ptr %t30, i32 0, i32 16
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:Viewer", ptr %t32, i32 0, i32 15
  %t35 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/views:Viewer", ptr %t38, i32 0, i32 14
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41, i1 true)
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/views:Viewer", ptr %t44, i32 0, i32 10
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb5
bb5:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 10
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = add i64 %t55, 1
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb6
bb6:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb7, label %bb8
bb7:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb15:
  br label %bb16
bb16:
  %t98 = load i64, ptr %l2, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/views:Viewer", ptr %t108, i32 0, i32 11
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t106)
  store i64 %t114, ptr %l65
  br label %bb17
bb17:
  %t115 = load i64, ptr %l65, !tbaa !24
  store i64 %t115, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb21
bb19:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/views:Viewer", ptr %t121, i32 0, i32 12
  %t125 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l72
  br label %bb20
bb20:
  %t126 = load i64, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l72, !tbaa !24
  %t128 = icmp sge i64 %t126, %t127
  store i1 %t128, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l68, !tbaa !21
  br i1 %t130, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/views:Viewer", ptr %t131, i32 0, i32 12
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l77
  br label %bb25
bb25:
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = icmp slt i64 %t138, 0
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %t141, i64 %t142)
  br label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/views:Viewer", ptr %t145, i32 0, i32 14
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t147, i64 %t148)
  store i1 %t151, ptr %l100
  br label %bb36
bb28:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/views:Viewer", ptr %t152, i32 0, i32 13
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l84
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/views:Viewer", ptr %t159, i32 0, i32 13
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l88
  br label %bb30
bb30:
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  br i1 %t168, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/views:Viewer", ptr %t170, i32 0, i32 13
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load i64, ptr %l1, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/views:Viewer", ptr %t174, i32 0, i32 13
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  store i64 %t180, ptr %l96
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t181 = load ptr, ptr %l91, !tbaa !29
  %t182 = load i64, ptr %l92, !tbaa !24
  %t183 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182, i64 %t183)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 12
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l105
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/views:Viewer", ptr %t192, i32 0, i32 13
  %t195 = load i64, ptr %l1, !tbaa !24
  %t198 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l109
  br label %bb40
bb40:
  %t199 = load i64, ptr %l105, !tbaa !24
  %t200 = load i64, ptr %l109, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  store i1 %t201, ptr %l101, !tbaa !21
  br label %bb41
bb41:
  %t203 = load i1, ptr %l101, !tbaa !21
  br i1 %t203, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/views:Viewer", ptr %t204, i32 0, i32 13
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  store i64 %t207, ptr %l113, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/views:Viewer", ptr %t208, i32 0, i32 12
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l117
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = load i64, ptr %l113, !tbaa !24
  %t217 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216, i64 %t217)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb13
bb49:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/views:Viewer", ptr %t222, i32 0, i32 13
  %t225 = load i64, ptr %l1, !tbaa !24
  %t228 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  store i64 %t228, ptr %l123
  br label %bb50
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/views:Viewer", ptr %t229, i32 0, i32 12
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t232)
  store i64 %t235, ptr %l127
  br label %bb51
bb51:
  %t236 = load i64, ptr %l123, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = icmp eq i64 %t236, %t237
  br i1 %t238, label %bb52, label %bb53
bb52:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/views:Viewer", ptr %t240, i32 0, i32 17
  store ptr %t242, ptr %l130, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/views:Viewer", ptr %t243, i32 0, i32 18
  %t247 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l133
  br label %bb54
bb53:
  br label %bb68
bb54:
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t249 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t248, i64 %t249)
  br label %bb55
bb55:
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/views:Viewer", ptr %t250, i32 0, i32 15
  %t254 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t252)
  %t255 = extractvalue { i32, i64 } %t254, 1
  %t256 = extractvalue { i32, i64 } %t254, 0
  store i32 %t256, ptr %l138
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb58, label %ok.258
ok.258:
  store i64 %t255, ptr %l137
  br label %bb57
bb57:
  %t259 = load i64, ptr %l137, !tbaa !24
  store i64 %t259, ptr %l134, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb60:
  %t260 = load i64, ptr %l134, !tbaa !24
  store i64 %t260, ptr %l9, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/views:Viewer", ptr %t261, i32 0, i32 14
  %t264 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t263, i64 %t264, i1 false)
  br label %bb61
bb61:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/views:Viewer", ptr %t267, i32 0, i32 18
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t269, i64 %t270)
  br label %bb62
bb62:
  %t273 = load i64, ptr %l9, !tbaa !24
  %t274 = load i64, ptr %l1, !tbaa !24
  %t277 = icmp eq i64 %t273, %t274
  br i1 %t277, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb66
bb66:
  br label %bb56
bb67:
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/typed:Local"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/views:state"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"compiler/views:holding"
  %l40 = alloca ptr
  %l47 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l83 = alloca { i64, ptr }
  %l95 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca i32
  %l130 = alloca %"compiler/views:state"
  %l135 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i64
  %l163 = alloca i32
  %l165 = alloca ptr
  %l169 = alloca %"compiler/typed:Local"
  %l171 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca i64
  %l176 = alloca %"compiler/views:place"
  %l180 = alloca %"compiler/typed:Local"
  %l183 = alloca %"compiler/views:view"
  %l184 = alloca %"compiler/views:holding"
  %l192 = alloca i1
  %l200 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l204 = alloca i32
  %l213 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca i32
  %l230 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %t280 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l40
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l40, !tbaa !29
  %t10 = getelementptr %"compiler/views:summary", ptr %t8, i32 0, i32 4
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/views:Viewer", ptr %t15, i32 0, i32 1
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l47
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l47, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t23, i32 0, i32 19
  store ptr %t24, ptr %t28, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr %"compiler/views:Viewer", ptr %t29, i32 0, i32 20
  store i64 %t30, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i1, ptr %l2, !tbaa !21
  %t38 = getelementptr %"compiler/views:Viewer", ptr %t34, i32 0, i32 21
  store i1 %t35, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/views:Viewer", ptr %t39, i32 0, i32 22
  store i1 false, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/views:Viewer", ptr %t47, i32 0, i32 7
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = icmp eq i64 %t46, %t50
  %t56 = getelementptr %"compiler/views:Viewer", ptr %t42, i32 0, i32 23
  store i1 %t53, ptr %t56, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/views:Viewer", ptr %t57, i32 0, i32 26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H70427050a088bf1a66351c183cb6df24(ptr %v0, ptr %t59)
  br label %bb6
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eCl_H0a9e00411db21d32682611ff4a2aedde(ptr %v0, ptr %t63)
  br label %bb7
bb7:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t67)
  br label %bb8
bb8:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  store ptr %t71, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t73, i64 %t74)
  %t78 = extractvalue { i32, { i64, ptr } } %t77, 1
  %t79 = extractvalue { i32, { i64, ptr } } %t77, 0
  store i32 %t79, ptr %l74
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb11, label %ok.81
ok.81:
  store { i64, ptr } %t78, ptr %l73
  br label %bb10
bb10:
  %t82 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t82, ptr %l70, !tbaa !27
  br label %bb15
bb11:
  %t83 = load i32, ptr %l74, !tbaa !23
  %t84 = ashr i32 %t83, 16
  %t86 = icmp eq i32 %t84, 1
  br i1 %t86, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_58304325d16d56e1_1ac2a884e74450d5)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb15:
  %t88 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t88, ptr %l6, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t101, ptr %l83, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/typed:Local", ptr %t105, i64 %t102
  %t107 = load %"compiler/typed:Local", ptr %t106
  store %"compiler/typed:Local" %t107, ptr %l9
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/views:Viewer", ptr %t109, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t111, i64 -1)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l8, !tbaa !24
  br label %bb16
bb22:
  %t117 = load i64, ptr %l5, !tbaa !24
  %t118 = load i64, ptr %l7, !tbaa !24
  %t121 = add i64 %t117, %t118
  store i64 %t121, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb9
bb24:
  store i64 0, ptr %l10, !tbaa !24
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Body", ptr %t123, i32 0, i32 5
  %t127 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t125)
  store i64 %t127, ptr %l95
  br label %bb25
bb25:
  %t128 = load i64, ptr %l95, !tbaa !24
  store i64 %t128, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb26, label %bb27
bb26:
  %t135 = load i64, ptr %l12, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb31
bb28:
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l12, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l102, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb30
bb30:
  %t155 = load i64, ptr %l102, !tbaa !24
  store i64 %t155, ptr %l99, !tbaa !24
  br label %bb31
bb31:
  %t156 = load i64, ptr %l99, !tbaa !24
  store i64 %t156, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load i64, ptr %l14, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  store i64 %t173, ptr %l15, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/views:Viewer", ptr %t175, i32 0, i32 25
  store ptr %t177, ptr %l121, !tbaa !29
  %t178 = load ptr, ptr %l3, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Body", ptr %t178, i32 0, i32 5
  %t181 = load i64, ptr %l15, !tbaa !24
  %t184 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l125
  br label %bb36
bb36:
  %t185 = load i32, ptr %l125, !tbaa !23
  %t186 = sext i32 %t185 to i64
  %t187 = load i64, ptr %l15, !tbaa !24
  %t188 = load ptr, ptr %l121, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t188, i64 %t186, i64 %t187)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  %t191 = load i64, ptr %l14, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l14, !tbaa !24
  br label %bb32
bb39:
  %t195 = call %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %s0)
  store %"compiler/views:state" %t195, ptr %l130
  br label %bb40
bb40:
  %t196 = load %"compiler/views:state", ptr %l130
  store %"compiler/views:state" %t196, ptr %l16
  %t197 = load i1, ptr %l2, !tbaa !21
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb41, label %bb42
bb41:
  store i64 0, ptr %l17, !tbaa !24
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Body", ptr %t201, i32 0, i32 5
  %t205 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l135
  br label %bb43
bb42:
  br label %bb67
bb43:
  %t206 = load i64, ptr %l135, !tbaa !24
  store i64 %t206, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t207 = load i64, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = icmp sgt i64 %t207, %t208
  br i1 %t211, label %bb44, label %bb45
bb44:
  %t213 = load i64, ptr %l19, !tbaa !24
  %t215 = icmp sgt i64 %t213, 0
  br i1 %t215, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb49
bb46:
  %t217 = load i64, ptr %l18, !tbaa !24
  %t218 = load i64, ptr %l17, !tbaa !24
  %t221 = sub i64 %t217, %t218
  %t222 = load i64, ptr %l19, !tbaa !24
  %t225 = add i64 %t221, %t222
  %t227 = sub i64 %t225, 1
  %t228 = load i64, ptr %l19, !tbaa !24
  %t231 = sdiv i64 %t227, %t228
  store i64 %t231, ptr %l142, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb48
bb48:
  %t233 = load i64, ptr %l142, !tbaa !24
  store i64 %t233, ptr %l139, !tbaa !24
  br label %bb49
bb49:
  %t234 = load i64, ptr %l139, !tbaa !24
  store i64 %t234, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t235 = load i64, ptr %l21, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb52:
  br label %bb53
bb53:
  %t243 = load i64, ptr %l17, !tbaa !24
  %t244 = load i64, ptr %l21, !tbaa !24
  %t245 = load i64, ptr %l19, !tbaa !24
  %t248 = mul i64 %t244, %t245
  %t251 = add i64 %t243, %t248
  store i64 %t251, ptr %l22, !tbaa !24
  %t253 = load ptr, ptr %l3, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Body", ptr %t253, i32 0, i32 5
  %t256 = load i64, ptr %l22, !tbaa !24
  %t259 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t255, i64 %t256)
  store i32 %t259, ptr %l163
  br label %bb54
bb54:
  %t260 = load i32, ptr %l163, !tbaa !23
  %t261 = sext i32 %t260 to i64
  store i64 %t261, ptr %l23, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l165, !tbaa !29
  %t264 = load ptr, ptr %l3, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Body", ptr %t264, i32 0, i32 7
  %t267 = load i64, ptr %l23, !tbaa !24
  %t270 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t266, i64 %t267)
  store %"compiler/typed:Local" %t270, ptr %l169
  br label %bb55
bb55:
  %t271 = getelementptr %"compiler/typed:Local", ptr %l169, i32 0, i32 2
  %t272 = load i32, ptr %t271, !tbaa !23
  %t273 = load ptr, ptr %l165, !tbaa !29
  %t275 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t273, i32 %t272)
  store i1 %t275, ptr %l171
  br label %bb56
bb56:
  %t276 = load i1, ptr %l171, !tbaa !21
  br i1 %t276, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  %t277 = getelementptr %"compiler/views:state", ptr %l16, i32 0, i32 1
  store ptr %t277, ptr %l172, !tbaa !29
  %t278 = load i64, ptr %l23, !tbaa !24
  store i64 %t278, ptr %l173, !tbaa !24
  %t279 = load i64, ptr %l22, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t280
  %t281 = getelementptr { i64, [2 x i64] }, ptr %t280, i32 0, i32 0
  store i64 4, ptr %t281
  %t283 = insertvalue { i64 } undef, i64 %t279, 0
  %t284 = getelementptr { i64, [2 x i64] }, ptr %t280, i32 0, i32 1
  store { i64 } %t283, ptr %t284
  %t285 = load { i64, [2 x i64] }, ptr %t280
  %t287 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s12, { i64, [2 x i64] } %t285, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t287, ptr %l176
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t288 = load ptr, ptr %l3, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Body", ptr %t288, i32 0, i32 7
  %t291 = load i64, ptr %l23, !tbaa !24
  %t294 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t290, i64 %t291)
  store %"compiler/typed:Local" %t294, ptr %l180
  br label %bb60
bb60:
  %t295 = getelementptr %"compiler/typed:Local", ptr %l180, i32 0, i32 1
  %t296 = getelementptr %"compiler/source:Span", ptr %t295, i32 0, i32 0
  %t297 = load i32, ptr %t296, !tbaa !23
  %t299 = sext i32 %t297 to i64
  %t300 = load %"compiler/views:place", ptr %l176
  %t302 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s12, %"compiler/views:place" %t300, i64 %t299)
  store %"compiler/views:view" %t302, ptr %l183
  br label %bb61
bb61:
  %t303 = load i64, ptr %l173, !tbaa !24
  %t304 = load %"compiler/views:view", ptr %l183
  %t305 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s12, i64 %t303, %"compiler/views:view" %t304)
  store %"compiler/views:holding" %t305, ptr %l184
  br label %bb62
bb62:
  %t306 = load ptr, ptr %l172, !tbaa !29
  %t307 = load %"compiler/views:holding", ptr %l184
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %s0, ptr %t306, %"compiler/views:holding" %t307)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t308 = load i64, ptr %l21, !tbaa !24
  %t310 = add i64 %t308, 1
  store i64 %t310, ptr %l21, !tbaa !24
  br label %bb50
bb66:
  br label %bb67
bb67:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Body", ptr %t313, i32 0, i32 11
  %t316 = load ptr, ptr %t315, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v0, ptr %s0, ptr %t312, ptr %t316, ptr %l16)
  br label %bb68
bb68:
  %t320 = load i1, ptr %l2, !tbaa !21
  br i1 %t320, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb71
bb70:
  %t322 = getelementptr %"compiler/views:state", ptr %l16, i32 0, i32 0
  %t323 = load i1, ptr %t322, !tbaa !21
  store i1 %t323, ptr %l192, !tbaa !21
  br label %bb71
bb71:
  %t325 = load i1, ptr %l192, !tbaa !21
  br i1 %t325, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb73:
  br label %bb74
bb74:
  %t326 = load ptr, ptr %l3, !tbaa !29
  %t328 = getelementptr %"compiler/typed:Body", ptr %t326, i32 0, i32 1
  %t329 = load { i64, [2 x i64] }, ptr %t328
  %t333 = extractvalue { i64, [2 x i64] } %t329, 0
  %t334 = icmp eq i64 %t333, 1
  br i1 %t334, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb112
bb77:
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Body", ptr %t336, i32 0, i32 10
  store ptr %t338, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s17
  %t340 = load ptr, ptr %l25, !tbaa !29
  %t341 = load i64, ptr %l26, !tbaa !24
  %t344 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t340, i64 %t341)
  %t345 = extractvalue { i32, { i64, ptr } } %t344, 1
  %t346 = extractvalue { i32, { i64, ptr } } %t344, 0
  store i32 %t346, ptr %l204
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb80, label %ok.348
ok.348:
  store { i64, ptr } %t345, ptr %l203
  br label %bb79
bb79:
  %t349 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t349, ptr %l200, !tbaa !27
  br label %bb84
bb80:
  %t350 = load i32, ptr %l204, !tbaa !23
  %t351 = ashr i32 %t350, 16
  %t353 = icmp eq i32 %t351, 1
  br i1 %t353, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_a298007ba002c150_d601faccbb5a36e4)
  unreachable
bb83:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb84:
  %t355 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t355, ptr %l27, !tbaa !27
  %t356 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t356, 0
  store i64 %t358, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s18
  %t360 = load i64, ptr %l29, !tbaa !24
  %t361 = load i64, ptr %l28, !tbaa !24
  %t364 = icmp slt i64 %t360, %t361
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb87:
  br label %bb88
bb88:
  %t368 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t368, ptr %l213, !tbaa !27
  %t369 = load i64, ptr %l29, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr i32, ptr %t372, i64 %t369
  %t374 = load i32, ptr %t373, !tbaa !33
  store i32 %t374, ptr %l30, !tbaa !23
  %t376 = getelementptr %"compiler/views:state", ptr %l16, i32 0, i32 1
  store ptr %t376, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s20
  %t378 = load ptr, ptr %l31, !tbaa !29
  %t379 = load i64, ptr %l32, !tbaa !24
  %t382 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %s0, ptr %t378, i64 %t379)
  %t383 = extractvalue { i32, { i64, ptr } } %t382, 1
  %t384 = extractvalue { i32, { i64, ptr } } %t382, 0
  store i32 %t384, ptr %l221
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb91, label %ok.386
ok.386:
  store { i64, ptr } %t383, ptr %l220
  br label %bb90
bb90:
  %t387 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t387, ptr %l217, !tbaa !27
  br label %bb95
bb91:
  %t388 = load i32, ptr %l221, !tbaa !23
  %t389 = ashr i32 %t388, 16
  %t391 = icmp eq i32 %t389, 1
  br i1 %t391, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_6e59d20d6709208b_b4c7cdbf7939291f)
  unreachable
bb94:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s20)
  br label %bb107
bb95:
  %t393 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t393, ptr %l33, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s21
  %t398 = load i64, ptr %l35, !tbaa !24
  %t399 = load i64, ptr %l34, !tbaa !24
  %t402 = icmp slt i64 %t398, %t399
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb105
bb98:
  br label %bb99
bb99:
  %t406 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t406, ptr %l230, !tbaa !27
  %t407 = load i64, ptr %l35, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr %"compiler/views:holding", ptr %t410, i64 %t407
  %t412 = load %"compiler/views:holding", ptr %t411
  store %"compiler/views:holding" %t412, ptr %l36
  %t414 = getelementptr %"compiler/views:holding", ptr %l36, i32 0, i32 0
  %t415 = load i64, ptr %t414, !tbaa !24
  %t416 = load i32, ptr %l30, !tbaa !23
  %t418 = sext i32 %t416 to i64
  %t421 = icmp eq i64 %t415, %t418
  br i1 %t421, label %bb100, label %bb101
bb100:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/views:holding", ptr %l36, i32 0, i32 1
  %t425 = load %"compiler/views:view", ptr %t424
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t423, %"compiler/views:view" %t425)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb104:
  %t428 = load i64, ptr %l35, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l35, !tbaa !24
  br label %bb96
bb105:
  %t432 = load i64, ptr %l32, !tbaa !24
  %t433 = load i64, ptr %l34, !tbaa !24
  %t436 = add i64 %t432, %t433
  store i64 %t436, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb106
bb106:
  br label %bb89
bb107:
  call void @__olang_scope_close(ptr %s18)
  br label %bb108
bb108:
  %t438 = load i64, ptr %l29, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l29, !tbaa !24
  br label %bb85
bb109:
  %t442 = load i64, ptr %l26, !tbaa !24
  %t443 = load i64, ptr %l28, !tbaa !24
  %t446 = add i64 %t442, %t443
  store i64 %t446, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb110
bb110:
  br label %bb78
bb111:
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_b5b09e955edab64a_4c68cd282b8cbe9e)
  unreachable
bb117:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalkable(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/typed:Local"
  %l13 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l38 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t24 = extractvalue { i64, [2 x i64] } %t20, 0
  %t25 = icmp eq i64 %t24, 7
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_f882b6801a6cfe65_db0a8f546b27139)
  unreachable
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 7
  store ptr %t30, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t32, i64 %t33)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l29
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb16, label %ok.40
ok.40:
  store { i64, ptr } %t37, ptr %l28
  br label %bb15
bb15:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  br label %bb20
bb16:
  %t42 = load i32, ptr %l29, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a380450d9739f734_de428b9b50328168)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb20:
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr %"compiler/typed:Local", ptr %t64, i64 %t61
  %t66 = load %"compiler/typed:Local", ptr %t65
  store %"compiler/typed:Local" %t66, ptr %l9
  %t68 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp eq i32 %t69, %t70
  br i1 %t73, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb21
bb29:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t80, %t81
  store i64 %t84, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  br label %bb14
bb31:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca %"compiler/typed:Local"
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 19
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4283dbd3668d18ac_9869995bfb9a4270)
  unreachable
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/views:Viewer", ptr %t21, i32 0, i32 19
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 7
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t27, i64 %t28)
  store %"compiler/typed:Local" %t31, ptr %l23
  br label %bb7
bb7:
  %t32 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t34, i32 %t33)
  store { i64, ptr } %t36, ptr %l25
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l10, !tbaa !27
  br label %bb32
bb9:
  %t44 = load { i64, [2 x i64] }, ptr %l2
  %t46 = extractvalue { i64, [2 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 2
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t50 = getelementptr { i64 }, ptr %t49, i32 0, i32 0
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:Viewer", ptr %t54, i32 0, i32 19
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7a5a13ecbea84e9b_d0d616c1e5cf6f4f)
  unreachable
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 19
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 7
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/views:Viewer", ptr %t68, i32 0, i32 19
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7a5a13ecbea84e9b_d0d616c1e5cf6f4f)
  unreachable
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/views:Viewer", ptr %t75, i32 0, i32 19
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t78, i32 0, i32 5
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l46
  br label %bb19
bb19:
  %t86 = load i32, ptr %l46, !tbaa !23
  %t87 = sext i32 %t86 to i64
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t90 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t88, i64 %t87)
  store %"compiler/typed:Local" %t90, ptr %l48
  br label %bb20
bb20:
  %t91 = getelementptr %"compiler/typed:Local", ptr %l48, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load ptr, ptr %l30, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t93, i32 %t92)
  store { i64, ptr } %t95, ptr %l50
  br label %bb21
bb21:
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t97, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  br label %bb32
bb22:
  %t103 = load { i64, [2 x i64] }, ptr %l2
  %t105 = extractvalue { i64, [2 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 3
  br i1 %t106, label %bb23, label %bb24
bb23:
  %t108 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t109 = getelementptr { i64, i32 }, ptr %t108, i32 0, i32 1
  %t110 = load i32, ptr %t109
  store i32 %t110, ptr %l5, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t112, i32 %t113)
  store { i64, ptr } %t116, ptr %l57
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t118, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l10, !tbaa !27
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l59, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t124, ptr %l10, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e23614535e762839_a3c52bd11c6a8cad)
  unreachable
bb32:
  %t126 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t126, ptr %l6, !tbaa !27
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/views:Viewer", ptr %t127, i32 0, i32 3
  %t130 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  %t134 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t129, i64 %t131)
  store { i64, ptr } %t134, ptr %l64
  br label %bb33
bb33:
  %t135 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t135, ptr %l7, !tbaa !27
  %t136 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb34, label %bb35
bb34:
  %t141 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t148 = icmp sle i64 %t142, %t145
  store i1 %t148, ptr %l67, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb36
bb36:
  %t150 = load i1, ptr %l67, !tbaa !21
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t151 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t152 = load i64, ptr %t151, !tbaa !24
  store i64 %t152, ptr %l72, !tbaa !24
  br label %bb39
bb38:
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  store i64 %t156, ptr %l72, !tbaa !24
  br label %bb39
bb39:
  %t158 = load i64, ptr %l72, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t159, ptr %l76, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t160, ptr %l77, !tbaa !27
  store i64 %t158, ptr %l78, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l79, !tbaa !24
  %t164 = icmp sge i64 0, 0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load i64, ptr %l78, !tbaa !24
  %t167 = icmp sle i64 0, %t166
  br i1 %t167, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173)
  unreachable
bb42:
  %t169 = load i64, ptr %l78, !tbaa !24
  %t170 = load i64, ptr %l79, !tbaa !24
  %t171 = icmp sle i64 %t169, %t170
  br i1 %t171, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173)
  unreachable
bb44:
  %t173 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l78, !tbaa !24
  %t176 = getelementptr i8, ptr %t174, i64 0
  %t177 = sub i64 %t175, 0
  %t178 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t180 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t184 = extractvalue { i64, ptr } %t179, 1
  %t185 = extractvalue { i64, ptr } %t179, 0
  %t186 = add i64 %t182, %t185
  %t187 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t181, i64 %t182)
  %t188 = getelementptr i8, ptr %t187, i64 %t182
  call void @olang_textcopy(ptr %t188, ptr %t184, i64 %t185)
  %t189 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t187, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t190, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/views:state"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:state"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %v1)
  store %"compiler/views:state" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/views:state", ptr %l2
  %t4 = load ptr, ptr %lp1
  store %"compiler/views:state" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = load ptr, ptr %lp1
  %t11 = getelementptr %"compiler/views:state", ptr %t10, i32 0, i32 0
  store i1 %t8, ptr %t11, !tbaa !21
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:state", ptr %t12, i32 0, i32 1
  %t16 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v0, ptr %v1, ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l7
  br label %bb2
bb2:
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t18 = load ptr, ptr %lp1
  %t19 = getelementptr %"compiler/views:state", ptr %t18, i32 0, i32 1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/views:state", ptr %t20, i32 0, i32 2
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %v1, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l10
  br label %bb3
bb3:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t26 = load ptr, ptr %lp1
  %t27 = getelementptr %"compiler/views:state", ptr %t26, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:state", ptr %t28, i32 0, i32 3
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l13
  br label %bb4
bb4:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t34 = load ptr, ptr %lp1
  %t35 = getelementptr %"compiler/views:state", ptr %t34, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t35
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/views:state", ptr %t36, i32 0, i32 4
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eClone_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %v1, ptr %t38)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l16
  br label %bb5
bb5:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t42 = load ptr, ptr %lp1
  %t43 = getelementptr %"compiler/views:state", ptr %t42, i32 0, i32 4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %t43
  %t44 = load ptr, ptr %lp1
  %t45 = load %"compiler/views:state", ptr %t44
  store %"compiler/views:state" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:state", ptr %rv
  ret %"compiler/views:state" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eforget(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:holding"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 1
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v0, ptr %s0, ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eCle_Ha50b8ef86adef4ee8ec69eed192d557f(ptr %v0, ptr %t9)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %s0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l19
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l18
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  br label %bb9
bb5:
  %t22 = load i32, ptr %l19, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f7e0c2831b30450a_35c62a326669c166)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l28, !tbaa !27
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/views:holding", ptr %t44, i64 %t41
  %t46 = load %"compiler/views:holding", ptr %t45
  store %"compiler/views:holding" %t46, ptr %l8
  %t48 = getelementptr %"compiler/views:holding", ptr %l8, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = icmp ne i64 %t49, %t50
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 1
  %t58 = load %"compiler/views:holding", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %v0, ptr %t57, %"compiler/views:holding" %t58)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb10
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb3
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v0, ptr %t71, i64 %t72)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/views:state", ptr %t2, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  %t8 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  store i1 %t5, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/views:state", ptr %t10, i32 0, i32 1
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v1, ptr %v0, ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr %"compiler/views:state", ptr %t16, i32 0, i32 1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %t17
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/views:state", ptr %t19, i32 0, i32 2
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v1, ptr %v0, ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l12
  br label %bb2
bb2:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t25 = load ptr, ptr %l9, !tbaa !29
  %t26 = getelementptr %"compiler/views:state", ptr %t25, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %t26
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/views:state", ptr %t28, i32 0, i32 3
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v1, ptr %v0, ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l16
  br label %bb3
bb3:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = getelementptr %"compiler/views:state", ptr %t34, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t35
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/views:state", ptr %t37, i32 0, i32 4
  %t41 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eClone_3ccompiler_2fviews_3atasked_3e(ptr %v1, ptr %v0, ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l20
  br label %bb4
bb4:
  %t42 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"compiler/views:state", ptr %t43, i32 0, i32 4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t44
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:naming"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l35 = alloca { i64, ptr }
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 2
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %s0, ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClear_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t9)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %s0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l26
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l25
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t21, ptr %l22, !tbaa !27
  br label %bb9
bb5:
  %t22 = load i32, ptr %l26, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_953a2c9bd6842121_4c37e734fd78df0d)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t27 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l35, !tbaa !27
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/views:naming", ptr %t44, i64 %t41
  %t46 = load %"compiler/views:naming", ptr %t45
  store %"compiler/views:naming" %t46, ptr %l8
  %t48 = getelementptr %"compiler/views:naming", ptr %l8, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = icmp ne i64 %t49, %t50
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 2
  %t58 = load %"compiler/views:naming", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t57, %"compiler/views:naming" %t58)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb10
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb3
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/views:state", ptr %t71, i32 0, i32 3
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %s0, ptr %t73)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l51
  br label %bb22
bb22:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l9
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/views:state", ptr %t77, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t79)
  br label %bb23
bb23:
  store ptr %l9, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load ptr, ptr %l10, !tbaa !29
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t82, i64 %t83)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l59
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb26, label %ok.90
ok.90:
  store { i64, ptr } %t87, ptr %l58
  br label %bb25
bb25:
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t91, ptr %l55, !tbaa !27
  br label %bb30
bb26:
  %t92 = load i32, ptr %l59, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  br i1 %t95, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_49bb3a1db5202690_b516fb53c86045dc)
  unreachable
bb29:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb30:
  %t97 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t97, ptr %l12, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t102 = load i64, ptr %l14, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb33:
  br label %bb34
bb34:
  %t110 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t110, ptr %l68, !tbaa !27
  %t111 = load i64, ptr %l14, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i64, ptr %t114, i64 %t111
  %t116 = load i64, ptr %t115, !tbaa !34
  store i64 %t116, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = icmp ne i64 %t118, %t119
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/views:state", ptr %t124, i32 0, i32 3
  %t127 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t126, i64 %t127)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb39:
  %t130 = load i64, ptr %l14, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l14, !tbaa !24
  br label %bb31
bb40:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %bb24
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/views:state" @compiler_2fviews_2edead(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca %"compiler/views:state"
  %rv = alloca %"compiler/views:state"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %v0)
  store %"compiler/views:state" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"compiler/views:state", ptr %l1
  %t4 = load ptr, ptr %lp0
  store %"compiler/views:state" %t3, ptr %t4
  %t5 = load ptr, ptr %lp0
  %t6 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  store i1 true, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %lp0
  %t8 = load %"compiler/views:state", ptr %t7
  store %"compiler/views:state" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:state", ptr %rv
  ret %"compiler/views:state" %rr
}

define dso_local i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/source:Span", ptr %t34
  store %"compiler/source:Span" %t35, ptr %l1
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i64 @compiler_2fviews_2eplaceEnd(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l22
  br label %bb10
bb10:
  %t46 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = load i64, ptr %l22, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t50, i64 %t49)
  store i64 %t52, ptr %l25
  br label %bb11
bb11:
  %t53 = load i64, ptr %l25, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb25
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l26, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 17
  store i1 %t61, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l33
  br label %bb18
bb18:
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t73)
  store %"compiler/source:Span" %t75, ptr %l35
  br label %bb23
bb23:
  %t76 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_26ef299dad5cdbef_4a7142c0b9c90bab)
  unreachable
bb25:
  %t81 = load i64, ptr %l4, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2eholdAdd(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:view" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/views:view"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca %"compiler/views:holding"
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca %"compiler/views:place"
  %l51 = alloca %"compiler/views:place"
  %l53 = alloca i1
  %l56 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca %"compiler/views:holding"
  %l70 = alloca ptr
  %l73 = alloca %"compiler/views:holding"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/views:view" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:state", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/views:holding" %t59, ptr %l40
  br label %bb12
bb12:
  %t60 = load %"compiler/views:holding", ptr %l40
  store %"compiler/views:holding" %t60, ptr %l9
  %t61 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t68 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t69 = getelementptr %"compiler/views:view", ptr %t68, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = icmp ne i64 %t70, %t72
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t78 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t79 = getelementptr %"compiler/views:view", ptr %t78, i32 0, i32 0
  %t80 = load %"compiler/views:place", ptr %t79
  store %"compiler/views:place" %t80, ptr %l49
  %t81 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 0
  %t82 = load %"compiler/views:place", ptr %t81
  store %"compiler/views:place" %t82, ptr %l51
  %t85 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l49, ptr %l51)
  store i1 %t85, ptr %l53
  br label %bb18
bb18:
  %t86 = load i1, ptr %l53, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb21:
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 2
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t94 = getelementptr %"compiler/views:view", ptr %t93, i32 0, i32 2
  %t95 = load i1, ptr %t94, !tbaa !21
  %t97 = xor i1 %t95, true
  store i1 %t97, ptr %l56, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l56, !tbaa !21
  br i1 %t99, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/views:state", ptr %t100, i32 0, i32 1
  store ptr %t102, ptr %l60, !tbaa !29
  %t103 = load i64, ptr %l8, !tbaa !24
  store i64 %t103, ptr %l61, !tbaa !24
  %t104 = load i64, ptr %l1, !tbaa !24
  %t105 = load %"compiler/views:view", ptr %l2
  %t108 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s4, i64 %t104, %"compiler/views:view" %t105)
  store %"compiler/views:holding" %t108, ptr %l64
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = load i64, ptr %l61, !tbaa !24
  %t111 = load %"compiler/views:holding", ptr %l64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v0, ptr %t109, i64 %t110, %"compiler/views:holding" %t111)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb8
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/views:state", ptr %t118, i32 0, i32 1
  store ptr %t120, ptr %l70, !tbaa !29
  %t121 = load i64, ptr %l1, !tbaa !24
  %t122 = load %"compiler/views:view", ptr %l2
  %t125 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s0, i64 %t121, %"compiler/views:view" %t122)
  store %"compiler/views:holding" %t125, ptr %l73
  br label %bb33
bb33:
  %t126 = load ptr, ptr %l70, !tbaa !29
  %t127 = load %"compiler/views:holding", ptr %l73
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %v0, ptr %t126, %"compiler/views:holding" %t127)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2emerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/views:holding"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/views:holding"
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca %"compiler/views:naming"
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca %"compiler/views:tasked"
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca %"compiler/views:tasked"
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i1
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l106 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l131 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l149 = alloca { i64, ptr }
  %l161 = alloca i1
  %l165 = alloca i1
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l188 = alloca { i64, ptr }
  %l195 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca %"compiler/views:place"
  %l206 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca i64
  %l212 = alloca %"compiler/views:place"
  %l215 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l219 = alloca i32
  %l228 = alloca { i64, ptr }
  %l246 = alloca i1
  %l258 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l262 = alloca i32
  %l271 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca i32
  %l289 = alloca { i64, ptr }
  %l295 = alloca i1
  %l296 = alloca %"compiler/source:Span"
  %l298 = alloca %"compiler/source:Span"
  %l300 = alloca i1
  %l301 = alloca i1
  %l302 = alloca %"compiler/views:place"
  %l304 = alloca %"compiler/views:place"
  %l306 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %t303 = alloca { i64, [2 x i64] }, align 8
  %t329 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/views:state", ptr %t6, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/views:state", ptr %t15, i32 0, i32 1
  store ptr %t17, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t19, i64 %t20)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l69
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb10, label %ok.27
ok.27:
  store { i64, ptr } %t24, ptr %l68
  br label %bb9
bb9:
  %t28 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t28, ptr %l65, !tbaa !27
  br label %bb14
bb10:
  %t29 = load i32, ptr %l69, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_14b5d885bc836b4b_caf3078777493f87)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  %t34 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t47, ptr %l78, !tbaa !27
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/views:holding", ptr %t51, i64 %t48
  %t53 = load %"compiler/views:holding", ptr %t52
  store %"compiler/views:holding" %t53, ptr %l7
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:holding", ptr %l7, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = getelementptr %"compiler/views:holding", ptr %l7, i32 0, i32 1
  %t59 = load %"compiler/views:view", ptr %t58
  %t63 = call i1 @compiler_2fviews_2eholdAdd(ptr %v0, ptr %t55, i64 %t57, %"compiler/views:view" %t59)
  store i1 %t63, ptr %l84
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb15
bb21:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = add i64 %t68, %t69
  store i64 %t72, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb8
bb23:
  %t74 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l90
  br label %bb24
bb24:
  %t75 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l8
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/views:state", ptr %t76, i32 0, i32 3
  store ptr %t78, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t80, i64 %t81)
  %t85 = extractvalue { i32, { i64, ptr } } %t84, 1
  %t86 = extractvalue { i32, { i64, ptr } } %t84, 0
  store i32 %t86, ptr %l97
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb27, label %ok.88
ok.88:
  store { i64, ptr } %t85, ptr %l96
  br label %bb26
bb26:
  %t89 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t89, ptr %l93, !tbaa !27
  br label %bb31
bb27:
  %t90 = load i32, ptr %l97, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  br i1 %t93, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_d6f46cea289d270a_99670469c794e026)
  unreachable
bb30:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb31:
  %t95 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t95, ptr %l11, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t100 = load i64, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t108, ptr %l106, !tbaa !27
  %t109 = load i64, ptr %l13, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i64, ptr %t112, i64 %t109
  %t114 = load i64, ptr %t113, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t114)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  %t119 = load i64, ptr %l13, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l13, !tbaa !24
  br label %bb32
bb38:
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t127 = add i64 %t123, %t124
  store i64 %t127, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb39:
  br label %bb25
bb40:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/views:state", ptr %t129, i32 0, i32 3
  store ptr %t131, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t133 = load ptr, ptr %l15, !tbaa !29
  %t134 = load i64, ptr %l16, !tbaa !24
  %t137 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  %t138 = extractvalue { i32, { i64, ptr } } %t137, 1
  %t139 = extractvalue { i32, { i64, ptr } } %t137, 0
  store i32 %t139, ptr %l122
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb43, label %ok.141
ok.141:
  store { i64, ptr } %t138, ptr %l121
  br label %bb42
bb42:
  %t142 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t142, ptr %l118, !tbaa !27
  br label %bb47
bb43:
  %t143 = load i32, ptr %l122, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 1
  br i1 %t146, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_ed1a709fbfa842a1_51b8be3172e619bd)
  unreachable
bb46:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb47:
  %t148 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t148, ptr %l17, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  store i64 %t151, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s13
  %t153 = load i64, ptr %l19, !tbaa !24
  %t154 = load i64, ptr %l18, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb50:
  br label %bb51
bb51:
  %t161 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t161, ptr %l131, !tbaa !27
  %t162 = load i64, ptr %l19, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i64, ptr %t165, i64 %t162
  %t167 = load i64, ptr %t166, !tbaa !34
  store i64 %t167, ptr %l20, !tbaa !24
  store i1 false, ptr %l21, !tbaa !21
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/views:state", ptr %t169, i32 0, i32 1
  store ptr %t171, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t173 = load ptr, ptr %l22, !tbaa !29
  %t174 = load i64, ptr %l23, !tbaa !24
  %t177 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t173, i64 %t174)
  %t178 = extractvalue { i32, { i64, ptr } } %t177, 1
  %t179 = extractvalue { i32, { i64, ptr } } %t177, 0
  store i32 %t179, ptr %l140
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb54, label %ok.181
ok.181:
  store { i64, ptr } %t178, ptr %l139
  br label %bb53
bb53:
  %t182 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t182, ptr %l136, !tbaa !27
  br label %bb58
bb54:
  %t183 = load i32, ptr %l140, !tbaa !23
  %t184 = ashr i32 %t183, 16
  %t186 = icmp eq i32 %t184, 1
  br i1 %t186, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_a19b7e219e444810_9c0582167fc3628c)
  unreachable
bb57:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb58:
  %t188 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t188, ptr %l24, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s16
  %t193 = load i64, ptr %l26, !tbaa !24
  %t194 = load i64, ptr %l25, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s16)
  br label %bb67
bb61:
  br label %bb62
bb62:
  %t201 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t201, ptr %l149, !tbaa !27
  %t202 = load i64, ptr %l26, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr %"compiler/views:holding", ptr %t205, i64 %t202
  %t207 = load %"compiler/views:holding", ptr %t206
  store %"compiler/views:holding" %t207, ptr %l27
  %t209 = getelementptr %"compiler/views:holding", ptr %l27, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load i64, ptr %l20, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s16)
  br label %bb66
bb66:
  %t216 = load i64, ptr %l26, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l26, !tbaa !24
  br label %bb59
bb67:
  %t220 = load i64, ptr %l23, !tbaa !24
  %t221 = load i64, ptr %l25, !tbaa !24
  %t224 = add i64 %t220, %t221
  store i64 %t224, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb68
bb68:
  br label %bb52
bb69:
  %t226 = load i1, ptr %l21, !tbaa !21
  br i1 %t226, label %bb70, label %bb71
bb70:
  %t228 = load i64, ptr %l20, !tbaa !24
  %t233 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l8, i64 %t228)
  store i1 %t233, ptr %l165
  br label %bb72
bb71:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb73
bb72:
  %t234 = load i1, ptr %l165, !tbaa !21
  %t235 = xor i1 %t234, true
  store i1 %t235, ptr %l161, !tbaa !21
  br label %bb73
bb73:
  %t237 = load i1, ptr %l161, !tbaa !21
  br i1 %t237, label %bb74, label %bb75
bb74:
  %t238 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t238)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s13)
  br label %bb78
bb78:
  %t241 = load i64, ptr %l19, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l19, !tbaa !24
  br label %bb48
bb79:
  %t245 = load i64, ptr %l16, !tbaa !24
  %t246 = load i64, ptr %l18, !tbaa !24
  %t249 = add i64 %t245, %t246
  store i64 %t249, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb80:
  br label %bb41
bb81:
  store ptr %l8, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s22
  %t252 = load ptr, ptr %l29, !tbaa !29
  %t253 = load i64, ptr %l30, !tbaa !24
  %t256 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t252, i64 %t253)
  %t257 = extractvalue { i32, { i64, ptr } } %t256, 1
  %t258 = extractvalue { i32, { i64, ptr } } %t256, 0
  store i32 %t258, ptr %l179
  %t259 = icmp ne i32 %t258, 0
  br i1 %t259, label %bb84, label %ok.260
ok.260:
  store { i64, ptr } %t257, ptr %l178
  br label %bb83
bb83:
  %t261 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t261, ptr %l175, !tbaa !27
  br label %bb88
bb84:
  %t262 = load i32, ptr %l179, !tbaa !23
  %t263 = ashr i32 %t262, 16
  %t265 = icmp eq i32 %t263, 1
  br i1 %t265, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_a65aecd2c2ee9227_2ed53f6634d29f2b)
  unreachable
bb87:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb132
bb88:
  %t267 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t267, ptr %l31, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 0
  store i64 %t270, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s23
  %t272 = load i64, ptr %l33, !tbaa !24
  %t273 = load i64, ptr %l32, !tbaa !24
  %t276 = icmp slt i64 %t272, %t273
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s23)
  br label %bb130
bb91:
  br label %bb92
bb92:
  %t280 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t280, ptr %l188, !tbaa !27
  %t281 = load i64, ptr %l33, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i64, ptr %t284, i64 %t281
  %t286 = load i64, ptr %t285, !tbaa !34
  store i64 %t286, ptr %l34, !tbaa !24
  %t288 = load i64, ptr %l34, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/views:state", ptr %t290, i32 0, i32 3
  %t296 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t292, i64 %t288)
  store i1 %t296, ptr %l195
  br label %bb93
bb93:
  %t297 = load i1, ptr %l195, !tbaa !21
  %t298 = xor i1 %t297, true
  br i1 %t298, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s24
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l197, !tbaa !29
  %t301 = load i64, ptr %l34, !tbaa !24
  store i64 %t301, ptr %l198, !tbaa !24
  %t302 = load i64, ptr %l34, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t303
  %t304 = getelementptr { i64, [2 x i64] }, ptr %t303, i32 0, i32 0
  store i64 1, ptr %t304
  %t306 = insertvalue { i64 } undef, i64 %t302, 0
  %t307 = getelementptr { i64, [2 x i64] }, ptr %t303, i32 0, i32 1
  store { i64 } %t306, ptr %t307
  %t308 = load { i64, [2 x i64] }, ptr %t303
  %t310 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s24, { i64, [2 x i64] } %t308, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t310, ptr %l201
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t311 = load ptr, ptr %l197, !tbaa !29
  %t312 = load i64, ptr %l198, !tbaa !24
  %t313 = load %"compiler/views:place", ptr %l201
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t311, i64 %t312, %"compiler/views:place" %t313)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s24)
  br label %bb98
bb98:
  %t314 = load i64, ptr %l34, !tbaa !24
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr %"compiler/views:state", ptr %t316, i32 0, i32 3
  %t322 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t318, i64 %t314)
  store i1 %t322, ptr %l206
  br label %bb99
bb99:
  %t323 = load i1, ptr %l206, !tbaa !21
  %t324 = xor i1 %t323, true
  br i1 %t324, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s25
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l208, !tbaa !29
  %t327 = load i64, ptr %l34, !tbaa !24
  store i64 %t327, ptr %l209, !tbaa !24
  %t328 = load i64, ptr %l34, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [2 x i64] }, ptr %t329, i32 0, i32 0
  store i64 1, ptr %t330
  %t332 = insertvalue { i64 } undef, i64 %t328, 0
  %t333 = getelementptr { i64, [2 x i64] }, ptr %t329, i32 0, i32 1
  store { i64 } %t332, ptr %t333
  %t334 = load { i64, [2 x i64] }, ptr %t329
  %t336 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s25, { i64, [2 x i64] } %t334, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t336, ptr %l212
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t337 = load ptr, ptr %l208, !tbaa !29
  %t338 = load i64, ptr %l209, !tbaa !24
  %t339 = load %"compiler/views:place", ptr %l212
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t337, i64 %t338, %"compiler/views:place" %t339)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s25)
  br label %bb104
bb104:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr %"compiler/views:state", ptr %t340, i32 0, i32 2
  store ptr %t342, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s27
  %t344 = load ptr, ptr %l37, !tbaa !29
  %t345 = load i64, ptr %l38, !tbaa !24
  %t348 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v1, ptr %t344, i64 %t345)
  %t349 = extractvalue { i32, { i64, ptr } } %t348, 1
  %t350 = extractvalue { i32, { i64, ptr } } %t348, 0
  store i32 %t350, ptr %l219
  %t351 = icmp ne i32 %t350, 0
  br i1 %t351, label %bb107, label %ok.352
ok.352:
  store { i64, ptr } %t349, ptr %l218
  br label %bb106
bb106:
  %t353 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t353, ptr %l215, !tbaa !27
  br label %bb111
bb107:
  %t354 = load i32, ptr %l219, !tbaa !23
  %t355 = ashr i32 %t354, 16
  %t357 = icmp eq i32 %t355, 1
  br i1 %t357, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_df8ec41a37771c46_862f0a7f5985226a)
  unreachable
bb110:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s27)
  br label %bb123
bb111:
  %t359 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t359, ptr %l39, !tbaa !27
  %t360 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t360, 0
  store i64 %t362, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s28
  %t364 = load i64, ptr %l41, !tbaa !24
  %t365 = load i64, ptr %l40, !tbaa !24
  %t368 = icmp slt i64 %t364, %t365
  %t370 = xor i1 %t368, true
  br i1 %t370, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s28)
  br label %bb121
bb114:
  br label %bb115
bb115:
  %t372 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t372, ptr %l228, !tbaa !27
  %t373 = load i64, ptr %l41, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr %"compiler/views:naming", ptr %t376, i64 %t373
  %t378 = load %"compiler/views:naming", ptr %t377
  store %"compiler/views:naming" %t378, ptr %l42
  %t380 = getelementptr %"compiler/views:naming", ptr %l42, i32 0, i32 0
  %t381 = load i64, ptr %t380, !tbaa !24
  %t382 = load i64, ptr %l34, !tbaa !24
  %t385 = icmp eq i64 %t381, %t382
  br i1 %t385, label %bb116, label %bb117
bb116:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i64, ptr %l34, !tbaa !24
  %t389 = getelementptr %"compiler/views:naming", ptr %l42, i32 0, i32 1
  %t390 = load %"compiler/views:place", ptr %t389
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t387, i64 %t388, %"compiler/views:place" %t390)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s28)
  br label %bb120
bb120:
  %t394 = load i64, ptr %l41, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l41, !tbaa !24
  br label %bb112
bb121:
  %t398 = load i64, ptr %l38, !tbaa !24
  %t399 = load i64, ptr %l40, !tbaa !24
  %t402 = add i64 %t398, %t399
  store i64 %t402, ptr %l38, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb122
bb122:
  br label %bb105
bb123:
  %t404 = load i64, ptr %l34, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/views:state", ptr %t406, i32 0, i32 3
  %t412 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t408, i64 %t404)
  store i1 %t412, ptr %l246
  br label %bb124
bb124:
  %t413 = load i1, ptr %l246, !tbaa !21
  %t414 = xor i1 %t413, true
  br i1 %t414, label %bb125, label %bb126
bb125:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/views:state", ptr %t416, i32 0, i32 3
  %t419 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t418, i64 %t419)
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s23)
  br label %bb129
bb129:
  %t422 = load i64, ptr %l33, !tbaa !24
  %t424 = add i64 %t422, 1
  store i64 %t424, ptr %l33, !tbaa !24
  br label %bb89
bb130:
  %t426 = load i64, ptr %l30, !tbaa !24
  %t427 = load i64, ptr %l32, !tbaa !24
  %t430 = add i64 %t426, %t427
  store i64 %t430, ptr %l30, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb131
bb131:
  br label %bb82
bb132:
  %t432 = load ptr, ptr %l1, !tbaa !29
  %t434 = getelementptr %"compiler/views:state", ptr %t432, i32 0, i32 4
  store ptr %t434, ptr %l44, !tbaa !29
  store i64 0, ptr %l45, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s34
  %t436 = load ptr, ptr %l44, !tbaa !29
  %t437 = load i64, ptr %l45, !tbaa !24
  %t440 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v1, ptr %t436, i64 %t437)
  %t441 = extractvalue { i32, { i64, ptr } } %t440, 1
  %t442 = extractvalue { i32, { i64, ptr } } %t440, 0
  store i32 %t442, ptr %l262
  %t443 = icmp ne i32 %t442, 0
  br i1 %t443, label %bb135, label %ok.444
ok.444:
  store { i64, ptr } %t441, ptr %l261
  br label %bb134
bb134:
  %t445 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t445, ptr %l258, !tbaa !27
  br label %bb139
bb135:
  %t446 = load i32, ptr %l262, !tbaa !23
  %t447 = ashr i32 %t446, 16
  %t449 = icmp eq i32 %t447, 1
  br i1 %t449, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_9d06bf101433075d_cc12e0b15fe44e81)
  unreachable
bb138:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s34)
  br label %bb177
bb139:
  %t451 = load { i64, ptr }, ptr %l258, !tbaa !27
  store { i64, ptr } %t451, ptr %l46, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s35
  %t456 = load i64, ptr %l48, !tbaa !24
  %t457 = load i64, ptr %l47, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s35)
  br label %bb175
bb142:
  br label %bb143
bb143:
  %t464 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t464, ptr %l271, !tbaa !27
  %t465 = load i64, ptr %l48, !tbaa !24
  %t467 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr %"compiler/views:tasked", ptr %t468, i64 %t465
  %t470 = load %"compiler/views:tasked", ptr %t469
  store %"compiler/views:tasked" %t470, ptr %l49
  store i1 false, ptr %l50, !tbaa !21
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/views:state", ptr %t472, i32 0, i32 4
  store ptr %t474, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s37
  %t476 = load ptr, ptr %l51, !tbaa !29
  %t477 = load i64, ptr %l52, !tbaa !24
  %t480 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v0, ptr %t476, i64 %t477)
  %t481 = extractvalue { i32, { i64, ptr } } %t480, 1
  %t482 = extractvalue { i32, { i64, ptr } } %t480, 0
  store i32 %t482, ptr %l280
  %t483 = icmp ne i32 %t482, 0
  br i1 %t483, label %bb146, label %ok.484
ok.484:
  store { i64, ptr } %t481, ptr %l279
  br label %bb145
bb145:
  %t485 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t485, ptr %l276, !tbaa !27
  br label %bb150
bb146:
  %t486 = load i32, ptr %l280, !tbaa !23
  %t487 = ashr i32 %t486, 16
  %t489 = icmp eq i32 %t487, 1
  br i1 %t489, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_903e8fd86c5784ac_ce002315b538aaf0)
  unreachable
bb149:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s37)
  br label %bb169
bb150:
  %t491 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t491, ptr %l53, !tbaa !27
  %t492 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t492, 0
  store i64 %t494, ptr %l54, !tbaa !24
  store i64 0, ptr %l55, !tbaa !24
  br label %bb151
bb151:
  store %olang.scope zeroinitializer, ptr %s38
  %t496 = load i64, ptr %l55, !tbaa !24
  %t497 = load i64, ptr %l54, !tbaa !24
  %t500 = icmp slt i64 %t496, %t497
  %t502 = xor i1 %t500, true
  br i1 %t502, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s38)
  br label %bb167
bb153:
  br label %bb154
bb154:
  %t504 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t504, ptr %l289, !tbaa !27
  %t505 = load i64, ptr %l55, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr %"compiler/views:tasked", ptr %t508, i64 %t505
  %t510 = load %"compiler/views:tasked", ptr %t509
  store %"compiler/views:tasked" %t510, ptr %l56
  %t512 = getelementptr %"compiler/views:tasked", ptr %l56, i32 0, i32 0
  %t513 = getelementptr %"compiler/views:view", ptr %t512, i32 0, i32 1
  %t514 = load i64, ptr %t513, !tbaa !24
  %t515 = getelementptr %"compiler/views:tasked", ptr %l49, i32 0, i32 0
  %t516 = getelementptr %"compiler/views:view", ptr %t515, i32 0, i32 1
  %t517 = load i64, ptr %t516, !tbaa !24
  %t520 = icmp eq i64 %t514, %t517
  br i1 %t520, label %bb155, label %bb156
bb155:
  %t522 = getelementptr %"compiler/views:tasked", ptr %l56, i32 0, i32 1
  %t523 = load %"compiler/source:Span", ptr %t522
  store %"compiler/source:Span" %t523, ptr %l296
  %t524 = getelementptr %"compiler/views:tasked", ptr %l49, i32 0, i32 1
  %t525 = load %"compiler/source:Span", ptr %t524
  store %"compiler/source:Span" %t525, ptr %l298
  %t528 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l296, ptr %l298)
  store i1 %t528, ptr %l300
  br label %bb157
bb156:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb158
bb157:
  %t529 = load i1, ptr %l300, !tbaa !21
  store i1 %t529, ptr %l295, !tbaa !21
  br label %bb158
bb158:
  %t530 = load i1, ptr %l295, !tbaa !21
  br i1 %t530, label %bb159, label %bb160
bb159:
  %t531 = getelementptr %"compiler/views:tasked", ptr %l56, i32 0, i32 0
  %t532 = getelementptr %"compiler/views:view", ptr %t531, i32 0, i32 0
  %t533 = load %"compiler/views:place", ptr %t532
  store %"compiler/views:place" %t533, ptr %l302
  %t534 = getelementptr %"compiler/views:tasked", ptr %l49, i32 0, i32 0
  %t535 = getelementptr %"compiler/views:view", ptr %t534, i32 0, i32 0
  %t536 = load %"compiler/views:place", ptr %t535
  store %"compiler/views:place" %t536, ptr %l304
  %t539 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l302, ptr %l304)
  store i1 %t539, ptr %l306
  br label %bb161
bb160:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb162
bb161:
  %t540 = load i1, ptr %l306, !tbaa !21
  store i1 %t540, ptr %l301, !tbaa !21
  br label %bb162
bb162:
  %t541 = load i1, ptr %l301, !tbaa !21
  br i1 %t541, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb165
bb164:
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s38)
  br label %bb166
bb166:
  %t542 = load i64, ptr %l55, !tbaa !24
  %t544 = add i64 %t542, 1
  store i64 %t544, ptr %l55, !tbaa !24
  br label %bb151
bb167:
  %t546 = load i64, ptr %l52, !tbaa !24
  %t547 = load i64, ptr %l54, !tbaa !24
  %t550 = add i64 %t546, %t547
  store i64 %t550, ptr %l52, !tbaa !24
  call void @__olang_scope_close(ptr %s37)
  br label %bb168
bb168:
  br label %bb144
bb169:
  %t552 = load i1, ptr %l50, !tbaa !21
  %t554 = xor i1 %t552, true
  br i1 %t554, label %bb170, label %bb171
bb170:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/views:state", ptr %t556, i32 0, i32 4
  %t559 = load %"compiler/views:tasked", ptr %l49
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t558, %"compiler/views:tasked" %t559)
  br label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s35)
  br label %bb174
bb174:
  %t562 = load i64, ptr %l48, !tbaa !24
  %t564 = add i64 %t562, 1
  store i64 %t564, ptr %l48, !tbaa !24
  br label %bb140
bb175:
  %t566 = load i64, ptr %l45, !tbaa !24
  %t567 = load i64, ptr %l47, !tbaa !24
  %t570 = add i64 %t566, %t567
  store i64 %t570, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s34)
  br label %bb176
bb176:
  br label %bb133
bb177:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2enameAdd(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:place" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/views:place"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:naming"
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca %"compiler/views:place"
  %l33 = alloca %"compiler/views:place"
  %l35 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca %"compiler/views:naming"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/views:place" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_25801b76ce52b4c9_210407662c6a9fd)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb7:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/views:naming", ptr %t37, i64 %t34
  %t39 = load %"compiler/views:naming", ptr %t38
  store %"compiler/views:naming" %t39, ptr %l8
  %t41 = getelementptr %"compiler/views:naming", ptr %l8, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp eq i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = getelementptr %"compiler/views:naming", ptr %l8, i32 0, i32 1
  %t49 = load %"compiler/views:place", ptr %t48
  store %"compiler/views:place" %t49, ptr %l31
  %t50 = load %"compiler/views:place", ptr %l2
  store %"compiler/views:place" %t50, ptr %l33
  %t53 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l31, ptr %l33)
  store i1 %t53, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i1, ptr %l35, !tbaa !21
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb8
bb20:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  store i64 %t64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb1
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:state", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l42, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load %"compiler/views:place", ptr %l2
  %t73 = call %"compiler/views:naming" @compiler_2fviews_3anaming_2ector(ptr %s0, i64 %t69, %"compiler/views:place" %t70)
  store %"compiler/views:naming" %t73, ptr %l45
  br label %bb23
bb23:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load %"compiler/views:naming", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t74, %"compiler/views:naming" %t75)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2eplaceAdd(ptr %v0, ptr %a0, %"compiler/views:place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"compiler/views:place"
  %l27 = alloca %"compiler/views:place"
  %l29 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l13
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_305bccfacac998b3_c52e57f7500b9967)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/views:place", ptr %t35, i64 %t32
  %t37 = load %"compiler/views:place", ptr %t36
  store %"compiler/views:place" %t37, ptr %l25
  %t40 = load %"compiler/views:place", ptr %l1
  store %"compiler/views:place" %t40, ptr %l27
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l25, ptr %l27)
  store i1 %t43, ptr %l29
  br label %bb12
bb12:
  %t44 = load i1, ptr %l29, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/views:place", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t55, %"compiler/views:place" %t56)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eplaceEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i64
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l11
  br label %bb6
bb6:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb20
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb13
bb13:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb18
bb18:
  %t42 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f3a6d7e7b6ee655_a5694061fe6eb811)
  unreachable
bb20:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cc40afa1f47574c5_1b87777640286ce9)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fviews_2eunAway(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  store i64 16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l7, !tbaa !24
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 17
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l8, !tbaa !29
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t64 = load ptr, ptr %l8, !tbaa !29
  store ptr %t64, ptr %l1, !tbaa !29
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t66, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c6dbc1b994c66c62_e0c1acfc7721040e)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l6, !tbaa !24
  br label %bb7
bb23:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fviews_2eviewAdd(ptr %v0, ptr %a0, %"compiler/views:view" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:view"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:view"
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca %"compiler/views:view"
  %l41 = alloca i1
  %l42 = alloca %"compiler/views:place"
  %l44 = alloca %"compiler/views:place"
  %l46 = alloca i1
  %l49 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:view" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i64, ptr %l10, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = call %"compiler/views:view" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/views:view" %t55, ptr %l37
  br label %bb12
bb12:
  %t56 = load %"compiler/views:view", ptr %l37
  store %"compiler/views:view" %t56, ptr %l8
  %t57 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = icmp ne i64 %t58, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb16
bb14:
  %t65 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 0
  %t66 = load %"compiler/views:place", ptr %t65
  store %"compiler/views:place" %t66, ptr %l42
  %t67 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 0
  %t68 = load %"compiler/views:place", ptr %t67
  store %"compiler/views:place" %t68, ptr %l44
  %t71 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l42, ptr %l44)
  store i1 %t71, ptr %l46
  br label %bb15
bb15:
  %t72 = load i1, ptr %l46, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l41, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t76 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 2
  %t80 = load i1, ptr %t79, !tbaa !21
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l49, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load %"compiler/views:view", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eSetAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t85, i64 %t86, %"compiler/views:view" %t87)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb27:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb8
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/views:view", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ePush_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t95, %"compiler/views:view" %t96)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eweight(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/views:holding"
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 4
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l13
  br label %bb4
bb4:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = add i64 1, %t12
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:state", ptr %t14, i32 0, i32 2
  %t18 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 2, %t19
  %t21 = load i64, ptr %l14, !tbaa !24
  %t23 = add i64 %t21, %t20
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/views:state", ptr %t24, i32 0, i32 3
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l22
  br label %bb6
bb6:
  %t29 = load i64, ptr %l19, !tbaa !24
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = add i64 %t29, %t30
  store i64 %t31, ptr %l1, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/views:state", ptr %t33, i32 0, i32 1
  store ptr %t35, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v0, ptr %t37, i64 %t38)
  %t42 = extractvalue { i32, { i64, ptr } } %t41, 1
  %t43 = extractvalue { i32, { i64, ptr } } %t41, 0
  store i32 %t43, ptr %l30
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb9, label %ok.45
ok.45:
  store { i64, ptr } %t42, ptr %l29
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  br label %bb13
bb9:
  %t47 = load i32, ptr %l30, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ca000a88a3496ac5_2f3dd4ec83ad4799)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb13:
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t52, ptr %l4, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr %"compiler/views:holding", ptr %t69, i64 %t66
  %t71 = load %"compiler/views:holding", ptr %t70
  store %"compiler/views:holding" %t71, ptr %l7
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = getelementptr %"compiler/views:holding", ptr %l7, i32 0, i32 1
  %t75 = getelementptr %"compiler/views:view", ptr %t74, i32 0, i32 2
  %t76 = load i1, ptr %t75, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  store i64 5, ptr %l44, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb20
bb20:
  %t78 = load i64, ptr %l44, !tbaa !24
  %t79 = add i64 3, %t78
  %t80 = load i64, ptr %l42, !tbaa !24
  %t82 = add i64 %t80, %t79
  store i64 %t82, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb14
bb22:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t88, %t89
  store i64 %t92, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb7
bb24:
  %t94 = load i64, ptr %l1, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"compiler/views:Viewer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l35
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l36
  br label %bb3
bb3:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l6
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l37
  br label %bb4
bb4:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l7
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l38
  br label %bb5
bb5:
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l8
  store i64 -1, ptr %l9, !tbaa !24
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l39
  br label %bb6
bb6:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l10
  %t17 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l40
  br label %bb7
bb7:
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l11
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l41
  br label %bb8
bb8:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l12
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l42
  br label %bb9
bb9:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l13
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l43
  br label %bb10
bb10:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l14
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l44
  br label %bb11
bb11:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l15
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l45
  br label %bb12
bb12:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l16
  %t29 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l46
  br label %bb13
bb13:
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l47
  br label %bb14
bb14:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l19
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l48
  br label %bb15
bb15:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l20
  store ptr null, ptr %l21, !tbaa !29
  store i64 -1, ptr %l22, !tbaa !24
  store i1 false, ptr %l23, !tbaa !21
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i1 false, ptr %l26, !tbaa !21
  %t35 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l49
  br label %bb16
bb16:
  %t36 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l27
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l50
  br label %bb17
bb17:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l28
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l51
  br label %bb18
bb18:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l29
  %t41 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l52
  br label %bb19
bb19:
  %t42 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l30
  %t43 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l53
  br label %bb20
bb20:
  %t44 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  %t45 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 0
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %t45, !tbaa !29
  %t47 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 1
  %t48 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %t47
  %t49 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 2
  %t50 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %t49
  %t51 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 3
  %t52 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %t51
  %t53 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 4
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t53
  %t55 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 5
  %t56 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %t55
  %t57 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 6
  %t58 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %t57
  %t59 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 7
  %t60 = load i64, ptr %l9, !tbaa !24
  store i64 %t60, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 8
  %t62 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %t61
  %t63 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 9
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t63
  %t65 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 10
  %t66 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t65
  %t67 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 11
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t67
  %t69 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 12
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %t69
  %t71 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 13
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %t71
  %t73 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 14
  %t74 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t73
  %t75 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 15
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t75
  %t77 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 16
  %t78 = load i64, ptr %l18, !tbaa !24
  store i64 %t78, ptr %t77, !tbaa !24
  %t79 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 17
  %t80 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %t79
  %t81 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 18
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t81
  %t83 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 19
  %t84 = load ptr, ptr %l21, !tbaa !29
  store ptr %t84, ptr %t83, !tbaa !29
  %t85 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 20
  %t86 = load i64, ptr %l22, !tbaa !24
  store i64 %t86, ptr %t85, !tbaa !24
  %t87 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 21
  %t88 = load i1, ptr %l23, !tbaa !21
  store i1 %t88, ptr %t87, !tbaa !21
  %t89 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 22
  %t90 = load i1, ptr %l24, !tbaa !21
  store i1 %t90, ptr %t89, !tbaa !21
  %t91 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 23
  %t92 = load i1, ptr %l25, !tbaa !21
  store i1 %t92, ptr %t91, !tbaa !21
  %t93 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 24
  %t94 = load i1, ptr %l26, !tbaa !21
  store i1 %t94, ptr %t93, !tbaa !21
  %t95 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 25
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t95
  %t97 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 26
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %t97
  %t99 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 27
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 28
  %t102 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t101
  %t103 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %t103
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l54, i64 216, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5, i64 %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %rv = alloca %"compiler/views:fact"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/views:fact" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/views:fact" %t18, i64 %a1, 1
  %t22 = insertvalue %"compiler/views:fact" %t20, i32 %a2, 2
  %t24 = insertvalue %"compiler/views:fact" %t22, i64 %a3, 3
  %t26 = insertvalue %"compiler/views:fact" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/views:fact" %t26, i1 %a5, 5
  %t30 = insertvalue %"compiler/views:fact" %t28, i64 %a6, 6
  %t32 = insertvalue %"compiler/views:fact" %t30, %"compiler/source:Span" %a7, 7
  %t34 = insertvalue %"compiler/views:fact" %t32, i64 -1, 8
  store %"compiler/views:fact" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:fact", ptr %rv
  ret %"compiler/views:fact" %rr
}

define dso_local %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %v0, i64 %a0, %"compiler/views:view" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:holding"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:holding" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/views:holding" %t6, %"compiler/views:view" %a1, 1
  store %"compiler/views:holding" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:holding", ptr %rv
  ret %"compiler/views:holding" %rr
}

define dso_local %"compiler/views:loopFrame" @compiler_2fviews_3aloopFrame_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:loopFrame"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l1, !tbaa !23
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = insertvalue %"compiler/views:loopFrame" undef, i32 %t7, 0
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t10 = insertvalue %"compiler/views:loopFrame" %t8, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 1
  %t12 = insertvalue %"compiler/views:loopFrame" %t10, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, 2
  store %"compiler/views:loopFrame" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:loopFrame", ptr %rv
  ret %"compiler/views:loopFrame" %rr
}

define dso_local %"compiler/views:naming" @compiler_2fviews_3anaming_2ector(ptr %v0, i64 %a0, %"compiler/views:place" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:naming"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:naming" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/views:naming" %t6, %"compiler/views:place" %a1, 1
  store %"compiler/views:naming" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:naming", ptr %rv
  ret %"compiler/views:naming" %rr
}

define dso_local %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %v0, { i64, [2 x i64] } %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/views:place"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/views:place" undef, { i64, [2 x i64] } %a0, 0
  %t12 = insertvalue %"compiler/views:place" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/views:place" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/views:place" %t14, i1 %a3, 3
  store %"compiler/views:place" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:place", ptr %rv
  ret %"compiler/views:place" %rr
}

define dso_local %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:state"
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l0, !tbaa !21
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l7
  br label %bb3
bb3:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t9 = load i1, ptr %l0, !tbaa !21
  %t10 = insertvalue %"compiler/views:state" undef, i1 %t9, 0
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t12 = insertvalue %"compiler/views:state" %t10, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 1
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/views:state" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 2
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t16 = insertvalue %"compiler/views:state" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 3
  %t18 = insertvalue %"compiler/views:state" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 4
  store %"compiler/views:state" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:state", ptr %rv
  ret %"compiler/views:state" %rr
}

define dso_local %"compiler/views:summary" @compiler_2fviews_3asummary_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:summary"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l6
  br label %bb2
bb2:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l7
  br label %bb3
bb3:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l8
  br label %bb4
bb4:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t10 = insertvalue %"compiler/views:summary" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 0
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t12 = insertvalue %"compiler/views:summary" %t10, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 1
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/views:summary" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 2
  %t16 = insertvalue %"compiler/views:summary" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 3
  %t18 = insertvalue %"compiler/views:summary" %t16, i1 false, 4
  store %"compiler/views:summary" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:summary", ptr %rv
  ret %"compiler/views:summary" %rr
}

define dso_local %"compiler/views:tasked" @compiler_2fviews_3atasked_2ector(ptr %v0, %"compiler/views:view" %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:tasked"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:tasked" undef, %"compiler/views:view" %a0, 0
  %t8 = insertvalue %"compiler/views:tasked" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/views:tasked" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:tasked", ptr %rv
  ret %"compiler/views:tasked" %rr
}

define dso_local %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %v0, %"compiler/views:place" %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"compiler/views:place"
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/views:view"
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/views:place" %a0, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t6, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  store i64 -1, ptr %l7, !tbaa !24
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load %"compiler/source:Span", ptr %l12
  %t9 = load %"compiler/views:place", ptr %l2
  %t10 = insertvalue %"compiler/views:view" undef, %"compiler/views:place" %t9, 0
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = insertvalue %"compiler/views:view" %t10, i64 %t11, 1
  %t13 = load i1, ptr %l4, !tbaa !21
  %t14 = insertvalue %"compiler/views:view" %t12, i1 %t13, 2
  %t15 = load %"compiler/source:Span", ptr %l5
  %t16 = insertvalue %"compiler/views:view" %t14, %"compiler/source:Span" %t15, 3
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = insertvalue %"compiler/views:view" %t16, i64 %t17, 4
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = insertvalue %"compiler/views:view" %t18, i64 %t19, 5
  %t22 = insertvalue %"compiler/views:view" %t20, %"compiler/source:Span" %t8, 6
  store %"compiler/views:view" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:view", ptr %rv
  ret %"compiler/views:view" %rr
}

declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d1 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/vec" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d3 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'Push'" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"vecState" }>, align 8
@.d7 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/vec" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 i64 4, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  %t68 = icmp eq i32 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d9 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a call through a function value" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d12 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a lambda" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/views:place", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/views:place", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:place", ptr %t9, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/views:place", ptr %t12, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp eq i64 %t11, %t14
  br i1 %t17, label %bb4, label %bb1
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/views:place", ptr %t19, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/views:place", ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = icmp eq i64 %t21, %t24
  br i1 %t27, label %bb5, label %bb1
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:place", ptr %t29, i32 0, i32 3
  %t31 = load i1, ptr %t30, !tbaa !21
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/views:place", ptr %t32, i32 0, i32 3
  %t34 = load i1, ptr %t33, !tbaa !21
  %t37 = icmp eq i1 %t31, %t34
  br i1 %t37, label %bb6, label %bb1
bb6:
  br label %bb7
bb7:
  %t39 = load i1, ptr %l2, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_a5e6daec8976db0_405389cf00db76ac = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3cbb6fb3b51c25bd_1e9ab5921d6290d1 = external constant [0 x i8]
@olang_loc_87083398c1f96e8c_18c50ee403fa2840 = external constant [0 x i8]
@olang_loc_b5f5b909b97f4b87_db04b2c3237782bb = external constant [0 x i8]
@olang_loc_8469b5ec09caec26_9b966bbb099df63a = external constant [0 x i8]
@olang_loc_f21fc7c42b27f081_20ede69b6f10d945 = external constant [0 x i8]
@olang_loc_293c6ab0a5c406c2_e9cd55f098635cb6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7c6f17176a51aa71_b3e719a904165ead = external constant [0 x i8]
@olang_loc_c1486460ddc03a29_b5b65c437008efc5 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_Hc36d700dbc0d7c55fb879f7e6bb38bd0(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_25fbb0065c7b3b5b_3189e80820eb64b7 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_55308b3b5a1f5c1_cb52dc999ec87de5 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f1fdfe9ad717b630_76506b271b9576b4 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
@olang_loc_bb5d94b92cb03aee_965554ec574ba44a = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0)
declare %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:holding" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_4fa08be5080f30fb_a534acff1333321f = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0)
@olang_loc_a1022307f3790c7a_3cd5ac67c586c79e = external constant [0 x i8]
@olang_loc_c9ea8b11de61d962_c452a48e933af9d6 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_50963a3b337a0d80_c66eda0c55543fe4 = external constant [0 x i8]
@olang_loc_f4d9265444485b3d_7f3b362071bb80f9 = external constant [0 x i8]
@olang_loc_1bacef8f79fa259f_b65daa57821eac43 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
@olang_loc_b34deef82c4dbb1e_7a61043bb66e64c2 = external constant [0 x i8]
@olang_loc_f56dc5f524947092_cf97541144f04b56 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H9aa2f94df86a2febe7e9c453722bc668(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_32ad0239e45c9a93_b06e8acfe17eaf77 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, %"compiler/views:place" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_4a2a6e3b3b101678_6265cdfc823cfbbc = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_44a8ae07879ec149_8b2f3e17da0f076d = external constant [0 x i8]
@olang_loc_76a82bee87fafbee_805dfafaf92c82da = external constant [0 x i8]
declare %"compiler/views:place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_ec5a55ed5d3c9caf_79dd336489dd21db = external constant [0 x i8]
@olang_loc_b4b39a7a8799bd74_cd2c4d49ead70ce0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_ad107d2d4e78d7a5_d0509a7597b390f1 = external constant [0 x i8]
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_6c927a3cb50e0c6a_17c3e17799f249e = external constant [0 x i8]
@olang_loc_1538af23905b892b_69db3eaec74b8f1f = external constant [0 x i8]
@olang_loc_a3500c8c48c46ea1_9f190e145f72346d = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_38f43db71f48b164_beb7f8d1a31792c8 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_66a9fc2455c15d42_1dde5b0b0f74f18e = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_57534b0b4c840b9f_734207cf536b370b = external constant [0 x i8]
@olang_loc_eef44a73fed7a11e_ba98d4574b3cccca = external constant [0 x i8]
@olang_loc_bd4e25d0ba8f3355_5d1878e7bdcf6d61 = external constant [0 x i8]
@olang_loc_788d78188ea51964_a780363d8c64d7d0 = external constant [0 x i8]
@olang_loc_9261c738df5c5703_df7f72a5455de2e7 = external constant [0 x i8]
@olang_loc_ce0fda4981aea582_2b2a2501d91dd806 = external constant [0 x i8]
@olang_loc_a471d4cd6a39e3a7_bf796cf0b70bcd93 = external constant [0 x i8]
@olang_loc_bf0f9cdbc99a00cc_873cbf0138bd5dc8 = external constant [0 x i8]
@olang_loc_9134020f70d092ba_383f6adc32770fa6 = external constant [0 x i8]
@olang_loc_960025b02095f4a2_7b552e5bb757722e = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0, %"compiler/views:fact" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hbdff57143197d3e3ce33a3087c05f7a0(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H10b97bb675358eb10150edb21083f11d(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_He143de49e62ad88ca82ea9d42e5a34cc(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hd7428d759783ef3a1a99ea96b3969ebe(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H63170323aaa56032a7f198353006b630(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_617a65436beb56f7_865c97eda452f2a3 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_80a32e84cf5cf2d6_d2f28a7009f6d1a2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d88fa77248fe9e33_2d427ecad2833217 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a9709b8d7599af1c_938b49c1f1943728 = external constant [0 x i8]
@olang_loc_5a02dfa0eab0974d_8c564576f095f5f9 = external constant [0 x i8]
@olang_loc_7a8d60d7f0d90b6_ecc0a280768e582 = external constant [0 x i8]
@olang_loc_ea9f86d593e82457_d31df71765169703 = external constant [0 x i8]
@olang_loc_87a52582f4438a40_b949a7f7145f5964 = external constant [0 x i8]
@olang_loc_8d7acc310dabf2d1_fe0a55af40497355 = external constant [0 x i8]
@olang_loc_155b02aaeb4da1a3_5b82cd4f01516287 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__He2aba1703ae07509d487434bdc4dbdab(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H9b6ab774c92f21a4ef5a53265d5b9504(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eRunFrom_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bafc93f6dfe0eed8_a0f473e6bdc32d74 = external constant [0 x i8]
@olang_loc_2a3f27cfff39c1a9_9951569984a247a5 = external constant [0 x i8]
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Haabd632b519baafc45866c30c5849be1(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2d854533e388acf3_9bd384635a298ef = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2a4a8b72a379b770_7cdc66c7220ef344 = external constant [0 x i8]
@olang_loc_b373ce5e6fb0acb1_b981b0fdcb20f7cd = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_dcfb2f8bfac0bc7f_4146aca391677efb = external constant [0 x i8]
@olang_loc_e4d7bfaf376e867e_92a843c67cd15a7a = external constant [0 x i8]
@olang_loc_2316851c574f2435_c433b61b556d3c11 = external constant [0 x i8]
@olang_loc_7b1b67136b76c79_188c2ea4ec84d8a5 = external constant [0 x i8]
@olang_loc_ee6babc37b5ada8_202f4bf225a5be74 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4e796811ab380d83_57d60764fb489daf = external constant [0 x i8]
@olang_loc_26b1312863f2c2c7_c8d66606dd24933b = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_52eb4a404ee8e2f2_daf885f9c5247eae = external constant [0 x i8]
@olang_loc_24f4045ab8cbf215_2ef83d27164e37c1 = external constant [0 x i8]
@olang_loc_40eaf25cbb0521a7_3d2a576ac0c8b0f3 = external constant [0 x i8]
@olang_loc_945ffbf6072962e3_f3ad5bbe10c5f487 = external constant [0 x i8]
@olang_loc_f83bd81acd9884e2_c22158a061119526 = external constant [0 x i8]
@olang_loc_5699d6f0b9487a4c_f8171e4e8a154888 = external constant [0 x i8]
@olang_loc_ef97709dce49d3b_530bdd1db1d3a0b7 = external constant [0 x i8]
@olang_loc_cf8b3001c30b10ba_435a3683731d1196 = external constant [0 x i8]
@olang_loc_528f79d8d6cfab51_d5690ebe94fe9aad = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0, %"compiler/views:tasked" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePo_H0db9b8972766e5b481cadc211ca24c07(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:state" %a1)
@olang_loc_1e57e3539652abf4_8f970453f904e310 = external constant [0 x i8]
@olang_loc_16b4c6065d31c625_db15f6d21a68dda1 = external constant [0 x i8]
@olang_loc_e04c74c796b3ea6e_c4eff31c835dc20a = external constant [0 x i8]
@olang_loc_55fe9ec66bf58b2f_2b15eb81744064b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eTrun_Hcf69da14cf76298bedfa6131a657bae8(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b3ceb71449c904f8_7e3a160ac7181fac = external constant [0 x i8]
@olang_loc_551fdf32d31d54b_8fb5917c27ba1e87 = external constant [0 x i8]
@olang_loc_c7909257994b910a_5e298e5e7805bf26 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a630935aa2e7253f_7098fd3403d75c2b = external constant [0 x i8]
@olang_loc_c9aa123fef6d1a3f_2cfdc9fada63f9db = external constant [0 x i8]
@olang_loc_fbef590508ae9827_444bd78203178143 = external constant [0 x i8]
@olang_loc_d673b6bd3b875b76_a50d9e4884ce91c2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H70427050a088bf1a66351c183cb6df24(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eCl_H0a9e00411db21d32682611ff4a2aedde(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_58304325d16d56e1_1ac2a884e74450d5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %v0, ptr %a0, %"compiler/views:holding" %a1)
@olang_loc_a298007ba002c150_d601faccbb5a36e4 = external constant [0 x i8]
@olang_loc_6e59d20d6709208b_b4c7cdbf7939291f = external constant [0 x i8]
@olang_loc_b5b09e955edab64a_4c68cd282b8cbe9e = external constant [0 x i8]
@olang_loc_f882b6801a6cfe65_db0a8f546b27139 = external constant [0 x i8]
@olang_loc_a380450d9739f734_de428b9b50328168 = external constant [0 x i8]
@olang_loc_4283dbd3668d18ac_9869995bfb9a4270 = external constant [0 x i8]
@olang_loc_7a5a13ecbea84e9b_d0d616c1e5cf6f4f = external constant [0 x i8]
@olang_loc_e23614535e762839_a3c52bd11c6a8cad = external constant [0 x i8]
@olang_loc_db6ebdbbbfbf616f_7fdbf604d525f173 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eClone_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eCle_Ha50b8ef86adef4ee8ec69eed192d557f(ptr %v0, ptr %a0)
@olang_loc_f7e0c2831b30450a_35c62a326669c166 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClear_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0)
@olang_loc_953a2c9bd6842121_4c37e734fd78df0d = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0, %"compiler/views:naming" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_49bb3a1db5202690_b516fb53c86045dc = external constant [0 x i8]
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_26ef299dad5cdbef_4a7142c0b9c90bab = external constant [0 x i8]
@olang_loc_14b5d885bc836b4b_caf3078777493f87 = external constant [0 x i8]
@olang_loc_d6f46cea289d270a_99670469c794e026 = external constant [0 x i8]
@olang_loc_ed1a709fbfa842a1_51b8be3172e619bd = external constant [0 x i8]
@olang_loc_a19b7e219e444810_9c0582167fc3628c = external constant [0 x i8]
@olang_loc_a65aecd2c2ee9227_2ed53f6634d29f2b = external constant [0 x i8]
@olang_loc_df8ec41a37771c46_862f0a7f5985226a = external constant [0 x i8]
@olang_loc_9d06bf101433075d_cc12e0b15fe44e81 = external constant [0 x i8]
@olang_loc_903e8fd86c5784ac_ce002315b538aaf0 = external constant [0 x i8]
@olang_loc_25801b76ce52b4c9_210407662c6a9fd = external constant [0 x i8]
@olang_loc_305bccfacac998b3_c52e57f7500b9967 = external constant [0 x i8]
@olang_loc_f3a6d7e7b6ee655_a5694061fe6eb811 = external constant [0 x i8]
@olang_loc_cc40afa1f47574c5_1b87777640286ce9 = external constant [0 x i8]
@olang_loc_c6dbc1b994c66c62_e0c1acfc7721040e = external constant [0 x i8]
declare %"compiler/views:view" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eSetAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:view" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ePush_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, %"compiler/views:view" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0)
@olang_loc_ca000a88a3496ac5_2f3dd4ec83ad4799 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
