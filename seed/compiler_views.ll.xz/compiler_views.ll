; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/views:summary" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/views:Viewer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/views:place" = type { { i64, [2 x i64] }, i64, i64, i1 }
%"compiler/views:state" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/views:holding" = type { i64, %"compiler/views:view" }
%"compiler/views:view" = type { %"compiler/views:place", i64, i1, %"compiler/source:Span", i64, i64, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/views:fact" = type { i64, i64, i32, i64, i64, i1, i64, %"compiler/source:Span", i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/views:tasked" = type { %"compiler/views:view", %"compiler/source:Span" }
%"compiler/views:loopFrame" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/views:naming" = type { i64, %"compiler/views:place" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
define dso_local ptr @compiler_2fviews_2eargPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fviews_2eunAway(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb10
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l5, !tbaa !29
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb16:
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t28, ptr %a1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l20 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Alt", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Alt", ptr %t37, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l34, !tbaa !27
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t64 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb14:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Arm", ptr %t77, i32 0, i32 2
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb18
bb18:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Arm", ptr %t84, i32 0, i32 3
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Arm", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t94, ptr %t95)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l126 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i1
  %l147 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l182 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l219 = alloca ptr
  %l220 = alloca i1
  %l233 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca i1
  %l257 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l283 = alloca i1
  %l299 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l322 = alloca ptr
  %l323 = alloca i1
  %l328 = alloca ptr
  %l329 = alloca i1
  %l341 = alloca { i64, ptr }
  %l349 = alloca ptr
  %l350 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca i1
  %l371 = alloca { i64, ptr }
  %l374 = alloca ptr
  %l375 = alloca i1
  %l384 = alloca ptr
  %l385 = alloca i1
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s49 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t6 = load ptr, ptr %l64, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l64, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l65, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l65, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t21 = load ptr, ptr %l70, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l70, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l71, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l71, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t36 = load ptr, ptr %l76, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l76, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l77, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l77, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  br label %bb17
bb17:
  br label %bb233
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t55 = load ptr, ptr %l84, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = load ptr, ptr %l84, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 5
  store i1 %t61, ptr %l85, !tbaa !21
  br label %bb20
bb20:
  %t62 = load i1, ptr %l85, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Promote", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  br label %bb24
bb24:
  br label %bb233
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t77 = load ptr, ptr %l93, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l93, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 6
  store i1 %t83, ptr %l94, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l94, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb57
bb30:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Call", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l5, !tbaa !29
  store ptr %t96, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t97 = load ptr, ptr %l101, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb31, label %bb32
bb31:
  %t100 = load ptr, ptr %l101, !tbaa !29
  %t101 = load i64, ptr %t100
  %t103 = icmp eq i64 %t101, 0
  store i1 %t103, ptr %l102, !tbaa !21
  br label %bb32
bb32:
  %t104 = load i1, ptr %l102, !tbaa !21
  br i1 %t104, label %bb33, label %bb34
bb33:
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr { i64, [1 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { i32 }, ptr %t107, i32 0, i32 0
  %t109 = load i32, ptr %t108
  store i32 %t109, ptr %l6, !tbaa !23
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  %t114 = sext i32 %t112 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t111, i64 %t114)
  br label %bb36
bb36:
  br label %bb49
bb37:
  %t117 = load ptr, ptr %l5, !tbaa !29
  store ptr %t117, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t118 = load ptr, ptr %l110, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb38, label %bb39
bb38:
  %t121 = load ptr, ptr %l110, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 2
  store i1 %t124, ptr %l111, !tbaa !21
  br label %bb39
bb39:
  %t125 = load i1, ptr %l111, !tbaa !21
  br i1 %t125, label %bb40, label %bb41
bb40:
  %t126 = load ptr, ptr %l5, !tbaa !29
  %t128 = getelementptr { i64, [1 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { ptr }, ptr %t128, i32 0, i32 0
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l7, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t133 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb49:
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t153 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t153, ptr %l126, !tbaa !27
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr ptr, ptr %t157, i64 %t154
  %t159 = load ptr, ptr %t158, !tbaa !39
  %t162 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t159, ptr %t162)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t165 = load i64, ptr %l9, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l9, !tbaa !24
  br label %bb50
bb56:
  br label %bb233
bb57:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t170 = load ptr, ptr %l133, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb58, label %bb59
bb58:
  %t173 = load ptr, ptr %l133, !tbaa !29
  %t174 = load i64, ptr %t173
  %t176 = icmp eq i64 %t174, 7
  store i1 %t176, ptr %l134, !tbaa !21
  br label %bb59
bb59:
  %t177 = load i1, ptr %l134, !tbaa !21
  br i1 %t177, label %bb60, label %bb61
bb60:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t180, i32 0, i32 2
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t184 = load ptr, ptr %l12, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Make", ptr %t184, i32 0, i32 2
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l15, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t193 = load i64, ptr %l14, !tbaa !24
  %t194 = load i64, ptr %l15, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb65:
  br label %bb66
bb66:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t201, ptr %l147, !tbaa !27
  %t202 = load i64, ptr %l14, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr ptr, ptr %t205, i64 %t202
  %t207 = load ptr, ptr %t206, !tbaa !39
  %t210 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t207, ptr %t210)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t213 = load i64, ptr %l14, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l14, !tbaa !24
  br label %bb63
bb69:
  %t217 = load ptr, ptr %l12, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Make", ptr %t217, i32 0, i32 3
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t221 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t220, ptr %t221)
  br label %bb70
bb70:
  br label %bb233
bb71:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t225 = load ptr, ptr %l157, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb72, label %bb73
bb72:
  %t228 = load ptr, ptr %l157, !tbaa !29
  %t229 = load i64, ptr %t228
  %t231 = icmp eq i64 %t229, 8
  store i1 %t231, ptr %l158, !tbaa !21
  br label %bb73
bb73:
  %t232 = load i1, ptr %l158, !tbaa !21
  br i1 %t232, label %bb74, label %bb75
bb74:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t235, i32 0, i32 2
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l17, !tbaa !29
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t239 = load ptr, ptr %l17, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Collect", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t242, ptr %t243)
  br label %bb77
bb77:
  %t246 = load ptr, ptr %l17, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Collect", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t250 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t249, ptr %t250)
  br label %bb78
bb78:
  br label %bb233
bb79:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t254 = load ptr, ptr %l169, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb80, label %bb81
bb80:
  %t257 = load ptr, ptr %l169, !tbaa !29
  %t258 = load i64, ptr %t257
  %t260 = icmp eq i64 %t258, 9
  store i1 %t260, ptr %l170, !tbaa !21
  br label %bb81
bb81:
  %t261 = load i1, ptr %l170, !tbaa !21
  br i1 %t261, label %bb82, label %bb83
bb82:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t264, i32 0, i32 4
  %t266 = load { i64, ptr }, ptr %t265
  store { i64, ptr } %t266, ptr %l18, !tbaa !27
  br label %bb84
bb83:
  br label %bb92
bb84:
  %t268 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t268, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  store i64 %t272, ptr %l21, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s18
  %t274 = load i64, ptr %l20, !tbaa !24
  %t275 = load i64, ptr %l21, !tbaa !24
  %t278 = icmp slt i64 %t274, %t275
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb87:
  br label %bb88
bb88:
  %t282 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t282, ptr %l182, !tbaa !27
  %t283 = load i64, ptr %l20, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr ptr, ptr %t286, i64 %t283
  %t288 = load ptr, ptr %t287, !tbaa !39
  %t291 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t288, ptr %t291)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb90
bb90:
  %t294 = load i64, ptr %l20, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l20, !tbaa !24
  br label %bb85
bb91:
  br label %bb233
bb92:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t299 = load ptr, ptr %l189, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb93, label %bb94
bb93:
  %t302 = load ptr, ptr %l189, !tbaa !29
  %t303 = load i64, ptr %t302
  %t305 = icmp eq i64 %t303, 10
  store i1 %t305, ptr %l190, !tbaa !21
  br label %bb94
bb94:
  %t306 = load i1, ptr %l190, !tbaa !21
  br i1 %t306, label %bb95, label %bb96
bb95:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t309, i32 0, i32 2
  %t311 = load ptr, ptr %t310
  store ptr %t311, ptr %l23, !tbaa !29
  br label %bb97
bb96:
  br label %bb101
bb97:
  %t313 = load ptr, ptr %l23, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Slice", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t316, ptr %t317)
  br label %bb98
bb98:
  %t320 = load ptr, ptr %l23, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Slice", ptr %t320, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t324 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t323, ptr %t324)
  br label %bb99
bb99:
  %t327 = load ptr, ptr %l23, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Slice", ptr %t327, i32 0, i32 2
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t331 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t330, ptr %t331)
  br label %bb100
bb100:
  br label %bb233
bb101:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t335 = load ptr, ptr %l204, !tbaa !29
  %t336 = icmp ne ptr %t335, null
  br i1 %t336, label %bb102, label %bb103
bb102:
  %t338 = load ptr, ptr %l204, !tbaa !29
  %t339 = load i64, ptr %t338
  %t341 = icmp eq i64 %t339, 11
  store i1 %t341, ptr %l205, !tbaa !21
  br label %bb103
bb103:
  %t342 = load i1, ptr %l205, !tbaa !21
  br i1 %t342, label %bb104, label %bb105
bb104:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr { i64, [5 x i64] }, ptr %t343, i32 0, i32 1
  %t346 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t345, i32 0, i32 2
  %t347 = load ptr, ptr %t346
  store ptr %t347, ptr %l24, !tbaa !29
  br label %bb106
bb105:
  br label %bb110
bb106:
  %t349 = load ptr, ptr %l24, !tbaa !29
  %t351 = getelementptr %"compiler/typed:Cond", ptr %t349, i32 0, i32 0
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t353 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t352, ptr %t353)
  br label %bb107
bb107:
  %t356 = load ptr, ptr %l24, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Cond", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t359, ptr %t360)
  br label %bb108
bb108:
  %t363 = load ptr, ptr %l24, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Cond", ptr %t363, i32 0, i32 2
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t367 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t366, ptr %t367)
  br label %bb109
bb109:
  br label %bb233
bb110:
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t371 = load ptr, ptr %l219, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb111, label %bb112
bb111:
  %t374 = load ptr, ptr %l219, !tbaa !29
  %t375 = load i64, ptr %t374
  %t377 = icmp eq i64 %t375, 12
  store i1 %t377, ptr %l220, !tbaa !21
  br label %bb112
bb112:
  %t378 = load i1, ptr %l220, !tbaa !21
  br i1 %t378, label %bb113, label %bb114
bb113:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t381, i32 0, i32 2
  %t383 = load ptr, ptr %t382
  store ptr %t383, ptr %l25, !tbaa !29
  br label %bb115
bb114:
  br label %bb124
bb115:
  %t385 = load ptr, ptr %l25, !tbaa !29
  %t387 = getelementptr %"compiler/typed:Seq", ptr %t385, i32 0, i32 0
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  store { i64, ptr } %t388, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t390 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 0
  store i64 %t392, ptr %l28, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s24
  %t394 = load i64, ptr %l27, !tbaa !24
  %t395 = load i64, ptr %l28, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s24)
  br label %bb122
bb118:
  br label %bb119
bb119:
  %t402 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t402, ptr %l233, !tbaa !27
  %t403 = load i64, ptr %l27, !tbaa !24
  %t405 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = getelementptr ptr, ptr %t406, i64 %t403
  %t408 = load ptr, ptr %t407, !tbaa !39
  %t411 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t408, ptr %t411)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s24)
  br label %bb121
bb121:
  %t414 = load i64, ptr %l27, !tbaa !24
  %t416 = add i64 %t414, 1
  store i64 %t416, ptr %l27, !tbaa !24
  br label %bb116
bb122:
  %t418 = load ptr, ptr %l25, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Seq", ptr %t418, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t422 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t421, ptr %t422)
  br label %bb123
bb123:
  br label %bb233
bb124:
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t426 = load ptr, ptr %l243, !tbaa !29
  %t427 = icmp ne ptr %t426, null
  br i1 %t427, label %bb125, label %bb126
bb125:
  %t429 = load ptr, ptr %l243, !tbaa !29
  %t430 = load i64, ptr %t429
  %t432 = icmp eq i64 %t430, 13
  store i1 %t432, ptr %l244, !tbaa !21
  br label %bb126
bb126:
  %t433 = load i1, ptr %l244, !tbaa !21
  br i1 %t433, label %bb127, label %bb128
bb127:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr { i64, [5 x i64] }, ptr %t434, i32 0, i32 1
  %t437 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t436, i32 0, i32 2
  %t438 = load ptr, ptr %t437
  store ptr %t438, ptr %l30, !tbaa !29
  br label %bb129
bb128:
  br label %bb145
bb129:
  %t440 = load ptr, ptr %l30, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Match", ptr %t440, i32 0, i32 0
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  store { i64, ptr } %t443, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t445, 0
  store i64 %t447, ptr %l33, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s28
  %t449 = load i64, ptr %l32, !tbaa !24
  %t450 = load i64, ptr %l33, !tbaa !24
  %t453 = icmp slt i64 %t449, %t450
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s28)
  br label %bb136
bb132:
  br label %bb133
bb133:
  %t457 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t457, ptr %l257, !tbaa !27
  %t458 = load i64, ptr %l32, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr ptr, ptr %t461, i64 %t458
  %t463 = load ptr, ptr %t462, !tbaa !39
  %t466 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %t463, ptr %t466)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s28)
  br label %bb135
bb135:
  %t469 = load i64, ptr %l32, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l32, !tbaa !24
  br label %bb130
bb136:
  %t473 = load ptr, ptr %l30, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Match", ptr %t473, i32 0, i32 1
  %t476 = load { i64, ptr }, ptr %t475, !tbaa !27
  store { i64, ptr } %t476, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t478, 0
  store i64 %t480, ptr %l37, !tbaa !24
  br label %bb137
bb137:
  store %olang.scope zeroinitializer, ptr %s31
  %t482 = load i64, ptr %l36, !tbaa !24
  %t483 = load i64, ptr %l37, !tbaa !24
  %t486 = icmp slt i64 %t482, %t483
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s31)
  br label %bb143
bb139:
  br label %bb140
bb140:
  %t490 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t490, ptr %l272, !tbaa !27
  %t491 = load i64, ptr %l36, !tbaa !24
  %t493 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr ptr, ptr %t494, i64 %t491
  %t496 = load ptr, ptr %t495, !tbaa !39
  %t499 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %t496, ptr %t499)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s31)
  br label %bb142
bb142:
  %t502 = load i64, ptr %l36, !tbaa !24
  %t504 = add i64 %t502, 1
  store i64 %t504, ptr %l36, !tbaa !24
  br label %bb137
bb143:
  %t506 = load ptr, ptr %l30, !tbaa !29
  %t508 = getelementptr %"compiler/typed:Match", ptr %t506, i32 0, i32 2
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t510 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsArm(ptr %v0, ptr %v1, ptr %t509, ptr %t510)
  br label %bb144
bb144:
  br label %bb233
bb145:
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l282, !tbaa !29
  store i1 false, ptr %l283, !tbaa !21
  %t514 = load ptr, ptr %l282, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  br i1 %t515, label %bb146, label %bb147
bb146:
  %t517 = load ptr, ptr %l282, !tbaa !29
  %t518 = load i64, ptr %t517
  %t520 = icmp eq i64 %t518, 14
  store i1 %t520, ptr %l283, !tbaa !21
  br label %bb147
bb147:
  %t521 = load i1, ptr %l283, !tbaa !21
  br i1 %t521, label %bb148, label %bb149
bb148:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t524 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  %t525 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t524, i32 0, i32 2
  %t526 = load ptr, ptr %t525
  store ptr %t526, ptr %l39, !tbaa !29
  br label %bb150
bb149:
  br label %bb166
bb150:
  %t528 = load ptr, ptr %l39, !tbaa !29
  %t530 = getelementptr %"compiler/typed:Try", ptr %t528, i32 0, i32 0
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t532 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t531, ptr %t532)
  br label %bb151
bb151:
  %t535 = load ptr, ptr %l39, !tbaa !29
  %t537 = getelementptr %"compiler/typed:Try", ptr %t535, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l42, !tbaa !24
  br label %bb152
bb152:
  store %olang.scope zeroinitializer, ptr %s35
  %t544 = load i64, ptr %l41, !tbaa !24
  %t545 = load i64, ptr %l42, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s35)
  br label %bb165
bb154:
  br label %bb155
bb155:
  %t552 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t552, ptr %l299, !tbaa !27
  %t553 = load i64, ptr %l41, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  store ptr %t558, ptr %l43, !tbaa !29
  %t560 = load ptr, ptr %l43, !tbaa !29
  %t562 = getelementptr %"compiler/typed:Clause", ptr %t560, i32 0, i32 3
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t564 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t563, ptr %t564)
  br label %bb156
bb156:
  %t567 = load ptr, ptr %l43, !tbaa !29
  %t569 = getelementptr %"compiler/typed:Clause", ptr %t567, i32 0, i32 4
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !27
  store { i64, ptr } %t570, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t572 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t572, 0
  store i64 %t574, ptr %l46, !tbaa !24
  br label %bb157
bb157:
  store %olang.scope zeroinitializer, ptr %s37
  %t576 = load i64, ptr %l45, !tbaa !24
  %t577 = load i64, ptr %l46, !tbaa !24
  %t580 = icmp slt i64 %t576, %t577
  %t582 = xor i1 %t580, true
  br i1 %t582, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s37)
  br label %bb163
bb159:
  br label %bb160
bb160:
  %t584 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t584, ptr %l313, !tbaa !27
  %t585 = load i64, ptr %l45, !tbaa !24
  %t587 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = getelementptr ptr, ptr %t588, i64 %t585
  %t590 = load ptr, ptr %t589, !tbaa !39
  %t593 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t590, ptr %t593)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s37)
  br label %bb162
bb162:
  %t596 = load i64, ptr %l45, !tbaa !24
  %t598 = add i64 %t596, 1
  store i64 %t598, ptr %l45, !tbaa !24
  br label %bb157
bb163:
  call void @__olang_scope_close(ptr %s35)
  br label %bb164
bb164:
  %t600 = load i64, ptr %l41, !tbaa !24
  %t602 = add i64 %t600, 1
  store i64 %t602, ptr %l41, !tbaa !24
  br label %bb152
bb165:
  br label %bb233
bb166:
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l322, !tbaa !29
  store i1 false, ptr %l323, !tbaa !21
  %t605 = load ptr, ptr %l322, !tbaa !29
  %t606 = icmp ne ptr %t605, null
  br i1 %t606, label %bb167, label %bb168
bb167:
  %t608 = load ptr, ptr %l322, !tbaa !29
  %t609 = load i64, ptr %t608
  %t611 = icmp eq i64 %t609, 15
  store i1 %t611, ptr %l323, !tbaa !21
  br label %bb168
bb168:
  %t612 = load i1, ptr %l323, !tbaa !21
  br i1 %t612, label %bb169, label %bb170
bb169:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr { i64, [5 x i64] }, ptr %t613, i32 0, i32 1
  %t616 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t615, i32 0, i32 2
  %t617 = load ptr, ptr %t616
  store ptr %t617, ptr %l48, !tbaa !29
  br label %bb171
bb170:
  br label %bb197
bb171:
  %t619 = load ptr, ptr %l48, !tbaa !29
  store ptr %t619, ptr %l328, !tbaa !29
  store i1 false, ptr %l329, !tbaa !21
  %t620 = load ptr, ptr %l328, !tbaa !29
  %t621 = icmp ne ptr %t620, null
  br i1 %t621, label %bb172, label %bb173
bb172:
  %t623 = load ptr, ptr %l328, !tbaa !29
  %t624 = load i64, ptr %t623
  %t626 = icmp eq i64 %t624, 1
  store i1 %t626, ptr %l329, !tbaa !21
  br label %bb173
bb173:
  %t627 = load i1, ptr %l329, !tbaa !21
  br i1 %t627, label %bb174, label %bb175
bb174:
  %t628 = load ptr, ptr %l48, !tbaa !29
  %t630 = getelementptr { i64, [4 x i64] }, ptr %t628, i32 0, i32 1
  %t631 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t630, i32 0, i32 1
  %t632 = load { i64, ptr }, ptr %t631
  store { i64, ptr } %t632, ptr %l49, !tbaa !27
  br label %bb176
bb175:
  br label %bb184
bb176:
  %t634 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t634, ptr %l50, !tbaa !27
  store i64 0, ptr %l51, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l52, !tbaa !24
  br label %bb177
bb177:
  store %olang.scope zeroinitializer, ptr %s43
  %t640 = load i64, ptr %l51, !tbaa !24
  %t641 = load i64, ptr %l52, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb178, label %bb179
bb178:
  call void @__olang_scope_close(ptr %s43)
  br label %bb183
bb179:
  br label %bb180
bb180:
  %t648 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t648, ptr %l341, !tbaa !27
  %t649 = load i64, ptr %l51, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  %t658 = getelementptr %"compiler/typed:Capture", ptr %t654, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !29
  %t660 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t659, ptr %t660)
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s43)
  br label %bb182
bb182:
  %t663 = load i64, ptr %l51, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l51, !tbaa !24
  br label %bb177
bb183:
  br label %bb196
bb184:
  %t667 = load ptr, ptr %l48, !tbaa !29
  store ptr %t667, ptr %l349, !tbaa !29
  store i1 false, ptr %l350, !tbaa !21
  %t668 = load ptr, ptr %l349, !tbaa !29
  %t669 = icmp ne ptr %t668, null
  br i1 %t669, label %bb185, label %bb186
bb185:
  %t671 = load ptr, ptr %l349, !tbaa !29
  %t672 = load i64, ptr %t671
  %t674 = icmp eq i64 %t672, 2
  store i1 %t674, ptr %l350, !tbaa !21
  br label %bb186
bb186:
  %t675 = load i1, ptr %l350, !tbaa !21
  br i1 %t675, label %bb187, label %bb188
bb187:
  %t676 = load ptr, ptr %l48, !tbaa !29
  %t678 = getelementptr { i64, [4 x i64] }, ptr %t676, i32 0, i32 1
  %t679 = getelementptr { i32, ptr, i32 }, ptr %t678, i32 0, i32 1
  %t680 = load ptr, ptr %t679
  store ptr %t680, ptr %l54, !tbaa !29
  br label %bb189
bb188:
  br label %bb191
bb189:
  %t682 = load ptr, ptr %l54, !tbaa !29
  %t683 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t682, ptr %t683)
  br label %bb190
bb190:
  br label %bb196
bb191:
  br i1 true, label %bb192, label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb196
bb195:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb196:
  br label %bb233
bb197:
  %t686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t686, ptr %l357, !tbaa !29
  store i1 false, ptr %l358, !tbaa !21
  %t687 = load ptr, ptr %l357, !tbaa !29
  %t688 = icmp ne ptr %t687, null
  br i1 %t688, label %bb198, label %bb199
bb198:
  %t690 = load ptr, ptr %l357, !tbaa !29
  %t691 = load i64, ptr %t690
  %t693 = icmp eq i64 %t691, 16
  store i1 %t693, ptr %l358, !tbaa !21
  br label %bb199
bb199:
  %t694 = load i1, ptr %l358, !tbaa !21
  br i1 %t694, label %bb200, label %bb201
bb200:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr { i64, [5 x i64] }, ptr %t695, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t697, i32 0, i32 2
  %t699 = load ptr, ptr %t698
  store ptr %t699, ptr %l55, !tbaa !29
  br label %bb202
bb201:
  br label %bb221
bb202:
  %t701 = load ptr, ptr %l55, !tbaa !29
  %t703 = getelementptr %"compiler/typed:Text", ptr %t701, i32 0, i32 0
  %t704 = load { i64, ptr }, ptr %t703, !tbaa !27
  store { i64, ptr } %t704, ptr %l56, !tbaa !27
  store i64 0, ptr %l57, !tbaa !24
  %t706 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t706, 0
  store i64 %t708, ptr %l58, !tbaa !24
  br label %bb203
bb203:
  store %olang.scope zeroinitializer, ptr %s49
  %t710 = load i64, ptr %l57, !tbaa !24
  %t711 = load i64, ptr %l58, !tbaa !24
  %t714 = icmp slt i64 %t710, %t711
  %t716 = xor i1 %t714, true
  br i1 %t716, label %bb204, label %bb205
bb204:
  call void @__olang_scope_close(ptr %s49)
  br label %bb220
bb205:
  br label %bb206
bb206:
  %t718 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t718, ptr %l371, !tbaa !27
  %t719 = load i64, ptr %l57, !tbaa !24
  %t721 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t722 = load ptr, ptr %t721, !tbaa !27
  %t723 = getelementptr ptr, ptr %t722, i64 %t719
  %t724 = load ptr, ptr %t723, !tbaa !39
  store ptr %t724, ptr %l59, !tbaa !29
  %t726 = load ptr, ptr %l59, !tbaa !29
  store ptr %t726, ptr %l374, !tbaa !29
  store i1 false, ptr %l375, !tbaa !21
  %t727 = load ptr, ptr %l374, !tbaa !29
  %t728 = icmp ne ptr %t727, null
  br i1 %t728, label %bb207, label %bb208
bb207:
  %t730 = load ptr, ptr %l374, !tbaa !29
  %t731 = load i64, ptr %t730
  %t733 = icmp eq i64 %t731, 1
  store i1 %t733, ptr %l375, !tbaa !21
  br label %bb208
bb208:
  %t734 = load i1, ptr %l375, !tbaa !21
  br i1 %t734, label %bb209, label %bb210
bb209:
  %t735 = load ptr, ptr %l59, !tbaa !29
  %t737 = getelementptr { i64, [2 x i64] }, ptr %t735, i32 0, i32 1
  %t738 = getelementptr { ptr }, ptr %t737, i32 0, i32 0
  %t739 = load ptr, ptr %t738
  store ptr %t739, ptr %l60, !tbaa !29
  br label %bb211
bb210:
  br label %bb213
bb211:
  %t741 = load ptr, ptr %l60, !tbaa !29
  %t742 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t741, ptr %t742)
  br label %bb212
bb212:
  br label %bb218
bb213:
  br i1 true, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb218
bb217:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb218:
  call void @__olang_scope_close(ptr %s49)
  br label %bb219
bb219:
  %t745 = load i64, ptr %l57, !tbaa !24
  %t747 = add i64 %t745, 1
  store i64 %t747, ptr %l57, !tbaa !24
  br label %bb203
bb220:
  br label %bb233
bb221:
  %t749 = load ptr, ptr %l0, !tbaa !29
  store ptr %t749, ptr %l384, !tbaa !29
  store i1 false, ptr %l385, !tbaa !21
  %t750 = load ptr, ptr %l384, !tbaa !29
  %t751 = icmp ne ptr %t750, null
  br i1 %t751, label %bb222, label %bb223
bb222:
  %t753 = load ptr, ptr %l384, !tbaa !29
  %t754 = load i64, ptr %t753
  %t756 = icmp eq i64 %t754, 17
  store i1 %t756, ptr %l385, !tbaa !21
  br label %bb223
bb223:
  %t757 = load i1, ptr %l385, !tbaa !21
  br i1 %t757, label %bb224, label %bb225
bb224:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t760 = getelementptr { i64, [5 x i64] }, ptr %t758, i32 0, i32 1
  %t761 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t760, i32 0, i32 2
  %t762 = load ptr, ptr %t761
  store ptr %t762, ptr %l61, !tbaa !29
  br label %bb226
bb225:
  br label %bb228
bb226:
  %t764 = load ptr, ptr %l61, !tbaa !29
  %t765 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t764, ptr %t765)
  br label %bb227
bb227:
  br label %bb233
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb233
bb232:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb233:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 3
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  br label %bb23
bb23:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Elem", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t76 = load ptr, ptr %l37, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Payload", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 6
  store i1 %t101, ptr %l47, !tbaa !21
  br label %bb34
bb34:
  %t102 = load i1, ptr %l47, !tbaa !21
  br i1 %t102, label %bb35, label %bb36
bb35:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t109 = load ptr, ptr %l6, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecallsStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l140 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l162 = alloca { i64, ptr }
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t6 = load ptr, ptr %l24, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l24, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l25, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb20
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l30, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l31, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb20
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t36 = load ptr, ptr %l36, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l36, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l37, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb20
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t51 = load ptr, ptr %l42, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l42, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 14
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l43, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [3 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb21
bb21:
  br label %bb106
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t70 = load ptr, ptr %l50, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = load ptr, ptr %l50, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 1
  store i1 %t76, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l51, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t80, i32 0, i32 1
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l3, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb28
bb28:
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t94, ptr %t95)
  br label %bb29
bb29:
  br label %bb106
bb30:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t99 = load ptr, ptr %l62, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l62, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l63, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", ptr }, ptr %t109, i32 0, i32 1
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/typed:If", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  br label %bb36
bb36:
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t122 = getelementptr %"compiler/typed:If", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb37
bb37:
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t129 = getelementptr %"compiler/typed:If", ptr %t127, i32 0, i32 2
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb38
bb38:
  br label %bb106
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t135 = load ptr, ptr %l77, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb40, label %bb41
bb40:
  %t138 = load ptr, ptr %l77, !tbaa !29
  %t139 = load i64, ptr %t138
  %t141 = icmp eq i64 %t139, 4
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb41
bb41:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb42, label %bb43
bb42:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t145, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l6, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [3 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t151, i32 0, i32 2
  %t153 = load ptr, ptr %t152
  store ptr %t153, ptr %l7, !tbaa !29
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t155 = load ptr, ptr %l6, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  br label %bb45
bb45:
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  br label %bb46
bb46:
  br label %bb106
bb47:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t164 = load ptr, ptr %l89, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb48, label %bb49
bb48:
  %t167 = load ptr, ptr %l89, !tbaa !29
  %t168 = load i64, ptr %t167
  %t170 = icmp eq i64 %t168, 9
  store i1 %t170, ptr %l90, !tbaa !21
  br label %bb49
bb49:
  %t171 = load i1, ptr %l90, !tbaa !21
  br i1 %t171, label %bb50, label %bb51
bb50:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t174, i32 0, i32 1
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l8, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t180, i32 0, i32 2
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l9, !tbaa !29
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t184 = load ptr, ptr %l8, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb53
bb53:
  %t188 = load ptr, ptr %l9, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t188, ptr %t189)
  br label %bb54
bb54:
  br label %bb106
bb55:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t193 = load ptr, ptr %l101, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb56, label %bb57
bb56:
  %t196 = load ptr, ptr %l101, !tbaa !29
  %t197 = load i64, ptr %t196
  %t199 = icmp eq i64 %t197, 8
  store i1 %t199, ptr %l102, !tbaa !21
  br label %bb57
bb57:
  %t200 = load i1, ptr %l102, !tbaa !21
  br i1 %t200, label %bb58, label %bb59
bb58:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr { i64, [3 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t203, i32 0, i32 2
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l10, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t207 = load ptr, ptr %l10, !tbaa !29
  %t208 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t207, ptr %t208)
  br label %bb61
bb61:
  br label %bb106
bb62:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t212 = load ptr, ptr %l109, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb63, label %bb64
bb63:
  %t215 = load ptr, ptr %l109, !tbaa !29
  %t216 = load i64, ptr %t215
  %t218 = icmp eq i64 %t216, 10
  store i1 %t218, ptr %l110, !tbaa !21
  br label %bb64
bb64:
  %t219 = load i1, ptr %l110, !tbaa !21
  br i1 %t219, label %bb65, label %bb66
bb65:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr { i64, [3 x i64] }, ptr %t220, i32 0, i32 1
  %t223 = getelementptr { %"compiler/source:Span", ptr }, ptr %t222, i32 0, i32 1
  %t224 = load ptr, ptr %t223
  store ptr %t224, ptr %l11, !tbaa !29
  br label %bb71
bb66:
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t227 = load ptr, ptr %l115, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb67, label %bb68
bb67:
  %t230 = load ptr, ptr %l115, !tbaa !29
  %t231 = load i64, ptr %t230
  %t233 = icmp eq i64 %t231, 11
  store i1 %t233, ptr %l116, !tbaa !21
  br label %bb68
bb68:
  %t234 = load i1, ptr %l116, !tbaa !21
  br i1 %t234, label %bb69, label %bb70
bb69:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t241 = load ptr, ptr %l11, !tbaa !29
  %t242 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t241, ptr %t242)
  br label %bb72
bb72:
  br label %bb106
bb73:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t246 = load ptr, ptr %l123, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb74, label %bb75
bb74:
  %t249 = load ptr, ptr %l123, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 12
  store i1 %t252, ptr %l124, !tbaa !21
  br label %bb75
bb75:
  %t253 = load i1, ptr %l124, !tbaa !21
  br i1 %t253, label %bb76, label %bb77
bb76:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr }, ptr %t256, i32 0, i32 1
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l12, !tbaa !29
  br label %bb78
bb77:
  br label %bb87
bb78:
  %t260 = load ptr, ptr %l12, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Join", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t263, ptr %t264)
  br label %bb79
bb79:
  %t267 = load ptr, ptr %l12, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Join", ptr %t267, i32 0, i32 2
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t272, 0
  store i64 %t274, ptr %l15, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s11
  %t276 = load i64, ptr %l14, !tbaa !24
  %t277 = load i64, ptr %l15, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb82:
  br label %bb83
bb83:
  %t284 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t284, ptr %l140, !tbaa !27
  %t285 = load i64, ptr %l14, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr ptr, ptr %t288, i64 %t285
  %t290 = load ptr, ptr %t289, !tbaa !39
  %t294 = getelementptr %"compiler/typed:Clause", ptr %t290, i32 0, i32 3
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t296 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v1, ptr %t295, ptr %t296)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb85:
  %t299 = load i64, ptr %l14, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l14, !tbaa !24
  br label %bb80
bb86:
  br label %bb106
bb87:
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t304 = load ptr, ptr %l148, !tbaa !29
  %t305 = icmp ne ptr %t304, null
  br i1 %t305, label %bb88, label %bb89
bb88:
  %t307 = load ptr, ptr %l148, !tbaa !29
  %t308 = load i64, ptr %t307
  %t310 = icmp eq i64 %t308, 13
  store i1 %t310, ptr %l149, !tbaa !21
  br label %bb89
bb89:
  %t311 = load i1, ptr %l149, !tbaa !21
  br i1 %t311, label %bb90, label %bb91
bb90:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", ptr }, ptr %t314, i32 0, i32 1
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l17, !tbaa !29
  br label %bb92
bb91:
  br label %bb101
bb92:
  %t318 = load ptr, ptr %l17, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Spawn", ptr %t318, i32 0, i32 0
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  store { i64, ptr } %t321, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t323 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t323, 0
  store i64 %t325, ptr %l20, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s15
  %t327 = load i64, ptr %l19, !tbaa !24
  %t328 = load i64, ptr %l20, !tbaa !24
  %t331 = icmp slt i64 %t327, %t328
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb99
bb95:
  br label %bb96
bb96:
  %t335 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t335, ptr %l162, !tbaa !27
  %t336 = load i64, ptr %l19, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t336
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t344 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsPlace(ptr %v0, ptr %v1, ptr %t341, ptr %t344)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s15)
  br label %bb98
bb98:
  %t347 = load i64, ptr %l19, !tbaa !24
  %t349 = add i64 %t347, 1
  store i64 %t349, ptr %l19, !tbaa !24
  br label %bb93
bb99:
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Spawn", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecallsExpr(ptr %v0, ptr %v1, ptr %t354, ptr %t355)
  br label %bb100
bb100:
  br label %bb106
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb106:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eRun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l62 = alloca { i64, ptr }
  %l80 = alloca i1
  %l87 = alloca i1
  %l100 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca %"compiler/views:summary"
  %l135 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i32
  %l151 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l172 = alloca i1
  %l178 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i64
  %l209 = alloca i64
  %l214 = alloca i64
  %l217 = alloca i64
  %l218 = alloca i64
  %l222 = alloca i64
  %l225 = alloca i1
  %l226 = alloca ptr
  %l228 = alloca ptr
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i1
  %l238 = alloca i64
  %l241 = alloca i64
  %l263 = alloca i64
  %l268 = alloca i64
  %l271 = alloca i64
  %l289 = alloca ptr
  %l293 = alloca i64
  %l299 = alloca i1
  %l307 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i64
  %l333 = alloca ptr
  %l337 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l53
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l52
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t20, ptr %l49, !tbaa !27
  br label %bb7
bb3:
  %t21 = load i32, ptr %l53, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb7:
  %t26 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t39, ptr %l62, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l6, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 4
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb13:
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 6
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp ne ptr %t57, null
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 5
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 4
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = load ptr, ptr %l6, !tbaa !29
  %t70 = getelementptr %"compiler/load:Module", ptr %t68, i32 0, i32 6
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/source:Source", ptr %t71, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t63, i64 %t67, { i64, ptr } %t74)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 2
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t81, { i64, ptr } { i64 4, ptr @.d8 })
  store i1 %t83, ptr %l80
  br label %bb19
bb19:
  %t84 = load i1, ptr %l80, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/views:Viewer", ptr %t85, i32 0, i32 6
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/load:Module", ptr %t88, i32 0, i32 4
  %t91 = load i64, ptr %t90, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t87, i64 %t91, i1 true)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t97, { i64, ptr } { i64 15, ptr @.d9 })
  store i1 %t99, ptr %l87
  br label %bb24
bb24:
  %t100 = load i1, ptr %l87, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/load:Module", ptr %t102, i32 0, i32 4
  %t105 = load i64, ptr %t104, !tbaa !24
  %t108 = getelementptr %"compiler/views:Viewer", ptr %t101, i32 0, i32 7
  store i64 %t105, ptr %t108, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l5, !tbaa !24
  br label %bb8
bb29:
  %t113 = load i64, ptr %l2, !tbaa !24
  %t114 = load i64, ptr %l4, !tbaa !24
  %t117 = add i64 %t113, %t114
  store i64 %t117, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  br label %bb1
bb31:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/views:Viewer", ptr %t119, i32 0, i32 7
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = icmp slt i64 %t122, 0
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t126, { i64, ptr } { i64 0, ptr @.d10 })
  store i64 %t128, ptr %l100
  br label %bb35
bb35:
  store i64 0, ptr %l7, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/views:Viewer", ptr %t129, i32 0, i32 1
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l103
  br label %bb36
bb36:
  %t134 = load i64, ptr %l103, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t136 = load i64, ptr %l7, !tbaa !24
  %t139 = icmp sgt i64 %t135, %t136
  br i1 %t139, label %bb37, label %bb38
bb37:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb42
bb39:
  %t145 = load i64, ptr %l8, !tbaa !24
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = sub i64 %t145, %t146
  %t150 = load i64, ptr %l9, !tbaa !24
  %t153 = add i64 %t149, %t150
  %t155 = sub i64 %t153, 1
  %t156 = load i64, ptr %l9, !tbaa !24
  %t159 = sdiv i64 %t155, %t156
  store i64 %t159, ptr %l110, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb41
bb41:
  %t161 = load i64, ptr %l110, !tbaa !24
  store i64 %t161, ptr %l107, !tbaa !24
  br label %bb42
bb42:
  %t162 = load i64, ptr %l107, !tbaa !24
  store i64 %t162, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  %t163 = load i64, ptr %l11, !tbaa !24
  %t164 = load i64, ptr %l10, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb70
bb45:
  br label %bb46
bb46:
  %t171 = load i64, ptr %l7, !tbaa !24
  %t172 = load i64, ptr %l11, !tbaa !24
  %t173 = load i64, ptr %l9, !tbaa !24
  %t176 = mul i64 %t172, %t173
  %t179 = add i64 %t171, %t176
  store i64 %t179, ptr %l12, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/views:Viewer", ptr %t181, i32 0, i32 2
  store ptr %t183, ptr %l129, !tbaa !29
  %t184 = call %"compiler/views:summary" @compiler_2fviews_3asummary_2ector(ptr %v0)
  store %"compiler/views:summary" %t184, ptr %l130
  br label %bb47
bb47:
  %t185 = load %"compiler/views:summary", ptr %l130
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/views:summary" %t185, ptr %t186
  %t187 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_Hc36d700dbc0d7c55fb879f7e6bb38bd0(ptr %v0, ptr %v0, ptr %t187, ptr %t186)
  br label %bb48
bb48:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/views:Viewer", ptr %t189, i32 0, i32 1
  %t192 = load i64, ptr %l12, !tbaa !24
  %t195 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t191, i64 %t192)
  store ptr %t195, ptr %l135
  br label %bb49
bb49:
  %t196 = load ptr, ptr %l135, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Body", ptr %t196, i32 0, i32 5
  store ptr %t198, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s13
  %t200 = load ptr, ptr %l13, !tbaa !29
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t200, i64 %t201)
  %t205 = extractvalue { i32, { i64, ptr } } %t204, 1
  %t206 = extractvalue { i32, { i64, ptr } } %t204, 0
  store i32 %t206, ptr %l142
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb52, label %ok.208
ok.208:
  store { i64, ptr } %t205, ptr %l141
  br label %bb51
bb51:
  %t209 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t209, ptr %l138, !tbaa !27
  br label %bb56
bb52:
  %t210 = load i32, ptr %l142, !tbaa !23
  %t211 = ashr i32 %t210, 16
  %t213 = icmp eq i32 %t211, 1
  br i1 %t213, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb66
bb56:
  %t215 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t215, ptr %l15, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 0
  store i64 %t218, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s14
  %t220 = load i64, ptr %l17, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s14)
  br label %bb64
bb59:
  br label %bb60
bb60:
  %t228 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t228, ptr %l151, !tbaa !27
  %t229 = load i64, ptr %l17, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i32, ptr %t232, i64 %t229
  %t234 = load i32, ptr %t233, !tbaa !33
  store i32 %t234, ptr %l18, !tbaa !23
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/views:Viewer", ptr %t236, i32 0, i32 2
  %t239 = load i64, ptr %l12, !tbaa !24
  %t242 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t238, i64 %t239)
  store ptr %t242, ptr %l157
  br label %bb61
bb61:
  %t243 = load ptr, ptr %l157, !tbaa !29
  %t245 = getelementptr %"compiler/views:summary", ptr %t243, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t245, i1 false)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb63:
  %t247 = load i64, ptr %l17, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l17, !tbaa !24
  br label %bb57
bb64:
  %t251 = load i64, ptr %l14, !tbaa !24
  %t252 = load i64, ptr %l16, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb65
bb65:
  br label %bb50
bb66:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/views:Viewer", ptr %t257, i32 0, i32 2
  %t260 = load i64, ptr %l12, !tbaa !24
  %t263 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t259, i64 %t260)
  store ptr %t263, ptr %l168
  br label %bb67
bb67:
  %t264 = load ptr, ptr %l168, !tbaa !29
  store ptr %t264, ptr %l169, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i64, ptr %l12, !tbaa !24
  %t269 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalkable(ptr %v0, ptr %t265, i64 %t266)
  store i1 %t269, ptr %l172
  br label %bb68
bb68:
  %t270 = load i1, ptr %l172, !tbaa !21
  %t271 = load ptr, ptr %l169, !tbaa !29
  %t272 = getelementptr %"compiler/views:summary", ptr %t271, i32 0, i32 4
  store i1 %t270, ptr %t272, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb69:
  %t273 = load i64, ptr %l11, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l11, !tbaa !24
  br label %bb43
bb70:
  %t277 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecomponents(ptr %v0, ptr %t277)
  br label %bb71
bb71:
  store i64 0, ptr %l19, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/views:Viewer", ptr %t279, i32 0, i32 17
  %t283 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t281)
  store i64 %t283, ptr %l178
  br label %bb72
bb72:
  %t284 = load i64, ptr %l178, !tbaa !24
  store i64 %t284, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t285 = load i64, ptr %l20, !tbaa !24
  %t286 = load i64, ptr %l19, !tbaa !24
  %t289 = icmp sgt i64 %t285, %t286
  br i1 %t289, label %bb73, label %bb74
bb73:
  %t291 = load i64, ptr %l21, !tbaa !24
  %t293 = icmp sgt i64 %t291, 0
  br i1 %t293, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb78
bb75:
  %t295 = load i64, ptr %l20, !tbaa !24
  %t296 = load i64, ptr %l19, !tbaa !24
  %t299 = sub i64 %t295, %t296
  %t300 = load i64, ptr %l21, !tbaa !24
  %t303 = add i64 %t299, %t300
  %t305 = sub i64 %t303, 1
  %t306 = load i64, ptr %l21, !tbaa !24
  %t309 = sdiv i64 %t305, %t306
  store i64 %t309, ptr %l185, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb77
bb77:
  %t311 = load i64, ptr %l185, !tbaa !24
  store i64 %t311, ptr %l182, !tbaa !24
  br label %bb78
bb78:
  %t312 = load i64, ptr %l182, !tbaa !24
  store i64 %t312, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t313 = load i64, ptr %l23, !tbaa !24
  %t314 = load i64, ptr %l22, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s18)
  br label %bb145
bb81:
  br label %bb82
bb82:
  %t321 = load i64, ptr %l19, !tbaa !24
  %t322 = load i64, ptr %l23, !tbaa !24
  %t323 = load i64, ptr %l21, !tbaa !24
  %t326 = mul i64 %t322, %t323
  %t329 = add i64 %t321, %t326
  store i64 %t329, ptr %l24, !tbaa !24
  %t331 = load i64, ptr %l24, !tbaa !24
  %t333 = add i64 %t331, 1
  store i64 %t333, ptr %l204, !tbaa !24
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/views:Viewer", ptr %t334, i32 0, i32 17
  %t338 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t336)
  store i64 %t338, ptr %l207
  br label %bb83
bb83:
  %t339 = load i64, ptr %l204, !tbaa !24
  %t340 = load i64, ptr %l207, !tbaa !24
  %t341 = icmp slt i64 %t339, %t340
  br i1 %t341, label %bb84, label %bb85
bb84:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/views:Viewer", ptr %t343, i32 0, i32 17
  %t346 = load i64, ptr %l24, !tbaa !24
  %t348 = add i64 %t346, 1
  %t351 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t345, i64 %t348)
  store i64 %t351, ptr %l214
  br label %bb86
bb85:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/views:Viewer", ptr %t352, i32 0, i32 18
  %t356 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t354)
  store i64 %t356, ptr %l217
  br label %bb87
bb86:
  %t357 = load i64, ptr %l214, !tbaa !24
  store i64 %t357, ptr %l209, !tbaa !24
  br label %bb88
bb87:
  %t358 = load i64, ptr %l217, !tbaa !24
  store i64 %t358, ptr %l209, !tbaa !24
  br label %bb88
bb88:
  %t359 = load i64, ptr %l209, !tbaa !24
  store i64 %t359, ptr %l25, !tbaa !24
  %t360 = load i64, ptr %l25, !tbaa !24
  store i64 %t360, ptr %l218, !tbaa !24
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/views:Viewer", ptr %t361, i32 0, i32 17
  %t364 = load i64, ptr %l24, !tbaa !24
  %t367 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t363, i64 %t364)
  store i64 %t367, ptr %l222
  br label %bb89
bb89:
  %t368 = load i64, ptr %l218, !tbaa !24
  %t369 = load i64, ptr %l222, !tbaa !24
  %t370 = sub i64 %t368, %t369
  %t372 = icmp sgt i64 %t370, 1
  br i1 %t372, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l225, !tbaa !21
  br label %bb95
bb91:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l226, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/views:Viewer", ptr %t375, i32 0, i32 18
  store ptr %t377, ptr %l228, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/views:Viewer", ptr %t378, i32 0, i32 17
  %t381 = load i64, ptr %l24, !tbaa !24
  %t384 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t380, i64 %t381)
  store i64 %t384, ptr %l232
  br label %bb92
bb92:
  %t385 = load ptr, ptr %l228, !tbaa !29
  %t386 = load i64, ptr %l232, !tbaa !24
  %t387 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t385, i64 %t386)
  store i64 %t387, ptr %l233
  br label %bb93
bb93:
  %t388 = load ptr, ptr %l226, !tbaa !29
  %t389 = load i64, ptr %l233, !tbaa !24
  %t390 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallsItself(ptr %v0, ptr %t388, i64 %t389)
  store i1 %t390, ptr %l234
  br label %bb94
bb94:
  %t391 = load i1, ptr %l234, !tbaa !21
  store i1 %t391, ptr %l225, !tbaa !21
  br label %bb95
bb95:
  %t392 = load i1, ptr %l225, !tbaa !21
  store i1 %t392, ptr %l26, !tbaa !21
  store i64 0, ptr %l27, !tbaa !24
  store i64 100, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t393 = load i64, ptr %l28, !tbaa !24
  %t394 = load i64, ptr %l27, !tbaa !24
  %t397 = icmp sgt i64 %t393, %t394
  br i1 %t397, label %bb96, label %bb97
bb96:
  %t399 = load i64, ptr %l29, !tbaa !24
  %t401 = icmp sgt i64 %t399, 0
  br i1 %t401, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb101
bb98:
  %t403 = load i64, ptr %l28, !tbaa !24
  %t404 = load i64, ptr %l27, !tbaa !24
  %t407 = sub i64 %t403, %t404
  %t408 = load i64, ptr %l29, !tbaa !24
  %t411 = add i64 %t407, %t408
  %t413 = sub i64 %t411, 1
  %t414 = load i64, ptr %l29, !tbaa !24
  %t417 = sdiv i64 %t413, %t414
  store i64 %t417, ptr %l241, !tbaa !24
  br label %bb100
bb99:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb100
bb100:
  %t419 = load i64, ptr %l241, !tbaa !24
  store i64 %t419, ptr %l238, !tbaa !24
  br label %bb101
bb101:
  %t420 = load i64, ptr %l238, !tbaa !24
  store i64 %t420, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s20
  %t421 = load i64, ptr %l31, !tbaa !24
  %t422 = load i64, ptr %l30, !tbaa !24
  %t425 = icmp slt i64 %t421, %t422
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s20)
  br label %bb128
bb104:
  br label %bb105
bb105:
  %t429 = load i64, ptr %l27, !tbaa !24
  %t430 = load i64, ptr %l31, !tbaa !24
  %t431 = load i64, ptr %l29, !tbaa !24
  %t434 = mul i64 %t430, %t431
  %t437 = add i64 %t429, %t434
  store i64 %t437, ptr %l32, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/views:Viewer", ptr %t439, i32 0, i32 24
  store i1 false, ptr %t441, !tbaa !21
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/views:Viewer", ptr %t442, i32 0, i32 17
  %t445 = load i64, ptr %l24, !tbaa !24
  %t448 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t444, i64 %t445)
  store i64 %t448, ptr %l263
  br label %bb106
bb106:
  %t449 = load i64, ptr %l263, !tbaa !24
  store i64 %t449, ptr %l33, !tbaa !24
  %t450 = load i64, ptr %l25, !tbaa !24
  store i64 %t450, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t452 = load i64, ptr %l34, !tbaa !24
  %t453 = load i64, ptr %l33, !tbaa !24
  %t456 = icmp sgt i64 %t452, %t453
  br i1 %t456, label %bb107, label %bb108
bb107:
  %t458 = load i64, ptr %l35, !tbaa !24
  %t460 = icmp sgt i64 %t458, 0
  br i1 %t460, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l268, !tbaa !24
  br label %bb112
bb109:
  %t462 = load i64, ptr %l34, !tbaa !24
  %t463 = load i64, ptr %l33, !tbaa !24
  %t466 = sub i64 %t462, %t463
  %t467 = load i64, ptr %l35, !tbaa !24
  %t470 = add i64 %t466, %t467
  %t472 = sub i64 %t470, 1
  %t473 = load i64, ptr %l35, !tbaa !24
  %t476 = sdiv i64 %t472, %t473
  store i64 %t476, ptr %l271, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l271, !tbaa !24
  br label %bb111
bb111:
  %t478 = load i64, ptr %l271, !tbaa !24
  store i64 %t478, ptr %l268, !tbaa !24
  br label %bb112
bb112:
  %t479 = load i64, ptr %l268, !tbaa !24
  store i64 %t479, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s22
  %t480 = load i64, ptr %l37, !tbaa !24
  %t481 = load i64, ptr %l36, !tbaa !24
  %t484 = icmp slt i64 %t480, %t481
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s22)
  br label %bb120
bb115:
  br label %bb116
bb116:
  %t488 = load i64, ptr %l33, !tbaa !24
  %t489 = load i64, ptr %l37, !tbaa !24
  %t490 = load i64, ptr %l35, !tbaa !24
  %t493 = mul i64 %t489, %t490
  %t496 = add i64 %t488, %t493
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l289, !tbaa !29
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/views:Viewer", ptr %t499, i32 0, i32 18
  %t505 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t501, i64 %t496)
  store i64 %t505, ptr %l293
  br label %bb117
bb117:
  %t506 = load ptr, ptr %l289, !tbaa !29
  %t507 = load i64, ptr %l293, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %t506, i64 %t507, i1 false)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s22)
  br label %bb119
bb119:
  %t508 = load i64, ptr %l37, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l37, !tbaa !24
  br label %bb113
bb120:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/views:Viewer", ptr %t512, i32 0, i32 24
  %t515 = load i1, ptr %t514, !tbaa !21
  %t517 = xor i1 %t515, true
  br i1 %t517, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l299, !tbaa !21
  br label %bb123
bb122:
  %t519 = load i1, ptr %l26, !tbaa !21
  %t521 = xor i1 %t519, true
  store i1 %t521, ptr %l299, !tbaa !21
  br label %bb123
bb123:
  %t523 = load i1, ptr %l299, !tbaa !21
  br i1 %t523, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s20)
  br label %bb128
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s20)
  br label %bb127
bb127:
  %t524 = load i64, ptr %l31, !tbaa !24
  %t526 = add i64 %t524, 1
  store i64 %t526, ptr %l31, !tbaa !24
  br label %bb102
bb128:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/views:Viewer", ptr %t528, i32 0, i32 17
  %t531 = load i64, ptr %l24, !tbaa !24
  %t534 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t530, i64 %t531)
  store i64 %t534, ptr %l307
  br label %bb129
bb129:
  %t535 = load i64, ptr %l307, !tbaa !24
  store i64 %t535, ptr %l39, !tbaa !24
  %t536 = load i64, ptr %l25, !tbaa !24
  store i64 %t536, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t538 = load i64, ptr %l40, !tbaa !24
  %t539 = load i64, ptr %l39, !tbaa !24
  %t542 = icmp sgt i64 %t538, %t539
  br i1 %t542, label %bb130, label %bb131
bb130:
  %t544 = load i64, ptr %l41, !tbaa !24
  %t546 = icmp sgt i64 %t544, 0
  br i1 %t546, label %bb132, label %bb133
bb131:
  store i64 0, ptr %l312, !tbaa !24
  br label %bb135
bb132:
  %t548 = load i64, ptr %l40, !tbaa !24
  %t549 = load i64, ptr %l39, !tbaa !24
  %t552 = sub i64 %t548, %t549
  %t553 = load i64, ptr %l41, !tbaa !24
  %t556 = add i64 %t552, %t553
  %t558 = sub i64 %t556, 1
  %t559 = load i64, ptr %l41, !tbaa !24
  %t562 = sdiv i64 %t558, %t559
  store i64 %t562, ptr %l315, !tbaa !24
  br label %bb134
bb133:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb134
bb134:
  %t564 = load i64, ptr %l315, !tbaa !24
  store i64 %t564, ptr %l312, !tbaa !24
  br label %bb135
bb135:
  %t565 = load i64, ptr %l312, !tbaa !24
  store i64 %t565, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s27
  %t566 = load i64, ptr %l43, !tbaa !24
  %t567 = load i64, ptr %l42, !tbaa !24
  %t570 = icmp slt i64 %t566, %t567
  %t572 = xor i1 %t570, true
  br i1 %t572, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s27)
  br label %bb143
bb138:
  br label %bb139
bb139:
  %t574 = load i64, ptr %l39, !tbaa !24
  %t575 = load i64, ptr %l43, !tbaa !24
  %t576 = load i64, ptr %l41, !tbaa !24
  %t579 = mul i64 %t575, %t576
  %t582 = add i64 %t574, %t579
  %t584 = load ptr, ptr %l0, !tbaa !29
  store ptr %t584, ptr %l333, !tbaa !29
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/views:Viewer", ptr %t585, i32 0, i32 18
  %t591 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t587, i64 %t582)
  store i64 %t591, ptr %l337
  br label %bb140
bb140:
  %t592 = load ptr, ptr %l333, !tbaa !29
  %t593 = load i64, ptr %l337, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %t592, i64 %t593, i1 true)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s27)
  br label %bb142
bb142:
  %t594 = load i64, ptr %l43, !tbaa !24
  %t596 = add i64 %t594, 1
  store i64 %t596, ptr %l43, !tbaa !24
  br label %bb136
bb143:
  call void @__olang_scope_close(ptr %s18)
  br label %bb144
bb144:
  %t598 = load i64, ptr %l23, !tbaa !24
  %t600 = add i64 %t598, 1
  store i64 %t600, ptr %l23, !tbaa !24
  br label %bb79
bb145:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i8 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i8
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i8 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i64 @compiler_2fviews_2eplaceEnd(ptr %v1, ptr %a2)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = icmp sle i64 %t5, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = icmp sge i64 %t14, %t18
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t24, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l20
  br label %bb8
bb8:
  %t31 = load i64, ptr %l20, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t32, i64 %t33)
  store i8 %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load i8, ptr %l3, !tbaa !22
  %t38 = load i8, ptr %l23, !tbaa !22
  %t40 = icmp ne i8 %t38, %t37
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t44 = load i8, ptr %l3, !tbaa !22
  %t46 = icmp eq i8 %t44, 46
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  %t55 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t49, i64 %t52)
  store i64 %t55, ptr %l33
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/source:Span" %t58, ptr %l34
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t59, ptr %rv
  br label %ret
bb17:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  %t67 = trunc i64 %t65 to i32
  %t70 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t62, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l40
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t71 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Arm", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l8, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Alt", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t28, ptr %t32, ptr %t33, ptr %l4)
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l39, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l12, !tbaa !29
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l42
  br label %bb11
bb11:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l13
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l12, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Bind", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s4, ptr %t65, ptr %t69, ptr %t70, ptr %l13)
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l12, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Bind", ptr %t76, i32 0, i32 0
  %t79 = load i32, ptr %t78, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t82 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %s4, ptr %s4, ptr %v2, ptr %t75, i64 %t81, ptr null, ptr %l13, i1 false, ptr %t82)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l10, !tbaa !24
  br label %bb7
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb2
bb17:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Arm", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t95, ptr %t99, ptr %t100, ptr %l4)
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Arm", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t105, ptr %t109, ptr %t110)
  br label %bb19
bb19:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Arm", ptr %t115, i32 0, i32 4
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t114, ptr %t118, ptr %t119, ptr %a3)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l8
  br label %bb2
bb2:
  store i32 19, ptr %l10
  %t17 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l8, ptr %l10)
  store i1 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca i1
  %l37 = alloca i1
  %l42 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca %"compiler/views:place"
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca %"compiler/views:place"
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca i64
  %l91 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l5, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t26 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %t20, i64 %t23)
  store i1 %t26, ptr %l25
  br label %bb9
bb9:
  %t27 = load i1, ptr %l25, !tbaa !21
  store i1 %t27, ptr %l6, !tbaa !21
  %t28 = load i1, ptr %l6, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %s3, ptr %v4, ptr %t30, ptr %t31, ptr null, ptr %t32)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t36, i64 %t39, ptr %a2, ptr %t41, i1 true, ptr %t42)
  br label %bb14
bb14:
  %t48 = load i1, ptr %l6, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t52 = load i32, ptr %l5, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t58 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v4, ptr %t50, ptr %t51, i64 %t54)
  store i1 %t58, ptr %l42
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l42, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l37, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load ptr, ptr %l4, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l46, !tbaa !24
  %t67 = load i32, ptr %l5, !tbaa !23
  %t69 = sext i32 %t67 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 1, ptr %t71
  %t73 = insertvalue { i64 } undef, i64 %t69, 0
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64 } %t73, ptr %t74
  %t75 = load { i64, [2 x i64] }, ptr %t70
  %t77 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s4, { i64, [2 x i64] } %t75, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t77, ptr %l50
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = load %"compiler/views:place", ptr %l50
  call void @compiler_2fviews_2enameAdd(ptr %v4, ptr %t78, i64 %t79, %"compiler/views:place" %t80)
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/views:state", ptr %t81, i32 0, i32 3
  %t84 = load i32, ptr %l5, !tbaa !23
  %t86 = sext i32 %t84 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v4, ptr %t83, i64 %t86)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l55, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 1
  store i1 %t96, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l56, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eparts(ptr %v0, ptr %v1, ptr %v4, ptr %t98, ptr %t99, ptr %t100)
  br label %bb35
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb37:
  %t104 = load ptr, ptr @__olang_prog_scope
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t104)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l62
  br label %bb38
bb38:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l7
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t114 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v4, ptr %s0, ptr %t107, ptr %t108, ptr %t109, ptr %l7)
  store i1 %t114, ptr %l67
  br label %bb39
bb39:
  %t115 = load i1, ptr %l67, !tbaa !21
  br i1 %t115, label %bb40, label %bb41
bb40:
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb42
bb41:
  br label %bb61
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t117, i64 %t118)
  %t122 = extractvalue { i32, { i64, ptr } } %t121, 1
  %t123 = extractvalue { i32, { i64, ptr } } %t121, 0
  store i32 %t123, ptr %l73
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb44, label %ok.125
ok.125:
  store { i64, ptr } %t122, ptr %l72
  br label %bb43
bb43:
  %t126 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t126, ptr %l69, !tbaa !27
  br label %bb48
bb44:
  %t127 = load i32, ptr %l73, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  br i1 %t130, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb48:
  %t132 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t132, ptr %l10, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t145 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t145, ptr %l82, !tbaa !27
  %t146 = load i64, ptr %l12, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr %"compiler/views:place", ptr %t149, i64 %t146
  %t151 = load %"compiler/views:place", ptr %t150
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l85, !tbaa !29
  store %"compiler/views:place" %t151, ptr %l86
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l88
  br label %bb53
bb53:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s10, ptr %t158, { i64, ptr } { i64 6, ptr @.d14 })
  store i64 %t160, ptr %l90
  br label %bb54
bb54:
  %t161 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 0, i32 0)
  store %"compiler/source:Span" %t161, ptr %l91
  br label %bb55
bb55:
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t163 = load ptr, ptr %l85, !tbaa !29
  %t164 = load %"compiler/views:place", ptr %l86
  %t165 = load %"compiler/source:Span", ptr %l88
  %t166 = load i64, ptr %l90, !tbaa !24
  %t167 = load %"compiler/source:Span", ptr %l91
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v4, ptr %t163, %"compiler/views:place" %t164, %"compiler/source:Span" %t165, i64 %t166, i64 -1, %"compiler/source:Span" %t167, ptr %t162)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t169 = load i64, ptr %l12, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l12, !tbaa !24
  br label %bb49
bb58:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = add i64 %t173, %t174
  store i64 %t177, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  br label %bb42
bb60:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t182 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t179, ptr %t180, ptr %t181, ptr %t182)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %rv = alloca { i64, [3 x i64] }
  %t16 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 19
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 3, ptr %t17
  %t19 = insertvalue { i64, i64, i64 } undef, i64 %t7, 0
  %t21 = insertvalue { i64, i64, i64 } %t19, i64 %t11, 1
  %t23 = insertvalue { i64, i64, i64 } %t21, i64 %t15, 2
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  store { i64, i64, i64 } %t23, ptr %t24
  %t25 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %a0, %"compiler/views:place" %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l3 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca %"compiler/views:place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/views:place"
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 3
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = load %"compiler/views:place", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/views:place" %t4, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/views:Viewer", ptr %t10, i32 0, i32 3
  %t13 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t12, i64 %t14)
  store { i64, ptr } %t17, ptr %l14
  br label %bb6
bb5:
  %t18 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l10, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  %t29 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t30 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t30, ptr %l19
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:Viewer", ptr %t32, i32 0, i32 3
  %t35 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t34, i64 %t36)
  store { i64, ptr } %t39, ptr %l24
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/views:Viewer", ptr %t40, i32 0, i32 3
  %t46 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t42, i64 %a2)
  store { i64, ptr } %t46, ptr %l28
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t48, i64 %t49)
  %t55 = getelementptr i8, ptr %t54, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t65 = load ptr, ptr %l20, !tbaa !29
  %t67 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } %t64)
  store i64 %t67, ptr %l31
  br label %bb10
bb10:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = load { i64, [2 x i64] }, ptr %l19
  %t71 = load i64, ptr %l31, !tbaa !24
  %t74 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s0, { i64, [2 x i64] } %t70, i64 %t71, i64 %t68, i1 %a4)
  store %"compiler/views:place" %t74, ptr %l34
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load %"compiler/views:place", ptr %l34
  store %"compiler/views:place" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:place", ptr %rv
  ret %"compiler/views:place" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/views:holding"
  %l13 = alloca %"compiler/views:view"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/views:place"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca %"compiler/views:holding"
  %l66 = alloca { i64, [2 x i64] }
  %l69 = alloca { i64, [2 x i64] }
  %l71 = alloca i1
  %l77 = alloca %"compiler/views:place"
  %l79 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca %"compiler/views:holding"
  %l90 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca i1
  %l95 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, [2 x i64] }
  %l120 = alloca { i64, [2 x i64] }
  %l122 = alloca i1
  %l129 = alloca i64
  %l131 = alloca i1
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca i32
  %l148 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l167 = alloca %"compiler/typed:Local"
  %l169 = alloca i1
  %l172 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca i32
  %l185 = alloca { i64, ptr }
  %l191 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t68 = alloca { i64, [2 x i64] }, align 8
  %t81 = alloca { i64, [2 x i64] }, align 8
  %t184 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load ptr, ptr %l5, !tbaa !29
  %t5 = getelementptr %"compiler/views:state", ptr %t3, i32 0, i32 1
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t5)
  store i64 %t7, ptr %l37
  br label %bb3
bb2:
  br label %bb78
bb3:
  %t8 = load i64, ptr %l37, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb9
bb6:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l8, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l8, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l44, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l44, !tbaa !24
  store i64 %t35, ptr %l41, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l41, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load i64, ptr %l10, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb12:
  br label %bb13
bb13:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l11, !tbaa !24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t57, i64 %t58)
  store %"compiler/views:holding" %t61, ptr %l65
  br label %bb14
bb14:
  %t62 = load %"compiler/views:holding", ptr %l65
  store %"compiler/views:holding" %t62, ptr %l12
  %t63 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t64 = getelementptr %"compiler/views:view", ptr %t63, i32 0, i32 0
  %t65 = getelementptr %"compiler/views:place", ptr %t64, i32 0, i32 0
  %t66 = load { i64, [2 x i64] }, ptr %t65
  store { i64, [2 x i64] } %t66, ptr %l66
  %t67 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 0
  store i64 1, ptr %t69
  %t71 = insertvalue { i64 } undef, i64 %t67, 0
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 1
  store { i64 } %t71, ptr %t72
  %t73 = load { i64, [2 x i64] }, ptr %t68
  store { i64, [2 x i64] } %t73, ptr %l69
  %t76 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l66, ptr %l69)
  store i1 %t76, ptr %l71
  br label %bb15
bb15:
  %t77 = load i1, ptr %l71, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t79 = load %"compiler/views:view", ptr %t78
  store %"compiler/views:view" %t79, ptr %l13
  store { i64, [2 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 0
  store i64 0, ptr %t82
  %t83 = load { i64, [2 x i64] }, ptr %t81
  %t84 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t85 = getelementptr %"compiler/views:place", ptr %t84, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t88 = getelementptr %"compiler/views:place", ptr %t87, i32 0, i32 2
  %t89 = load i64, ptr %t88, !tbaa !24
  %t90 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  %t91 = getelementptr %"compiler/views:place", ptr %t90, i32 0, i32 3
  %t92 = load i1, ptr %t91, !tbaa !21
  %t97 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s4, { i64, [2 x i64] } %t83, i64 %t86, i64 %t89, i1 %t92)
  store %"compiler/views:place" %t97, ptr %l77
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t98 = load %"compiler/views:place", ptr %l77
  %t99 = getelementptr %"compiler/views:view", ptr %l13, i32 0, i32 0
  store %"compiler/views:place" %t98, ptr %t99
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/views:state", ptr %t100, i32 0, i32 1
  store ptr %t102, ptr %l79, !tbaa !29
  %t103 = load i64, ptr %l11, !tbaa !24
  store i64 %t103, ptr %l80, !tbaa !24
  %t104 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 0
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load %"compiler/views:view", ptr %l13
  %t109 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s4, i64 %t105, %"compiler/views:view" %t106)
  store %"compiler/views:holding" %t109, ptr %l83
  br label %bb19
bb19:
  %t110 = load ptr, ptr %l79, !tbaa !29
  %t111 = load i64, ptr %l80, !tbaa !24
  %t112 = load %"compiler/views:holding", ptr %l83
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v3, ptr %t110, i64 %t111, %"compiler/views:holding" %t112)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l10, !tbaa !24
  br label %bb10
bb23:
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eforget(ptr %v3, ptr %t117, i64 %t118)
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = icmp ne ptr %t121, null
  br i1 %t123, label %bb25, label %bb26
bb25:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l91, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t128 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t126)
  store i32 %t128, ptr %l93
  br label %bb27
bb26:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb29
bb27:
  %t129 = load ptr, ptr %l91, !tbaa !29
  %t130 = load i32, ptr %l93, !tbaa !23
  %t131 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t131, ptr %l94
  br label %bb28
bb28:
  %t132 = load i1, ptr %l94, !tbaa !21
  store i1 %t132, ptr %l90, !tbaa !21
  br label %bb29
bb29:
  %t133 = load i1, ptr %l90, !tbaa !21
  br i1 %t133, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t134 = load ptr, ptr @__olang_prog_scope
  %t135 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t134)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l95
  br label %bb32
bb31:
  br label %bb77
bb32:
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l14
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s6, ptr %t137, ptr %t138, ptr %t139, ptr %l14)
  br label %bb33
bb33:
  store i1 false, ptr %l15, !tbaa !21
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t145 = load ptr, ptr %l16, !tbaa !29
  %t146 = load i64, ptr %l17, !tbaa !24
  %t149 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t145, i64 %t146)
  %t150 = extractvalue { i32, { i64, ptr } } %t149, 1
  %t151 = extractvalue { i32, { i64, ptr } } %t149, 0
  store i32 %t151, ptr %l105
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb36, label %ok.153
ok.153:
  store { i64, ptr } %t150, ptr %l104
  br label %bb35
bb35:
  %t154 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t154, ptr %l101, !tbaa !27
  br label %bb40
bb36:
  %t155 = load i32, ptr %l105, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  br i1 %t158, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb40:
  %t160 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t160, ptr %l18, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t165 = load i64, ptr %l20, !tbaa !24
  %t166 = load i64, ptr %l19, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t173 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t173, ptr %l114, !tbaa !27
  %t174 = load i64, ptr %l20, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr %"compiler/views:place", ptr %t177, i64 %t174
  %t179 = load %"compiler/views:place", ptr %t178
  store %"compiler/views:place" %t179, ptr %l21
  %t181 = getelementptr %"compiler/views:place", ptr %l21, i32 0, i32 0
  %t182 = load { i64, [2 x i64] }, ptr %t181
  store { i64, [2 x i64] } %t182, ptr %l117
  %t183 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [2 x i64] }, ptr %t184, i32 0, i32 0
  store i64 1, ptr %t185
  %t187 = insertvalue { i64 } undef, i64 %t183, 0
  %t188 = getelementptr { i64, [2 x i64] }, ptr %t184, i32 0, i32 1
  store { i64 } %t187, ptr %t188
  %t189 = load { i64, [2 x i64] }, ptr %t184
  store { i64, [2 x i64] } %t189, ptr %l120
  %t192 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l117, ptr %l120)
  store i1 %t192, ptr %l122
  br label %bb45
bb45:
  %t193 = load i1, ptr %l122, !tbaa !21
  br i1 %t193, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb48
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb49:
  %t194 = load i64, ptr %l20, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l20, !tbaa !24
  br label %bb41
bb50:
  %t198 = load i64, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l19, !tbaa !24
  %t202 = add i64 %t198, %t199
  store i64 %t202, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb51:
  br label %bb34
bb52:
  %t205 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %l14)
  store i64 %t205, ptr %l129
  br label %bb53
bb53:
  %t206 = load i64, ptr %l129, !tbaa !24
  %t207 = icmp sgt i64 %t206, 0
  br i1 %t207, label %bb54, label %bb55
bb54:
  %t209 = load i1, ptr %l15, !tbaa !21
  %t211 = xor i1 %t209, true
  store i1 %t211, ptr %l131, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb56
bb56:
  %t213 = load i1, ptr %l131, !tbaa !21
  br i1 %t213, label %bb57, label %bb58
bb57:
  store ptr %l14, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb59
bb58:
  br label %bb76
bb59:
  store %olang.scope zeroinitializer, ptr %s14
  %t215 = load ptr, ptr %l22, !tbaa !29
  %t216 = load i64, ptr %l23, !tbaa !24
  %t219 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s6, ptr %t215, i64 %t216)
  %t220 = extractvalue { i32, { i64, ptr } } %t219, 1
  %t221 = extractvalue { i32, { i64, ptr } } %t219, 0
  store i32 %t221, ptr %l139
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb61, label %ok.223
ok.223:
  store { i64, ptr } %t220, ptr %l138
  br label %bb60
bb60:
  %t224 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t224, ptr %l135, !tbaa !27
  br label %bb65
bb61:
  %t225 = load i32, ptr %l139, !tbaa !23
  %t226 = ashr i32 %t225, 16
  %t228 = icmp eq i32 %t226, 1
  br i1 %t228, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb64:
  call void @__olang_scope_close(ptr %s14)
  br label %bb74
bb65:
  %t230 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t230, ptr %l24, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  store i64 %t233, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s15
  %t235 = load i64, ptr %l26, !tbaa !24
  %t236 = load i64, ptr %l25, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s15)
  br label %bb72
bb68:
  br label %bb69
bb69:
  %t243 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t243, ptr %l148, !tbaa !27
  %t244 = load i64, ptr %l26, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr %"compiler/views:place", ptr %t247, i64 %t244
  %t249 = load %"compiler/views:place", ptr %t248
  %t251 = load ptr, ptr %l5, !tbaa !29
  %t252 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2enameAdd(ptr %v3, ptr %t251, i64 %t252, %"compiler/views:place" %t249)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb71
bb71:
  %t257 = load i64, ptr %l26, !tbaa !24
  %t259 = add i64 %t257, 1
  store i64 %t259, ptr %l26, !tbaa !24
  br label %bb66
bb72:
  %t261 = load i64, ptr %l23, !tbaa !24
  %t262 = load i64, ptr %l25, !tbaa !24
  %t265 = add i64 %t261, %t262
  store i64 %t265, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  br label %bb59
bb74:
  %t267 = load ptr, ptr %l5, !tbaa !29
  %t269 = getelementptr %"compiler/views:state", ptr %t267, i32 0, i32 3
  %t270 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v3, ptr %t269, i64 %t270)
  br label %bb75
bb75:
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s6)
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l162, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/views:Viewer", ptr %t274, i32 0, i32 19
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 7
  %t280 = load i64, ptr %l1, !tbaa !24
  %t283 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t279, i64 %t280)
  store %"compiler/typed:Local" %t283, ptr %l167
  br label %bb79
bb79:
  %t284 = getelementptr %"compiler/typed:Local", ptr %l167, i32 0, i32 2
  %t285 = load i32, ptr %t284, !tbaa !23
  %t286 = load ptr, ptr %l162, !tbaa !29
  %t288 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t286, i32 %t285)
  store i1 %t288, ptr %l169
  br label %bb80
bb80:
  %t289 = load i1, ptr %l169, !tbaa !21
  %t290 = xor i1 %t289, true
  br i1 %t290, label %bb81, label %bb82
bb81:
  br label %ret
bb82:
  br label %bb83
bb83:
  store ptr %a3, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s19
  %t294 = load ptr, ptr %l28, !tbaa !29
  %t295 = load i64, ptr %l29, !tbaa !24
  %t298 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t294, i64 %t295)
  %t299 = extractvalue { i32, { i64, ptr } } %t298, 1
  %t300 = extractvalue { i32, { i64, ptr } } %t298, 0
  store i32 %t300, ptr %l176
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb86, label %ok.302
ok.302:
  store { i64, ptr } %t299, ptr %l175
  br label %bb85
bb85:
  %t303 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t303, ptr %l172, !tbaa !27
  br label %bb90
bb86:
  %t304 = load i32, ptr %l176, !tbaa !23
  %t305 = ashr i32 %t304, 16
  %t307 = icmp eq i32 %t305, 1
  br i1 %t307, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb89:
  call void @__olang_scope_close(ptr %s19)
  br label %bb99
bb90:
  %t309 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t309, ptr %l30, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  store i64 %t312, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s20
  %t314 = load i64, ptr %l32, !tbaa !24
  %t315 = load i64, ptr %l31, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s20)
  br label %bb97
bb93:
  br label %bb94
bb94:
  %t322 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t322, ptr %l185, !tbaa !27
  %t323 = load i64, ptr %l32, !tbaa !24
  %t325 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr %"compiler/views:view", ptr %t326, i64 %t323
  %t328 = load %"compiler/views:view", ptr %t327
  %t330 = load ptr, ptr %l5, !tbaa !29
  %t331 = load i64, ptr %l1, !tbaa !24
  %t336 = call i1 @compiler_2fviews_2eholdAdd(ptr %v3, ptr %t330, i64 %t331, %"compiler/views:view" %t328)
  store i1 %t336, ptr %l191
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s20)
  br label %bb96
bb96:
  %t337 = load i64, ptr %l32, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l32, !tbaa !24
  br label %bb91
bb97:
  %t341 = load i64, ptr %l29, !tbaa !24
  %t342 = load i64, ptr %l31, !tbaa !24
  %t345 = add i64 %t341, %t342
  store i64 %t345, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb98
bb98:
  br label %bb84
bb99:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 0
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t35, ptr %t36, ptr %t37)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb4
bb13:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/views:state", ptr %t45, i32 0, i32 0
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Block", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Block", ptr %t65, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l7, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  store ptr %t74, ptr %l8, !tbaa !29
  %t76 = load ptr, ptr %l8, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb21, label %bb22
bb21:
  %t80 = load ptr, ptr %l43, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 11
  store i1 %t83, ptr %l44, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l44, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l8, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr }, ptr %t87, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l9, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l9, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t91, ptr %t92, ptr %t93)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb32:
  %t97 = load i64, ptr %l7, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  br label %bb17
bb34:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = call ptr @compiler_2fviews_2eunAway(ptr %v1, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  store ptr %t19, ptr %l5, !tbaa !29
  %t20 = load ptr, ptr %l5, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l6, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t37, ptr %t38)
  store i1 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb18:
  br label %bb43
bb19:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l7, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t62, i32 0, i32 3
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb24
bb23:
  br label %bb38
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l36, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t67)
  store i32 %t69, ptr %l38
  br label %bb25
bb25:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l38, !tbaa !23
  %t72 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t72, ptr %l39
  br label %bb26
bb26:
  %t73 = load i1, ptr %l39, !tbaa !21
  br i1 %t73, label %bb27, label %bb28
bb27:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l42, !tbaa !29
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t76)
  store i32 %t78, ptr %l44
  br label %bb29
bb28:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb33
bb29:
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = load i32, ptr %l44, !tbaa !23
  %t81 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t81, ptr %l45
  br label %bb30
bb30:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t84 = load i32, ptr %l45, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %s4, ptr %t83, i32 %t84, i64 %t82)
  store { i64, ptr } %t86, ptr %l47
  br label %bb31
bb31:
  %t87 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t93, { i64, ptr } { i64 4, ptr @.d20 })
  store i1 %t95, ptr %l49
  br label %bb32
bb32:
  %t96 = load i1, ptr %l49, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l7, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erecordPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t98, ptr %t99, ptr %t100, ptr %t101)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb43:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/views:fact"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca %"compiler/views:place"
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca %"compiler/views:view"
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/views:fact"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca i64
  %l121 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca %"compiler/views:place"
  %l128 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca %"compiler/views:fact"
  %l134 = alloca ptr
  %l135 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca ptr
  %l139 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l159 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca i64
  %l167 = alloca i64
  %l185 = alloca ptr
  %l186 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l187 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l195 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l208 = alloca i64
  %l211 = alloca i1
  %l215 = alloca ptr
  %l218 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l219 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l220 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l225 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l232 = alloca i32
  %l241 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l253 = alloca %"compiler/views:place"
  %l261 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l264 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca i32
  %l283 = alloca { i64, ptr }
  %l286 = alloca ptr
  %l292 = alloca %"compiler/views:place"
  %l310 = alloca ptr
  %l313 = alloca ptr
  %l316 = alloca i32
  %l317 = alloca i32
  %l318 = alloca { i64, ptr }
  %l323 = alloca i64
  %l326 = alloca i64
  %l345 = alloca { i64, ptr }
  %l348 = alloca ptr
  %l350 = alloca i32
  %l351 = alloca i1
  %l357 = alloca i1
  %l361 = alloca { i64, ptr }
  %l364 = alloca i1
  %l365 = alloca i1
  %l369 = alloca { i64, ptr }
  %l372 = alloca i64
  %l376 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l382 = alloca { i64, ptr }
  %l385 = alloca { i64, ptr }
  %l386 = alloca i32
  %l395 = alloca { i64, ptr }
  %l398 = alloca ptr
  %l399 = alloca { i64, [2 x i64] }
  %l400 = alloca i64
  %l404 = alloca { i64, ptr }
  %l406 = alloca %"compiler/views:place"
  %l408 = alloca ptr
  %l409 = alloca %"compiler/source:Span"
  %l419 = alloca i1
  %l423 = alloca i1
  %l431 = alloca i64
  %l434 = alloca i64
  %l454 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l456 = alloca { i64, ptr }
  %l459 = alloca { i64, ptr }
  %l460 = alloca i32
  %l469 = alloca { i64, ptr }
  %l474 = alloca i64
  %l478 = alloca i64
  %l481 = alloca i64
  %l499 = alloca ptr
  %l500 = alloca %"compiler/views:place"
  %l503 = alloca %"compiler/views:place"
  %l504 = alloca i1
  %l508 = alloca { i64, ptr }
  %l511 = alloca %"compiler/source:Span"
  %l514 = alloca i1
  %l517 = alloca { i64, ptr }
  %l521 = alloca ptr
  %l524 = alloca { i64, [3 x i64] }
  %l525 = alloca { i64, ptr }
  %l529 = alloca { i64, ptr }
  %l532 = alloca %"compiler/msgs:Msg"
  %l533 = alloca i64
  %l535 = alloca i1
  %l538 = alloca i64
  %l540 = alloca i1
  %l542 = alloca ptr
  %l545 = alloca i64
  %l546 = alloca i1
  %l551 = alloca ptr
  %l552 = alloca i64
  %l555 = alloca i64
  %l558 = alloca %"compiler/source:Span"
  %l560 = alloca i64
  %l563 = alloca %"compiler/source:Span"
  %l566 = alloca { i64, [3 x i64] }
  %l570 = alloca { i64, ptr }
  %l571 = alloca %"compiler/msgs:Msg"
  %l582 = alloca i64
  %l586 = alloca i64
  %l589 = alloca i64
  %l607 = alloca ptr
  %l610 = alloca %"compiler/views:place"
  %l611 = alloca %"compiler/source:Span"
  %l612 = alloca i64
  %l615 = alloca i64
  %l618 = alloca %"compiler/source:Span"
  %l623 = alloca { i64, ptr }
  %l626 = alloca { i64, ptr }
  %l627 = alloca i32
  %l636 = alloca { i64, ptr }
  %l646 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l651 = alloca i64
  %l654 = alloca i64
  %l679 = alloca ptr
  %l682 = alloca { i64, ptr }
  %l685 = alloca { i64, ptr }
  %l686 = alloca i32
  %l695 = alloca { i64, ptr }
  %l700 = alloca i1
  %l706 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l709 = alloca { i64, ptr }
  %l715 = alloca { i64, ptr }
  %l718 = alloca { i64, ptr }
  %l719 = alloca i32
  %l728 = alloca { i64, ptr }
  %l731 = alloca ptr
  %l737 = alloca %"compiler/views:place"
  %l740 = alloca %"compiler/views:view"
  %l753 = alloca i1
  %l758 = alloca i64
  %l761 = alloca i64
  %l781 = alloca i1
  %l783 = alloca i1
  %l786 = alloca i1
  %l789 = alloca i1
  %l790 = alloca i64
  %l794 = alloca ptr
  %l797 = alloca i64
  %l799 = alloca i1
  %l803 = alloca ptr
  %l807 = alloca i1
  %l811 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l813 = alloca { i64, ptr }
  %l816 = alloca { i64, ptr }
  %l817 = alloca i32
  %l826 = alloca { i64, ptr }
  %l837 = alloca i1
  %l838 = alloca ptr
  %l840 = alloca { i64, ptr }
  %l843 = alloca i32
  %l844 = alloca i1
  %l845 = alloca i1
  %l848 = alloca i1
  %l849 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l852 = alloca { i64, ptr }
  %l858 = alloca { i64, ptr }
  %l861 = alloca { i64, ptr }
  %l862 = alloca i32
  %l871 = alloca { i64, ptr }
  %l874 = alloca ptr
  %l875 = alloca { i64, [2 x i64] }
  %l876 = alloca i64
  %l880 = alloca { i64, ptr }
  %l882 = alloca %"compiler/views:place"
  %l885 = alloca %"compiler/views:view"
  %l894 = alloca i1
  %l901 = alloca ptr
  %l904 = alloca { i64, ptr }
  %l907 = alloca { i64, ptr }
  %l908 = alloca i32
  %l917 = alloca { i64, ptr }
  %l922 = alloca i1
  %l926 = alloca i1
  %l929 = alloca i1
  %l933 = alloca i1
  %l936 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l938 = alloca i64
  %l941 = alloca { i64, ptr }
  %l944 = alloca ptr
  %l946 = alloca ptr
  %l948 = alloca i32
  %l951 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s69 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s76 = alloca %olang.scope
  %s81 = alloca %olang.scope
  %s82 = alloca %olang.scope
  %t247 = alloca { i64, [2 x i64] }, align 8
  %t907 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l135
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  store i64 -1, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Call", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l9, !tbaa !29
  store ptr %t8, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t9 = load ptr, ptr %l138, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l138, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l139, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l139, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l10, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t23 = load i32, ptr %l10, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb19
bb7:
  %t27 = load ptr, ptr %l9, !tbaa !29
  store ptr %t27, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t28 = load ptr, ptr %l146, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l146, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l147, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l147, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l9, !tbaa !29
  %t38 = getelementptr { i64, [1 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { ptr }, ptr %t38, i32 0, i32 0
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l11, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  store i1 true, ptr %l8, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t42, ptr %t43, ptr %t44, ptr %l6)
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb19:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Call", ptr %t49, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l12, !tbaa !24
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e(ptr %t56)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l159
  br label %bb20
bb20:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l159
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t59 = load i64, ptr %l12, !tbaa !24
  store i64 %t59, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t61 = load i64, ptr %l15, !tbaa !24
  %t62 = load i64, ptr %l14, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load i64, ptr %l16, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb26
bb23:
  %t71 = load i64, ptr %l15, !tbaa !24
  %t72 = load i64, ptr %l14, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l16, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l16, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l167, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb25
bb25:
  %t87 = load i64, ptr %l167, !tbaa !24
  store i64 %t87, ptr %l164, !tbaa !24
  br label %bb26
bb26:
  %t88 = load i64, ptr %l164, !tbaa !24
  store i64 %t88, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load i64, ptr %l18, !tbaa !24
  %t90 = load i64, ptr %l17, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t98 = load i64, ptr %l18, !tbaa !24
  %t99 = load i64, ptr %l16, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l19, !tbaa !24
  store ptr %l13, ptr %l185, !tbaa !29
  %t107 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l186
  br label %bb31
bb31:
  %t108 = load ptr, ptr %l185, !tbaa !29
  %t109 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l186
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H9aa2f94df86a2febe7e9c453722bc668(ptr %s0, ptr %s0, ptr %t108, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t109)
  br label %bb32
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l187, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l189, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  store ptr %t120, ptr %l191, !tbaa !29
  %t121 = load ptr, ptr %l4, !tbaa !29
  store ptr %t121, ptr %l192, !tbaa !29
  %t122 = load i64, ptr %l19, !tbaa !24
  %t125 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t122)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l195
  br label %bb33
bb33:
  %t126 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l195
  %t127 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %t127
  %t128 = load ptr, ptr %l187, !tbaa !29
  %t129 = load ptr, ptr %l191, !tbaa !29
  %t130 = load ptr, ptr %l192, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t128, ptr %t129, ptr %t130, ptr %t127)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t132 = load i64, ptr %l18, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l18, !tbaa !24
  br label %bb27
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t142 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %t136, %"compiler/source:Span" %a1, ptr %t138)
  store %"compiler/source:Span" %t142, ptr %l202
  br label %bb37
bb37:
  %t143 = load %"compiler/source:Span", ptr %l202
  store %"compiler/source:Span" %t143, ptr %l20
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l203, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2equoted(ptr %v0, ptr %s0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l206
  br label %bb38
bb38:
  %t150 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t157 = load ptr, ptr %l203, !tbaa !29
  %t159 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t156)
  store i64 %t159, ptr %l208
  br label %bb39
bb39:
  %t160 = load i64, ptr %l208, !tbaa !24
  store i64 %t160, ptr %l21, !tbaa !24
  %t161 = load i64, ptr %l7, !tbaa !24
  %t163 = icmp sge i64 %t161, 0
  br i1 %t163, label %bb40, label %bb41
bb40:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/views:Viewer", ptr %t165, i32 0, i32 2
  %t168 = load i64, ptr %l7, !tbaa !24
  %t171 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t167, i64 %t168)
  store ptr %t171, ptr %l215
  br label %bb42
bb41:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb43
bb42:
  %t172 = load ptr, ptr %l215, !tbaa !29
  %t174 = getelementptr %"compiler/views:summary", ptr %t172, i32 0, i32 4
  %t175 = load i1, ptr %t174, !tbaa !21
  store i1 %t175, ptr %l211, !tbaa !21
  br label %bb43
bb43:
  %t177 = load i1, ptr %l211, !tbaa !21
  store i1 %t177, ptr %l22, !tbaa !21
  %t178 = load ptr, ptr @__olang_prog_scope
  %t179 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t178)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l218
  br label %bb44
bb44:
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l218
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l23
  %t181 = load ptr, ptr @__olang_prog_scope
  %t182 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t181)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l219
  br label %bb45
bb45:
  %t183 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l219
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l24
  %t184 = load ptr, ptr @__olang_prog_scope
  %t185 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t184)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t185, ptr %l220
  br label %bb46
bb46:
  %t186 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l220
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %l25
  %t187 = load i1, ptr %l22, !tbaa !21
  br i1 %t187, label %bb47, label %bb48
bb47:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/views:Viewer", ptr %t189, i32 0, i32 2
  %t192 = load i64, ptr %l7, !tbaa !24
  %t195 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t191, i64 %t192)
  store ptr %t195, ptr %l225
  br label %bb49
bb48:
  %t196 = load i1, ptr %l8, !tbaa !21
  br i1 %t196, label %bb96, label %bb97
bb49:
  %t198 = load ptr, ptr %l225, !tbaa !29
  %t200 = getelementptr %"compiler/views:summary", ptr %t198, i32 0, i32 0
  store ptr %t200, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t202 = load ptr, ptr %l26, !tbaa !29
  %t203 = load i64, ptr %l27, !tbaa !24
  %t206 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t202, i64 %t203)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l232
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb52, label %ok.210
ok.210:
  store { i64, ptr } %t207, ptr %l231
  br label %bb51
bb51:
  %t211 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t211, ptr %l228, !tbaa !27
  br label %bb56
bb52:
  %t212 = load i32, ptr %l232, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  br i1 %t215, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb95
bb56:
  %t217 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t217, ptr %l28, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  store i64 %t220, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  %t222 = load i64, ptr %l30, !tbaa !24
  %t223 = load i64, ptr %l29, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb93
bb59:
  br label %bb60
bb60:
  %t230 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t230, ptr %l241, !tbaa !27
  %t231 = load i64, ptr %l30, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr %"compiler/views:fact", ptr %t234, i64 %t231
  %t236 = load %"compiler/views:fact", ptr %t235
  store %"compiler/views:fact" %t236, ptr %l31
  %t238 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 0
  %t239 = load i64, ptr %t238, !tbaa !24
  %t241 = icmp slt i64 %t239, 0
  br i1 %t241, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l23, ptr %l246, !tbaa !29
  %t243 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 1
  %t244 = load i64, ptr %t243, !tbaa !24
  %t245 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 2
  %t246 = load i32, ptr %t245, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [2 x i64] }, ptr %t247, i32 0, i32 0
  store i64 3, ptr %t248
  %t250 = insertvalue { i64, i32 } undef, i64 %t244, 0
  %t252 = insertvalue { i64, i32 } %t250, i32 %t246, 1
  %t253 = getelementptr { i64, [2 x i64] }, ptr %t247, i32 0, i32 1
  store { i64, i32 } %t252, ptr %t253
  %t254 = load { i64, [2 x i64] }, ptr %t247
  %t255 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 3
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 4
  %t258 = load i64, ptr %t257, !tbaa !24
  %t259 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 5
  %t260 = load i1, ptr %t259, !tbaa !21
  %t265 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s11, { i64, [2 x i64] } %t254, i64 %t256, i64 %t258, i1 %t260)
  store %"compiler/views:place" %t265, ptr %l253
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t266 = load ptr, ptr %l246, !tbaa !29
  %t267 = load %"compiler/views:place", ptr %l253
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t266, %"compiler/views:place" %t267)
  br label %bb64
bb64:
  %t268 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 6
  %t269 = load i64, ptr %t268, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 %t269)
  br label %bb65
bb65:
  %t272 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 7
  %t273 = load %"compiler/source:Span", ptr %t272
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, %"compiler/source:Span" %t273)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  br label %bb92
bb67:
  %t276 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 0
  %t277 = load i64, ptr %t276, !tbaa !24
  %t278 = load i64, ptr %l12, !tbaa !24
  %t281 = icmp sge i64 %t277, %t278
  br i1 %t281, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb92
bb69:
  br label %bb70
bb70:
  %t283 = load ptr, ptr @__olang_prog_scope
  %t284 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t283)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t284, ptr %l261
  br label %bb71
bb71:
  %t285 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l261
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t285, ptr %l32
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Call", ptr %t287, i32 0, i32 1
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l264, !tbaa !27
  %t291 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 0
  %t292 = load i64, ptr %t291, !tbaa !24
  %t294 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr ptr, ptr %t295, i64 %t292
  %t297 = load ptr, ptr %t296, !tbaa !39
  %t298 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s10, ptr %t286, ptr %t297, ptr %t298, ptr %l32)
  br label %bb72
bb72:
  store ptr %l32, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t304 = load ptr, ptr %l33, !tbaa !29
  %t305 = load i64, ptr %l34, !tbaa !24
  %t308 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s10, ptr %t304, i64 %t305)
  %t309 = extractvalue { i32, { i64, ptr } } %t308, 1
  %t310 = extractvalue { i32, { i64, ptr } } %t308, 0
  store i32 %t310, ptr %l274
  %t311 = icmp ne i32 %t310, 0
  br i1 %t311, label %bb75, label %ok.312
ok.312:
  store { i64, ptr } %t309, ptr %l273
  br label %bb74
bb74:
  %t313 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t313, ptr %l270, !tbaa !27
  br label %bb79
bb75:
  %t314 = load i32, ptr %l274, !tbaa !23
  %t315 = ashr i32 %t314, 16
  %t317 = icmp eq i32 %t315, 1
  br i1 %t317, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb91
bb79:
  %t319 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t319, ptr %l35, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  store i64 %t322, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s15
  %t324 = load i64, ptr %l37, !tbaa !24
  %t325 = load i64, ptr %l36, !tbaa !24
  %t328 = icmp slt i64 %t324, %t325
  %t330 = xor i1 %t328, true
  br i1 %t330, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s15)
  br label %bb89
bb82:
  br label %bb83
bb83:
  %t332 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t332, ptr %l283, !tbaa !27
  %t333 = load i64, ptr %l37, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr %"compiler/views:place", ptr %t336, i64 %t333
  %t338 = load %"compiler/views:place", ptr %t337
  store ptr %l23, ptr %l286, !tbaa !29
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 3
  %t343 = load i64, ptr %t342, !tbaa !24
  %t344 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 4
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 5
  %t347 = load i1, ptr %t346, !tbaa !21
  %t353 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t340, %"compiler/views:place" %t338, i64 %t343, i64 %t345, i1 %t347)
  store %"compiler/views:place" %t353, ptr %l292
  br label %bb84
bb84:
  %t354 = load ptr, ptr %l286, !tbaa !29
  %t355 = load %"compiler/views:place", ptr %l292
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t354, %"compiler/views:place" %t355)
  br label %bb85
bb85:
  %t356 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 6
  %t357 = load i64, ptr %t356, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 %t357)
  br label %bb86
bb86:
  %t360 = getelementptr %"compiler/views:fact", ptr %l31, i32 0, i32 7
  %t361 = load %"compiler/source:Span", ptr %t360
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, %"compiler/source:Span" %t361)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb88:
  %t364 = load i64, ptr %l37, !tbaa !24
  %t366 = add i64 %t364, 1
  store i64 %t366, ptr %l37, !tbaa !24
  br label %bb80
bb89:
  %t368 = load i64, ptr %l34, !tbaa !24
  %t369 = load i64, ptr %l36, !tbaa !24
  %t372 = add i64 %t368, %t369
  store i64 %t372, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb90:
  br label %bb73
bb91:
  call void @__olang_scope_close(ptr %s10)
  br label %bb92
bb92:
  %t374 = load i64, ptr %l30, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l30, !tbaa !24
  br label %bb57
bb93:
  %t378 = load i64, ptr %l27, !tbaa !24
  %t379 = load i64, ptr %l29, !tbaa !24
  %t382 = add i64 %t378, %t379
  store i64 %t382, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb94
bb94:
  br label %bb50
bb95:
  br label %bb153
bb96:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/views:Viewer", ptr %t384, i32 0, i32 0
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = getelementptr %"compiler/generic:Program", ptr %t387, i32 0, i32 2
  store ptr %t389, ptr %l310, !tbaa !29
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/views:Viewer", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 2
  store ptr %t395, ptr %l313, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l3, !tbaa !29
  %t400 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecalleeType(ptr %v0, ptr %v1, ptr %t396, ptr %t397)
  store i32 %t400, ptr %l316
  br label %bb98
bb97:
  br label %bb152
bb98:
  %t401 = load ptr, ptr %l313, !tbaa !29
  %t402 = load i32, ptr %l316, !tbaa !23
  %t403 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t401, i32 %t402)
  store i32 %t403, ptr %l317
  br label %bb99
bb99:
  %t404 = load ptr, ptr %l310, !tbaa !29
  %t405 = load i32, ptr %l317, !tbaa !23
  %t406 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t404, i32 %t405)
  store { i64, ptr } %t406, ptr %l318
  br label %bb100
bb100:
  %t407 = load { i64, ptr }, ptr %l318, !tbaa !27
  store { i64, ptr } %t407, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t408 = load i64, ptr %l12, !tbaa !24
  store i64 %t408, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t410 = load i64, ptr %l41, !tbaa !24
  %t411 = load i64, ptr %l40, !tbaa !24
  %t414 = icmp sgt i64 %t410, %t411
  br i1 %t414, label %bb101, label %bb102
bb101:
  %t416 = load i64, ptr %l42, !tbaa !24
  %t418 = icmp sgt i64 %t416, 0
  br i1 %t418, label %bb103, label %bb104
bb102:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb106
bb103:
  %t420 = load i64, ptr %l41, !tbaa !24
  %t421 = load i64, ptr %l40, !tbaa !24
  %t424 = sub i64 %t420, %t421
  %t425 = load i64, ptr %l42, !tbaa !24
  %t428 = add i64 %t424, %t425
  %t430 = sub i64 %t428, 1
  %t431 = load i64, ptr %l42, !tbaa !24
  %t434 = sdiv i64 %t430, %t431
  store i64 %t434, ptr %l326, !tbaa !24
  br label %bb105
bb104:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb105
bb105:
  %t436 = load i64, ptr %l326, !tbaa !24
  store i64 %t436, ptr %l323, !tbaa !24
  br label %bb106
bb106:
  %t437 = load i64, ptr %l323, !tbaa !24
  store i64 %t437, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s21
  %t438 = load i64, ptr %l44, !tbaa !24
  %t439 = load i64, ptr %l43, !tbaa !24
  %t442 = icmp slt i64 %t438, %t439
  %t444 = xor i1 %t442, true
  br i1 %t444, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s21)
  br label %bb151
bb109:
  br label %bb110
bb110:
  %t446 = load i64, ptr %l40, !tbaa !24
  %t447 = load i64, ptr %l44, !tbaa !24
  %t448 = load i64, ptr %l42, !tbaa !24
  %t451 = mul i64 %t447, %t448
  %t454 = add i64 %t446, %t451
  store i64 %t454, ptr %l45, !tbaa !24
  %t456 = load ptr, ptr %l3, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Call", ptr %t456, i32 0, i32 1
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  store { i64, ptr } %t459, ptr %l345, !tbaa !27
  %t460 = load i64, ptr %l45, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr ptr, ptr %t463, i64 %t460
  %t465 = load ptr, ptr %t464, !tbaa !39
  store ptr %t465, ptr %l46, !tbaa !29
  %t467 = load ptr, ptr %l0, !tbaa !29
  store ptr %t467, ptr %l348, !tbaa !29
  %t468 = load ptr, ptr %l46, !tbaa !29
  %t470 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t468)
  store i32 %t470, ptr %l350
  br label %bb111
bb111:
  %t471 = load ptr, ptr %l348, !tbaa !29
  %t472 = load i32, ptr %l350, !tbaa !23
  %t473 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t471, i32 %t472)
  store i1 %t473, ptr %l351
  br label %bb112
bb112:
  %t474 = load i1, ptr %l351, !tbaa !21
  %t475 = xor i1 %t474, true
  br i1 %t475, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb114:
  br label %bb115
bb115:
  %t477 = load i64, ptr %l45, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t478, 0
  %t483 = icmp slt i64 %t477, %t480
  br i1 %t483, label %bb116, label %bb117
bb116:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/views:Viewer", ptr %t485, i32 0, i32 0
  %t488 = load ptr, ptr %t487, !tbaa !29
  %t490 = getelementptr %"compiler/generic:Program", ptr %t488, i32 0, i32 2
  %t491 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t491, ptr %l361, !tbaa !27
  %t492 = load i64, ptr %l45, !tbaa !24
  %t494 = getelementptr { i64, ptr }, ptr %l361, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !27
  %t496 = getelementptr i32, ptr %t495, i64 %t492
  %t497 = load i32, ptr %t496, !tbaa !33
  %t500 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t490, i32 %t497)
  store i1 %t500, ptr %l364
  br label %bb118
bb117:
  store i1 false, ptr %l357, !tbaa !21
  br label %bb119
bb118:
  %t501 = load i1, ptr %l364, !tbaa !21
  store i1 %t501, ptr %l357, !tbaa !21
  br label %bb119
bb119:
  %t502 = load i1, ptr %l357, !tbaa !21
  br i1 %t502, label %bb120, label %bb121
bb120:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/views:Viewer", ptr %t503, i32 0, i32 0
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t508 = getelementptr %"compiler/generic:Program", ptr %t506, i32 0, i32 2
  %t509 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t509, ptr %l369, !tbaa !27
  %t510 = load i64, ptr %l45, !tbaa !24
  %t512 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !27
  %t514 = getelementptr i32, ptr %t513, i64 %t510
  %t515 = load i32, ptr %t514, !tbaa !33
  %t518 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t508, i32 %t515)
  store i64 %t518, ptr %l372
  br label %bb122
bb121:
  store i1 false, ptr %l365, !tbaa !21
  br label %bb123
bb122:
  %t519 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t520 = load i64, ptr %l372, !tbaa !24
  %t522 = and i64 %t520, %t519
  %t524 = icmp eq i64 %t522, 0
  store i1 %t524, ptr %l365, !tbaa !21
  br label %bb123
bb123:
  %t526 = load i1, ptr %l365, !tbaa !21
  br i1 %t526, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb125:
  br label %bb126
bb126:
  %t527 = load ptr, ptr @__olang_prog_scope
  %t528 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t527)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t528, ptr %l376
  br label %bb127
bb127:
  %t529 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l376
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t529, ptr %l47
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load ptr, ptr %l46, !tbaa !29
  %t532 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s21, ptr %t530, ptr %t531, ptr %t532, ptr %l47)
  br label %bb128
bb128:
  store ptr %l47, ptr %l48, !tbaa !29
  store i64 0, ptr %l49, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s25
  %t538 = load ptr, ptr %l48, !tbaa !29
  %t539 = load i64, ptr %l49, !tbaa !24
  %t542 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s21, ptr %t538, i64 %t539)
  %t543 = extractvalue { i32, { i64, ptr } } %t542, 1
  %t544 = extractvalue { i32, { i64, ptr } } %t542, 0
  store i32 %t544, ptr %l386
  %t545 = icmp ne i32 %t544, 0
  br i1 %t545, label %bb131, label %ok.546
ok.546:
  store { i64, ptr } %t543, ptr %l385
  br label %bb130
bb130:
  %t547 = load { i64, ptr }, ptr %l385, !tbaa !27
  store { i64, ptr } %t547, ptr %l382, !tbaa !27
  br label %bb135
bb131:
  %t548 = load i32, ptr %l386, !tbaa !23
  %t549 = ashr i32 %t548, 16
  %t551 = icmp eq i32 %t549, 1
  br i1 %t551, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb134:
  call void @__olang_scope_close(ptr %s25)
  br label %bb149
bb135:
  %t553 = load { i64, ptr }, ptr %l382, !tbaa !27
  store { i64, ptr } %t553, ptr %l50, !tbaa !27
  %t554 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t554, 0
  store i64 %t556, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s26
  %t558 = load i64, ptr %l52, !tbaa !24
  %t559 = load i64, ptr %l51, !tbaa !24
  %t562 = icmp slt i64 %t558, %t559
  %t564 = xor i1 %t562, true
  br i1 %t564, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s26)
  br label %bb147
bb138:
  br label %bb139
bb139:
  %t566 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t566, ptr %l395, !tbaa !27
  %t567 = load i64, ptr %l52, !tbaa !24
  %t569 = getelementptr { i64, ptr }, ptr %l395, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !27
  %t571 = getelementptr %"compiler/views:place", ptr %t570, i64 %t567
  %t572 = load %"compiler/views:place", ptr %t571
  store %"compiler/views:place" %t572, ptr %l53
  store ptr %l23, ptr %l398, !tbaa !29
  %t574 = getelementptr %"compiler/views:place", ptr %l53, i32 0, i32 0
  %t575 = load { i64, [2 x i64] }, ptr %t574
  store { i64, [2 x i64] } %t575, ptr %l399
  %t576 = getelementptr %"compiler/views:place", ptr %l53, i32 0, i32 1
  %t577 = load i64, ptr %t576, !tbaa !24
  store i64 %t577, ptr %l400, !tbaa !24
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = getelementptr %"compiler/views:Viewer", ptr %t578, i32 0, i32 3
  %t581 = getelementptr %"compiler/views:place", ptr %l53, i32 0, i32 1
  %t582 = load i64, ptr %t581, !tbaa !24
  %t585 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s26, ptr %t580, i64 %t582)
  store { i64, ptr } %t585, ptr %l404
  br label %bb140
bb140:
  %t586 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t586, 0
  %t588 = load { i64, [2 x i64] }, ptr %l399
  %t589 = load i64, ptr %l400, !tbaa !24
  %t591 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s26, { i64, [2 x i64] } %t588, i64 %t589, i64 %t587, i1 true)
  store %"compiler/views:place" %t591, ptr %l406
  br label %bb141
bb141:
  %t592 = load ptr, ptr %l398, !tbaa !29
  %t593 = load %"compiler/views:place", ptr %l406
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t592, %"compiler/views:place" %t593)
  br label %bb142
bb142:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l24, i64 -1)
  br label %bb143
bb143:
  store ptr %l25, ptr %l408, !tbaa !29
  %t595 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s26, i32 0, i32 0)
  store %"compiler/source:Span" %t595, ptr %l409
  br label %bb144
bb144:
  %t596 = load ptr, ptr %l408, !tbaa !29
  %t597 = load %"compiler/source:Span", ptr %l409
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %t596, %"compiler/source:Span" %t597)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s26)
  br label %bb146
bb146:
  %t598 = load i64, ptr %l52, !tbaa !24
  %t600 = add i64 %t598, 1
  store i64 %t600, ptr %l52, !tbaa !24
  br label %bb136
bb147:
  %t602 = load i64, ptr %l49, !tbaa !24
  %t603 = load i64, ptr %l51, !tbaa !24
  %t606 = add i64 %t602, %t603
  store i64 %t606, ptr %l49, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb148
bb148:
  br label %bb129
bb149:
  call void @__olang_scope_close(ptr %s21)
  br label %bb150
bb150:
  %t608 = load i64, ptr %l44, !tbaa !24
  %t610 = add i64 %t608, 1
  store i64 %t610, ptr %l44, !tbaa !24
  br label %bb107
bb151:
  br label %bb152
bb152:
  br label %bb153
bb153:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/views:Viewer", ptr %t612, i32 0, i32 21
  %t615 = load i1, ptr %t614, !tbaa !21
  br i1 %t615, label %bb154, label %bb155
bb154:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t619 = getelementptr %"compiler/views:Viewer", ptr %t617, i32 0, i32 22
  %t620 = load i1, ptr %t619, !tbaa !21
  %t622 = xor i1 %t620, true
  store i1 %t622, ptr %l419, !tbaa !21
  br label %bb156
bb155:
  store i1 false, ptr %l419, !tbaa !21
  br label %bb156
bb156:
  %t624 = load i1, ptr %l419, !tbaa !21
  br i1 %t624, label %bb157, label %bb158
bb157:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/views:Viewer", ptr %t625, i32 0, i32 23
  %t628 = load i1, ptr %t627, !tbaa !21
  %t630 = xor i1 %t628, true
  store i1 %t630, ptr %l423, !tbaa !21
  br label %bb159
bb158:
  store i1 false, ptr %l423, !tbaa !21
  br label %bb159
bb159:
  %t632 = load i1, ptr %l423, !tbaa !21
  br i1 %t632, label %bb160, label %bb161
bb160:
  store i64 0, ptr %l54, !tbaa !24
  %t633 = load i64, ptr %l12, !tbaa !24
  store i64 %t633, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t635 = load i64, ptr %l55, !tbaa !24
  %t636 = load i64, ptr %l54, !tbaa !24
  %t639 = icmp sgt i64 %t635, %t636
  br i1 %t639, label %bb162, label %bb163
bb161:
  br label %bb239
bb162:
  %t641 = load i64, ptr %l56, !tbaa !24
  %t643 = icmp sgt i64 %t641, 0
  br i1 %t643, label %bb164, label %bb165
bb163:
  store i64 0, ptr %l431, !tbaa !24
  br label %bb167
bb164:
  %t645 = load i64, ptr %l55, !tbaa !24
  %t646 = load i64, ptr %l54, !tbaa !24
  %t649 = sub i64 %t645, %t646
  %t650 = load i64, ptr %l56, !tbaa !24
  %t653 = add i64 %t649, %t650
  %t655 = sub i64 %t653, 1
  %t656 = load i64, ptr %l56, !tbaa !24
  %t659 = sdiv i64 %t655, %t656
  store i64 %t659, ptr %l434, !tbaa !24
  br label %bb166
bb165:
  store i64 0, ptr %l434, !tbaa !24
  br label %bb166
bb166:
  %t661 = load i64, ptr %l434, !tbaa !24
  store i64 %t661, ptr %l431, !tbaa !24
  br label %bb167
bb167:
  %t662 = load i64, ptr %l431, !tbaa !24
  store i64 %t662, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb168
bb168:
  store %olang.scope zeroinitializer, ptr %s31
  %t663 = load i64, ptr %l58, !tbaa !24
  %t664 = load i64, ptr %l57, !tbaa !24
  %t667 = icmp slt i64 %t663, %t664
  %t669 = xor i1 %t667, true
  br i1 %t669, label %bb169, label %bb170
bb169:
  call void @__olang_scope_close(ptr %s31)
  br label %bb238
bb170:
  br label %bb171
bb171:
  %t671 = load i64, ptr %l54, !tbaa !24
  %t672 = load i64, ptr %l58, !tbaa !24
  %t673 = load i64, ptr %l56, !tbaa !24
  %t676 = mul i64 %t672, %t673
  %t679 = add i64 %t671, %t676
  store i64 %t679, ptr %l59, !tbaa !24
  store i1 false, ptr %l60, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s32
  %t681 = load i64, ptr %l59, !tbaa !24
  %t684 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t681)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t684, ptr %l454
  br label %bb172
bb172:
  %t685 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l454
  %t686 = call ptr @__olang_scope_alloc_a(ptr %s32, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t685, ptr %t686
  store ptr %t686, ptr %l61, !tbaa !29
  store i64 0, ptr %l62, !tbaa !24
  br label %bb173
bb173:
  store %olang.scope zeroinitializer, ptr %s33
  %t688 = load ptr, ptr %l61, !tbaa !29
  %t689 = load i64, ptr %l62, !tbaa !24
  %t692 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t688, i64 %t689)
  %t693 = extractvalue { i32, { i64, ptr } } %t692, 1
  %t694 = extractvalue { i32, { i64, ptr } } %t692, 0
  store i32 %t694, ptr %l460
  %t695 = icmp ne i32 %t694, 0
  br i1 %t695, label %bb175, label %ok.696
ok.696:
  store { i64, ptr } %t693, ptr %l459
  br label %bb174
bb174:
  %t697 = load { i64, ptr }, ptr %l459, !tbaa !27
  store { i64, ptr } %t697, ptr %l456, !tbaa !27
  br label %bb179
bb175:
  %t698 = load i32, ptr %l460, !tbaa !23
  %t699 = ashr i32 %t698, 16
  %t701 = icmp eq i32 %t699, 1
  br i1 %t701, label %bb176, label %bb177
bb176:
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb178:
  call void @__olang_scope_close(ptr %s33)
  br label %bb236
bb179:
  %t703 = load { i64, ptr }, ptr %l456, !tbaa !27
  store { i64, ptr } %t703, ptr %l63, !tbaa !27
  %t704 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t706 = extractvalue { i64, ptr } %t704, 0
  store i64 %t706, ptr %l64, !tbaa !24
  store i64 0, ptr %l65, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s34
  %t708 = load i64, ptr %l65, !tbaa !24
  %t709 = load i64, ptr %l64, !tbaa !24
  %t712 = icmp slt i64 %t708, %t709
  %t714 = xor i1 %t712, true
  br i1 %t714, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s34)
  br label %bb234
bb182:
  br label %bb183
bb183:
  %t716 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t716, ptr %l469, !tbaa !27
  %t717 = load i64, ptr %l65, !tbaa !24
  %t719 = getelementptr { i64, ptr }, ptr %l469, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !27
  %t721 = getelementptr %"compiler/views:view", ptr %t720, i64 %t717
  %t722 = load %"compiler/views:view", ptr %t721
  store %"compiler/views:view" %t722, ptr %l66
  %t724 = load i1, ptr %l60, !tbaa !21
  br i1 %t724, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s33)
  br label %bb236
bb185:
  br label %bb186
bb186:
  store i64 0, ptr %l67, !tbaa !24
  %t727 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23)
  store i64 %t727, ptr %l474
  br label %bb187
bb187:
  %t728 = load i64, ptr %l474, !tbaa !24
  store i64 %t728, ptr %l68, !tbaa !24
  store i64 1, ptr %l69, !tbaa !24
  %t729 = load i64, ptr %l68, !tbaa !24
  %t730 = load i64, ptr %l67, !tbaa !24
  %t733 = icmp sgt i64 %t729, %t730
  br i1 %t733, label %bb188, label %bb189
bb188:
  %t735 = load i64, ptr %l69, !tbaa !24
  %t737 = icmp sgt i64 %t735, 0
  br i1 %t737, label %bb190, label %bb191
bb189:
  store i64 0, ptr %l478, !tbaa !24
  br label %bb193
bb190:
  %t739 = load i64, ptr %l68, !tbaa !24
  %t740 = load i64, ptr %l67, !tbaa !24
  %t743 = sub i64 %t739, %t740
  %t744 = load i64, ptr %l69, !tbaa !24
  %t747 = add i64 %t743, %t744
  %t749 = sub i64 %t747, 1
  %t750 = load i64, ptr %l69, !tbaa !24
  %t753 = sdiv i64 %t749, %t750
  store i64 %t753, ptr %l481, !tbaa !24
  br label %bb192
bb191:
  store i64 0, ptr %l481, !tbaa !24
  br label %bb192
bb192:
  %t755 = load i64, ptr %l481, !tbaa !24
  store i64 %t755, ptr %l478, !tbaa !24
  br label %bb193
bb193:
  %t756 = load i64, ptr %l478, !tbaa !24
  store i64 %t756, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb194
bb194:
  store %olang.scope zeroinitializer, ptr %s37
  %t757 = load i64, ptr %l71, !tbaa !24
  %t758 = load i64, ptr %l70, !tbaa !24
  %t761 = icmp slt i64 %t757, %t758
  %t763 = xor i1 %t761, true
  br i1 %t763, label %bb195, label %bb196
bb195:
  call void @__olang_scope_close(ptr %s37)
  br label %bb232
bb196:
  br label %bb197
bb197:
  %t765 = load i64, ptr %l67, !tbaa !24
  %t766 = load i64, ptr %l71, !tbaa !24
  %t767 = load i64, ptr %l69, !tbaa !24
  %t770 = mul i64 %t766, %t767
  %t773 = add i64 %t765, %t770
  store i64 %t773, ptr %l72, !tbaa !24
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l499, !tbaa !29
  %t776 = getelementptr %"compiler/views:view", ptr %l66, i32 0, i32 0
  %t777 = load %"compiler/views:place", ptr %t776
  store %"compiler/views:place" %t777, ptr %l500
  %t778 = load i64, ptr %l72, !tbaa !24
  %t781 = call %"compiler/views:place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23, i64 %t778)
  store %"compiler/views:place" %t781, ptr %l503
  br label %bb198
bb198:
  %t782 = load ptr, ptr %l499, !tbaa !29
  %t783 = load %"compiler/views:place", ptr %l500
  %t784 = load %"compiler/views:place", ptr %l503
  %t785 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t782, %"compiler/views:place" %t783, %"compiler/views:place" %t784)
  store i1 %t785, ptr %l504
  br label %bb199
bb199:
  %t786 = load i1, ptr %l504, !tbaa !21
  %t787 = xor i1 %t786, true
  br i1 %t787, label %bb200, label %bb201
bb200:
  call void @__olang_scope_close(ptr %s37)
  br label %bb231
bb201:
  br label %bb202
bb202:
  store i1 true, ptr %l60, !tbaa !21
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load ptr, ptr %l3, !tbaa !29
  %t792 = getelementptr %"compiler/typed:Call", ptr %t790, i32 0, i32 1
  %t793 = load { i64, ptr }, ptr %t792, !tbaa !27
  store { i64, ptr } %t793, ptr %l508, !tbaa !27
  %t794 = load i64, ptr %l59, !tbaa !24
  %t796 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t797 = load ptr, ptr %t796, !tbaa !27
  %t798 = getelementptr ptr, ptr %t797, i64 %t794
  %t799 = load ptr, ptr %t798, !tbaa !39
  %t802 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t789, ptr %t799)
  store %"compiler/source:Span" %t802, ptr %l511
  br label %bb203
bb203:
  %t803 = load %"compiler/source:Span", ptr %l511
  store %"compiler/source:Span" %t803, ptr %l73
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = load %"compiler/source:Span", ptr %l73
  %t808 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t804, %"compiler/source:Span" %t805)
  store i1 %t808, ptr %l514
  br label %bb204
bb204:
  %t809 = load i1, ptr %l514, !tbaa !21
  br i1 %t809, label %bb205, label %bb206
bb205:
  call void @__olang_scope_close(ptr %s37)
  br label %bb232
bb206:
  br label %bb207
bb207:
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = getelementptr %"compiler/views:view", ptr %l66, i32 0, i32 0
  %t812 = load %"compiler/views:place", ptr %t811
  %t815 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s37, ptr %t810, %"compiler/views:place" %t812)
  store { i64, ptr } %t815, ptr %l517
  br label %bb208
bb208:
  %t816 = load { i64, ptr }, ptr %l517, !tbaa !27
  store { i64, ptr } %t816, ptr %l74, !tbaa !27
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t819 = getelementptr %"compiler/views:Viewer", ptr %t817, i32 0, i32 0
  %t820 = load ptr, ptr %t819, !tbaa !29
  %t822 = getelementptr %"compiler/generic:Program", ptr %t820, i32 0, i32 0
  %t823 = load ptr, ptr %t822, !tbaa !29
  %t825 = getelementptr %"compiler/load:Loader", ptr %t823, i32 0, i32 4
  %t826 = load ptr, ptr %t825, !tbaa !29
  store ptr %t826, ptr %l521, !tbaa !29
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t828 = load %"compiler/source:Span", ptr %l73
  %t831 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t827, %"compiler/source:Span" %t828)
  store { i64, [3 x i64] } %t831, ptr %l524
  br label %bb209
bb209:
  %t832 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t832, ptr %l525, !tbaa !27
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t835 = getelementptr %"compiler/views:Viewer", ptr %t833, i32 0, i32 3
  %t836 = load i64, ptr %l21, !tbaa !24
  %t839 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t835, i64 %t836)
  store { i64, ptr } %t839, ptr %l529
  br label %bb210
bb210:
  %t840 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t842 = load { i64, ptr }, ptr %l525, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l529, !tbaa !27
  %t846 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %s37, ptr %v0, ptr %s37, ptr %s37, ptr %s37, { i64, ptr } %t842, { i64, ptr } %t843, { i64, ptr } %t840, { i64, ptr } %t841)
  store %"compiler/msgs:Msg" %t846, ptr %l532
  br label %bb211
bb211:
  %t847 = load ptr, ptr %l521, !tbaa !29
  %t848 = load { i64, [3 x i64] }, ptr %l524
  %t849 = load %"compiler/msgs:Msg", ptr %l532
  %t850 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s37, ptr %t847, { i64, [3 x i64] } %t848, %"compiler/msgs:Msg" %t849)
  store i64 %t850, ptr %l533
  br label %bb212
bb212:
  %t851 = load i64, ptr %l533, !tbaa !24
  store i64 %t851, ptr %l75, !tbaa !24
  %t852 = load i1, ptr %l22, !tbaa !21
  br i1 %t852, label %bb213, label %bb214
bb213:
  %t854 = load i64, ptr %l72, !tbaa !24
  %t857 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t854)
  store i64 %t857, ptr %l538
  br label %bb215
bb214:
  store i1 false, ptr %l535, !tbaa !21
  br label %bb216
bb215:
  %t858 = load i64, ptr %l538, !tbaa !24
  %t859 = icmp sge i64 %t858, 0
  store i1 %t859, ptr %l535, !tbaa !21
  br label %bb216
bb216:
  %t861 = load i1, ptr %l535, !tbaa !21
  br i1 %t861, label %bb217, label %bb218
bb217:
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t864 = getelementptr %"compiler/views:Viewer", ptr %t862, i32 0, i32 6
  store ptr %t864, ptr %l542, !tbaa !29
  %t865 = load i64, ptr %l72, !tbaa !24
  %t868 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t865)
  store i64 %t868, ptr %l545
  br label %bb219
bb218:
  store i1 false, ptr %l540, !tbaa !21
  br label %bb221
bb219:
  %t869 = load ptr, ptr %l542, !tbaa !29
  %t870 = load i64, ptr %l545, !tbaa !24
  %t871 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t869, i64 %t870)
  store i1 %t871, ptr %l546
  br label %bb220
bb220:
  %t872 = load i1, ptr %l546, !tbaa !21
  %t873 = xor i1 %t872, true
  store i1 %t873, ptr %l540, !tbaa !21
  br label %bb221
bb221:
  %t875 = load i1, ptr %l540, !tbaa !21
  br i1 %t875, label %bb222, label %bb223
bb222:
  store %olang.scope zeroinitializer, ptr %s40
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t878 = getelementptr %"compiler/views:Viewer", ptr %t876, i32 0, i32 0
  %t879 = load ptr, ptr %t878, !tbaa !29
  %t881 = getelementptr %"compiler/generic:Program", ptr %t879, i32 0, i32 0
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t884 = getelementptr %"compiler/load:Loader", ptr %t882, i32 0, i32 4
  %t885 = load ptr, ptr %t884, !tbaa !29
  store ptr %t885, ptr %l551, !tbaa !29
  %t886 = load i64, ptr %l75, !tbaa !24
  store i64 %t886, ptr %l552, !tbaa !24
  %t887 = load i64, ptr %l72, !tbaa !24
  %t890 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t887)
  store i64 %t890, ptr %l555
  br label %bb224
bb223:
  br label %bb230
bb224:
  %t891 = load i64, ptr %l72, !tbaa !24
  %t894 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t891)
  store %"compiler/source:Span" %t894, ptr %l558
  br label %bb225
bb225:
  %t895 = getelementptr %"compiler/source:Span", ptr %l558, i32 0, i32 0
  %t896 = load i32, ptr %t895, !tbaa !23
  %t898 = sext i32 %t896 to i64
  store i64 %t898, ptr %l560, !tbaa !24
  %t899 = load i64, ptr %l72, !tbaa !24
  %t902 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t899)
  store %"compiler/source:Span" %t902, ptr %l563
  br label %bb226
bb226:
  %t903 = getelementptr %"compiler/source:Span", ptr %l563, i32 0, i32 1
  %t904 = load i32, ptr %t903, !tbaa !23
  %t906 = sext i32 %t904 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t907
  %t908 = getelementptr { i64, [3 x i64] }, ptr %t907, i32 0, i32 0
  store i64 3, ptr %t908
  %t909 = load i64, ptr %l555, !tbaa !24
  %t910 = insertvalue { i64, i64, i64 } undef, i64 %t909, 0
  %t911 = load i64, ptr %l560, !tbaa !24
  %t912 = insertvalue { i64, i64, i64 } %t910, i64 %t911, 1
  %t914 = insertvalue { i64, i64, i64 } %t912, i64 %t906, 2
  %t915 = getelementptr { i64, [3 x i64] }, ptr %t907, i32 0, i32 1
  store { i64, i64, i64 } %t914, ptr %t915
  %t916 = load { i64, [3 x i64] }, ptr %t907
  store { i64, [3 x i64] } %t916, ptr %l566
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t919 = getelementptr %"compiler/views:Viewer", ptr %t917, i32 0, i32 3
  %t920 = load i64, ptr %l21, !tbaa !24
  %t923 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t919, i64 %t920)
  store { i64, ptr } %t923, ptr %l570
  br label %bb227
bb227:
  %t924 = load { i64, ptr }, ptr %l570, !tbaa !27
  %t925 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %s40, { i64, ptr } %t924)
  store %"compiler/msgs:Msg" %t925, ptr %l571
  br label %bb228
bb228:
  %t926 = load ptr, ptr %l551, !tbaa !29
  %t927 = load i64, ptr %l552, !tbaa !24
  %t928 = load { i64, [3 x i64] }, ptr %l566
  %t929 = load %"compiler/msgs:Msg", ptr %l571
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s40, ptr %t926, i64 %t927, { i64, [3 x i64] } %t928, %"compiler/msgs:Msg" %t929)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s40)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s37)
  br label %bb232
bb231:
  %t930 = load i64, ptr %l71, !tbaa !24
  %t932 = add i64 %t930, 1
  store i64 %t932, ptr %l71, !tbaa !24
  br label %bb194
bb232:
  call void @__olang_scope_close(ptr %s34)
  br label %bb233
bb233:
  %t934 = load i64, ptr %l65, !tbaa !24
  %t936 = add i64 %t934, 1
  store i64 %t936, ptr %l65, !tbaa !24
  br label %bb180
bb234:
  %t938 = load i64, ptr %l62, !tbaa !24
  %t939 = load i64, ptr %l64, !tbaa !24
  %t942 = add i64 %t938, %t939
  store i64 %t942, ptr %l62, !tbaa !24
  call void @__olang_scope_close(ptr %s33)
  br label %bb235
bb235:
  br label %bb173
bb236:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  br label %bb237
bb237:
  %t944 = load i64, ptr %l58, !tbaa !24
  %t946 = add i64 %t944, 1
  store i64 %t946, ptr %l58, !tbaa !24
  br label %bb168
bb238:
  br label %bb239
bb239:
  store i64 0, ptr %l76, !tbaa !24
  %t949 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23)
  store i64 %t949, ptr %l582
  br label %bb240
bb240:
  %t950 = load i64, ptr %l582, !tbaa !24
  store i64 %t950, ptr %l77, !tbaa !24
  store i64 1, ptr %l78, !tbaa !24
  %t951 = load i64, ptr %l77, !tbaa !24
  %t952 = load i64, ptr %l76, !tbaa !24
  %t955 = icmp sgt i64 %t951, %t952
  br i1 %t955, label %bb241, label %bb242
bb241:
  %t957 = load i64, ptr %l78, !tbaa !24
  %t959 = icmp sgt i64 %t957, 0
  br i1 %t959, label %bb243, label %bb244
bb242:
  store i64 0, ptr %l586, !tbaa !24
  br label %bb246
bb243:
  %t961 = load i64, ptr %l77, !tbaa !24
  %t962 = load i64, ptr %l76, !tbaa !24
  %t965 = sub i64 %t961, %t962
  %t966 = load i64, ptr %l78, !tbaa !24
  %t969 = add i64 %t965, %t966
  %t971 = sub i64 %t969, 1
  %t972 = load i64, ptr %l78, !tbaa !24
  %t975 = sdiv i64 %t971, %t972
  store i64 %t975, ptr %l589, !tbaa !24
  br label %bb245
bb244:
  store i64 0, ptr %l589, !tbaa !24
  br label %bb245
bb245:
  %t977 = load i64, ptr %l589, !tbaa !24
  store i64 %t977, ptr %l586, !tbaa !24
  br label %bb246
bb246:
  %t978 = load i64, ptr %l586, !tbaa !24
  store i64 %t978, ptr %l79, !tbaa !24
  store i64 0, ptr %l80, !tbaa !24
  br label %bb247
bb247:
  store %olang.scope zeroinitializer, ptr %s45
  %t979 = load i64, ptr %l80, !tbaa !24
  %t980 = load i64, ptr %l79, !tbaa !24
  %t983 = icmp slt i64 %t979, %t980
  %t985 = xor i1 %t983, true
  br i1 %t985, label %bb248, label %bb249
bb248:
  call void @__olang_scope_close(ptr %s45)
  br label %bb256
bb249:
  br label %bb250
bb250:
  %t987 = load i64, ptr %l76, !tbaa !24
  %t988 = load i64, ptr %l80, !tbaa !24
  %t989 = load i64, ptr %l78, !tbaa !24
  %t992 = mul i64 %t988, %t989
  %t995 = add i64 %t987, %t992
  store i64 %t995, ptr %l81, !tbaa !24
  %t997 = load ptr, ptr %l0, !tbaa !29
  store ptr %t997, ptr %l607, !tbaa !29
  %t998 = load i64, ptr %l81, !tbaa !24
  %t1001 = call %"compiler/views:place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %l23, i64 %t998)
  store %"compiler/views:place" %t1001, ptr %l610
  br label %bb251
bb251:
  %t1002 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t1002, ptr %l611
  %t1003 = load i64, ptr %l21, !tbaa !24
  store i64 %t1003, ptr %l612, !tbaa !24
  %t1004 = load i64, ptr %l81, !tbaa !24
  %t1007 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l24, i64 %t1004)
  store i64 %t1007, ptr %l615
  br label %bb252
bb252:
  %t1008 = load i64, ptr %l81, !tbaa !24
  %t1011 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l25, i64 %t1008)
  store %"compiler/source:Span" %t1011, ptr %l618
  br label %bb253
bb253:
  %t1012 = load ptr, ptr %l4, !tbaa !29
  %t1013 = load ptr, ptr %l607, !tbaa !29
  %t1014 = load %"compiler/views:place", ptr %l610
  %t1015 = load %"compiler/source:Span", ptr %l611
  %t1016 = load i64, ptr %l612, !tbaa !24
  %t1017 = load i64, ptr %l615, !tbaa !24
  %t1018 = load %"compiler/source:Span", ptr %l618
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v2, ptr %t1013, %"compiler/views:place" %t1014, %"compiler/source:Span" %t1015, i64 %t1016, i64 %t1017, %"compiler/source:Span" %t1018, ptr %t1012)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s45)
  br label %bb255
bb255:
  %t1020 = load i64, ptr %l80, !tbaa !24
  %t1022 = add i64 %t1020, 1
  store i64 %t1022, ptr %l80, !tbaa !24
  br label %bb247
bb256:
  store ptr %l6, ptr %l82, !tbaa !29
  store i64 0, ptr %l83, !tbaa !24
  br label %bb257
bb257:
  store %olang.scope zeroinitializer, ptr %s48
  %t1025 = load ptr, ptr %l82, !tbaa !29
  %t1026 = load i64, ptr %l83, !tbaa !24
  %t1029 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t1025, i64 %t1026)
  %t1030 = extractvalue { i32, { i64, ptr } } %t1029, 1
  %t1031 = extractvalue { i32, { i64, ptr } } %t1029, 0
  store i32 %t1031, ptr %l627
  %t1032 = icmp ne i32 %t1031, 0
  br i1 %t1032, label %bb259, label %ok.1033
ok.1033:
  store { i64, ptr } %t1030, ptr %l626
  br label %bb258
bb258:
  %t1034 = load { i64, ptr }, ptr %l626, !tbaa !27
  store { i64, ptr } %t1034, ptr %l623, !tbaa !27
  br label %bb263
bb259:
  %t1035 = load i32, ptr %l627, !tbaa !23
  %t1036 = ashr i32 %t1035, 16
  %t1038 = icmp eq i32 %t1036, 1
  br i1 %t1038, label %bb260, label %bb261
bb260:
  br label %bb262
bb261:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb262:
  call void @__olang_scope_close(ptr %s48)
  br label %bb272
bb263:
  %t1040 = load { i64, ptr }, ptr %l623, !tbaa !27
  store { i64, ptr } %t1040, ptr %l84, !tbaa !27
  %t1041 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t1043 = extractvalue { i64, ptr } %t1041, 0
  store i64 %t1043, ptr %l85, !tbaa !24
  store i64 0, ptr %l86, !tbaa !24
  br label %bb264
bb264:
  store %olang.scope zeroinitializer, ptr %s49
  %t1045 = load i64, ptr %l86, !tbaa !24
  %t1046 = load i64, ptr %l85, !tbaa !24
  %t1049 = icmp slt i64 %t1045, %t1046
  %t1051 = xor i1 %t1049, true
  br i1 %t1051, label %bb265, label %bb266
bb265:
  call void @__olang_scope_close(ptr %s49)
  br label %bb270
bb266:
  br label %bb267
bb267:
  %t1053 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t1053, ptr %l636, !tbaa !27
  %t1054 = load i64, ptr %l86, !tbaa !24
  %t1056 = getelementptr { i64, ptr }, ptr %l636, i32 0, i32 1
  %t1057 = load ptr, ptr %t1056, !tbaa !27
  %t1058 = getelementptr %"compiler/views:view", ptr %t1057, i64 %t1054
  %t1059 = load %"compiler/views:view", ptr %t1058
  %t1061 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1061, %"compiler/views:view" %t1059)
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s49)
  br label %bb269
bb269:
  %t1065 = load i64, ptr %l86, !tbaa !24
  %t1067 = add i64 %t1065, 1
  store i64 %t1067, ptr %l86, !tbaa !24
  br label %bb264
bb270:
  %t1069 = load i64, ptr %l83, !tbaa !24
  %t1070 = load i64, ptr %l85, !tbaa !24
  %t1073 = add i64 %t1069, %t1070
  store i64 %t1073, ptr %l83, !tbaa !24
  call void @__olang_scope_close(ptr %s48)
  br label %bb271
bb271:
  br label %bb257
bb272:
  %t1075 = load ptr, ptr @__olang_prog_scope
  %t1076 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t1075)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1076, ptr %l646
  br label %bb273
bb273:
  %t1077 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l646
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1077, ptr %l88
  store i64 0, ptr %l89, !tbaa !24
  %t1078 = load i64, ptr %l12, !tbaa !24
  store i64 %t1078, ptr %l90, !tbaa !24
  store i64 1, ptr %l91, !tbaa !24
  %t1080 = load i64, ptr %l90, !tbaa !24
  %t1081 = load i64, ptr %l89, !tbaa !24
  %t1084 = icmp sgt i64 %t1080, %t1081
  br i1 %t1084, label %bb274, label %bb275
bb274:
  %t1086 = load i64, ptr %l91, !tbaa !24
  %t1088 = icmp sgt i64 %t1086, 0
  br i1 %t1088, label %bb276, label %bb277
bb275:
  store i64 0, ptr %l651, !tbaa !24
  br label %bb279
bb276:
  %t1090 = load i64, ptr %l90, !tbaa !24
  %t1091 = load i64, ptr %l89, !tbaa !24
  %t1094 = sub i64 %t1090, %t1091
  %t1095 = load i64, ptr %l91, !tbaa !24
  %t1098 = add i64 %t1094, %t1095
  %t1100 = sub i64 %t1098, 1
  %t1101 = load i64, ptr %l91, !tbaa !24
  %t1104 = sdiv i64 %t1100, %t1101
  store i64 %t1104, ptr %l654, !tbaa !24
  br label %bb278
bb277:
  store i64 0, ptr %l654, !tbaa !24
  br label %bb278
bb278:
  %t1106 = load i64, ptr %l654, !tbaa !24
  store i64 %t1106, ptr %l651, !tbaa !24
  br label %bb279
bb279:
  %t1107 = load i64, ptr %l651, !tbaa !24
  store i64 %t1107, ptr %l92, !tbaa !24
  store i64 0, ptr %l93, !tbaa !24
  br label %bb280
bb280:
  store %olang.scope zeroinitializer, ptr %s52
  %t1108 = load i64, ptr %l93, !tbaa !24
  %t1109 = load i64, ptr %l92, !tbaa !24
  %t1112 = icmp slt i64 %t1108, %t1109
  %t1114 = xor i1 %t1112, true
  br i1 %t1114, label %bb281, label %bb282
bb281:
  call void @__olang_scope_close(ptr %s52)
  br label %bb286
bb282:
  br label %bb283
bb283:
  %t1116 = load i64, ptr %l89, !tbaa !24
  %t1117 = load i64, ptr %l93, !tbaa !24
  %t1118 = load i64, ptr %l91, !tbaa !24
  %t1121 = mul i64 %t1117, %t1118
  %t1124 = add i64 %t1116, %t1121
  store i64 %t1124, ptr %l94, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l88, i1 false)
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s52)
  br label %bb285
bb285:
  %t1127 = load i64, ptr %l93, !tbaa !24
  %t1129 = add i64 %t1127, 1
  store i64 %t1129, ptr %l93, !tbaa !24
  br label %bb280
bb286:
  %t1131 = load i1, ptr %l22, !tbaa !21
  br i1 %t1131, label %bb287, label %bb288
bb287:
  %t1133 = load ptr, ptr %l0, !tbaa !29
  %t1135 = getelementptr %"compiler/views:Viewer", ptr %t1133, i32 0, i32 2
  %t1136 = load i64, ptr %l7, !tbaa !24
  %t1139 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1135, i64 %t1136)
  store ptr %t1139, ptr %l679
  br label %bb289
bb288:
  br label %bb332
bb289:
  %t1140 = load ptr, ptr %l679, !tbaa !29
  %t1142 = getelementptr %"compiler/views:summary", ptr %t1140, i32 0, i32 1
  store ptr %t1142, ptr %l95, !tbaa !29
  store i64 0, ptr %l96, !tbaa !24
  br label %bb290
bb290:
  store %olang.scope zeroinitializer, ptr %s56
  %t1144 = load ptr, ptr %l95, !tbaa !29
  %t1145 = load i64, ptr %l96, !tbaa !24
  %t1148 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t1144, i64 %t1145)
  %t1149 = extractvalue { i32, { i64, ptr } } %t1148, 1
  %t1150 = extractvalue { i32, { i64, ptr } } %t1148, 0
  store i32 %t1150, ptr %l686
  %t1151 = icmp ne i32 %t1150, 0
  br i1 %t1151, label %bb292, label %ok.1152
ok.1152:
  store { i64, ptr } %t1149, ptr %l685
  br label %bb291
bb291:
  %t1153 = load { i64, ptr }, ptr %l685, !tbaa !27
  store { i64, ptr } %t1153, ptr %l682, !tbaa !27
  br label %bb296
bb292:
  %t1154 = load i32, ptr %l686, !tbaa !23
  %t1155 = ashr i32 %t1154, 16
  %t1157 = icmp eq i32 %t1155, 1
  br i1 %t1157, label %bb293, label %bb294
bb293:
  br label %bb295
bb294:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb295:
  call void @__olang_scope_close(ptr %s56)
  br label %bb331
bb296:
  %t1159 = load { i64, ptr }, ptr %l682, !tbaa !27
  store { i64, ptr } %t1159, ptr %l97, !tbaa !27
  %t1160 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t1162 = extractvalue { i64, ptr } %t1160, 0
  store i64 %t1162, ptr %l98, !tbaa !24
  store i64 0, ptr %l99, !tbaa !24
  br label %bb297
bb297:
  store %olang.scope zeroinitializer, ptr %s57
  %t1164 = load i64, ptr %l99, !tbaa !24
  %t1165 = load i64, ptr %l98, !tbaa !24
  %t1168 = icmp slt i64 %t1164, %t1165
  %t1170 = xor i1 %t1168, true
  br i1 %t1170, label %bb298, label %bb299
bb298:
  call void @__olang_scope_close(ptr %s57)
  br label %bb329
bb299:
  br label %bb300
bb300:
  %t1172 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t1172, ptr %l695, !tbaa !27
  %t1173 = load i64, ptr %l99, !tbaa !24
  %t1175 = getelementptr { i64, ptr }, ptr %l695, i32 0, i32 1
  %t1176 = load ptr, ptr %t1175, !tbaa !27
  %t1177 = getelementptr %"compiler/views:fact", ptr %t1176, i64 %t1173
  %t1178 = load %"compiler/views:fact", ptr %t1177
  store %"compiler/views:fact" %t1178, ptr %l100
  %t1180 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1181 = load i64, ptr %t1180, !tbaa !24
  %t1183 = icmp slt i64 %t1181, 0
  br i1 %t1183, label %bb301, label %bb302
bb301:
  store i1 true, ptr %l700, !tbaa !21
  br label %bb303
bb302:
  %t1185 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1186 = load i64, ptr %t1185, !tbaa !24
  %t1187 = load i64, ptr %l12, !tbaa !24
  %t1190 = icmp sge i64 %t1186, %t1187
  store i1 %t1190, ptr %l700, !tbaa !21
  br label %bb303
bb303:
  %t1192 = load i1, ptr %l700, !tbaa !21
  br i1 %t1192, label %bb304, label %bb305
bb304:
  call void @__olang_scope_close(ptr %s57)
  br label %bb328
bb305:
  br label %bb306
bb306:
  %t1193 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1194 = load i64, ptr %t1193, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l88, i64 %t1194, i1 true)
  br label %bb307
bb307:
  %t1197 = load ptr, ptr @__olang_prog_scope
  %t1198 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t1197)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1198, ptr %l706
  br label %bb308
bb308:
  %t1199 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l706
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1199, ptr %l101
  %t1200 = load ptr, ptr %l0, !tbaa !29
  %t1201 = load ptr, ptr %l3, !tbaa !29
  %t1203 = getelementptr %"compiler/typed:Call", ptr %t1201, i32 0, i32 1
  %t1204 = load { i64, ptr }, ptr %t1203, !tbaa !27
  store { i64, ptr } %t1204, ptr %l709, !tbaa !27
  %t1205 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 0
  %t1206 = load i64, ptr %t1205, !tbaa !24
  %t1208 = getelementptr { i64, ptr }, ptr %l709, i32 0, i32 1
  %t1209 = load ptr, ptr %t1208, !tbaa !27
  %t1210 = getelementptr ptr, ptr %t1209, i64 %t1206
  %t1211 = load ptr, ptr %t1210, !tbaa !39
  %t1212 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s57, ptr %t1200, ptr %t1211, ptr %t1212, ptr %l101)
  br label %bb309
bb309:
  store ptr %l101, ptr %l102, !tbaa !29
  store i64 0, ptr %l103, !tbaa !24
  br label %bb310
bb310:
  store %olang.scope zeroinitializer, ptr %s60
  %t1218 = load ptr, ptr %l102, !tbaa !29
  %t1219 = load i64, ptr %l103, !tbaa !24
  %t1222 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s57, ptr %t1218, i64 %t1219)
  %t1223 = extractvalue { i32, { i64, ptr } } %t1222, 1
  %t1224 = extractvalue { i32, { i64, ptr } } %t1222, 0
  store i32 %t1224, ptr %l719
  %t1225 = icmp ne i32 %t1224, 0
  br i1 %t1225, label %bb312, label %ok.1226
ok.1226:
  store { i64, ptr } %t1223, ptr %l718
  br label %bb311
bb311:
  %t1227 = load { i64, ptr }, ptr %l718, !tbaa !27
  store { i64, ptr } %t1227, ptr %l715, !tbaa !27
  br label %bb316
bb312:
  %t1228 = load i32, ptr %l719, !tbaa !23
  %t1229 = ashr i32 %t1228, 16
  %t1231 = icmp eq i32 %t1229, 1
  br i1 %t1231, label %bb313, label %bb314
bb313:
  br label %bb315
bb314:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb315:
  call void @__olang_scope_close(ptr %s60)
  br label %bb327
bb316:
  %t1233 = load { i64, ptr }, ptr %l715, !tbaa !27
  store { i64, ptr } %t1233, ptr %l104, !tbaa !27
  %t1234 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t1236 = extractvalue { i64, ptr } %t1234, 0
  store i64 %t1236, ptr %l105, !tbaa !24
  store i64 0, ptr %l106, !tbaa !24
  br label %bb317
bb317:
  store %olang.scope zeroinitializer, ptr %s61
  %t1238 = load i64, ptr %l106, !tbaa !24
  %t1239 = load i64, ptr %l105, !tbaa !24
  %t1242 = icmp slt i64 %t1238, %t1239
  %t1244 = xor i1 %t1242, true
  br i1 %t1244, label %bb318, label %bb319
bb318:
  call void @__olang_scope_close(ptr %s61)
  br label %bb325
bb319:
  br label %bb320
bb320:
  %t1246 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t1246, ptr %l728, !tbaa !27
  %t1247 = load i64, ptr %l106, !tbaa !24
  %t1249 = getelementptr { i64, ptr }, ptr %l728, i32 0, i32 1
  %t1250 = load ptr, ptr %t1249, !tbaa !27
  %t1251 = getelementptr %"compiler/views:place", ptr %t1250, i64 %t1247
  %t1252 = load %"compiler/views:place", ptr %t1251
  %t1254 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1254, ptr %l731, !tbaa !29
  %t1255 = load ptr, ptr %l0, !tbaa !29
  %t1257 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 3
  %t1258 = load i64, ptr %t1257, !tbaa !24
  %t1259 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 4
  %t1260 = load i64, ptr %t1259, !tbaa !24
  %t1261 = getelementptr %"compiler/views:fact", ptr %l100, i32 0, i32 5
  %t1262 = load i1, ptr %t1261, !tbaa !21
  %t1268 = call %"compiler/views:place" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebelow(ptr %v0, ptr %t1255, %"compiler/views:place" %t1252, i64 %t1258, i64 %t1260, i1 %t1262)
  store %"compiler/views:place" %t1268, ptr %l737
  br label %bb321
bb321:
  %t1269 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t1270 = load i32, ptr %t1269, !tbaa !23
  %t1272 = sext i32 %t1270 to i64
  %t1273 = load %"compiler/views:place", ptr %l737
  %t1275 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s61, %"compiler/views:place" %t1273, i64 %t1272)
  store %"compiler/views:view" %t1275, ptr %l740
  br label %bb322
bb322:
  %t1276 = load ptr, ptr %l731, !tbaa !29
  %t1277 = load %"compiler/views:view", ptr %l740
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1276, %"compiler/views:view" %t1277)
  br label %bb323
bb323:
  call void @__olang_scope_close(ptr %s61)
  br label %bb324
bb324:
  %t1278 = load i64, ptr %l106, !tbaa !24
  %t1280 = add i64 %t1278, 1
  store i64 %t1280, ptr %l106, !tbaa !24
  br label %bb317
bb325:
  %t1282 = load i64, ptr %l103, !tbaa !24
  %t1283 = load i64, ptr %l105, !tbaa !24
  %t1286 = add i64 %t1282, %t1283
  store i64 %t1286, ptr %l103, !tbaa !24
  call void @__olang_scope_close(ptr %s60)
  br label %bb326
bb326:
  br label %bb310
bb327:
  call void @__olang_scope_close(ptr %s57)
  br label %bb328
bb328:
  %t1288 = load i64, ptr %l99, !tbaa !24
  %t1290 = add i64 %t1288, 1
  store i64 %t1290, ptr %l99, !tbaa !24
  br label %bb297
bb329:
  %t1292 = load i64, ptr %l96, !tbaa !24
  %t1293 = load i64, ptr %l98, !tbaa !24
  %t1296 = add i64 %t1292, %t1293
  store i64 %t1296, ptr %l96, !tbaa !24
  call void @__olang_scope_close(ptr %s56)
  br label %bb330
bb330:
  br label %bb290
bb331:
  br label %bb332
bb332:
  %t1298 = load ptr, ptr %l0, !tbaa !29
  %t1299 = load i32, ptr %l2, !tbaa !23
  %t1302 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t1298, i32 %t1299)
  store i1 %t1302, ptr %l753
  br label %bb333
bb333:
  %t1303 = load i1, ptr %l753, !tbaa !21
  br i1 %t1303, label %bb334, label %bb335
bb334:
  store i64 0, ptr %l108, !tbaa !24
  %t1304 = load i64, ptr %l12, !tbaa !24
  store i64 %t1304, ptr %l109, !tbaa !24
  store i64 1, ptr %l110, !tbaa !24
  %t1306 = load i64, ptr %l109, !tbaa !24
  %t1307 = load i64, ptr %l108, !tbaa !24
  %t1310 = icmp sgt i64 %t1306, %t1307
  br i1 %t1310, label %bb336, label %bb337
bb335:
  br label %bb421
bb336:
  %t1312 = load i64, ptr %l110, !tbaa !24
  %t1314 = icmp sgt i64 %t1312, 0
  br i1 %t1314, label %bb338, label %bb339
bb337:
  store i64 0, ptr %l758, !tbaa !24
  br label %bb341
bb338:
  %t1316 = load i64, ptr %l109, !tbaa !24
  %t1317 = load i64, ptr %l108, !tbaa !24
  %t1320 = sub i64 %t1316, %t1317
  %t1321 = load i64, ptr %l110, !tbaa !24
  %t1324 = add i64 %t1320, %t1321
  %t1326 = sub i64 %t1324, 1
  %t1327 = load i64, ptr %l110, !tbaa !24
  %t1330 = sdiv i64 %t1326, %t1327
  store i64 %t1330, ptr %l761, !tbaa !24
  br label %bb340
bb339:
  store i64 0, ptr %l761, !tbaa !24
  br label %bb340
bb340:
  %t1332 = load i64, ptr %l761, !tbaa !24
  store i64 %t1332, ptr %l758, !tbaa !24
  br label %bb341
bb341:
  %t1333 = load i64, ptr %l758, !tbaa !24
  store i64 %t1333, ptr %l111, !tbaa !24
  store i64 0, ptr %l112, !tbaa !24
  br label %bb342
bb342:
  store %olang.scope zeroinitializer, ptr %s66
  %t1334 = load i64, ptr %l112, !tbaa !24
  %t1335 = load i64, ptr %l111, !tbaa !24
  %t1338 = icmp slt i64 %t1334, %t1335
  %t1340 = xor i1 %t1338, true
  br i1 %t1340, label %bb343, label %bb344
bb343:
  call void @__olang_scope_close(ptr %s66)
  br label %bb420
bb344:
  br label %bb345
bb345:
  %t1342 = load i64, ptr %l108, !tbaa !24
  %t1343 = load i64, ptr %l112, !tbaa !24
  %t1344 = load i64, ptr %l110, !tbaa !24
  %t1347 = mul i64 %t1343, %t1344
  %t1350 = add i64 %t1342, %t1347
  store i64 %t1350, ptr %l113, !tbaa !24
  %t1352 = load i64, ptr %l113, !tbaa !24
  %t1355 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l88, i64 %t1352)
  store i1 %t1355, ptr %l781
  br label %bb346
bb346:
  %t1356 = load i1, ptr %l781, !tbaa !21
  br i1 %t1356, label %bb347, label %bb348
bb347:
  call void @__olang_scope_close(ptr %s66)
  br label %bb419
bb348:
  br label %bb349
bb349:
  %t1357 = load i1, ptr %l8, !tbaa !21
  br i1 %t1357, label %bb350, label %bb351
bb350:
  store i1 true, ptr %l783, !tbaa !21
  br label %bb365
bb351:
  %t1359 = load i64, ptr %l7, !tbaa !24
  %t1361 = icmp sge i64 %t1359, 0
  br i1 %t1361, label %bb352, label %bb353
bb352:
  %t1363 = load i1, ptr %l22, !tbaa !21
  %t1365 = xor i1 %t1363, true
  br i1 %t1365, label %bb354, label %bb355
bb353:
  store i1 false, ptr %l786, !tbaa !21
  br label %bb364
bb354:
  store i1 true, ptr %l789, !tbaa !21
  br label %bb363
bb355:
  %t1367 = load i64, ptr %l113, !tbaa !24
  store i64 %t1367, ptr %l790, !tbaa !24
  %t1368 = load ptr, ptr %l0, !tbaa !29
  %t1370 = getelementptr %"compiler/views:Viewer", ptr %t1368, i32 0, i32 2
  %t1371 = load i64, ptr %l7, !tbaa !24
  %t1374 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1370, i64 %t1371)
  store ptr %t1374, ptr %l794
  br label %bb356
bb356:
  %t1375 = load ptr, ptr %l794, !tbaa !29
  %t1377 = getelementptr %"compiler/views:summary", ptr %t1375, i32 0, i32 3
  %t1379 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1377)
  store i64 %t1379, ptr %l797
  br label %bb357
bb357:
  %t1380 = load i64, ptr %l790, !tbaa !24
  %t1381 = load i64, ptr %l797, !tbaa !24
  %t1382 = icmp slt i64 %t1380, %t1381
  br i1 %t1382, label %bb358, label %bb359
bb358:
  %t1384 = load ptr, ptr %l0, !tbaa !29
  %t1386 = getelementptr %"compiler/views:Viewer", ptr %t1384, i32 0, i32 2
  %t1387 = load i64, ptr %l7, !tbaa !24
  %t1390 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1386, i64 %t1387)
  store ptr %t1390, ptr %l803
  br label %bb360
bb359:
  store i1 false, ptr %l799, !tbaa !21
  br label %bb362
bb360:
  %t1391 = load ptr, ptr %l803, !tbaa !29
  %t1393 = getelementptr %"compiler/views:summary", ptr %t1391, i32 0, i32 3
  %t1394 = load i64, ptr %l113, !tbaa !24
  %t1397 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1393, i64 %t1394)
  store i1 %t1397, ptr %l807
  br label %bb361
bb361:
  %t1398 = load i1, ptr %l807, !tbaa !21
  store i1 %t1398, ptr %l799, !tbaa !21
  br label %bb362
bb362:
  %t1399 = load i1, ptr %l799, !tbaa !21
  store i1 %t1399, ptr %l789, !tbaa !21
  br label %bb363
bb363:
  %t1400 = load i1, ptr %l789, !tbaa !21
  store i1 %t1400, ptr %l786, !tbaa !21
  br label %bb364
bb364:
  %t1401 = load i1, ptr %l786, !tbaa !21
  store i1 %t1401, ptr %l783, !tbaa !21
  br label %bb365
bb365:
  %t1402 = load i1, ptr %l783, !tbaa !21
  br i1 %t1402, label %bb366, label %bb367
bb366:
  store %olang.scope zeroinitializer, ptr %s69
  %t1405 = load i64, ptr %l113, !tbaa !24
  %t1408 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t1405)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1408, ptr %l811
  br label %bb368
bb367:
  br label %bb385
bb368:
  %t1409 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l811
  %t1410 = call ptr @__olang_scope_alloc_a(ptr %s69, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1409, ptr %t1410
  store ptr %t1410, ptr %l115, !tbaa !29
  store i64 0, ptr %l116, !tbaa !24
  br label %bb369
bb369:
  store %olang.scope zeroinitializer, ptr %s70
  %t1412 = load ptr, ptr %l115, !tbaa !29
  %t1413 = load i64, ptr %l116, !tbaa !24
  %t1416 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t1412, i64 %t1413)
  %t1417 = extractvalue { i32, { i64, ptr } } %t1416, 1
  %t1418 = extractvalue { i32, { i64, ptr } } %t1416, 0
  store i32 %t1418, ptr %l817
  %t1419 = icmp ne i32 %t1418, 0
  br i1 %t1419, label %bb371, label %ok.1420
ok.1420:
  store { i64, ptr } %t1417, ptr %l816
  br label %bb370
bb370:
  %t1421 = load { i64, ptr }, ptr %l816, !tbaa !27
  store { i64, ptr } %t1421, ptr %l813, !tbaa !27
  br label %bb375
bb371:
  %t1422 = load i32, ptr %l817, !tbaa !23
  %t1423 = ashr i32 %t1422, 16
  %t1425 = icmp eq i32 %t1423, 1
  br i1 %t1425, label %bb372, label %bb373
bb372:
  br label %bb374
bb373:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb374:
  call void @__olang_scope_close(ptr %s70)
  br label %bb384
bb375:
  %t1427 = load { i64, ptr }, ptr %l813, !tbaa !27
  store { i64, ptr } %t1427, ptr %l117, !tbaa !27
  %t1428 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t1430 = extractvalue { i64, ptr } %t1428, 0
  store i64 %t1430, ptr %l118, !tbaa !24
  store i64 0, ptr %l119, !tbaa !24
  br label %bb376
bb376:
  store %olang.scope zeroinitializer, ptr %s71
  %t1432 = load i64, ptr %l119, !tbaa !24
  %t1433 = load i64, ptr %l118, !tbaa !24
  %t1436 = icmp slt i64 %t1432, %t1433
  %t1438 = xor i1 %t1436, true
  br i1 %t1438, label %bb377, label %bb378
bb377:
  call void @__olang_scope_close(ptr %s71)
  br label %bb382
bb378:
  br label %bb379
bb379:
  %t1440 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t1440, ptr %l826, !tbaa !27
  %t1441 = load i64, ptr %l119, !tbaa !24
  %t1443 = getelementptr { i64, ptr }, ptr %l826, i32 0, i32 1
  %t1444 = load ptr, ptr %t1443, !tbaa !27
  %t1445 = getelementptr %"compiler/views:view", ptr %t1444, i64 %t1441
  %t1446 = load %"compiler/views:view", ptr %t1445
  %t1448 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1448, %"compiler/views:view" %t1446)
  br label %bb380
bb380:
  call void @__olang_scope_close(ptr %s71)
  br label %bb381
bb381:
  %t1452 = load i64, ptr %l119, !tbaa !24
  %t1454 = add i64 %t1452, 1
  store i64 %t1454, ptr %l119, !tbaa !24
  br label %bb376
bb382:
  %t1456 = load i64, ptr %l116, !tbaa !24
  %t1457 = load i64, ptr %l118, !tbaa !24
  %t1460 = add i64 %t1456, %t1457
  store i64 %t1460, ptr %l116, !tbaa !24
  call void @__olang_scope_close(ptr %s70)
  br label %bb383
bb383:
  br label %bb369
bb384:
  call void @__olang_scope_close(ptr %s69)
  br label %bb385
bb385:
  %t1462 = load i1, ptr %l8, !tbaa !21
  br i1 %t1462, label %bb386, label %bb387
bb386:
  %t1464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1464, ptr %l838, !tbaa !29
  %t1465 = load ptr, ptr %l3, !tbaa !29
  %t1467 = getelementptr %"compiler/typed:Call", ptr %t1465, i32 0, i32 1
  %t1468 = load { i64, ptr }, ptr %t1467, !tbaa !27
  store { i64, ptr } %t1468, ptr %l840, !tbaa !27
  %t1469 = load i64, ptr %l113, !tbaa !24
  %t1471 = getelementptr { i64, ptr }, ptr %l840, i32 0, i32 1
  %t1472 = load ptr, ptr %t1471, !tbaa !27
  %t1473 = getelementptr ptr, ptr %t1472, i64 %t1469
  %t1474 = load ptr, ptr %t1473, !tbaa !39
  %t1476 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1474)
  store i32 %t1476, ptr %l843
  br label %bb388
bb387:
  store i1 false, ptr %l837, !tbaa !21
  br label %bb390
bb388:
  %t1477 = load ptr, ptr %l838, !tbaa !29
  %t1478 = load i32, ptr %l843, !tbaa !23
  %t1479 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %t1477, i32 %t1478)
  store i1 %t1479, ptr %l844
  br label %bb389
bb389:
  %t1480 = load i1, ptr %l844, !tbaa !21
  store i1 %t1480, ptr %l837, !tbaa !21
  br label %bb390
bb390:
  %t1481 = load i1, ptr %l837, !tbaa !21
  br i1 %t1481, label %bb391, label %bb392
bb391:
  %t1482 = load ptr, ptr %l0, !tbaa !29
  %t1483 = load i32, ptr %l2, !tbaa !23
  %t1486 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earrayish(ptr %v0, ptr %t1482, i32 %t1483)
  store i1 %t1486, ptr %l848
  br label %bb393
bb392:
  store i1 false, ptr %l845, !tbaa !21
  br label %bb394
bb393:
  %t1487 = load i1, ptr %l848, !tbaa !21
  store i1 %t1487, ptr %l845, !tbaa !21
  br label %bb394
bb394:
  %t1488 = load i1, ptr %l845, !tbaa !21
  br i1 %t1488, label %bb395, label %bb396
bb395:
  store %olang.scope zeroinitializer, ptr %s73
  %t1489 = load ptr, ptr @__olang_prog_scope
  %t1490 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t1489)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1490, ptr %l849
  br label %bb397
bb396:
  br label %bb418
bb397:
  %t1491 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l849
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1491, ptr %l121
  %t1492 = load ptr, ptr %l0, !tbaa !29
  %t1493 = load ptr, ptr %l3, !tbaa !29
  %t1495 = getelementptr %"compiler/typed:Call", ptr %t1493, i32 0, i32 1
  %t1496 = load { i64, ptr }, ptr %t1495, !tbaa !27
  store { i64, ptr } %t1496, ptr %l852, !tbaa !27
  %t1497 = load i64, ptr %l113, !tbaa !24
  %t1499 = getelementptr { i64, ptr }, ptr %l852, i32 0, i32 1
  %t1500 = load ptr, ptr %t1499, !tbaa !27
  %t1501 = getelementptr ptr, ptr %t1500, i64 %t1497
  %t1502 = load ptr, ptr %t1501, !tbaa !39
  %t1503 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s73, ptr %t1492, ptr %t1502, ptr %t1503, ptr %l121)
  br label %bb398
bb398:
  store ptr %l121, ptr %l122, !tbaa !29
  store i64 0, ptr %l123, !tbaa !24
  br label %bb399
bb399:
  store %olang.scope zeroinitializer, ptr %s75
  %t1509 = load ptr, ptr %l122, !tbaa !29
  %t1510 = load i64, ptr %l123, !tbaa !24
  %t1513 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s73, ptr %t1509, i64 %t1510)
  %t1514 = extractvalue { i32, { i64, ptr } } %t1513, 1
  %t1515 = extractvalue { i32, { i64, ptr } } %t1513, 0
  store i32 %t1515, ptr %l862
  %t1516 = icmp ne i32 %t1515, 0
  br i1 %t1516, label %bb401, label %ok.1517
ok.1517:
  store { i64, ptr } %t1514, ptr %l861
  br label %bb400
bb400:
  %t1518 = load { i64, ptr }, ptr %l861, !tbaa !27
  store { i64, ptr } %t1518, ptr %l858, !tbaa !27
  br label %bb405
bb401:
  %t1519 = load i32, ptr %l862, !tbaa !23
  %t1520 = ashr i32 %t1519, 16
  %t1522 = icmp eq i32 %t1520, 1
  br i1 %t1522, label %bb402, label %bb403
bb402:
  br label %bb404
bb403:
  call void @__olang_check_failed(ptr @.c31)
  unreachable
bb404:
  call void @__olang_scope_close(ptr %s75)
  br label %bb417
bb405:
  %t1524 = load { i64, ptr }, ptr %l858, !tbaa !27
  store { i64, ptr } %t1524, ptr %l124, !tbaa !27
  %t1525 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t1527 = extractvalue { i64, ptr } %t1525, 0
  store i64 %t1527, ptr %l125, !tbaa !24
  store i64 0, ptr %l126, !tbaa !24
  br label %bb406
bb406:
  store %olang.scope zeroinitializer, ptr %s76
  %t1529 = load i64, ptr %l126, !tbaa !24
  %t1530 = load i64, ptr %l125, !tbaa !24
  %t1533 = icmp slt i64 %t1529, %t1530
  %t1535 = xor i1 %t1533, true
  br i1 %t1535, label %bb407, label %bb408
bb407:
  call void @__olang_scope_close(ptr %s76)
  br label %bb415
bb408:
  br label %bb409
bb409:
  %t1537 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t1537, ptr %l871, !tbaa !27
  %t1538 = load i64, ptr %l126, !tbaa !24
  %t1540 = getelementptr { i64, ptr }, ptr %l871, i32 0, i32 1
  %t1541 = load ptr, ptr %t1540, !tbaa !27
  %t1542 = getelementptr %"compiler/views:place", ptr %t1541, i64 %t1538
  %t1543 = load %"compiler/views:place", ptr %t1542
  store %"compiler/views:place" %t1543, ptr %l127
  %t1545 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1545, ptr %l874, !tbaa !29
  %t1546 = getelementptr %"compiler/views:place", ptr %l127, i32 0, i32 0
  %t1547 = load { i64, [2 x i64] }, ptr %t1546
  store { i64, [2 x i64] } %t1547, ptr %l875
  %t1548 = getelementptr %"compiler/views:place", ptr %l127, i32 0, i32 1
  %t1549 = load i64, ptr %t1548, !tbaa !24
  store i64 %t1549, ptr %l876, !tbaa !24
  %t1550 = load ptr, ptr %l0, !tbaa !29
  %t1552 = getelementptr %"compiler/views:Viewer", ptr %t1550, i32 0, i32 3
  %t1553 = getelementptr %"compiler/views:place", ptr %l127, i32 0, i32 1
  %t1554 = load i64, ptr %t1553, !tbaa !24
  %t1557 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s76, ptr %t1552, i64 %t1554)
  store { i64, ptr } %t1557, ptr %l880
  br label %bb410
bb410:
  %t1558 = load { i64, ptr }, ptr %l880, !tbaa !27
  %t1559 = extractvalue { i64, ptr } %t1558, 0
  %t1560 = load { i64, [2 x i64] }, ptr %l875
  %t1561 = load i64, ptr %l876, !tbaa !24
  %t1563 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s76, { i64, [2 x i64] } %t1560, i64 %t1561, i64 %t1559, i1 true)
  store %"compiler/views:place" %t1563, ptr %l882
  br label %bb411
bb411:
  %t1564 = getelementptr %"compiler/source:Span", ptr %l20, i32 0, i32 0
  %t1565 = load i32, ptr %t1564, !tbaa !23
  %t1567 = sext i32 %t1565 to i64
  %t1568 = load %"compiler/views:place", ptr %l882
  %t1570 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s76, %"compiler/views:place" %t1568, i64 %t1567)
  store %"compiler/views:view" %t1570, ptr %l885
  br label %bb412
bb412:
  %t1571 = load ptr, ptr %l874, !tbaa !29
  %t1572 = load %"compiler/views:view", ptr %l885
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t1571, %"compiler/views:view" %t1572)
  br label %bb413
bb413:
  call void @__olang_scope_close(ptr %s76)
  br label %bb414
bb414:
  %t1573 = load i64, ptr %l126, !tbaa !24
  %t1575 = add i64 %t1573, 1
  store i64 %t1575, ptr %l126, !tbaa !24
  br label %bb406
bb415:
  %t1577 = load i64, ptr %l123, !tbaa !24
  %t1578 = load i64, ptr %l125, !tbaa !24
  %t1581 = add i64 %t1577, %t1578
  store i64 %t1581, ptr %l123, !tbaa !24
  call void @__olang_scope_close(ptr %s75)
  br label %bb416
bb416:
  br label %bb399
bb417:
  call void @__olang_scope_close(ptr %s73)
  br label %bb418
bb418:
  call void @__olang_scope_close(ptr %s66)
  br label %bb419
bb419:
  %t1583 = load i64, ptr %l112, !tbaa !24
  %t1585 = add i64 %t1583, 1
  store i64 %t1585, ptr %l112, !tbaa !24
  br label %bb342
bb420:
  br label %bb421
bb421:
  %t1587 = load i1, ptr %l22, !tbaa !21
  br i1 %t1587, label %bb422, label %bb423
bb422:
  %t1589 = load ptr, ptr %l0, !tbaa !29
  %t1591 = getelementptr %"compiler/views:Viewer", ptr %t1589, i32 0, i32 22
  %t1592 = load i1, ptr %t1591, !tbaa !21
  %t1594 = xor i1 %t1592, true
  store i1 %t1594, ptr %l894, !tbaa !21
  br label %bb424
bb423:
  store i1 false, ptr %l894, !tbaa !21
  br label %bb424
bb424:
  %t1596 = load i1, ptr %l894, !tbaa !21
  br i1 %t1596, label %bb425, label %bb426
bb425:
  %t1597 = load ptr, ptr %l0, !tbaa !29
  %t1599 = getelementptr %"compiler/views:Viewer", ptr %t1597, i32 0, i32 2
  %t1600 = load i64, ptr %l7, !tbaa !24
  %t1603 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t1599, i64 %t1600)
  store ptr %t1603, ptr %l901
  br label %bb427
bb426:
  br label %bb464
bb427:
  %t1604 = load ptr, ptr %l901, !tbaa !29
  %t1606 = getelementptr %"compiler/views:summary", ptr %t1604, i32 0, i32 2
  store ptr %t1606, ptr %l128, !tbaa !29
  store i64 0, ptr %l129, !tbaa !24
  br label %bb428
bb428:
  store %olang.scope zeroinitializer, ptr %s81
  %t1608 = load ptr, ptr %l128, !tbaa !29
  %t1609 = load i64, ptr %l129, !tbaa !24
  %t1612 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t1608, i64 %t1609)
  %t1613 = extractvalue { i32, { i64, ptr } } %t1612, 1
  %t1614 = extractvalue { i32, { i64, ptr } } %t1612, 0
  store i32 %t1614, ptr %l908
  %t1615 = icmp ne i32 %t1614, 0
  br i1 %t1615, label %bb430, label %ok.1616
ok.1616:
  store { i64, ptr } %t1613, ptr %l907
  br label %bb429
bb429:
  %t1617 = load { i64, ptr }, ptr %l907, !tbaa !27
  store { i64, ptr } %t1617, ptr %l904, !tbaa !27
  br label %bb434
bb430:
  %t1618 = load i32, ptr %l908, !tbaa !23
  %t1619 = ashr i32 %t1618, 16
  %t1621 = icmp eq i32 %t1619, 1
  br i1 %t1621, label %bb431, label %bb432
bb431:
  br label %bb433
bb432:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb433:
  call void @__olang_scope_close(ptr %s81)
  br label %bb463
bb434:
  %t1623 = load { i64, ptr }, ptr %l904, !tbaa !27
  store { i64, ptr } %t1623, ptr %l130, !tbaa !27
  %t1624 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t1626 = extractvalue { i64, ptr } %t1624, 0
  store i64 %t1626, ptr %l131, !tbaa !24
  store i64 0, ptr %l132, !tbaa !24
  br label %bb435
bb435:
  store %olang.scope zeroinitializer, ptr %s82
  %t1628 = load i64, ptr %l132, !tbaa !24
  %t1629 = load i64, ptr %l131, !tbaa !24
  %t1632 = icmp slt i64 %t1628, %t1629
  %t1634 = xor i1 %t1632, true
  br i1 %t1634, label %bb436, label %bb437
bb436:
  call void @__olang_scope_close(ptr %s82)
  br label %bb461
bb437:
  br label %bb438
bb438:
  %t1636 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t1636, ptr %l917, !tbaa !27
  %t1637 = load i64, ptr %l132, !tbaa !24
  %t1639 = getelementptr { i64, ptr }, ptr %l917, i32 0, i32 1
  %t1640 = load ptr, ptr %t1639, !tbaa !27
  %t1641 = getelementptr %"compiler/views:fact", ptr %t1640, i64 %t1637
  %t1642 = load %"compiler/views:fact", ptr %t1641
  store %"compiler/views:fact" %t1642, ptr %l133
  %t1644 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1645 = load i64, ptr %t1644, !tbaa !24
  %t1647 = icmp slt i64 %t1645, 0
  br i1 %t1647, label %bb439, label %bb440
bb439:
  store i1 true, ptr %l922, !tbaa !21
  br label %bb441
bb440:
  %t1649 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1650 = load i64, ptr %t1649, !tbaa !24
  %t1651 = load i64, ptr %l12, !tbaa !24
  %t1654 = icmp sge i64 %t1650, %t1651
  store i1 %t1654, ptr %l922, !tbaa !21
  br label %bb441
bb441:
  %t1656 = load i1, ptr %l922, !tbaa !21
  br i1 %t1656, label %bb442, label %bb443
bb442:
  store i1 true, ptr %l926, !tbaa !21
  br label %bb444
bb443:
  %t1657 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 8
  %t1658 = load i64, ptr %t1657, !tbaa !24
  %t1660 = icmp slt i64 %t1658, 0
  store i1 %t1660, ptr %l926, !tbaa !21
  br label %bb444
bb444:
  %t1662 = load i1, ptr %l926, !tbaa !21
  br i1 %t1662, label %bb445, label %bb446
bb445:
  store i1 true, ptr %l929, !tbaa !21
  br label %bb447
bb446:
  %t1663 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 8
  %t1664 = load i64, ptr %t1663, !tbaa !24
  %t1665 = load i64, ptr %l12, !tbaa !24
  %t1668 = icmp sge i64 %t1664, %t1665
  store i1 %t1668, ptr %l929, !tbaa !21
  br label %bb447
bb447:
  %t1670 = load i1, ptr %l929, !tbaa !21
  br i1 %t1670, label %bb448, label %bb449
bb448:
  store i1 true, ptr %l933, !tbaa !21
  br label %bb452
bb449:
  %t1671 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1672 = load i64, ptr %t1671, !tbaa !24
  %t1675 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t1672)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1675, ptr %l936
  br label %bb450
bb450:
  %t1676 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l936
  %t1677 = call ptr @__olang_scope_alloc_a(ptr %s82, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1676, ptr %t1677
  %t1679 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t1677)
  store i64 %t1679, ptr %l938
  br label %bb451
bb451:
  %t1680 = load i64, ptr %l938, !tbaa !24
  %t1681 = icmp eq i64 %t1680, 0
  store i1 %t1681, ptr %l933, !tbaa !21
  br label %bb452
bb452:
  %t1683 = load i1, ptr %l933, !tbaa !21
  br i1 %t1683, label %bb453, label %bb454
bb453:
  call void @__olang_scope_close(ptr %s82)
  br label %bb460
bb454:
  br label %bb455
bb455:
  %t1684 = load ptr, ptr %l3, !tbaa !29
  %t1686 = getelementptr %"compiler/typed:Call", ptr %t1684, i32 0, i32 1
  %t1687 = load { i64, ptr }, ptr %t1686, !tbaa !27
  store { i64, ptr } %t1687, ptr %l941, !tbaa !27
  %t1688 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 8
  %t1689 = load i64, ptr %t1688, !tbaa !24
  %t1691 = getelementptr { i64, ptr }, ptr %l941, i32 0, i32 1
  %t1692 = load ptr, ptr %t1691, !tbaa !27
  %t1693 = getelementptr ptr, ptr %t1692, i64 %t1689
  %t1694 = load ptr, ptr %t1693, !tbaa !39
  store ptr %t1694, ptr %l134, !tbaa !29
  %t1696 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1696, ptr %l944, !tbaa !29
  %t1697 = load ptr, ptr %l134, !tbaa !29
  %t1699 = call ptr @compiler_2fviews_2eargPlace(ptr %v1, ptr %t1697)
  store ptr %t1699, ptr %l946
  br label %bb456
bb456:
  %t1700 = load ptr, ptr %l134, !tbaa !29
  %t1702 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1700)
  store i32 %t1702, ptr %l948
  br label %bb457
bb457:
  %t1703 = getelementptr %"compiler/views:fact", ptr %l133, i32 0, i32 0
  %t1704 = load i64, ptr %t1703, !tbaa !24
  %t1707 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %s0, ptr %s0, ptr %l13, i64 %t1704)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1707, ptr %l951
  br label %bb458
bb458:
  %t1708 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l951
  %t1709 = call ptr @__olang_scope_alloc_a(ptr %s82, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1708, ptr %t1709
  %t1710 = load ptr, ptr %l4, !tbaa !29
  %t1711 = load ptr, ptr %l944, !tbaa !29
  %t1712 = load ptr, ptr %l946, !tbaa !29
  %t1713 = load i32, ptr %l948, !tbaa !23
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t1711, ptr %t1712, i32 %t1713, ptr %t1709, ptr %t1710)
  br label %bb459
bb459:
  call void @__olang_scope_close(ptr %s82)
  br label %bb460
bb460:
  %t1716 = load i64, ptr %l132, !tbaa !24
  %t1718 = add i64 %t1716, 1
  store i64 %t1718, ptr %l132, !tbaa !24
  br label %bb435
bb461:
  %t1720 = load i64, ptr %l129, !tbaa !24
  %t1721 = load i64, ptr %l131, !tbaa !24
  %t1724 = add i64 %t1720, %t1721
  store i64 %t1724, ptr %l129, !tbaa !24
  call void @__olang_scope_close(ptr %s81)
  br label %bb462
bb462:
  br label %bb428
bb463:
  br label %bb464
bb464:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/source:Span"
  %l20 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i8
  %l32 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr ptr, ptr %t15, i64 0
  %t17 = load ptr, ptr %t16, !tbaa !39
  %t19 = call i64 @compiler_2fviews_2eexprEnd(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l12
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t37 = icmp eq i32 %t32, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = icmp slt i64 %t39, %t43
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l20, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t49, i64 %t50)
  store i64 %t53, ptr %l27
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t55, i64 %t56)
  store i8 %t59, ptr %l30
  br label %bb11
bb11:
  %t60 = load i8, ptr %l30, !tbaa !22
  %t61 = icmp eq i8 %t60, 46
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = add i64 %t65, 1
  %t70 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %t64, i64 %t67)
  store i64 %t70, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t71 = load ptr, ptr %l32, !tbaa !29
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t71, i64 %t72)
  store %"compiler/source:Span" %t73, ptr %l37
  br label %bb15
bb15:
  %t74 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t74, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %t75, i64 %t79)
  store %"compiler/source:Span" %t82, ptr %l41
  br label %bb19
bb19:
  %t83 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  br label %bb19
bb7:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { i32 }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t42 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 1
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l26
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %l7, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c33)
  unreachable
bb19:
  %t56 = load i32, ptr %l7, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/views:Viewer", ptr %t9, i32 0, i32 10
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 11
  %t71 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l13 = alloca i1
  %l18 = alloca i8
  %l19 = alloca { i64, ptr }
  %rv = alloca i8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/views:Viewer", ptr %t4, i32 0, i32 19
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 3
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t3, i64 %t10)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l10
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb2, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l9
  br label %bb1
bb1:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d34 }, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l2, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t30 = icmp slt i64 %t24, %t27
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l19, !tbaa !27
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t34
  %t39 = load i8, ptr %t38, !tbaa !32
  store i8 %t39, ptr %l18, !tbaa !22
  br label %bb10
bb9:
  store i8 0, ptr %l18, !tbaa !22
  br label %bb10
bb10:
  %t41 = load i8, ptr %l18, !tbaa !22
  store i8 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca %"compiler/views:state"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/views:state"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i1
  %l21 = alloca %"compiler/views:state"
  %l29 = alloca { i64, ptr }
  %l33 = alloca %"compiler/views:state"
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s0, ptr %t18)
  store %"compiler/views:state" %t20, ptr %l21
  br label %bb7
bb7:
  %t21 = load %"compiler/views:state", ptr %l21
  store %"compiler/views:state" %t21, ptr %l4
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %l29, !tbaa !27
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l8, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s3, ptr %t44)
  store %"compiler/views:state" %t46, ptr %l33
  br label %bb12
bb12:
  %t47 = load %"compiler/views:state", ptr %l33
  store %"compiler/views:state" %t47, ptr %l9
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l8, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 3
  %t52 = load ptr, ptr %t51, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s3, ptr %t48, ptr %t52, ptr %l9)
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l8, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Clause", ptr %t56, i32 0, i32 4
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } zeroinitializer, 0
  %t63 = icmp eq i64 %t61, %t62
  %t64 = extractvalue { i64, ptr } %t59, 1
  %t65 = extractvalue { i64, ptr } zeroinitializer, 1
  %t66 = icmp eq ptr %t64, %t65
  %t67 = and i1 %t63, %t66
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Clause", ptr %t70, i32 0, i32 4
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l12, !tbaa !24
  br label %bb16
bb15:
  br label %bb23
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t87 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t87, ptr %l49, !tbaa !27
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 %t88
  %t93 = load ptr, ptr %t92, !tbaa !39
  %t95 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %v3, ptr %t95, ptr %t93, ptr %l9, ptr %a3)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t102 = load i64, ptr %l11, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l11, !tbaa !24
  br label %bb16
bb22:
  br label %bb23
bb23:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s3, ptr %l4, ptr %l9)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l6, !tbaa !24
  br label %bb8
bb26:
  %t112 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s0, ptr %t112, ptr %l4)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecomponents(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l44 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l100 = alloca i64
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:Viewer", ptr %t55, i32 0, i32 10
  store ptr %t57, ptr %l44, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/views:Viewer", ptr %t58, i32 0, i32 11
  %t62 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l47
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l44, !tbaa !29
  %t64 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l51
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l51, !tbaa !29
  store ptr %t72, ptr %l8, !tbaa !29
  %t73 = load ptr, ptr %l8, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 11
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp ne ptr %t76, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l8, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 11
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/views:Viewer", ptr %t84, i32 0, i32 11
  call void @compiler_2fviews_2ecalls(ptr %v0, ptr %v0, ptr %t83, ptr %t86)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/views:Viewer", ptr %t89, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t91, i64 -1)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/views:Viewer", ptr %t93, i32 0, i32 13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t95, i64 0)
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/views:Viewer", ptr %t97, i32 0, i32 14
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t99, i1 false)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb8
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/views:Viewer", ptr %t105, i32 0, i32 10
  store ptr %t107, ptr %l68, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/views:Viewer", ptr %t108, i32 0, i32 11
  %t112 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l71
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l68, !tbaa !29
  %t114 = load i64, ptr %l71, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t113, i64 %t114)
  br label %bb25
bb25:
  store i64 0, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l1, !tbaa !24
  store i64 %t115, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb26, label %bb27
bb26:
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb28:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = sub i64 %t127, %t128
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t137 = sub i64 %t135, 1
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = sdiv i64 %t137, %t138
  store i64 %t141, ptr %l79, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb30
bb30:
  %t143 = load i64, ptr %l79, !tbaa !24
  store i64 %t143, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t144 = load i64, ptr %l76, !tbaa !24
  store i64 %t144, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l12, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb34:
  br label %bb35
bb35:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = mul i64 %t154, %t155
  %t161 = add i64 %t153, %t158
  store i64 %t161, ptr %l14, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/views:Viewer", ptr %t163, i32 0, i32 12
  %t166 = load i64, ptr %l14, !tbaa !24
  %t169 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t165, i64 %t166)
  store i64 %t169, ptr %l100
  br label %bb36
bb36:
  %t170 = load i64, ptr %l100, !tbaa !24
  %t171 = icmp slt i64 %t170, 0
  br i1 %t171, label %bb37, label %bb38
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %t173, i64 %t174)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t177 = load i64, ptr %l13, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l13, !tbaa !24
  br label %bb32
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:Viewer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb4
bb3:
  %t22 = load i32, ptr %l1, !tbaa !23
  store i32 %t22, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  %t24 = load i32, ptr %l12, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  br label %bb5
bb5:
  %t25 = load i32, ptr %l7, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca %"compiler/views:state"
  %l45 = alloca %"compiler/views:state"
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i64
  %l75 = alloca i1
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca ptr
  %l81 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l151 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l193 = alloca i64
  %l196 = alloca i64
  %l214 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l216 = alloca { i64, ptr }
  %l221 = alloca i32
  %l223 = alloca i32
  %l225 = alloca i1
  %l226 = alloca i1
  %l230 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l234 = alloca i32
  %l243 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l256 = alloca i1
  %l278 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l284 = alloca i1
  %l286 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l290 = alloca i32
  %l299 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l306 = alloca %"compiler/views:view"
  %l312 = alloca ptr
  %l313 = alloca i1
  %l324 = alloca %"compiler/views:state"
  %l326 = alloca %"compiler/views:state"
  %l341 = alloca ptr
  %l342 = alloca i1
  %l355 = alloca { i64, ptr }
  %l368 = alloca ptr
  %l369 = alloca i1
  %l378 = alloca ptr
  %l379 = alloca i1
  %l394 = alloca ptr
  %l395 = alloca i1
  %l400 = alloca ptr
  %l401 = alloca i1
  %l413 = alloca { i64, ptr }
  %l423 = alloca ptr
  %l424 = alloca i1
  %l433 = alloca ptr
  %l434 = alloca i1
  %l447 = alloca { i64, ptr }
  %l450 = alloca ptr
  %l451 = alloca i1
  %l462 = alloca ptr
  %l463 = alloca i1
  %l472 = alloca ptr
  %l474 = alloca i32
  %l475 = alloca i1
  %l477 = alloca { i64, ptr }
  %l480 = alloca { i64, ptr }
  %l481 = alloca i32
  %l490 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l75, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l75, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l78
  br label %bb7
bb7:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l4
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l79
  br label %bb8
bb8:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l5
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t16 = load ptr, ptr %l80, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l80, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l81, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l81, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t30, ptr %t31, i1 false, ptr %t32, ptr %l4)
  br label %bb14
bb14:
  br label %bb248
bb15:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t38 = load ptr, ptr %l90, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t41 = load ptr, ptr %l90, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 3
  store i1 %t44, ptr %l91, !tbaa !21
  br label %bb17
bb17:
  %t45 = load i1, ptr %l91, !tbaa !21
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l7, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t52, ptr %t53, i1 true, ptr %t54, ptr %l4)
  br label %bb21
bb21:
  br label %bb248
bb22:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t60 = load ptr, ptr %l100, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb23, label %bb24
bb23:
  %t63 = load ptr, ptr %l100, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l101, !tbaa !21
  br label %bb24
bb24:
  %t67 = load i1, ptr %l101, !tbaa !21
  br i1 %t67, label %bb25, label %bb26
bb25:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l8, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t74, ptr %t75, i1 false, ptr %t76, ptr %l4)
  br label %bb28
bb28:
  br label %bb248
bb29:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t82 = load ptr, ptr %l110, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb30, label %bb31
bb30:
  %t85 = load ptr, ptr %l110, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 5
  store i1 %t88, ptr %l111, !tbaa !21
  br label %bb31
bb31:
  %t89 = load i1, ptr %l111, !tbaa !21
  br i1 %t89, label %bb32, label %bb33
bb32:
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l9, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l9, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Promote", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t96, ptr %t100, ptr %t101, ptr %l4)
  br label %bb35
bb35:
  br label %bb248
bb36:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t107 = load ptr, ptr %l121, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb37, label %bb38
bb37:
  %t110 = load ptr, ptr %l121, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 6
  store i1 %t113, ptr %l122, !tbaa !21
  br label %bb38
bb38:
  %t114 = load i1, ptr %l122, !tbaa !21
  br i1 %t114, label %bb39, label %bb40
bb39:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 0
  %t119 = load %"compiler/source:Span", ptr %t118
  store %"compiler/source:Span" %t119, ptr %l10
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 1
  %t125 = load i32, ptr %t124
  store i32 %t125, ptr %l11, !tbaa !23
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l12, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l10
  %t135 = load i32, ptr %l11, !tbaa !23
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t137 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t133, %"compiler/source:Span" %t134, i32 %t135, ptr %t136, ptr %t137, ptr %l4)
  br label %bb42
bb42:
  br label %bb248
bb43:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t145 = load ptr, ptr %l137, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb44, label %bb45
bb44:
  %t148 = load ptr, ptr %l137, !tbaa !29
  %t149 = load i64, ptr %t148
  %t151 = icmp eq i64 %t149, 7
  store i1 %t151, ptr %l138, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l138, !tbaa !21
  br i1 %t152, label %bb46, label %bb47
bb46:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t155, i32 0, i32 2
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l13, !tbaa !29
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t159 = load ptr, ptr %l13, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Make", ptr %t159, i32 0, i32 2
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t168 = load i64, ptr %l15, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t176 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t176, ptr %l151, !tbaa !27
  %t177 = load i64, ptr %l15, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr ptr, ptr %t180, i64 %t177
  %t182 = load ptr, ptr %t181, !tbaa !39
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t184, ptr %t182, ptr %t186, ptr %l4)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l15, !tbaa !24
  br label %bb49
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l13, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Make", ptr %t196, i32 0, i32 3
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t195, ptr %t199, ptr %t200, ptr %l5)
  br label %bb56
bb56:
  br label %bb248
bb57:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t206 = load ptr, ptr %l165, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb58, label %bb59
bb58:
  %t209 = load ptr, ptr %l165, !tbaa !29
  %t210 = load i64, ptr %t209
  %t212 = icmp eq i64 %t210, 8
  store i1 %t212, ptr %l166, !tbaa !21
  br label %bb59
bb59:
  %t213 = load i1, ptr %l166, !tbaa !21
  br i1 %t213, label %bb60, label %bb61
bb60:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t216, i32 0, i32 2
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l18, !tbaa !29
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l18, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Collect", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t225 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t220, ptr %t224, ptr %t225, ptr %l5)
  br label %bb63
bb63:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l18, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Collect", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t235 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t230, ptr %t234, ptr %t235)
  br label %bb64
bb64:
  br label %bb248
bb65:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t240 = load ptr, ptr %l180, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb66, label %bb67
bb66:
  %t243 = load ptr, ptr %l180, !tbaa !29
  %t244 = load i64, ptr %t243
  %t246 = icmp eq i64 %t244, 9
  store i1 %t246, ptr %l181, !tbaa !21
  br label %bb67
bb67:
  %t247 = load i1, ptr %l181, !tbaa !21
  br i1 %t247, label %bb68, label %bb69
bb68:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t250, i32 0, i32 2
  %t252 = load i32, ptr %t251
  store i32 %t252, ptr %l19
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t256, i32 0, i32 4
  %t258 = load { i64, ptr }, ptr %t257
  store { i64, ptr } %t258, ptr %l20, !tbaa !27
  br label %bb70
bb69:
  br label %bb108
bb70:
  store i64 0, ptr %l21, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  store i64 %t262, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t264 = load i64, ptr %l22, !tbaa !24
  %t265 = load i64, ptr %l21, !tbaa !24
  %t268 = icmp sgt i64 %t264, %t265
  br i1 %t268, label %bb71, label %bb72
bb71:
  %t270 = load i64, ptr %l23, !tbaa !24
  %t272 = icmp sgt i64 %t270, 0
  br i1 %t272, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb76
bb73:
  %t274 = load i64, ptr %l22, !tbaa !24
  %t275 = load i64, ptr %l21, !tbaa !24
  %t278 = sub i64 %t274, %t275
  %t279 = load i64, ptr %l23, !tbaa !24
  %t282 = add i64 %t278, %t279
  %t284 = sub i64 %t282, 1
  %t285 = load i64, ptr %l23, !tbaa !24
  %t288 = sdiv i64 %t284, %t285
  store i64 %t288, ptr %l196, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb75
bb75:
  %t290 = load i64, ptr %l196, !tbaa !24
  store i64 %t290, ptr %l193, !tbaa !24
  br label %bb76
bb76:
  %t291 = load i64, ptr %l193, !tbaa !24
  store i64 %t291, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t292 = load i64, ptr %l25, !tbaa !24
  %t293 = load i64, ptr %l24, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb107
bb79:
  br label %bb80
bb80:
  %t300 = load i64, ptr %l21, !tbaa !24
  %t301 = load i64, ptr %l25, !tbaa !24
  %t302 = load i64, ptr %l23, !tbaa !24
  %t305 = mul i64 %t301, %t302
  %t308 = add i64 %t300, %t305
  store i64 %t308, ptr %l26, !tbaa !24
  %t310 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t310, ptr %l214
  br label %bb81
bb81:
  %t311 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l214
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t311, ptr %l27
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t313, ptr %l216, !tbaa !27
  %t314 = load i64, ptr %l26, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr ptr, ptr %t317, i64 %t314
  %t319 = load ptr, ptr %t318, !tbaa !39
  %t320 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s14, ptr %t312, ptr %t319, ptr %t320, ptr %l27)
  br label %bb82
bb82:
  %t325 = load i32, ptr %l19
  store i32 %t325, ptr %l221
  store i32 20, ptr %l223
  %t328 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aPrimOp(ptr %l221, ptr %l223)
  store i1 %t328, ptr %l225
  br label %bb83
bb83:
  %t329 = load i1, ptr %l225, !tbaa !21
  br i1 %t329, label %bb84, label %bb85
bb84:
  %t330 = load i64, ptr %l26, !tbaa !24
  %t332 = icmp eq i64 %t330, 0
  store i1 %t332, ptr %l226, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb86
bb86:
  %t334 = load i1, ptr %l226, !tbaa !21
  br i1 %t334, label %bb87, label %bb88
bb87:
  store ptr %l27, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb89
bb88:
  br label %bb105
bb89:
  store %olang.scope zeroinitializer, ptr %s17
  %t336 = load ptr, ptr %l28, !tbaa !29
  %t337 = load i64, ptr %l29, !tbaa !24
  %t340 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s14, ptr %t336, i64 %t337)
  %t341 = extractvalue { i32, { i64, ptr } } %t340, 1
  %t342 = extractvalue { i32, { i64, ptr } } %t340, 0
  store i32 %t342, ptr %l234
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb91, label %ok.344
ok.344:
  store { i64, ptr } %t341, ptr %l233
  br label %bb90
bb90:
  %t345 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t345, ptr %l230, !tbaa !27
  br label %bb95
bb91:
  %t346 = load i32, ptr %l234, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  br i1 %t349, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @.c35)
  unreachable
bb94:
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb95:
  %t351 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t351, ptr %l30, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s18
  %t356 = load i64, ptr %l32, !tbaa !24
  %t357 = load i64, ptr %l31, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t364 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t364, ptr %l243, !tbaa !27
  %t365 = load i64, ptr %l32, !tbaa !24
  %t367 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr %"compiler/views:view", ptr %t368, i64 %t365
  %t370 = load %"compiler/views:view", ptr %t369
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %l4, %"compiler/views:view" %t370)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  %t375 = load i64, ptr %l32, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l32, !tbaa !24
  br label %bb96
bb102:
  %t379 = load i64, ptr %l29, !tbaa !24
  %t380 = load i64, ptr %l31, !tbaa !24
  %t383 = add i64 %t379, %t380
  store i64 %t383, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb103:
  br label %bb89
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s14)
  br label %bb106
bb106:
  %t385 = load i64, ptr %l25, !tbaa !24
  %t387 = add i64 %t385, 1
  store i64 %t387, ptr %l25, !tbaa !24
  br label %bb77
bb107:
  br label %bb248
bb108:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t390 = load ptr, ptr %l255, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb109, label %bb110
bb109:
  %t393 = load ptr, ptr %l255, !tbaa !29
  %t394 = load i64, ptr %t393
  %t396 = icmp eq i64 %t394, 10
  store i1 %t396, ptr %l256, !tbaa !21
  br label %bb110
bb110:
  %t397 = load i1, ptr %l256, !tbaa !21
  br i1 %t397, label %bb111, label %bb112
bb111:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t400, i32 0, i32 0
  %t402 = load %"compiler/source:Span", ptr %t401
  store %"compiler/source:Span" %t402, ptr %l34
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t406, i32 0, i32 2
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l35, !tbaa !29
  br label %bb113
bb112:
  br label %bb139
bb113:
  store %olang.scope zeroinitializer, ptr %s21
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l35, !tbaa !29
  %t413 = getelementptr %"compiler/typed:Slice", ptr %t411, i32 0, i32 0
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t415 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t410, ptr %t414, i1 false, ptr %t415, ptr %l4)
  br label %bb114
bb114:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load ptr, ptr %l35, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Slice", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t425 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t420, ptr %t424, ptr %t425, ptr %l5)
  br label %bb115
bb115:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load ptr, ptr %l35, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Slice", ptr %t431, i32 0, i32 2
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t435 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t430, ptr %t434, ptr %t435, ptr %l5)
  br label %bb116
bb116:
  %t440 = load ptr, ptr @__olang_prog_scope
  %t441 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t440)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t441, ptr %l278
  br label %bb117
bb117:
  %t442 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l278
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t442, ptr %l36
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l35, !tbaa !29
  %t446 = getelementptr %"compiler/typed:Slice", ptr %t444, i32 0, i32 0
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t448 = load ptr, ptr %l2, !tbaa !29
  %t453 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebufferOf(ptr %v0, ptr %v1, ptr %v2, ptr %s21, ptr %t443, ptr %t447, ptr %t448, ptr %l36)
  store i1 %t453, ptr %l284
  br label %bb118
bb118:
  %t454 = load i1, ptr %l284, !tbaa !21
  br i1 %t454, label %bb119, label %bb120
bb119:
  store ptr %l36, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb121
bb120:
  br label %bb138
bb121:
  store %olang.scope zeroinitializer, ptr %s24
  %t456 = load ptr, ptr %l37, !tbaa !29
  %t457 = load i64, ptr %l38, !tbaa !24
  %t460 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s21, ptr %t456, i64 %t457)
  %t461 = extractvalue { i32, { i64, ptr } } %t460, 1
  %t462 = extractvalue { i32, { i64, ptr } } %t460, 0
  store i32 %t462, ptr %l290
  %t463 = icmp ne i32 %t462, 0
  br i1 %t463, label %bb123, label %ok.464
ok.464:
  store { i64, ptr } %t461, ptr %l289
  br label %bb122
bb122:
  %t465 = load { i64, ptr }, ptr %l289, !tbaa !27
  store { i64, ptr } %t465, ptr %l286, !tbaa !27
  br label %bb127
bb123:
  %t466 = load i32, ptr %l290, !tbaa !23
  %t467 = ashr i32 %t466, 16
  %t469 = icmp eq i32 %t467, 1
  br i1 %t469, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @.c36)
  unreachable
bb126:
  call void @__olang_scope_close(ptr %s24)
  br label %bb137
bb127:
  %t471 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t471, ptr %l39, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t472, 0
  store i64 %t474, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s25
  %t476 = load i64, ptr %l41, !tbaa !24
  %t477 = load i64, ptr %l40, !tbaa !24
  %t480 = icmp slt i64 %t476, %t477
  %t482 = xor i1 %t480, true
  br i1 %t482, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s25)
  br label %bb135
bb130:
  br label %bb131
bb131:
  %t484 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t484, ptr %l299, !tbaa !27
  %t485 = load i64, ptr %l41, !tbaa !24
  %t487 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = getelementptr %"compiler/views:place", ptr %t488, i64 %t485
  %t490 = load %"compiler/views:place", ptr %t489
  store ptr %l4, ptr %l302, !tbaa !29
  %t493 = getelementptr %"compiler/source:Span", ptr %l34, i32 0, i32 0
  %t494 = load i32, ptr %t493, !tbaa !23
  %t496 = sext i32 %t494 to i64
  %t499 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s25, %"compiler/views:place" %t490, i64 %t496)
  store %"compiler/views:view" %t499, ptr %l306
  br label %bb132
bb132:
  %t500 = load ptr, ptr %l302, !tbaa !29
  %t501 = load %"compiler/views:view", ptr %l306
  call void @compiler_2fviews_2eviewAdd(ptr %s0, ptr %t500, %"compiler/views:view" %t501)
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s25)
  br label %bb134
bb134:
  %t502 = load i64, ptr %l41, !tbaa !24
  %t504 = add i64 %t502, 1
  store i64 %t504, ptr %l41, !tbaa !24
  br label %bb128
bb135:
  %t506 = load i64, ptr %l38, !tbaa !24
  %t507 = load i64, ptr %l40, !tbaa !24
  %t510 = add i64 %t506, %t507
  store i64 %t510, ptr %l38, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb136
bb136:
  br label %bb121
bb137:
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s21)
  br label %bb248
bb139:
  %t512 = load ptr, ptr %l1, !tbaa !29
  store ptr %t512, ptr %l312, !tbaa !29
  store i1 false, ptr %l313, !tbaa !21
  %t513 = load ptr, ptr %l312, !tbaa !29
  %t514 = icmp ne ptr %t513, null
  br i1 %t514, label %bb140, label %bb141
bb140:
  %t516 = load ptr, ptr %l312, !tbaa !29
  %t517 = load i64, ptr %t516
  %t519 = icmp eq i64 %t517, 11
  store i1 %t519, ptr %l313, !tbaa !21
  br label %bb141
bb141:
  %t520 = load i1, ptr %l313, !tbaa !21
  br i1 %t520, label %bb142, label %bb143
bb142:
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t523, i32 0, i32 2
  %t525 = load ptr, ptr %t524
  store ptr %t525, ptr %l43, !tbaa !29
  br label %bb144
bb143:
  br label %bb152
bb144:
  store %olang.scope zeroinitializer, ptr %s27
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load ptr, ptr %l43, !tbaa !29
  %t530 = getelementptr %"compiler/typed:Cond", ptr %t528, i32 0, i32 0
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t532 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t527, ptr %t531, ptr %t532, ptr %l5)
  br label %bb145
bb145:
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t539 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s27, ptr %t537)
  store %"compiler/views:state" %t539, ptr %l324
  br label %bb146
bb146:
  %t540 = load %"compiler/views:state", ptr %l324
  store %"compiler/views:state" %t540, ptr %l44
  %t541 = load ptr, ptr %l2, !tbaa !29
  %t543 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s27, ptr %t541)
  store %"compiler/views:state" %t543, ptr %l326
  br label %bb147
bb147:
  %t544 = load %"compiler/views:state", ptr %l326
  store %"compiler/views:state" %t544, ptr %l45
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %l43, !tbaa !29
  %t548 = getelementptr %"compiler/typed:Cond", ptr %t546, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %s0, ptr %t545, ptr %t549, ptr %l44, ptr %l4)
  br label %bb148
bb148:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l43, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Cond", ptr %t555, i32 0, i32 2
  %t558 = load ptr, ptr %t557, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %s0, ptr %t554, ptr %t558, ptr %l45, ptr %l4)
  br label %bb149
bb149:
  call void @compiler_2fviews_2emerge(ptr %s27, ptr %s27, ptr %l44, ptr %l45)
  br label %bb150
bb150:
  %t565 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s27, ptr %t565, ptr %l44)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s27)
  br label %bb248
bb152:
  %t568 = load ptr, ptr %l1, !tbaa !29
  store ptr %t568, ptr %l341, !tbaa !29
  store i1 false, ptr %l342, !tbaa !21
  %t569 = load ptr, ptr %l341, !tbaa !29
  %t570 = icmp ne ptr %t569, null
  br i1 %t570, label %bb153, label %bb154
bb153:
  %t572 = load ptr, ptr %l341, !tbaa !29
  %t573 = load i64, ptr %t572
  %t575 = icmp eq i64 %t573, 12
  store i1 %t575, ptr %l342, !tbaa !21
  br label %bb154
bb154:
  %t576 = load i1, ptr %l342, !tbaa !21
  br i1 %t576, label %bb155, label %bb156
bb155:
  %t577 = load ptr, ptr %l1, !tbaa !29
  %t579 = getelementptr { i64, [5 x i64] }, ptr %t577, i32 0, i32 1
  %t580 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t579, i32 0, i32 2
  %t581 = load ptr, ptr %t580
  store ptr %t581, ptr %l46, !tbaa !29
  br label %bb157
bb156:
  br label %bb166
bb157:
  %t583 = load ptr, ptr %l46, !tbaa !29
  %t585 = getelementptr %"compiler/typed:Seq", ptr %t583, i32 0, i32 0
  %t586 = load { i64, ptr }, ptr %t585, !tbaa !27
  store { i64, ptr } %t586, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t588 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t588, 0
  store i64 %t590, ptr %l49, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s30
  %t592 = load i64, ptr %l48, !tbaa !24
  %t593 = load i64, ptr %l49, !tbaa !24
  %t596 = icmp slt i64 %t592, %t593
  %t598 = xor i1 %t596, true
  br i1 %t598, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s30)
  br label %bb164
bb160:
  br label %bb161
bb161:
  %t600 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t600, ptr %l355, !tbaa !27
  %t601 = load i64, ptr %l48, !tbaa !24
  %t603 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !27
  %t605 = getelementptr ptr, ptr %t604, i64 %t601
  %t606 = load ptr, ptr %t605, !tbaa !39
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t608, ptr %t606, ptr %t610)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s30)
  br label %bb163
bb163:
  %t614 = load i64, ptr %l48, !tbaa !24
  %t616 = add i64 %t614, 1
  store i64 %t616, ptr %l48, !tbaa !24
  br label %bb158
bb164:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load ptr, ptr %l46, !tbaa !29
  %t621 = getelementptr %"compiler/typed:Seq", ptr %t619, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t623 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t618, ptr %t622, ptr %t623, ptr %l4)
  br label %bb165
bb165:
  br label %bb248
bb166:
  %t628 = load ptr, ptr %l1, !tbaa !29
  store ptr %t628, ptr %l368, !tbaa !29
  store i1 false, ptr %l369, !tbaa !21
  %t629 = load ptr, ptr %l368, !tbaa !29
  %t630 = icmp ne ptr %t629, null
  br i1 %t630, label %bb167, label %bb168
bb167:
  %t632 = load ptr, ptr %l368, !tbaa !29
  %t633 = load i64, ptr %t632
  %t635 = icmp eq i64 %t633, 13
  store i1 %t635, ptr %l369, !tbaa !21
  br label %bb168
bb168:
  %t636 = load i1, ptr %l369, !tbaa !21
  br i1 %t636, label %bb169, label %bb170
bb169:
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = getelementptr { i64, [5 x i64] }, ptr %t637, i32 0, i32 1
  %t640 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t639, i32 0, i32 2
  %t641 = load ptr, ptr %t640
  store ptr %t641, ptr %l51, !tbaa !29
  br label %bb171
bb170:
  br label %bb173
bb171:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load ptr, ptr %l51, !tbaa !29
  %t645 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t643, ptr %t644, ptr %t645, ptr %l4)
  br label %bb172
bb172:
  br label %bb248
bb173:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l378, !tbaa !29
  store i1 false, ptr %l379, !tbaa !21
  %t651 = load ptr, ptr %l378, !tbaa !29
  %t652 = icmp ne ptr %t651, null
  br i1 %t652, label %bb174, label %bb175
bb174:
  %t654 = load ptr, ptr %l378, !tbaa !29
  %t655 = load i64, ptr %t654
  %t657 = icmp eq i64 %t655, 14
  store i1 %t657, ptr %l379, !tbaa !21
  br label %bb175
bb175:
  %t658 = load i1, ptr %l379, !tbaa !21
  br i1 %t658, label %bb176, label %bb177
bb176:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr { i64, [5 x i64] }, ptr %t659, i32 0, i32 1
  %t662 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t661, i32 0, i32 2
  %t663 = load ptr, ptr %t662
  store ptr %t663, ptr %l52, !tbaa !29
  br label %bb178
bb177:
  br label %bb181
bb178:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load ptr, ptr %l52, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Try", ptr %t666, i32 0, i32 0
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t670 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t665, ptr %t669, ptr %t670, ptr %l4)
  br label %bb179
bb179:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load ptr, ptr %l52, !tbaa !29
  %t678 = getelementptr %"compiler/typed:Try", ptr %t676, i32 0, i32 1
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  %t680 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t675, { i64, ptr } %t679, ptr %t680, ptr %l4)
  br label %bb180
bb180:
  br label %bb248
bb181:
  %t685 = load ptr, ptr %l1, !tbaa !29
  store ptr %t685, ptr %l394, !tbaa !29
  store i1 false, ptr %l395, !tbaa !21
  %t686 = load ptr, ptr %l394, !tbaa !29
  %t687 = icmp ne ptr %t686, null
  br i1 %t687, label %bb182, label %bb183
bb182:
  %t689 = load ptr, ptr %l394, !tbaa !29
  %t690 = load i64, ptr %t689
  %t692 = icmp eq i64 %t690, 15
  store i1 %t692, ptr %l395, !tbaa !21
  br label %bb183
bb183:
  %t693 = load i1, ptr %l395, !tbaa !21
  br i1 %t693, label %bb184, label %bb185
bb184:
  %t694 = load ptr, ptr %l1, !tbaa !29
  %t696 = getelementptr { i64, [5 x i64] }, ptr %t694, i32 0, i32 1
  %t697 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t696, i32 0, i32 2
  %t698 = load ptr, ptr %t697
  store ptr %t698, ptr %l53, !tbaa !29
  br label %bb186
bb185:
  br label %bb212
bb186:
  %t700 = load ptr, ptr %l53, !tbaa !29
  store ptr %t700, ptr %l400, !tbaa !29
  store i1 false, ptr %l401, !tbaa !21
  %t701 = load ptr, ptr %l400, !tbaa !29
  %t702 = icmp ne ptr %t701, null
  br i1 %t702, label %bb187, label %bb188
bb187:
  %t704 = load ptr, ptr %l400, !tbaa !29
  %t705 = load i64, ptr %t704
  %t707 = icmp eq i64 %t705, 1
  store i1 %t707, ptr %l401, !tbaa !21
  br label %bb188
bb188:
  %t708 = load i1, ptr %l401, !tbaa !21
  br i1 %t708, label %bb189, label %bb190
bb189:
  %t709 = load ptr, ptr %l53, !tbaa !29
  %t711 = getelementptr { i64, [4 x i64] }, ptr %t709, i32 0, i32 1
  %t712 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t711, i32 0, i32 1
  %t713 = load { i64, ptr }, ptr %t712
  store { i64, ptr } %t713, ptr %l54, !tbaa !27
  br label %bb191
bb190:
  br label %bb199
bb191:
  %t715 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t715, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t717 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t719 = extractvalue { i64, ptr } %t717, 0
  store i64 %t719, ptr %l57, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s37
  %t721 = load i64, ptr %l56, !tbaa !24
  %t722 = load i64, ptr %l57, !tbaa !24
  %t725 = icmp slt i64 %t721, %t722
  %t727 = xor i1 %t725, true
  br i1 %t727, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s37)
  br label %bb198
bb194:
  br label %bb195
bb195:
  %t729 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t729, ptr %l413, !tbaa !27
  %t730 = load i64, ptr %l56, !tbaa !24
  %t732 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t733 = load ptr, ptr %t732, !tbaa !27
  %t734 = getelementptr ptr, ptr %t733, i64 %t730
  %t735 = load ptr, ptr %t734, !tbaa !39
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t740 = getelementptr %"compiler/typed:Capture", ptr %t735, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !29
  %t742 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t737, ptr %t741, ptr %t742, ptr %l4)
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s37)
  br label %bb197
bb197:
  %t747 = load i64, ptr %l56, !tbaa !24
  %t749 = add i64 %t747, 1
  store i64 %t749, ptr %l56, !tbaa !24
  br label %bb192
bb198:
  br label %bb211
bb199:
  %t751 = load ptr, ptr %l53, !tbaa !29
  store ptr %t751, ptr %l423, !tbaa !29
  store i1 false, ptr %l424, !tbaa !21
  %t752 = load ptr, ptr %l423, !tbaa !29
  %t753 = icmp ne ptr %t752, null
  br i1 %t753, label %bb200, label %bb201
bb200:
  %t755 = load ptr, ptr %l423, !tbaa !29
  %t756 = load i64, ptr %t755
  %t758 = icmp eq i64 %t756, 2
  store i1 %t758, ptr %l424, !tbaa !21
  br label %bb201
bb201:
  %t759 = load i1, ptr %l424, !tbaa !21
  br i1 %t759, label %bb202, label %bb203
bb202:
  %t760 = load ptr, ptr %l53, !tbaa !29
  %t762 = getelementptr { i64, [4 x i64] }, ptr %t760, i32 0, i32 1
  %t763 = getelementptr { i32, ptr, i32 }, ptr %t762, i32 0, i32 1
  %t764 = load ptr, ptr %t763
  store ptr %t764, ptr %l59, !tbaa !29
  br label %bb204
bb203:
  br label %bb206
bb204:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load ptr, ptr %l59, !tbaa !29
  %t768 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t766, ptr %t767, ptr %t768, ptr %l4)
  br label %bb205
bb205:
  br label %bb211
bb206:
  br i1 true, label %bb207, label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb210
bb209:
  br label %bb211
bb210:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
bb211:
  br label %bb248
bb212:
  %t773 = load ptr, ptr %l1, !tbaa !29
  store ptr %t773, ptr %l433, !tbaa !29
  store i1 false, ptr %l434, !tbaa !21
  %t774 = load ptr, ptr %l433, !tbaa !29
  %t775 = icmp ne ptr %t774, null
  br i1 %t775, label %bb213, label %bb214
bb213:
  %t777 = load ptr, ptr %l433, !tbaa !29
  %t778 = load i64, ptr %t777
  %t780 = icmp eq i64 %t778, 16
  store i1 %t780, ptr %l434, !tbaa !21
  br label %bb214
bb214:
  %t781 = load i1, ptr %l434, !tbaa !21
  br i1 %t781, label %bb215, label %bb216
bb215:
  %t782 = load ptr, ptr %l1, !tbaa !29
  %t784 = getelementptr { i64, [5 x i64] }, ptr %t782, i32 0, i32 1
  %t785 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t784, i32 0, i32 2
  %t786 = load ptr, ptr %t785
  store ptr %t786, ptr %l60, !tbaa !29
  br label %bb217
bb216:
  br label %bb236
bb217:
  %t788 = load ptr, ptr %l60, !tbaa !29
  %t790 = getelementptr %"compiler/typed:Text", ptr %t788, i32 0, i32 0
  %t791 = load { i64, ptr }, ptr %t790, !tbaa !27
  store { i64, ptr } %t791, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t793 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t795 = extractvalue { i64, ptr } %t793, 0
  store i64 %t795, ptr %l63, !tbaa !24
  br label %bb218
bb218:
  store %olang.scope zeroinitializer, ptr %s43
  %t797 = load i64, ptr %l62, !tbaa !24
  %t798 = load i64, ptr %l63, !tbaa !24
  %t801 = icmp slt i64 %t797, %t798
  %t803 = xor i1 %t801, true
  br i1 %t803, label %bb219, label %bb220
bb219:
  call void @__olang_scope_close(ptr %s43)
  br label %bb235
bb220:
  br label %bb221
bb221:
  %t805 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t805, ptr %l447, !tbaa !27
  %t806 = load i64, ptr %l62, !tbaa !24
  %t808 = getelementptr { i64, ptr }, ptr %l447, i32 0, i32 1
  %t809 = load ptr, ptr %t808, !tbaa !27
  %t810 = getelementptr ptr, ptr %t809, i64 %t806
  %t811 = load ptr, ptr %t810, !tbaa !39
  store ptr %t811, ptr %l64, !tbaa !29
  %t813 = load ptr, ptr %l64, !tbaa !29
  store ptr %t813, ptr %l450, !tbaa !29
  store i1 false, ptr %l451, !tbaa !21
  %t814 = load ptr, ptr %l450, !tbaa !29
  %t815 = icmp ne ptr %t814, null
  br i1 %t815, label %bb222, label %bb223
bb222:
  %t817 = load ptr, ptr %l450, !tbaa !29
  %t818 = load i64, ptr %t817
  %t820 = icmp eq i64 %t818, 1
  store i1 %t820, ptr %l451, !tbaa !21
  br label %bb223
bb223:
  %t821 = load i1, ptr %l451, !tbaa !21
  br i1 %t821, label %bb224, label %bb225
bb224:
  %t822 = load ptr, ptr %l64, !tbaa !29
  %t824 = getelementptr { i64, [2 x i64] }, ptr %t822, i32 0, i32 1
  %t825 = getelementptr { ptr }, ptr %t824, i32 0, i32 0
  %t826 = load ptr, ptr %t825
  store ptr %t826, ptr %l65, !tbaa !29
  br label %bb226
bb225:
  br label %bb228
bb226:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t829 = load ptr, ptr %l65, !tbaa !29
  %t830 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t828, ptr %t829, ptr %t830, ptr %l5)
  br label %bb227
bb227:
  br label %bb233
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb233
bb232:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb233:
  call void @__olang_scope_close(ptr %s43)
  br label %bb234
bb234:
  %t835 = load i64, ptr %l62, !tbaa !24
  %t837 = add i64 %t835, 1
  store i64 %t837, ptr %l62, !tbaa !24
  br label %bb218
bb235:
  br label %bb248
bb236:
  %t839 = load ptr, ptr %l1, !tbaa !29
  store ptr %t839, ptr %l462, !tbaa !29
  store i1 false, ptr %l463, !tbaa !21
  %t840 = load ptr, ptr %l462, !tbaa !29
  %t841 = icmp ne ptr %t840, null
  br i1 %t841, label %bb237, label %bb238
bb237:
  %t843 = load ptr, ptr %l462, !tbaa !29
  %t844 = load i64, ptr %t843
  %t846 = icmp eq i64 %t844, 17
  store i1 %t846, ptr %l463, !tbaa !21
  br label %bb238
bb238:
  %t847 = load i1, ptr %l463, !tbaa !21
  br i1 %t847, label %bb239, label %bb240
bb239:
  %t848 = load ptr, ptr %l1, !tbaa !29
  %t850 = getelementptr { i64, [5 x i64] }, ptr %t848, i32 0, i32 1
  %t851 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t850, i32 0, i32 2
  %t852 = load ptr, ptr %t851
  store ptr %t852, ptr %l66, !tbaa !29
  br label %bb241
bb240:
  br label %bb243
bb241:
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load ptr, ptr %l66, !tbaa !29
  %t856 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t854, ptr %t855, ptr %t856, ptr %l4)
  br label %bb242
bb242:
  br label %bb248
bb243:
  br i1 true, label %bb244, label %bb245
bb244:
  br label %bb246
bb245:
  br label %bb247
bb246:
  br label %bb248
bb247:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb248:
  %t861 = load ptr, ptr %l0, !tbaa !29
  store ptr %t861, ptr %l472, !tbaa !29
  %t862 = load ptr, ptr %l1, !tbaa !29
  %t864 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t862)
  store i32 %t864, ptr %l474
  br label %bb249
bb249:
  %t865 = load ptr, ptr %l472, !tbaa !29
  %t866 = load i32, ptr %l474, !tbaa !23
  %t867 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t865, i32 %t866)
  store i1 %t867, ptr %l475
  br label %bb250
bb250:
  %t868 = load i1, ptr %l475, !tbaa !21
  br i1 %t868, label %bb251, label %bb252
bb251:
  store ptr %l4, ptr %l67, !tbaa !29
  store i64 0, ptr %l68, !tbaa !24
  br label %bb253
bb252:
  br label %bb269
bb253:
  store %olang.scope zeroinitializer, ptr %s51
  %t870 = load ptr, ptr %l67, !tbaa !29
  %t871 = load i64, ptr %l68, !tbaa !24
  %t874 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t870, i64 %t871)
  %t875 = extractvalue { i32, { i64, ptr } } %t874, 1
  %t876 = extractvalue { i32, { i64, ptr } } %t874, 0
  store i32 %t876, ptr %l481
  %t877 = icmp ne i32 %t876, 0
  br i1 %t877, label %bb255, label %ok.878
ok.878:
  store { i64, ptr } %t875, ptr %l480
  br label %bb254
bb254:
  %t879 = load { i64, ptr }, ptr %l480, !tbaa !27
  store { i64, ptr } %t879, ptr %l477, !tbaa !27
  br label %bb259
bb255:
  %t880 = load i32, ptr %l481, !tbaa !23
  %t881 = ashr i32 %t880, 16
  %t883 = icmp eq i32 %t881, 1
  br i1 %t883, label %bb256, label %bb257
bb256:
  br label %bb258
bb257:
  call void @__olang_check_failed(ptr @.c40)
  unreachable
bb258:
  call void @__olang_scope_close(ptr %s51)
  br label %bb268
bb259:
  %t885 = load { i64, ptr }, ptr %l477, !tbaa !27
  store { i64, ptr } %t885, ptr %l69, !tbaa !27
  %t886 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t888 = extractvalue { i64, ptr } %t886, 0
  store i64 %t888, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb260
bb260:
  store %olang.scope zeroinitializer, ptr %s52
  %t890 = load i64, ptr %l71, !tbaa !24
  %t891 = load i64, ptr %l70, !tbaa !24
  %t894 = icmp slt i64 %t890, %t891
  %t896 = xor i1 %t894, true
  br i1 %t896, label %bb261, label %bb262
bb261:
  call void @__olang_scope_close(ptr %s52)
  br label %bb266
bb262:
  br label %bb263
bb263:
  %t898 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t898, ptr %l490, !tbaa !27
  %t899 = load i64, ptr %l71, !tbaa !24
  %t901 = getelementptr { i64, ptr }, ptr %l490, i32 0, i32 1
  %t902 = load ptr, ptr %t901, !tbaa !27
  %t903 = getelementptr %"compiler/views:view", ptr %t902, i64 %t899
  %t904 = load %"compiler/views:view", ptr %t903
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %a3, %"compiler/views:view" %t904)
  br label %bb264
bb264:
  call void @__olang_scope_close(ptr %s52)
  br label %bb265
bb265:
  %t910 = load i64, ptr %l71, !tbaa !24
  %t912 = add i64 %t910, 1
  store i64 %t912, ptr %l71, !tbaa !24
  br label %bb260
bb266:
  %t914 = load i64, ptr %l68, !tbaa !24
  %t915 = load i64, ptr %l70, !tbaa !24
  %t918 = add i64 %t914, %t915
  store i64 %t918, ptr %l68, !tbaa !24
  call void @__olang_scope_close(ptr %s51)
  br label %bb267
bb267:
  br label %bb253
bb268:
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l4, !tbaa !29
  br label %bb12
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t36, ptr %t37, ptr %t38)
  br label %bb13
bb13:
  br label %bb34
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 11
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Cond", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t58, ptr %t62, ptr %t63, ptr %t64)
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Cond", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t69, ptr %t73, ptr %t74, ptr %t75)
  br label %bb21
bb21:
  br label %bb34
bb22:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t81 = load ptr, ptr %l41, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 17
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t88 = load i1, ptr %l42, !tbaa !21
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t98 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t96, ptr %t97, ptr %t98)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @.c41)
  unreachable
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i32 %a4, %"compiler/views:place" %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/views:place"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/views:fact"
  %l27 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l89 = alloca { i64, ptr }
  %l95 = alloca i1
  %l99 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i1
  %l122 = alloca i64
  %l126 = alloca { i64, ptr }
  %l129 = alloca i64
  %l134 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l147 = alloca %"compiler/views:fact"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/views:place" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %t5)
  store { i64, ptr } %t8, ptr %l27
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t13 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l9, !tbaa !21
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb7
bb4:
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = load i64, ptr %l11, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l13, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l13, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l38, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l38, !tbaa !24
  store i64 %t46, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l35, !tbaa !24
  store i64 %t47, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l15, !tbaa !24
  %t49 = load i64, ptr %l14, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t56 = load i64, ptr %l11, !tbaa !24
  %t57 = load i64, ptr %l15, !tbaa !24
  %t58 = load i64, ptr %l13, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l16, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t66, ptr %l56, !tbaa !27
  %t67 = load i64, ptr %l16, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 46
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp sgt i64 %t80, 8
  br i1 %t82, label %bb14, label %bb15
bb13:
  br label %bb24
bb14:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l64, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t85, ptr %l65, !tbaa !27
  %t86 = load i64, ptr %l16, !tbaa !24
  store i64 %t86, ptr %l66, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l67, !tbaa !24
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb16, label %bb17
bb15:
  br label %bb23
bb16:
  %t91 = load i64, ptr %l66, !tbaa !24
  %t92 = icmp sle i64 0, %t91
  br i1 %t92, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb18:
  %t94 = load i64, ptr %l66, !tbaa !24
  %t95 = load i64, ptr %l67, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb20:
  %t98 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l66, !tbaa !24
  %t101 = getelementptr i8, ptr %t99, i64 0
  %t102 = sub i64 %t100, 0
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %v0, ptr %t105, { i64, ptr } %t104)
  store i64 %t107, ptr %l72
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb22:
  %t108 = load i64, ptr %l72, !tbaa !24
  store i64 %t108, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t109 = load i64, ptr %l15, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l15, !tbaa !24
  br label %bb8
bb26:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = load ptr, ptr %l17, !tbaa !29
  %t116 = load i64, ptr %l18, !tbaa !24
  %t119 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t115, i64 %t116)
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l80
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb29, label %ok.123
ok.123:
  store { i64, ptr } %t120, ptr %l79
  br label %bb28
bb28:
  %t124 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  br label %bb33
bb29:
  %t125 = load i32, ptr %l80, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  br i1 %t128, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @.c43)
  unreachable
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb33:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l19, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t135 = load i64, ptr %l21, !tbaa !24
  %t136 = load i64, ptr %l20, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb36:
  br label %bb37
bb37:
  %t143 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t143, ptr %l89, !tbaa !27
  %t144 = load i64, ptr %l21, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr %"compiler/views:fact", ptr %t147, i64 %t144
  %t149 = load %"compiler/views:fact", ptr %t148
  store %"compiler/views:fact" %t149, ptr %l22
  %t151 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = icmp ne i64 %t152, %t153
  br i1 %t156, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb40
bb39:
  %t158 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 1
  %t159 = load i64, ptr %t158, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t163 = icmp ne i64 %t159, %t160
  store i1 %t163, ptr %l95, !tbaa !21
  br label %bb40
bb40:
  %t165 = load i1, ptr %l95, !tbaa !21
  br i1 %t165, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb43
bb42:
  %t166 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 2
  %t167 = load i32, ptr %t166, !tbaa !23
  %t168 = load i32, ptr %l4, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  store i1 %t171, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l99, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb63
bb45:
  br label %bb46
bb46:
  %t174 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 3
  %t175 = load i64, ptr %t174, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t179 = icmp eq i64 %t175, %t176
  br i1 %t179, label %bb47, label %bb48
bb47:
  %t181 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 5
  %t182 = load i1, ptr %t181, !tbaa !21
  br i1 %t182, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb52
bb49:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb51
bb50:
  %t184 = load i1, ptr %l9, !tbaa !21
  %t186 = xor i1 %t184, true
  store i1 %t186, ptr %l108, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l108, !tbaa !21
  store i1 %t188, ptr %l106, !tbaa !21
  br label %bb52
bb52:
  %t189 = load i1, ptr %l106, !tbaa !21
  br i1 %t189, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  br label %bb55
bb55:
  %t190 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 5
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb56:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/views:fact", ptr %l22, i32 0, i32 3
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load i64, ptr %l8, !tbaa !24
  %t200 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t193, i64 %t195, i64 %t196)
  store i1 %t200, ptr %l116
  br label %bb58
bb57:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb59
bb58:
  %t201 = load i1, ptr %l116, !tbaa !21
  store i1 %t201, ptr %l112, !tbaa !21
  br label %bb59
bb59:
  %t202 = load i1, ptr %l112, !tbaa !21
  br i1 %t202, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb63
bb63:
  %t203 = load i64, ptr %l21, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l21, !tbaa !24
  br label %bb34
bb64:
  %t207 = load i64, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t207, %t208
  store i64 %t211, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  br label %bb27
bb66:
  %t213 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 2
  %t214 = load i64, ptr %t213, !tbaa !24
  store i64 %t214, ptr %l122, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/views:Viewer", ptr %t215, i32 0, i32 3
  %t218 = load i64, ptr %l8, !tbaa !24
  %t221 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t217, i64 %t218)
  store { i64, ptr } %t221, ptr %l126
  br label %bb67
bb67:
  %t222 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = load i64, ptr %l122, !tbaa !24
  %t226 = icmp sle i64 %t224, %t223
  br i1 %t226, label %bb68, label %bb69
bb68:
  %t228 = getelementptr %"compiler/views:place", ptr %l5, i32 0, i32 2
  %t229 = load i64, ptr %t228, !tbaa !24
  store i64 %t229, ptr %l129, !tbaa !24
  br label %bb71
bb69:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/views:Viewer", ptr %t231, i32 0, i32 3
  %t234 = load i64, ptr %l8, !tbaa !24
  %t237 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t233, i64 %t234)
  store { i64, ptr } %t237, ptr %l134
  br label %bb70
bb70:
  %t238 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  store i64 %t239, ptr %l129, !tbaa !24
  br label %bb71
bb71:
  %t241 = load i64, ptr %l129, !tbaa !24
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l136, !tbaa !29
  %t243 = load i64, ptr %l2, !tbaa !24
  %t244 = load i64, ptr %l3, !tbaa !24
  %t245 = load i32, ptr %l4, !tbaa !23
  %t246 = load i64, ptr %l8, !tbaa !24
  %t248 = load i1, ptr %l9, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/views:Viewer", ptr %t249, i32 0, i32 19
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Body", ptr %t252, i32 0, i32 3
  %t255 = load i64, ptr %t254, !tbaa !24
  %t265 = call %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %s0, i64 %t243, i64 %t244, i32 %t245, i64 %t246, i64 %t241, i1 %t248, i64 %t255, %"compiler/source:Span" %a6)
  store %"compiler/views:fact" %t265, ptr %l147
  br label %bb72
bb72:
  %t266 = load ptr, ptr %l136, !tbaa !29
  %t267 = load %"compiler/views:fact", ptr %l147
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v1, ptr %t266, %"compiler/views:fact" %t267)
  br label %bb73
bb73:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/views:Viewer", ptr %t268, i32 0, i32 24
  store i1 true, ptr %t270, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i1
  %l34 = alloca i32
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l102 = alloca { i64, ptr }
  %l108 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca i64
  %l121 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l22
  br label %bb1
bb1:
  store i32 18, ptr %l24
  %t13 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l22, ptr %l24)
  store i1 %t13, ptr %l26
  br label %bb2
bb2:
  %t14 = load i1, ptr %l26, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t17)
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = call i64 @__olang_fmt_i64(ptr %t20, i64 %t17)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/views:Viewer", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l34
  br label %bb6
bb6:
  %t35 = load i32, ptr %l34, !tbaa !23
  store i32 %t35, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/views:Viewer", ptr %t36, i32 0, i32 8
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hbdff57143197d3e3ce33a3087c05f7a0(ptr %v0, ptr %t38, i32 %t39)
  %t43 = extractvalue { i32, i64 } %t42, 1
  %t44 = extractvalue { i32, i64 } %t42, 0
  store i32 %t44, ptr %l40
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb8, label %ok.46
ok.46:
  store i64 %t43, ptr %l39
  br label %bb7
bb7:
  %t47 = load i64, ptr %l39, !tbaa !24
  store i64 %t47, ptr %l35, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:Viewer", ptr %t53, i32 0, i32 9
  store ptr %t55, ptr %l44, !tbaa !29
  %t56 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l45
  br label %bb13
bb12:
  br label %bb58
bb13:
  %t57 = load ptr, ptr %l44, !tbaa !29
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H10b97bb675358eb10150edb21083f11d(ptr %v0, ptr %v0, ptr %t57, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58)
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/views:Viewer", ptr %t59, i32 0, i32 9
  %t63 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_He143de49e62ad88ca82ea9d42e5a34cc(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l48
  br label %bb15
bb15:
  %t64 = load i64, ptr %l48, !tbaa !24
  %t65 = sub i64 %t64, 1
  store i64 %t65, ptr %l4, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/views:Viewer", ptr %t67, i32 0, i32 8
  %t70 = load i32, ptr %l3, !tbaa !23
  %t71 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hd7428d759783ef3a1a99ea96b3969ebe(ptr %v0, ptr %t69, i32 %t70, i64 %t71)
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/views:Viewer", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l3, !tbaa !23
  %t82 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t78, i32 %t79)
  store ptr %t82, ptr %l57
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l57, !tbaa !29
  store ptr %t83, ptr %l5, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = icmp ne ptr %t84, null
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/ast:TypeDecl", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp ne ptr %t91, null
  store i1 %t93, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l60, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t98 = getelementptr %"compiler/ast:TypeDecl", ptr %t96, i32 0, i32 3
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l6, !tbaa !29
  %t101 = load ptr, ptr %l6, !tbaa !29
  store ptr %t101, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t102 = load ptr, ptr %l66, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb23, label %bb24
bb22:
  br label %bb57
bb23:
  %t105 = load ptr, ptr %l66, !tbaa !29
  %t106 = load i64, ptr %t105
  %t108 = icmp eq i64 %t106, 0
  store i1 %t108, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l67, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { ptr }, ptr %t112, i32 0, i32 0
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb55
bb27:
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = getelementptr %"compiler/ast:StructBody", ptr %t116, i32 0, i32 2
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } zeroinitializer, 0
  %t123 = icmp eq i64 %t121, %t122
  %t124 = extractvalue { i64, ptr } %t119, 1
  %t125 = extractvalue { i64, ptr } zeroinitializer, 1
  %t126 = icmp eq ptr %t124, %t125
  %t127 = and i1 %t123, %t126
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t132 = getelementptr %"compiler/ast:StructBody", ptr %t130, i32 0, i32 2
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l10, !tbaa !24
  br label %bb30
bb29:
  br label %bb54
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb32:
  br label %bb33
bb33:
  %t147 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t147, ptr %l83, !tbaa !27
  %t148 = load i64, ptr %l9, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr ptr, ptr %t151, i64 %t148
  %t153 = load ptr, ptr %t152, !tbaa !39
  store ptr %t153, ptr %l11, !tbaa !29
  %t155 = load ptr, ptr %l11, !tbaa !29
  store ptr %t155, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb34, label %bb35
bb34:
  %t159 = load ptr, ptr %l86, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 1
  store i1 %t162, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t163 = load i1, ptr %l87, !tbaa !21
  br i1 %t163, label %bb36, label %bb37
bb36:
  %t164 = load ptr, ptr %l11, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 1
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l12, !tbaa !29
  br label %bb38
bb37:
  br label %bb50
bb38:
  %t170 = load ptr, ptr %l12, !tbaa !29
  %t172 = getelementptr %"compiler/ast:VarDecl", ptr %t170, i32 0, i32 5
  %t173 = load i1, ptr %t172, !tbaa !21
  br i1 %t173, label %bb39, label %bb40
bb39:
  %t175 = load ptr, ptr %l12, !tbaa !29
  %t177 = getelementptr %"compiler/ast:VarDecl", ptr %t175, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l15, !tbaa !24
  br label %bb41
bb40:
  br label %bb49
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t184 = load i64, ptr %l14, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t192 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t192, ptr %l102, !tbaa !27
  %t193 = load i64, ptr %l14, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  store i32 %t198, ptr %l16, !tbaa !23
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/views:Viewer", ptr %t200, i32 0, i32 9
  %t203 = load i64, ptr %l4, !tbaa !24
  %t206 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H63170323aaa56032a7f198353006b630(ptr %v0, ptr %v0, ptr %t202, i64 %t203)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l108
  br label %bb45
bb45:
  %t207 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  %t208 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %t208
  %t209 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %t208, i32 %t209)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s12)
  br label %bb47
bb47:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l14, !tbaa !24
  br label %bb41
bb48:
  br label %bb49
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  %t216 = load i64, ptr %l9, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l9, !tbaa !24
  br label %bb30
bb53:
  br label %bb54
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/views:Viewer", ptr %t220, i32 0, i32 9
  %t223 = load i64, ptr %l4, !tbaa !24
  %t226 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H63170323aaa56032a7f198353006b630(ptr %v0, ptr %v0, ptr %t222, i64 %t223)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %l118
  br label %bb59
bb59:
  %t227 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t227, ptr %l17
  %t228 = load i64, ptr %l2, !tbaa !24
  store i64 %t228, ptr %l119, !tbaa !24
  %t230 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %l17)
  store i64 %t230, ptr %l121
  br label %bb60
bb60:
  %t231 = load i64, ptr %l119, !tbaa !24
  %t232 = load i64, ptr %l121, !tbaa !24
  %t233 = icmp slt i64 %t231, %t232
  br i1 %t233, label %bb61, label %bb62
bb61:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  %t236 = load i64, ptr %l2, !tbaa !24
  %t239 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %l17, i64 %t236)
  store i32 %t239, ptr %l127
  br label %bb63
bb62:
  %t240 = load i64, ptr %l2, !tbaa !24
  %t242 = call i64 @__olang_fmt_i64(ptr null, i64 %t240)
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  %t244 = call i64 @__olang_fmt_i64(ptr %t243, i64 %t240)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  store { i64, ptr } %t246, ptr %l123, !tbaa !27
  br label %bb65
bb63:
  %t248 = load ptr, ptr %l124, !tbaa !29
  %t249 = load i32, ptr %l127, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l128
  br label %bb64
bb64:
  %t251 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t252, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l123, !tbaa !27
  br label %bb65
bb65:
  %t258 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t258, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2egrow(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/views:holding"
  %l18 = alloca %"compiler/views:view"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/views:tasked"
  %l25 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l41 = alloca ptr
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l93 = alloca %"compiler/views:holding"
  %l95 = alloca i1
  %l99 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i64
  %l111 = alloca %"compiler/views:holding"
  %l117 = alloca i1
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l135 = alloca { i64, ptr }
  %l141 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l156 = alloca { i64, [3 x i64] }
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l168 = alloca { i64, [3 x i64] }
  %l170 = alloca %"compiler/msgs:Msg"
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/views:Viewer", ptr %t6, i32 0, i32 21
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t14 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t14, ptr %l7
  %t16 = load { i64, [2 x i64] }, ptr %l7
  %t18 = extractvalue { i64, [2 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 2
  br i1 %t19, label %bb6, label %bb7
bb5:
  br label %bb23
bb6:
  %t21 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t22 = getelementptr { i64 }, ptr %t21, i32 0, i32 0
  %t23 = load i64, ptr %t22
  store i64 %t23, ptr %l8, !tbaa !24
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l36, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/views:Viewer", ptr %t26, i32 0, i32 2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/views:Viewer", ptr %t29, i32 0, i32 20
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t28, i64 %t32)
  store ptr %t35, ptr %l41
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l41, !tbaa !29
  %t38 = getelementptr %"compiler/views:summary", ptr %t36, i32 0, i32 0
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load %"compiler/views:place", ptr %l1
  %t41 = load %"compiler/source:Span", ptr %l2
  %t42 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t42, ptr %t38, i64 %t39, i64 -1, i32 0, %"compiler/views:place" %t40, %"compiler/source:Span" %t41)
  br label %bb10
bb10:
  br label %bb22
bb11:
  %t47 = load { i64, [2 x i64] }, ptr %l7
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 3
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t53 = getelementptr { i64, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i64, ptr %t53
  store i64 %t54, ptr %l9, !tbaa !24
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t57 = getelementptr { i64, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l10, !tbaa !23
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l51, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/views:Viewer", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 20
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t63, i64 %t67)
  store ptr %t70, ptr %l56
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l56, !tbaa !29
  %t73 = getelementptr %"compiler/views:summary", ptr %t71, i32 0, i32 0
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i32, ptr %l10, !tbaa !23
  %t76 = load %"compiler/views:place", ptr %l1
  %t77 = load %"compiler/source:Span", ptr %l2
  %t78 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t78, ptr %t73, i64 -1, i64 %t74, i32 %t75, %"compiler/views:place" %t76, %"compiler/source:Span" %t77)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l11, !tbaa !24
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t86 = getelementptr %"compiler/views:state", ptr %t84, i32 0, i32 1
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t86)
  store i64 %t88, ptr %l65
  br label %bb24
bb24:
  %t89 = load i64, ptr %l65, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb25, label %bb26
bb25:
  %t96 = load i64, ptr %l13, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb30
bb27:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l13, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l13, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l72, !tbaa !24
  store i64 %t116, ptr %l69, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l69, !tbaa !24
  store i64 %t117, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l14, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t127 = load i64, ptr %l15, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l16, !tbaa !24
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = getelementptr %"compiler/views:state", ptr %t136, i32 0, i32 1
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v1, ptr %t138, i64 %t139)
  store %"compiler/views:holding" %t142, ptr %l93
  br label %bb35
bb35:
  %t143 = load %"compiler/views:holding", ptr %l93
  store %"compiler/views:holding" %t143, ptr %l17
  %t144 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t145 = getelementptr %"compiler/views:view", ptr %t144, i32 0, i32 2
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb39
bb37:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t150 = getelementptr %"compiler/views:view", ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/views:place", ptr %t150
  %t152 = load %"compiler/views:place", ptr %l1
  %t156 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t148, %"compiler/views:place" %t151, %"compiler/views:place" %t152)
  store i1 %t156, ptr %l99
  br label %bb38
bb38:
  %t157 = load i1, ptr %l99, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l95, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t161 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 1
  %t162 = load %"compiler/views:view", ptr %t161
  store %"compiler/views:view" %t162, ptr %l18
  %t164 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 2
  store i1 true, ptr %t164, !tbaa !21
  %t165 = load %"compiler/source:Span", ptr %l2
  %t167 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 3
  store %"compiler/source:Span" %t165, ptr %t167
  %t170 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 4
  store i64 %a3, ptr %t170, !tbaa !24
  %t173 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 5
  store i64 %a4, ptr %t173, !tbaa !24
  %t176 = getelementptr %"compiler/views:view", ptr %l18, i32 0, i32 6
  store %"compiler/source:Span" %a5, ptr %t176
  %t177 = load ptr, ptr %l6, !tbaa !29
  %t179 = getelementptr %"compiler/views:state", ptr %t177, i32 0, i32 1
  store ptr %t179, ptr %l107, !tbaa !29
  %t180 = load i64, ptr %l16, !tbaa !24
  store i64 %t180, ptr %l108, !tbaa !24
  %t181 = getelementptr %"compiler/views:holding", ptr %l17, i32 0, i32 0
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = load %"compiler/views:view", ptr %l18
  %t186 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s7, i64 %t182, %"compiler/views:view" %t183)
  store %"compiler/views:holding" %t186, ptr %l111
  br label %bb43
bb43:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load i64, ptr %l108, !tbaa !24
  %t189 = load %"compiler/views:holding", ptr %l111
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v1, ptr %t187, i64 %t188, %"compiler/views:holding" %t189)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l15, !tbaa !24
  br label %bb31
bb46:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/views:Viewer", ptr %t194, i32 0, i32 21
  %t197 = load i1, ptr %t196, !tbaa !21
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb49
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/views:Viewer", ptr %t201, i32 0, i32 23
  %t204 = load i1, ptr %t203, !tbaa !21
  store i1 %t204, ptr %l117, !tbaa !21
  br label %bb49
bb49:
  %t206 = load i1, ptr %l117, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  br label %ret
bb51:
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l6, !tbaa !29
  %t209 = getelementptr %"compiler/views:state", ptr %t207, i32 0, i32 4
  store ptr %t209, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t211 = load ptr, ptr %l19, !tbaa !29
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v1, ptr %t211, i64 %t212)
  %t216 = extractvalue { i32, { i64, ptr } } %t215, 1
  %t217 = extractvalue { i32, { i64, ptr } } %t215, 0
  store i32 %t217, ptr %l126
  %t218 = icmp ne i32 %t217, 0
  br i1 %t218, label %bb55, label %ok.219
ok.219:
  store { i64, ptr } %t216, ptr %l125
  br label %bb54
bb54:
  %t220 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t220, ptr %l122, !tbaa !27
  br label %bb59
bb55:
  %t221 = load i32, ptr %l126, !tbaa !23
  %t222 = ashr i32 %t221, 16
  %t224 = icmp eq i32 %t222, 1
  br i1 %t224, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb59:
  %t226 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t226, ptr %l21, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s13
  %t231 = load i64, ptr %l23, !tbaa !24
  %t232 = load i64, ptr %l22, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb62:
  br label %bb63
bb63:
  %t239 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t239, ptr %l135, !tbaa !27
  %t240 = load i64, ptr %l23, !tbaa !24
  %t242 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr %"compiler/views:tasked", ptr %t243, i64 %t240
  %t245 = load %"compiler/views:tasked", ptr %t244
  store %"compiler/views:tasked" %t245, ptr %l24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/views:tasked", ptr %l24, i32 0, i32 0
  %t249 = getelementptr %"compiler/views:view", ptr %t248, i32 0, i32 0
  %t250 = load %"compiler/views:place", ptr %t249
  %t251 = load %"compiler/views:place", ptr %l1
  %t255 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %t247, %"compiler/views:place" %t250, %"compiler/views:place" %t251)
  store i1 %t255, ptr %l141
  br label %bb64
bb64:
  %t256 = load i1, ptr %l141, !tbaa !21
  %t257 = xor i1 %t256, true
  br i1 %t257, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb68
bb66:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l2
  %t263 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t259, %"compiler/source:Span" %t260)
  store i1 %t263, ptr %l146
  br label %bb67
bb67:
  %t264 = load i1, ptr %l146, !tbaa !21
  store i1 %t264, ptr %l143, !tbaa !21
  br label %bb68
bb68:
  %t265 = load i1, ptr %l143, !tbaa !21
  br i1 %t265, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb70:
  br label %bb71
bb71:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/views:tasked", ptr %l24, i32 0, i32 0
  %t268 = getelementptr %"compiler/views:view", ptr %t267, i32 0, i32 0
  %t269 = load %"compiler/views:place", ptr %t268
  %t272 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s13, ptr %t266, %"compiler/views:place" %t269)
  store { i64, ptr } %t272, ptr %l149
  br label %bb72
bb72:
  %t273 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t273, ptr %l25, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/views:Viewer", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  store ptr %t283, ptr %l153, !tbaa !29
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l2
  %t288 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t284, %"compiler/source:Span" %t285)
  store { i64, [3 x i64] } %t288, ptr %l156
  br label %bb73
bb73:
  %t289 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t289, { i64, ptr } %t290)
  store %"compiler/msgs:Msg" %t293, ptr %l159
  br label %bb74
bb74:
  %t294 = load ptr, ptr %l153, !tbaa !29
  %t295 = load { i64, [3 x i64] }, ptr %l156
  %t296 = load %"compiler/msgs:Msg", ptr %l159
  %t297 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t294, { i64, [3 x i64] } %t295, %"compiler/msgs:Msg" %t296)
  store i64 %t297, ptr %l160
  br label %bb75
bb75:
  %t298 = load i64, ptr %l160, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/views:Viewer", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = getelementptr %"compiler/load:Loader", ptr %t305, i32 0, i32 4
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l164, !tbaa !29
  store i64 %t298, ptr %l165, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/views:tasked", ptr %l24, i32 0, i32 1
  %t312 = load %"compiler/source:Span", ptr %t311
  %t315 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t310, %"compiler/source:Span" %t312)
  store { i64, [3 x i64] } %t315, ptr %l168
  br label %bb76
bb76:
  %t316 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t318 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %s13, ptr %s13, { i64, ptr } %t316)
  store %"compiler/msgs:Msg" %t318, ptr %l170
  br label %bb77
bb77:
  %t319 = load ptr, ptr %l164, !tbaa !29
  %t320 = load i64, ptr %l165, !tbaa !24
  %t321 = load { i64, [3 x i64] }, ptr %l168
  %t322 = load %"compiler/msgs:Msg", ptr %l170
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s13, ptr %t319, i64 %t320, { i64, [3 x i64] } %t321, %"compiler/msgs:Msg" %t322)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb79:
  %t323 = load i64, ptr %l23, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l23, !tbaa !24
  br label %bb60
bb80:
  %t327 = load i64, ptr %l20, !tbaa !24
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = add i64 %t327, %t328
  store i64 %t331, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb81:
  br label %bb53
bb82:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eholdsOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:state", ptr %a1, i32 0, i32 1
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l12, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c46)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/views:holding", ptr %t37, i64 %t34
  %t39 = load %"compiler/views:holding", ptr %t38
  store %"compiler/views:holding" %t39, ptr %l9
  %t41 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t46 = icmp eq i64 %t42, %a2
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t49 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t50 = load %"compiler/views:view", ptr %t49
  call void @compiler_2fviews_2eviewAdd(ptr %v2, ptr %a3, %"compiler/views:view" %t50)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l8, !tbaa !24
  br label %bb8
bb17:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t57, %t58
  store i64 %t61, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 25
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  store i64 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i1
  %l22 = alloca i32
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  store i32 18, ptr %l13
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l11, ptr %l13)
  store i1 %t19, ptr %l15
  br label %bb3
bb3:
  %t20 = load i1, ptr %l15, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/views:Viewer", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l22
  br label %bb7
bb7:
  %t34 = load i32, ptr %l22, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/views:Viewer", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load i32, ptr %l28, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l29
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 8, ptr @.d47 })
  store i1 %t50, ptr %l30
  br label %bb10
bb10:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = getelementptr %"compiler/types:Table", ptr %t57, i32 0, i32 14
  store ptr %t58, ptr %l34, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/views:Viewer", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l3, !tbaa !23
  %t68 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l39
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb16
bb13:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t71, ptr %l40
  br label %bb14
bb14:
  %t72 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 15, ptr @.d48 })
  store i1 %t73, ptr %l41
  br label %bb15
bb15:
  %t74 = load i1, ptr %l41, !tbaa !21
  store i1 %t74, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l31, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:place"
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/views:view"
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/views:fact"
  %l39 = alloca %"compiler/views:fact"
  %l42 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l66 = alloca { i64, ptr }
  %l72 = alloca i1
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l104 = alloca { i64, ptr }
  %l108 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i32
  %l129 = alloca { i64, ptr }
  %l133 = alloca i64
  %l140 = alloca i1
  %l148 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i32
  %l164 = alloca { i64, ptr }
  %l170 = alloca i1
  %l180 = alloca i64
  %l183 = alloca i64
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca %"compiler/views:fact"
  %l195 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t5, i32 %a2)
  store i1 %t9, ptr %l45
  br label %bb3
bb3:
  %t10 = load i1, ptr %l45, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l42, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l42, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l49
  br label %bb8
bb8:
  %t19 = load i64, ptr %l49, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l3, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb10:
  br label %bb27
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t26, i64 %t27)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l57
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb13, label %ok.34
ok.34:
  store { i64, ptr } %t31, ptr %l56
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t35, ptr %l53, !tbaa !27
  br label %bb17
bb13:
  %t36 = load i32, ptr %l57, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c49)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb17:
  %t41 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t46 = load i64, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t54, ptr %l66, !tbaa !27
  %t55 = load i64, ptr %l10, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/views:view", ptr %t58, i64 %t55
  %t60 = load %"compiler/views:view", ptr %t59
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i64, ptr %l5, !tbaa !24
  %t68 = call i1 @compiler_2fviews_2eholdAdd(ptr %v3, ptr %t62, i64 %t63, %"compiler/views:view" %t60)
  store i1 %t68, ptr %l72
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb23:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l10, !tbaa !24
  br label %bb18
bb24:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = add i64 %t73, %t74
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  br label %bb11
bb26:
  br label %bb27
bb27:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/views:Viewer", ptr %t79, i32 0, i32 21
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t84)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l80
  br label %bb31
bb31:
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l12
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t91 = call ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store ptr %t91, ptr %l83
  br label %bb32
bb32:
  %t92 = load ptr, ptr %l83, !tbaa !29
  store ptr %t92, ptr %l13, !tbaa !29
  %t93 = load ptr, ptr %l13, !tbaa !29
  %t95 = icmp ne ptr %t93, null
  br i1 %t95, label %bb33, label %bb34
bb33:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l13, !tbaa !29
  %t99 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t97, ptr %t98, ptr %t99, ptr %l12)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  store ptr %l12, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t105 = load ptr, ptr %l14, !tbaa !29
  %t106 = load i64, ptr %l15, !tbaa !24
  %t109 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t105, i64 %t106)
  %t110 = extractvalue { i32, { i64, ptr } } %t109, 1
  %t111 = extractvalue { i32, { i64, ptr } } %t109, 0
  store i32 %t111, ptr %l95
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb39, label %ok.113
ok.113:
  store { i64, ptr } %t110, ptr %l94
  br label %bb38
bb38:
  %t114 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t114, ptr %l91, !tbaa !27
  br label %bb43
bb39:
  %t115 = load i32, ptr %l95, !tbaa !23
  %t116 = ashr i32 %t115, 16
  %t118 = icmp eq i32 %t116, 1
  br i1 %t118, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c50)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb122
bb43:
  %t120 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t120, ptr %l16, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  store i64 %t123, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t125 = load i64, ptr %l18, !tbaa !24
  %t126 = load i64, ptr %l17, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb46:
  br label %bb47
bb47:
  %t133 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t133, ptr %l104, !tbaa !27
  %t134 = load i64, ptr %l18, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr %"compiler/views:place", ptr %t137, i64 %t134
  %t139 = load %"compiler/views:place", ptr %t138
  store %"compiler/views:place" %t139, ptr %l19
  %t141 = getelementptr %"compiler/views:place", ptr %l19, i32 0, i32 0
  %t142 = load { i64, [2 x i64] }, ptr %t141
  store { i64, [2 x i64] } %t142, ptr %l20
  %t144 = load { i64, [2 x i64] }, ptr %l20
  %t146 = extractvalue { i64, [2 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 2
  br i1 %t147, label %bb48, label %bb49
bb48:
  %t149 = getelementptr { i64, [2 x i64] }, ptr %l20, i32 0, i32 1
  %t150 = getelementptr { i64 }, ptr %t149, i32 0, i32 0
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l21, !tbaa !24
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t153 = load i64, ptr %l21, !tbaa !24
  store i64 %t153, ptr %l108, !tbaa !24
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i64 -1, ptr %l108, !tbaa !24
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb56:
  %t155 = load i64, ptr %l108, !tbaa !24
  store i64 %t155, ptr %l22, !tbaa !24
  %t156 = load i64, ptr %l22, !tbaa !24
  %t158 = icmp slt i64 %t156, 0
  br i1 %t158, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb119
bb58:
  br label %bb59
bb59:
  %t160 = load ptr, ptr %l3, !tbaa !29
  store ptr %t160, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s16
  %t162 = load ptr, ptr %l23, !tbaa !29
  %t163 = load i64, ptr %l24, !tbaa !24
  %t166 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v2, ptr %t162, i64 %t163)
  %t167 = extractvalue { i32, { i64, ptr } } %t166, 1
  %t168 = extractvalue { i32, { i64, ptr } } %t166, 0
  store i32 %t168, ptr %l120
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb62, label %ok.170
ok.170:
  store { i64, ptr } %t167, ptr %l119
  br label %bb61
bb61:
  %t171 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t171, ptr %l116, !tbaa !27
  br label %bb66
bb62:
  %t172 = load i32, ptr %l120, !tbaa !23
  %t173 = ashr i32 %t172, 16
  %t175 = icmp eq i32 %t173, 1
  br i1 %t175, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @.c52)
  unreachable
bb65:
  call void @__olang_scope_close(ptr %s16)
  br label %bb118
bb66:
  %t177 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t177, ptr %l25, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  store i64 %t180, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s17
  %t182 = load i64, ptr %l27, !tbaa !24
  %t183 = load i64, ptr %l26, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s17)
  br label %bb116
bb69:
  br label %bb70
bb70:
  %t190 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t190, ptr %l129, !tbaa !27
  %t191 = load i64, ptr %l27, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr %"compiler/views:view", ptr %t194, i64 %t191
  %t196 = load %"compiler/views:view", ptr %t195
  store %"compiler/views:view" %t196, ptr %l28
  %t198 = getelementptr %"compiler/views:view", ptr %l28, i32 0, i32 0
  %t199 = getelementptr %"compiler/views:place", ptr %t198, i32 0, i32 0
  %t200 = load { i64, [2 x i64] }, ptr %t199
  store { i64, [2 x i64] } %t200, ptr %l29
  %t202 = load { i64, [2 x i64] }, ptr %l29
  %t204 = extractvalue { i64, [2 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 4
  br i1 %t205, label %bb71, label %bb72
bb71:
  %t207 = getelementptr { i64, [2 x i64] }, ptr %l29, i32 0, i32 1
  %t208 = getelementptr { i64 }, ptr %t207, i32 0, i32 0
  %t209 = load i64, ptr %t208
  store i64 %t209, ptr %l30, !tbaa !24
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t211 = load i64, ptr %l30, !tbaa !24
  store i64 %t211, ptr %l133, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i64 -1, ptr %l133, !tbaa !24
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @.c53)
  unreachable
bb79:
  %t213 = load i64, ptr %l133, !tbaa !24
  store i64 %t213, ptr %l31, !tbaa !24
  %t214 = load i64, ptr %l31, !tbaa !24
  %t216 = icmp slt i64 %t214, 0
  br i1 %t216, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb82
bb81:
  %t218 = load i64, ptr %l31, !tbaa !24
  %t219 = load i64, ptr %l22, !tbaa !24
  %t222 = icmp eq i64 %t218, %t219
  store i1 %t222, ptr %l140, !tbaa !21
  br label %bb82
bb82:
  %t224 = load i1, ptr %l140, !tbaa !21
  br i1 %t224, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb115
bb84:
  br label %bb85
bb85:
  store i1 false, ptr %l32, !tbaa !21
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/views:Viewer", ptr %t225, i32 0, i32 2
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/views:Viewer", ptr %t228, i32 0, i32 20
  %t231 = load i64, ptr %t230, !tbaa !24
  %t234 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t227, i64 %t231)
  store ptr %t234, ptr %l148
  br label %bb86
bb86:
  %t235 = load ptr, ptr %l148, !tbaa !29
  %t237 = getelementptr %"compiler/views:summary", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s22
  %t239 = load ptr, ptr %l33, !tbaa !29
  %t240 = load i64, ptr %l34, !tbaa !24
  %t243 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t239, i64 %t240)
  %t244 = extractvalue { i32, { i64, ptr } } %t243, 1
  %t245 = extractvalue { i32, { i64, ptr } } %t243, 0
  store i32 %t245, ptr %l155
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb89, label %ok.247
ok.247:
  store { i64, ptr } %t244, ptr %l154
  br label %bb88
bb88:
  %t248 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t248, ptr %l151, !tbaa !27
  br label %bb93
bb89:
  %t249 = load i32, ptr %l155, !tbaa !23
  %t250 = ashr i32 %t249, 16
  %t252 = icmp eq i32 %t250, 1
  br i1 %t252, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @.c54)
  unreachable
bb92:
  call void @__olang_scope_close(ptr %s22)
  br label %bb107
bb93:
  %t254 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t254, ptr %l35, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s23
  %t259 = load i64, ptr %l37, !tbaa !24
  %t260 = load i64, ptr %l36, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s23)
  br label %bb105
bb96:
  br label %bb97
bb97:
  %t267 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t267, ptr %l164, !tbaa !27
  %t268 = load i64, ptr %l37, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr %"compiler/views:fact", ptr %t271, i64 %t268
  %t273 = load %"compiler/views:fact", ptr %t272
  store %"compiler/views:fact" %t273, ptr %l38
  %t275 = getelementptr %"compiler/views:fact", ptr %l38, i32 0, i32 0
  %t276 = load i64, ptr %t275, !tbaa !24
  %t277 = load i64, ptr %l31, !tbaa !24
  %t280 = icmp eq i64 %t276, %t277
  br i1 %t280, label %bb98, label %bb99
bb98:
  %t282 = getelementptr %"compiler/views:fact", ptr %l38, i32 0, i32 8
  %t283 = load i64, ptr %t282, !tbaa !24
  %t284 = load i64, ptr %l22, !tbaa !24
  %t287 = icmp eq i64 %t283, %t284
  store i1 %t287, ptr %l170, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb100
bb100:
  %t289 = load i1, ptr %l170, !tbaa !21
  br i1 %t289, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s23)
  br label %bb104
bb104:
  %t290 = load i64, ptr %l37, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l37, !tbaa !24
  br label %bb94
bb105:
  %t294 = load i64, ptr %l34, !tbaa !24
  %t295 = load i64, ptr %l36, !tbaa !24
  %t298 = add i64 %t294, %t295
  store i64 %t298, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb106:
  br label %bb87
bb107:
  %t300 = load i1, ptr %l32, !tbaa !21
  br i1 %t300, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s17)
  br label %bb115
bb109:
  br label %bb110
bb110:
  %t302 = load i64, ptr %l31, !tbaa !24
  store i64 %t302, ptr %l180, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/views:Viewer", ptr %t303, i32 0, i32 19
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Body", ptr %t306, i32 0, i32 3
  %t309 = load i64, ptr %t308, !tbaa !24
  store i64 %t309, ptr %l183, !tbaa !24
  %t310 = getelementptr %"compiler/views:view", ptr %l28, i32 0, i32 1
  %t311 = load i64, ptr %t310, !tbaa !24
  %t313 = trunc i64 %t311 to i32
  %t314 = getelementptr %"compiler/views:view", ptr %l28, i32 0, i32 1
  %t315 = load i64, ptr %t314, !tbaa !24
  %t317 = trunc i64 %t315 to i32
  %t320 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s17, i32 %t313, i32 %t317)
  store %"compiler/source:Span" %t320, ptr %l188
  br label %bb111
bb111:
  %t321 = load i64, ptr %l180, !tbaa !24
  %t322 = load i64, ptr %l183, !tbaa !24
  %t323 = load %"compiler/source:Span", ptr %l188
  %t324 = call %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %s17, i64 %t321, i64 -1, i32 0, i64 0, i64 0, i1 false, i64 %t322, %"compiler/source:Span" %t323)
  store %"compiler/views:fact" %t324, ptr %l189
  br label %bb112
bb112:
  %t325 = load %"compiler/views:fact", ptr %l189
  store %"compiler/views:fact" %t325, ptr %l39
  %t326 = load i64, ptr %l22, !tbaa !24
  %t328 = getelementptr %"compiler/views:fact", ptr %l39, i32 0, i32 8
  store i64 %t326, ptr %t328, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/views:Viewer", ptr %t329, i32 0, i32 2
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/views:Viewer", ptr %t332, i32 0, i32 20
  %t335 = load i64, ptr %t334, !tbaa !24
  %t338 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t331, i64 %t335)
  store ptr %t338, ptr %l195
  br label %bb113
bb113:
  %t339 = load ptr, ptr %l195, !tbaa !29
  %t341 = getelementptr %"compiler/views:summary", ptr %t339, i32 0, i32 2
  %t342 = load %"compiler/views:fact", ptr %l39
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %t341, %"compiler/views:fact" %t342)
  br label %bb114
bb114:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/views:Viewer", ptr %t345, i32 0, i32 24
  store i1 true, ptr %t347, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb115
bb115:
  %t348 = load i64, ptr %l27, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l27, !tbaa !24
  br label %bb67
bb116:
  %t352 = load i64, ptr %l24, !tbaa !24
  %t353 = load i64, ptr %l26, !tbaa !24
  %t356 = add i64 %t352, %t353
  store i64 %t356, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb117
bb117:
  br label %bb60
bb118:
  call void @__olang_scope_close(ptr %s11)
  br label %bb119
bb119:
  %t358 = load i64, ptr %l18, !tbaa !24
  %t360 = add i64 %t358, 1
  store i64 %t360, ptr %l18, !tbaa !24
  br label %bb44
bb120:
  %t362 = load i64, ptr %l15, !tbaa !24
  %t363 = load i64, ptr %l17, !tbaa !24
  %t366 = add i64 %t362, %t363
  store i64 %t366, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb121
bb121:
  br label %bb37
bb122:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/views:state"
  %l6 = alloca %"compiler/views:state"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/views:state"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/views:state"
  %l26 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca %"compiler/views:loopFrame"
  %l34 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca %"compiler/views:state"
  %l42 = alloca %"compiler/views:state"
  %l46 = alloca i64
  %l49 = alloca i64
  %l72 = alloca %"compiler/views:state"
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l91 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l119 = alloca { i64, ptr }
  %l130 = alloca i64
  %l134 = alloca i64
  %l139 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 26
  store ptr %t3, ptr %l28, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Block", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = call %"compiler/views:loopFrame" @compiler_2fviews_3aloopFrame_2ector(ptr %v0, i32 %t7)
  store %"compiler/views:loopFrame" %t9, ptr %l31
  br label %bb1
bb1:
  %t10 = load %"compiler/views:loopFrame", ptr %l31
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/views:loopFrame" %t10, ptr %t11
  %t12 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__He2aba1703ae07509d487434bdc4dbdab(ptr %v0, ptr %v0, ptr %t12, ptr %t11)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 26
  store ptr %t16, ptr %l34, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/views:Viewer", ptr %t17, i32 0, i32 26
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H9b6ab774c92f21a4ef5a53265d5b9504(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l37
  br label %bb3
bb3:
  %t22 = load i64, ptr %l37, !tbaa !24
  %t23 = sub i64 %t22, 1
  %t24 = load ptr, ptr %l34, !tbaa !29
  %t26 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t24, i64 %t23)
  store ptr %t26, ptr %l39
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l39, !tbaa !29
  store ptr %t27, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v3, ptr %s0, ptr %t28)
  store %"compiler/views:state" %t30, ptr %l41
  br label %bb5
bb5:
  %t31 = load %"compiler/views:state", ptr %l41
  store %"compiler/views:state" %t31, ptr %l5
  %t32 = call %"compiler/views:state" @compiler_2fviews_2edead(ptr %s0)
  store %"compiler/views:state" %t32, ptr %l42
  br label %bb6
bb6:
  %t33 = load %"compiler/views:state", ptr %l42
  store %"compiler/views:state" %t33, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  store i64 12, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb12
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l49, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb11
bb11:
  %t60 = load i64, ptr %l49, !tbaa !24
  store i64 %t60, ptr %l46, !tbaa !24
  br label %bb12
bb12:
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load i64, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb15:
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l12, !tbaa !24
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/views:loopFrame", ptr %t80, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t82)
  br label %bb17
bb17:
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/views:loopFrame", ptr %t84, i32 0, i32 2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t86)
  br label %bb18
bb18:
  %t89 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %s0, ptr %s2, ptr %l5)
  store %"compiler/views:state" %t89, ptr %l72
  br label %bb19
bb19:
  %t90 = load %"compiler/views:state", ptr %l72
  store %"compiler/views:state" %t90, ptr %l13
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s2, ptr %t91, ptr %t92, ptr %l13)
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/views:loopFrame", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load ptr, ptr %l14, !tbaa !29
  %t101 = load i64, ptr %l15, !tbaa !24
  %t104 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eRunFrom_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t100, i64 %t101)
  %t105 = extractvalue { i32, { i64, ptr } } %t104, 1
  %t106 = extractvalue { i32, { i64, ptr } } %t104, 0
  store i32 %t106, ptr %l82
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb23, label %ok.108
ok.108:
  store { i64, ptr } %t105, ptr %l81
  br label %bb22
bb22:
  %t109 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t109, ptr %l78, !tbaa !27
  br label %bb27
bb23:
  %t110 = load i32, ptr %l82, !tbaa !23
  %t111 = ashr i32 %t110, 16
  %t113 = icmp eq i32 %t111, 1
  br i1 %t113, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb27:
  %t115 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t115, ptr %l16, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t120 = load i64, ptr %l18, !tbaa !24
  %t121 = load i64, ptr %l17, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t128 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t128, ptr %l91, !tbaa !27
  %t129 = load i64, ptr %l18, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/views:state", ptr %t132, i64 %t129
  %t134 = load %"compiler/views:state", ptr %t133
  store %"compiler/views:state" %t134, ptr %l19
  call void @compiler_2fviews_2emerge(ptr %s2, ptr %s5, ptr %l13, ptr %l19)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t138 = load i64, ptr %l18, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l18, !tbaa !24
  br label %bb28
bb34:
  %t142 = load i64, ptr %l15, !tbaa !24
  %t143 = load i64, ptr %l17, !tbaa !24
  %t146 = add i64 %t142, %t143
  store i64 %t146, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  br label %bb21
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v2, ptr %s2, ptr %t148, ptr %a2, ptr %l13)
  br label %bb37
bb37:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = getelementptr %"compiler/views:loopFrame", ptr %t153, i32 0, i32 1
  store ptr %t155, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t157 = load ptr, ptr %l20, !tbaa !29
  %t158 = load i64, ptr %l21, !tbaa !24
  %t161 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eRunFrom_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %t157, i64 %t158)
  %t162 = extractvalue { i32, { i64, ptr } } %t161, 1
  %t163 = extractvalue { i32, { i64, ptr } } %t161, 0
  store i32 %t163, ptr %l110
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb40, label %ok.165
ok.165:
  store { i64, ptr } %t162, ptr %l109
  br label %bb39
bb39:
  %t166 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t166, ptr %l106, !tbaa !27
  br label %bb44
bb40:
  %t167 = load i32, ptr %l110, !tbaa !23
  %t168 = ashr i32 %t167, 16
  %t170 = icmp eq i32 %t168, 1
  br i1 %t170, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @.c56)
  unreachable
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb44:
  %t172 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t172, ptr %l22, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load i64, ptr %l24, !tbaa !24
  %t178 = load i64, ptr %l23, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t185 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t185, ptr %l119, !tbaa !27
  %t186 = load i64, ptr %l24, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr %"compiler/views:state", ptr %t189, i64 %t186
  %t191 = load %"compiler/views:state", ptr %t190
  store %"compiler/views:state" %t191, ptr %l25
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s9, ptr %l6, ptr %l25)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  %t195 = load i64, ptr %l24, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l24, !tbaa !24
  br label %bb45
bb51:
  %t199 = load i64, ptr %l21, !tbaa !24
  %t200 = load i64, ptr %l23, !tbaa !24
  %t203 = add i64 %t199, %t200
  store i64 %t203, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  br label %bb38
bb53:
  %t206 = call i64 @compiler_2fviews_2eweight(ptr %s0, ptr %l5)
  store i64 %t206, ptr %l130
  br label %bb54
bb54:
  %t207 = load i64, ptr %l130, !tbaa !24
  store i64 %t207, ptr %l26, !tbaa !24
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s2, ptr %l5, ptr %l13)
  br label %bb55
bb55:
  %t211 = call i64 @compiler_2fviews_2eweight(ptr %s0, ptr %l5)
  store i64 %t211, ptr %l134
  br label %bb56
bb56:
  %t212 = load i64, ptr %l26, !tbaa !24
  %t213 = load i64, ptr %l134, !tbaa !24
  %t215 = icmp eq i64 %t213, %t212
  br i1 %t215, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb60:
  %t217 = load i64, ptr %l11, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l11, !tbaa !24
  br label %bb13
bb61:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/views:Viewer", ptr %t221, i32 0, i32 26
  %t225 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Haabd632b519baafc45866c30c5849be1(ptr %v0, ptr %v0, ptr %t223)
  %t226 = extractvalue { i32, ptr } %t225, 1
  %t227 = extractvalue { i32, ptr } %t225, 0
  store i32 %t227, ptr %l143
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb63, label %ok.229
ok.229:
  store ptr %t226, ptr %l142
  br label %bb62
bb62:
  %t230 = load ptr, ptr %l142, !tbaa !29
  store ptr %t230, ptr %l139, !tbaa !29
  br label %bb65
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t231 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v3, ptr %s0, ptr %t231, ptr %l6)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/views:state"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca %"compiler/views:state"
  %l23 = alloca { i64, ptr }
  %l31 = alloca %"compiler/views:state"
  %l40 = alloca { i64, ptr }
  %l44 = alloca %"compiler/views:state"
  %l57 = alloca %"compiler/views:state"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l23, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t24, ptr %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb1
bb7:
  %t36 = call %"compiler/views:state" @compiler_2fviews_2edead(ptr %s0)
  store %"compiler/views:state" %t36, ptr %l31
  br label %bb8
bb8:
  %t37 = load %"compiler/views:state", ptr %l31
  store %"compiler/views:state" %t37, ptr %l8
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Match", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l40, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l12, !tbaa !29
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s5, ptr %t63)
  store %"compiler/views:state" %t65, ptr %l44
  br label %bb13
bb13:
  %t66 = load %"compiler/views:state", ptr %l44
  store %"compiler/views:state" %t66, ptr %l13
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l12, !tbaa !29
  %t69 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %s5, ptr %v3, ptr %t67, ptr %t68, ptr %l13, ptr %t69)
  br label %bb14
bb14:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s5, ptr %l8, ptr %l13)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb16:
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l10, !tbaa !24
  br label %bb9
bb17:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Match", ptr %t80, i32 0, i32 2
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp ne ptr %t83, null
  br i1 %t85, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s7, ptr %t87)
  store %"compiler/views:state" %t89, ptr %l57
  br label %bb20
bb19:
  %t90 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %v2, ptr %l8, ptr %t90)
  br label %bb23
bb20:
  %t93 = load %"compiler/views:state", ptr %l57
  store %"compiler/views:state" %t93, ptr %l14
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Match", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2earm(ptr %v0, ptr %v1, ptr %s7, ptr %v3, ptr %t94, ptr %t98, ptr %l14, ptr %t99)
  br label %bb21
bb21:
  call void @compiler_2fviews_2emerge(ptr %s0, ptr %s7, ptr %l8, ptr %l14)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s0, ptr %t106, ptr %l8)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2emeets(ptr %v0, ptr %a0, %"compiler/views:place" %a1, %"compiler/views:place" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca %"compiler/views:place"
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l11 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  store %"compiler/views:place" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t2)
  store i1 %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb3:
  %t8 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l7
  %t10 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 0
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l9
  %t14 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l7, ptr %l9)
  store i1 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i1, ptr %l11, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l6, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = icmp eq i64 %t21, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t32, i64 %t34, i64 %t36)
  store i1 %t40, ptr %l23
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb15
bb14:
  %t41 = load i1, ptr %l23, !tbaa !21
  store i1 %t41, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l19, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t44 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 3
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = getelementptr %"compiler/views:place", ptr %l2, i32 0, i32 1
  %t51 = load i64, ptr %t50, !tbaa !24
  %t55 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t47, i64 %t49, i64 %t51)
  store i1 %t55, ptr %l30
  br label %bb21
bb20:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb22
bb21:
  %t56 = load i1, ptr %l30, !tbaa !21
  store i1 %t56, ptr %l26, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l26, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enameFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i8
  %l22 = alloca i32
  %l26 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t3, i64 %t4)
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t8)
  store i1 %t9, ptr %l7
  br label %bb3
bb3:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb8
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t11, i64 %t12)
  store i8 %t15, ptr %l11
  br label %bb6
bb6:
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t16)
  store i1 %t17, ptr %l12
  br label %bb7
bb7:
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t20, i64 %t21)
  store i8 %t24, ptr %l16
  br label %bb11
bb11:
  %t25 = load i8, ptr %l16, !tbaa !22
  %t26 = icmp eq i8 %t25, 95
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb1
bb17:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store i32 %t37, ptr %l22, !tbaa !23
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t44 = load i64, ptr %l2, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb20
bb19:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l26, !tbaa !24
  br label %bb20
bb20:
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = trunc i64 %t50 to i32
  %t52 = load i32, ptr %l22, !tbaa !23
  %t54 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t52, i32 %t51)
  store %"compiler/source:Span" %t54, ptr %l31
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t5 = getelementptr %"compiler/views:state", ptr %a1, i32 0, i32 3
  %t9 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %a2)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t4 = load ptr, ptr %l10, !tbaa !29
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = load i64, ptr %t7
  %t10 = icmp eq i64 %t8, 3
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t12, i32 0, i32 1
  %t15 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t18, ptr %t19, i1 false, ptr %t20, ptr %l3)
  br label %bb7
bb7:
  br label %bb42
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 4
  store i1 %t32, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l21, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Elem", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t40, ptr %t44, i1 false, ptr %t45, ptr %l3)
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Elem", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t50, ptr %t54, ptr %t55, ptr %l3)
  br label %bb15
bb15:
  br label %bb42
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l6, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Payload", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t75, ptr %t79, i1 false, ptr %t80, ptr %l3)
  br label %bb22
bb22:
  br label %bb42
bb23:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t86 = load ptr, ptr %l47, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = load i64, ptr %t89
  %t92 = icmp eq i64 %t90, 2
  store i1 %t92, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t100, ptr %t101, ptr %t102, ptr %l3)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t107 = load ptr, ptr %l1, !tbaa !29
  store ptr %t107, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t108 = load ptr, ptr %l57, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb31, label %bb32
bb31:
  %t111 = load ptr, ptr %l57, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 6
  store i1 %t114, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t115 = load i1, ptr %l58, !tbaa !21
  br i1 %t115, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t118, i32 0, i32 2
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l8, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t122, ptr %t123, ptr %t124, ptr %l3)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %a0, %"compiler/views:view" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:view"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/views:view" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 0
  %t2 = getelementptr %"compiler/views:place", ptr %t1, i32 0, i32 0
  %t3 = load { i64, [2 x i64] }, ptr %t2
  store { i64, [2 x i64] } %t3, ptr %l2
  %t5 = load { i64, [2 x i64] }, ptr %l2
  %t7 = extractvalue { i64, [2 x i64] } %t5, 0
  %t8 = icmp eq i64 %t7, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i64 }, ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/views:Viewer", ptr %t17, i32 0, i32 20
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l12
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t26 = getelementptr %"compiler/views:summary", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l16
  br label %bb5
bb5:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/views:Viewer", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/views:Viewer", ptr %t37, i32 0, i32 20
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t36, i64 %t40)
  store ptr %t43, ptr %l22
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t46 = getelementptr %"compiler/views:summary", ptr %t44, i32 0, i32 3
  %t47 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t46, i64 %t47, i1 true)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/views:Viewer", ptr %t50, i32 0, i32 24
  store i1 true, ptr %t52, !tbaa !21
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/views:naming"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/views:place"
  %l26 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l56 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca { i64, [2 x i64] }
  %l84 = alloca %"compiler/views:place"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l93 = alloca ptr
  %l97 = alloca %"compiler/views:place"
  %l98 = alloca ptr
  %l99 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l118 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l123 = alloca ptr
  %l125 = alloca i32
  %l127 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca i32
  %l143 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l157 = alloca i64
  %l160 = alloca i1
  %l161 = alloca i64
  %l166 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l172 = alloca %"compiler/views:place"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %t110 = alloca { i64, [2 x i64] }, align 8
  %t120 = alloca { i64, [2 x i64] }, align 8
  %t155 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t6 = load ptr, ptr %l30, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l30, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l31, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l31, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb38
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l4, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t28 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v2, ptr %t20, ptr %t21, i64 %t24)
  store i1 %t28, ptr %l40
  br label %bb9
bb9:
  %t29 = load i1, ptr %l40, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/views:state", ptr %t30, i32 0, i32 2
  store ptr %t32, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  br label %bb31
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v2, ptr %t34, i64 %t35)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l47
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb14, label %ok.42
ok.42:
  store { i64, ptr } %t39, ptr %l46
  br label %bb13
bb13:
  %t43 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t43, ptr %l43, !tbaa !27
  br label %bb18
bb14:
  %t44 = load i32, ptr %l47, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  br i1 %t47, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb18:
  %t49 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t62 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t62, ptr %l56, !tbaa !27
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/views:naming", ptr %t66, i64 %t63
  %t68 = load %"compiler/views:naming", ptr %t67
  store %"compiler/views:naming" %t68, ptr %l10
  %t70 = getelementptr %"compiler/views:naming", ptr %l10, i32 0, i32 0
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load i32, ptr %l4, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = icmp eq i64 %t71, %t74
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/views:naming", ptr %l10, i32 0, i32 1
  %t81 = load %"compiler/views:place", ptr %t80
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t79, %"compiler/views:place" %t81)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l9, !tbaa !24
  br label %bb19
bb28:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = add i64 %t88, %t89
  store i64 %t92, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  br label %bb12
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb31:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/views:Viewer", ptr %t94, i32 0, i32 25
  %t97 = load i32, ptr %l4, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t96, i64 %t99)
  store i64 %t102, ptr %l74
  br label %bb32
bb32:
  %t103 = load i64, ptr %l74, !tbaa !24
  store i64 %t103, ptr %l11, !tbaa !24
  %t104 = load ptr, ptr %l3, !tbaa !29
  store ptr %t104, ptr %l75, !tbaa !29
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = icmp sge i64 %t105, 0
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t109 = load i64, ptr %l11, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 0
  store i64 2, ptr %t111
  %t113 = insertvalue { i64 } undef, i64 %t109, 0
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  store { i64 } %t113, ptr %t114
  %t115 = load { i64, [2 x i64] }, ptr %t110
  store { i64, [2 x i64] } %t115, ptr %l78
  br label %bb35
bb34:
  %t117 = load i32, ptr %l4, !tbaa !23
  %t119 = sext i32 %t117 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 0
  store i64 1, ptr %t121
  %t123 = insertvalue { i64 } undef, i64 %t119, 0
  %t124 = getelementptr { i64, [2 x i64] }, ptr %t120, i32 0, i32 1
  store { i64 } %t123, ptr %t124
  %t125 = load { i64, [2 x i64] }, ptr %t120
  store { i64, [2 x i64] } %t125, ptr %l78
  br label %bb35
bb35:
  %t127 = load { i64, [2 x i64] }, ptr %l78
  %t128 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s2, { i64, [2 x i64] } %t127, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t128, ptr %l84
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t130 = load %"compiler/views:place", ptr %l84
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t129, %"compiler/views:place" %t130)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb38:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t132 = load ptr, ptr %l85, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t135 = load ptr, ptr %l85, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 1
  store i1 %t138, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l86, !tbaa !21
  br i1 %t139, label %bb41, label %bb42
bb41:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l12, !tbaa !24
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t148, i32 0, i32 3
  %t150 = load i32, ptr %t149
  store i32 %t150, ptr %l13, !tbaa !23
  br label %bb43
bb42:
  br label %bb46
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t152 = load ptr, ptr %l3, !tbaa !29
  store ptr %t152, ptr %l93, !tbaa !29
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i32, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 0
  store i64 3, ptr %t156
  %t158 = insertvalue { i64, i32 } undef, i64 %t153, 0
  %t160 = insertvalue { i64, i32 } %t158, i32 %t154, 1
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 1
  store { i64, i32 } %t160, ptr %t161
  %t162 = load { i64, [2 x i64] }, ptr %t155
  %t164 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s9, { i64, [2 x i64] } %t162, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t164, ptr %l97
  br label %bb44
bb44:
  %t165 = load ptr, ptr %l93, !tbaa !29
  %t166 = load %"compiler/views:place", ptr %l97
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t165, %"compiler/views:place" %t166)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb96
bb46:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t168 = load ptr, ptr %l98, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb47, label %bb48
bb47:
  %t171 = load ptr, ptr %l98, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 2
  store i1 %t174, ptr %l99, !tbaa !21
  br label %bb48
bb48:
  %t175 = load i1, ptr %l99, !tbaa !21
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l14, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t185 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t182, ptr %t183, ptr %t184, ptr %t185)
  br label %bb52
bb52:
  br label %bb96
bb53:
  %t190 = load ptr, ptr %l1, !tbaa !29
  store ptr %t190, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t191 = load ptr, ptr %l108, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb54, label %bb55
bb54:
  %t194 = load ptr, ptr %l108, !tbaa !29
  %t195 = load i64, ptr %t194
  %t197 = icmp eq i64 %t195, 3
  store i1 %t197, ptr %l109, !tbaa !21
  br label %bb55
bb55:
  %t198 = load i1, ptr %l109, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t201, i32 0, i32 1
  %t203 = load i32, ptr %t202
  store i32 %t203, ptr %l15, !tbaa !23
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l16, !tbaa !29
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t213, i32 0, i32 3
  %t215 = load i64, ptr %t214
  store i64 %t215, ptr %l17, !tbaa !24
  br label %bb58
bb57:
  br label %bb91
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t217 = load ptr, ptr @__olang_prog_scope
  %t218 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t217)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t218, ptr %l118
  br label %bb59
bb59:
  %t219 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l18
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l16, !tbaa !29
  %t222 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %s11, ptr %t220, ptr %t221, ptr %t222, ptr %l18)
  br label %bb60
bb60:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l123, !tbaa !29
  %t228 = load ptr, ptr %l16, !tbaa !29
  %t230 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t228)
  store i32 %t230, ptr %l125
  br label %bb61
bb61:
  %t231 = load i64, ptr %l17, !tbaa !24
  %t232 = load ptr, ptr %l123, !tbaa !29
  %t233 = load i32, ptr %l125, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efieldName(ptr %v0, ptr %s11, ptr %t232, i32 %t233, i64 %t231)
  store { i64, ptr } %t235, ptr %l127
  br label %bb62
bb62:
  %t236 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t238 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = add i64 %t237, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t236, i64 %t237)
  %t243 = getelementptr i8, ptr %t242, i64 %t237
  call void @olang_textcopy(ptr %t243, ptr %t239, i64 %t240)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t242, 1
  store { i64, ptr } %t245, ptr %l19, !tbaa !27
  store ptr %l18, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t248 = load ptr, ptr %l20, !tbaa !29
  %t249 = load i64, ptr %l21, !tbaa !24
  %t252 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s11, ptr %t248, i64 %t249)
  %t253 = extractvalue { i32, { i64, ptr } } %t252, 1
  %t254 = extractvalue { i32, { i64, ptr } } %t252, 0
  store i32 %t254, ptr %l134
  %t255 = icmp ne i32 %t254, 0
  br i1 %t255, label %bb65, label %ok.256
ok.256:
  store { i64, ptr } %t253, ptr %l133
  br label %bb64
bb64:
  %t257 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t257, ptr %l130, !tbaa !27
  br label %bb69
bb65:
  %t258 = load i32, ptr %l134, !tbaa !23
  %t259 = ashr i32 %t258, 16
  %t261 = icmp eq i32 %t259, 1
  br i1 %t261, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @.c61)
  unreachable
bb68:
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb69:
  %t263 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t263, ptr %l22, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  store i64 %t266, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s15
  %t268 = load i64, ptr %l24, !tbaa !24
  %t269 = load i64, ptr %l23, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb72:
  br label %bb73
bb73:
  %t276 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t276, ptr %l143, !tbaa !27
  %t277 = load i64, ptr %l24, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr %"compiler/views:place", ptr %t280, i64 %t277
  %t282 = load %"compiler/views:place", ptr %t281
  store %"compiler/views:place" %t282, ptr %l25
  %t284 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 3
  %t285 = load i1, ptr %t284, !tbaa !21
  br i1 %t285, label %bb74, label %bb75
bb74:
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t288 = load %"compiler/views:place", ptr %l25
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t287, %"compiler/views:place" %t288)
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb77:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l149, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/views:Viewer", ptr %t292, i32 0, i32 3
  %t295 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 1
  %t296 = load i64, ptr %t295, !tbaa !24
  %t299 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s15, ptr %t294, i64 %t296)
  store { i64, ptr } %t299, ptr %l153
  br label %bb78
bb78:
  %t300 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t305 = extractvalue { i64, ptr } %t300, 1
  %t306 = extractvalue { i64, ptr } %t300, 0
  %t307 = add i64 %t303, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t302, i64 %t303)
  %t309 = getelementptr i8, ptr %t308, i64 %t303
  call void @olang_textcopy(ptr %t309, ptr %t305, i64 %t306)
  %t310 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t308, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  %t319 = load ptr, ptr %l149, !tbaa !29
  %t321 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %s15, ptr %t319, { i64, ptr } %t318)
  store i64 %t321, ptr %l157
  br label %bb79
bb79:
  %t322 = load i64, ptr %l157, !tbaa !24
  store i64 %t322, ptr %l26, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l15, !tbaa !23
  %t327 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t323, i32 %t324)
  store i1 %t327, ptr %l160
  br label %bb80
bb80:
  %t328 = load i1, ptr %l160, !tbaa !21
  br i1 %t328, label %bb81, label %bb82
bb81:
  %t329 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 2
  %t330 = load i64, ptr %t329, !tbaa !24
  store i64 %t330, ptr %l161, !tbaa !24
  br label %bb84
bb82:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/views:Viewer", ptr %t332, i32 0, i32 3
  %t335 = load i64, ptr %l26, !tbaa !24
  %t338 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s15, ptr %t334, i64 %t335)
  store { i64, ptr } %t338, ptr %l166
  br label %bb83
bb83:
  %t339 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l161, !tbaa !24
  br label %bb84
bb84:
  %t342 = load i64, ptr %l161, !tbaa !24
  %t343 = load ptr, ptr %l3, !tbaa !29
  store ptr %t343, ptr %l168, !tbaa !29
  %t344 = getelementptr %"compiler/views:place", ptr %l25, i32 0, i32 0
  %t345 = load { i64, [2 x i64] }, ptr %t344
  %t346 = load i64, ptr %l26, !tbaa !24
  %t351 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s15, { i64, [2 x i64] } %t345, i64 %t346, i64 %t342, i1 false)
  store %"compiler/views:place" %t351, ptr %l172
  br label %bb85
bb85:
  %t352 = load ptr, ptr %l168, !tbaa !29
  %t353 = load %"compiler/views:place", ptr %l172
  call void @compiler_2fviews_2eplaceAdd(ptr %v3, ptr %t352, %"compiler/views:place" %t353)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb87:
  %t354 = load i64, ptr %l24, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l24, !tbaa !24
  br label %bb70
bb88:
  %t358 = load i64, ptr %l21, !tbaa !24
  %t359 = load i64, ptr %l23, !tbaa !24
  %t362 = add i64 %t358, %t359
  store i64 %t362, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb89:
  br label %bb63
bb90:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb96:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca i1
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i32
  %l94 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca i1
  %l110 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l116 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %l137 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l148 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l174 = alloca i64
  %l179 = alloca ptr
  %l181 = alloca ptr
  %l184 = alloca i64
  %l186 = alloca ptr
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l31, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t12 = load ptr, ptr %l34, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l34, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l35, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l35, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l5
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l6, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load %"compiler/source:Span", ptr %l5
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2euse(ptr %v0, ptr %v2, ptr %t32, i64 %t35, %"compiler/source:Span" %t36, ptr %t37)
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l6, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t47 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eholdsOf(ptr %v0, ptr %v2, ptr %v3, ptr %t42, ptr %t43, i64 %t46, ptr %t47)
  br label %bb13
bb13:
  br label %bb113
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t53 = load ptr, ptr %l52, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l52, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 2
  store i1 %t59, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l53, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l7, !tbaa !29
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t67, ptr %t68, ptr %t69, ptr %t70)
  br label %bb20
bb20:
  br label %bb113
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t76 = load ptr, ptr %l62, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t83 = load i1, ptr %l63, !tbaa !21
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l8, !tbaa !23
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb52
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l70
  br label %bb27
bb27:
  %t97 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l10
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s4, ptr %t98, ptr %t99, i1 false, ptr %t100, ptr %l10)
  br label %bb28
bb28:
  %t105 = load i1, ptr %l2, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb32
bb30:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l8, !tbaa !23
  %t111 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l79
  br label %bb31
bb31:
  %t112 = load i1, ptr %l79, !tbaa !21
  store i1 %t112, ptr %l76, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l76, !tbaa !21
  br i1 %t113, label %bb33, label %bb34
bb33:
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb34:
  br label %bb51
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = load ptr, ptr %l11, !tbaa !29
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s4, ptr %t115, i64 %t116)
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l85
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb37, label %ok.123
ok.123:
  store { i64, ptr } %t120, ptr %l84
  br label %bb36
bb36:
  %t124 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t124, ptr %l81, !tbaa !27
  br label %bb41
bb37:
  %t125 = load i32, ptr %l85, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  br i1 %t128, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @.c63)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb41:
  %t130 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t130, ptr %l13, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t135 = load i64, ptr %l15, !tbaa !24
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t143 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t143, ptr %l94, !tbaa !27
  %t144 = load i64, ptr %l15, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr %"compiler/views:view", ptr %t147, i64 %t144
  %t149 = load %"compiler/views:view", ptr %t148
  %t151 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t151, %"compiler/views:view" %t149)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb47:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l15, !tbaa !24
  br label %bb42
bb48:
  %t159 = load i64, ptr %l12, !tbaa !24
  %t160 = load i64, ptr %l14, !tbaa !24
  %t163 = add i64 %t159, %t160
  store i64 %t163, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  br label %bb35
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb113
bb52:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t166 = load ptr, ptr %l104, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb53, label %bb54
bb53:
  %t169 = load ptr, ptr %l104, !tbaa !29
  %t170 = load i64, ptr %t169
  %t172 = icmp eq i64 %t170, 4
  store i1 %t172, ptr %l105, !tbaa !21
  br label %bb54
bb54:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb55, label %bb56
bb55:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t176, i32 0, i32 2
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l17, !tbaa !29
  br label %bb57
bb56:
  br label %bb81
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  %t180 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l110
  br label %bb58
bb58:
  %t181 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t181, ptr %l18
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l17, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Elem", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %s10, ptr %t182, ptr %t186, i1 false, ptr %t187, ptr %l18)
  br label %bb59
bb59:
  %t192 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %l116
  br label %bb60
bb60:
  %t193 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %l19
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l17, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Elem", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s10, ptr %t194, ptr %t198, ptr %t199, ptr %l19)
  br label %bb61
bb61:
  %t204 = load i1, ptr %l2, !tbaa !21
  br i1 %t204, label %bb62, label %bb63
bb62:
  store ptr %l18, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb64
bb63:
  br label %bb80
bb64:
  store %olang.scope zeroinitializer, ptr %s13
  %t207 = load ptr, ptr %l20, !tbaa !29
  %t208 = load i64, ptr %l21, !tbaa !24
  %t211 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s10, ptr %t207, i64 %t208)
  %t212 = extractvalue { i32, { i64, ptr } } %t211, 1
  %t213 = extractvalue { i32, { i64, ptr } } %t211, 0
  store i32 %t213, ptr %l128
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb66, label %ok.215
ok.215:
  store { i64, ptr } %t212, ptr %l127
  br label %bb65
bb65:
  %t216 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t216, ptr %l124, !tbaa !27
  br label %bb70
bb66:
  %t217 = load i32, ptr %l128, !tbaa !23
  %t218 = ashr i32 %t217, 16
  %t220 = icmp eq i32 %t218, 1
  br i1 %t220, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @.c64)
  unreachable
bb69:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb70:
  %t222 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t222, ptr %l22, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  store i64 %t225, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t227 = load i64, ptr %l24, !tbaa !24
  %t228 = load i64, ptr %l23, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb73:
  br label %bb74
bb74:
  %t235 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t235, ptr %l137, !tbaa !27
  %t236 = load i64, ptr %l24, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr %"compiler/views:view", ptr %t239, i64 %t236
  %t241 = load %"compiler/views:view", ptr %t240
  %t243 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2eviewAdd(ptr %v3, ptr %t243, %"compiler/views:view" %t241)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb76
bb76:
  %t247 = load i64, ptr %l24, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l24, !tbaa !24
  br label %bb71
bb77:
  %t251 = load i64, ptr %l21, !tbaa !24
  %t252 = load i64, ptr %l23, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb78
bb78:
  br label %bb64
bb79:
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s10)
  br label %bb113
bb81:
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t258 = load ptr, ptr %l147, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb82, label %bb83
bb82:
  %t261 = load ptr, ptr %l147, !tbaa !29
  %t262 = load i64, ptr %t261
  %t264 = icmp eq i64 %t262, 5
  store i1 %t264, ptr %l148, !tbaa !21
  br label %bb83
bb83:
  %t265 = load i1, ptr %l148, !tbaa !21
  br i1 %t265, label %bb84, label %bb85
bb84:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr { i64, [4 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t268, i32 0, i32 2
  %t270 = load ptr, ptr %t269
  store ptr %t270, ptr %l26, !tbaa !29
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load ptr, ptr %l26, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Payload", ptr %t273, i32 0, i32 0
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t277 = load ptr, ptr %l3, !tbaa !29
  %t278 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t272, ptr %t276, i1 false, ptr %t277, ptr %t278)
  br label %bb87
bb87:
  br label %bb113
bb88:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t284 = load ptr, ptr %l158, !tbaa !29
  %t285 = icmp ne ptr %t284, null
  br i1 %t285, label %bb89, label %bb90
bb89:
  %t287 = load ptr, ptr %l158, !tbaa !29
  %t288 = load i64, ptr %t287
  %t290 = icmp eq i64 %t288, 6
  store i1 %t290, ptr %l159, !tbaa !21
  br label %bb90
bb90:
  %t291 = load i1, ptr %l159, !tbaa !21
  br i1 %t291, label %bb91, label %bb92
bb91:
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t294, i32 0, i32 2
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l27, !tbaa !29
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l27, !tbaa !29
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t301 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t298, ptr %t299, ptr %t300, ptr %t301)
  br label %bb94
bb94:
  br label %bb113
bb95:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t307 = load ptr, ptr %l168, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb96, label %bb97
bb96:
  %t310 = load ptr, ptr %l168, !tbaa !29
  %t311 = load i64, ptr %t310
  %t313 = icmp eq i64 %t311, 7
  store i1 %t313, ptr %l169, !tbaa !21
  br label %bb97
bb97:
  %t314 = load i1, ptr %l169, !tbaa !21
  br i1 %t314, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb108
bb100:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/views:Viewer", ptr %t315, i32 0, i32 27
  %t319 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t317)
  store i64 %t319, ptr %l174
  br label %bb101
bb101:
  %t320 = load i64, ptr %l174, !tbaa !24
  %t321 = icmp sgt i64 %t320, 0
  br i1 %t321, label %bb102, label %bb103
bb102:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/views:Viewer", ptr %t323, i32 0, i32 22
  %t326 = load i1, ptr %t325, !tbaa !21
  store i1 %t326, ptr %l28, !tbaa !21
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/views:Viewer", ptr %t328, i32 0, i32 22
  store i1 true, ptr %t330, !tbaa !21
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l179, !tbaa !29
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/views:Viewer", ptr %t332, i32 0, i32 27
  store ptr %t334, ptr %l181, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/views:Viewer", ptr %t335, i32 0, i32 27
  %t339 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t337)
  store i64 %t339, ptr %l184
  br label %bb104
bb103:
  br label %bb107
bb104:
  %t340 = load i64, ptr %l184, !tbaa !24
  %t341 = sub i64 %t340, 1
  %t342 = load ptr, ptr %l181, !tbaa !29
  %t344 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v0, ptr %t342, i64 %t341)
  store ptr %t344, ptr %l186
  br label %bb105
bb105:
  %t345 = load i1, ptr %l2, !tbaa !21
  %t346 = load ptr, ptr %l3, !tbaa !29
  %t347 = load ptr, ptr %l4, !tbaa !29
  %t348 = load ptr, ptr %l179, !tbaa !29
  %t349 = load ptr, ptr %l186, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceRefs(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t348, ptr %t349, i1 %t345, ptr %t346, ptr %t347)
  br label %bb106
bb106:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i1, ptr %l28, !tbaa !21
  %t357 = getelementptr %"compiler/views:Viewer", ptr %t353, i32 0, i32 22
  store i1 %t354, ptr %t357, !tbaa !21
  br label %bb107
bb107:
  br label %bb113
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb113:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Elem", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t27, i8 91)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t32, ptr %l6
  br label %bb20
bb7:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 3
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l4
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l4
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t60 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eafter(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, ptr %t56, i8 46)
  store %"compiler/source:Span" %t60, ptr %l31
  br label %bb13
bb13:
  %t61 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t62)
  store %"compiler/source:Span" %t64, ptr %l33
  br label %bb18
bb18:
  %t65 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t65, ptr %l6
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb20:
  %t66 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 3
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/views:Viewer", ptr %t9, i32 0, i32 3
  %t15 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t11, i64 %a2)
  store { i64, ptr } %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v0, { i64, ptr } %t17, { i64, ptr } %t18)
  store i1 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp eq i64 %t25, %t28
  br i1 %t31, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 46
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l22, !tbaa !21
  store i1 %t45, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l16, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2equoted(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 31, ptr @.d67 }, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/views:Viewer", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l14
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 1
  %t31 = load { i64, [2 x i64] }, ptr %t30
  store { i64, [2 x i64] } %t31, ptr %l2
  %t33 = load { i64, [2 x i64] }, ptr %l2
  %t35 = extractvalue { i64, [2 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 0
  br i1 %t36, label %bb5, label %bb6
bb5:
  %t38 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t39 = getelementptr { i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/views:Viewer", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/views:Viewer", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l27
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l27, !tbaa !24
  %t57 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t55, i64 %t56)
  store ptr %t57, ptr %l28
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load ptr, ptr %l21, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t62, i32 %t61)
  store { i64, ptr } %t64, ptr %l31
  br label %bb10
bb10:
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t75, ptr %t68, i64 %t69)
  %t76 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t76, ptr %t71, i64 %t72)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t74, 1
  store { i64, ptr } %t78, ptr %l17, !tbaa !27
  br label %bb23
bb11:
  %t80 = load { i64, [2 x i64] }, ptr %l2
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 1
  br i1 %t83, label %bb12, label %bb13
bb12:
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t86 = getelementptr { i32, i32 }, ptr %t85, i32 0, i32 0
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l36, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/views:Viewer", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l39, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/views:Viewer", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l4, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l44
  br label %bb15
bb15:
  %t106 = load ptr, ptr %l39, !tbaa !29
  %t107 = load i32, ptr %l44, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t108, ptr %l45
  br label %bb16
bb16:
  %t109 = load ptr, ptr %l36, !tbaa !29
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l46
  br label %bb17
bb17:
  %t112 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  %t114 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr @.d71 }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr @.d71 }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t112, i64 %t113)
  %t122 = getelementptr i8, ptr %t121, i64 %t113
  call void @olang_textcopy(ptr %t122, ptr %t115, i64 %t116)
  %t123 = getelementptr i8, ptr %t122, i64 %t116
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t121, 1
  store { i64, ptr } %t125, ptr %l17, !tbaa !27
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 8, ptr @.d72 }, ptr %l48, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t127, ptr %l17, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @.c73)
  unreachable
bb23:
  %t129 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l50, !tbaa !24
  %t131 = load i64, ptr %l50, !tbaa !24
  %t132 = mul i64 %t131, 1
  %t133 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l51, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = mul i64 %t140, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %t139, i64 %t141, i1 false)
  %t142 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t142, ptr %l17, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erecordPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i32, ptr %l7, !tbaa !23
  %t7 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisRecord(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t7, ptr %l8
  br label %bb2
bb2:
  %t8 = load i1, ptr %l8, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 2
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexprPlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t26, ptr %t27, ptr %t28, ptr %t29)
  br label %bb11
bb11:
  br label %bb18
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t34, ptr %t35, ptr %t36, ptr %t37)
  br label %bb16
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c74)
  unreachable
bb18:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l6, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eisParam(ptr %v0, ptr %t27, i64 %t30)
  store i1 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb13
bb12:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb13
bb13:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l10, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c75)
  unreachable
bb19:
  %t40 = load i64, ptr %l10, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  store i64 64, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l19, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t55 = load ptr, ptr %l43, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l43, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t62 = load i1, ptr %l44, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l9, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t69 = load ptr, ptr %l9, !tbaa !29
  store ptr %t69, ptr %l2, !tbaa !29
  br label %bb68
bb19:
  %t71 = load ptr, ptr %l2, !tbaa !29
  store ptr %t71, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t72 = load ptr, ptr %l50, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l51, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l51, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t86 = load ptr, ptr %l10, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l2, !tbaa !29
  br label %bb68
bb25:
  %t91 = load ptr, ptr %l2, !tbaa !29
  store ptr %t91, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t92 = load ptr, ptr %l58, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t95 = load ptr, ptr %l58, !tbaa !29
  %t96 = load i64, ptr %t95
  %t98 = icmp eq i64 %t96, 5
  store i1 %t98, ptr %l59, !tbaa !21
  br label %bb27
bb27:
  %t99 = load i1, ptr %l59, !tbaa !21
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l11, !tbaa !29
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t106 = load ptr, ptr %l11, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Payload", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l2, !tbaa !29
  br label %bb68
bb31:
  %t111 = load ptr, ptr %l2, !tbaa !29
  store ptr %t111, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t112 = load ptr, ptr %l66, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb32, label %bb33
bb32:
  %t115 = load ptr, ptr %l66, !tbaa !29
  %t116 = load i64, ptr %t115
  %t118 = icmp eq i64 %t116, 2
  store i1 %t118, ptr %l67, !tbaa !21
  br label %bb33
bb33:
  %t119 = load i1, ptr %l67, !tbaa !21
  br i1 %t119, label %bb34, label %bb35
bb34:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l12, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t126 = load ptr, ptr %l12, !tbaa !29
  %t128 = call ptr @compiler_2fviews_2eunAway(ptr %v1, ptr %t126)
  store ptr %t128, ptr %l73
  br label %bb37
bb37:
  %t129 = load ptr, ptr %l73, !tbaa !29
  store ptr %t129, ptr %l13, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t131 = load ptr, ptr %l74, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t134 = load ptr, ptr %l74, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 2
  store i1 %t137, ptr %l75, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l75, !tbaa !21
  br i1 %t138, label %bb40, label %bb41
bb40:
  %t139 = load ptr, ptr %l13, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l14, !tbaa !29
  br label %bb46
bb41:
  %t145 = load ptr, ptr %l13, !tbaa !29
  store ptr %t145, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t146 = load ptr, ptr %l80, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb42, label %bb43
bb42:
  %t149 = load ptr, ptr %l80, !tbaa !29
  %t150 = load i64, ptr %t149
  %t152 = icmp eq i64 %t150, 3
  store i1 %t152, ptr %l81, !tbaa !21
  br label %bb43
bb43:
  %t153 = load i1, ptr %l81, !tbaa !21
  br i1 %t153, label %bb44, label %bb45
bb44:
  %t154 = load ptr, ptr %l13, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l14, !tbaa !29
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t160 = load ptr, ptr %l14, !tbaa !29
  store ptr %t160, ptr %l2, !tbaa !29
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb51:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb52:
  br label %bb68
bb53:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t164 = load ptr, ptr %l88, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb54, label %bb55
bb54:
  %t167 = load ptr, ptr %l88, !tbaa !29
  %t168 = load i64, ptr %t167
  %t170 = icmp eq i64 %t168, 0
  store i1 %t170, ptr %l89, !tbaa !21
  br label %bb55
bb55:
  %t171 = load i1, ptr %l89, !tbaa !21
  br i1 %t171, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t172 = load ptr, ptr %l2, !tbaa !29
  store ptr %t172, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t173 = load ptr, ptr %l92, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb58, label %bb59
bb58:
  %t176 = load ptr, ptr %l92, !tbaa !29
  %t177 = load i64, ptr %t176
  %t179 = icmp eq i64 %t177, 1
  store i1 %t179, ptr %l93, !tbaa !21
  br label %bb59
bb59:
  %t180 = load i1, ptr %l93, !tbaa !21
  br i1 %t180, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t181 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t181, ptr %rv
  br label %ret
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s2)
  store ptr null, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @.c77)
  unreachable
bb68:
  call void @__olang_scope_close(ptr %s2)
  br label %bb69
bb69:
  %t184 = load i64, ptr %l7, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l7, !tbaa !24
  br label %bb7
bb70:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l13 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 19
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 3
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = shl i64 %t7, 32
  %t10 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t16 = or i64 %t9, %t13
  store i64 %t16, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/views:Viewer", ptr %t18, i32 0, i32 28
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t20, i64 %t21)
  store i1 %t24, ptr %l13
  br label %bb1
bb1:
  %t25 = load i1, ptr %l13, !tbaa !21
  br i1 %t25, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/views:Viewer", ptr %t27, i32 0, i32 28
  %t30 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t29, i64 %t30, i1 true)
  br label %bb5
bb5:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eskipSpace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i8
  %l8 = alloca i1
  %l11 = alloca i8
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t3, i64 %t4)
  store i8 %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = icmp eq i8 %t8, 32
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i8 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2echarAt(ptr %v0, ptr %t11, i64 %t12)
  store i8 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i8, ptr %l11, !tbaa !22
  %t17 = icmp eq i8 %t16, 9
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l8, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = add i64 %t22, 1
  store i64 %t24, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb1
bb11:
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca ptr
  %l38 = alloca i1
  %l51 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i32
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca %"compiler/views:tasked"
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Spawn", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t3, ptr %t7, ptr %t8, ptr %l4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/views:Viewer", ptr %t13, i32 0, i32 22
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l5, !tbaa !21
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/views:Viewer", ptr %t18, i32 0, i32 22
  store i1 true, ptr %t20, !tbaa !21
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l34
  br label %bb3
bb3:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l6
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Spawn", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l7, !tbaa !29
  %t28 = load ptr, ptr %l7, !tbaa !29
  store ptr %t28, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t29 = load ptr, ptr %l37, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t32 = load ptr, ptr %l37, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 6
  store i1 %t35, ptr %l38, !tbaa !21
  br label %bb5
bb5:
  %t36 = load i1, ptr %l38, !tbaa !21
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l8, !tbaa !29
  br label %bb8
bb7:
  br label %bb28
bb8:
  %t43 = load ptr, ptr %l8, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Call", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t60 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t60, ptr %l51, !tbaa !27
  %t61 = load i64, ptr %l10, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr ptr, ptr %t64, i64 %t61
  %t66 = load ptr, ptr %t65, !tbaa !39
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t68, ptr %t66, ptr %t70, ptr %l6)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l10, !tbaa !24
  br label %bb9
bb15:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Call", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  store ptr %t82, ptr %l13, !tbaa !29
  %t84 = load ptr, ptr %l13, !tbaa !29
  store ptr %t84, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb16, label %bb17
bb16:
  %t88 = load ptr, ptr %l62, !tbaa !29
  %t89 = load i64, ptr %t88
  %t91 = icmp eq i64 %t89, 2
  store i1 %t91, ptr %l63, !tbaa !21
  br label %bb17
bb17:
  %t92 = load i1, ptr %l63, !tbaa !21
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t93 = load ptr, ptr %l13, !tbaa !29
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { ptr }, ptr %t95, i32 0, i32 0
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l14, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l14, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t99, ptr %t100, ptr %t101, ptr %l6)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i1, ptr %l5, !tbaa !21
  %t110 = getelementptr %"compiler/views:Viewer", ptr %t106, i32 0, i32 22
  store i1 %t107, ptr %t110, !tbaa !21
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t112 = load ptr, ptr %l15, !tbaa !29
  %t113 = load i64, ptr %l16, !tbaa !24
  %t116 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s0, ptr %t112, i64 %t113)
  %t117 = extractvalue { i32, { i64, ptr } } %t116, 1
  %t118 = extractvalue { i32, { i64, ptr } } %t116, 0
  store i32 %t118, ptr %l79
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb36, label %ok.120
ok.120:
  store { i64, ptr } %t117, ptr %l78
  br label %bb35
bb35:
  %t121 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t121, ptr %l75, !tbaa !27
  br label %bb40
bb36:
  %t122 = load i32, ptr %l79, !tbaa !23
  %t123 = ashr i32 %t122, 16
  %t125 = icmp eq i32 %t123, 1
  br i1 %t125, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @.c80)
  unreachable
bb39:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb40:
  %t127 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t127, ptr %l17, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  store i64 %t130, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t132 = load i64, ptr %l19, !tbaa !24
  %t133 = load i64, ptr %l18, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t140 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t140, ptr %l88, !tbaa !27
  %t141 = load i64, ptr %l19, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/views:view", ptr %t144, i64 %t141
  %t146 = load %"compiler/views:view", ptr %t145
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/views:state", ptr %t148, i32 0, i32 4
  store ptr %t150, ptr %l92, !tbaa !29
  %t155 = call %"compiler/views:tasked" @compiler_2fviews_3atasked_2ector(ptr %s10, %"compiler/views:view" %t146, %"compiler/source:Span" %a1)
  store %"compiler/views:tasked" %t155, ptr %l95
  br label %bb45
bb45:
  %t156 = load ptr, ptr %l92, !tbaa !29
  %t157 = load %"compiler/views:tasked", ptr %l95
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t156, %"compiler/views:tasked" %t157)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t158 = load i64, ptr %l19, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l19, !tbaa !24
  br label %bb41
bb48:
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = add i64 %t162, %t163
  store i64 %t166, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb49:
  br label %bb34
bb50:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Spawn", ptr %t168, i32 0, i32 0
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l23, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s13
  %t177 = load i64, ptr %l22, !tbaa !24
  %t178 = load i64, ptr %l23, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t185 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t185, ptr %l109, !tbaa !27
  %t186 = load i64, ptr %l22, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr ptr, ptr %t189, i64 %t186
  %t191 = load ptr, ptr %t190, !tbaa !39
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %s13, ptr %s0, ptr %v2, ptr %t193, ptr %t191, ptr null, ptr %l4, ptr %t195)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s13)
  br label %bb56
bb56:
  %t200 = load i64, ptr %l22, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l22, !tbaa !24
  br label %bb51
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/views:state"
  %l13 = alloca %"compiler/views:state"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/views:view"
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca %"compiler/views:state"
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i1
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l113 = alloca %"compiler/views:state"
  %l115 = alloca %"compiler/views:state"
  %l128 = alloca ptr
  %l129 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l150 = alloca i64
  %l154 = alloca i1
  %l158 = alloca ptr
  %l168 = alloca i32
  %l170 = alloca i32
  %l172 = alloca i1
  %l176 = alloca ptr
  %l178 = alloca ptr
  %l180 = alloca %"compiler/views:state"
  %l184 = alloca ptr
  %l186 = alloca ptr
  %l188 = alloca %"compiler/views:state"
  %l190 = alloca ptr
  %l191 = alloca i1
  %l198 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l207 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca i32
  %l220 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l232 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca i1
  %l253 = alloca ptr
  %l254 = alloca i1
  %l266 = alloca ptr
  %l267 = alloca i1
  %l281 = alloca %"compiler/views:state"
  %l286 = alloca ptr
  %l287 = alloca i1
  %l295 = alloca ptr
  %l296 = alloca i1
  %l299 = alloca ptr
  %l300 = alloca i1
  %l307 = alloca i64
  %l315 = alloca i1
  %l318 = alloca i64
  %l329 = alloca ptr
  %l330 = alloca i1
  %l341 = alloca ptr
  %l342 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s26 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l42, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l42, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l45
  br label %bb7
bb7:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l3
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t14 = load ptr, ptr %l46, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb8, label %bb9
bb8:
  %t17 = load ptr, ptr %l46, !tbaa !29
  %t18 = load i64, ptr %t17
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l47, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l47, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l54
  br label %bb13
bb13:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l6
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %t36, ptr %t37, ptr %t38, ptr %l6)
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ebind(ptr %v0, ptr %v1, ptr %s2, ptr %v2, ptr %t43, i64 %t46, ptr %t47, ptr %l6, i1 true, ptr %t48)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb202
bb16:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t55 = load ptr, ptr %l65, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l65, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 1
  store i1 %t61, ptr %l66, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l66, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l8, !tbaa !29
  br label %bb21
bb20:
  br label %bb30
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l73
  br label %bb22
bb22:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l9
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/views:Viewer", ptr %t77, i32 0, i32 27
  %t80 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  br label %bb23
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t83, ptr %t84, ptr %t85, ptr %l9)
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/views:Viewer", ptr %t90, i32 0, i32 27
  %t94 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePo_H0db9b8972766e5b481cadc211ca24c07(ptr %v0, ptr %s3, ptr %t92)
  %t95 = extractvalue { i32, ptr } %t94, 1
  %t96 = extractvalue { i32, ptr } %t94, 0
  store i32 %t96, ptr %l85
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb26, label %ok.98
ok.98:
  store ptr %t95, ptr %l84
  br label %bb25
bb25:
  %t99 = load ptr, ptr %l84, !tbaa !29
  store ptr %t99, ptr %l81, !tbaa !29
  br label %bb28
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t102 = load ptr, ptr %l8, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %s3, ptr %v2, ptr %t100, ptr %t101, ptr %t102, ptr %l9, ptr %t103)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb202
bb30:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t110 = load ptr, ptr %l91, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t113 = load ptr, ptr %l91, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 2
  store i1 %t116, ptr %l92, !tbaa !21
  br label %bb32
bb32:
  %t117 = load i1, ptr %l92, !tbaa !21
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr }, ptr %t120, i32 0, i32 1
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t124, ptr %t125, ptr %t126, ptr %l3)
  br label %bb36
bb36:
  br label %bb202
bb37:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t132 = load ptr, ptr %l101, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb38, label %bb39
bb38:
  %t135 = load ptr, ptr %l101, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 3
  store i1 %t138, ptr %l102, !tbaa !21
  br label %bb39
bb39:
  %t139 = load i1, ptr %l102, !tbaa !21
  br i1 %t139, label %bb40, label %bb41
bb40:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr }, ptr %t142, i32 0, i32 1
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l11, !tbaa !29
  br label %bb42
bb41:
  br label %bb50
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l11, !tbaa !29
  %t149 = getelementptr %"compiler/typed:If", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t146, ptr %t150, ptr %t151, ptr %l3)
  br label %bb43
bb43:
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t158 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s6, ptr %t156)
  store %"compiler/views:state" %t158, ptr %l113
  br label %bb44
bb44:
  %t159 = load %"compiler/views:state", ptr %l113
  store %"compiler/views:state" %t159, ptr %l12
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s6, ptr %t160)
  store %"compiler/views:state" %t162, ptr %l115
  br label %bb45
bb45:
  %t163 = load %"compiler/views:state", ptr %l115
  store %"compiler/views:state" %t163, ptr %l13
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t167 = getelementptr %"compiler/typed:If", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s6, ptr %t164, ptr %t168, ptr %l12)
  br label %bb46
bb46:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l11, !tbaa !29
  %t175 = getelementptr %"compiler/typed:If", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %s6, ptr %t172, ptr %t176, ptr %l13)
  br label %bb47
bb47:
  call void @compiler_2fviews_2emerge(ptr %s6, ptr %s6, ptr %l12, ptr %l13)
  br label %bb48
bb48:
  %t182 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v2, ptr %s6, ptr %t182, ptr %l12)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb202
bb50:
  %t185 = load ptr, ptr %l1, !tbaa !29
  store ptr %t185, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t186 = load ptr, ptr %l128, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = load ptr, ptr %l128, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 4
  store i1 %t192, ptr %l129, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l129, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t196, i32 0, i32 1
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l14, !tbaa !29
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [3 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l15, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l14, !tbaa !29
  %t208 = load ptr, ptr %l15, !tbaa !29
  %t209 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t206, ptr %t207, ptr %t208, ptr %t209)
  br label %bb56
bb56:
  br label %bb202
bb57:
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t215 = load ptr, ptr %l140, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb58, label %bb59
bb58:
  %t218 = load ptr, ptr %l140, !tbaa !29
  %t219 = load i64, ptr %t218
  %t221 = icmp eq i64 %t219, 5
  store i1 %t221, ptr %l141, !tbaa !21
  br label %bb59
bb59:
  %t222 = load i1, ptr %l141, !tbaa !21
  br i1 %t222, label %bb60, label %bb61
bb60:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t225, i32 0, i32 1
  %t227 = load i32, ptr %t226
  store i32 %t227, ptr %l16
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t231, i32 0, i32 2
  %t233 = load i32, ptr %t232
  store i32 %t233, ptr %l17, !tbaa !23
  br label %bb62
bb61:
  br label %bb87
bb62:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/views:Viewer", ptr %t235, i32 0, i32 26
  %t239 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H9b6ab774c92f21a4ef5a53265d5b9504(ptr %v0, ptr %t237)
  store i64 %t239, ptr %l150
  br label %bb63
bb63:
  %t240 = load i64, ptr %l150, !tbaa !24
  %t241 = sub i64 %t240, 1
  store i64 %t241, ptr %l18, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t243 = load i64, ptr %l18, !tbaa !24
  %t245 = icmp sge i64 %t243, 0
  br i1 %t245, label %bb65, label %bb66
bb65:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/views:Viewer", ptr %t247, i32 0, i32 26
  %t250 = load i64, ptr %l18, !tbaa !24
  %t253 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t249, i64 %t250)
  store ptr %t253, ptr %l158
  br label %bb67
bb66:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb68
bb67:
  %t254 = load ptr, ptr %l158, !tbaa !29
  %t256 = getelementptr %"compiler/views:loopFrame", ptr %t254, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  %t258 = load i32, ptr %l17, !tbaa !23
  %t261 = icmp ne i32 %t257, %t258
  store i1 %t261, ptr %l154, !tbaa !21
  br label %bb68
bb68:
  %t263 = load i1, ptr %l154, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb73
bb70:
  br label %bb71
bb71:
  %t266 = load i64, ptr %l18, !tbaa !24
  %t268 = sub i64 %t266, 1
  store i64 %t268, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb72:
  br label %bb64
bb73:
  %t270 = load i64, ptr %l18, !tbaa !24
  %t272 = icmp sge i64 %t270, 0
  br i1 %t272, label %bb74, label %bb75
bb74:
  %t274 = load i32, ptr %l16
  store i32 %t274, ptr %l168
  store i32 0, ptr %l170
  %t277 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aJumpKind(ptr %l168, ptr %l170)
  store i1 %t277, ptr %l172
  br label %bb76
bb75:
  br label %bb86
bb76:
  %t278 = load i1, ptr %l172, !tbaa !21
  br i1 %t278, label %bb77, label %bb78
bb77:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/views:Viewer", ptr %t279, i32 0, i32 26
  %t282 = load i64, ptr %l18, !tbaa !24
  %t285 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t281, i64 %t282)
  store ptr %t285, ptr %l176
  br label %bb79
bb78:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/views:Viewer", ptr %t286, i32 0, i32 26
  %t289 = load i64, ptr %l18, !tbaa !24
  %t292 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v0, ptr %t288, i64 %t289)
  store ptr %t292, ptr %l184
  br label %bb82
bb79:
  %t293 = load ptr, ptr %l176, !tbaa !29
  %t295 = getelementptr %"compiler/views:loopFrame", ptr %t293, i32 0, i32 1
  store ptr %t295, ptr %l178, !tbaa !29
  %t296 = load ptr, ptr %l2, !tbaa !29
  %t298 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %v0, ptr %t296)
  store %"compiler/views:state" %t298, ptr %l180
  br label %bb80
bb80:
  %t299 = load ptr, ptr %l178, !tbaa !29
  %t300 = load %"compiler/views:state", ptr %l180
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v0, ptr %t299, %"compiler/views:state" %t300)
  br label %bb81
bb81:
  br label %bb85
bb82:
  %t301 = load ptr, ptr %l184, !tbaa !29
  %t303 = getelementptr %"compiler/views:loopFrame", ptr %t301, i32 0, i32 2
  store ptr %t303, ptr %l186, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %v0, ptr %t304)
  store %"compiler/views:state" %t306, ptr %l188
  br label %bb83
bb83:
  %t307 = load ptr, ptr %l186, !tbaa !29
  %t308 = load %"compiler/views:state", ptr %l188
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v0, ptr %t307, %"compiler/views:state" %t308)
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t309 = load ptr, ptr %l2, !tbaa !29
  %t311 = getelementptr %"compiler/views:state", ptr %t309, i32 0, i32 0
  store i1 true, ptr %t311, !tbaa !21
  br label %bb202
bb87:
  %t312 = load ptr, ptr %l1, !tbaa !29
  store ptr %t312, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t313 = load ptr, ptr %l190, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb88, label %bb89
bb88:
  %t316 = load ptr, ptr %l190, !tbaa !29
  %t317 = load i64, ptr %t316
  %t319 = icmp eq i64 %t317, 6
  store i1 %t319, ptr %l191, !tbaa !21
  br label %bb89
bb89:
  %t320 = load i1, ptr %l191, !tbaa !21
  br i1 %t320, label %bb90, label %bb91
bb90:
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr }, ptr %t323, i32 0, i32 0
  %t325 = load %"compiler/source:Span", ptr %t324
  store %"compiler/source:Span" %t325, ptr %l19
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t329 = getelementptr { i64, [3 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l20, !tbaa !29
  br label %bb92
bb91:
  br label %bb129
bb92:
  store %olang.scope zeroinitializer, ptr %s13
  %t333 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %s13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t333, ptr %l198
  br label %bb93
bb93:
  %t334 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l198
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t334, ptr %l21
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l20, !tbaa !29
  %t337 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s13, ptr %t335, ptr %t336, ptr %t337, ptr %l21)
  br label %bb94
bb94:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/views:Viewer", ptr %t342, i32 0, i32 21
  %t345 = load i1, ptr %t344, !tbaa !21
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb95, label %bb96
bb95:
  store ptr %l21, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb97
bb96:
  br label %bb128
bb97:
  store %olang.scope zeroinitializer, ptr %s16
  %t350 = load ptr, ptr %l22, !tbaa !29
  %t351 = load i64, ptr %l23, !tbaa !24
  %t354 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %s13, ptr %t350, i64 %t351)
  %t355 = extractvalue { i32, { i64, ptr } } %t354, 1
  %t356 = extractvalue { i32, { i64, ptr } } %t354, 0
  store i32 %t356, ptr %l211
  %t357 = icmp ne i32 %t356, 0
  br i1 %t357, label %bb99, label %ok.358
ok.358:
  store { i64, ptr } %t355, ptr %l210
  br label %bb98
bb98:
  %t359 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t359, ptr %l207, !tbaa !27
  br label %bb103
bb99:
  %t360 = load i32, ptr %l211, !tbaa !23
  %t361 = ashr i32 %t360, 16
  %t363 = icmp eq i32 %t361, 1
  br i1 %t363, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @.c81)
  unreachable
bb102:
  call void @__olang_scope_close(ptr %s16)
  br label %bb127
bb103:
  %t365 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t365, ptr %l24, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t366, 0
  store i64 %t368, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s17
  %t370 = load i64, ptr %l26, !tbaa !24
  %t371 = load i64, ptr %l25, !tbaa !24
  %t374 = icmp slt i64 %t370, %t371
  %t376 = xor i1 %t374, true
  br i1 %t376, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s17)
  br label %bb125
bb106:
  br label %bb107
bb107:
  %t378 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t378, ptr %l220, !tbaa !27
  %t379 = load i64, ptr %l26, !tbaa !24
  %t381 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr %"compiler/views:view", ptr %t382, i64 %t379
  %t384 = load %"compiler/views:view", ptr %t383
  store %"compiler/views:view" %t384, ptr %l27
  %t386 = getelementptr %"compiler/views:view", ptr %l27, i32 0, i32 0
  %t387 = getelementptr %"compiler/views:place", ptr %t386, i32 0, i32 0
  %t388 = load { i64, [2 x i64] }, ptr %t387
  store { i64, [2 x i64] } %t388, ptr %l28
  %t390 = load { i64, [2 x i64] }, ptr %l28
  %t392 = extractvalue { i64, [2 x i64] } %t390, 0
  %t393 = icmp eq i64 %t392, 2
  br i1 %t393, label %bb108, label %bb109
bb108:
  %t395 = getelementptr { i64, [2 x i64] }, ptr %l28, i32 0, i32 1
  %t396 = getelementptr { i64 }, ptr %t395, i32 0, i32 0
  %t397 = load i64, ptr %t396
  store i64 %t397, ptr %l29, !tbaa !24
  br label %bb110
bb109:
  br label %bb113
bb110:
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l227, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/views:Viewer", ptr %t400, i32 0, i32 2
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/views:Viewer", ptr %t403, i32 0, i32 20
  %t406 = load i64, ptr %t405, !tbaa !24
  %t409 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t402, i64 %t406)
  store ptr %t409, ptr %l232
  br label %bb111
bb111:
  %t410 = load ptr, ptr %l232, !tbaa !29
  %t412 = getelementptr %"compiler/views:summary", ptr %t410, i32 0, i32 1
  %t413 = load i64, ptr %l29, !tbaa !24
  %t414 = getelementptr %"compiler/views:view", ptr %l27, i32 0, i32 0
  %t415 = load %"compiler/views:place", ptr %t414
  %t416 = load %"compiler/source:Span", ptr %l19
  %t417 = load ptr, ptr %l227, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2efactPut(ptr %v0, ptr %v0, ptr %t417, ptr %t412, i64 %t413, i64 -1, i32 0, %"compiler/views:place" %t415, %"compiler/source:Span" %t416)
  br label %bb112
bb112:
  br label %bb123
bb113:
  %t422 = load { i64, [2 x i64] }, ptr %l28
  %t424 = extractvalue { i64, [2 x i64] } %t422, 0
  %t425 = icmp eq i64 %t424, 4
  br i1 %t425, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load %"compiler/views:view", ptr %l27
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t427, %"compiler/views:view" %t428)
  br label %bb117
bb117:
  br label %bb123
bb118:
  br i1 true, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb123:
  call void @__olang_scope_close(ptr %s17)
  br label %bb124
bb124:
  %t431 = load i64, ptr %l26, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l26, !tbaa !24
  br label %bb104
bb125:
  %t435 = load i64, ptr %l23, !tbaa !24
  %t436 = load i64, ptr %l25, !tbaa !24
  %t439 = add i64 %t435, %t436
  store i64 %t439, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb126
bb126:
  br label %bb97
bb127:
  br label %bb128
bb128:
  %t441 = load ptr, ptr %l2, !tbaa !29
  %t443 = getelementptr %"compiler/views:state", ptr %t441, i32 0, i32 0
  store i1 true, ptr %t443, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb202
bb129:
  %t444 = load ptr, ptr %l1, !tbaa !29
  store ptr %t444, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t445 = load ptr, ptr %l248, !tbaa !29
  %t446 = icmp ne ptr %t445, null
  br i1 %t446, label %bb130, label %bb131
bb130:
  %t448 = load ptr, ptr %l248, !tbaa !29
  %t449 = load i64, ptr %t448
  %t451 = icmp eq i64 %t449, 7
  store i1 %t451, ptr %l249, !tbaa !21
  br label %bb131
bb131:
  %t452 = load i1, ptr %l249, !tbaa !21
  br i1 %t452, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb135
bb134:
  %t453 = load ptr, ptr %l2, !tbaa !29
  %t455 = getelementptr %"compiler/views:state", ptr %t453, i32 0, i32 0
  store i1 true, ptr %t455, !tbaa !21
  br label %bb202
bb135:
  %t456 = load ptr, ptr %l1, !tbaa !29
  store ptr %t456, ptr %l253, !tbaa !29
  store i1 false, ptr %l254, !tbaa !21
  %t457 = load ptr, ptr %l253, !tbaa !29
  %t458 = icmp ne ptr %t457, null
  br i1 %t458, label %bb136, label %bb137
bb136:
  %t460 = load ptr, ptr %l253, !tbaa !29
  %t461 = load i64, ptr %t460
  %t463 = icmp eq i64 %t461, 8
  store i1 %t463, ptr %l254, !tbaa !21
  br label %bb137
bb137:
  %t464 = load i1, ptr %l254, !tbaa !21
  br i1 %t464, label %bb138, label %bb139
bb138:
  %t465 = load ptr, ptr %l1, !tbaa !29
  %t467 = getelementptr { i64, [3 x i64] }, ptr %t465, i32 0, i32 1
  %t468 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t467, i32 0, i32 2
  %t469 = load ptr, ptr %t468
  store ptr %t469, ptr %l30, !tbaa !29
  br label %bb140
bb139:
  br label %bb145
bb140:
  %t471 = load ptr, ptr %l30, !tbaa !29
  %t473 = icmp ne ptr %t471, null
  br i1 %t473, label %bb141, label %bb142
bb141:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l30, !tbaa !29
  %t477 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t475, ptr %t476, ptr %t477, ptr %l3)
  br label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb144
bb144:
  %t482 = load ptr, ptr %l2, !tbaa !29
  %t484 = getelementptr %"compiler/views:state", ptr %t482, i32 0, i32 0
  store i1 true, ptr %t484, !tbaa !21
  br label %bb202
bb145:
  %t485 = load ptr, ptr %l1, !tbaa !29
  store ptr %t485, ptr %l266, !tbaa !29
  store i1 false, ptr %l267, !tbaa !21
  %t486 = load ptr, ptr %l266, !tbaa !29
  %t487 = icmp ne ptr %t486, null
  br i1 %t487, label %bb146, label %bb147
bb146:
  %t489 = load ptr, ptr %l266, !tbaa !29
  %t490 = load i64, ptr %t489
  %t492 = icmp eq i64 %t490, 9
  store i1 %t492, ptr %l267, !tbaa !21
  br label %bb147
bb147:
  %t493 = load i1, ptr %l267, !tbaa !21
  br i1 %t493, label %bb148, label %bb149
bb148:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [3 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t496, i32 0, i32 1
  %t498 = load ptr, ptr %t497
  store ptr %t498, ptr %l31, !tbaa !29
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr { i64, [3 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t502, i32 0, i32 2
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l32, !tbaa !29
  br label %bb150
bb149:
  br label %bb157
bb150:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load ptr, ptr %l31, !tbaa !29
  %t508 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t506, ptr %t507, ptr %t508, ptr %l3)
  br label %bb151
bb151:
  %t513 = load ptr, ptr %l32, !tbaa !29
  %t515 = icmp ne ptr %t513, null
  br i1 %t515, label %bb152, label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s26
  %t517 = load ptr, ptr %l2, !tbaa !29
  %t519 = call %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v2, ptr %s26, ptr %t517)
  store %"compiler/views:state" %t519, ptr %l281
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t520 = load %"compiler/views:state", ptr %l281
  store %"compiler/views:state" %t520, ptr %l33
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %s26, ptr %s0, ptr %t521, ptr %t522, ptr %l33, ptr %l3)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s26)
  br label %bb156
bb156:
  br label %bb202
bb157:
  %t527 = load ptr, ptr %l1, !tbaa !29
  store ptr %t527, ptr %l286, !tbaa !29
  store i1 false, ptr %l287, !tbaa !21
  %t528 = load ptr, ptr %l286, !tbaa !29
  %t529 = icmp ne ptr %t528, null
  br i1 %t529, label %bb158, label %bb159
bb158:
  %t531 = load ptr, ptr %l286, !tbaa !29
  %t532 = load i64, ptr %t531
  %t534 = icmp eq i64 %t532, 10
  store i1 %t534, ptr %l287, !tbaa !21
  br label %bb159
bb159:
  %t535 = load i1, ptr %l287, !tbaa !21
  br i1 %t535, label %bb160, label %bb161
bb160:
  %t536 = load ptr, ptr %l1, !tbaa !29
  %t538 = getelementptr { i64, [3 x i64] }, ptr %t536, i32 0, i32 1
  %t539 = getelementptr { %"compiler/source:Span", ptr }, ptr %t538, i32 0, i32 1
  %t540 = load ptr, ptr %t539
  store ptr %t540, ptr %l34, !tbaa !29
  br label %bb162
bb161:
  br label %bb164
bb162:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load ptr, ptr %l34, !tbaa !29
  %t544 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t542, ptr %t543, ptr %t544)
  br label %bb163
bb163:
  br label %bb202
bb164:
  %t548 = load ptr, ptr %l1, !tbaa !29
  store ptr %t548, ptr %l295, !tbaa !29
  store i1 false, ptr %l296, !tbaa !21
  %t549 = load ptr, ptr %l295, !tbaa !29
  %t550 = icmp ne ptr %t549, null
  br i1 %t550, label %bb165, label %bb166
bb165:
  %t552 = load ptr, ptr %l295, !tbaa !29
  %t553 = load i64, ptr %t552
  %t555 = icmp eq i64 %t553, 11
  store i1 %t555, ptr %l296, !tbaa !21
  br label %bb166
bb166:
  %t556 = load i1, ptr %l296, !tbaa !21
  br i1 %t556, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb202
bb170:
  %t557 = load ptr, ptr %l1, !tbaa !29
  store ptr %t557, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t558 = load ptr, ptr %l299, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb171, label %bb172
bb171:
  %t561 = load ptr, ptr %l299, !tbaa !29
  %t562 = load i64, ptr %t561
  %t564 = icmp eq i64 %t562, 12
  store i1 %t564, ptr %l300, !tbaa !21
  br label %bb172
bb172:
  %t565 = load i1, ptr %l300, !tbaa !21
  br i1 %t565, label %bb173, label %bb174
bb173:
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr { i64, [3 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l35, !tbaa !29
  br label %bb175
bb174:
  br label %bb187
bb175:
  %t572 = load ptr, ptr %l2, !tbaa !29
  %t574 = getelementptr %"compiler/views:state", ptr %t572, i32 0, i32 4
  %t576 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t574)
  store i64 %t576, ptr %l307
  br label %bb176
bb176:
  %t577 = load i64, ptr %l307, !tbaa !24
  store i64 %t577, ptr %l36, !tbaa !24
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load ptr, ptr %l35, !tbaa !29
  %t581 = getelementptr %"compiler/typed:Join", ptr %t579, i32 0, i32 0
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t583 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %t578, ptr %t582, ptr %t583)
  br label %bb177
bb177:
  %t587 = load ptr, ptr %l2, !tbaa !29
  %t589 = getelementptr %"compiler/views:state", ptr %t587, i32 0, i32 0
  %t590 = load i1, ptr %t589, !tbaa !21
  %t592 = xor i1 %t590, true
  br i1 %t592, label %bb178, label %bb179
bb178:
  %t594 = load ptr, ptr %l2, !tbaa !29
  %t596 = getelementptr %"compiler/views:state", ptr %t594, i32 0, i32 4
  %t598 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v2, ptr %t596)
  store i64 %t598, ptr %l318
  br label %bb180
bb179:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb181
bb180:
  %t599 = load i64, ptr %l36, !tbaa !24
  %t600 = load i64, ptr %l318, !tbaa !24
  %t602 = icmp sgt i64 %t600, %t599
  store i1 %t602, ptr %l315, !tbaa !21
  br label %bb181
bb181:
  %t604 = load i1, ptr %l315, !tbaa !21
  br i1 %t604, label %bb182, label %bb183
bb182:
  %t605 = load ptr, ptr %l2, !tbaa !29
  %t607 = getelementptr %"compiler/views:state", ptr %t605, i32 0, i32 4
  %t608 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eTrun_Hcf69da14cf76298bedfa6131a657bae8(ptr %v2, ptr %t607, i64 %t608)
  br label %bb184
bb183:
  br label %bb185
bb184:
  br label %bb185
bb185:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load ptr, ptr %l35, !tbaa !29
  %t614 = getelementptr %"compiler/typed:Join", ptr %t612, i32 0, i32 2
  %t615 = load { i64, ptr }, ptr %t614, !tbaa !27
  %t616 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t611, { i64, ptr } %t615, ptr %t616, ptr %l3)
  br label %bb186
bb186:
  br label %bb202
bb187:
  %t621 = load ptr, ptr %l1, !tbaa !29
  store ptr %t621, ptr %l329, !tbaa !29
  store i1 false, ptr %l330, !tbaa !21
  %t622 = load ptr, ptr %l329, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  br i1 %t623, label %bb188, label %bb189
bb188:
  %t625 = load ptr, ptr %l329, !tbaa !29
  %t626 = load i64, ptr %t625
  %t628 = icmp eq i64 %t626, 13
  store i1 %t628, ptr %l330, !tbaa !21
  br label %bb189
bb189:
  %t629 = load i1, ptr %l330, !tbaa !21
  br i1 %t629, label %bb190, label %bb191
bb190:
  %t630 = load ptr, ptr %l1, !tbaa !29
  %t632 = getelementptr { i64, [3 x i64] }, ptr %t630, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", ptr }, ptr %t632, i32 0, i32 0
  %t634 = load %"compiler/source:Span", ptr %t633
  store %"compiler/source:Span" %t634, ptr %l37
  %t636 = load ptr, ptr %l1, !tbaa !29
  %t638 = getelementptr { i64, [3 x i64] }, ptr %t636, i32 0, i32 1
  %t639 = getelementptr { %"compiler/source:Span", ptr }, ptr %t638, i32 0, i32 1
  %t640 = load ptr, ptr %t639
  store ptr %t640, ptr %l38, !tbaa !29
  br label %bb192
bb191:
  br label %bb194
bb192:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l37
  %t644 = load ptr, ptr %l38, !tbaa !29
  %t645 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2espawn(ptr %v0, ptr %v1, ptr %v2, ptr %t642, %"compiler/source:Span" %t643, ptr %t644, ptr %t645)
  br label %bb193
bb193:
  br label %bb202
bb194:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l341, !tbaa !29
  store i1 false, ptr %l342, !tbaa !21
  %t651 = load ptr, ptr %l341, !tbaa !29
  %t652 = icmp ne ptr %t651, null
  br i1 %t652, label %bb195, label %bb196
bb195:
  %t654 = load ptr, ptr %l341, !tbaa !29
  %t655 = load i64, ptr %t654
  %t657 = icmp eq i64 %t655, 14
  store i1 %t657, ptr %l342, !tbaa !21
  br label %bb196
bb196:
  %t658 = load i1, ptr %l342, !tbaa !21
  br i1 %t658, label %bb197, label %bb198
bb197:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr { i64, [3 x i64] }, ptr %t659, i32 0, i32 1
  %t662 = getelementptr { %"compiler/source:Span", ptr }, ptr %t661, i32 0, i32 1
  %t663 = load ptr, ptr %t662
  store ptr %t663, ptr %l39, !tbaa !29
  br label %bb199
bb198:
  br label %bb201
bb199:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load ptr, ptr %l39, !tbaa !29
  %t667 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t665, ptr %t666, ptr %t667, ptr %l3)
  br label %bb200
bb200:
  br label %bb202
bb201:
  call void @__olang_check_failed(ptr @.c83)
  unreachable
bb202:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/views:holding"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/views:place"
  %l19 = alloca %"compiler/views:view"
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca %"compiler/views:holding"
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i32
  %l73 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, [2 x i64] }
  %l81 = alloca { i64, [2 x i64] }
  %l83 = alloca i1
  %l84 = alloca i1
  %l88 = alloca i1
  %l94 = alloca %"compiler/views:place"
  %l96 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca %"compiler/views:holding"
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca i32
  %l118 = alloca ptr
  %l119 = alloca i1
  %l125 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t148 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l23
  br label %bb2
bb2:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l5
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplacePlaces(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t10, ptr %t11, ptr %t12, ptr %l5)
  br label %bb3
bb3:
  store i64 0, ptr %l6, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/views:state", ptr %t17, i32 0, i32 1
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t19)
  store i64 %t21, ptr %l30
  br label %bb4
bb4:
  %t22 = load i64, ptr %l30, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l37, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l37, !tbaa !24
  store i64 %t49, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb13:
  br label %bb14
bb14:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l11, !tbaa !24
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/views:state", ptr %t69, i32 0, i32 1
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v3, ptr %t71, i64 %t72)
  store %"compiler/views:holding" %t75, ptr %l58
  br label %bb15
bb15:
  %t76 = load %"compiler/views:holding", ptr %l58
  store %"compiler/views:holding" %t76, ptr %l12
  store ptr %l5, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load ptr, ptr %l13, !tbaa !29
  %t79 = load i64, ptr %l14, !tbaa !24
  %t82 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %s0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, { i64, ptr } } %t82, 1
  %t84 = extractvalue { i32, { i64, ptr } } %t82, 0
  store i32 %t84, ptr %l64
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb18, label %ok.86
ok.86:
  store { i64, ptr } %t83, ptr %l63
  br label %bb17
bb17:
  %t87 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t87, ptr %l60, !tbaa !27
  br label %bb22
bb18:
  %t88 = load i32, ptr %l64, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  br i1 %t91, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c84)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb22:
  %t93 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t93, ptr %l15, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l17, !tbaa !24
  %t99 = load i64, ptr %l16, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb25:
  br label %bb26
bb26:
  %t106 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t106, ptr %l73, !tbaa !27
  %t107 = load i64, ptr %l17, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/views:place", ptr %t110, i64 %t107
  %t112 = load %"compiler/views:place", ptr %t111
  store %"compiler/views:place" %t112, ptr %l18
  %t114 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t115 = getelementptr %"compiler/views:view", ptr %t114, i32 0, i32 0
  %t116 = getelementptr %"compiler/views:place", ptr %t115, i32 0, i32 0
  %t117 = load { i64, [2 x i64] }, ptr %t116
  %t119 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t117)
  store i1 %t119, ptr %l77
  br label %bb27
bb27:
  %t120 = load i1, ptr %l77, !tbaa !21
  br i1 %t120, label %bb28, label %bb29
bb28:
  %t121 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t122 = getelementptr %"compiler/views:view", ptr %t121, i32 0, i32 0
  %t123 = getelementptr %"compiler/views:place", ptr %t122, i32 0, i32 0
  %t124 = load { i64, [2 x i64] }, ptr %t123
  store { i64, [2 x i64] } %t124, ptr %l79
  %t125 = getelementptr %"compiler/views:place", ptr %l18, i32 0, i32 0
  %t126 = load { i64, [2 x i64] }, ptr %t125
  store { i64, [2 x i64] } %t126, ptr %l81
  %t129 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %l79, ptr %l81)
  store i1 %t129, ptr %l83
  br label %bb30
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb31
bb30:
  %t130 = load i1, ptr %l83, !tbaa !21
  store i1 %t130, ptr %l78, !tbaa !21
  br label %bb31
bb31:
  %t131 = load i1, ptr %l78, !tbaa !21
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/views:place", ptr %l18, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t136 = getelementptr %"compiler/views:view", ptr %t135, i32 0, i32 0
  %t137 = getelementptr %"compiler/views:place", ptr %t136, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t142 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eprefix(ptr %v0, ptr %t132, i64 %t134, i64 %t138)
  store i1 %t142, ptr %l88
  br label %bb34
bb33:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb35
bb34:
  %t143 = load i1, ptr %l88, !tbaa !21
  store i1 %t143, ptr %l84, !tbaa !21
  br label %bb35
bb35:
  %t144 = load i1, ptr %l84, !tbaa !21
  br i1 %t144, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 1
  %t146 = load %"compiler/views:view", ptr %t145
  store %"compiler/views:view" %t146, ptr %l19
  store { i64, [2 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [2 x i64] }, ptr %t148, i32 0, i32 0
  store i64 0, ptr %t149
  %t150 = load { i64, [2 x i64] }, ptr %t148
  %t151 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t152 = getelementptr %"compiler/views:place", ptr %t151, i32 0, i32 1
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t155 = getelementptr %"compiler/views:place", ptr %t154, i32 0, i32 2
  %t156 = load i64, ptr %t155, !tbaa !24
  %t157 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  %t158 = getelementptr %"compiler/views:place", ptr %t157, i32 0, i32 3
  %t159 = load i1, ptr %t158, !tbaa !21
  %t164 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s6, { i64, [2 x i64] } %t150, i64 %t153, i64 %t156, i1 %t159)
  store %"compiler/views:place" %t164, ptr %l94
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t165 = load %"compiler/views:place", ptr %l94
  %t166 = getelementptr %"compiler/views:view", ptr %l19, i32 0, i32 0
  store %"compiler/views:place" %t165, ptr %t166
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = getelementptr %"compiler/views:state", ptr %t167, i32 0, i32 1
  store ptr %t169, ptr %l96, !tbaa !29
  %t170 = load i64, ptr %l11, !tbaa !24
  store i64 %t170, ptr %l97, !tbaa !24
  %t171 = getelementptr %"compiler/views:holding", ptr %l12, i32 0, i32 0
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = load %"compiler/views:view", ptr %l19
  %t176 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s6, i64 %t172, %"compiler/views:view" %t173)
  store %"compiler/views:holding" %t176, ptr %l100
  br label %bb39
bb39:
  %t177 = load ptr, ptr %l96, !tbaa !29
  %t178 = load i64, ptr %l97, !tbaa !24
  %t179 = load %"compiler/views:holding", ptr %l100
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v3, ptr %t177, i64 %t178, %"compiler/views:holding" %t179)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb23
bb43:
  %t184 = load i64, ptr %l14, !tbaa !24
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = add i64 %t184, %t185
  store i64 %t188, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %bb16
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb46:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l10, !tbaa !24
  br label %bb11
bb47:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = icmp ne ptr %t194, null
  br i1 %t196, label %bb48, label %bb49
bb48:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l110, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l111, !tbaa !29
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t200)
  store i32 %t202, ptr %l113
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t204 = load ptr, ptr %l3, !tbaa !29
  %t205 = load ptr, ptr %l110, !tbaa !29
  %t206 = load ptr, ptr %l111, !tbaa !29
  %t207 = load i32, ptr %l113, !tbaa !23
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ekeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t205, ptr %t206, i32 %t207, ptr %t203, ptr %t204)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t210 = load i64, ptr %l4, !tbaa !24
  %t212 = icmp slt i64 %t210, 0
  br i1 %t212, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  br label %bb55
bb55:
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t215 = load ptr, ptr %l118, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb56, label %bb57
bb56:
  %t218 = load ptr, ptr %l118, !tbaa !29
  %t219 = load i64, ptr %t218
  %t221 = icmp eq i64 %t219, 3
  store i1 %t221, ptr %l119, !tbaa !21
  br label %bb57
bb57:
  %t222 = load i1, ptr %l119, !tbaa !21
  br i1 %t222, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb66
bb60:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t225 = load i64, ptr %l4, !tbaa !24
  %t229 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2enamed(ptr %v0, ptr %v3, ptr %t223, ptr %t224, i64 %t225)
  store i1 %t229, ptr %l125
  br label %bb61
bb61:
  %t230 = load i1, ptr %l125, !tbaa !21
  br i1 %t230, label %bb62, label %bb63
bb62:
  %t231 = load ptr, ptr %l3, !tbaa !29
  %t232 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v3, ptr %t231, i64 %t232)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @.c85)
  unreachable
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/views:Viewer", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t36)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/views:Viewer", ptr %t39, i32 0, i32 4
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l21, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/views:Viewer", ptr %t56, i32 0, i32 3
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load ptr, ptr %l18, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64, i64 %t62)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:Viewer", ptr %t66, i32 0, i32 3
  %t70 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l28
  br label %bb11
bb11:
  %t71 = load i64, ptr %l28, !tbaa !24
  %t72 = sub i64 %t71, 1
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2estructish(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:Viewer", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb2
bb2:
  store i32 18, ptr %l12
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l10, ptr %l12)
  store i1 %t19, ptr %l14
  br label %bb3
bb3:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/views:Viewer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/views:Viewer", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l23
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb6:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l24
  br label %bb7
bb7:
  store i32 0, ptr %l26
  %t42 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %l24, ptr %l26)
  store i1 %t42, ptr %l28
  br label %bb8
bb8:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l15, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecallTok(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t24)
  store %"compiler/source:Span" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t29, ptr %l7
  br label %bb38
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb16
bb11:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 3
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t64 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eplaceTok(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/source:Span" %t64, ptr %l34
  br label %bb17
bb17:
  %t65 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t65, ptr %l7
  br label %bb38
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 5
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l36, !tbaa !21
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Promote", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  store %"compiler/source:Span" %t88, ptr %l44
  br label %bb24
bb24:
  %t89 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t89, ptr %l7
  br label %bb38
bb25:
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i64, ptr %t94
  %t97 = icmp eq i64 %t95, 17
  store i1 %t97, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l6, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etokOf(ptr %v0, ptr %v1, ptr %t105, ptr %t106)
  store %"compiler/source:Span" %t109, ptr %l53
  br label %bb31
bb31:
  %t110 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t110, ptr %l7
  br label %bb38
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t111)
  store %"compiler/source:Span" %t113, ptr %l55
  br label %bb36
bb36:
  %t114 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t114, ptr %l7
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb38:
  %t115 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2euse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/msgs:Msg"
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca { i64, ptr }
  %l46 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l66 = alloca i1
  %l72 = alloca i1
  %l75 = alloca { i64, ptr }
  %l80 = alloca %"compiler/typed:Local"
  %l84 = alloca %"compiler/msgs:Msg"
  %l87 = alloca %"compiler/msgs:Msg"
  %l90 = alloca { i64, ptr }
  %l93 = alloca %"compiler/msgs:Msg"
  %l97 = alloca ptr
  %l100 = alloca { i64, [3 x i64] }
  %l102 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i64
  %l114 = alloca { i64, [3 x i64] }
  %l118 = alloca %"compiler/msgs:Msg"
  %l121 = alloca i1
  %l125 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i64
  %l137 = alloca { i64, [3 x i64] }
  %l139 = alloca %"compiler/msgs:Msg"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t278 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 21
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:Viewer", ptr %t8, i32 0, i32 22
  %t11 = load i1, ptr %t10, !tbaa !21
  store i1 %t11, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 23
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = getelementptr %"compiler/views:state", ptr %a3, i32 0, i32 1
  store ptr %t22, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l31
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb12, label %ok.32
ok.32:
  store { i64, ptr } %t29, ptr %l30
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  br label %bb16
bb12:
  %t34 = load i32, ptr %l31, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @.c87)
  unreachable
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb16:
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb64
bb19:
  br label %bb20
bb20:
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l40, !tbaa !27
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr %"compiler/views:holding", ptr %t56, i64 %t53
  %t58 = load %"compiler/views:holding", ptr %t57
  store %"compiler/views:holding" %t58, ptr %l9
  %t60 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = icmp ne i64 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  %t67 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t68 = getelementptr %"compiler/views:view", ptr %t67, i32 0, i32 2
  %t69 = load i1, ptr %t68, !tbaa !21
  %t71 = xor i1 %t69, true
  store i1 %t71, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l46, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb27
bb25:
  %t74 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t75 = getelementptr %"compiler/views:view", ptr %t74, i32 0, i32 0
  %t76 = getelementptr %"compiler/views:place", ptr %t75, i32 0, i32 0
  %t77 = load { i64, [2 x i64] }, ptr %t76
  %t79 = call i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %t77)
  store i1 %t79, ptr %l51
  br label %bb26
bb26:
  %t80 = load i1, ptr %l51, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l49, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb63
bb29:
  br label %bb30
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/views:Viewer", ptr %t84, i32 0, i32 19
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Body", ptr %t87, i32 0, i32 3
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = shl i64 %t90, 40
  %t93 = load i64, ptr %l1, !tbaa !24
  %t95 = shl i64 %t93, 24
  %t98 = or i64 %t92, %t95
  %t99 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t100 = getelementptr %"compiler/views:view", ptr %t99, i32 0, i32 3
  %t101 = getelementptr %"compiler/source:Span", ptr %t100, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = or i64 %t98, %t104
  store i64 %t107, ptr %l10, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/views:Viewer", ptr %t109, i32 0, i32 29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t111, i64 %t112)
  store i1 %t115, ptr %l66
  br label %bb31
bb31:
  %t116 = load i1, ptr %l66, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb33:
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/views:Viewer", ptr %t117, i32 0, i32 29
  %t120 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t119, i64 %t120, i1 true)
  br label %bb35
bb35:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l2
  %t127 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eseen(ptr %v0, ptr %t123, %"compiler/source:Span" %t124)
  store i1 %t127, ptr %l72
  br label %bb36
bb36:
  %t128 = load i1, ptr %l72, !tbaa !21
  br i1 %t128, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb38:
  br label %bb39
bb39:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t131 = getelementptr %"compiler/views:view", ptr %t130, i32 0, i32 0
  %t132 = load %"compiler/views:place", ptr %t131
  %t135 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %s4, ptr %t129, %"compiler/views:place" %t132)
  store { i64, ptr } %t135, ptr %l75
  br label %bb40
bb40:
  %t136 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t136, ptr %l11, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/views:Viewer", ptr %t137, i32 0, i32 19
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 7
  %t143 = load i64, ptr %l1, !tbaa !24
  %t146 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t142, i64 %t143)
  store %"compiler/typed:Local" %t146, ptr %l80
  br label %bb41
bb41:
  %t147 = getelementptr %"compiler/typed:Local", ptr %l80, i32 0, i32 0
  %t148 = load i32, ptr %t147, !tbaa !23
  store i32 %t148, ptr %l12, !tbaa !23
  %t150 = load i32, ptr %l12, !tbaa !23
  %t152 = icmp eq i32 %t150, 0
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t154 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t158 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t154, { i64, ptr } %t155)
  store %"compiler/msgs:Msg" %t158, ptr %l87
  br label %bb44
bb43:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l12, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l90
  br label %bb45
bb44:
  %t164 = load %"compiler/msgs:Msg", ptr %l87
  store %"compiler/msgs:Msg" %t164, ptr %l84
  br label %bb47
bb45:
  %t165 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t170 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t167, { i64, ptr } %t165, { i64, ptr } %t166)
  store %"compiler/msgs:Msg" %t170, ptr %l93
  br label %bb46
bb46:
  %t171 = load %"compiler/msgs:Msg", ptr %l93
  store %"compiler/msgs:Msg" %t171, ptr %l84
  br label %bb47
bb47:
  %t172 = load %"compiler/msgs:Msg", ptr %l84
  store %"compiler/msgs:Msg" %t172, ptr %l13
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/views:Viewer", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/load:Loader", ptr %t179, i32 0, i32 4
  %t182 = load ptr, ptr %t181, !tbaa !29
  store ptr %t182, ptr %l97, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l2
  %t187 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t183, %"compiler/source:Span" %t184)
  store { i64, [3 x i64] } %t187, ptr %l100
  br label %bb48
bb48:
  %t188 = load %"compiler/msgs:Msg", ptr %l13
  %t189 = load ptr, ptr %l97, !tbaa !29
  %t190 = load { i64, [3 x i64] }, ptr %l100
  %t192 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t189, { i64, [3 x i64] } %t190, %"compiler/msgs:Msg" %t188)
  store i64 %t192, ptr %l102
  br label %bb49
bb49:
  %t193 = load i64, ptr %l102, !tbaa !24
  store i64 %t193, ptr %l14, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/views:Viewer", ptr %t194, i32 0, i32 3
  %t197 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t198 = getelementptr %"compiler/views:view", ptr %t197, i32 0, i32 4
  %t199 = load i64, ptr %t198, !tbaa !24
  %t202 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t196, i64 %t199)
  store { i64, ptr } %t202, ptr %l106
  br label %bb50
bb50:
  %t203 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t203, ptr %l15, !tbaa !27
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/views:Viewer", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = getelementptr %"compiler/generic:Program", ptr %t207, i32 0, i32 0
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/load:Loader", ptr %t210, i32 0, i32 4
  %t213 = load ptr, ptr %t212, !tbaa !29
  store ptr %t213, ptr %l110, !tbaa !29
  %t214 = load i64, ptr %l14, !tbaa !24
  store i64 %t214, ptr %l111, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t217 = getelementptr %"compiler/views:view", ptr %t216, i32 0, i32 3
  %t218 = load %"compiler/source:Span", ptr %t217
  %t221 = call { i64, [3 x i64] } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eat(ptr %v0, ptr %t215, %"compiler/source:Span" %t218)
  store { i64, [3 x i64] } %t221, ptr %l114
  br label %bb51
bb51:
  %t222 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t228 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %s4, ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t222, { i64, ptr } %t223, { i64, ptr } %t224)
  store %"compiler/msgs:Msg" %t228, ptr %l118
  br label %bb52
bb52:
  %t229 = load ptr, ptr %l110, !tbaa !29
  %t230 = load i64, ptr %l111, !tbaa !24
  %t231 = load { i64, [3 x i64] }, ptr %l114
  %t232 = load %"compiler/msgs:Msg", ptr %l118
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t229, i64 %t230, { i64, [3 x i64] } %t231, %"compiler/msgs:Msg" %t232)
  br label %bb53
bb53:
  %t233 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t234 = getelementptr %"compiler/views:view", ptr %t233, i32 0, i32 5
  %t235 = load i64, ptr %t234, !tbaa !24
  %t237 = icmp sge i64 %t235, 0
  br i1 %t237, label %bb54, label %bb55
bb54:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/views:Viewer", ptr %t239, i32 0, i32 6
  %t242 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t243 = getelementptr %"compiler/views:view", ptr %t242, i32 0, i32 5
  %t244 = load i64, ptr %t243, !tbaa !24
  %t247 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t241, i64 %t244)
  store i1 %t247, ptr %l125
  br label %bb56
bb55:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb57
bb56:
  %t248 = load i1, ptr %l125, !tbaa !21
  %t249 = xor i1 %t248, true
  store i1 %t249, ptr %l121, !tbaa !21
  br label %bb57
bb57:
  %t251 = load i1, ptr %l121, !tbaa !21
  br i1 %t251, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/views:Viewer", ptr %t252, i32 0, i32 0
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = getelementptr %"compiler/generic:Program", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = getelementptr %"compiler/load:Loader", ptr %t258, i32 0, i32 4
  %t261 = load ptr, ptr %t260, !tbaa !29
  store ptr %t261, ptr %l130, !tbaa !29
  %t262 = load i64, ptr %l14, !tbaa !24
  store i64 %t262, ptr %l131, !tbaa !24
  %t263 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t264 = getelementptr %"compiler/views:view", ptr %t263, i32 0, i32 5
  %t265 = load i64, ptr %t264, !tbaa !24
  %t266 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t267 = getelementptr %"compiler/views:view", ptr %t266, i32 0, i32 6
  %t268 = getelementptr %"compiler/source:Span", ptr %t267, i32 0, i32 0
  %t269 = load i32, ptr %t268, !tbaa !23
  %t271 = sext i32 %t269 to i64
  %t272 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t273 = getelementptr %"compiler/views:view", ptr %t272, i32 0, i32 6
  %t274 = getelementptr %"compiler/source:Span", ptr %t273, i32 0, i32 1
  %t275 = load i32, ptr %t274, !tbaa !23
  %t277 = sext i32 %t275 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 0
  store i64 3, ptr %t279
  %t281 = insertvalue { i64, i64, i64 } undef, i64 %t265, 0
  %t283 = insertvalue { i64, i64, i64 } %t281, i64 %t271, 1
  %t285 = insertvalue { i64, i64, i64 } %t283, i64 %t277, 2
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 1
  store { i64, i64, i64 } %t285, ptr %t286
  %t287 = load { i64, [3 x i64] }, ptr %t278
  store { i64, [3 x i64] } %t287, ptr %l137
  %t288 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t290 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %s8, { i64, ptr } %t288)
  store %"compiler/msgs:Msg" %t290, ptr %l139
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t291 = load ptr, ptr %l130, !tbaa !29
  %t292 = load i64, ptr %l131, !tbaa !24
  %t293 = load { i64, [3 x i64] }, ptr %l137
  %t294 = load %"compiler/msgs:Msg", ptr %l139
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t291, i64 %t292, { i64, [3 x i64] } %t293, %"compiler/msgs:Msg" %t294)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb63:
  %t295 = load i64, ptr %l8, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l8, !tbaa !24
  br label %bb17
bb64:
  %t299 = load i64, ptr %l5, !tbaa !24
  %t300 = load i64, ptr %l7, !tbaa !24
  %t303 = add i64 %t299, %t300
  store i64 %t303, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb65
bb65:
  br label %bb10
bb66:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l20 = alloca ptr
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca i64
  %l117 = alloca i64
  %l123 = alloca i64
  %l127 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/views:Viewer", ptr %t5, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 %t8)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:Viewer", ptr %t12, i32 0, i32 13
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/views:Viewer", ptr %t16, i32 0, i32 16
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t15, i64 %t19)
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l20, !tbaa !29
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = getelementptr %"compiler/views:Viewer", ptr %t24, i32 0, i32 16
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = add i64 %t26, 1
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/views:Viewer", ptr %t30, i32 0, i32 16
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/views:Viewer", ptr %t32, i32 0, i32 15
  %t35 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/views:Viewer", ptr %t38, i32 0, i32 14
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41, i1 true)
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/views:Viewer", ptr %t44, i32 0, i32 10
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb5
bb5:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 10
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = add i64 %t55, 1
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb6
bb6:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb7, label %bb8
bb7:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb15:
  br label %bb16
bb16:
  %t98 = load i64, ptr %l2, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/views:Viewer", ptr %t108, i32 0, i32 11
  %t114 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t106)
  store i64 %t114, ptr %l65
  br label %bb17
bb17:
  %t115 = load i64, ptr %l65, !tbaa !24
  store i64 %t115, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb21
bb19:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/views:Viewer", ptr %t121, i32 0, i32 12
  %t125 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l72
  br label %bb20
bb20:
  %t126 = load i64, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l72, !tbaa !24
  %t128 = icmp sge i64 %t126, %t127
  store i1 %t128, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l68, !tbaa !21
  br i1 %t130, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/views:Viewer", ptr %t131, i32 0, i32 12
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l77
  br label %bb25
bb25:
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = icmp slt i64 %t138, 0
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2evisit(ptr %v0, ptr %t141, i64 %t142)
  br label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/views:Viewer", ptr %t145, i32 0, i32 14
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t147, i64 %t148)
  store i1 %t151, ptr %l100
  br label %bb36
bb28:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/views:Viewer", ptr %t152, i32 0, i32 13
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l84
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/views:Viewer", ptr %t159, i32 0, i32 13
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l88
  br label %bb30
bb30:
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  br i1 %t168, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/views:Viewer", ptr %t170, i32 0, i32 13
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load i64, ptr %l1, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/views:Viewer", ptr %t174, i32 0, i32 13
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  store i64 %t180, ptr %l96
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t181 = load ptr, ptr %l91, !tbaa !29
  %t182 = load i64, ptr %l92, !tbaa !24
  %t183 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182, i64 %t183)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/views:Viewer", ptr %t185, i32 0, i32 12
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l105
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/views:Viewer", ptr %t192, i32 0, i32 13
  %t195 = load i64, ptr %l1, !tbaa !24
  %t198 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l109
  br label %bb40
bb40:
  %t199 = load i64, ptr %l105, !tbaa !24
  %t200 = load i64, ptr %l109, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  store i1 %t201, ptr %l101, !tbaa !21
  br label %bb41
bb41:
  %t203 = load i1, ptr %l101, !tbaa !21
  br i1 %t203, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/views:Viewer", ptr %t204, i32 0, i32 13
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  store i64 %t207, ptr %l113, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/views:Viewer", ptr %t208, i32 0, i32 12
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l117
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = load i64, ptr %l113, !tbaa !24
  %t217 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216, i64 %t217)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb13
bb49:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/views:Viewer", ptr %t222, i32 0, i32 13
  %t225 = load i64, ptr %l1, !tbaa !24
  %t228 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  store i64 %t228, ptr %l123
  br label %bb50
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/views:Viewer", ptr %t229, i32 0, i32 12
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t232)
  store i64 %t235, ptr %l127
  br label %bb51
bb51:
  %t236 = load i64, ptr %l123, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = icmp eq i64 %t236, %t237
  br i1 %t238, label %bb52, label %bb53
bb52:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/views:Viewer", ptr %t240, i32 0, i32 17
  store ptr %t242, ptr %l130, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/views:Viewer", ptr %t243, i32 0, i32 18
  %t247 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l133
  br label %bb54
bb53:
  br label %bb68
bb54:
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t249 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t248, i64 %t249)
  br label %bb55
bb55:
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/views:Viewer", ptr %t250, i32 0, i32 15
  %t254 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t252)
  %t255 = extractvalue { i32, i64 } %t254, 1
  %t256 = extractvalue { i32, i64 } %t254, 0
  store i32 %t256, ptr %l138
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb58, label %ok.258
ok.258:
  store i64 %t255, ptr %l137
  br label %bb57
bb57:
  %t259 = load i64, ptr %l137, !tbaa !24
  store i64 %t259, ptr %l134, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb60:
  %t260 = load i64, ptr %l134, !tbaa !24
  store i64 %t260, ptr %l9, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/views:Viewer", ptr %t261, i32 0, i32 14
  %t264 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t263, i64 %t264, i1 false)
  br label %bb61
bb61:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/views:Viewer", ptr %t267, i32 0, i32 18
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t269, i64 %t270)
  br label %bb62
bb62:
  %t273 = load i64, ptr %l9, !tbaa !24
  %t274 = load i64, ptr %l1, !tbaa !24
  %t277 = icmp eq i64 %t273, %t274
  br i1 %t277, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb66
bb66:
  br label %bb56
bb67:
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/typed:Local"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/views:state"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"compiler/views:holding"
  %l40 = alloca ptr
  %l47 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l82 = alloca { i64, ptr }
  %l94 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l120 = alloca ptr
  %l124 = alloca i32
  %l129 = alloca %"compiler/views:state"
  %l134 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l162 = alloca i32
  %l164 = alloca ptr
  %l168 = alloca %"compiler/typed:Local"
  %l170 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i64
  %l175 = alloca %"compiler/views:place"
  %l179 = alloca %"compiler/typed:Local"
  %l182 = alloca %"compiler/views:view"
  %l183 = alloca %"compiler/views:holding"
  %l191 = alloca i1
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l212 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca i32
  %l229 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %t279 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:Viewer", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l40
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l40, !tbaa !29
  %t10 = getelementptr %"compiler/views:summary", ptr %t8, i32 0, i32 4
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/views:Viewer", ptr %t15, i32 0, i32 1
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l47
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l47, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/views:Viewer", ptr %t23, i32 0, i32 19
  store ptr %t24, ptr %t27, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = getelementptr %"compiler/views:Viewer", ptr %t28, i32 0, i32 20
  store i64 %t29, ptr %t32, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i1, ptr %l2, !tbaa !21
  %t37 = getelementptr %"compiler/views:Viewer", ptr %t33, i32 0, i32 21
  store i1 %t34, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/views:Viewer", ptr %t38, i32 0, i32 22
  store i1 false, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:Viewer", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %t48, !tbaa !24
  %t52 = icmp eq i64 %t45, %t49
  %t55 = getelementptr %"compiler/views:Viewer", ptr %t41, i32 0, i32 23
  store i1 %t52, ptr %t55, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/views:Viewer", ptr %t56, i32 0, i32 26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H70427050a088bf1a66351c183cb6df24(ptr %v0, ptr %t58)
  br label %bb6
bb6:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/views:Viewer", ptr %t60, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eCl_H0a9e00411db21d32682611ff4a2aedde(ptr %v0, ptr %t62)
  br label %bb7
bb7:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/views:Viewer", ptr %t64, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t66)
  br label %bb8
bb8:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 7
  store ptr %t70, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t73)
  %t77 = extractvalue { i32, { i64, ptr } } %t76, 1
  %t78 = extractvalue { i32, { i64, ptr } } %t76, 0
  store i32 %t78, ptr %l73
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb11, label %ok.80
ok.80:
  store { i64, ptr } %t77, ptr %l72
  br label %bb10
bb10:
  %t81 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t81, ptr %l69, !tbaa !27
  br label %bb15
bb11:
  %t82 = load i32, ptr %l73, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  br i1 %t85, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb15:
  %t87 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t87, ptr %l6, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t100, ptr %l82, !tbaa !27
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/typed:Local", ptr %t104, i64 %t101
  %t106 = load %"compiler/typed:Local", ptr %t105
  store %"compiler/typed:Local" %t106, ptr %l9
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/views:Viewer", ptr %t108, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t110, i64 -1)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t112 = load i64, ptr %l8, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l8, !tbaa !24
  br label %bb16
bb22:
  %t116 = load i64, ptr %l5, !tbaa !24
  %t117 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t116, %t117
  store i64 %t120, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb9
bb24:
  store i64 0, ptr %l10, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Body", ptr %t122, i32 0, i32 5
  %t126 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t124)
  store i64 %t126, ptr %l94
  br label %bb25
bb25:
  %t127 = load i64, ptr %l94, !tbaa !24
  store i64 %t127, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb26, label %bb27
bb26:
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb31
bb28:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb30
bb30:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb31
bb31:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t156 = load i64, ptr %l14, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t165 = load i64, ptr %l14, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l15, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/views:Viewer", ptr %t174, i32 0, i32 25
  store ptr %t176, ptr %l120, !tbaa !29
  %t177 = load ptr, ptr %l3, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Body", ptr %t177, i32 0, i32 5
  %t180 = load i64, ptr %l15, !tbaa !24
  %t183 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t179, i64 %t180)
  store i32 %t183, ptr %l124
  br label %bb36
bb36:
  %t184 = load i32, ptr %l124, !tbaa !23
  %t185 = sext i32 %t184 to i64
  %t186 = load i64, ptr %l15, !tbaa !24
  %t187 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t185, i64 %t186)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  %t190 = load i64, ptr %l14, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l14, !tbaa !24
  br label %bb32
bb39:
  %t194 = call %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %s0)
  store %"compiler/views:state" %t194, ptr %l129
  br label %bb40
bb40:
  %t195 = load %"compiler/views:state", ptr %l129
  store %"compiler/views:state" %t195, ptr %l16
  %t196 = load i1, ptr %l2, !tbaa !21
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb41, label %bb42
bb41:
  store i64 0, ptr %l17, !tbaa !24
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Body", ptr %t200, i32 0, i32 5
  %t204 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t202)
  store i64 %t204, ptr %l134
  br label %bb43
bb42:
  br label %bb67
bb43:
  %t205 = load i64, ptr %l134, !tbaa !24
  store i64 %t205, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t206 = load i64, ptr %l18, !tbaa !24
  %t207 = load i64, ptr %l17, !tbaa !24
  %t210 = icmp sgt i64 %t206, %t207
  br i1 %t210, label %bb44, label %bb45
bb44:
  %t212 = load i64, ptr %l19, !tbaa !24
  %t214 = icmp sgt i64 %t212, 0
  br i1 %t214, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb49
bb46:
  %t216 = load i64, ptr %l18, !tbaa !24
  %t217 = load i64, ptr %l17, !tbaa !24
  %t220 = sub i64 %t216, %t217
  %t221 = load i64, ptr %l19, !tbaa !24
  %t224 = add i64 %t220, %t221
  %t226 = sub i64 %t224, 1
  %t227 = load i64, ptr %l19, !tbaa !24
  %t230 = sdiv i64 %t226, %t227
  store i64 %t230, ptr %l141, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb48
bb48:
  %t232 = load i64, ptr %l141, !tbaa !24
  store i64 %t232, ptr %l138, !tbaa !24
  br label %bb49
bb49:
  %t233 = load i64, ptr %l138, !tbaa !24
  store i64 %t233, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t234 = load i64, ptr %l21, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb52:
  br label %bb53
bb53:
  %t242 = load i64, ptr %l17, !tbaa !24
  %t243 = load i64, ptr %l21, !tbaa !24
  %t244 = load i64, ptr %l19, !tbaa !24
  %t247 = mul i64 %t243, %t244
  %t250 = add i64 %t242, %t247
  store i64 %t250, ptr %l22, !tbaa !24
  %t252 = load ptr, ptr %l3, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Body", ptr %t252, i32 0, i32 5
  %t255 = load i64, ptr %l22, !tbaa !24
  %t258 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t254, i64 %t255)
  store i32 %t258, ptr %l162
  br label %bb54
bb54:
  %t259 = load i32, ptr %l162, !tbaa !23
  %t260 = sext i32 %t259 to i64
  store i64 %t260, ptr %l23, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l164, !tbaa !29
  %t263 = load ptr, ptr %l3, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 7
  %t266 = load i64, ptr %l23, !tbaa !24
  %t269 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t265, i64 %t266)
  store %"compiler/typed:Local" %t269, ptr %l168
  br label %bb55
bb55:
  %t270 = getelementptr %"compiler/typed:Local", ptr %l168, i32 0, i32 2
  %t271 = load i32, ptr %t270, !tbaa !23
  %t272 = load ptr, ptr %l164, !tbaa !29
  %t274 = call i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ecarries(ptr %v0, ptr %t272, i32 %t271)
  store i1 %t274, ptr %l170
  br label %bb56
bb56:
  %t275 = load i1, ptr %l170, !tbaa !21
  br i1 %t275, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  %t276 = getelementptr %"compiler/views:state", ptr %l16, i32 0, i32 1
  store ptr %t276, ptr %l171, !tbaa !29
  %t277 = load i64, ptr %l23, !tbaa !24
  store i64 %t277, ptr %l172, !tbaa !24
  %t278 = load i64, ptr %l22, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [2 x i64] }, ptr %t279, i32 0, i32 0
  store i64 4, ptr %t280
  %t282 = insertvalue { i64 } undef, i64 %t278, 0
  %t283 = getelementptr { i64, [2 x i64] }, ptr %t279, i32 0, i32 1
  store { i64 } %t282, ptr %t283
  %t284 = load { i64, [2 x i64] }, ptr %t279
  %t286 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s12, { i64, [2 x i64] } %t284, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t286, ptr %l175
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Body", ptr %t287, i32 0, i32 7
  %t290 = load i64, ptr %l23, !tbaa !24
  %t293 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t289, i64 %t290)
  store %"compiler/typed:Local" %t293, ptr %l179
  br label %bb60
bb60:
  %t294 = getelementptr %"compiler/typed:Local", ptr %l179, i32 0, i32 1
  %t295 = getelementptr %"compiler/source:Span", ptr %t294, i32 0, i32 0
  %t296 = load i32, ptr %t295, !tbaa !23
  %t298 = sext i32 %t296 to i64
  %t299 = load %"compiler/views:place", ptr %l175
  %t301 = call %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %s12, %"compiler/views:place" %t299, i64 %t298)
  store %"compiler/views:view" %t301, ptr %l182
  br label %bb61
bb61:
  %t302 = load i64, ptr %l172, !tbaa !24
  %t303 = load %"compiler/views:view", ptr %l182
  %t304 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s12, i64 %t302, %"compiler/views:view" %t303)
  store %"compiler/views:holding" %t304, ptr %l183
  br label %bb62
bb62:
  %t305 = load ptr, ptr %l171, !tbaa !29
  %t306 = load %"compiler/views:holding", ptr %l183
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %s0, ptr %t305, %"compiler/views:holding" %t306)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t307 = load i64, ptr %l21, !tbaa !24
  %t309 = add i64 %t307, 1
  store i64 %t309, ptr %l21, !tbaa !24
  br label %bb50
bb66:
  br label %bb67
bb67:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l3, !tbaa !29
  %t314 = getelementptr %"compiler/typed:Body", ptr %t312, i32 0, i32 11
  %t315 = load ptr, ptr %t314, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2eblock(ptr %v0, ptr %v0, ptr %s0, ptr %t311, ptr %t315, ptr %l16)
  br label %bb68
bb68:
  %t319 = load i1, ptr %l2, !tbaa !21
  br i1 %t319, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb71
bb70:
  %t321 = getelementptr %"compiler/views:state", ptr %l16, i32 0, i32 0
  %t322 = load i1, ptr %t321, !tbaa !21
  store i1 %t322, ptr %l191, !tbaa !21
  br label %bb71
bb71:
  %t324 = load i1, ptr %l191, !tbaa !21
  br i1 %t324, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb73:
  br label %bb74
bb74:
  %t325 = load ptr, ptr %l3, !tbaa !29
  %t327 = getelementptr %"compiler/typed:Body", ptr %t325, i32 0, i32 1
  %t328 = load { i64, [2 x i64] }, ptr %t327
  %t332 = extractvalue { i64, [2 x i64] } %t328, 0
  %t333 = icmp eq i64 %t332, 1
  br i1 %t333, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb112
bb77:
  %t335 = load ptr, ptr %l3, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Body", ptr %t335, i32 0, i32 10
  store ptr %t337, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s17
  %t339 = load ptr, ptr %l25, !tbaa !29
  %t340 = load i64, ptr %l26, !tbaa !24
  %t343 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t339, i64 %t340)
  %t344 = extractvalue { i32, { i64, ptr } } %t343, 1
  %t345 = extractvalue { i32, { i64, ptr } } %t343, 0
  store i32 %t345, ptr %l203
  %t346 = icmp ne i32 %t345, 0
  br i1 %t346, label %bb80, label %ok.347
ok.347:
  store { i64, ptr } %t344, ptr %l202
  br label %bb79
bb79:
  %t348 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t348, ptr %l199, !tbaa !27
  br label %bb84
bb80:
  %t349 = load i32, ptr %l203, !tbaa !23
  %t350 = ashr i32 %t349, 16
  %t352 = icmp eq i32 %t350, 1
  br i1 %t352, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @.c89)
  unreachable
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb84:
  %t354 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t354, ptr %l27, !tbaa !27
  %t355 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 0
  store i64 %t357, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s18
  %t359 = load i64, ptr %l29, !tbaa !24
  %t360 = load i64, ptr %l28, !tbaa !24
  %t363 = icmp slt i64 %t359, %t360
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb87:
  br label %bb88
bb88:
  %t367 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t367, ptr %l212, !tbaa !27
  %t368 = load i64, ptr %l29, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i32, ptr %t371, i64 %t368
  %t373 = load i32, ptr %t372, !tbaa !33
  store i32 %t373, ptr %l30, !tbaa !23
  %t375 = getelementptr %"compiler/views:state", ptr %l16, i32 0, i32 1
  store ptr %t375, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s20
  %t377 = load ptr, ptr %l31, !tbaa !29
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %s0, ptr %t377, i64 %t378)
  %t382 = extractvalue { i32, { i64, ptr } } %t381, 1
  %t383 = extractvalue { i32, { i64, ptr } } %t381, 0
  store i32 %t383, ptr %l220
  %t384 = icmp ne i32 %t383, 0
  br i1 %t384, label %bb91, label %ok.385
ok.385:
  store { i64, ptr } %t382, ptr %l219
  br label %bb90
bb90:
  %t386 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t386, ptr %l216, !tbaa !27
  br label %bb95
bb91:
  %t387 = load i32, ptr %l220, !tbaa !23
  %t388 = ashr i32 %t387, 16
  %t390 = icmp eq i32 %t388, 1
  br i1 %t390, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb94:
  call void @__olang_scope_close(ptr %s20)
  br label %bb107
bb95:
  %t392 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t392, ptr %l33, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t393, 0
  store i64 %t395, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s21
  %t397 = load i64, ptr %l35, !tbaa !24
  %t398 = load i64, ptr %l34, !tbaa !24
  %t401 = icmp slt i64 %t397, %t398
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb105
bb98:
  br label %bb99
bb99:
  %t405 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t405, ptr %l229, !tbaa !27
  %t406 = load i64, ptr %l35, !tbaa !24
  %t408 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr %"compiler/views:holding", ptr %t409, i64 %t406
  %t411 = load %"compiler/views:holding", ptr %t410
  store %"compiler/views:holding" %t411, ptr %l36
  %t413 = getelementptr %"compiler/views:holding", ptr %l36, i32 0, i32 0
  %t414 = load i64, ptr %t413, !tbaa !24
  %t415 = load i32, ptr %l30, !tbaa !23
  %t417 = sext i32 %t415 to i64
  %t420 = icmp eq i64 %t414, %t417
  br i1 %t420, label %bb100, label %bb101
bb100:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/views:holding", ptr %l36, i32 0, i32 1
  %t424 = load %"compiler/views:view", ptr %t423
  call void @compiler_2fviews_2ecompiler_2fviews_3aViewer_2epasses(ptr %v0, ptr %t422, %"compiler/views:view" %t424)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb104:
  %t427 = load i64, ptr %l35, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l35, !tbaa !24
  br label %bb96
bb105:
  %t431 = load i64, ptr %l32, !tbaa !24
  %t432 = load i64, ptr %l34, !tbaa !24
  %t435 = add i64 %t431, %t432
  store i64 %t435, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb106
bb106:
  br label %bb89
bb107:
  call void @__olang_scope_close(ptr %s18)
  br label %bb108
bb108:
  %t437 = load i64, ptr %l29, !tbaa !24
  %t439 = add i64 %t437, 1
  store i64 %t439, ptr %l29, !tbaa !24
  br label %bb85
bb109:
  %t441 = load i64, ptr %l26, !tbaa !24
  %t442 = load i64, ptr %l28, !tbaa !24
  %t445 = add i64 %t441, %t442
  store i64 %t445, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb110
bb110:
  br label %bb78
bb111:
  br label %bb117
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb117:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewalkable(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/typed:Local"
  %l13 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l38 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/views:Viewer", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t24 = extractvalue { i64, [2 x i64] } %t20, 0
  %t25 = icmp eq i64 %t24, 7
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c92)
  unreachable
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 7
  store ptr %t30, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t32, i64 %t33)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l29
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb16, label %ok.40
ok.40:
  store { i64, ptr } %t37, ptr %l28
  br label %bb15
bb15:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  br label %bb20
bb16:
  %t42 = load i32, ptr %l29, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c93)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb20:
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr %"compiler/typed:Local", ptr %t64, i64 %t61
  %t66 = load %"compiler/typed:Local", ptr %t65
  store %"compiler/typed:Local" %t66, ptr %l9
  %t68 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp eq i32 %t69, %t70
  br i1 %t73, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb21
bb29:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t80, %t81
  store i64 %t84, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  br label %bb14
bb31:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2ewhere(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l19 = alloca %"compiler/typed:Local"
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca %"compiler/typed:Local"
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l60 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:Viewer", ptr %t14, i32 0, i32 19
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 7
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/typed:Local" %t23, ptr %l19
  br label %bb4
bb4:
  %t24 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t26, i32 %t25)
  store { i64, ptr } %t28, ptr %l21
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l10, !tbaa !27
  br label %bb23
bb6:
  %t36 = load { i64, [2 x i64] }, ptr %l2
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t42 = getelementptr { i64 }, ptr %t41, i32 0, i32 0
  %t43 = load i64, ptr %t42
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/views:Viewer", ptr %t46, i32 0, i32 19
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 7
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/views:Viewer", ptr %t52, i32 0, i32 19
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 5
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t57, i64 %t58)
  store i32 %t61, ptr %l34
  br label %bb10
bb10:
  %t62 = load i32, ptr %l34, !tbaa !23
  %t63 = sext i32 %t62 to i64
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t66 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64, i64 %t63)
  store %"compiler/typed:Local" %t66, ptr %l36
  br label %bb11
bb11:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l36, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t69, i32 %t68)
  store { i64, ptr } %t71, ptr %l38
  br label %bb12
bb12:
  %t72 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t73, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  br label %bb23
bb13:
  %t79 = load { i64, [2 x i64] }, ptr %l2
  %t81 = extractvalue { i64, [2 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 3
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t85 = getelementptr { i64, i32 }, ptr %t84, i32 0, i32 1
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l5, !tbaa !23
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l5, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fviews_2ecompiler_2fviews_3aViewer_2etext(ptr %v0, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l45
  br label %bb17
bb17:
  %t93 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t94, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l10, !tbaa !27
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store { i64, ptr } { i64 1, ptr @.d94 }, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t100, ptr %l10, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb23:
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %l6, !tbaa !27
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/views:Viewer", ptr %t103, i32 0, i32 3
  %t106 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  %t110 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t105, i64 %t107)
  store { i64, ptr } %t110, ptr %l52
  br label %bb24
bb24:
  %t111 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t111, ptr %l7, !tbaa !27
  %t112 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = icmp sge i64 %t113, 0
  br i1 %t115, label %bb25, label %bb26
bb25:
  %t117 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp sle i64 %t118, %t121
  store i1 %t124, ptr %l55, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb27
bb27:
  %t126 = load i1, ptr %l55, !tbaa !21
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t127 = getelementptr %"compiler/views:place", ptr %l1, i32 0, i32 2
  %t128 = load i64, ptr %t127, !tbaa !24
  store i64 %t128, ptr %l60, !tbaa !24
  br label %bb30
bb29:
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l60, !tbaa !24
  br label %bb30
bb30:
  %t134 = load i64, ptr %l60, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t135, ptr %l64, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t136, ptr %l65, !tbaa !27
  store i64 %t134, ptr %l66, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l67, !tbaa !24
  %t140 = icmp sge i64 0, 0
  br i1 %t140, label %bb31, label %bb32
bb31:
  %t142 = load i64, ptr %l66, !tbaa !24
  %t143 = icmp sle i64 0, %t142
  br i1 %t143, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb33:
  %t145 = load i64, ptr %l66, !tbaa !24
  %t146 = load i64, ptr %l67, !tbaa !24
  %t147 = icmp sle i64 %t145, %t146
  br i1 %t147, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb35:
  %t149 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = load i64, ptr %l66, !tbaa !24
  %t152 = getelementptr i8, ptr %t150, i64 0
  %t153 = sub i64 %t151, 0
  %t154 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t152, 1
  %t156 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t157, i64 %t158)
  %t164 = getelementptr i8, ptr %t163, i64 %t158
  call void @olang_textcopy(ptr %t164, ptr %t160, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t166, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/views:state" @compiler_2fviews_2ecompiler_2fviews_3astate_2ecopy(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/views:state"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:state"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %v1)
  store %"compiler/views:state" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/views:state", ptr %l2
  %t4 = load ptr, ptr %lp1
  store %"compiler/views:state" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = load ptr, ptr %lp1
  %t11 = getelementptr %"compiler/views:state", ptr %t10, i32 0, i32 0
  store i1 %t8, ptr %t11, !tbaa !21
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/views:state", ptr %t12, i32 0, i32 1
  %t16 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v0, ptr %v1, ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l7
  br label %bb2
bb2:
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t18 = load ptr, ptr %lp1
  %t19 = getelementptr %"compiler/views:state", ptr %t18, i32 0, i32 1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/views:state", ptr %t20, i32 0, i32 2
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %v1, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l10
  br label %bb3
bb3:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t26 = load ptr, ptr %lp1
  %t27 = getelementptr %"compiler/views:state", ptr %t26, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:state", ptr %t28, i32 0, i32 3
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l13
  br label %bb4
bb4:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t34 = load ptr, ptr %lp1
  %t35 = getelementptr %"compiler/views:state", ptr %t34, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t35
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/views:state", ptr %t36, i32 0, i32 4
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eClone_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %v1, ptr %t38)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l16
  br label %bb5
bb5:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t42 = load ptr, ptr %lp1
  %t43 = getelementptr %"compiler/views:state", ptr %t42, i32 0, i32 4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %t43
  %t44 = load ptr, ptr %lp1
  %t45 = load %"compiler/views:state", ptr %t44
  store %"compiler/views:state" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:state", ptr %rv
  ret %"compiler/views:state" %rr
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eforget(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:holding"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 1
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v0, ptr %s0, ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eCle_Ha50b8ef86adef4ee8ec69eed192d557f(ptr %v0, ptr %t9)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %s0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l19
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l18
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  br label %bb9
bb5:
  %t22 = load i32, ptr %l19, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c97)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l28, !tbaa !27
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/views:holding", ptr %t44, i64 %t41
  %t46 = load %"compiler/views:holding", ptr %t45
  store %"compiler/views:holding" %t46, ptr %l8
  %t48 = getelementptr %"compiler/views:holding", ptr %l8, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = icmp ne i64 %t49, %t50
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 1
  %t58 = load %"compiler/views:holding", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %v0, ptr %t57, %"compiler/views:holding" %t58)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb10
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb3
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v0, ptr %t71, i64 %t72)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/views:state", ptr %t2, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  %t8 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  store i1 %t5, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/views:state", ptr %t10, i32 0, i32 1
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v1, ptr %v0, ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr %"compiler/views:state", ptr %t16, i32 0, i32 1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %t17
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/views:state", ptr %t19, i32 0, i32 2
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v1, ptr %v0, ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l12
  br label %bb2
bb2:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t25 = load ptr, ptr %l9, !tbaa !29
  %t26 = getelementptr %"compiler/views:state", ptr %t25, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %t26
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/views:state", ptr %t28, i32 0, i32 3
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v1, ptr %v0, ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l16
  br label %bb3
bb3:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = getelementptr %"compiler/views:state", ptr %t34, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t35
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/views:state", ptr %t37, i32 0, i32 4
  %t41 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eClone_3ccompiler_2fviews_3atasked_3e(ptr %v1, ptr %v0, ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l20
  br label %bb4
bb4:
  %t42 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"compiler/views:state", ptr %t43, i32 0, i32 4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t44
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2ecompiler_2fviews_3astate_2eunname(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:naming"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l35 = alloca { i64, ptr }
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 2
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %s0, ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClear_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t9)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %s0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l26
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l25
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t21, ptr %l22, !tbaa !27
  br label %bb9
bb5:
  %t22 = load i32, ptr %l26, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  %t27 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l35, !tbaa !27
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/views:naming", ptr %t44, i64 %t41
  %t46 = load %"compiler/views:naming", ptr %t45
  store %"compiler/views:naming" %t46, ptr %l8
  %t48 = getelementptr %"compiler/views:naming", ptr %l8, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = icmp ne i64 %t49, %t50
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/views:state", ptr %t55, i32 0, i32 2
  %t58 = load %"compiler/views:naming", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t57, %"compiler/views:naming" %t58)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb10
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb3
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/views:state", ptr %t71, i32 0, i32 3
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %s0, ptr %t73)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l51
  br label %bb22
bb22:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l9
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/views:state", ptr %t77, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t79)
  br label %bb23
bb23:
  store ptr %l9, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load ptr, ptr %l10, !tbaa !29
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t82, i64 %t83)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l59
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb26, label %ok.90
ok.90:
  store { i64, ptr } %t87, ptr %l58
  br label %bb25
bb25:
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t91, ptr %l55, !tbaa !27
  br label %bb30
bb26:
  %t92 = load i32, ptr %l59, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  br i1 %t95, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c99)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb30:
  %t97 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t97, ptr %l12, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t102 = load i64, ptr %l14, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb33:
  br label %bb34
bb34:
  %t110 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t110, ptr %l68, !tbaa !27
  %t111 = load i64, ptr %l14, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i64, ptr %t114, i64 %t111
  %t116 = load i64, ptr %t115, !tbaa !34
  store i64 %t116, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = icmp ne i64 %t118, %t119
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/views:state", ptr %t124, i32 0, i32 3
  %t127 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t126, i64 %t127)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb39:
  %t130 = load i64, ptr %l14, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l14, !tbaa !24
  br label %bb31
bb40:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %bb24
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/views:state" @compiler_2fviews_2edead(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca %"compiler/views:state"
  %rv = alloca %"compiler/views:state"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %v0)
  store %"compiler/views:state" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"compiler/views:state", ptr %l1
  %t4 = load ptr, ptr %lp0
  store %"compiler/views:state" %t3, ptr %t4
  %t5 = load ptr, ptr %lp0
  %t6 = getelementptr %"compiler/views:state", ptr %t5, i32 0, i32 0
  store i1 true, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %lp0
  %t8 = load %"compiler/views:state", ptr %t7
  store %"compiler/views:state" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:state", ptr %rv
  ret %"compiler/views:state" %rr
}

define dso_local i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/source:Span", ptr %t34
  store %"compiler/source:Span" %t35, ptr %l1
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i64 @compiler_2fviews_2eplaceEnd(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l22
  br label %bb10
bb10:
  %t46 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t50 = load i64, ptr %l22, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t50, i64 %t49)
  store i64 %t52, ptr %l25
  br label %bb11
bb11:
  %t53 = load i64, ptr %l25, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb25
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l26, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 17
  store i1 %t61, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l33
  br label %bb18
bb18:
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t73)
  store %"compiler/source:Span" %t75, ptr %l35
  br label %bb23
bb23:
  %t76 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb25:
  %t81 = load i64, ptr %l4, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2eholdAdd(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:view" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/views:view"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/views:holding"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca %"compiler/views:holding"
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca %"compiler/views:place"
  %l51 = alloca %"compiler/views:place"
  %l53 = alloca i1
  %l56 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca %"compiler/views:holding"
  %l70 = alloca ptr
  %l73 = alloca %"compiler/views:holding"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/views:view" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/views:state", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/views:holding" %t59, ptr %l40
  br label %bb12
bb12:
  %t60 = load %"compiler/views:holding", ptr %l40
  store %"compiler/views:holding" %t60, ptr %l9
  %t61 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb15
bb14:
  %t68 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t69 = getelementptr %"compiler/views:view", ptr %t68, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = icmp ne i64 %t70, %t72
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb17:
  %t78 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t79 = getelementptr %"compiler/views:view", ptr %t78, i32 0, i32 0
  %t80 = load %"compiler/views:place", ptr %t79
  store %"compiler/views:place" %t80, ptr %l49
  %t81 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 0
  %t82 = load %"compiler/views:place", ptr %t81
  store %"compiler/views:place" %t82, ptr %l51
  %t85 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l49, ptr %l51)
  store i1 %t85, ptr %l53
  br label %bb18
bb18:
  %t86 = load i1, ptr %l53, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb21:
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/views:view", ptr %l2, i32 0, i32 2
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = getelementptr %"compiler/views:holding", ptr %l9, i32 0, i32 1
  %t94 = getelementptr %"compiler/views:view", ptr %t93, i32 0, i32 2
  %t95 = load i1, ptr %t94, !tbaa !21
  %t97 = xor i1 %t95, true
  store i1 %t97, ptr %l56, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l56, !tbaa !21
  br i1 %t99, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/views:state", ptr %t100, i32 0, i32 1
  store ptr %t102, ptr %l60, !tbaa !29
  %t103 = load i64, ptr %l8, !tbaa !24
  store i64 %t103, ptr %l61, !tbaa !24
  %t104 = load i64, ptr %l1, !tbaa !24
  %t105 = load %"compiler/views:view", ptr %l2
  %t108 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s4, i64 %t104, %"compiler/views:view" %t105)
  store %"compiler/views:holding" %t108, ptr %l64
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = load i64, ptr %l61, !tbaa !24
  %t111 = load %"compiler/views:holding", ptr %l64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v0, ptr %t109, i64 %t110, %"compiler/views:holding" %t111)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb8
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/views:state", ptr %t118, i32 0, i32 1
  store ptr %t120, ptr %l70, !tbaa !29
  %t121 = load i64, ptr %l1, !tbaa !24
  %t122 = load %"compiler/views:view", ptr %l2
  %t125 = call %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %s0, i64 %t121, %"compiler/views:view" %t122)
  store %"compiler/views:holding" %t125, ptr %l73
  br label %bb33
bb33:
  %t126 = load ptr, ptr %l70, !tbaa !29
  %t127 = load %"compiler/views:holding", ptr %l73
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %v0, ptr %t126, %"compiler/views:holding" %t127)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fviews_2emerge(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/views:holding"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/views:holding"
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca %"compiler/views:naming"
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca %"compiler/views:tasked"
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca %"compiler/views:tasked"
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i1
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l106 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l131 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l149 = alloca { i64, ptr }
  %l161 = alloca i1
  %l165 = alloca i1
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l188 = alloca { i64, ptr }
  %l195 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca %"compiler/views:place"
  %l206 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca i64
  %l212 = alloca %"compiler/views:place"
  %l215 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l219 = alloca i32
  %l228 = alloca { i64, ptr }
  %l246 = alloca i1
  %l258 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l262 = alloca i32
  %l271 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca i32
  %l289 = alloca { i64, ptr }
  %l295 = alloca i1
  %l296 = alloca %"compiler/source:Span"
  %l298 = alloca %"compiler/source:Span"
  %l300 = alloca i1
  %l301 = alloca i1
  %l302 = alloca %"compiler/views:place"
  %l304 = alloca %"compiler/views:place"
  %l306 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %t304 = alloca { i64, [2 x i64] }, align 8
  %t330 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/views:state", ptr %t6, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fviews_2ecompiler_2fviews_3astate_2eset(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/views:state", ptr %t15, i32 0, i32 1
  store ptr %t17, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t19, i64 %t20)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l69
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb10, label %ok.27
ok.27:
  store { i64, ptr } %t24, ptr %l68
  br label %bb9
bb9:
  %t28 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t28, ptr %l65, !tbaa !27
  br label %bb14
bb10:
  %t29 = load i32, ptr %l69, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c101)
  unreachable
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb14:
  %t34 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t47, ptr %l78, !tbaa !27
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/views:holding", ptr %t51, i64 %t48
  %t53 = load %"compiler/views:holding", ptr %t52
  store %"compiler/views:holding" %t53, ptr %l7
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/views:holding", ptr %l7, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = getelementptr %"compiler/views:holding", ptr %l7, i32 0, i32 1
  %t59 = load %"compiler/views:view", ptr %t58
  %t63 = call i1 @compiler_2fviews_2eholdAdd(ptr %v0, ptr %t55, i64 %t57, %"compiler/views:view" %t59)
  store i1 %t63, ptr %l84
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb15
bb21:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = add i64 %t68, %t69
  store i64 %t72, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb8
bb23:
  %t74 = load ptr, ptr @__olang_prog_scope
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t74)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l90
  br label %bb24
bb24:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l8
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/views:state", ptr %t77, i32 0, i32 3
  store ptr %t79, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t81, i64 %t82)
  %t86 = extractvalue { i32, { i64, ptr } } %t85, 1
  %t87 = extractvalue { i32, { i64, ptr } } %t85, 0
  store i32 %t87, ptr %l97
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb27, label %ok.89
ok.89:
  store { i64, ptr } %t86, ptr %l96
  br label %bb26
bb26:
  %t90 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t90, ptr %l93, !tbaa !27
  br label %bb31
bb27:
  %t91 = load i32, ptr %l97, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  br i1 %t94, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @.c102)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb31:
  %t96 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t96, ptr %l11, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t101 = load i64, ptr %l13, !tbaa !24
  %t102 = load i64, ptr %l12, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t109 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t109, ptr %l106, !tbaa !27
  %t110 = load i64, ptr %l13, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i64, ptr %t113, i64 %t110
  %t115 = load i64, ptr %t114, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t115)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l13, !tbaa !24
  br label %bb32
bb38:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l12, !tbaa !24
  %t128 = add i64 %t124, %t125
  store i64 %t128, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb39:
  br label %bb25
bb40:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/views:state", ptr %t130, i32 0, i32 3
  store ptr %t132, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t134 = load ptr, ptr %l15, !tbaa !29
  %t135 = load i64, ptr %l16, !tbaa !24
  %t138 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t134, i64 %t135)
  %t139 = extractvalue { i32, { i64, ptr } } %t138, 1
  %t140 = extractvalue { i32, { i64, ptr } } %t138, 0
  store i32 %t140, ptr %l122
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb43, label %ok.142
ok.142:
  store { i64, ptr } %t139, ptr %l121
  br label %bb42
bb42:
  %t143 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t143, ptr %l118, !tbaa !27
  br label %bb47
bb43:
  %t144 = load i32, ptr %l122, !tbaa !23
  %t145 = ashr i32 %t144, 16
  %t147 = icmp eq i32 %t145, 1
  br i1 %t147, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb46:
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb47:
  %t149 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t149, ptr %l17, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s13
  %t154 = load i64, ptr %l19, !tbaa !24
  %t155 = load i64, ptr %l18, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb50:
  br label %bb51
bb51:
  %t162 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t162, ptr %l131, !tbaa !27
  %t163 = load i64, ptr %l19, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i64, ptr %t166, i64 %t163
  %t168 = load i64, ptr %t167, !tbaa !34
  store i64 %t168, ptr %l20, !tbaa !24
  store i1 false, ptr %l21, !tbaa !21
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/views:state", ptr %t170, i32 0, i32 1
  store ptr %t172, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t174 = load ptr, ptr %l22, !tbaa !29
  %t175 = load i64, ptr %l23, !tbaa !24
  %t178 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v1, ptr %t174, i64 %t175)
  %t179 = extractvalue { i32, { i64, ptr } } %t178, 1
  %t180 = extractvalue { i32, { i64, ptr } } %t178, 0
  store i32 %t180, ptr %l140
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb54, label %ok.182
ok.182:
  store { i64, ptr } %t179, ptr %l139
  br label %bb53
bb53:
  %t183 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t183, ptr %l136, !tbaa !27
  br label %bb58
bb54:
  %t184 = load i32, ptr %l140, !tbaa !23
  %t185 = ashr i32 %t184, 16
  %t187 = icmp eq i32 %t185, 1
  br i1 %t187, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c104)
  unreachable
bb57:
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb58:
  %t189 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t189, ptr %l24, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s16
  %t194 = load i64, ptr %l26, !tbaa !24
  %t195 = load i64, ptr %l25, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s16)
  br label %bb67
bb61:
  br label %bb62
bb62:
  %t202 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t202, ptr %l149, !tbaa !27
  %t203 = load i64, ptr %l26, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr %"compiler/views:holding", ptr %t206, i64 %t203
  %t208 = load %"compiler/views:holding", ptr %t207
  store %"compiler/views:holding" %t208, ptr %l27
  %t210 = getelementptr %"compiler/views:holding", ptr %l27, i32 0, i32 0
  %t211 = load i64, ptr %t210, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = icmp eq i64 %t211, %t212
  br i1 %t215, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s16)
  br label %bb66
bb66:
  %t217 = load i64, ptr %l26, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l26, !tbaa !24
  br label %bb59
bb67:
  %t221 = load i64, ptr %l23, !tbaa !24
  %t222 = load i64, ptr %l25, !tbaa !24
  %t225 = add i64 %t221, %t222
  store i64 %t225, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb68
bb68:
  br label %bb52
bb69:
  %t227 = load i1, ptr %l21, !tbaa !21
  br i1 %t227, label %bb70, label %bb71
bb70:
  %t229 = load i64, ptr %l20, !tbaa !24
  %t234 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l8, i64 %t229)
  store i1 %t234, ptr %l165
  br label %bb72
bb71:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb73
bb72:
  %t235 = load i1, ptr %l165, !tbaa !21
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l161, !tbaa !21
  br label %bb73
bb73:
  %t238 = load i1, ptr %l161, !tbaa !21
  br i1 %t238, label %bb74, label %bb75
bb74:
  %t239 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t239)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s13)
  br label %bb78
bb78:
  %t242 = load i64, ptr %l19, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l19, !tbaa !24
  br label %bb48
bb79:
  %t246 = load i64, ptr %l16, !tbaa !24
  %t247 = load i64, ptr %l18, !tbaa !24
  %t250 = add i64 %t246, %t247
  store i64 %t250, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb80:
  br label %bb41
bb81:
  store ptr %l8, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s22
  %t253 = load ptr, ptr %l29, !tbaa !29
  %t254 = load i64, ptr %l30, !tbaa !24
  %t257 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t253, i64 %t254)
  %t258 = extractvalue { i32, { i64, ptr } } %t257, 1
  %t259 = extractvalue { i32, { i64, ptr } } %t257, 0
  store i32 %t259, ptr %l179
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb84, label %ok.261
ok.261:
  store { i64, ptr } %t258, ptr %l178
  br label %bb83
bb83:
  %t262 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t262, ptr %l175, !tbaa !27
  br label %bb88
bb84:
  %t263 = load i32, ptr %l179, !tbaa !23
  %t264 = ashr i32 %t263, 16
  %t266 = icmp eq i32 %t264, 1
  br i1 %t266, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb87:
  call void @__olang_scope_close(ptr %s22)
  br label %bb132
bb88:
  %t268 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t268, ptr %l31, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s23
  %t273 = load i64, ptr %l33, !tbaa !24
  %t274 = load i64, ptr %l32, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s23)
  br label %bb130
bb91:
  br label %bb92
bb92:
  %t281 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t281, ptr %l188, !tbaa !27
  %t282 = load i64, ptr %l33, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i64, ptr %t285, i64 %t282
  %t287 = load i64, ptr %t286, !tbaa !34
  store i64 %t287, ptr %l34, !tbaa !24
  %t289 = load i64, ptr %l34, !tbaa !24
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/views:state", ptr %t291, i32 0, i32 3
  %t297 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t293, i64 %t289)
  store i1 %t297, ptr %l195
  br label %bb93
bb93:
  %t298 = load i1, ptr %l195, !tbaa !21
  %t299 = xor i1 %t298, true
  br i1 %t299, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s24
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l197, !tbaa !29
  %t302 = load i64, ptr %l34, !tbaa !24
  store i64 %t302, ptr %l198, !tbaa !24
  %t303 = load i64, ptr %l34, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [2 x i64] }, ptr %t304, i32 0, i32 0
  store i64 1, ptr %t305
  %t307 = insertvalue { i64 } undef, i64 %t303, 0
  %t308 = getelementptr { i64, [2 x i64] }, ptr %t304, i32 0, i32 1
  store { i64 } %t307, ptr %t308
  %t309 = load { i64, [2 x i64] }, ptr %t304
  %t311 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s24, { i64, [2 x i64] } %t309, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t311, ptr %l201
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t312 = load ptr, ptr %l197, !tbaa !29
  %t313 = load i64, ptr %l198, !tbaa !24
  %t314 = load %"compiler/views:place", ptr %l201
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t312, i64 %t313, %"compiler/views:place" %t314)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s24)
  br label %bb98
bb98:
  %t315 = load i64, ptr %l34, !tbaa !24
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr %"compiler/views:state", ptr %t317, i32 0, i32 3
  %t323 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t319, i64 %t315)
  store i1 %t323, ptr %l206
  br label %bb99
bb99:
  %t324 = load i1, ptr %l206, !tbaa !21
  %t325 = xor i1 %t324, true
  br i1 %t325, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s25
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l208, !tbaa !29
  %t328 = load i64, ptr %l34, !tbaa !24
  store i64 %t328, ptr %l209, !tbaa !24
  %t329 = load i64, ptr %l34, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [2 x i64] }, ptr %t330, i32 0, i32 0
  store i64 1, ptr %t331
  %t333 = insertvalue { i64 } undef, i64 %t329, 0
  %t334 = getelementptr { i64, [2 x i64] }, ptr %t330, i32 0, i32 1
  store { i64 } %t333, ptr %t334
  %t335 = load { i64, [2 x i64] }, ptr %t330
  %t337 = call %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %s25, { i64, [2 x i64] } %t335, i64 0, i64 0, i1 false)
  store %"compiler/views:place" %t337, ptr %l212
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t338 = load ptr, ptr %l208, !tbaa !29
  %t339 = load i64, ptr %l209, !tbaa !24
  %t340 = load %"compiler/views:place", ptr %l212
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t338, i64 %t339, %"compiler/views:place" %t340)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s25)
  br label %bb104
bb104:
  %t341 = load ptr, ptr %l1, !tbaa !29
  %t343 = getelementptr %"compiler/views:state", ptr %t341, i32 0, i32 2
  store ptr %t343, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s27
  %t345 = load ptr, ptr %l37, !tbaa !29
  %t346 = load i64, ptr %l38, !tbaa !24
  %t349 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v1, ptr %t345, i64 %t346)
  %t350 = extractvalue { i32, { i64, ptr } } %t349, 1
  %t351 = extractvalue { i32, { i64, ptr } } %t349, 0
  store i32 %t351, ptr %l219
  %t352 = icmp ne i32 %t351, 0
  br i1 %t352, label %bb107, label %ok.353
ok.353:
  store { i64, ptr } %t350, ptr %l218
  br label %bb106
bb106:
  %t354 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t354, ptr %l215, !tbaa !27
  br label %bb111
bb107:
  %t355 = load i32, ptr %l219, !tbaa !23
  %t356 = ashr i32 %t355, 16
  %t358 = icmp eq i32 %t356, 1
  br i1 %t358, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @.c106)
  unreachable
bb110:
  call void @__olang_scope_close(ptr %s27)
  br label %bb123
bb111:
  %t360 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t360, ptr %l39, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s28
  %t365 = load i64, ptr %l41, !tbaa !24
  %t366 = load i64, ptr %l40, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s28)
  br label %bb121
bb114:
  br label %bb115
bb115:
  %t373 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t373, ptr %l228, !tbaa !27
  %t374 = load i64, ptr %l41, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr %"compiler/views:naming", ptr %t377, i64 %t374
  %t379 = load %"compiler/views:naming", ptr %t378
  store %"compiler/views:naming" %t379, ptr %l42
  %t381 = getelementptr %"compiler/views:naming", ptr %l42, i32 0, i32 0
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = load i64, ptr %l34, !tbaa !24
  %t386 = icmp eq i64 %t382, %t383
  br i1 %t386, label %bb116, label %bb117
bb116:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load i64, ptr %l34, !tbaa !24
  %t390 = getelementptr %"compiler/views:naming", ptr %l42, i32 0, i32 1
  %t391 = load %"compiler/views:place", ptr %t390
  call void @compiler_2fviews_2enameAdd(ptr %v0, ptr %t388, i64 %t389, %"compiler/views:place" %t391)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s28)
  br label %bb120
bb120:
  %t395 = load i64, ptr %l41, !tbaa !24
  %t397 = add i64 %t395, 1
  store i64 %t397, ptr %l41, !tbaa !24
  br label %bb112
bb121:
  %t399 = load i64, ptr %l38, !tbaa !24
  %t400 = load i64, ptr %l40, !tbaa !24
  %t403 = add i64 %t399, %t400
  store i64 %t403, ptr %l38, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb122
bb122:
  br label %bb105
bb123:
  %t405 = load i64, ptr %l34, !tbaa !24
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/views:state", ptr %t407, i32 0, i32 3
  %t413 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t409, i64 %t405)
  store i1 %t413, ptr %l246
  br label %bb124
bb124:
  %t414 = load i1, ptr %l246, !tbaa !21
  %t415 = xor i1 %t414, true
  br i1 %t415, label %bb125, label %bb126
bb125:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/views:state", ptr %t417, i32 0, i32 3
  %t420 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t419, i64 %t420)
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s23)
  br label %bb129
bb129:
  %t423 = load i64, ptr %l33, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l33, !tbaa !24
  br label %bb89
bb130:
  %t427 = load i64, ptr %l30, !tbaa !24
  %t428 = load i64, ptr %l32, !tbaa !24
  %t431 = add i64 %t427, %t428
  store i64 %t431, ptr %l30, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb131
bb131:
  br label %bb82
bb132:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr %"compiler/views:state", ptr %t433, i32 0, i32 4
  store ptr %t435, ptr %l44, !tbaa !29
  store i64 0, ptr %l45, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s34
  %t437 = load ptr, ptr %l44, !tbaa !29
  %t438 = load i64, ptr %l45, !tbaa !24
  %t441 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v1, ptr %t437, i64 %t438)
  %t442 = extractvalue { i32, { i64, ptr } } %t441, 1
  %t443 = extractvalue { i32, { i64, ptr } } %t441, 0
  store i32 %t443, ptr %l262
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb135, label %ok.445
ok.445:
  store { i64, ptr } %t442, ptr %l261
  br label %bb134
bb134:
  %t446 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t446, ptr %l258, !tbaa !27
  br label %bb139
bb135:
  %t447 = load i32, ptr %l262, !tbaa !23
  %t448 = ashr i32 %t447, 16
  %t450 = icmp eq i32 %t448, 1
  br i1 %t450, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb138:
  call void @__olang_scope_close(ptr %s34)
  br label %bb177
bb139:
  %t452 = load { i64, ptr }, ptr %l258, !tbaa !27
  store { i64, ptr } %t452, ptr %l46, !tbaa !27
  %t453 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t453, 0
  store i64 %t455, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s35
  %t457 = load i64, ptr %l48, !tbaa !24
  %t458 = load i64, ptr %l47, !tbaa !24
  %t461 = icmp slt i64 %t457, %t458
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s35)
  br label %bb175
bb142:
  br label %bb143
bb143:
  %t465 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t465, ptr %l271, !tbaa !27
  %t466 = load i64, ptr %l48, !tbaa !24
  %t468 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !27
  %t470 = getelementptr %"compiler/views:tasked", ptr %t469, i64 %t466
  %t471 = load %"compiler/views:tasked", ptr %t470
  store %"compiler/views:tasked" %t471, ptr %l49
  store i1 false, ptr %l50, !tbaa !21
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/views:state", ptr %t473, i32 0, i32 4
  store ptr %t475, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s37
  %t477 = load ptr, ptr %l51, !tbaa !29
  %t478 = load i64, ptr %l52, !tbaa !24
  %t481 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v0, ptr %t477, i64 %t478)
  %t482 = extractvalue { i32, { i64, ptr } } %t481, 1
  %t483 = extractvalue { i32, { i64, ptr } } %t481, 0
  store i32 %t483, ptr %l280
  %t484 = icmp ne i32 %t483, 0
  br i1 %t484, label %bb146, label %ok.485
ok.485:
  store { i64, ptr } %t482, ptr %l279
  br label %bb145
bb145:
  %t486 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t486, ptr %l276, !tbaa !27
  br label %bb150
bb146:
  %t487 = load i32, ptr %l280, !tbaa !23
  %t488 = ashr i32 %t487, 16
  %t490 = icmp eq i32 %t488, 1
  br i1 %t490, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @.c108)
  unreachable
bb149:
  call void @__olang_scope_close(ptr %s37)
  br label %bb169
bb150:
  %t492 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t492, ptr %l53, !tbaa !27
  %t493 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t495 = extractvalue { i64, ptr } %t493, 0
  store i64 %t495, ptr %l54, !tbaa !24
  store i64 0, ptr %l55, !tbaa !24
  br label %bb151
bb151:
  store %olang.scope zeroinitializer, ptr %s38
  %t497 = load i64, ptr %l55, !tbaa !24
  %t498 = load i64, ptr %l54, !tbaa !24
  %t501 = icmp slt i64 %t497, %t498
  %t503 = xor i1 %t501, true
  br i1 %t503, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s38)
  br label %bb167
bb153:
  br label %bb154
bb154:
  %t505 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t505, ptr %l289, !tbaa !27
  %t506 = load i64, ptr %l55, !tbaa !24
  %t508 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr %"compiler/views:tasked", ptr %t509, i64 %t506
  %t511 = load %"compiler/views:tasked", ptr %t510
  store %"compiler/views:tasked" %t511, ptr %l56
  %t513 = getelementptr %"compiler/views:tasked", ptr %l56, i32 0, i32 0
  %t514 = getelementptr %"compiler/views:view", ptr %t513, i32 0, i32 1
  %t515 = load i64, ptr %t514, !tbaa !24
  %t516 = getelementptr %"compiler/views:tasked", ptr %l49, i32 0, i32 0
  %t517 = getelementptr %"compiler/views:view", ptr %t516, i32 0, i32 1
  %t518 = load i64, ptr %t517, !tbaa !24
  %t521 = icmp eq i64 %t515, %t518
  br i1 %t521, label %bb155, label %bb156
bb155:
  %t523 = getelementptr %"compiler/views:tasked", ptr %l56, i32 0, i32 1
  %t524 = load %"compiler/source:Span", ptr %t523
  store %"compiler/source:Span" %t524, ptr %l296
  %t525 = getelementptr %"compiler/views:tasked", ptr %l49, i32 0, i32 1
  %t526 = load %"compiler/source:Span", ptr %t525
  store %"compiler/source:Span" %t526, ptr %l298
  %t529 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l296, ptr %l298)
  store i1 %t529, ptr %l300
  br label %bb157
bb156:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb158
bb157:
  %t530 = load i1, ptr %l300, !tbaa !21
  store i1 %t530, ptr %l295, !tbaa !21
  br label %bb158
bb158:
  %t531 = load i1, ptr %l295, !tbaa !21
  br i1 %t531, label %bb159, label %bb160
bb159:
  %t532 = getelementptr %"compiler/views:tasked", ptr %l56, i32 0, i32 0
  %t533 = getelementptr %"compiler/views:view", ptr %t532, i32 0, i32 0
  %t534 = load %"compiler/views:place", ptr %t533
  store %"compiler/views:place" %t534, ptr %l302
  %t535 = getelementptr %"compiler/views:tasked", ptr %l49, i32 0, i32 0
  %t536 = getelementptr %"compiler/views:view", ptr %t535, i32 0, i32 0
  %t537 = load %"compiler/views:place", ptr %t536
  store %"compiler/views:place" %t537, ptr %l304
  %t540 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l302, ptr %l304)
  store i1 %t540, ptr %l306
  br label %bb161
bb160:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb162
bb161:
  %t541 = load i1, ptr %l306, !tbaa !21
  store i1 %t541, ptr %l301, !tbaa !21
  br label %bb162
bb162:
  %t542 = load i1, ptr %l301, !tbaa !21
  br i1 %t542, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb165
bb164:
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s38)
  br label %bb166
bb166:
  %t543 = load i64, ptr %l55, !tbaa !24
  %t545 = add i64 %t543, 1
  store i64 %t545, ptr %l55, !tbaa !24
  br label %bb151
bb167:
  %t547 = load i64, ptr %l52, !tbaa !24
  %t548 = load i64, ptr %l54, !tbaa !24
  %t551 = add i64 %t547, %t548
  store i64 %t551, ptr %l52, !tbaa !24
  call void @__olang_scope_close(ptr %s37)
  br label %bb168
bb168:
  br label %bb144
bb169:
  %t553 = load i1, ptr %l50, !tbaa !21
  %t555 = xor i1 %t553, true
  br i1 %t555, label %bb170, label %bb171
bb170:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/views:state", ptr %t557, i32 0, i32 4
  %t560 = load %"compiler/views:tasked", ptr %l49
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t559, %"compiler/views:tasked" %t560)
  br label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s35)
  br label %bb174
bb174:
  %t563 = load i64, ptr %l48, !tbaa !24
  %t565 = add i64 %t563, 1
  store i64 %t565, ptr %l48, !tbaa !24
  br label %bb140
bb175:
  %t567 = load i64, ptr %l45, !tbaa !24
  %t568 = load i64, ptr %l47, !tbaa !24
  %t571 = add i64 %t567, %t568
  store i64 %t571, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s34)
  br label %bb176
bb176:
  br label %bb133
bb177:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2enameAdd(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:place" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/views:place"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:naming"
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca %"compiler/views:place"
  %l33 = alloca %"compiler/views:place"
  %l35 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca %"compiler/views:naming"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/views:place" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb7:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/views:naming", ptr %t37, i64 %t34
  %t39 = load %"compiler/views:naming", ptr %t38
  store %"compiler/views:naming" %t39, ptr %l8
  %t41 = getelementptr %"compiler/views:naming", ptr %l8, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp eq i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = getelementptr %"compiler/views:naming", ptr %l8, i32 0, i32 1
  %t49 = load %"compiler/views:place", ptr %t48
  store %"compiler/views:place" %t49, ptr %l31
  %t50 = load %"compiler/views:place", ptr %l2
  store %"compiler/views:place" %t50, ptr %l33
  %t53 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l31, ptr %l33)
  store i1 %t53, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i1, ptr %l35, !tbaa !21
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb8
bb20:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t60, %t61
  store i64 %t64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb1
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/views:state", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l42, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load %"compiler/views:place", ptr %l2
  %t73 = call %"compiler/views:naming" @compiler_2fviews_3anaming_2ector(ptr %s0, i64 %t69, %"compiler/views:place" %t70)
  store %"compiler/views:naming" %t73, ptr %l45
  br label %bb23
bb23:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load %"compiler/views:naming", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t74, %"compiler/views:naming" %t75)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fviews_2eplaceAdd(ptr %v0, ptr %a0, %"compiler/views:place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:place"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"compiler/views:place"
  %l27 = alloca %"compiler/views:place"
  %l29 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l13
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/views:place", ptr %t35, i64 %t32
  %t37 = load %"compiler/views:place", ptr %t36
  store %"compiler/views:place" %t37, ptr %l25
  %t40 = load %"compiler/views:place", ptr %l1
  store %"compiler/views:place" %t40, ptr %l27
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l25, ptr %l27)
  store i1 %t43, ptr %l29
  br label %bb12
bb12:
  %t44 = load i1, ptr %l29, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/views:place", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %t55, %"compiler/views:place" %t56)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eplaceEnd(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i64
  %l21 = alloca %"compiler/source:Span"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l11
  br label %bb6
bb6:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb20
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2fviews_2eexprEnd(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb13
bb13:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb18
bb18:
  %t42 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c111)
  unreachable
bb20:
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fviews_2ereal({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fviews_2eunAway(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  store i64 16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l7, !tbaa !24
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 17
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l8, !tbaa !29
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t64 = load ptr, ptr %l8, !tbaa !29
  store ptr %t64, ptr %l1, !tbaa !29
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t66, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @.c113)
  unreachable
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l6, !tbaa !24
  br label %bb7
bb23:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fviews_2eviewAdd(ptr %v0, ptr %a0, %"compiler/views:view" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/views:view"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/views:view"
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca %"compiler/views:view"
  %l41 = alloca i1
  %l42 = alloca %"compiler/views:place"
  %l44 = alloca %"compiler/views:place"
  %l46 = alloca i1
  %l49 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/views:view" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i64, ptr %l10, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = call %"compiler/views:view" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/views:view" %t55, ptr %l37
  br label %bb12
bb12:
  %t56 = load %"compiler/views:view", ptr %l37
  store %"compiler/views:view" %t56, ptr %l8
  %t57 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = icmp ne i64 %t58, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb16
bb14:
  %t65 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 0
  %t66 = load %"compiler/views:place", ptr %t65
  store %"compiler/views:place" %t66, ptr %l42
  %t67 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 0
  %t68 = load %"compiler/views:place", ptr %t67
  store %"compiler/views:place" %t68, ptr %l44
  %t71 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %l42, ptr %l44)
  store i1 %t71, ptr %l46
  br label %bb15
bb15:
  %t72 = load i1, ptr %l46, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l41, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t76 = getelementptr %"compiler/views:view", ptr %l1, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = getelementptr %"compiler/views:view", ptr %l8, i32 0, i32 2
  %t80 = load i1, ptr %t79, !tbaa !21
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l49, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l49, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load %"compiler/views:view", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eSetAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t85, i64 %t86, %"compiler/views:view" %t87)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb27:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb8
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/views:view", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ePush_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %t95, %"compiler/views:view" %t96)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fviews_2eweight(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/views:holding"
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/views:state", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/views:state", ptr %t7, i32 0, i32 4
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l13
  br label %bb4
bb4:
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = add i64 1, %t12
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/views:state", ptr %t14, i32 0, i32 2
  %t18 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 2, %t19
  %t21 = load i64, ptr %l14, !tbaa !24
  %t23 = add i64 %t21, %t20
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/views:state", ptr %t24, i32 0, i32 3
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l22
  br label %bb6
bb6:
  %t29 = load i64, ptr %l19, !tbaa !24
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = add i64 %t29, %t30
  store i64 %t31, ptr %l1, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/views:state", ptr %t33, i32 0, i32 1
  store ptr %t35, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v0, ptr %t37, i64 %t38)
  %t42 = extractvalue { i32, { i64, ptr } } %t41, 1
  %t43 = extractvalue { i32, { i64, ptr } } %t41, 0
  store i32 %t43, ptr %l30
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb9, label %ok.45
ok.45:
  store { i64, ptr } %t42, ptr %l29
  br label %bb8
bb8:
  %t46 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t46, ptr %l26, !tbaa !27
  br label %bb13
bb9:
  %t47 = load i32, ptr %l30, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb13:
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t52, ptr %l4, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr %"compiler/views:holding", ptr %t69, i64 %t66
  %t71 = load %"compiler/views:holding", ptr %t70
  store %"compiler/views:holding" %t71, ptr %l7
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = getelementptr %"compiler/views:holding", ptr %l7, i32 0, i32 1
  %t75 = getelementptr %"compiler/views:view", ptr %t74, i32 0, i32 2
  %t76 = load i1, ptr %t75, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  store i64 5, ptr %l44, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb20
bb20:
  %t78 = load i64, ptr %l44, !tbaa !24
  %t79 = add i64 3, %t78
  %t80 = load i64, ptr %l42, !tbaa !24
  %t82 = add i64 %t80, %t79
  store i64 %t82, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb14
bb22:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t88, %t89
  store i64 %t92, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb7
bb24:
  %t94 = load i64, ptr %l1, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fviews_3aViewer_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"compiler/views:Viewer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e(ptr %t5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l34
  br label %bb1
bb1:
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l35
  br label %bb2
bb2:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t11)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l36
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l6
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t14)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l37
  br label %bb4
bb4:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l7
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t17)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l38
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l8
  store i64 -1, ptr %l9, !tbaa !24
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e(ptr %t20)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l39
  br label %bb6
bb6:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l10
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l40
  br label %bb7
bb7:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l11
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t26)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l41
  br label %bb8
bb8:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l12
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t29)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l42
  br label %bb9
bb9:
  %t31 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l13
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t32)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l43
  br label %bb10
bb10:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l14
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t35)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l44
  br label %bb11
bb11:
  %t37 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l15
  %t38 = load ptr, ptr @__olang_prog_scope
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t38)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l45
  br label %bb12
bb12:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l16
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t41)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l46
  br label %bb13
bb13:
  %t43 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  %t44 = load ptr, ptr @__olang_prog_scope
  %t45 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t44)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l47
  br label %bb14
bb14:
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l19
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t47)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l48
  br label %bb15
bb15:
  %t49 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l20
  store ptr null, ptr %l21, !tbaa !29
  store i64 -1, ptr %l22, !tbaa !24
  store i1 false, ptr %l23, !tbaa !21
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i1 false, ptr %l26, !tbaa !21
  %t50 = load ptr, ptr @__olang_prog_scope
  %t51 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t50)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l49
  br label %bb16
bb16:
  %t52 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l27
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e(ptr %t53)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l50
  br label %bb17
bb17:
  %t55 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l28
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %t56)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l51
  br label %bb18
bb18:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l29
  %t59 = load ptr, ptr @__olang_prog_scope
  %t60 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t59)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l52
  br label %bb19
bb19:
  %t61 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l30
  %t62 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t62)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l53
  br label %bb20
bb20:
  %t64 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  %t65 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 0
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %t65, !tbaa !29
  %t67 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 1
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t67
  %t69 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 2
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %t69
  %t71 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 3
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %t71
  %t73 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 4
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t73
  %t75 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 5
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t75
  %t77 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 6
  %t78 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %t77
  %t79 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 7
  %t80 = load i64, ptr %l9, !tbaa !24
  store i64 %t80, ptr %t79, !tbaa !24
  %t81 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 8
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t81
  %t83 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 9
  %t84 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %t83
  %t85 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 10
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t85
  %t87 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 11
  %t88 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %t87
  %t89 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 12
  %t90 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %t89
  %t91 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 13
  %t92 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %t91
  %t93 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 14
  %t94 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %t93
  %t95 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 15
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t95
  %t97 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 16
  %t98 = load i64, ptr %l18, !tbaa !24
  store i64 %t98, ptr %t97, !tbaa !24
  %t99 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 17
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 18
  %t102 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t101
  %t103 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 19
  %t104 = load ptr, ptr %l21, !tbaa !29
  store ptr %t104, ptr %t103, !tbaa !29
  %t105 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 20
  %t106 = load i64, ptr %l22, !tbaa !24
  store i64 %t106, ptr %t105, !tbaa !24
  %t107 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 21
  %t108 = load i1, ptr %l23, !tbaa !21
  store i1 %t108, ptr %t107, !tbaa !21
  %t109 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 22
  %t110 = load i1, ptr %l24, !tbaa !21
  store i1 %t110, ptr %t109, !tbaa !21
  %t111 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 23
  %t112 = load i1, ptr %l25, !tbaa !21
  store i1 %t112, ptr %t111, !tbaa !21
  %t113 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 24
  %t114 = load i1, ptr %l26, !tbaa !21
  store i1 %t114, ptr %t113, !tbaa !21
  %t115 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 25
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t115
  %t117 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 26
  %t118 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %t117
  %t119 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 27
  %t120 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t119
  %t121 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 28
  %t122 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t121
  %t123 = getelementptr %"compiler/views:Viewer", ptr %l54, i32 0, i32 29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t123
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l54, i64 216, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/views:fact" @compiler_2fviews_3afact_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5, i64 %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %rv = alloca %"compiler/views:fact"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/views:fact" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/views:fact" %t18, i64 %a1, 1
  %t22 = insertvalue %"compiler/views:fact" %t20, i32 %a2, 2
  %t24 = insertvalue %"compiler/views:fact" %t22, i64 %a3, 3
  %t26 = insertvalue %"compiler/views:fact" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/views:fact" %t26, i1 %a5, 5
  %t30 = insertvalue %"compiler/views:fact" %t28, i64 %a6, 6
  %t32 = insertvalue %"compiler/views:fact" %t30, %"compiler/source:Span" %a7, 7
  %t34 = insertvalue %"compiler/views:fact" %t32, i64 -1, 8
  store %"compiler/views:fact" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:fact", ptr %rv
  ret %"compiler/views:fact" %rr
}

define dso_local %"compiler/views:holding" @compiler_2fviews_3aholding_2ector(ptr %v0, i64 %a0, %"compiler/views:view" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:holding"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:holding" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/views:holding" %t6, %"compiler/views:view" %a1, 1
  store %"compiler/views:holding" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:holding", ptr %rv
  ret %"compiler/views:holding" %rr
}

define dso_local %"compiler/views:loopFrame" @compiler_2fviews_3aloopFrame_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:loopFrame"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l1, !tbaa !23
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e(ptr %t3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e(ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t9 = load i32, ptr %l1, !tbaa !23
  %t10 = insertvalue %"compiler/views:loopFrame" undef, i32 %t9, 0
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t12 = insertvalue %"compiler/views:loopFrame" %t10, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 1
  %t14 = insertvalue %"compiler/views:loopFrame" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 2
  store %"compiler/views:loopFrame" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:loopFrame", ptr %rv
  ret %"compiler/views:loopFrame" %rr
}

define dso_local %"compiler/views:naming" @compiler_2fviews_3anaming_2ector(ptr %v0, i64 %a0, %"compiler/views:place" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:naming"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:naming" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/views:naming" %t6, %"compiler/views:place" %a1, 1
  store %"compiler/views:naming" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:naming", ptr %rv
  ret %"compiler/views:naming" %rr
}

define dso_local %"compiler/views:place" @compiler_2fviews_3aplace_2ector(ptr %v0, { i64, [2 x i64] } %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/views:place"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/views:place" undef, { i64, [2 x i64] } %a0, 0
  %t12 = insertvalue %"compiler/views:place" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/views:place" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/views:place" %t14, i1 %a3, 3
  store %"compiler/views:place" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:place", ptr %rv
  ret %"compiler/views:place" %rr
}

define dso_local %"compiler/views:state" @compiler_2fviews_3astate_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:state"
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l0, !tbaa !21
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l1
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e(ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l3
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e(ptr %t10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t13 = load i1, ptr %l0, !tbaa !21
  %t14 = insertvalue %"compiler/views:state" undef, i1 %t13, 0
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t16 = insertvalue %"compiler/views:state" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 1
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t18 = insertvalue %"compiler/views:state" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 2
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t20 = insertvalue %"compiler/views:state" %t18, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 3
  %t22 = insertvalue %"compiler/views:state" %t20, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 4
  store %"compiler/views:state" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:state", ptr %rv
  ret %"compiler/views:state" %rr
}

define dso_local %"compiler/views:summary" @compiler_2fviews_3asummary_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/views:summary"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t14 = insertvalue %"compiler/views:summary" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 0
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t16 = insertvalue %"compiler/views:summary" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 1
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t18 = insertvalue %"compiler/views:summary" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 2
  %t20 = insertvalue %"compiler/views:summary" %t18, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 3
  %t22 = insertvalue %"compiler/views:summary" %t20, i1 false, 4
  store %"compiler/views:summary" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:summary", ptr %rv
  ret %"compiler/views:summary" %rr
}

define dso_local %"compiler/views:tasked" @compiler_2fviews_3atasked_2ector(ptr %v0, %"compiler/views:view" %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/views:tasked"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/views:tasked" undef, %"compiler/views:view" %a0, 0
  %t8 = insertvalue %"compiler/views:tasked" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/views:tasked" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:tasked", ptr %rv
  ret %"compiler/views:tasked" %rr
}

define dso_local %"compiler/views:view" @compiler_2fviews_3aview_2ector(ptr %v0, %"compiler/views:place" %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"compiler/views:place"
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/views:view"
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/views:place" %a0, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t6, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  store i64 -1, ptr %l7, !tbaa !24
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load %"compiler/source:Span", ptr %l12
  %t9 = load %"compiler/views:place", ptr %l2
  %t10 = insertvalue %"compiler/views:view" undef, %"compiler/views:place" %t9, 0
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = insertvalue %"compiler/views:view" %t10, i64 %t11, 1
  %t13 = load i1, ptr %l4, !tbaa !21
  %t14 = insertvalue %"compiler/views:view" %t12, i1 %t13, 2
  %t15 = load %"compiler/source:Span", ptr %l5
  %t16 = insertvalue %"compiler/views:view" %t14, %"compiler/source:Span" %t15, 3
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = insertvalue %"compiler/views:view" %t16, i64 %t17, 4
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = insertvalue %"compiler/views:view" %t18, i64 %t19, 5
  %t22 = insertvalue %"compiler/views:view" %t20, %"compiler/source:Span" %t8, 6
  store %"compiler/views:view" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/views:view", ptr %rv
  ret %"compiler/views:view" %rr
}

declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:644: unreachable reached\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.c1 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1513: unreachable reached\0A\00"
@.c2 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1558: unreachable reached\0A\00"
@.c3 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1568: unreachable reached\0A\00"
@.c4 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1509: unreachable reached\0A\00"
@.c5 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1494: unreachable reached\0A\00"
@.c6 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1459: unreachable reached\0A\00"
@.c7 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:214: unreachable reached\0A\00"
@.d8 = private constant [4 x i8] c"std/"
@.d9 = private constant [15 x i8] c"std/prelude/vec"
@.d10 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.c11 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:225: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c12 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1008: unreachable reached\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c13 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1025: unreachable reached\0A\00"
@.d14 = private constant [6 x i8] c"'Push'"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 i64 4, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  %t68 = icmp eq i32 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c15 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:992: unreachable reached\0A\00"
@.c16 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:996: unreachable reached\0A\00"
@.c17 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1003: unreachable reached\0A\00"
@.c18 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:835: unreachable reached\0A\00"
@.c19 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:551: unreachable reached\0A\00"
@.d20 = private constant [4 x i8] c"data"
@.c21 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:549: unreachable reached\0A\00"
@.c22 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1274: unreachable reached\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c23 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1296: unreachable reached\0A\00"
@.c24 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1306: unreachable reached\0A\00"
@.c25 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1321: unreachable reached\0A\00"
@.c26 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1332: unreachable reached\0A\00"
@.c27 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1352: unreachable reached\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c28 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1356: unreachable reached\0A\00"
@.c29 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1361: unreachable reached\0A\00"
@.c30 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1369: unreachable reached\0A\00"
@.c31 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1375: unreachable reached\0A\00"
@.c32 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1382: unreachable reached\0A\00"
@.c33 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1392: unreachable reached\0A\00"
@.d34 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aPrimOp(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c35 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1137: unreachable reached\0A\00"
@.c36 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1148: unreachable reached\0A\00"
@.c37 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1170: unreachable reached\0A\00"
@.c38 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1180: unreachable reached\0A\00"
@.c39 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1118: unreachable reached\0A\00"
@.c40 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1190: unreachable reached\0A\00"
@.c41 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:492: unreachable reached\0A\00"
@.c42 = private unnamed_addr constant [53 x i8] c"compiler/views.olang:807: slice bounds out of range\0A\00"
@.c43 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:813: unreachable reached\0A\00"
declare i64 @__olang_fmt_i64(ptr, i64)
@.c44 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:770: unreachable reached\0A\00"
@.c45 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:788: unreachable reached\0A\00"
@.c46 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:684: unreachable reached\0A\00"
@.d47 = private constant [8 x i8] c"vecState"
@.d48 = private constant [15 x i8] c"std/prelude/vec"
@.c49 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1080: unreachable reached\0A\00"
@.c50 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1086: unreachable reached\0A\00"
@.c51 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1087: unreachable reached\0A\00"
@.c52 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1092: unreachable reached\0A\00"
@.c53 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1093: unreachable reached\0A\00"
@.c54 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1099: unreachable reached\0A\00"
@.c55 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:927: unreachable reached\0A\00"
@.c56 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:929: unreachable reached\0A\00"
@.c57 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1034: unreachable reached\0A\00"
@.c58 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:296: unreachable reached\0A\00"
@.c59 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:509: unreachable reached\0A\00"
@.d60 = private constant [1 x i8] c"."
@.c61 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:523: unreachable reached\0A\00"
@.c62 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:505: unreachable reached\0A\00"
@.c63 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1209: unreachable reached\0A\00"
@.c64 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1218: unreachable reached\0A\00"
@.c65 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1199: unreachable reached\0A\00"
@.c66 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:419: unreachable reached\0A\00"
@.d67 = private constant [31 x i8] c"a call through a function value"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d68 = private constant [1 x i8] c"'"
@.d69 = private constant [1 x i8] c"'"
@.d70 = private constant [1 x i8] c"'"
@.d71 = private constant [1 x i8] c"'"
@.d72 = private constant [8 x i8] c"a lambda"
@.c73 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:322: unreachable reached\0A\00"
@.c74 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:541: unreachable reached\0A\00"
@.c75 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:601: unreachable reached\0A\00"
@.c76 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:618: unreachable reached\0A\00"
@.c77 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:612: unreachable reached\0A\00"
@.c78 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:963: unreachable reached\0A\00"
@.c79 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:960: unreachable reached\0A\00"
@.c80 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:971: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aJumpKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c81 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:882: unreachable reached\0A\00"
@.c82 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:883: unreachable reached\0A\00"
@.c83 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:846: unreachable reached\0A\00"
@.c84 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1054: unreachable reached\0A\00"
@.c85 = private unnamed_addr constant [48 x i8] c"compiler/views.olang:1066: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aDeclKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c86 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:398: unreachable reached\0A\00"
@.c87 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:746: unreachable reached\0A\00"
@.c88 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:267: unreachable reached\0A\00"
@.c89 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:284: unreachable reached\0A\00"
@.c90 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:285: unreachable reached\0A\00"
@.c91 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:282: unreachable reached\0A\00"
@.c92 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:245: unreachable reached\0A\00"
@.c93 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:249: unreachable reached\0A\00"
@.d94 = private constant [1 x i8] c"?"
@.c95 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:331: unreachable reached\0A\00"
@.c96 = private unnamed_addr constant [53 x i8] c"compiler/views.olang:339: slice bounds out of range\0A\00"
@.c97 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:120: unreachable reached\0A\00"
@.c98 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:129: unreachable reached\0A\00"
@.c99 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:134: unreachable reached\0A\00"
@.c100 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:447: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aplace(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/views:place", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/views:place", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fviews_3aRoot(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/views:place", ptr %t9, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/views:place", ptr %t12, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp eq i64 %t11, %t14
  br i1 %t17, label %bb4, label %bb1
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/views:place", ptr %t19, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/views:place", ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = icmp eq i64 %t21, %t24
  br i1 %t27, label %bb5, label %bb1
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/views:place", ptr %t29, i32 0, i32 3
  %t31 = load i1, ptr %t30, !tbaa !21
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/views:place", ptr %t32, i32 0, i32 3
  %t34 = load i1, ptr %t33, !tbaa !21
  %t37 = icmp eq i1 %t31, %t34
  br i1 %t37, label %bb6, label %bb1
bb6:
  br label %bb7
bb7:
  %t39 = load i1, ptr %l2, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c101 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:696: unreachable reached\0A\00"
@.c102 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:699: unreachable reached\0A\00"
@.c103 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:700: unreachable reached\0A\00"
@.c104 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:702: unreachable reached\0A\00"
@.c105 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:707: unreachable reached\0A\00"
@.c106 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:710: unreachable reached\0A\00"
@.c107 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:715: unreachable reached\0A\00"
@.c108 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:717: unreachable reached\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c109 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:677: unreachable reached\0A\00"
@.c110 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:483: unreachable reached\0A\00"
@.c111 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:439: unreachable reached\0A\00"
@.c112 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:582: unreachable reached\0A\00"
@.c113 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:633: unreachable reached\0A\00"
@.c114 = private unnamed_addr constant [47 x i8] c"compiler/views.olang:728: unreachable reached\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_Hc36d700dbc0d7c55fb879f7e6bb38bd0(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_H365785b86dec7d6afdc3535b24ecad85(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eRunFrom_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eLen_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0)
declare %"compiler/views:holding" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eAt_3ccompiler_2fviews_3aholding_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eSet_Hdb5ffc4567dd715a7ca5cbd951b61a5b(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:holding" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eLen_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eRunFrom_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H9aa2f94df86a2febe7e9c453722bc668(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H2e2a62b4f845423e00fa2da02073382d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2eRunFrom_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ePush_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, %"compiler/views:place" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/views:place" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2eAt_3ccompiler_2fviews_3aplace_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsInside(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eLen_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ePush_3ccompiler_2fviews_3afact_3e(ptr %v0, ptr %a0, %"compiler/views:fact" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hbdff57143197d3e3ce33a3087c05f7a0(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H10b97bb675358eb10150edb21083f11d(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_He143de49e62ad88ca82ea9d42e5a34cc(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e__Hd7428d759783ef3a1a99ea96b3969ebe(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompi_H63170323aaa56032a7f198353006b630(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eRunF_H64ffd0a400cf6514808343c63d4c8da4(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecGrowsUnderTask(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecTaskHolds(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eRun_He248f280ffb05b128fb35d2cb2cf40a9(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__He2aba1703ae07509d487434bdc4dbdab(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H9b6ab774c92f21a4ef5a53265d5b9504(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Hf233d75f20e205ae94e98cda5dfd15fb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eClear_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2eRunFrom_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__Haabd632b519baafc45866c30c5849be1(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eRunF_H3ad1cdae29ad1a70533744962fbf6680(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ePush_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0, %"compiler/views:tasked" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePo_H0db9b8972766e5b481cadc211ca24c07(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ePush_3ccompiler_2fviews_3astate_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/views:state" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eLen_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eTrun_Hcf69da14cf76298bedfa6131a657bae8(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecHiddenViewStale(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVecViewStale(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteVecGrowsHere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame__H70427050a088bf1a66351c183cb6df24(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eCl_H0a9e00411db21d32682611ff4a2aedde(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ePus_H2c23b7a8de0d438b47a74a1cc30e7335(ptr %v0, ptr %a0, %"compiler/views:holding" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eClo_H3d89fa23a5cc04821e5b80d374f68346(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClone_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2eClone_3ccompiler_2fviews_3atasked_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2eCle_Ha50b8ef86adef4ee8ec69eed192d557f(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eClear_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ePush_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0, %"compiler/views:naming" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"compiler/views:view" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2eSetAt_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/views:view" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_2ePush_3ccompiler_2fviews_3aview_3e(ptr %v0, ptr %a0, %"compiler/views:view" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2eLen_3ccompiler_2fviews_3anaming_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aplace_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fviews_3aview_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3asummary_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aDeclId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fviews_3aloopFrame_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3astate_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3aholding_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3anaming_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3atasked_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fviews_3afact_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
