; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
define dso_local { i64, ptr } @std_2fprelude_2ftext_2ejoinTexts_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l54 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i1
  %l69 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i1
  %l85 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca i1
  %l107 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l25, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = icmp slt i64 %t9, 2147483648
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  %t15 = and i1 %t10, %t12
  store i1 %t15, ptr %l28, !tbaa !21
  br label %bb1
bb1:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l33, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = extractvalue { i64, ptr } %t30, 0
  %t38 = add i64 %t32, %t35
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb1
bb6:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp sgt i64 %t47, 1
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t59 = sub i64 %t57, 1
  %t62 = mul i64 %t54, %t59
  %t65 = add i64 %t51, %t62
  store i64 %t65, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t67 = load i64, ptr %l2, !tbaa !24
  store i64 %t67, ptr %l54, !tbaa !24
  %t68 = load i64, ptr %l54, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb10, label %bb11
bb10:
  %t71 = load i64, ptr %l54, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t76, ptr %lp7
  %t78 = load ptr, ptr %lp7
  store { i64, ptr } %t75, ptr %t78, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l11, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t86 = sub i64 %t85, 1
  store i64 %t86, ptr %l60, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp slt i64 %t87, 2147483648
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  %t93 = and i1 %t88, %t90
  store i1 %t93, ptr %l63, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6124bee271ea27df_40001a175be242b)
  unreachable
bb12:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  br label %bb32
bb14:
  br label %bb15
bb15:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t104, ptr %l69, !tbaa !27
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %t108, i64 %t105
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  store { i64, ptr } %t110, ptr %l13, !tbaa !27
  %t114 = icmp sgt i64 %t102, 0
  br i1 %t114, label %bb16, label %bb17
bb16:
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t116, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l16, !tbaa !24
  %t122 = load i64, ptr %l16, !tbaa !24
  %t123 = sub i64 %t122, 1
  store i64 %t123, ptr %l77, !tbaa !24
  %t124 = load i64, ptr %l16, !tbaa !24
  %t125 = icmp slt i64 %t124, 2147483648
  %t126 = load i64, ptr %l15, !tbaa !24
  %t127 = icmp sge i64 %t126, 0
  %t130 = and i1 %t125, %t127
  store i1 %t130, ptr %l80, !tbaa !21
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t131 = load i64, ptr %l15, !tbaa !24
  %t132 = load i64, ptr %l16, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t139 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t139, ptr %l85, !tbaa !27
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i8, ptr %t143, i64 %t140
  %t145 = load i8, ptr %t144, !tbaa !32
  %t147 = load i64, ptr %l8, !tbaa !24
  %t150 = load ptr, ptr %lp7
  %t152 = getelementptr { i64, ptr }, ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i8, ptr %t153, i64 %t147
  store i8 %t145, ptr %t154, !tbaa !32
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t160 = load i64, ptr %l15, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l15, !tbaa !24
  br label %bb18
bb23:
  br label %bb24
bb24:
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t165, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l20, !tbaa !24
  %t171 = load i64, ptr %l20, !tbaa !24
  %t172 = sub i64 %t171, 1
  store i64 %t172, ptr %l99, !tbaa !24
  %t173 = load i64, ptr %l20, !tbaa !24
  %t174 = icmp slt i64 %t173, 2147483648
  %t175 = load i64, ptr %l19, !tbaa !24
  %t176 = icmp sge i64 %t175, 0
  %t179 = and i1 %t174, %t176
  store i1 %t179, ptr %l102, !tbaa !21
  br label %bb25
bb25:
  %t180 = load i64, ptr %l19, !tbaa !24
  %t181 = load i64, ptr %l20, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t188 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t188, ptr %l107, !tbaa !27
  %t189 = load i64, ptr %l19, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i8, ptr %t192, i64 %t189
  %t194 = load i8, ptr %t193, !tbaa !32
  %t196 = load i64, ptr %l8, !tbaa !24
  %t199 = load ptr, ptr %lp7
  %t201 = getelementptr { i64, ptr }, ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i8, ptr %t202, i64 %t196
  store i8 %t194, ptr %t203, !tbaa !32
  %t204 = load i64, ptr %l8, !tbaa !24
  %t207 = add i64 %t204, 1
  store i64 %t207, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  %t209 = load i64, ptr %l19, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l19, !tbaa !24
  br label %bb25
bb30:
  br label %bb31
bb31:
  %t214 = load i64, ptr %l10, !tbaa !24
  %t217 = add i64 %t214, 1
  store i64 %t217, ptr %l10, !tbaa !24
  br label %bb12
bb32:
  %t219 = load ptr, ptr %lp7
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2ejoinTexts_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l54 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i1
  %l87 = alloca { i64, ptr }
  %l101 = alloca i64
  %l104 = alloca i1
  %l109 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l25, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = icmp slt i64 %t9, 2147483648
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  %t15 = and i1 %t10, %t12
  store i1 %t15, ptr %l28, !tbaa !21
  br label %bb1
bb1:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l33, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = extractvalue { i64, ptr } %t30, 0
  %t38 = add i64 %t32, %t35
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t40, 1
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb1
bb6:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp sgt i64 %t47, 1
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t59 = sub i64 %t57, 1
  %t62 = mul i64 %t54, %t59
  %t65 = add i64 %t51, %t62
  store i64 %t65, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t67 = load i64, ptr %l2, !tbaa !24
  store i64 %t67, ptr %l54, !tbaa !24
  %t68 = load i64, ptr %l54, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb10, label %bb11
bb10:
  %t71 = load i64, ptr %l54, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t76, ptr %lp7
  %t78 = load ptr, ptr %lp7
  store { i64, ptr } %t75, ptr %t78, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l11, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t86 = sub i64 %t85, 1
  store i64 %t86, ptr %l60, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp slt i64 %t87, 2147483648
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  %t93 = and i1 %t88, %t90
  store i1 %t93, ptr %l63, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_b4b3d3a21dffee1a_94412941cff469ee)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s6
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb14:
  br label %bb15
bb15:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t104, ptr %l69, !tbaa !27
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %t108, i64 %t105
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  store { i64, ptr } %t110, ptr %l71, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l72, !tbaa !24
  %t113 = load i64, ptr %l72, !tbaa !24
  %t114 = mul i64 %t113, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l73, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l72, !tbaa !24
  %t123 = mul i64 %t122, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  %t124 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t124, ptr %l13, !tbaa !27
  %t127 = icmp sgt i64 %t102, 0
  br i1 %t127, label %bb16, label %bb17
bb16:
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t129, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  store i64 %t133, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l16, !tbaa !24
  %t136 = sub i64 %t135, 1
  store i64 %t136, ptr %l79, !tbaa !24
  %t137 = load i64, ptr %l16, !tbaa !24
  %t138 = icmp slt i64 %t137, 2147483648
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = icmp sge i64 %t139, 0
  %t143 = and i1 %t138, %t140
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t144 = load i64, ptr %l15, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t152 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t152, ptr %l87, !tbaa !27
  %t153 = load i64, ptr %l15, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i8, ptr %t156, i64 %t153
  %t158 = load i8, ptr %t157, !tbaa !32
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = load ptr, ptr %lp7
  %t165 = getelementptr { i64, ptr }, ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i8, ptr %t166, i64 %t160
  store i8 %t158, ptr %t167, !tbaa !32
  %t168 = load i64, ptr %l8, !tbaa !24
  %t171 = add i64 %t168, 1
  store i64 %t171, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t173 = load i64, ptr %l15, !tbaa !24
  %t176 = add i64 %t173, 1
  store i64 %t176, ptr %l15, !tbaa !24
  br label %bb18
bb23:
  br label %bb24
bb24:
  %t178 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t178, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l20, !tbaa !24
  %t184 = load i64, ptr %l20, !tbaa !24
  %t185 = sub i64 %t184, 1
  store i64 %t185, ptr %l101, !tbaa !24
  %t186 = load i64, ptr %l20, !tbaa !24
  %t187 = icmp slt i64 %t186, 2147483648
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = icmp sge i64 %t188, 0
  %t192 = and i1 %t187, %t189
  store i1 %t192, ptr %l104, !tbaa !21
  br label %bb25
bb25:
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l20, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t201 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t201, ptr %l109, !tbaa !27
  %t202 = load i64, ptr %l19, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i8, ptr %t205, i64 %t202
  %t207 = load i8, ptr %t206, !tbaa !32
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = load ptr, ptr %lp7
  %t214 = getelementptr { i64, ptr }, ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i8, ptr %t215, i64 %t209
  store i8 %t207, ptr %t216, !tbaa !32
  %t217 = load i64, ptr %l8, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  %t222 = load i64, ptr %l19, !tbaa !24
  %t225 = add i64 %t222, 1
  store i64 %t225, ptr %l19, !tbaa !24
  br label %bb25
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t227 = load i64, ptr %l10, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l10, !tbaa !24
  br label %bb12
bb32:
  %t232 = load ptr, ptr %lp7
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_6124bee271ea27df_40001a175be242b = external constant [0 x i8]
@olang_loc_b4b3d3a21dffee1a_94412941cff469ee = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
