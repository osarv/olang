; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { ptr, ptr }, { ptr, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:feed" = type { i64, i64, i64, i64, { i64, [2 x i64] }, { i64, [2 x i64] }, i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, i1, %"compiler/source:Span", { i64, ptr }, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/free:feedCall" = type { i64, i64, i64, i64, i64, i1 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i32, %"compiler/source:Span", { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %l16 = alloca i1
  %l20 = alloca ptr
  %l24 = alloca i1
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l3, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t20, i64 %t21)
  store i1 %t24, ptr %l14
  br label %bb6
bb6:
  %t25 = load i1, ptr %l14, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l20
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb14
bb9:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 11
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/free:Free", ptr %t42, i32 0, i32 93
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t48, ptr %l28
  br label %bb12
bb12:
  %t49 = load i1, ptr %l28, !tbaa !21
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l24, !tbaa !21
  store i1 %t50, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l16, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb33
bb18:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 5}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 5}
  %t69 = icmp eq i64 %t67, 1
  store i1 %t69, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t70 = load i1, ptr %l35, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8ade3a8f9c8eb28_5e24e0670bb9abf4)
  unreachable
bb33:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsHere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/typed:Local"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l24 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l41 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l86 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i1
  %l123 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l131 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10, i64 %t11)
  store %"compiler/typed:Local" %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load %"compiler/typed:Local", ptr %l20
  store %"compiler/typed:Local" %t15, ptr %l4
  %t16 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t17 = load i32, ptr %t16, !range !{i32 0, i32 7}
  %t19 = trunc i64 1 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t24)
  store ptr %t26, ptr %l26
  br label %bb5
bb5:
  %t27 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = load ptr, ptr %l26, !tbaa !29
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t29, i32 %t28)
  store i1 %t31, ptr %l28
  br label %bb6
bb6:
  %t32 = load i1, ptr %l28, !tbaa !21
  store i1 %t32, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendPlaces(ptr %v0, ptr %s0, ptr %t34, i64 %t35, i64 %t36)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l33
  br label %bb10
bb10:
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l33)
  store i64 %t42, ptr %l35
  br label %bb11
bb11:
  %t43 = load i64, ptr %l35, !tbaa !24
  %t44 = icmp eq i64 %t43, 0
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l2, !tbaa !24
  %t54 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emovedLocal(ptr %v0, ptr %t48, i64 %t49, i64 %t50)
  store i1 %t54, ptr %l41
  br label %bb16
bb16:
  %t55 = load i1, ptr %l41, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t66 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emadeLocal(ptr %v0, ptr %v1, ptr %t58, i64 %t59, i64 %t60, ptr %t61)
  store i1 %t66, ptr %l48
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb20
bb19:
  %t67 = load i1, ptr %l48, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l43, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/typed:LocalUses", ptr %t72, i32 0, i32 18
  %t75 = load i64, ptr %l2, !tbaa !24
  %t78 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t74, i64 %t75)
  store i1 %t78, ptr %l54
  br label %bb24
bb24:
  %t79 = load i1, ptr %l54, !tbaa !21
  br i1 %t79, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb28
bb26:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:LocalUses", ptr %t80, i32 0, i32 8
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l59
  br label %bb27
bb27:
  %t87 = load i1, ptr %l59, !tbaa !21
  store i1 %t87, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t88 = load i1, ptr %l55, !tbaa !21
  br i1 %t88, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb32
bb30:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t91, i64 %t92)
  store i1 %t95, ptr %l64
  br label %bb31
bb31:
  %t96 = load i1, ptr %l64, !tbaa !21
  store i1 %t96, ptr %l60, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l60, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb36
bb34:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t98, i32 0, i32 3
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t100, i64 %t101)
  store i1 %t104, ptr %l69
  br label %bb35
bb35:
  %t105 = load i1, ptr %l69, !tbaa !21
  store i1 %t105, ptr %l65, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l65, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb40
bb38:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/typed:LocalUses", ptr %t107, i32 0, i32 4
  %t110 = load i64, ptr %l2, !tbaa !24
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t109, i64 %t110)
  store i1 %t113, ptr %l74
  br label %bb39
bb39:
  %t114 = load i1, ptr %l74, !tbaa !21
  store i1 %t114, ptr %l70, !tbaa !21
  br label %bb40
bb40:
  %t115 = load i1, ptr %l70, !tbaa !21
  br i1 %t115, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb44
bb42:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t120 = getelementptr %"compiler/typed:LocalUses", ptr %t118, i32 0, i32 24
  %t124 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t120, i64 %t116)
  store i1 %t124, ptr %l80
  br label %bb43
bb43:
  %t125 = load i1, ptr %l80, !tbaa !21
  store i1 %t125, ptr %l75, !tbaa !21
  br label %bb44
bb44:
  %t126 = load i1, ptr %l75, !tbaa !21
  br i1 %t126, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb48
bb46:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:LocalUses", ptr %t129, i32 0, i32 19
  %t135 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t131, i64 %t127)
  store i1 %t135, ptr %l86
  br label %bb47
bb47:
  %t136 = load i1, ptr %l86, !tbaa !21
  store i1 %t136, ptr %l81, !tbaa !21
  br label %bb48
bb48:
  %t137 = load i1, ptr %l81, !tbaa !21
  br i1 %t137, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  store i64 0, ptr %l7, !tbaa !24
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t141 = getelementptr %"compiler/typed:LocalUses", ptr %t139, i32 0, i32 27
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t141)
  store i64 %t143, ptr %l90
  br label %bb52
bb52:
  %t144 = load i64, ptr %l90, !tbaa !24
  store i64 %t144, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb53, label %bb54
bb53:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb55, label %bb56
bb54:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb58
bb55:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t156 = load i64, ptr %l7, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l9, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l9, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l97, !tbaa !24
  br label %bb57
bb56:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb57
bb57:
  %t171 = load i64, ptr %l97, !tbaa !24
  store i64 %t171, ptr %l94, !tbaa !24
  br label %bb58
bb58:
  %t172 = load i64, ptr %l94, !tbaa !24
  store i64 %t172, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb59
bb59:
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb60, label %bb61
bb60:
  br label %bb75
bb61:
  br label %bb62
bb62:
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l11, !tbaa !24
  %t183 = load i64, ptr %l9, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l12, !tbaa !24
  %t191 = load ptr, ptr %l3, !tbaa !29
  %t193 = getelementptr %"compiler/typed:LocalUses", ptr %t191, i32 0, i32 27
  %t194 = load i64, ptr %l12, !tbaa !24
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t193, i64 %t194)
  store i64 %t197, ptr %l118
  br label %bb63
bb63:
  %t198 = load i64, ptr %l2, !tbaa !24
  %t199 = load i64, ptr %l118, !tbaa !24
  %t201 = icmp eq i64 %t199, %t198
  br i1 %t201, label %bb64, label %bb65
bb64:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/free:Free", ptr %t203, i32 0, i32 27
  store ptr %t205, ptr %l123, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t206)
  store ptr %t208, ptr %l125
  br label %bb66
bb65:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb70
bb66:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:Free", ptr %t209, i32 0, i32 1
  store ptr %t211, ptr %l127, !tbaa !29
  %t212 = load ptr, ptr %l3, !tbaa !29
  %t214 = getelementptr %"compiler/typed:LocalUses", ptr %t212, i32 0, i32 28
  %t215 = load i64, ptr %l12, !tbaa !24
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t214, i64 %t215)
  store i64 %t218, ptr %l131
  br label %bb67
bb67:
  %t219 = load ptr, ptr %l3, !tbaa !29
  %t221 = getelementptr %"compiler/typed:LocalUses", ptr %t219, i32 0, i32 29
  %t222 = load i64, ptr %l12, !tbaa !24
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t221, i64 %t222)
  store i64 %t225, ptr %l135
  br label %bb68
bb68:
  %t226 = load ptr, ptr %l123, !tbaa !29
  %t227 = load ptr, ptr %l125, !tbaa !29
  %t228 = load ptr, ptr %l127, !tbaa !29
  %t229 = load i64, ptr %l131, !tbaa !24
  %t230 = load i64, ptr %l135, !tbaa !24
  %t231 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v0, ptr %v0, ptr %t226, ptr %t227, ptr %t228, i64 %t229, i64 %t230, i1 false)
  store i1 %t231, ptr %l136
  br label %bb69
bb69:
  %t232 = load i1, ptr %l136, !tbaa !21
  %t233 = xor i1 %t232, true
  store i1 %t233, ptr %l121, !tbaa !21
  br label %bb70
bb70:
  %t235 = load i1, ptr %l121, !tbaa !21
  br i1 %t235, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l11, !tbaa !24
  br label %bb59
bb75:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"compiler/typed:LastUses"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca %"compiler/typed:LastUses"
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l61 = alloca i64
  %l64 = alloca i64
  %l83 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i1
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l165 = alloca i64
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t15 = alloca %"compiler/typed:LastUses", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l27
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l27, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 7
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l30
  br label %bb3
bb3:
  %t16 = load i64, ptr %l30, !tbaa !24
  call void @compiler_2ftyped_3aLastUses_2ector(ptr %t15, ptr %s0, i64 %t16)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t15, i64 336, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l31, i64 336, i1 false)
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Block", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t27 = load i64, ptr %l9, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t34, ptr %l40, !tbaa !27
  %t35 = load i64, ptr %l8, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l10, !tbaa !29
  %t42 = load ptr, ptr %l10, !tbaa !29
  store ptr %t42, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t43 = load ptr, ptr %l43, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l43, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 17}
  %t49 = icmp eq i64 %t47, 12
  store i1 %t49, ptr %l44, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l44, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l10, !tbaa !29
  %t53 = getelementptr { i64, [3 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr }, ptr %t53, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l11, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t57 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %s0, ptr %v1, ptr %l6, ptr %t57)
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3996fae1d7559477_f511e22967edef5b)
  unreachable
bb20:
  br label %bb21
bb21:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = add i64 %t61, 1
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb5
bb22:
  store i64 0, ptr %l12, !tbaa !24
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Block", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load i64, ptr %l14, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb28
bb25:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l14, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l14, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l64, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb27
bb27:
  %t99 = load i64, ptr %l64, !tbaa !24
  store i64 %t99, ptr %l61, !tbaa !24
  br label %bb28
bb28:
  %t100 = load i64, ptr %l61, !tbaa !24
  store i64 %t100, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  %t101 = load i64, ptr %l16, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb30, label %bb31
bb30:
  br label %bb85
bb31:
  br label %bb32
bb32:
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l16, !tbaa !24
  %t111 = load i64, ptr %l14, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l17, !tbaa !24
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Block", ptr %t119, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l83, !tbaa !27
  %t123 = load i64, ptr %l17, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr ptr, ptr %t126, i64 %t123
  %t128 = load ptr, ptr %t127, !tbaa !39
  store ptr %t128, ptr %l18, !tbaa !29
  %t130 = load ptr, ptr %l18, !tbaa !29
  store ptr %t130, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t131 = load ptr, ptr %l86, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t134 = load ptr, ptr %l86, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 17}
  %t137 = icmp eq i64 %t135, 0
  store i1 %t137, ptr %l87, !tbaa !21
  br label %bb34
bb34:
  %t138 = load i1, ptr %l87, !tbaa !21
  br i1 %t138, label %bb35, label %bb36
bb35:
  %t139 = load ptr, ptr %l18, !tbaa !29
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t141, i32 0, i32 1
  %t143 = load i32, ptr %t142
  store i32 %t143, ptr %l19, !tbaa !23
  br label %bb37
bb36:
  br label %bb50
bb37:
  %t145 = getelementptr %"compiler/typed:LastUses", ptr %l6, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l92, !tbaa !27
  %t147 = load i32, ptr %l19, !tbaa !23
  %t149 = sext i32 %t147 to i64
  %t151 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i64, ptr %t152, i64 %t149
  %t154 = load i64, ptr %t153, !tbaa !34
  %t156 = icmp slt i64 %t154, 0
  br i1 %t156, label %bb38, label %bb39
bb38:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l1, !tbaa !24
  %t160 = load i32, ptr %l19, !tbaa !23
  %t162 = sext i32 %t160 to i64
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t168 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsHere(ptr %v0, ptr %v2, ptr %t158, i64 %t159, i64 %t162, ptr %t163)
  store i1 %t168, ptr %l103
  br label %bb40
bb39:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb41
bb40:
  %t169 = load i1, ptr %l103, !tbaa !21
  store i1 %t169, ptr %l97, !tbaa !21
  br label %bb41
bb41:
  %t170 = load i1, ptr %l97, !tbaa !21
  br i1 %t170, label %bb42, label %bb43
bb42:
  %t171 = load ptr, ptr %l2, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Block", ptr %t171, i32 0, i32 1
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l17, !tbaa !24
  %t177 = add i64 %t175, 1
  %t180 = call i1 @compiler_2ftyped_2eRestLeaves(ptr %v1, { i64, ptr } %t174, i64 %t177)
  store i1 %t180, ptr %l109
  br label %bb44
bb43:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb45
bb44:
  %t181 = load i1, ptr %l109, !tbaa !21
  %t182 = xor i1 %t181, true
  store i1 %t182, ptr %l104, !tbaa !21
  br label %bb45
bb45:
  %t184 = load i1, ptr %l104, !tbaa !21
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t185 = load i32, ptr %l19, !tbaa !23
  %t187 = sext i32 %t185 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t187)
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb83
bb50:
  %t190 = load ptr, ptr %l18, !tbaa !29
  store ptr %t190, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t191 = load ptr, ptr %l114, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb51, label %bb52
bb51:
  %t194 = load ptr, ptr %l114, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 17}
  %t197 = icmp eq i64 %t195, 11
  store i1 %t197, ptr %l115, !tbaa !21
  br label %bb52
bb52:
  %t198 = load i1, ptr %l115, !tbaa !21
  br i1 %t198, label %bb53, label %bb54
bb53:
  %t199 = load ptr, ptr %l18, !tbaa !29
  %t201 = getelementptr { i64, [3 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr }, ptr %t201, i32 0, i32 1
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l20, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i64, ptr %l1, !tbaa !24
  %t207 = load ptr, ptr %l20, !tbaa !29
  %t208 = load ptr, ptr %l3, !tbaa !29
  %t209 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t205, i64 %t206, ptr %t207, ptr %t208, ptr %t209)
  br label %bb56
bb56:
  br label %bb83
bb57:
  %t215 = load ptr, ptr %l18, !tbaa !29
  store ptr %t215, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t216 = load ptr, ptr %l125, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb58, label %bb59
bb58:
  %t219 = load ptr, ptr %l125, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 17}
  %t222 = icmp eq i64 %t220, 4
  store i1 %t222, ptr %l126, !tbaa !21
  br label %bb59
bb59:
  %t223 = load i1, ptr %l126, !tbaa !21
  br i1 %t223, label %bb60, label %bb61
bb60:
  %t224 = load ptr, ptr %l18, !tbaa !29
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l21, !tbaa !29
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l1, !tbaa !24
  %t232 = load ptr, ptr %l21, !tbaa !29
  %t233 = load ptr, ptr %l3, !tbaa !29
  %t234 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t230, i64 %t231, ptr %t232, ptr %t233, ptr %t234)
  br label %bb63
bb63:
  br label %bb83
bb64:
  %t240 = load ptr, ptr %l18, !tbaa !29
  store ptr %t240, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t241 = load ptr, ptr %l136, !tbaa !29
  %t242 = icmp ne ptr %t241, null
  br i1 %t242, label %bb65, label %bb66
bb65:
  %t244 = load ptr, ptr %l136, !tbaa !29
  %t245 = load i64, ptr %t244, !range !{i64 0, i64 17}
  %t247 = icmp eq i64 %t245, 3
  store i1 %t247, ptr %l137, !tbaa !21
  br label %bb66
bb66:
  %t248 = load i1, ptr %l137, !tbaa !21
  br i1 %t248, label %bb67, label %bb68
bb67:
  %t249 = load ptr, ptr %l18, !tbaa !29
  %t251 = getelementptr { i64, [3 x i64] }, ptr %t249, i32 0, i32 1
  %t252 = getelementptr { %"compiler/source:Span", ptr }, ptr %t251, i32 0, i32 1
  %t253 = load ptr, ptr %t252
  store ptr %t253, ptr %l22, !tbaa !29
  br label %bb69
bb68:
  br label %bb78
bb69:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l1, !tbaa !24
  %t257 = load ptr, ptr %l22, !tbaa !29
  %t259 = getelementptr %"compiler/typed:If", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load ptr, ptr %l3, !tbaa !29
  %t262 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t255, i64 %t256, ptr %t260, ptr %t261, ptr %t262)
  br label %bb70
bb70:
  %t268 = load ptr, ptr %l22, !tbaa !29
  %t270 = getelementptr %"compiler/typed:If", ptr %t268, i32 0, i32 2
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = icmp eq ptr %t271, null
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb71, label %bb72
bb71:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l152, !tbaa !29
  %t278 = load i64, ptr %l1, !tbaa !24
  store i64 %t278, ptr %l153, !tbaa !24
  %t279 = load ptr, ptr %l22, !tbaa !29
  %t281 = getelementptr %"compiler/typed:If", ptr %t279, i32 0, i32 2
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = icmp eq ptr %t282, null
  br i1 %t284, label %bb73, label %bb74
bb72:
  br label %bb77
bb73:
  call void @__olang_check_failed(ptr @olang_loc_509723034437c60f_ef8201934b6b99c3)
  unreachable
bb74:
  br label %bb75
bb75:
  %t286 = load ptr, ptr %l22, !tbaa !29
  %t288 = getelementptr %"compiler/typed:If", ptr %t286, i32 0, i32 2
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t290 = load ptr, ptr %l3, !tbaa !29
  %t291 = load ptr, ptr %l4, !tbaa !29
  %t292 = load ptr, ptr %l152, !tbaa !29
  %t293 = load i64, ptr %l153, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendsWalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t292, i64 %t293, ptr %t289, ptr %t290, ptr %t291)
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_1457ae29cfe5ec6d_4b85493a75c45e71)
  unreachable
bb83:
  br label %bb84
bb84:
  %t297 = load i64, ptr %l16, !tbaa !24
  %t300 = add i64 %t297, 1
  store i64 %t300, ptr %l16, !tbaa !24
  br label %bb29
bb85:
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t303, ptr %l165
  br label %bb86
bb86:
  %t304 = load i64, ptr %l165, !tbaa !24
  %t305 = icmp sgt i64 %t304, 0
  br i1 %t305, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s16
  %t307 = load ptr, ptr %l4, !tbaa !29
  %t308 = load ptr, ptr %l2, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Block", ptr %t308, i32 0, i32 0
  %t311 = load i32, ptr %t310, !tbaa !23
  %t313 = sext i32 %t311 to i64
  %t314 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v3, ptr %s16, ptr %t307, i64 %t313, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314)
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_scope_close(ptr %s16)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efillParted(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i1
  %l29 = alloca i32
  %l34 = alloca i32
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca %"compiler/free:leaf"
  %l48 = alloca %"compiler/free:leaf"
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l60 = alloca i1
  %l63 = alloca i1
  %l72 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l14, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l18
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = load i32, ptr %l18, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l19
  br label %bb3
bb3:
  %t14 = load i32, ptr %l19, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t22 = trunc i64 19 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb8
bb6:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l29
  br label %bb7
bb7:
  %t32 = load i32, ptr %l29, !tbaa !23
  %t33 = icmp eq i32 %t32, 0
  store i1 %t33, ptr %l26, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l34
  br label %bb12
bb12:
  %t42 = load i32, ptr %l34, !tbaa !23
  store i32 %t42, ptr %l4, !tbaa !23
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l35
  br label %bb13
bb13:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l5
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l4, !tbaa !23
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t45, i32 %t46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l38
  br label %bb14
bb14:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t51 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  store ptr %t51, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l40, !tbaa !24
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %t54)
  store i64 %t56, ptr %l42
  br label %bb16
bb16:
  %t57 = load i64, ptr %l40, !tbaa !24
  %t58 = load i64, ptr %l42, !tbaa !24
  %t59 = icmp slt i64 %t57, %t58
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb18:
  br label %bb19
bb19:
  %t63 = load ptr, ptr %l6, !tbaa !29
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %s2, ptr %t63, i64 %t64)
  store %"compiler/free:leaf" %t67, ptr %l47
  br label %bb20
bb20:
  %t68 = load %"compiler/free:leaf", ptr %l47
  store %"compiler/free:leaf" %t68, ptr %l48
  %t69 = call ptr @__olang_scope_hold(ptr %s3)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l49, !tbaa !24
  %t71 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t73 = call ptr @__olang_region_make_part(ptr %s3)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l49, !tbaa !24
  br label %bb22
bb22:
  %t75 = getelementptr %"compiler/free:leaf", ptr %l48, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l51, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l52, !tbaa !24
  %t79 = load i64, ptr %l52, !tbaa !24
  %t80 = mul i64 %t79, 8
  %t81 = load i64, ptr %l49
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l53, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l52, !tbaa !24
  %t91 = mul i64 %t90, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t93 = getelementptr %"compiler/free:leaf", ptr %l48, i32 0, i32 0
  store { i64, ptr } %t92, ptr %t93, !tbaa !27
  %t94 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t96 = getelementptr %"compiler/free:leaf", ptr %l48, i32 0, i32 0
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t100 = icmp eq i64 %t98, 0
  br i1 %t100, label %bb25, label %bb26
bb24:
  %t102 = load %"compiler/free:leaf", ptr %l48
  store %"compiler/free:leaf" %t102, ptr %l8
  %t103 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp ne i64 %t106, 1
  br i1 %t108, label %bb27, label %bb28
bb25:
  %t110 = getelementptr %"compiler/free:leaf", ptr %l48, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t110, !tbaa !27
  br label %bb26
bb26:
  %t111 = getelementptr %"compiler/free:leaf", ptr %l48, i32 0, i32 0
  %t112 = load i64, ptr %l49
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = load { i64, ptr }, ptr %t111
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = call ptr @__olang_region_or(ptr %t115, ptr null)
  %t117 = icmp ne ptr %t116, null
  %t118 = select i1 %t117, ptr %t116, ptr null
  call void @__olang_region_settle_in(ptr %t113, ptr %t118)
  br label %bb24
bb27:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb30
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t124 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t119, i64 %t121)
  store i1 %t124, ptr %l63
  br label %bb29
bb29:
  %t125 = load i1, ptr %l63, !tbaa !21
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l60, !tbaa !21
  br label %bb30
bb30:
  %t128 = load i1, ptr %l60, !tbaa !21
  br i1 %t128, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t130 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t131)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t137 = add i64 %t134, 1
  store i64 %t137, ptr %l7, !tbaa !24
  br label %bb15
bb36:
  call void @__olang_scope_close(ptr %s2)
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t140, ptr %l72
  br label %bb37
bb37:
  %t141 = load i64, ptr %l72, !tbaa !24
  %t142 = icmp eq i64 %t141, 0
  br i1 %t142, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb39:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l4, !tbaa !23
  %t149 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownersSplit(ptr %v0, ptr %s0, ptr %t144, i32 %t145, ptr %l5)
  store i1 %t149, ptr %l78
  br label %bb40
bb40:
  %t150 = load i1, ptr %l78, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t153 = load i1, ptr %l74, !tbaa !21
  br i1 %t153, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t158 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitOwners(ptr %v0, ptr %s0, ptr %s0, ptr %t155, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %l83
  br label %bb45
bb45:
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l9
  store %olang.scope zeroinitializer, ptr %s7
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s7, ptr %t160, i32 %t161)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l86
  br label %bb46
bb46:
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  %t166 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %t166
  store ptr %t166, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb47
bb47:
  %t168 = load i64, ptr %l11, !tbaa !24
  store i64 %t168, ptr %l88, !tbaa !24
  %t169 = load ptr, ptr %l10, !tbaa !29
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s7, ptr %t169)
  store i64 %t171, ptr %l90
  br label %bb48
bb48:
  %t172 = load i64, ptr %l88, !tbaa !24
  %t173 = load i64, ptr %l90, !tbaa !24
  %t174 = icmp slt i64 %t172, %t173
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb49, label %bb50
bb49:
  br label %bb62
bb50:
  br label %bb51
bb51:
  %t178 = load ptr, ptr %l10, !tbaa !29
  %t179 = load i64, ptr %l11, !tbaa !24
  %t182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s7, ptr %t178, i64 %t179)
  store i64 %t182, ptr %l95
  br label %bb52
bb52:
  %t183 = load i64, ptr %l95, !tbaa !24
  store i64 %t183, ptr %l12, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l12, !tbaa !24
  %t188 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t184, i64 %t185)
  store i1 %t188, ptr %l98
  br label %bb53
bb53:
  %t189 = load i1, ptr %l98, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb54, label %bb55
bb54:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t195 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %l9, i64 %t192)
  store i1 %t195, ptr %l103
  br label %bb56
bb55:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb57
bb56:
  %t196 = load i1, ptr %l103, !tbaa !21
  %t197 = xor i1 %t196, true
  store i1 %t197, ptr %l100, !tbaa !21
  br label %bb57
bb57:
  %t199 = load i1, ptr %l100, !tbaa !21
  br i1 %t199, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t201 = load i64, ptr %l11, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l11, !tbaa !24
  br label %bb47
bb62:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenLetGo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 75
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 78
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb4:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:Free", ptr %t24, i32 0, i32 85
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t31 = load i64, ptr %l18, !tbaa !24
  %t32 = icmp eq i64 %t31, 0
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l14, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l22
  br label %bb14
bb14:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emodelled(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l26
  br label %bb17
bb16:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb18
bb17:
  %t46 = load i1, ptr %l26, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 78
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t53)
  store i1 %t56, ptr %l31
  br label %bb21
bb20:
  br label %bb39
bb21:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb25
bb23:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:Free", ptr %t58, i32 0, i32 85
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l36
  br label %bb24
bb24:
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = icmp ne i64 %t65, 0
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 99
  store i1 true, ptr %t71, !tbaa !21
  br label %bb30
bb27:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 100
  store ptr %t74, ptr %l40, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 75
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t77, i64 %t78)
  store ptr %t81, ptr %l44
  br label %bb28
bb28:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v0, ptr %t82, ptr %t83)
  store i64 %t84, ptr %l45
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 180
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l48, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  %t95 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s5, ptr %t91, i64 %t92)
  store { i64, ptr } %t95, ptr %l51
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t102, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l59
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l59, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 3
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l61, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 1
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t119, i64 %t120)
  store ptr %t123, ptr %l65
  br label %bb35
bb35:
  %t124 = load ptr, ptr %l65, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 4
  %t127 = getelementptr %"compiler/source:Span", ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t131 = load ptr, ptr %l55, !tbaa !29
  %t132 = load i64, ptr %l61, !tbaa !24
  %t134 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s5, ptr %t131, i64 %t132, i64 %t130)
  store { i64, ptr } %t134, ptr %l69
  br label %bb36
bb36:
  %t135 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t137 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  call void @olang_textcopy(ptr %t153, ptr %t141, i64 %t142)
  %t154 = getelementptr i8, ptr %t153, i64 %t142
  call void @olang_textcopy(ptr %t154, ptr %t145, i64 %t146)
  %t155 = getelementptr i8, ptr %t154, i64 %t146
  call void @olang_textcopy(ptr %t155, ptr %t148, i64 %t149)
  %t156 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t151, 1
  %t159 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s5, ptr %t159, { i64, ptr } %t157)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ejoinReached(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l35 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i64
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca %"compiler/source:Span"
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca %"compiler/source:Span"
  %l101 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i32
  %l116 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l128 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca %"compiler/source:Span"
  %l141 = alloca i64
  %l144 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l166 = alloca i64
  %l167 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %t290 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1, i32 0, i32 1
  %t2 = load i64, ptr %t1, !tbaa !24
  store i64 %t2, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 138
  %t7 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %v0, ptr %t6, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l25
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l24
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l26, !tbaa !24
  %t18 = load i64, ptr %l26, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l27, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l26, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l30, !tbaa !24
  %t34 = load i64, ptr %l30, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l30, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t45, ptr %lp4
  %t46 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t47 = load ptr, ptr %lp4
  store { i64, ptr } %t46, ptr %t47, !tbaa !27
  %t48 = load ptr, ptr %lp4
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t51, ptr %l33
  br label %bb5
bb5:
  %t52 = load i1, ptr %l33, !tbaa !21
  store i1 %t52, ptr %l5, !tbaa !21
  %t53 = load i1, ptr %l5, !tbaa !21
  br i1 %t53, label %bb6, label %bb7
bb6:
  %t55 = call ptr @__olang_scope_hold(ptr %v0)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l35, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4
  br i1 %t57, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  %t59 = call ptr @__olang_region_make(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l35, !tbaa !24
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:Free", ptr %t61, i32 0, i32 130
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l38, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l39, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = load i64, ptr %l35
  %t70 = inttoptr i64 %t69 to ptr
  %t71 = call ptr @__olang_held_alloc(ptr %t70, i64 %t68)
  %t72 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l40, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load ptr, ptr %lp4
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t83 = load ptr, ptr %lp4
  store { i64, ptr } %t82, ptr %t83, !tbaa !27
  %t84 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4
  br i1 %t84, label %bb10, label %bb11
bb10:
  %t86 = load { i64, ptr }, ptr %l41
  %t87 = extractvalue { i64, ptr } %t86, 1
  call void @__olang_region_release(ptr %t87)
  store { i64, ptr } zeroinitializer, ptr %l41
  br label %bb11
bb11:
  %t88 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = load ptr, ptr %lp4
  %t91 = load i64, ptr %l35
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = load { i64, ptr }, ptr %t90
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = call ptr @__olang_region_or(ptr %t94, ptr null)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr null
  call void @__olang_region_settle_in(ptr %t92, ptr %t97)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t98 = load ptr, ptr %lp4
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t99, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t101, ptr %l45
  br label %bb15
bb15:
  %t102 = load i1, ptr %l45, !tbaa !21
  br i1 %t102, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t103 = call ptr @__olang_scope_hold(ptr %v0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l46, !tbaa !24
  %t105 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4
  br i1 %t105, label %bb19, label %bb20
bb19:
  %t107 = call ptr @__olang_region_make(ptr %v0)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l46, !tbaa !24
  br label %bb20
bb20:
  %t109 = load ptr, ptr %lp4
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = extractvalue { i64, ptr } %t110, 0
  %t114 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = load i64, ptr %l46
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = call ptr @__olang_held_alloc(ptr %t118, i64 %t116)
  call void @olang_textcopy(ptr %t119, ptr %t112, i64 %t113)
  %t120 = getelementptr i8, ptr %t119, i64 %t113
  call void @olang_textcopy(ptr %t120, ptr %t114, i64 %t115)
  %t121 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  store { i64, ptr } %t122, ptr %l49, !tbaa !27
  %t123 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4
  br i1 %t123, label %bb21, label %bb22
bb21:
  %t125 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t128 = icmp eq i64 %t126, 0
  br i1 %t128, label %bb23, label %bb24
bb22:
  %t130 = load ptr, ptr %lp4
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l53, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t133 = load ptr, ptr %lp4
  store { i64, ptr } %t132, ptr %t133, !tbaa !27
  %t134 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4
  br i1 %t134, label %bb25, label %bb26
bb23:
  store { i64, ptr } zeroinitializer, ptr %l49, !tbaa !27
  br label %bb24
bb24:
  %t136 = load i64, ptr %l46
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = load { i64, ptr }, ptr %l49
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr null
  call void @__olang_region_settle_in(ptr %t137, ptr %t142)
  br label %bb22
bb25:
  %t143 = load { i64, ptr }, ptr %l53
  %t144 = extractvalue { i64, ptr } %t143, 1
  call void @__olang_region_release(ptr %t144)
  store { i64, ptr } zeroinitializer, ptr %l53
  br label %bb26
bb26:
  %t145 = load i1, ptr %l5, !tbaa !21
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb27, label %bb28
bb27:
  %t149 = load i64, ptr %l3, !tbaa !24
  %t150 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  %t153 = icmp ne i64 %t149, %t150
  br i1 %t153, label %bb29, label %bb30
bb28:
  br label %bb48
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l60, !tbaa !29
  %t156 = load i64, ptr %l3, !tbaa !24
  store i64 %t156, ptr %l61, !tbaa !24
  %t157 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t157, ptr %l62, !tbaa !24
  %t158 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 0, i32 0)
  store %"compiler/source:Span" %t158, ptr %l63
  br label %bb31
bb30:
  store i64 0, ptr %l6, !tbaa !24
  %t159 = load i64, ptr %l2, !tbaa !24
  store i64 %t159, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t161 = load i64, ptr %l7, !tbaa !24
  %t162 = load i64, ptr %l6, !tbaa !24
  %t165 = icmp sgt i64 %t161, %t162
  br i1 %t165, label %bb33, label %bb34
bb31:
  %t167 = load ptr, ptr %lp4
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = load ptr, ptr %l60, !tbaa !29
  %t170 = load i64, ptr %l61, !tbaa !24
  %t171 = load i64, ptr %l62, !tbaa !24
  %t172 = load %"compiler/source:Span", ptr %l63
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t169, i64 %t170, i64 %t171, i64 -1, %"compiler/source:Span" %t172, { i64, ptr } %t168)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb33:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t176 = icmp sgt i64 %t174, 0
  br i1 %t176, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb38
bb35:
  %t178 = load i64, ptr %l7, !tbaa !24
  %t179 = load i64, ptr %l6, !tbaa !24
  %t182 = sub i64 %t178, %t179
  %t183 = load i64, ptr %l8, !tbaa !24
  %t186 = add i64 %t182, %t183
  %t188 = sub i64 %t186, 1
  %t189 = load i64, ptr %l8, !tbaa !24
  %t192 = sdiv i64 %t188, %t189
  store i64 %t192, ptr %l72, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb37
bb37:
  %t194 = load i64, ptr %l72, !tbaa !24
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb38
bb38:
  %t195 = load i64, ptr %l69, !tbaa !24
  store i64 %t195, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t196 = load i64, ptr %l10, !tbaa !24
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = icmp slt i64 %t196, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t204 = load i64, ptr %l6, !tbaa !24
  %t205 = load i64, ptr %l10, !tbaa !24
  %t206 = load i64, ptr %l8, !tbaa !24
  %t209 = mul i64 %t205, %t206
  %t212 = add i64 %t204, %t209
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l90, !tbaa !29
  store i64 %t212, ptr %l91, !tbaa !24
  %t216 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t216, ptr %l92, !tbaa !24
  %t217 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t217, ptr %l93
  br label %bb43
bb43:
  %t218 = load ptr, ptr %lp4
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t220 = load ptr, ptr %l90, !tbaa !29
  %t221 = load i64, ptr %l91, !tbaa !24
  %t222 = load i64, ptr %l92, !tbaa !24
  %t223 = load %"compiler/source:Span", ptr %l93
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t220, i64 %t221, i64 %t222, i64 -1, %"compiler/source:Span" %t223, { i64, ptr } %t219)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  %t225 = load i64, ptr %l10, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l10, !tbaa !24
  br label %bb39
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb48:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/free:Free", ptr %t230, i32 0, i32 132
  %t233 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1, i32 0, i32 0
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2eHas_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %t232, i64 %t234)
  store i1 %t237, ptr %l101
  br label %bb49
bb49:
  %t238 = load i1, ptr %l101, !tbaa !21
  %t239 = xor i1 %t238, true
  br i1 %t239, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 132
  store ptr %t243, ptr %l104, !tbaa !29
  %t244 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1, i32 0, i32 0
  %t245 = load i64, ptr %t244, !tbaa !24
  store i64 %t245, ptr %l105, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1, i32 0, i32 0
  %t248 = load i64, ptr %t247, !tbaa !24
  %t249 = load i64, ptr %l2, !tbaa !24
  %t253 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobReach(ptr %v0, ptr %s10, ptr %t246, i64 %t248, i64 %t249)
  store { i64, ptr } %t253, ptr %l109
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t254 = load ptr, ptr %l104, !tbaa !29
  %t255 = load i64, ptr %l105, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l109, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2ePut_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %t254, i64 %t255, { i64, ptr } %t256)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/free:Free", ptr %t257, i32 0, i32 132
  %t260 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1, i32 0, i32 0
  %t261 = load i64, ptr %t260, !tbaa !24
  %t264 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2eGet_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %s0, ptr %t259, i64 %t261)
  %t265 = extractvalue { i32, { i64, ptr } } %t264, 1
  %t266 = extractvalue { i32, { i64, ptr } } %t264, 0
  store i32 %t266, ptr %l115
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb56, label %ok.268, !prof !99
ok.268:
  store { i64, ptr } %t265, ptr %l114
  br label %bb55
bb55:
  %t269 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l116, !tbaa !24
  %t271 = load i64, ptr %l116, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l117, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l116, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t282, ptr %l110, !tbaa !27
  br label %bb60
bb56:
  br label %bb57
bb57:
  %t283 = load i64, ptr %l2, !tbaa !24
  store i64 %t283, ptr %l118, !tbaa !24
  %t284 = load i64, ptr %l118, !tbaa !24
  %t285 = icmp sge i64 %t284, 0
  br i1 %t285, label %bb58, label %bb59
bb58:
  %t287 = load i64, ptr %l118, !tbaa !24
  %t288 = mul i64 %t287, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t288)
  store i64 0, ptr %t290
  br label %fill.291
fill.291:
  %t294 = load i64, ptr %t290
  %t295 = icmp slt i64 %t294, %t287
  br i1 %t295, label %fillb.292, label %filld.293
fillb.292:
  %t296 = getelementptr i1, ptr %t289, i64 %t294
  store i1 true, ptr %t296
  %t297 = add i64 %t294, 1
  store i64 %t297, ptr %t290
  br label %fill.291
filld.293:
  %t298 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t289, 1
  store { i64, ptr } %t299, ptr %l110, !tbaa !27
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_af64c4abd7ad73bb_8da5f4f674882a7f)
  unreachable
bb60:
  %t301 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  %t302 = load i64, ptr %l3, !tbaa !24
  %t303 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  %t306 = icmp ne i64 %t302, %t303
  br i1 %t306, label %bb61, label %bb62
bb61:
  %t308 = load i64, ptr %l3, !tbaa !24
  %t309 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t314 = icmp slt i64 %t308, %t311
  br i1 %t314, label %bb63, label %bb64
bb62:
  br label %bb71
bb63:
  %t316 = load i64, ptr %l3, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i1, ptr %t319, i64 %t316
  %t321 = load i1, ptr %t320, !tbaa !31
  store i1 %t321, ptr %l128, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb65
bb65:
  %t323 = load i1, ptr %l128, !tbaa !21
  br i1 %t323, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s12
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l131, !tbaa !29
  %t325 = load i64, ptr %l3, !tbaa !24
  store i64 %t325, ptr %l132, !tbaa !24
  %t326 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t326, ptr %l133, !tbaa !24
  %t327 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 0, i32 0)
  store %"compiler/source:Span" %t327, ptr %l134
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t328 = load ptr, ptr %lp4
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  %t330 = load ptr, ptr %l131, !tbaa !29
  %t331 = load i64, ptr %l132, !tbaa !24
  %t332 = load i64, ptr %l133, !tbaa !24
  %t333 = load %"compiler/source:Span", ptr %l134
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t330, i64 %t331, i64 %t332, i64 -1, %"compiler/source:Span" %t333, { i64, ptr } %t329)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s12)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb71:
  store i64 0, ptr %l13, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t339 = load i64, ptr %l14, !tbaa !24
  %t340 = load i64, ptr %l13, !tbaa !24
  %t343 = icmp sgt i64 %t339, %t340
  br i1 %t343, label %bb72, label %bb73
bb72:
  %t345 = load i64, ptr %l15, !tbaa !24
  %t347 = icmp sgt i64 %t345, 0
  br i1 %t347, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb77
bb74:
  %t349 = load i64, ptr %l14, !tbaa !24
  %t350 = load i64, ptr %l13, !tbaa !24
  %t353 = sub i64 %t349, %t350
  %t354 = load i64, ptr %l15, !tbaa !24
  %t357 = add i64 %t353, %t354
  %t359 = sub i64 %t357, 1
  %t360 = load i64, ptr %l15, !tbaa !24
  %t363 = sdiv i64 %t359, %t360
  store i64 %t363, ptr %l144, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb76
bb76:
  %t365 = load i64, ptr %l144, !tbaa !24
  store i64 %t365, ptr %l141, !tbaa !24
  br label %bb77
bb77:
  %t366 = load i64, ptr %l141, !tbaa !24
  store i64 %t366, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb78
bb78:
  %t367 = load i64, ptr %l17, !tbaa !24
  %t368 = load i64, ptr %l16, !tbaa !24
  %t371 = icmp slt i64 %t367, %t368
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb79, label %bb80
bb79:
  br label %bb88
bb80:
  br label %bb81
bb81:
  %t375 = load i64, ptr %l13, !tbaa !24
  %t376 = load i64, ptr %l17, !tbaa !24
  %t377 = load i64, ptr %l15, !tbaa !24
  %t380 = mul i64 %t376, %t377
  %t383 = add i64 %t375, %t380
  store i64 %t383, ptr %l18, !tbaa !24
  %t385 = load i64, ptr %l18, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i1, ptr %t388, i64 %t385
  %t390 = load i1, ptr %t389, !tbaa !31
  br i1 %t390, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l164, !tbaa !29
  %t393 = load i64, ptr %l18, !tbaa !24
  store i64 %t393, ptr %l165, !tbaa !24
  %t394 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t394, ptr %l166, !tbaa !24
  %t395 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s15, i32 0, i32 0)
  store %"compiler/source:Span" %t395, ptr %l167
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t396 = load ptr, ptr %lp4
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  %t398 = load ptr, ptr %l164, !tbaa !29
  %t399 = load i64, ptr %l165, !tbaa !24
  %t400 = load i64, ptr %l166, !tbaa !24
  %t401 = load %"compiler/source:Span", ptr %l167
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t398, i64 %t399, i64 %t400, i64 -1, %"compiler/source:Span" %t401, { i64, ptr } %t397)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t403 = load i64, ptr %l17, !tbaa !24
  %t406 = add i64 %t403, 1
  store i64 %t406, ptr %l17, !tbaa !24
  br label %bb78
bb88:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:leaf"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i32
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/free:leaf"
  %l119 = alloca %"compiler/free:leaf"
  %l121 = alloca { i64, ptr }
  %l124 = alloca i32
  %l127 = alloca i32
  %l130 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i32
  %l144 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l146 = alloca i64
  %l148 = alloca i64
  %l153 = alloca %"compiler/free:leaf"
  %l154 = alloca %"compiler/free:leaf"
  %l155 = alloca i64
  %l157 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca { i64, ptr }
  %l165 = alloca i64
  %l175 = alloca i64
  %l178 = alloca i64
  %l187 = alloca i64
  %l190 = alloca i1
  %l207 = alloca ptr
  %l210 = alloca %"compiler/free:leaf"
  %l212 = alloca %"compiler/free:leaf"
  %l220 = alloca ptr
  %l221 = alloca i32
  %l222 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l224 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l27, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l30
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l27, !tbaa !29
  %t12 = load i32, ptr %l30, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l31
  br label %bb3
bb3:
  %t14 = load i32, ptr %l31, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l32
  br label %bb4
bb4:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l4
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l35
  br label %bb5
bb5:
  %t22 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb9
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l42
  br label %bb8
bb8:
  %t34 = load i1, ptr %l42, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l39, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb14
bb11:
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l45, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l48
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l45, !tbaa !29
  %t45 = load i32, ptr %l48, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t46, ptr %l49
  br label %bb13
bb13:
  %t47 = load i32, ptr %l49, !range !{i32 0, i32 6}
  %t49 = trunc i64 0 to i32
  %t50 = icmp eq i32 %t47, %t49
  %t52 = xor i1 %t50, true
  store i1 %t52, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l44, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 19
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He7b3466db9a608577543dd7c0832d3d6(ptr %v0, ptr %v1, ptr %t59, i32 %t60)
  %t64 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t63, 1
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t63, 0
  store i32 %t65, ptr %l59
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb19, label %ok.67, !prof !99
ok.67:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l58
  br label %bb18
bb18:
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %l58)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l61
  br label %bb21
bb19:
  br label %bb20
bb20:
  %t70 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l62
  br label %bb22
bb21:
  %t71 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l54
  br label %bb23
bb22:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l54
  br label %bb23
bb23:
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l5
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 19
  %t77 = load i32, ptr %l3, !tbaa !23
  %t80 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H39ca684a9144c6cba1af5dc2ea7b2e34(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l66
  br label %bb24
bb24:
  %t81 = load i1, ptr %l66, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:Free", ptr %t84, i32 0, i32 19
  store ptr %t86, ptr %l69, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  store i32 %t87, ptr %l70, !tbaa !23
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l71
  %t90 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l71)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l73
  br label %bb28
bb28:
  %t91 = load ptr, ptr %l69, !tbaa !29
  %t92 = load i32, ptr %l70, !tbaa !23
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %s0, ptr %t91, i32 %t92, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93)
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l2, !tbaa !29
  store ptr %t94, ptr %l74, !tbaa !29
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i32, ptr %l3, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l77
  br label %bb30
bb30:
  %t100 = load ptr, ptr %l74, !tbaa !29
  %t101 = load i32, ptr %l77, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t100, i32 %t101)
  store { i64, ptr } %t102, ptr %l78
  br label %bb31
bb31:
  %t103 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t103, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb34:
  %t118 = load i64, ptr %l8, !tbaa !24
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l87, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t134 = load i64, ptr %l87, !tbaa !24
  store i64 %t134, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t135 = load i64, ptr %l84, !tbaa !24
  store i64 %t135, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb39, label %bb40
bb39:
  br label %bb100
bb40:
  br label %bb41
bb41:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l9, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  store i64 %t152, ptr %l12, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l3, !tbaa !23
  %t156 = load i64, ptr %l12, !tbaa !24
  %t160 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t154, i32 %t155, i64 %t156)
  store i64 %t160, ptr %l108
  br label %bb42
bb42:
  %t161 = load i64, ptr %l108, !tbaa !24
  store i64 %t161, ptr %l13, !tbaa !24
  %t162 = load i64, ptr %l13, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l111, !tbaa !29
  %t166 = call ptr @__olang_scope_hold(ptr %s5)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l112, !tbaa !24
  %t168 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t168, label %bb45, label %bb46
bb44:
  br label %bb50
bb45:
  %t170 = call ptr @__olang_region_make_part(ptr %s5)
  %t171 = ptrtoint ptr %t170 to i64
  store i64 %t171, ptr %l112, !tbaa !24
  br label %bb46
bb46:
  %t172 = load i64, ptr %l12, !tbaa !24
  %t173 = mul i64 1, 8
  %t174 = load i64, ptr %l112
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %t175, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 1, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l115, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i64, ptr %t181, i64 0
  store i64 %t172, ptr %t182, !tbaa !34
  %t183 = load i64, ptr %l13, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t186 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s5, { i64, ptr } %t184, i64 %t183)
  store %"compiler/free:leaf" %t186, ptr %l117
  br label %bb47
bb47:
  %t188 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s5, ptr %l117)
  store %"compiler/free:leaf" %t188, ptr %l119
  br label %bb48
bb48:
  %t189 = load ptr, ptr %l111, !tbaa !29
  %t190 = load %"compiler/free:leaf", ptr %l119
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s5, ptr %t189, %"compiler/free:leaf" %t190)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb99
bb50:
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t192, ptr %l121, !tbaa !27
  %t193 = load i64, ptr %l12, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t191, i32 %t198)
  store i32 %t201, ptr %l124
  br label %bb51
bb51:
  %t202 = load i32, ptr %l124, !tbaa !23
  store i32 %t202, ptr %l14, !tbaa !23
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t204 = load i32, ptr %l14, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l127
  br label %bb52
bb52:
  %t208 = load i32, ptr %l127, !range !{i32 0, i32 33}
  %t210 = trunc i64 18 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb53, label %bb54
bb53:
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t214 = load i32, ptr %l14, !tbaa !23
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l133
  br label %bb55
bb54:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb56
bb55:
  %t218 = load i1, ptr %l133, !tbaa !21
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb56
bb56:
  %t219 = load i1, ptr %l130, !tbaa !21
  br i1 %t219, label %bb57, label %bb58
bb57:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l135, !tbaa !29
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l138
  br label %bb59
bb58:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb61
bb59:
  %t226 = load ptr, ptr %l135, !tbaa !29
  %t227 = load i32, ptr %l138, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l139
  br label %bb60
bb60:
  %t229 = load i32, ptr %l139, !range !{i32 0, i32 6}
  %t231 = trunc i64 0 to i32
  %t232 = icmp eq i32 %t229, %t231
  store i1 %t232, ptr %l134, !tbaa !21
  br label %bb61
bb61:
  %t234 = load i1, ptr %l134, !tbaa !21
  br i1 %t234, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l14, !tbaa !23
  %t239 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s7, ptr %t235, i32 %t236)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l144
  br label %bb64
bb63:
  br label %bb98
bb64:
  %t240 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144
  %t241 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %t241
  store ptr %t241, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s8
  %t243 = load i64, ptr %l16, !tbaa !24
  store i64 %t243, ptr %l146, !tbaa !24
  %t244 = load ptr, ptr %l15, !tbaa !29
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %t244)
  store i64 %t246, ptr %l148
  br label %bb66
bb66:
  %t247 = load i64, ptr %l146, !tbaa !24
  %t248 = load i64, ptr %l148, !tbaa !24
  %t249 = icmp slt i64 %t247, %t248
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb97
bb68:
  br label %bb69
bb69:
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t254 = load i64, ptr %l16, !tbaa !24
  %t257 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %s7, ptr %t253, i64 %t254)
  store %"compiler/free:leaf" %t257, ptr %l153
  br label %bb70
bb70:
  %t258 = load %"compiler/free:leaf", ptr %l153
  store %"compiler/free:leaf" %t258, ptr %l154
  %t259 = call ptr @__olang_scope_hold(ptr %s8)
  %t260 = ptrtoint ptr %t259 to i64
  store i64 %t260, ptr %l155, !tbaa !24
  %t261 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t261, label %bb71, label %bb72
bb71:
  %t263 = call ptr @__olang_region_make_part(ptr %s8)
  %t264 = ptrtoint ptr %t263 to i64
  store i64 %t264, ptr %l155, !tbaa !24
  br label %bb72
bb72:
  %t265 = getelementptr %"compiler/free:leaf", ptr %l154, i32 0, i32 0
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l157, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 0
  store i64 %t268, ptr %l158, !tbaa !24
  %t269 = load i64, ptr %l158, !tbaa !24
  %t270 = mul i64 %t269, 8
  %t271 = load i64, ptr %l155
  %t272 = inttoptr i64 %t271 to ptr
  %t273 = call ptr @__olang_held_alloc(ptr %t272, i64 %t270)
  %t274 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l159, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l158, !tbaa !24
  %t281 = mul i64 %t280, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t283 = getelementptr %"compiler/free:leaf", ptr %l154, i32 0, i32 0
  store { i64, ptr } %t282, ptr %t283, !tbaa !27
  %t284 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t284, label %bb73, label %bb74
bb73:
  %t286 = getelementptr %"compiler/free:leaf", ptr %l154, i32 0, i32 0
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  %t290 = icmp eq i64 %t288, 0
  br i1 %t290, label %bb75, label %bb76
bb74:
  %t292 = load %"compiler/free:leaf", ptr %l154
  store %"compiler/free:leaf" %t292, ptr %l17
  %t293 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l165, !tbaa !24
  %t299 = load i64, ptr %l165, !tbaa !24
  %t300 = icmp sge i64 %t299, 0
  br i1 %t300, label %bb77, label %bb78
bb75:
  %t302 = getelementptr %"compiler/free:leaf", ptr %l154, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t302, !tbaa !27
  br label %bb76
bb76:
  %t303 = getelementptr %"compiler/free:leaf", ptr %l154, i32 0, i32 0
  %t304 = load i64, ptr %l155
  %t305 = inttoptr i64 %t304 to ptr
  %t306 = load { i64, ptr }, ptr %t303
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = call ptr @__olang_region_or(ptr %t307, ptr null)
  %t309 = icmp ne ptr %t308, null
  %t310 = select i1 %t309, ptr %t308, ptr null
  call void @__olang_region_settle_in(ptr %t305, ptr %t310)
  br label %bb74
bb77:
  %t311 = load i64, ptr %l165, !tbaa !24
  %t312 = icmp sle i64 %t311, 1152921504606846975
  br i1 %t312, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd)
  unreachable
bb79:
  %t314 = load i64, ptr %l165, !tbaa !24
  %t315 = mul i64 %t314, 8
  %t316 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t315)
  %t317 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  store { i64, ptr } %t318, ptr %l18, !tbaa !27
  %t320 = load i64, ptr %l12, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i64, ptr %t323, i64 0
  store i64 %t320, ptr %t324, !tbaa !34
  store i64 0, ptr %l19, !tbaa !24
  %t325 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t326, 0
  store i64 %t328, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t330 = load i64, ptr %l20, !tbaa !24
  %t331 = load i64, ptr %l19, !tbaa !24
  %t334 = icmp sgt i64 %t330, %t331
  br i1 %t334, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd)
  unreachable
bb81:
  %t336 = load i64, ptr %l21, !tbaa !24
  %t338 = icmp sgt i64 %t336, 0
  br i1 %t338, label %bb83, label %bb84
bb82:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb86
bb83:
  %t340 = load i64, ptr %l20, !tbaa !24
  %t341 = load i64, ptr %l19, !tbaa !24
  %t344 = sub i64 %t340, %t341
  %t345 = load i64, ptr %l21, !tbaa !24
  %t348 = add i64 %t344, %t345
  %t350 = sub i64 %t348, 1
  %t351 = load i64, ptr %l21, !tbaa !24
  %t354 = sdiv i64 %t350, %t351
  store i64 %t354, ptr %l178, !tbaa !24
  br label %bb85
bb84:
  store i64 0, ptr %l178, !tbaa !24
  br label %bb85
bb85:
  %t356 = load i64, ptr %l178, !tbaa !24
  store i64 %t356, ptr %l175, !tbaa !24
  br label %bb86
bb86:
  %t357 = load i64, ptr %l175, !tbaa !24
  store i64 %t357, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t358 = load i64, ptr %l22, !tbaa !24
  %t359 = sub i64 %t358, 1
  store i64 %t359, ptr %l187, !tbaa !24
  %t360 = load i64, ptr %l22, !tbaa !24
  %t361 = icmp slt i64 %t360, 2147483648
  %t362 = load i64, ptr %l23, !tbaa !24
  %t363 = icmp sge i64 %t362, 0
  %t366 = and i1 %t361, %t363
  store i1 %t366, ptr %l190, !tbaa !21
  br label %bb87
bb87:
  %t367 = load i64, ptr %l23, !tbaa !24
  %t368 = load i64, ptr %l22, !tbaa !24
  %t371 = icmp slt i64 %t367, %t368
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb88, label %bb89
bb88:
  br label %bb92
bb89:
  br label %bb90
bb90:
  %t375 = load i64, ptr %l19, !tbaa !24
  %t376 = load i64, ptr %l23, !tbaa !24
  %t377 = load i64, ptr %l21, !tbaa !24
  %t380 = mul i64 %t376, %t377
  %t383 = add i64 %t375, %t380
  store i64 %t383, ptr %l24, !tbaa !24
  %t385 = load i64, ptr %l24, !tbaa !24
  %t387 = add i64 %t385, 1
  %t388 = load i64, ptr %l24, !tbaa !24
  %t389 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t391 = getelementptr { i64, ptr }, ptr %t389, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr i64, ptr %t392, i64 %t388
  %t394 = load i64, ptr %t393, !tbaa !34
  %t397 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = getelementptr i64, ptr %t398, i64 %t387
  store i64 %t394, ptr %t399, !tbaa !34
  br label %bb91
bb91:
  %t400 = load i64, ptr %l23, !tbaa !24
  %t403 = add i64 %t400, 1
  store i64 %t403, ptr %l23, !tbaa !24
  br label %bb87
bb92:
  store ptr %l4, ptr %l207, !tbaa !29
  %t405 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t406 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t407 = load i64, ptr %t406, !tbaa !24
  %t410 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s8, { i64, ptr } %t405, i64 %t407)
  store %"compiler/free:leaf" %t410, ptr %l210
  br label %bb93
bb93:
  %t412 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s8, ptr %l210)
  store %"compiler/free:leaf" %t412, ptr %l212
  br label %bb94
bb94:
  %t413 = load ptr, ptr %l207, !tbaa !29
  %t414 = load %"compiler/free:leaf", ptr %l212
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s8, ptr %t413, %"compiler/free:leaf" %t414)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s8)
  br label %bb96
bb96:
  %t415 = load i64, ptr %l16, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l16, !tbaa !24
  br label %bb65
bb97:
  call void @__olang_scope_close(ptr %s7)
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t420 = load i64, ptr %l11, !tbaa !24
  %t423 = add i64 %t420, 1
  store i64 %t423, ptr %l11, !tbaa !24
  br label %bb38
bb100:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/free:Free", ptr %t425, i32 0, i32 19
  store ptr %t427, ptr %l220, !tbaa !29
  %t428 = load i32, ptr %l3, !tbaa !23
  store i32 %t428, ptr %l221, !tbaa !23
  %t429 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t429, ptr %l222
  %t431 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l222)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t431, ptr %l224
  br label %bb101
bb101:
  %t432 = load ptr, ptr %l220, !tbaa !29
  %t433 = load i32, ptr %l221, !tbaa !23
  %t434 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l224
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %s0, ptr %t432, i32 %t433, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t434)
  br label %bb102
bb102:
  %t435 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t435, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2elibraryGaps(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:letGo"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/free:reason"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/free:letGo"
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i1
  %l71 = alloca { i64, ptr }
  %l76 = alloca i1
  %l78 = alloca i1
  %l83 = alloca i1
  %l87 = alloca i64
  %l91 = alloca i64
  %l95 = alloca i1
  %l99 = alloca i1
  %l106 = alloca %"compiler/free:reason"
  %l109 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i64
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 4
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 102
  store ptr %t16, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l4, !tbaa !24
  store i64 %t18, ptr %l20, !tbaa !24
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l22
  br label %bb3
bb3:
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = load i64, ptr %l22, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/free:letGo" %t32, ptr %l27
  br label %bb7
bb7:
  %t33 = load %"compiler/free:letGo", ptr %l27
  store %"compiler/free:letGo" %t33, ptr %l5
  %t34 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  %t41 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 8
  %t42 = load i1, ptr %t41, !tbaa !21
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l31, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb13
bb12:
  %t47 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 5
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t52 = icmp ne i64 %t48, %t49
  store i1 %t52, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t54 = load i1, ptr %l34, !tbaa !21
  br i1 %t54, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb16
bb15:
  %t55 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 7
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp slt i64 %t56, 0
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb20
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:Free", ptr %t61, i32 0, i32 30
  %t64 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t65)
  store i1 %t68, ptr %l45
  br label %bb19
bb19:
  %t69 = load i1, ptr %l45, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l41, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb24
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 30
  %t76 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 7
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t75, i64 %t77)
  store i1 %t80, ptr %l51
  br label %bb23
bb23:
  %t81 = load i1, ptr %l51, !tbaa !21
  store i1 %t81, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t82 = load i1, ptr %l47, !tbaa !21
  br i1 %t82, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb26:
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l54
  br label %bb28
bb28:
  %t88 = load i1, ptr %l54, !tbaa !21
  br i1 %t88, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb32
bb30:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epartsFree(ptr %v0, ptr %t89, i64 %t90, i64 0)
  store i1 %t93, ptr %l58
  br label %bb31
bb31:
  %t94 = load i1, ptr %l58, !tbaa !21
  store i1 %t94, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb40
bb34:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 5
  %t103 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l63
  br label %bb35
bb35:
  %t104 = load i64, ptr %l63, !tbaa !24
  %t105 = icmp sgt i64 %t104, 0
  br i1 %t105, label %bb36, label %bb37
bb36:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l6, !tbaa !24
  %t111 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %t107, i64 %t108)
  store i1 %t111, ptr %l68
  br label %bb38
bb37:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb39
bb38:
  %t112 = load i1, ptr %l68, !tbaa !21
  store i1 %t112, ptr %l65, !tbaa !21
  br label %bb39
bb39:
  %t113 = load i1, ptr %l65, !tbaa !21
  store i1 %t113, ptr %l59, !tbaa !21
  br label %bb40
bb40:
  %t114 = load i1, ptr %l59, !tbaa !21
  br i1 %t114, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb42:
  br label %bb43
bb43:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 7
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s2, ptr %t115, i64 %t117)
  store { i64, ptr } %t120, ptr %l71
  br label %bb44
bb44:
  %t121 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t121, ptr %l7, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = insertvalue { i64, ptr } undef, i64 9, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr @G_2ecompiler_2ffree_2eRemovalNames, 1
  %t128 = load ptr, ptr @__olang_prog_scope
  %t131 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t128, ptr %s2, { i64, ptr } %t126, { i64, ptr } %t122)
  store i1 %t131, ptr %l76
  br label %bb45
bb45:
  %t132 = load i1, ptr %l76, !tbaa !21
  %t133 = xor i1 %t132, true
  br i1 %t133, label %bb46, label %bb47
bb46:
  %t135 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t138 = insertvalue { i64, ptr } undef, i64 2, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr @G_2ecompiler_2ffree_2eGapCalls, 1
  %t141 = load ptr, ptr @__olang_prog_scope
  %t144 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t141, ptr %s2, { i64, ptr } %t139, { i64, ptr } %t135)
  store i1 %t144, ptr %l83
  br label %bb48
bb47:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb49
bb48:
  %t145 = load i1, ptr %l83, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l78, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l78, !tbaa !21
  br i1 %t148, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb51:
  br label %bb52
bb52:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l6, !tbaa !24
  %t153 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitPart(ptr %v0, ptr %t149, i64 %t150, i64 0)
  store i64 %t153, ptr %l87
  br label %bb53
bb53:
  %t154 = load i64, ptr %l87, !tbaa !24
  store i64 %t154, ptr %l10, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/free:Free", ptr %t155, i32 0, i32 104
  %t158 = load i64, ptr %l10, !tbaa !24
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t157, i64 %t158)
  store i64 %t161, ptr %l91
  br label %bb54
bb54:
  %t162 = load i64, ptr %l91, !tbaa !24
  store i64 %t162, ptr %l11, !tbaa !24
  %t163 = load i64, ptr %l11, !tbaa !24
  %t164 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  %t167 = icmp eq i64 %t163, %t164
  br i1 %t167, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb57
bb56:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t170 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  %t173 = icmp eq i64 %t169, %t170
  store i1 %t173, ptr %l95, !tbaa !21
  br label %bb57
bb57:
  %t175 = load i1, ptr %l95, !tbaa !21
  br i1 %t175, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb60
bb59:
  %t176 = load i64, ptr %l11, !tbaa !24
  %t177 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  %t180 = icmp eq i64 %t176, %t177
  store i1 %t180, ptr %l99, !tbaa !21
  br label %bb60
bb60:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb62:
  br label %bb63
bb63:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:Free", ptr %t183, i32 0, i32 106
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = call %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t185, i64 %t186)
  store %"compiler/free:reason" %t189, ptr %l106
  br label %bb64
bb64:
  %t190 = load %"compiler/free:reason", ptr %l106
  store %"compiler/free:reason" %t190, ptr %l12
  %t191 = getelementptr %"compiler/free:reason", ptr %l12, i32 0, i32 1
  %t192 = load i64, ptr %t191, !tbaa !24
  %t194 = icmp sge i64 %t192, 0
  br i1 %t194, label %bb65, label %bb66
bb65:
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/free:reason", ptr %l12, i32 0, i32 1
  %t198 = load i64, ptr %t197, !tbaa !24
  %t201 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t196, i64 %t198, i64 0)
  store { i64, ptr } %t201, ptr %l112
  br label %bb67
bb66:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb69
bb67:
  %t202 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t212 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s2, ptr %s2, { i64, ptr } %t209, { i64, ptr } %t211)
  store i1 %t212, ptr %l116
  br label %bb68
bb68:
  %t213 = load i1, ptr %l116, !tbaa !21
  %t214 = xor i1 %t213, true
  store i1 %t214, ptr %l109, !tbaa !21
  br label %bb69
bb69:
  %t216 = load i1, ptr %l109, !tbaa !21
  br i1 %t216, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb71:
  br label %bb72
bb72:
  store ptr %l1, ptr %l118, !tbaa !29
  %t217 = call ptr @__olang_scope_hold(ptr %v1)
  %t218 = ptrtoint ptr %t217 to i64
  store i64 %t218, ptr %l119, !tbaa !24
  %t219 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t219, label %bb73, label %bb74
bb73:
  %t221 = call ptr @__olang_region_make(ptr %v1)
  %t222 = ptrtoint ptr %t221 to i64
  store i64 %t222, ptr %l119, !tbaa !24
  br label %bb74
bb74:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t224 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 2
  %t225 = load i64, ptr %t224, !tbaa !24
  %t226 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 3
  %t227 = getelementptr %"compiler/source:Span", ptr %t226, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = sext i32 %t228 to i64
  %t234 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t223, i64 %t225, i64 %t230)
  store { i64, ptr } %t234, ptr %l125
  br label %bb75
bb75:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 2
  %t237 = load i64, ptr %t236, !tbaa !24
  %t238 = getelementptr %"compiler/free:letGo", ptr %l5, i32 0, i32 4
  %t239 = load %"compiler/source:Span", ptr %t238
  %t243 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s2, ptr %t235, i64 %t237, %"compiler/source:Span" %t239)
  store { i64, ptr } %t243, ptr %l129
  br label %bb76
bb76:
  %t244 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = load i64, ptr %l119
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = call ptr @__olang_held_alloc(ptr %t258, i64 %t256)
  call void @olang_textcopy(ptr %t259, ptr %t245, i64 %t246)
  %t260 = getelementptr i8, ptr %t259, i64 %t246
  call void @olang_textcopy(ptr %t260, ptr %t247, i64 %t248)
  %t261 = getelementptr i8, ptr %t260, i64 %t248
  call void @olang_textcopy(ptr %t261, ptr %t251, i64 %t252)
  %t262 = getelementptr i8, ptr %t261, i64 %t252
  call void @olang_textcopy(ptr %t262, ptr %t254, i64 %t255)
  %t263 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t259, 1
  %t266 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t266, { i64, ptr } %t264)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb78:
  %t268 = load i64, ptr %l4, !tbaa !24
  %t271 = add i64 %t268, 1
  store i64 %t271, ptr %l4, !tbaa !24
  br label %bb2
bb79:
  %t273 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l35 = alloca i1
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca ptr
  %l63 = alloca i1
  %l64 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca i64
  %l74 = alloca i1
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l88 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l104 = alloca i32
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca %"compiler/typed:Local"
  %l115 = alloca i32
  %l116 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t7 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleafLocal(ptr %v0, ptr %t1, i64 %t2, i64 %t3)
  store i1 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i1, ptr %l11, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/typed:LocalUses", ptr %t11, i32 0, i32 4
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l17
  br label %bb4
bb4:
  %t18 = load i1, ptr %l17, !tbaa !21
  store i1 %t18, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:LocalUses", ptr %t20, i32 0, i32 20
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %s0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l22
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t28 = icmp eq ptr %t27, null
  store i1 %t28, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 156
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t38, ptr %l28
  br label %bb13
bb13:
  %t39 = load i1, ptr %l28, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:Free", ptr %t40, i32 0, i32 121
  store ptr %t42, ptr %l31, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t43, i64 %t44)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t47, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb16:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l34
  %t50 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t48, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t49)
  store i1 %t50, ptr %l35
  br label %bb17
bb17:
  %t51 = load i1, ptr %l35, !tbaa !21
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t54)
  store ptr %t56, ptr %l38
  br label %bb22
bb22:
  %t57 = load ptr, ptr %l38, !tbaa !29
  store ptr %t57, ptr %l4, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 20
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l42
  br label %bb23
bb23:
  %t65 = load ptr, ptr %l42, !tbaa !29
  store ptr %t65, ptr %l5, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_90a48e1653e30d13_61ffec3ea9309927)
  unreachable
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t73 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t70)
  store ptr %t73, ptr %l47
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l47, !tbaa !29
  store ptr %t74, ptr %l6, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t80 = load ptr, ptr %l6, !tbaa !29
  %t82 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t80)
  store i64 %t82, ptr %l52
  br label %bb31
bb31:
  %t83 = load i64, ptr %l52, !tbaa !24
  store i64 %t83, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb35
bb33:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 1
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t90, i64 %t91)
  store ptr %t94, ptr %l59
  br label %bb34
bb34:
  %t95 = load ptr, ptr %l59, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t95, i32 0, i32 11
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  store i1 %t100, ptr %l55, !tbaa !21
  br label %bb35
bb35:
  %t102 = load i1, ptr %l55, !tbaa !21
  br i1 %t102, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb40
bb37:
  %t103 = load ptr, ptr %l4, !tbaa !29
  store ptr %t103, ptr %l64, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/free:Free", ptr %t104, i32 0, i32 1
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t106, i64 %t107)
  store ptr %t110, ptr %l68
  br label %bb38
bb38:
  %t111 = load ptr, ptr %l68, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %t113, !tbaa !23
  %t115 = load ptr, ptr %l64, !tbaa !29
  %t117 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t115, i32 %t114)
  store i64 %t117, ptr %l71
  br label %bb39
bb39:
  %t118 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t119 = load i64, ptr %l71, !tbaa !24
  %t121 = icmp ne i64 %t119, %t118
  store i1 %t121, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t123 = load i1, ptr %l63, !tbaa !21
  br i1 %t123, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb45
bb42:
  %t124 = load ptr, ptr %l4, !tbaa !29
  store ptr %t124, ptr %l75, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 1
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t127, i64 %t128)
  store ptr %t131, ptr %l79
  br label %bb43
bb43:
  %t132 = load ptr, ptr %l79, !tbaa !29
  %t134 = getelementptr %"compiler/typed:Body", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %t134, !tbaa !23
  %t136 = load ptr, ptr %l75, !tbaa !29
  %t138 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t136, i32 %t135)
  store { i64, ptr } %t138, ptr %l82
  br label %bb44
bb44:
  %t139 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 1
  store i1 %t142, ptr %l74, !tbaa !21
  br label %bb45
bb45:
  %t144 = load i1, ptr %l74, !tbaa !21
  br i1 %t144, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i64, ptr %l7, !tbaa !24
  %t150 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t146, i64 %t147)
  store i64 %t150, ptr %l88
  br label %bb49
bb49:
  %t151 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t152 = load i64, ptr %l88, !tbaa !24
  %t154 = and i64 %t152, %t151
  %t156 = icmp ne i64 %t154, 0
  br i1 %t156, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t159 = load ptr, ptr %l4, !tbaa !29
  store ptr %t159, ptr %l93, !tbaa !29
  %t160 = load ptr, ptr %l4, !tbaa !29
  store ptr %t160, ptr %l94, !tbaa !29
  %t161 = load ptr, ptr %l4, !tbaa !29
  store ptr %t161, ptr %l95, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/free:Free", ptr %t162, i32 0, i32 1
  %t165 = load i64, ptr %l7, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l99
  br label %bb53
bb53:
  %t169 = load ptr, ptr %l99, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %t171, !tbaa !23
  %t173 = load ptr, ptr %l95, !tbaa !29
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t173, i32 %t172)
  store { i64, ptr } %t175, ptr %l102
  br label %bb54
bb54:
  %t176 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 0
  %t179 = load i32, ptr %t178, !tbaa !33
  %t180 = load ptr, ptr %l94, !tbaa !29
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t180, i32 %t179)
  store i32 %t182, ptr %l104
  br label %bb55
bb55:
  %t183 = load ptr, ptr %l4, !tbaa !29
  store ptr %t183, ptr %l105, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:Free", ptr %t184, i32 0, i32 1
  %t187 = load i64, ptr %l1, !tbaa !24
  %t190 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t186, i64 %t187)
  store ptr %t190, ptr %l109
  br label %bb56
bb56:
  %t191 = load ptr, ptr %l109, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Body", ptr %t191, i32 0, i32 7
  %t194 = load i64, ptr %l2, !tbaa !24
  %t197 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t193, i64 %t194)
  store %"compiler/typed:Local" %t197, ptr %l113
  br label %bb57
bb57:
  %t198 = getelementptr %"compiler/typed:Local", ptr %l113, i32 0, i32 2
  %t199 = load i32, ptr %t198, !tbaa !23
  %t200 = load ptr, ptr %l105, !tbaa !29
  %t202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t200, i32 %t199)
  store i32 %t202, ptr %l115
  br label %bb58
bb58:
  %t203 = load ptr, ptr %l93, !tbaa !29
  %t204 = load i32, ptr %l104, !tbaa !23
  %t205 = load i32, ptr %l115, !tbaa !23
  %t206 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t203, i32 %t204, i32 %t205)
  store i1 %t206, ptr %l116
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t207 = load i1, ptr %l116, !tbaa !21
  store i1 %t207, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l79 = alloca { i64, ptr }
  %l84 = alloca i1
  %l93 = alloca i1
  %l94 = alloca ptr
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l119 = alloca i1
  %l129 = alloca { i64, ptr }
  %l134 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l153 = alloca { i64, ptr }
  %l158 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i1
  %l182 = alloca i1
  %l183 = alloca i1
  %l188 = alloca i1
  %l189 = alloca ptr
  %l195 = alloca i1
  %l196 = alloca i1
  %l200 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l209 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l216 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i1
  %l231 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %l241 = alloca i1
  %l247 = alloca i1
  %l248 = alloca ptr
  %l254 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l265 = alloca i1
  %l266 = alloca ptr
  %l272 = alloca i1
  %l278 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t2 = load ptr, ptr %l27, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l27, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l28, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l28, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t11 = load ptr, ptr %l31, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l31, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l32, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t20 = load ptr, ptr %l35, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l35, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l36, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t29 = load ptr, ptr %l39, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l40, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t39 = load ptr, ptr %l44, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t42 = load ptr, ptr %l44, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l45, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l45, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t49 = load ptr, ptr %l49, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb25, label %bb26
bb25:
  %t52 = load ptr, ptr %l49, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 5
  store i1 %t55, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t56 = load i1, ptr %l50, !tbaa !21
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l2, !tbaa !23
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l59
  br label %bb30
bb30:
  %t74 = load i1, ptr %l59, !tbaa !21
  br i1 %t74, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb34
bb32:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  store i1 %t82, ptr %l64
  br label %bb33
bb33:
  %t83 = load i1, ptr %l64, !tbaa !21
  store i1 %t83, ptr %l60, !tbaa !21
  br label %bb34
bb34:
  %t84 = load i1, ptr %l60, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb35:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t86 = load ptr, ptr %l65, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb36, label %bb37
bb36:
  %t89 = load ptr, ptr %l65, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 7
  store i1 %t92, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t93 = load i1, ptr %l66, !tbaa !21
  br i1 %t93, label %bb38, label %bb39
bb38:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Make", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb41
bb41:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb42, label %bb43
bb42:
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l79, !tbaa !27
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t118
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t123)
  store i1 %t129, ptr %l84
  br label %bb45
bb45:
  %t130 = load i1, ptr %l84, !tbaa !21
  br i1 %t130, label %bb46, label %bb47
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb41
bb50:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 3
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb51, label %bb52
bb51:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l94, !tbaa !29
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Make", ptr %t147, i32 0, i32 3
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb53, label %bb54
bb52:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db)
  unreachable
bb54:
  br label %bb55
bb55:
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Make", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t158 = load ptr, ptr %l94, !tbaa !29
  %t160 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t158, ptr %t157)
  store i1 %t160, ptr %l100
  br label %bb56
bb56:
  %t161 = load i1, ptr %l100, !tbaa !21
  store i1 %t161, ptr %l93, !tbaa !21
  br label %bb57
bb57:
  %t162 = load i1, ptr %l93, !tbaa !21
  store i1 %t162, ptr %rv
  br label %ret
bb58:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t164 = load ptr, ptr %l101, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb59, label %bb60
bb59:
  %t167 = load ptr, ptr %l101, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 16
  store i1 %t170, ptr %l102, !tbaa !21
  br label %bb60
bb60:
  %t171 = load i1, ptr %l102, !tbaa !21
  br i1 %t171, label %bb61, label %bb62
bb61:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l9, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l9, !tbaa !29
  %t182 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextMayRegister(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  store i1 %t182, ptr %l109
  br label %bb64
bb64:
  %t183 = load i1, ptr %l109, !tbaa !21
  store i1 %t183, ptr %rv
  br label %ret
bb65:
  %t184 = load ptr, ptr %l1, !tbaa !29
  store ptr %t184, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t185 = load ptr, ptr %l110, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb66, label %bb67
bb66:
  %t188 = load ptr, ptr %l110, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 18}
  %t191 = icmp eq i64 %t189, 6
  store i1 %t191, ptr %l111, !tbaa !21
  br label %bb67
bb67:
  %t192 = load i1, ptr %l111, !tbaa !21
  br i1 %t192, label %bb68, label %bb69
bb68:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t195, i32 0, i32 2
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l10, !tbaa !29
  br label %bb70
bb69:
  br label %bb85
bb70:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l10, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Call", ptr %t200, i32 0, i32 0
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeMayRegister(ptr %v0, ptr %v1, ptr %t199, ptr %t203)
  store i1 %t206, ptr %l119
  br label %bb71
bb71:
  %t207 = load i1, ptr %l119, !tbaa !21
  br i1 %t207, label %bb72, label %bb73
bb72:
  store i1 true, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t209 = load ptr, ptr %l10, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Call", ptr %t209, i32 0, i32 1
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %l13, !tbaa !24
  br label %bb75
bb75:
  %t218 = load i64, ptr %l12, !tbaa !24
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb76, label %bb77
bb76:
  br label %bb84
bb77:
  br label %bb78
bb78:
  %t226 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t226, ptr %l129, !tbaa !27
  %t227 = load i64, ptr %l12, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr ptr, ptr %t230, i64 %t227
  %t232 = load ptr, ptr %t231, !tbaa !39
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t238 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t234, ptr %t232)
  store i1 %t238, ptr %l134
  br label %bb79
bb79:
  %t239 = load i1, ptr %l134, !tbaa !21
  br i1 %t239, label %bb80, label %bb81
bb80:
  store i1 true, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t241 = load i64, ptr %l12, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l12, !tbaa !24
  br label %bb75
bb84:
  store i1 false, ptr %rv
  br label %ret
bb85:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t248 = load ptr, ptr %l140, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb86, label %bb87
bb86:
  %t251 = load ptr, ptr %l140, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 9
  store i1 %t254, ptr %l141, !tbaa !21
  br label %bb87
bb87:
  %t255 = load i1, ptr %l141, !tbaa !21
  br i1 %t255, label %bb88, label %bb89
bb88:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t258, i32 0, i32 4
  %t260 = load { i64, ptr }, ptr %t259
  store { i64, ptr } %t260, ptr %l15, !tbaa !27
  br label %bb90
bb89:
  br label %bb101
bb90:
  %t262 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t262, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  store i64 %t266, ptr %l18, !tbaa !24
  br label %bb91
bb91:
  %t268 = load i64, ptr %l17, !tbaa !24
  %t269 = load i64, ptr %l18, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb92, label %bb93
bb92:
  br label %bb100
bb93:
  br label %bb94
bb94:
  %t276 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t276, ptr %l153, !tbaa !27
  %t277 = load i64, ptr %l17, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr ptr, ptr %t280, i64 %t277
  %t282 = load ptr, ptr %t281, !tbaa !39
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t288 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t284, ptr %t282)
  store i1 %t288, ptr %l158
  br label %bb95
bb95:
  %t289 = load i1, ptr %l158, !tbaa !21
  br i1 %t289, label %bb96, label %bb97
bb96:
  store i1 true, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t291 = load i64, ptr %l17, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l17, !tbaa !24
  br label %bb91
bb100:
  store i1 false, ptr %rv
  br label %ret
bb101:
  %t297 = load ptr, ptr %l1, !tbaa !29
  store ptr %t297, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t298 = load ptr, ptr %l164, !tbaa !29
  %t299 = icmp ne ptr %t298, null
  br i1 %t299, label %bb102, label %bb103
bb102:
  %t301 = load ptr, ptr %l164, !tbaa !29
  %t302 = load i64, ptr %t301, !range !{i64 0, i64 18}
  %t304 = icmp eq i64 %t302, 17
  store i1 %t304, ptr %l165, !tbaa !21
  br label %bb103
bb103:
  %t305 = load i1, ptr %l165, !tbaa !21
  br i1 %t305, label %bb104, label %bb105
bb104:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t308, i32 0, i32 2
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l20, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l20, !tbaa !29
  %t316 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t312, ptr %t313)
  store i1 %t316, ptr %l172
  br label %bb107
bb107:
  %t317 = load i1, ptr %l172, !tbaa !21
  store i1 %t317, ptr %rv
  br label %ret
bb108:
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t319 = load ptr, ptr %l173, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb109, label %bb110
bb109:
  %t322 = load ptr, ptr %l173, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 18}
  %t325 = icmp eq i64 %t323, 11
  store i1 %t325, ptr %l174, !tbaa !21
  br label %bb110
bb110:
  %t326 = load i1, ptr %l174, !tbaa !21
  br i1 %t326, label %bb111, label %bb112
bb111:
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l21, !tbaa !29
  br label %bb113
bb112:
  br label %bb129
bb113:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l21, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Cond", ptr %t334, i32 0, i32 0
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t340 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t333, ptr %t337)
  store i1 %t340, ptr %l182
  br label %bb114
bb114:
  %t341 = load i1, ptr %l182, !tbaa !21
  br i1 %t341, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb124
bb116:
  %t342 = load ptr, ptr %l21, !tbaa !29
  %t344 = getelementptr %"compiler/typed:Cond", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = icmp eq ptr %t345, null
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb117, label %bb118
bb117:
  %t351 = load ptr, ptr %l0, !tbaa !29
  store ptr %t351, ptr %l189, !tbaa !29
  %t352 = load ptr, ptr %l21, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Cond", ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t357 = icmp eq ptr %t355, null
  br i1 %t357, label %bb119, label %bb120
bb118:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb123
bb119:
  call void @__olang_check_failed(ptr @olang_loc_fc2fcdbc2f007840_c2f2791b7eb787ec)
  unreachable
bb120:
  br label %bb121
bb121:
  %t359 = load ptr, ptr %l21, !tbaa !29
  %t361 = getelementptr %"compiler/typed:Cond", ptr %t359, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t363 = load ptr, ptr %l189, !tbaa !29
  %t365 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t363, ptr %t362)
  store i1 %t365, ptr %l195
  br label %bb122
bb122:
  %t366 = load i1, ptr %l195, !tbaa !21
  store i1 %t366, ptr %l188, !tbaa !21
  br label %bb123
bb123:
  %t367 = load i1, ptr %l188, !tbaa !21
  store i1 %t367, ptr %l183, !tbaa !21
  br label %bb124
bb124:
  %t368 = load i1, ptr %l183, !tbaa !21
  br i1 %t368, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l196, !tbaa !21
  br label %bb128
bb126:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l21, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Cond", ptr %t370, i32 0, i32 2
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t376 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t369, ptr %t373)
  store i1 %t376, ptr %l200
  br label %bb127
bb127:
  %t377 = load i1, ptr %l200, !tbaa !21
  store i1 %t377, ptr %l196, !tbaa !21
  br label %bb128
bb128:
  %t378 = load i1, ptr %l196, !tbaa !21
  store i1 %t378, ptr %rv
  br label %ret
bb129:
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t380 = load ptr, ptr %l201, !tbaa !29
  %t381 = icmp ne ptr %t380, null
  br i1 %t381, label %bb130, label %bb131
bb130:
  %t383 = load ptr, ptr %l201, !tbaa !29
  %t384 = load i64, ptr %t383, !range !{i64 0, i64 18}
  %t386 = icmp eq i64 %t384, 14
  store i1 %t386, ptr %l202, !tbaa !21
  br label %bb131
bb131:
  %t387 = load i1, ptr %l202, !tbaa !21
  br i1 %t387, label %bb132, label %bb133
bb132:
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr { i64, [5 x i64] }, ptr %t388, i32 0, i32 1
  %t391 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t390, i32 0, i32 2
  %t392 = load ptr, ptr %t391
  store ptr %t392, ptr %l22, !tbaa !29
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load ptr, ptr %l22, !tbaa !29
  %t398 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etryMayRegister(ptr %v0, ptr %v1, ptr %t394, ptr %t395)
  store i1 %t398, ptr %l209
  br label %bb135
bb135:
  %t399 = load i1, ptr %l209, !tbaa !21
  store i1 %t399, ptr %rv
  br label %ret
bb136:
  %t400 = load ptr, ptr %l1, !tbaa !29
  store ptr %t400, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t401 = load ptr, ptr %l210, !tbaa !29
  %t402 = icmp ne ptr %t401, null
  br i1 %t402, label %bb137, label %bb138
bb137:
  %t404 = load ptr, ptr %l210, !tbaa !29
  %t405 = load i64, ptr %t404, !range !{i64 0, i64 18}
  %t407 = icmp eq i64 %t405, 15
  store i1 %t407, ptr %l211, !tbaa !21
  br label %bb138
bb138:
  %t408 = load i1, ptr %l211, !tbaa !21
  br i1 %t408, label %bb139, label %bb140
bb139:
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = getelementptr { i64, [5 x i64] }, ptr %t409, i32 0, i32 1
  %t412 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t411, i32 0, i32 2
  %t413 = load ptr, ptr %t412
  store ptr %t413, ptr %l23, !tbaa !29
  br label %bb141
bb140:
  br label %bb160
bb141:
  %t415 = load ptr, ptr %l23, !tbaa !29
  store ptr %t415, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t416 = load ptr, ptr %l217, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb142, label %bb143
bb142:
  %t419 = load ptr, ptr %l217, !tbaa !29
  %t420 = load i64, ptr %t419, !range !{i64 0, i64 3}
  %t422 = icmp eq i64 %t420, 0
  store i1 %t422, ptr %l218, !tbaa !21
  br label %bb143
bb143:
  %t423 = load i1, ptr %l218, !tbaa !21
  br i1 %t423, label %bb144, label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb159
bb147:
  %t424 = load ptr, ptr %l23, !tbaa !29
  store ptr %t424, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t425 = load ptr, ptr %l221, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb148, label %bb149
bb148:
  %t428 = load ptr, ptr %l221, !tbaa !29
  %t429 = load i64, ptr %t428, !range !{i64 0, i64 3}
  %t431 = icmp eq i64 %t429, 1
  store i1 %t431, ptr %l222, !tbaa !21
  br label %bb149
bb149:
  %t432 = load i1, ptr %l222, !tbaa !21
  br i1 %t432, label %bb150, label %bb151
bb150:
  %t433 = load ptr, ptr %l23, !tbaa !29
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t435, i32 0, i32 0
  %t437 = load i32, ptr %t436
  store i32 %t437, ptr %l24, !tbaa !23
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/free:Free", ptr %t439, i32 0, i32 93
  %t442 = load i32, ptr %l24, !tbaa !23
  %t444 = sext i32 %t442 to i64
  %t447 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t441, i64 %t444)
  store i1 %t447, ptr %l231
  br label %bb153
bb153:
  %t448 = load i1, ptr %l231, !tbaa !21
  store i1 %t448, ptr %l216, !tbaa !21
  br label %bb159
bb154:
  br i1 true, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb158
bb157:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8)
  unreachable
bb159:
  %t449 = load i1, ptr %l216, !tbaa !21
  store i1 %t449, ptr %rv
  br label %ret
bb160:
  %t450 = load ptr, ptr %l1, !tbaa !29
  store ptr %t450, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t451 = load ptr, ptr %l232, !tbaa !29
  %t452 = icmp ne ptr %t451, null
  br i1 %t452, label %bb161, label %bb162
bb161:
  %t454 = load ptr, ptr %l232, !tbaa !29
  %t455 = load i64, ptr %t454, !range !{i64 0, i64 18}
  %t457 = icmp eq i64 %t455, 12
  store i1 %t457, ptr %l233, !tbaa !21
  br label %bb162
bb162:
  %t458 = load i1, ptr %l233, !tbaa !21
  br i1 %t458, label %bb163, label %bb164
bb163:
  %t459 = load ptr, ptr %l1, !tbaa !29
  %t461 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 1
  %t462 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t461, i32 0, i32 2
  %t463 = load ptr, ptr %t462
  store ptr %t463, ptr %l25, !tbaa !29
  br label %bb165
bb164:
  br label %bb177
bb165:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load ptr, ptr %l25, !tbaa !29
  %t468 = getelementptr %"compiler/typed:Seq", ptr %t466, i32 0, i32 0
  %t469 = load { i64, ptr }, ptr %t468, !tbaa !27
  %t472 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t465, { i64, ptr } %t469)
  store i1 %t472, ptr %l241
  br label %bb166
bb166:
  %t473 = load i1, ptr %l241, !tbaa !21
  br i1 %t473, label %bb167, label %bb168
bb167:
  store i1 true, ptr %rv
  br label %ret
bb168:
  br label %bb169
bb169:
  %t475 = load ptr, ptr %l25, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Seq", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = icmp eq ptr %t478, null
  %t482 = xor i1 %t480, true
  br i1 %t482, label %bb170, label %bb171
bb170:
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l248, !tbaa !29
  %t485 = load ptr, ptr %l25, !tbaa !29
  %t487 = getelementptr %"compiler/typed:Seq", ptr %t485, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !29
  %t490 = icmp eq ptr %t488, null
  br i1 %t490, label %bb172, label %bb173
bb171:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb176
bb172:
  call void @__olang_check_failed(ptr @olang_loc_c329a7357b4632ae_1972f4ce8b92321a)
  unreachable
bb173:
  br label %bb174
bb174:
  %t492 = load ptr, ptr %l25, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Seq", ptr %t492, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !29
  %t496 = load ptr, ptr %l248, !tbaa !29
  %t498 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t496, ptr %t495)
  store i1 %t498, ptr %l254
  br label %bb175
bb175:
  %t499 = load i1, ptr %l254, !tbaa !21
  store i1 %t499, ptr %l247, !tbaa !21
  br label %bb176
bb176:
  %t500 = load i1, ptr %l247, !tbaa !21
  store i1 %t500, ptr %rv
  br label %ret
bb177:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t502 = load ptr, ptr %l255, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb178, label %bb179
bb178:
  %t505 = load ptr, ptr %l255, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 18}
  %t508 = icmp eq i64 %t506, 8
  store i1 %t508, ptr %l256, !tbaa !21
  br label %bb179
bb179:
  %t509 = load i1, ptr %l256, !tbaa !21
  br i1 %t509, label %bb180, label %bb181
bb180:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t512, i32 0, i32 2
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l26, !tbaa !29
  br label %bb182
bb181:
  br label %bb194
bb182:
  %t516 = load ptr, ptr %l26, !tbaa !29
  %t518 = getelementptr %"compiler/typed:Collect", ptr %t516, i32 0, i32 0
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t521 = icmp eq ptr %t519, null
  %t523 = xor i1 %t521, true
  br i1 %t523, label %bb183, label %bb184
bb183:
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l266, !tbaa !29
  %t526 = load ptr, ptr %l26, !tbaa !29
  %t528 = getelementptr %"compiler/typed:Collect", ptr %t526, i32 0, i32 0
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t531 = icmp eq ptr %t529, null
  br i1 %t531, label %bb185, label %bb186
bb184:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb189
bb185:
  call void @__olang_check_failed(ptr @olang_loc_ce4a56608212b1d3_28564c72fb26107)
  unreachable
bb186:
  br label %bb187
bb187:
  %t533 = load ptr, ptr %l26, !tbaa !29
  %t535 = getelementptr %"compiler/typed:Collect", ptr %t533, i32 0, i32 0
  %t536 = load ptr, ptr %t535, !tbaa !29
  %t537 = load ptr, ptr %l266, !tbaa !29
  %t539 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t537, ptr %t536)
  store i1 %t539, ptr %l272
  br label %bb188
bb188:
  %t540 = load i1, ptr %l272, !tbaa !21
  store i1 %t540, ptr %l265, !tbaa !21
  br label %bb189
bb189:
  %t541 = load i1, ptr %l265, !tbaa !21
  br i1 %t541, label %bb190, label %bb191
bb190:
  store i1 true, ptr %rv
  br label %ret
bb191:
  br label %bb192
bb192:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l26, !tbaa !29
  %t546 = getelementptr %"compiler/typed:Collect", ptr %t544, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !29
  %t549 = getelementptr %"compiler/typed:Block", ptr %t547, i32 0, i32 1
  %t550 = load { i64, ptr }, ptr %t549, !tbaa !27
  %t553 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t543, { i64, ptr } %t550)
  store i1 %t553, ptr %l278
  br label %bb193
bb193:
  %t554 = load i1, ptr %l278, !tbaa !21
  store i1 %t554, ptr %rv
  br label %ret
bb194:
  br i1 true, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb198
bb197:
  store i1 true, ptr %rv
  br label %ret
bb198:
  call void @__olang_check_failed(ptr @olang_loc_8c3ff88e405c7c2b_15d3403d537d031f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emodelled(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 182
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 1
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 1
  %t17 = load { i64, [2 x i64] }, ptr %t16
  store { i64, [2 x i64] } %t17, ptr %l2
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 3
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i32 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 184
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t31)
  store ptr %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t35, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb9
bb9:
  %t38 = load i32, ptr %l22, !tbaa !23
  %t39 = sext i32 %t38 to i64
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t40, i64 %t39)
  store i1 %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load i1, ptr %l24, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l13, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4d387e337fecd808_d73c070d6177d604)
  unreachable
bb16:
  %t46 = load i1, ptr %l13, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t47 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l28
  br label %bb20
bb20:
  %t48 = load i1, ptr %l28, !tbaa !21
  store i1 %t48, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 8}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l30, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store i1 %t68, ptr %l37
  br label %bb27
bb27:
  %t69 = load i1, ptr %l37, !tbaa !21
  store i1 %t69, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb29, label %bb30
bb29:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 4
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb30
bb30:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb31, label %bb32
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  store i1 %t92, ptr %l47
  br label %bb34
bb34:
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  store i1 %t101, ptr %l52
  br label %bb37
bb37:
  %t102 = load i1, ptr %l52, !tbaa !21
  store i1 %t102, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t103 = load i1, ptr %l48, !tbaa !21
  store i1 %t103, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb40, label %bb41
bb40:
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l54, !tbaa !21
  br label %bb41
bb41:
  %t112 = load i1, ptr %l54, !tbaa !21
  br i1 %t112, label %bb42, label %bb43
bb42:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Payload", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t126 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t119, ptr %t123)
  store i1 %t126, ptr %l62
  br label %bb45
bb45:
  %t127 = load i1, ptr %l62, !tbaa !21
  store i1 %t127, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t128 = load ptr, ptr %l1, !tbaa !29
  store ptr %t128, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t129 = load ptr, ptr %l63, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb47, label %bb48
bb47:
  %t132 = load ptr, ptr %l63, !tbaa !29
  %t133 = load i64, ptr %t132, !range !{i64 0, i64 8}
  %t135 = icmp eq i64 %t133, 6
  store i1 %t135, ptr %l64, !tbaa !21
  br label %bb48
bb48:
  %t136 = load i1, ptr %l64, !tbaa !21
  br i1 %t136, label %bb49, label %bb50
bb49:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t139, i32 0, i32 2
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t147 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t143, ptr %t144)
  store i1 %t147, ptr %l71
  br label %bb52
bb52:
  %t148 = load i1, ptr %l71, !tbaa !21
  store i1 %t148, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a4118a366f7ca1d5_524409770a0878b9)
  unreachable
bb54:
  %t149 = load i1, ptr %l7, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/free:letGo"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l60 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca %"compiler/free:letGo"
  %l78 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca i1
  %l88 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l103 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l119 = alloca i64
  %l120 = alloca i64
  %l128 = alloca ptr
  %l130 = alloca ptr
  %l133 = alloca i64
  %l137 = alloca i64
  %l140 = alloca i64
  %l161 = alloca ptr
  %l165 = alloca %"compiler/typed:Local"
  %l167 = alloca { i64, ptr }
  %l169 = alloca i1
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca i32
  %l189 = alloca ptr
  %l193 = alloca %"compiler/typed:Local"
  %l195 = alloca i32
  %l198 = alloca i1
  %l199 = alloca ptr
  %l202 = alloca i32
  %l203 = alloca i32
  %l206 = alloca i32
  %l212 = alloca ptr
  %l213 = alloca ptr
  %l216 = alloca i32
  %l217 = alloca i32
  %l218 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca i64
  %l230 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/free:letGo", ptr %l1
  %t5 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s0, ptr %t1, %"compiler/free:letGo" %t2)
  store { i64, ptr } %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i1, ptr %l29, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t13, ptr %l31, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l32, !tbaa !24
  %t16 = load i64, ptr %l32, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l33, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l32, !tbaa !24
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t27, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 10
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l37
  br label %bb6
bb6:
  %t36 = load i64, ptr %l37, !tbaa !24
  %t37 = icmp slt i64 %t36, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t41, ptr %l41
  br label %bb9
bb8:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb10
bb9:
  %t42 = load i1, ptr %l41, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l39, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %t46, i64 %t47)
  store i1 %t50, ptr %l46
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t51 = load i1, ptr %l46, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l43, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t55, ptr %l48, !tbaa !27
  br label %bb18
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/free:letGo", ptr %l1
  %t61 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s0, ptr %t57, %"compiler/free:letGo" %t58)
  store { i64, ptr } %t61, ptr %l52
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t62, ptr %l48, !tbaa !27
  br label %bb18
bb18:
  %t63 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l53, !tbaa !24
  %t65 = load i64, ptr %l53, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l54, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 10
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t79, i64 %t80)
  store i64 %t83, ptr %l58
  br label %bb19
bb19:
  %t84 = load i64, ptr %l58, !tbaa !24
  %t85 = icmp slt i64 %t84, 0
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %t87, i64 %t88)
  store i1 %t91, ptr %l63
  br label %bb22
bb21:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb23
bb22:
  %t92 = load i1, ptr %l63, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t95 = load i1, ptr %l60, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 102
  store ptr %t98, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb25:
  br label %bb51
bb26:
  %t100 = load i64, ptr %l6, !tbaa !24
  store i64 %t100, ptr %l67, !tbaa !24
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l69
  br label %bb27
bb27:
  %t104 = load i64, ptr %l67, !tbaa !24
  %t105 = load i64, ptr %l69, !tbaa !24
  %t106 = icmp slt i64 %t104, %t105
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb28, label %bb29
bb28:
  br label %bb50
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t111 = load i64, ptr %l6, !tbaa !24
  %t114 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t110, i64 %t111)
  store %"compiler/free:letGo" %t114, ptr %l74
  br label %bb31
bb31:
  %t115 = load %"compiler/free:letGo", ptr %l74
  store %"compiler/free:letGo" %t115, ptr %l7
  %t116 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 0
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t129 = icmp eq i64 %t124, %t126
  store i1 %t129, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t131 = load i1, ptr %l78, !tbaa !21
  br i1 %t131, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/free:letGo", ptr %l7
  %t136 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s5, ptr %t132, %"compiler/free:letGo" %t133)
  store { i64, ptr } %t136, ptr %l84
  br label %bb37
bb36:
  br label %bb48
bb37:
  %t137 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t137, ptr %l8, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t138, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t140, ptr %l86
  br label %bb38
bb38:
  %t141 = load i1, ptr %l86, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t144 = call ptr @__olang_scope_hold(ptr %s0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l88, !tbaa !24
  %t146 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2escopeName_2elocal_2e4
  br i1 %t146, label %bb41, label %bb42
bb40:
  br label %bb47
bb41:
  %t148 = call ptr @__olang_region_make(ptr %s0)
  %t149 = ptrtoint ptr %t148 to i64
  store i64 %t149, ptr %l88, !tbaa !24
  br label %bb42
bb42:
  %t150 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t150, ptr %l90, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l91, !tbaa !24
  %t153 = load i64, ptr %l91, !tbaa !24
  %t154 = mul i64 %t153, 1
  %t155 = load i64, ptr %l88
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = call ptr @__olang_held_alloc(ptr %t156, i64 %t154)
  %t158 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l92, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l91, !tbaa !24
  %t165 = mul i64 %t164, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  %t166 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t166, ptr %l93, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t167, ptr %l4, !tbaa !27
  %t168 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2escopeName_2elocal_2e4
  br i1 %t168, label %bb43, label %bb44
bb43:
  %t170 = load { i64, ptr }, ptr %l93
  %t171 = extractvalue { i64, ptr } %t170, 1
  call void @__olang_region_release(ptr %t171)
  store { i64, ptr } zeroinitializer, ptr %l93
  br label %bb44
bb44:
  %t172 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2escopeName_2elocal_2e4
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t174 = load i64, ptr %l88
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = load { i64, ptr }, ptr %l4
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = call ptr @__olang_region_or(ptr %t177, ptr null)
  %t179 = icmp ne ptr %t178, null
  %t180 = select i1 %t179, ptr %t178, ptr null
  call void @__olang_region_settle_in(ptr %t175, ptr %t180)
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t181 = load i64, ptr %l6, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l6, !tbaa !24
  br label %bb26
bb50:
  br label %bb51
bb51:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb52
bb52:
  %t186 = load i64, ptr %l9, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t192 = icmp slt i64 %t186, %t189
  br i1 %t192, label %bb53, label %bb54
bb53:
  %t194 = load i64, ptr %l9, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i8, ptr %t197, i64 %t194
  %t199 = load i8, ptr %t198, !tbaa !32
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t199)
  store i1 %t201, ptr %l106
  br label %bb55
bb54:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb63
bb55:
  %t202 = load i1, ptr %l106, !tbaa !21
  br i1 %t202, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb59
bb57:
  %t203 = load i64, ptr %l9, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i8, ptr %t206, i64 %t203
  %t208 = load i8, ptr %t207, !tbaa !32
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t208)
  store i1 %t210, ptr %l110
  br label %bb58
bb58:
  %t211 = load i1, ptr %l110, !tbaa !21
  store i1 %t211, ptr %l107, !tbaa !21
  br label %bb59
bb59:
  %t212 = load i1, ptr %l107, !tbaa !21
  br i1 %t212, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb62
bb61:
  %t213 = load i64, ptr %l9, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i8, ptr %t216, i64 %t213
  %t218 = load i8, ptr %t217, !tbaa !32
  %t220 = icmp eq i8 %t218, 95
  store i1 %t220, ptr %l111, !tbaa !21
  br label %bb62
bb62:
  %t222 = load i1, ptr %l111, !tbaa !21
  store i1 %t222, ptr %l103, !tbaa !21
  br label %bb63
bb63:
  %t223 = load i1, ptr %l103, !tbaa !21
  %t224 = xor i1 %t223, true
  br i1 %t224, label %bb64, label %bb65
bb64:
  br label %bb68
bb65:
  br label %bb66
bb66:
  %t226 = load i64, ptr %l9, !tbaa !24
  %t229 = add i64 %t226, 1
  store i64 %t229, ptr %l9, !tbaa !24
  br label %bb67
bb67:
  br label %bb52
bb68:
  %t231 = load i64, ptr %l9, !tbaa !24
  store i64 %t231, ptr %l119, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 0
  store i64 %t233, ptr %l120, !tbaa !24
  %t234 = icmp sge i64 0, 0
  br i1 %t234, label %bb69, label %bb70
bb69:
  %t236 = load i64, ptr %l119, !tbaa !24
  %t237 = icmp sle i64 0, %t236
  br i1 %t237, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb71:
  %t239 = load i64, ptr %l119, !tbaa !24
  %t240 = load i64, ptr %l120, !tbaa !24
  %t241 = icmp sle i64 %t239, %t240
  br i1 %t241, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb73:
  %t243 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = load i64, ptr %l119, !tbaa !24
  %t246 = getelementptr i8, ptr %t244, i64 0
  %t247 = sub i64 %t245, 0
  %t248 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t246, 1
  store { i64, ptr } %t249, ptr %l10, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/free:Free", ptr %t251, i32 0, i32 1
  %t254 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t255 = load i64, ptr %t254, !tbaa !24
  %t258 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t253, i64 %t255)
  store ptr %t258, ptr %l128
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb75:
  %t259 = load ptr, ptr %l128, !tbaa !29
  store ptr %t259, ptr %l11, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t260)
  store ptr %t262, ptr %l130
  br label %bb76
bb76:
  %t263 = load ptr, ptr %l130, !tbaa !29
  store ptr %t263, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t264 = load ptr, ptr %l11, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Body", ptr %t264, i32 0, i32 7
  %t268 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t266)
  store i64 %t268, ptr %l133
  br label %bb77
bb77:
  %t269 = load i64, ptr %l133, !tbaa !24
  store i64 %t269, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t270 = load i64, ptr %l14, !tbaa !24
  %t271 = load i64, ptr %l13, !tbaa !24
  %t274 = icmp sgt i64 %t270, %t271
  br i1 %t274, label %bb78, label %bb79
bb78:
  %t276 = load i64, ptr %l15, !tbaa !24
  %t278 = icmp sgt i64 %t276, 0
  br i1 %t278, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb83
bb80:
  %t280 = load i64, ptr %l14, !tbaa !24
  %t281 = load i64, ptr %l13, !tbaa !24
  %t284 = sub i64 %t280, %t281
  %t285 = load i64, ptr %l15, !tbaa !24
  %t288 = add i64 %t284, %t285
  %t290 = sub i64 %t288, 1
  %t291 = load i64, ptr %l15, !tbaa !24
  %t294 = sdiv i64 %t290, %t291
  store i64 %t294, ptr %l140, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb82
bb82:
  %t296 = load i64, ptr %l140, !tbaa !24
  store i64 %t296, ptr %l137, !tbaa !24
  br label %bb83
bb83:
  %t297 = load i64, ptr %l137, !tbaa !24
  store i64 %t297, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s10
  %t298 = load i64, ptr %l17, !tbaa !24
  %t299 = load i64, ptr %l16, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s10)
  br label %bb125
bb86:
  br label %bb87
bb87:
  %t306 = load i64, ptr %l13, !tbaa !24
  %t307 = load i64, ptr %l17, !tbaa !24
  %t308 = load i64, ptr %l15, !tbaa !24
  %t311 = mul i64 %t307, %t308
  %t314 = add i64 %t306, %t311
  store i64 %t314, ptr %l18, !tbaa !24
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/free:Free", ptr %t316, i32 0, i32 0
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = getelementptr %"compiler/generic:Program", ptr %t319, i32 0, i32 0
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/load:Loader", ptr %t322, i32 0, i32 3
  %t325 = load ptr, ptr %t324, !tbaa !29
  store ptr %t325, ptr %l161, !tbaa !29
  %t326 = load ptr, ptr %l11, !tbaa !29
  %t328 = getelementptr %"compiler/typed:Body", ptr %t326, i32 0, i32 7
  %t329 = load i64, ptr %l18, !tbaa !24
  %t332 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t328, i64 %t329)
  store %"compiler/typed:Local" %t332, ptr %l165
  br label %bb88
bb88:
  %t333 = getelementptr %"compiler/typed:Local", ptr %l165, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  %t335 = load ptr, ptr %l161, !tbaa !29
  %t337 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t335, i32 %t334)
  store { i64, ptr } %t337, ptr %l167
  br label %bb89
bb89:
  %t338 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t341 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t339, { i64, ptr } %t338)
  store i1 %t341, ptr %l169
  br label %bb90
bb90:
  %t342 = load i1, ptr %l169, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s10)
  br label %bb124
bb92:
  br label %bb93
bb93:
  store i1 false, ptr %l19, !tbaa !21
  %t345 = load ptr, ptr %l11, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Body", ptr %t345, i32 0, i32 5
  store ptr %t347, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb94
bb94:
  %t349 = load i64, ptr %l21, !tbaa !24
  store i64 %t349, ptr %l173, !tbaa !24
  %t350 = load ptr, ptr %l20, !tbaa !29
  %t352 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t350)
  store i64 %t352, ptr %l175
  br label %bb95
bb95:
  %t353 = load i64, ptr %l173, !tbaa !24
  %t354 = load i64, ptr %l175, !tbaa !24
  %t355 = icmp slt i64 %t353, %t354
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb96, label %bb97
bb96:
  br label %bb104
bb97:
  br label %bb98
bb98:
  %t359 = load ptr, ptr %l20, !tbaa !29
  %t360 = load i64, ptr %l21, !tbaa !24
  %t363 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t359, i64 %t360)
  store i32 %t363, ptr %l180
  br label %bb99
bb99:
  %t364 = load i32, ptr %l180, !tbaa !23
  %t367 = sext i32 %t364 to i64
  %t368 = load i64, ptr %l18, !tbaa !24
  %t371 = icmp eq i64 %t367, %t368
  br i1 %t371, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t373 = load i64, ptr %l21, !tbaa !24
  %t376 = add i64 %t373, 1
  store i64 %t376, ptr %l21, !tbaa !24
  br label %bb94
bb104:
  %t378 = load i1, ptr %l19, !tbaa !21
  br i1 %t378, label %bb105, label %bb106
bb105:
  %t380 = load ptr, ptr %l12, !tbaa !29
  store ptr %t380, ptr %l189, !tbaa !29
  %t381 = load ptr, ptr %l11, !tbaa !29
  %t383 = getelementptr %"compiler/typed:Body", ptr %t381, i32 0, i32 7
  %t384 = load i64, ptr %l18, !tbaa !24
  %t387 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t383, i64 %t384)
  store %"compiler/typed:Local" %t387, ptr %l193
  br label %bb107
bb106:
  br label %bb122
bb107:
  %t388 = getelementptr %"compiler/typed:Local", ptr %l193, i32 0, i32 2
  %t389 = load i32, ptr %t388, !tbaa !23
  %t390 = load ptr, ptr %l189, !tbaa !29
  %t392 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t390, i32 %t389)
  store i32 %t392, ptr %l195
  br label %bb108
bb108:
  %t393 = load i32, ptr %l195, !tbaa !23
  store i32 %t393, ptr %l23, !tbaa !23
  %t394 = load ptr, ptr %l12, !tbaa !29
  %t395 = load i32, ptr %l23, !tbaa !23
  %t398 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t394, i32 %t395)
  store i1 %t398, ptr %l198
  br label %bb109
bb109:
  %t399 = load i1, ptr %l198, !tbaa !21
  br i1 %t399, label %bb110, label %bb111
bb110:
  %t400 = load ptr, ptr %l12, !tbaa !29
  store ptr %t400, ptr %l199, !tbaa !29
  %t401 = load ptr, ptr %l12, !tbaa !29
  %t402 = load i32, ptr %l23, !tbaa !23
  %t405 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t401, i32 %t402)
  store i32 %t405, ptr %l202
  br label %bb112
bb111:
  br label %bb114
bb112:
  %t406 = load ptr, ptr %l199, !tbaa !29
  %t407 = load i32, ptr %l202, !tbaa !23
  %t408 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t408, ptr %l203
  br label %bb113
bb113:
  %t409 = load i32, ptr %l203, !tbaa !23
  store i32 %t409, ptr %l23, !tbaa !23
  br label %bb114
bb114:
  %t410 = load ptr, ptr %l12, !tbaa !29
  %t411 = load i32, ptr %l23, !tbaa !23
  %t414 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t410, i32 %t411)
  store i32 %t414, ptr %l206
  br label %bb115
bb115:
  %t415 = load i32, ptr %l206, !range !{i32 0, i32 33}
  %t417 = trunc i64 18 to i32
  %t418 = icmp eq i32 %t415, %t417
  br i1 %t418, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s18
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/free:Free", ptr %t420, i32 0, i32 0
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = getelementptr %"compiler/generic:Program", ptr %t423, i32 0, i32 0
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/load:Loader", ptr %t426, i32 0, i32 3
  %t429 = load ptr, ptr %t428, !tbaa !29
  store ptr %t429, ptr %l212, !tbaa !29
  %t430 = load ptr, ptr %l12, !tbaa !29
  store ptr %t430, ptr %l213, !tbaa !29
  %t431 = load ptr, ptr %l12, !tbaa !29
  %t432 = load i32, ptr %l23, !tbaa !23
  %t435 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t431, i32 %t432)
  store i32 %t435, ptr %l216
  br label %bb118
bb117:
  br label %bb121
bb118:
  %t436 = load ptr, ptr %l213, !tbaa !29
  %t437 = load i32, ptr %l216, !tbaa !23
  %t438 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t436, i32 %t437)
  store i32 %t438, ptr %l217
  br label %bb119
bb119:
  %t439 = load ptr, ptr %l212, !tbaa !29
  %t440 = load i32, ptr %l217, !tbaa !23
  %t441 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s18, ptr %t439, i32 %t440)
  store { i64, ptr } %t441, ptr %l218
  br label %bb120
bb120:
  %t442 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t444 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = add i64 %t443, %t446
  %t448 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t449 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t450 = add i64 %t447, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t442, i64 %t443)
  %t452 = getelementptr i8, ptr %t451, i64 %t443
  call void @olang_textcopy(ptr %t452, ptr %t445, i64 %t446)
  %t453 = getelementptr i8, ptr %t452, i64 %t446
  call void @olang_textcopy(ptr %t453, ptr %t448, i64 %t449)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t451, 1
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t455, ptr %rv
  br label %ret
bb121:
  br label %bb122
bb122:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t459 = load i64, ptr %t458, !tbaa !24
  %t462 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s10, ptr %t457, i64 %t459)
  store { i64, ptr } %t462, ptr %l222
  br label %bb123
bb123:
  %t463 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = extractvalue { i64, ptr } %t463, 0
  %t466 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t468 = add i64 %t465, %t467
  %t469 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t468)
  call void @olang_textcopy(ptr %t469, ptr %t464, i64 %t465)
  %t470 = getelementptr i8, ptr %t469, i64 %t465
  call void @olang_textcopy(ptr %t470, ptr %t466, i64 %t467)
  %t471 = insertvalue { i64, ptr } undef, i64 %t468, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t469, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t472, ptr %rv
  br label %ret
bb124:
  %t474 = load i64, ptr %l17, !tbaa !24
  %t477 = add i64 %t474, 1
  store i64 %t477, ptr %l17, !tbaa !24
  br label %bb84
bb125:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l227, !tbaa !27
  %t479 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t479, ptr %l228, !tbaa !27
  %t480 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 0
  store i64 %t481, ptr %l229, !tbaa !24
  %t482 = load i64, ptr %l229, !tbaa !24
  %t483 = mul i64 %t482, 1
  %t484 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t483)
  %t485 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  store { i64, ptr } %t486, ptr %l230, !tbaa !27
  %t487 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = load i64, ptr %l229, !tbaa !24
  %t492 = mul i64 %t491, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t488, ptr %t490, i64 %t492, i1 false)
  %t493 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t493, ptr %l228, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t494 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t494, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l76 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l91 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l104 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb100
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 17}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb17
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l29, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 2
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l6, !tbaa !29
  br label %bb17
bb12:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 15
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l43
  br label %bb18
bb18:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb98
bb22:
  %t75 = load ptr, ptr %l5, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t76 = load ptr, ptr %l45, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l45, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 17}
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l7, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l55
  br label %bb28
bb28:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb32
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t106 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l59
  br label %bb31
bb31:
  %t107 = load i1, ptr %l59, !tbaa !21
  store i1 %t107, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb98
bb36:
  %t110 = load ptr, ptr %l5, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l61, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 17}
  %t117 = icmp eq i64 %t115, 3
  store i1 %t117, ptr %l62, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb60
bb41:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t128 = getelementptr %"compiler/typed:If", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t132 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  br i1 %t133, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb46
bb44:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l9, !tbaa !29
  %t137 = getelementptr %"compiler/typed:If", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Block", ptr %t138, i32 0, i32 1
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t144 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t134, { i64, ptr } %t141)
  store i1 %t144, ptr %l76
  br label %bb45
bb45:
  %t145 = load i1, ptr %l76, !tbaa !21
  store i1 %t145, ptr %l71, !tbaa !21
  br label %bb46
bb46:
  %t146 = load i1, ptr %l71, !tbaa !21
  br i1 %t146, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t148 = load ptr, ptr %l9, !tbaa !29
  %t150 = getelementptr %"compiler/typed:If", ptr %t148, i32 0, i32 2
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb50, label %bb51
bb50:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l83, !tbaa !29
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr %"compiler/typed:If", ptr %t158, i32 0, i32 2
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb56
bb52:
  call void @__olang_check_failed(ptr @olang_loc_b71f5ffe7a4b5626_fc1be7c1ddcacd52)
  unreachable
bb53:
  br label %bb54
bb54:
  %t165 = load ptr, ptr %l9, !tbaa !29
  %t167 = getelementptr %"compiler/typed:If", ptr %t165, i32 0, i32 2
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Block", ptr %t168, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load ptr, ptr %l83, !tbaa !29
  %t175 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t173, { i64, ptr } %t172)
  store i1 %t175, ptr %l91
  br label %bb55
bb55:
  %t176 = load i1, ptr %l91, !tbaa !21
  store i1 %t176, ptr %l82, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l82, !tbaa !21
  br i1 %t177, label %bb57, label %bb58
bb57:
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb98
bb60:
  %t179 = load ptr, ptr %l5, !tbaa !29
  store ptr %t179, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb61, label %bb62
bb61:
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 17}
  %t186 = icmp eq i64 %t184, 4
  store i1 %t186, ptr %l94, !tbaa !21
  br label %bb62
bb62:
  %t187 = load i1, ptr %l94, !tbaa !21
  br i1 %t187, label %bb63, label %bb64
bb63:
  %t188 = load ptr, ptr %l5, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l10, !tbaa !29
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t196, i32 0, i32 2
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l11, !tbaa !29
  br label %bb65
bb64:
  br label %bb77
bb65:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l10, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Block", ptr %t201, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t207 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t200, { i64, ptr } %t204)
  store i1 %t207, ptr %l104
  br label %bb66
bb66:
  %t208 = load i1, ptr %l104, !tbaa !21
  br i1 %t208, label %bb67, label %bb68
bb67:
  store i1 true, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t210 = load ptr, ptr %l11, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb70, label %bb71
bb70:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Block", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t216, { i64, ptr } %t220)
  store i1 %t223, ptr %l113
  br label %bb72
bb71:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb73
bb72:
  %t224 = load i1, ptr %l113, !tbaa !21
  store i1 %t224, ptr %l109, !tbaa !21
  br label %bb73
bb73:
  %t225 = load i1, ptr %l109, !tbaa !21
  br i1 %t225, label %bb74, label %bb75
bb74:
  store i1 true, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  br label %bb98
bb77:
  %t227 = load ptr, ptr %l5, !tbaa !29
  store ptr %t227, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb78, label %bb79
bb78:
  %t231 = load ptr, ptr %l115, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 17}
  %t234 = icmp eq i64 %t232, 11
  store i1 %t234, ptr %l116, !tbaa !21
  br label %bb79
bb79:
  %t235 = load i1, ptr %l116, !tbaa !21
  br i1 %t235, label %bb80, label %bb81
bb80:
  %t236 = load ptr, ptr %l5, !tbaa !29
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l12, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Block", ptr %t243, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t249 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t242, { i64, ptr } %t246)
  store i1 %t249, ptr %l124
  br label %bb83
bb83:
  %t250 = load i1, ptr %l124, !tbaa !21
  br i1 %t250, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb98
bb87:
  %t252 = load ptr, ptr %l5, !tbaa !29
  store ptr %t252, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t253 = load ptr, ptr %l126, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb88, label %bb89
bb88:
  %t256 = load ptr, ptr %l126, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 17}
  %t259 = icmp eq i64 %t257, 5
  store i1 %t259, ptr %l127, !tbaa !21
  br label %bb89
bb89:
  %t260 = load i1, ptr %l127, !tbaa !21
  br i1 %t260, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb98
bb93:
  br i1 true, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  store i1 true, ptr %rv
  br label %ret
bb97:
  call void @__olang_check_failed(ptr @olang_loc_80901eaab4a643b4_757281eb5f4291b0)
  unreachable
bb98:
  br label %bb99
bb99:
  %t262 = load i64, ptr %l3, !tbaa !24
  %t265 = add i64 %t262, 1
  store i64 %t265, ptr %l3, !tbaa !24
  br label %bb1
bb100:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2etaskKeeps(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/effects:Facts"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %lp30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca %"compiler/free:store"
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca %"compiler/free:letGo"
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca %"compiler/free:orStore"
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca %"compiler/free:orCall"
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca %"compiler/free:feed"
  %l75 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l84 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l89 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca %"compiler/source:Span"
  %l127 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca ptr
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca %"compiler/effects:Effects"
  %l143 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l146 = alloca i64
  %l148 = alloca i64
  %l153 = alloca i64
  %l165 = alloca i64
  %l167 = alloca i64
  %l172 = alloca i64
  %l179 = alloca %"compiler/effects:Facts"
  %l181 = alloca i1
  %l183 = alloca i1
  %l185 = alloca i1
  %l187 = alloca i1
  %l190 = alloca i1
  %l193 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca i64
  %l200 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l207 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i64
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l232 = alloca i1
  %l238 = alloca i64
  %l241 = alloca i64
  %l259 = alloca ptr
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca %"compiler/source:Span"
  %l263 = alloca i64
  %l273 = alloca i64
  %l277 = alloca i64
  %l281 = alloca i64
  %l284 = alloca i64
  %l306 = alloca i1
  %l314 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l317 = alloca i64
  %l318 = alloca { i64, ptr }
  %l324 = alloca i64
  %l327 = alloca i64
  %l351 = alloca i1
  %l352 = alloca i1
  %l356 = alloca i64
  %l358 = alloca i1
  %l361 = alloca i1
  %l366 = alloca i64
  %l369 = alloca i64
  %l387 = alloca ptr
  %l388 = alloca i64
  %l389 = alloca i64
  %l390 = alloca %"compiler/source:Span"
  %l397 = alloca ptr
  %l398 = alloca i64
  %l399 = alloca ptr
  %l400 = alloca i64
  %l403 = alloca i64
  %l406 = alloca ptr
  %l407 = alloca i64
  %l411 = alloca i64
  %l412 = alloca ptr
  %l413 = alloca i64
  %l414 = alloca i64
  %l415 = alloca %"compiler/source:Span"
  %l423 = alloca ptr
  %l424 = alloca i64
  %l425 = alloca ptr
  %l426 = alloca i64
  %l429 = alloca i64
  %l432 = alloca ptr
  %l433 = alloca i64
  %l437 = alloca i64
  %l438 = alloca ptr
  %l439 = alloca i64
  %l440 = alloca i64
  %l441 = alloca %"compiler/source:Span"
  %l451 = alloca i64
  %l453 = alloca i64
  %l458 = alloca %"compiler/free:store"
  %l472 = alloca i64
  %l476 = alloca i64
  %l479 = alloca i64
  %l500 = alloca %"compiler/free:letGo"
  %l504 = alloca i1
  %l508 = alloca i1
  %l512 = alloca i1
  %l516 = alloca i1
  %l519 = alloca i1
  %l524 = alloca i1
  %l531 = alloca i64
  %l534 = alloca i64
  %l571 = alloca i64
  %l573 = alloca i64
  %l578 = alloca %"compiler/free:orStore"
  %l581 = alloca ptr
  %l582 = alloca i64
  %l583 = alloca i64
  %l584 = alloca %"compiler/source:Span"
  %l591 = alloca i64
  %l593 = alloca i64
  %l598 = alloca %"compiler/free:orCall"
  %l601 = alloca ptr
  %l602 = alloca i64
  %l603 = alloca i64
  %l604 = alloca %"compiler/source:Span"
  %l611 = alloca i64
  %l613 = alloca i64
  %l618 = alloca %"compiler/free:feed"
  %l621 = alloca ptr
  %l622 = alloca i64
  %l623 = alloca i64
  %l624 = alloca %"compiler/source:Span"
  %l631 = alloca i64
  %l633 = alloca i64
  %l638 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l647 = alloca i64
  %l649 = alloca i64
  %l654 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l663 = alloca i64
  %l665 = alloca i64
  %l670 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l673 = alloca i64
  %l675 = alloca i64
  %l680 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l684 = alloca i1
  %l688 = alloca i1
  %l692 = alloca ptr
  %l693 = alloca i64
  %l694 = alloca i64
  %l695 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %t106 = alloca %"compiler/effects:Effects", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l89
  br label %bb1
bb1:
  %t6 = load i64, ptr %l89, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 128
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb4, label %bb5
bb3:
  br label %bb18
bb4:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb9
bb6:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l99, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l99, !tbaa !24
  store i64 %t40, ptr %l96, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l96, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l117, !tbaa !29
  store i64 %t58, ptr %l118, !tbaa !24
  %t62 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t62, ptr %l119, !tbaa !24
  %t63 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t63, ptr %l120
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l117, !tbaa !29
  %t65 = load i64, ptr %l118, !tbaa !24
  %t66 = load i64, ptr %l119, !tbaa !24
  %t67 = load %"compiler/source:Span", ptr %l120
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t64, i64 %t65, i64 %t66, i64 -1, %"compiler/source:Span" %t67, { i64, ptr } { i64 128, ptr getelementptr inbounds (<{ i64, [128 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb10
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 96
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:Free", ptr %t80, i32 0, i32 127
  %t83 = load i1, ptr %t82, !tbaa !21
  %t85 = xor i1 %t83, true
  store i1 %t85, ptr %l127, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l127, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 150
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l134, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l136, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 1
  %t103 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l138
  %t105 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %l138)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l140
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t107 = load ptr, ptr %l136, !tbaa !29
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  call void @compiler_2feffects_3aEffects_2ector(ptr %t106, ptr %v0, ptr %v0, ptr %v0, ptr %t107, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108)
  call void @llvm.memmove.p0.p0.i64(ptr %l141, ptr %t106, i64 3136, i1 false)
  br label %bb28
bb28:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 3136, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %l141, i64 3136, i1 false)
  %t111 = load ptr, ptr %l134, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t111, i32 0, i32 150
  store ptr %t109, ptr %t112, !tbaa !29
  br label %bb29
bb29:
  %t113 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %l143
  br label %bb30
bb30:
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l8
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/free:Free", ptr %t115, i32 0, i32 145
  store ptr %t117, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t119 = load i64, ptr %l10, !tbaa !24
  store i64 %t119, ptr %l146, !tbaa !24
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t120)
  store i64 %t122, ptr %l148
  br label %bb32
bb32:
  %t123 = load i64, ptr %l146, !tbaa !24
  %t124 = load i64, ptr %l148, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb33, label %bb34
bb33:
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l9, !tbaa !29
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l153
  br label %bb36
bb36:
  %t134 = load i64, ptr %l153, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t134)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t138 = load i64, ptr %l10, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l10, !tbaa !24
  br label %bb31
bb39:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:Free", ptr %t143, i32 0, i32 127
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb40, label %bb41
bb40:
  %t148 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecRoots(ptr %v0, ptr %s0, ptr %t148, ptr %l8)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/free:Free", ptr %t151, i32 0, i32 144
  store ptr %t153, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s12
  %t155 = load i64, ptr %l13, !tbaa !24
  store i64 %t155, ptr %l165, !tbaa !24
  %t156 = load ptr, ptr %l12, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t156)
  store i64 %t158, ptr %l167
  br label %bb45
bb45:
  %t159 = load i64, ptr %l165, !tbaa !24
  %t160 = load i64, ptr %l167, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s12)
  br label %bb103
bb47:
  br label %bb48
bb48:
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t165, i64 %t166)
  store i64 %t169, ptr %l172
  br label %bb49
bb49:
  %t170 = load i64, ptr %l172, !tbaa !24
  store i64 %t170, ptr %l14, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/free:Free", ptr %t171, i32 0, i32 150
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = icmp eq ptr %t174, null
  br i1 %t176, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_521e7ccdaf7a192e_299b0461ce1a73ca)
  unreachable
bb51:
  br label %bb52
bb52:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:Free", ptr %t178, i32 0, i32 150
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t182 = load i64, ptr %l14, !tbaa !24
  %t185 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t181, i64 %t182)
  store %"compiler/effects:Facts" %t185, ptr %l179
  br label %bb53
bb53:
  %t186 = load %"compiler/effects:Facts", ptr %l179
  store %"compiler/effects:Facts" %t186, ptr %l15
  %t187 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 12
  %t188 = load i1, ptr %t187, !tbaa !21
  br i1 %t188, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb56
bb55:
  %t190 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 13
  %t191 = load i1, ptr %t190, !tbaa !21
  store i1 %t191, ptr %l181, !tbaa !21
  br label %bb56
bb56:
  %t193 = load i1, ptr %l181, !tbaa !21
  br i1 %t193, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb59
bb58:
  %t194 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 17
  %t195 = load i1, ptr %t194, !tbaa !21
  store i1 %t195, ptr %l183, !tbaa !21
  br label %bb59
bb59:
  %t197 = load i1, ptr %l183, !tbaa !21
  br i1 %t197, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb62
bb61:
  %t198 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 16
  %t199 = load i1, ptr %t198, !tbaa !21
  store i1 %t199, ptr %l185, !tbaa !21
  br label %bb62
bb62:
  %t201 = load i1, ptr %l185, !tbaa !21
  br i1 %t201, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb65
bb64:
  %t202 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 24
  %t203 = load i64, ptr %t202, !tbaa !24
  %t205 = icmp ne i64 %t203, 0
  store i1 %t205, ptr %l187, !tbaa !21
  br label %bb65
bb65:
  %t207 = load i1, ptr %l187, !tbaa !21
  br i1 %t207, label %bb66, label %bb67
bb66:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:Free", ptr %t208, i32 0, i32 129
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t211, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t213, ptr %l193
  br label %bb68
bb67:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb69
bb68:
  %t214 = load i1, ptr %l193, !tbaa !21
  store i1 %t214, ptr %l190, !tbaa !21
  br label %bb69
bb69:
  %t215 = load i1, ptr %l190, !tbaa !21
  br i1 %t215, label %bb70, label %bb71
bb70:
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l194, !tbaa !29
  %t217 = call ptr @__olang_scope_hold(ptr %v0)
  %t218 = ptrtoint ptr %t217 to i64
  store i64 %t218, ptr %l195, !tbaa !24
  %t219 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e129
  br i1 %t219, label %bb72, label %bb73
bb71:
  br label %bb80
bb72:
  %t221 = call ptr @__olang_region_make_part(ptr %v0)
  %t222 = ptrtoint ptr %t221 to i64
  store i64 %t222, ptr %l195, !tbaa !24
  br label %bb73
bb73:
  store { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l197, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t223, ptr %l198, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l199, !tbaa !24
  %t226 = load i64, ptr %l199, !tbaa !24
  %t227 = mul i64 %t226, 1
  %t228 = load i64, ptr %l195
  %t229 = inttoptr i64 %t228 to ptr
  %t230 = call ptr @__olang_held_alloc(ptr %t229, i64 %t227)
  %t231 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  store { i64, ptr } %t232, ptr %l200, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = load i64, ptr %l199, !tbaa !24
  %t238 = mul i64 %t237, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t234, ptr %t236, i64 %t238, i1 false)
  %t239 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e129
  br i1 %t239, label %bb74, label %bb75
bb74:
  %t241 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t244 = icmp eq i64 %t242, 0
  br i1 %t244, label %bb76, label %bb77
bb75:
  %t246 = load ptr, ptr %l194, !tbaa !29
  %t247 = getelementptr %"compiler/free:Free", ptr %t246, i32 0, i32 129
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l204, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t250 = load ptr, ptr %l194, !tbaa !29
  %t251 = getelementptr %"compiler/free:Free", ptr %t250, i32 0, i32 129
  store { i64, ptr } %t249, ptr %t251, !tbaa !27
  %t252 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e129
  br i1 %t252, label %bb78, label %bb79
bb76:
  store { i64, ptr } zeroinitializer, ptr %l200, !tbaa !27
  br label %bb77
bb77:
  %t254 = load i64, ptr %l195
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = load { i64, ptr }, ptr %l200
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = call ptr @__olang_region_or(ptr %t257, ptr null)
  %t259 = icmp ne ptr %t258, null
  %t260 = select i1 %t259, ptr %t258, ptr null
  call void @__olang_region_settle_in(ptr %t255, ptr %t260)
  br label %bb75
bb78:
  %t261 = load { i64, ptr }, ptr %l204
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  call void @__olang_region_release_part(ptr %t263, i64 %t262)
  store { i64, ptr } zeroinitializer, ptr %l204
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t264 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 4
  %t265 = load i1, ptr %t264, !tbaa !21
  br i1 %t265, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb83
bb82:
  %t267 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 5
  %t268 = load i1, ptr %t267, !tbaa !21
  store i1 %t268, ptr %l207, !tbaa !21
  br label %bb83
bb83:
  %t270 = load i1, ptr %l207, !tbaa !21
  br i1 %t270, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l209, !tbaa !21
  br label %bb86
bb85:
  %t271 = getelementptr %"compiler/effects:Facts", ptr %l15, i32 0, i32 3
  %t272 = load i1, ptr %t271, !tbaa !21
  store i1 %t272, ptr %l209, !tbaa !21
  br label %bb86
bb86:
  %t274 = load i1, ptr %l209, !tbaa !21
  br i1 %t274, label %bb87, label %bb88
bb87:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/free:Free", ptr %t275, i32 0, i32 130
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t278, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t280, ptr %l214
  br label %bb89
bb88:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb90
bb89:
  %t281 = load i1, ptr %l214, !tbaa !21
  store i1 %t281, ptr %l211, !tbaa !21
  br label %bb90
bb90:
  %t282 = load i1, ptr %l211, !tbaa !21
  br i1 %t282, label %bb91, label %bb92
bb91:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l215, !tbaa !29
  %t284 = call ptr @__olang_scope_hold(ptr %v0)
  %t285 = ptrtoint ptr %t284 to i64
  store i64 %t285, ptr %l216, !tbaa !24
  %t286 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e130
  br i1 %t286, label %bb93, label %bb94
bb92:
  br label %bb101
bb93:
  %t288 = call ptr @__olang_region_make_part(ptr %v0)
  %t289 = ptrtoint ptr %t288 to i64
  store i64 %t289, ptr %l216, !tbaa !24
  br label %bb94
bb94:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l218, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t290, ptr %l219, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 0
  store i64 %t292, ptr %l220, !tbaa !24
  %t293 = load i64, ptr %l220, !tbaa !24
  %t294 = mul i64 %t293, 1
  %t295 = load i64, ptr %l216
  %t296 = inttoptr i64 %t295 to ptr
  %t297 = call ptr @__olang_held_alloc(ptr %t296, i64 %t294)
  %t298 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l221, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l220, !tbaa !24
  %t305 = mul i64 %t304, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t301, ptr %t303, i64 %t305, i1 false)
  %t306 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e130
  br i1 %t306, label %bb95, label %bb96
bb95:
  %t308 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t311 = icmp eq i64 %t309, 0
  br i1 %t311, label %bb97, label %bb98
bb96:
  %t313 = load ptr, ptr %l215, !tbaa !29
  %t314 = getelementptr %"compiler/free:Free", ptr %t313, i32 0, i32 130
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l225, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t317 = load ptr, ptr %l215, !tbaa !29
  %t318 = getelementptr %"compiler/free:Free", ptr %t317, i32 0, i32 130
  store { i64, ptr } %t316, ptr %t318, !tbaa !27
  %t319 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e130
  br i1 %t319, label %bb99, label %bb100
bb97:
  store { i64, ptr } zeroinitializer, ptr %l221, !tbaa !27
  br label %bb98
bb98:
  %t321 = load i64, ptr %l216
  %t322 = inttoptr i64 %t321 to ptr
  %t323 = load { i64, ptr }, ptr %l221
  %t324 = extractvalue { i64, ptr } %t323, 1
  %t325 = call ptr @__olang_region_or(ptr %t324, ptr null)
  %t326 = icmp ne ptr %t325, null
  %t327 = select i1 %t326, ptr %t325, ptr null
  call void @__olang_region_settle_in(ptr %t322, ptr %t327)
  br label %bb96
bb99:
  %t328 = load { i64, ptr }, ptr %l225
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t330 = extractvalue { i64, ptr } %t328, 1
  call void @__olang_region_release_part(ptr %t330, i64 %t329)
  store { i64, ptr } zeroinitializer, ptr %l225
  br label %bb100
bb100:
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s12)
  br label %bb102
bb102:
  %t331 = load i64, ptr %l13, !tbaa !24
  %t334 = add i64 %t331, 1
  store i64 %t334, ptr %l13, !tbaa !24
  br label %bb44
bb103:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/free:Free", ptr %t336, i32 0, i32 129
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  %t341 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t339, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t341, ptr %l232
  br label %bb104
bb104:
  %t342 = load i1, ptr %l232, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb105, label %bb106
bb105:
  store i64 0, ptr %l16, !tbaa !24
  %t345 = load i64, ptr %l1, !tbaa !24
  store i64 %t345, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t347 = load i64, ptr %l17, !tbaa !24
  %t348 = load i64, ptr %l16, !tbaa !24
  %t351 = icmp sgt i64 %t347, %t348
  br i1 %t351, label %bb107, label %bb108
bb106:
  br label %bb123
bb107:
  %t353 = load i64, ptr %l18, !tbaa !24
  %t355 = icmp sgt i64 %t353, 0
  br i1 %t355, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb112
bb109:
  %t357 = load i64, ptr %l17, !tbaa !24
  %t358 = load i64, ptr %l16, !tbaa !24
  %t361 = sub i64 %t357, %t358
  %t362 = load i64, ptr %l18, !tbaa !24
  %t365 = add i64 %t361, %t362
  %t367 = sub i64 %t365, 1
  %t368 = load i64, ptr %l18, !tbaa !24
  %t371 = sdiv i64 %t367, %t368
  store i64 %t371, ptr %l241, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb111
bb111:
  %t373 = load i64, ptr %l241, !tbaa !24
  store i64 %t373, ptr %l238, !tbaa !24
  br label %bb112
bb112:
  %t374 = load i64, ptr %l238, !tbaa !24
  store i64 %t374, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s18
  %t375 = load i64, ptr %l20, !tbaa !24
  %t376 = load i64, ptr %l19, !tbaa !24
  %t379 = icmp slt i64 %t375, %t376
  %t381 = xor i1 %t379, true
  br i1 %t381, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s18)
  br label %bb122
bb115:
  br label %bb116
bb116:
  %t383 = load i64, ptr %l16, !tbaa !24
  %t384 = load i64, ptr %l20, !tbaa !24
  %t385 = load i64, ptr %l18, !tbaa !24
  %t388 = mul i64 %t384, %t385
  %t391 = add i64 %t383, %t388
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l259, !tbaa !29
  store i64 %t391, ptr %l260, !tbaa !24
  %t395 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t395, ptr %l261, !tbaa !24
  %t396 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s18, i32 0, i32 0)
  store %"compiler/source:Span" %t396, ptr %l262
  br label %bb117
bb117:
  %t397 = call ptr @__olang_scope_hold(ptr %v0)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l263, !tbaa !24
  %t399 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t399, label %bb118, label %bb119
bb118:
  %t401 = call ptr @__olang_region_make(ptr %v0)
  %t402 = ptrtoint ptr %t401 to i64
  store i64 %t402, ptr %l263, !tbaa !24
  br label %bb119
bb119:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/free:Free", ptr %t403, i32 0, i32 129
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t406, 1
  %t409 = extractvalue { i64, ptr } %t406, 0
  %t410 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t412 = add i64 %t409, %t411
  %t413 = load i64, ptr %l263
  %t414 = inttoptr i64 %t413 to ptr
  %t415 = call ptr @__olang_held_alloc(ptr %t414, i64 %t412)
  call void @olang_textcopy(ptr %t415, ptr %t408, i64 %t409)
  %t416 = getelementptr i8, ptr %t415, i64 %t409
  call void @olang_textcopy(ptr %t416, ptr %t410, i64 %t411)
  %t417 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t415, 1
  %t420 = load ptr, ptr %l259, !tbaa !29
  %t421 = load i64, ptr %l260, !tbaa !24
  %t422 = load i64, ptr %l261, !tbaa !24
  %t423 = load %"compiler/source:Span", ptr %l262
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t420, i64 %t421, i64 %t422, i64 -1, %"compiler/source:Span" %t423, { i64, ptr } %t418)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s18)
  br label %bb121
bb121:
  %t425 = load i64, ptr %l20, !tbaa !24
  %t428 = add i64 %t425, 1
  store i64 %t428, ptr %l20, !tbaa !24
  br label %bb113
bb122:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb123:
  %t431 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l8)
  store i64 %t431, ptr %l273
  br label %bb124
bb124:
  %t432 = load i64, ptr %l273, !tbaa !24
  %t433 = icmp sgt i64 %t432, 0
  store i1 %t433, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/free:Free", ptr %t435, i32 0, i32 1
  %t439 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t437)
  store i64 %t439, ptr %l277
  br label %bb125
bb125:
  %t440 = load i64, ptr %l277, !tbaa !24
  store i64 %t440, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t441 = load i64, ptr %l24, !tbaa !24
  %t442 = load i64, ptr %l23, !tbaa !24
  %t445 = icmp sgt i64 %t441, %t442
  br i1 %t445, label %bb126, label %bb127
bb126:
  %t447 = load i64, ptr %l25, !tbaa !24
  %t449 = icmp sgt i64 %t447, 0
  br i1 %t449, label %bb128, label %bb129
bb127:
  store i64 0, ptr %l281, !tbaa !24
  br label %bb131
bb128:
  %t451 = load i64, ptr %l24, !tbaa !24
  %t452 = load i64, ptr %l23, !tbaa !24
  %t455 = sub i64 %t451, %t452
  %t456 = load i64, ptr %l25, !tbaa !24
  %t459 = add i64 %t455, %t456
  %t461 = sub i64 %t459, 1
  %t462 = load i64, ptr %l25, !tbaa !24
  %t465 = sdiv i64 %t461, %t462
  store i64 %t465, ptr %l284, !tbaa !24
  br label %bb130
bb129:
  store i64 0, ptr %l284, !tbaa !24
  br label %bb130
bb130:
  %t467 = load i64, ptr %l284, !tbaa !24
  store i64 %t467, ptr %l281, !tbaa !24
  br label %bb131
bb131:
  %t468 = load i64, ptr %l281, !tbaa !24
  store i64 %t468, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb132
bb132:
  %t469 = load i64, ptr %l27, !tbaa !24
  %t470 = load i64, ptr %l26, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb133, label %bb134
bb133:
  br label %bb145
bb134:
  br label %bb135
bb135:
  %t477 = load i64, ptr %l23, !tbaa !24
  %t478 = load i64, ptr %l27, !tbaa !24
  %t479 = load i64, ptr %l25, !tbaa !24
  %t482 = mul i64 %t478, %t479
  %t485 = add i64 %t477, %t482
  store i64 %t485, ptr %l28, !tbaa !24
  %t487 = load i1, ptr %l22, !tbaa !21
  %t489 = xor i1 %t487, true
  br i1 %t489, label %bb136, label %bb137
bb136:
  br label %bb145
bb137:
  br label %bb138
bb138:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i64, ptr %l28, !tbaa !24
  %t495 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %t491, i64 %t492)
  store i1 %t495, ptr %l306
  br label %bb139
bb139:
  %t496 = load i1, ptr %l306, !tbaa !21
  br i1 %t496, label %bb140, label %bb141
bb140:
  %t497 = load i64, ptr %l28, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t497)
  br label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t500 = load i64, ptr %l27, !tbaa !24
  %t503 = add i64 %t500, 1
  store i64 %t503, ptr %l27, !tbaa !24
  br label %bb132
bb145:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t508 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereached(ptr %v0, ptr %s0, ptr %s0, ptr %t505, ptr %l8, i1 true)
  store { i64, ptr } %t508, ptr %l314
  br label %bb146
bb146:
  %t509 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t509, ptr %l29, !tbaa !27
  store { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l315, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l315, !tbaa !27
  store { i64, ptr } %t510, ptr %l316, !tbaa !27
  %t511 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 0
  store i64 %t512, ptr %l317, !tbaa !24
  %t513 = load i64, ptr %l317, !tbaa !24
  %t514 = mul i64 %t513, 1
  %t515 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t514)
  %t516 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t515, 1
  store { i64, ptr } %t517, ptr %l318, !tbaa !27
  %t518 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = load i64, ptr %l317, !tbaa !24
  %t523 = mul i64 %t522, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t519, ptr %t521, i64 %t523, i1 false)
  %t524 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t524, ptr %lp30
  %t525 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t526 = load ptr, ptr %lp30
  store { i64, ptr } %t525, ptr %t526, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t527, 0
  store i64 %t529, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t531 = load i64, ptr %l32, !tbaa !24
  %t532 = load i64, ptr %l31, !tbaa !24
  %t535 = icmp sgt i64 %t531, %t532
  br i1 %t535, label %bb147, label %bb148
bb147:
  %t537 = load i64, ptr %l33, !tbaa !24
  %t539 = icmp sgt i64 %t537, 0
  br i1 %t539, label %bb149, label %bb150
bb148:
  store i64 0, ptr %l324, !tbaa !24
  br label %bb152
bb149:
  %t541 = load i64, ptr %l32, !tbaa !24
  %t542 = load i64, ptr %l31, !tbaa !24
  %t545 = sub i64 %t541, %t542
  %t546 = load i64, ptr %l33, !tbaa !24
  %t549 = add i64 %t545, %t546
  %t551 = sub i64 %t549, 1
  %t552 = load i64, ptr %l33, !tbaa !24
  %t555 = sdiv i64 %t551, %t552
  store i64 %t555, ptr %l327, !tbaa !24
  br label %bb151
bb150:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb151
bb151:
  %t557 = load i64, ptr %l327, !tbaa !24
  store i64 %t557, ptr %l324, !tbaa !24
  br label %bb152
bb152:
  %t558 = load i64, ptr %l324, !tbaa !24
  store i64 %t558, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb153
bb153:
  %t559 = load i64, ptr %l35, !tbaa !24
  %t560 = load i64, ptr %l34, !tbaa !24
  %t563 = icmp slt i64 %t559, %t560
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb154, label %bb155
bb154:
  br label %bb217
bb155:
  br label %bb156
bb156:
  %t567 = load i64, ptr %l31, !tbaa !24
  %t568 = load i64, ptr %l35, !tbaa !24
  %t569 = load i64, ptr %l33, !tbaa !24
  %t572 = mul i64 %t568, %t569
  %t575 = add i64 %t567, %t572
  store i64 %t575, ptr %l36, !tbaa !24
  %t577 = load i64, ptr %l36, !tbaa !24
  %t579 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr i1, ptr %t580, i64 %t577
  %t582 = load i1, ptr %t581, !tbaa !31
  %t584 = xor i1 %t582, true
  br i1 %t584, label %bb157, label %bb158
bb157:
  br label %bb216
bb158:
  br label %bb159
bb159:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/free:Free", ptr %t586, i32 0, i32 78
  %t589 = load i64, ptr %l36, !tbaa !24
  %t592 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t588, i64 %t589)
  store i1 %t592, ptr %l351
  br label %bb160
bb160:
  %t593 = load i1, ptr %l351, !tbaa !21
  br i1 %t593, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l352, !tbaa !21
  br label %bb168
bb162:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/free:Free", ptr %t594, i32 0, i32 85
  %t597 = load i64, ptr %l36, !tbaa !24
  %t600 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t596, i64 %t597)
  store i64 %t600, ptr %l356
  br label %bb163
bb163:
  %t601 = load i64, ptr %l356, !tbaa !24
  %t602 = icmp ne i64 %t601, 0
  br i1 %t602, label %bb164, label %bb165
bb164:
  %t604 = load i64, ptr %l36, !tbaa !24
  %t607 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %l8, i64 %t604)
  store i1 %t607, ptr %l361
  br label %bb166
bb165:
  store i1 false, ptr %l358, !tbaa !21
  br label %bb167
bb166:
  %t608 = load i1, ptr %l361, !tbaa !21
  store i1 %t608, ptr %l358, !tbaa !21
  br label %bb167
bb167:
  %t609 = load i1, ptr %l358, !tbaa !21
  store i1 %t609, ptr %l352, !tbaa !21
  br label %bb168
bb168:
  %t610 = load i1, ptr %l352, !tbaa !21
  br i1 %t610, label %bb169, label %bb170
bb169:
  store i64 0, ptr %l37, !tbaa !24
  %t611 = load i64, ptr %l1, !tbaa !24
  store i64 %t611, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t613 = load i64, ptr %l38, !tbaa !24
  %t614 = load i64, ptr %l37, !tbaa !24
  %t617 = icmp sgt i64 %t613, %t614
  br i1 %t617, label %bb171, label %bb172
bb170:
  br label %bb185
bb171:
  %t619 = load i64, ptr %l39, !tbaa !24
  %t621 = icmp sgt i64 %t619, 0
  br i1 %t621, label %bb173, label %bb174
bb172:
  store i64 0, ptr %l366, !tbaa !24
  br label %bb176
bb173:
  %t623 = load i64, ptr %l38, !tbaa !24
  %t624 = load i64, ptr %l37, !tbaa !24
  %t627 = sub i64 %t623, %t624
  %t628 = load i64, ptr %l39, !tbaa !24
  %t631 = add i64 %t627, %t628
  %t633 = sub i64 %t631, 1
  %t634 = load i64, ptr %l39, !tbaa !24
  %t637 = sdiv i64 %t633, %t634
  store i64 %t637, ptr %l369, !tbaa !24
  br label %bb175
bb174:
  store i64 0, ptr %l369, !tbaa !24
  br label %bb175
bb175:
  %t639 = load i64, ptr %l369, !tbaa !24
  store i64 %t639, ptr %l366, !tbaa !24
  br label %bb176
bb176:
  %t640 = load i64, ptr %l366, !tbaa !24
  store i64 %t640, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb177
bb177:
  store %olang.scope zeroinitializer, ptr %s31
  %t641 = load i64, ptr %l41, !tbaa !24
  %t642 = load i64, ptr %l40, !tbaa !24
  %t645 = icmp slt i64 %t641, %t642
  %t647 = xor i1 %t645, true
  br i1 %t647, label %bb178, label %bb179
bb178:
  call void @__olang_scope_close(ptr %s31)
  br label %bb184
bb179:
  br label %bb180
bb180:
  %t649 = load i64, ptr %l37, !tbaa !24
  %t650 = load i64, ptr %l41, !tbaa !24
  %t651 = load i64, ptr %l39, !tbaa !24
  %t654 = mul i64 %t650, %t651
  %t657 = add i64 %t649, %t654
  %t659 = load ptr, ptr %l0, !tbaa !29
  store ptr %t659, ptr %l387, !tbaa !29
  store i64 %t657, ptr %l388, !tbaa !24
  %t661 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t661, ptr %l389, !tbaa !24
  %t662 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s31, i32 0, i32 0)
  store %"compiler/source:Span" %t662, ptr %l390
  br label %bb181
bb181:
  %t663 = load ptr, ptr %l387, !tbaa !29
  %t664 = load i64, ptr %l388, !tbaa !24
  %t665 = load i64, ptr %l389, !tbaa !24
  %t666 = load %"compiler/source:Span", ptr %l390
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t663, i64 %t664, i64 %t665, i64 -1, %"compiler/source:Span" %t666, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s31)
  br label %bb183
bb183:
  %t667 = load i64, ptr %l41, !tbaa !24
  %t670 = add i64 %t667, 1
  store i64 %t670, ptr %l41, !tbaa !24
  br label %bb177
bb184:
  br label %bb185
bb185:
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t674 = getelementptr %"compiler/free:Free", ptr %t672, i32 0, i32 76
  %t675 = load i64, ptr %l36, !tbaa !24
  %t678 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t674, i64 %t675)
  store ptr %t678, ptr %l397
  br label %bb186
bb186:
  %t679 = load ptr, ptr %l397, !tbaa !29
  store ptr %t679, ptr %l43, !tbaa !29
  store i64 0, ptr %l44, !tbaa !24
  br label %bb187
bb187:
  store %olang.scope zeroinitializer, ptr %s34
  %t680 = load i64, ptr %l44, !tbaa !24
  store i64 %t680, ptr %l398, !tbaa !24
  %t681 = load ptr, ptr %l43, !tbaa !29
  store ptr %t681, ptr %l399, !tbaa !29
  %t682 = call ptr @__olang_scope_hold(ptr %v0)
  %t683 = ptrtoint ptr %t682 to i64
  store i64 %t683, ptr %l400, !tbaa !24
  %t684 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t684, label %bb188, label %bb189
bb188:
  %t686 = load ptr, ptr %l399, !tbaa !29
  %t687 = call ptr @__olang_region_or(ptr %t686, ptr %v0)
  %t688 = call ptr @__olang_scope_hold(ptr %t687)
  %t689 = ptrtoint ptr %t688 to i64
  store i64 %t689, ptr %l400, !tbaa !24
  br label %bb189
bb189:
  %t690 = load ptr, ptr %l43, !tbaa !29
  %t691 = load i64, ptr %l400
  %t692 = inttoptr i64 %t691 to ptr
  %t694 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t692, ptr %t690)
  store i64 %t694, ptr %l403
  br label %bb190
bb190:
  %t695 = load i64, ptr %l398, !tbaa !24
  %t696 = load i64, ptr %l403, !tbaa !24
  %t697 = icmp slt i64 %t695, %t696
  %t699 = xor i1 %t697, true
  br i1 %t699, label %bb191, label %bb192
bb191:
  call void @__olang_scope_close(ptr %s34)
  br label %bb200
bb192:
  br label %bb193
bb193:
  %t701 = load ptr, ptr %l43, !tbaa !29
  store ptr %t701, ptr %l406, !tbaa !29
  %t702 = call ptr @__olang_scope_hold(ptr %v0)
  %t703 = ptrtoint ptr %t702 to i64
  store i64 %t703, ptr %l407, !tbaa !24
  %t704 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t704, label %bb194, label %bb195
bb194:
  %t706 = load ptr, ptr %l406, !tbaa !29
  %t707 = call ptr @__olang_region_or(ptr %t706, ptr %v0)
  %t708 = call ptr @__olang_scope_hold(ptr %t707)
  %t709 = ptrtoint ptr %t708 to i64
  store i64 %t709, ptr %l407, !tbaa !24
  br label %bb195
bb195:
  %t710 = load ptr, ptr %l43, !tbaa !29
  %t711 = load i64, ptr %l44, !tbaa !24
  %t712 = load i64, ptr %l407
  %t713 = inttoptr i64 %t712 to ptr
  %t716 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t713, ptr %t710, i64 %t711)
  store i64 %t716, ptr %l411
  br label %bb196
bb196:
  %t717 = load i64, ptr %l411, !tbaa !24
  %t718 = load ptr, ptr %l0, !tbaa !29
  store ptr %t718, ptr %l412, !tbaa !29
  store i64 %t717, ptr %l413, !tbaa !24
  %t720 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t720, ptr %l414, !tbaa !24
  %t721 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s34, i32 0, i32 0)
  store %"compiler/source:Span" %t721, ptr %l415
  br label %bb197
bb197:
  %t722 = load ptr, ptr %lp30
  %t723 = load { i64, ptr }, ptr %t722, !tbaa !27
  %t724 = load ptr, ptr %l412, !tbaa !29
  %t725 = load i64, ptr %l413, !tbaa !24
  %t726 = load i64, ptr %l414, !tbaa !24
  %t727 = load %"compiler/source:Span", ptr %l415
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t724, i64 %t725, i64 %t726, i64 -1, %"compiler/source:Span" %t727, { i64, ptr } %t723)
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s34)
  br label %bb199
bb199:
  %t729 = load i64, ptr %l44, !tbaa !24
  %t732 = add i64 %t729, 1
  store i64 %t732, ptr %l44, !tbaa !24
  br label %bb187
bb200:
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/free:Free", ptr %t734, i32 0, i32 77
  %t737 = load i64, ptr %l36, !tbaa !24
  %t740 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t736, i64 %t737)
  store ptr %t740, ptr %l423
  br label %bb201
bb201:
  %t741 = load ptr, ptr %l423, !tbaa !29
  store ptr %t741, ptr %l46, !tbaa !29
  store i64 0, ptr %l47, !tbaa !24
  br label %bb202
bb202:
  store %olang.scope zeroinitializer, ptr %s37
  %t742 = load i64, ptr %l47, !tbaa !24
  store i64 %t742, ptr %l424, !tbaa !24
  %t743 = load ptr, ptr %l46, !tbaa !29
  store ptr %t743, ptr %l425, !tbaa !29
  %t744 = call ptr @__olang_scope_hold(ptr %v0)
  %t745 = ptrtoint ptr %t744 to i64
  store i64 %t745, ptr %l426, !tbaa !24
  %t746 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t746, label %bb203, label %bb204
bb203:
  %t748 = load ptr, ptr %l425, !tbaa !29
  %t749 = call ptr @__olang_region_or(ptr %t748, ptr %v0)
  %t750 = call ptr @__olang_scope_hold(ptr %t749)
  %t751 = ptrtoint ptr %t750 to i64
  store i64 %t751, ptr %l426, !tbaa !24
  br label %bb204
bb204:
  %t752 = load ptr, ptr %l46, !tbaa !29
  %t753 = load i64, ptr %l426
  %t754 = inttoptr i64 %t753 to ptr
  %t756 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t754, ptr %t752)
  store i64 %t756, ptr %l429
  br label %bb205
bb205:
  %t757 = load i64, ptr %l424, !tbaa !24
  %t758 = load i64, ptr %l429, !tbaa !24
  %t759 = icmp slt i64 %t757, %t758
  %t761 = xor i1 %t759, true
  br i1 %t761, label %bb206, label %bb207
bb206:
  call void @__olang_scope_close(ptr %s37)
  br label %bb215
bb207:
  br label %bb208
bb208:
  %t763 = load ptr, ptr %l46, !tbaa !29
  store ptr %t763, ptr %l432, !tbaa !29
  %t764 = call ptr @__olang_scope_hold(ptr %v0)
  %t765 = ptrtoint ptr %t764 to i64
  store i64 %t765, ptr %l433, !tbaa !24
  %t766 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t766, label %bb209, label %bb210
bb209:
  %t768 = load ptr, ptr %l432, !tbaa !29
  %t769 = call ptr @__olang_region_or(ptr %t768, ptr %v0)
  %t770 = call ptr @__olang_scope_hold(ptr %t769)
  %t771 = ptrtoint ptr %t770 to i64
  store i64 %t771, ptr %l433, !tbaa !24
  br label %bb210
bb210:
  %t772 = load ptr, ptr %l46, !tbaa !29
  %t773 = load i64, ptr %l47, !tbaa !24
  %t774 = load i64, ptr %l433
  %t775 = inttoptr i64 %t774 to ptr
  %t778 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t775, ptr %t772, i64 %t773)
  store i64 %t778, ptr %l437
  br label %bb211
bb211:
  %t779 = load i64, ptr %l437, !tbaa !24
  %t780 = load ptr, ptr %l0, !tbaa !29
  store ptr %t780, ptr %l438, !tbaa !29
  store i64 %t779, ptr %l439, !tbaa !24
  %t782 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t782, ptr %l440, !tbaa !24
  %t783 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s37, i32 0, i32 0)
  store %"compiler/source:Span" %t783, ptr %l441
  br label %bb212
bb212:
  %t784 = load ptr, ptr %lp30
  %t785 = load { i64, ptr }, ptr %t784, !tbaa !27
  %t786 = load ptr, ptr %l438, !tbaa !29
  %t787 = load i64, ptr %l439, !tbaa !24
  %t788 = load i64, ptr %l440, !tbaa !24
  %t789 = load %"compiler/source:Span", ptr %l441
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t786, i64 %t787, i64 %t788, i64 -1, %"compiler/source:Span" %t789, { i64, ptr } %t785)
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s37)
  br label %bb214
bb214:
  %t791 = load i64, ptr %l47, !tbaa !24
  %t794 = add i64 %t791, 1
  store i64 %t794, ptr %l47, !tbaa !24
  br label %bb202
bb215:
  br label %bb216
bb216:
  %t796 = load i64, ptr %l35, !tbaa !24
  %t799 = add i64 %t796, 1
  store i64 %t799, ptr %l35, !tbaa !24
  br label %bb153
bb217:
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/free:Free", ptr %t801, i32 0, i32 101
  store ptr %t803, ptr %l49, !tbaa !29
  store i64 0, ptr %l50, !tbaa !24
  br label %bb218
bb218:
  %t805 = load i64, ptr %l50, !tbaa !24
  store i64 %t805, ptr %l451, !tbaa !24
  %t806 = load ptr, ptr %l49, !tbaa !29
  %t808 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t806)
  store i64 %t808, ptr %l453
  br label %bb219
bb219:
  %t809 = load i64, ptr %l451, !tbaa !24
  %t810 = load i64, ptr %l453, !tbaa !24
  %t811 = icmp slt i64 %t809, %t810
  %t813 = xor i1 %t811, true
  br i1 %t813, label %bb220, label %bb221
bb220:
  br label %bb229
bb221:
  br label %bb222
bb222:
  %t815 = load ptr, ptr %l49, !tbaa !29
  %t816 = load i64, ptr %l50, !tbaa !24
  %t819 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t815, i64 %t816)
  store %"compiler/free:store" %t819, ptr %l458
  br label %bb223
bb223:
  %t820 = load %"compiler/free:store", ptr %l458
  store %"compiler/free:store" %t820, ptr %l51
  %t821 = getelementptr %"compiler/free:store", ptr %l51, i32 0, i32 1
  %t822 = load i64, ptr %t821, !tbaa !24
  %t824 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !27
  %t826 = getelementptr i1, ptr %t825, i64 %t822
  %t827 = load i1, ptr %t826, !tbaa !31
  br i1 %t827, label %bb224, label %bb225
bb224:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/free:store", ptr %l51, i32 0, i32 0
  %t831 = load i64, ptr %t830, !tbaa !24
  %t832 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  %t833 = getelementptr %"compiler/free:store", ptr %l51, i32 0, i32 2
  %t834 = load i64, ptr %t833, !tbaa !24
  %t835 = getelementptr %"compiler/free:store", ptr %l51, i32 0, i32 3
  %t836 = load %"compiler/source:Span", ptr %t835
  %t837 = load ptr, ptr %lp30
  %t838 = load { i64, ptr }, ptr %t837, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t829, i64 %t831, i64 %t832, i64 %t834, %"compiler/source:Span" %t836, { i64, ptr } %t838)
  br label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb227
bb227:
  br label %bb228
bb228:
  %t845 = load i64, ptr %l50, !tbaa !24
  %t848 = add i64 %t845, 1
  store i64 %t848, ptr %l50, !tbaa !24
  br label %bb218
bb229:
  store i64 0, ptr %l52, !tbaa !24
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/free:Free", ptr %t850, i32 0, i32 102
  %t854 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t852)
  store i64 %t854, ptr %l472
  br label %bb230
bb230:
  %t855 = load i64, ptr %l472, !tbaa !24
  store i64 %t855, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t856 = load i64, ptr %l53, !tbaa !24
  %t857 = load i64, ptr %l52, !tbaa !24
  %t860 = icmp sgt i64 %t856, %t857
  br i1 %t860, label %bb231, label %bb232
bb231:
  %t862 = load i64, ptr %l54, !tbaa !24
  %t864 = icmp sgt i64 %t862, 0
  br i1 %t864, label %bb233, label %bb234
bb232:
  store i64 0, ptr %l476, !tbaa !24
  br label %bb236
bb233:
  %t866 = load i64, ptr %l53, !tbaa !24
  %t867 = load i64, ptr %l52, !tbaa !24
  %t870 = sub i64 %t866, %t867
  %t871 = load i64, ptr %l54, !tbaa !24
  %t874 = add i64 %t870, %t871
  %t876 = sub i64 %t874, 1
  %t877 = load i64, ptr %l54, !tbaa !24
  %t880 = sdiv i64 %t876, %t877
  store i64 %t880, ptr %l479, !tbaa !24
  br label %bb235
bb234:
  store i64 0, ptr %l479, !tbaa !24
  br label %bb235
bb235:
  %t882 = load i64, ptr %l479, !tbaa !24
  store i64 %t882, ptr %l476, !tbaa !24
  br label %bb236
bb236:
  %t883 = load i64, ptr %l476, !tbaa !24
  store i64 %t883, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb237
bb237:
  %t884 = load i64, ptr %l56, !tbaa !24
  %t885 = load i64, ptr %l55, !tbaa !24
  %t888 = icmp slt i64 %t884, %t885
  %t890 = xor i1 %t888, true
  br i1 %t890, label %bb238, label %bb239
bb238:
  br label %bb277
bb239:
  br label %bb240
bb240:
  %t892 = load i64, ptr %l52, !tbaa !24
  %t893 = load i64, ptr %l56, !tbaa !24
  %t894 = load i64, ptr %l54, !tbaa !24
  %t897 = mul i64 %t893, %t894
  %t900 = add i64 %t892, %t897
  store i64 %t900, ptr %l57, !tbaa !24
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t904 = getelementptr %"compiler/free:Free", ptr %t902, i32 0, i32 102
  %t905 = load i64, ptr %l57, !tbaa !24
  %t908 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t904, i64 %t905)
  store %"compiler/free:letGo" %t908, ptr %l500
  br label %bb241
bb241:
  %t909 = load %"compiler/free:letGo", ptr %l500
  store %"compiler/free:letGo" %t909, ptr %l58
  %t910 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 1
  %t911 = load i64, ptr %t910, !tbaa !24
  %t913 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t914 = load ptr, ptr %t913, !tbaa !27
  %t915 = getelementptr i1, ptr %t914, i64 %t911
  %t916 = load i1, ptr %t915, !tbaa !31
  %t918 = xor i1 %t916, true
  br i1 %t918, label %bb242, label %bb243
bb242:
  store i1 true, ptr %l504, !tbaa !21
  br label %bb245
bb243:
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t922 = getelementptr %"compiler/free:Free", ptr %t920, i32 0, i32 103
  %t923 = load i64, ptr %l57, !tbaa !24
  %t926 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t922, i64 %t923)
  store i1 %t926, ptr %l508
  br label %bb244
bb244:
  %t927 = load i1, ptr %l508, !tbaa !21
  store i1 %t927, ptr %l504, !tbaa !21
  br label %bb245
bb245:
  %t928 = load i1, ptr %l504, !tbaa !21
  br i1 %t928, label %bb246, label %bb247
bb246:
  br label %bb276
bb247:
  br label %bb248
bb248:
  %t929 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 7
  %t930 = load i64, ptr %t929, !tbaa !24
  %t931 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeVia, !tbaa !24
  %t934 = icmp eq i64 %t930, %t931
  br i1 %t934, label %bb249, label %bb250
bb249:
  store i1 true, ptr %l512, !tbaa !21
  br label %bb251
bb250:
  %t936 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 7
  %t937 = load i64, ptr %t936, !tbaa !24
  %t938 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeViaGiven, !tbaa !24
  %t941 = icmp eq i64 %t937, %t938
  store i1 %t941, ptr %l512, !tbaa !21
  br label %bb251
bb251:
  %t943 = load i1, ptr %l512, !tbaa !21
  br i1 %t943, label %bb252, label %bb253
bb252:
  %t944 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 1
  %t945 = load i64, ptr %t944, !tbaa !24
  %t948 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %l8, i64 %t945)
  store i1 %t948, ptr %l519
  br label %bb254
bb253:
  store i1 false, ptr %l516, !tbaa !21
  br label %bb255
bb254:
  %t949 = load i1, ptr %l519, !tbaa !21
  %t950 = xor i1 %t949, true
  store i1 %t950, ptr %l516, !tbaa !21
  br label %bb255
bb255:
  %t952 = load i1, ptr %l516, !tbaa !21
  store i1 %t952, ptr %l59, !tbaa !21
  %t953 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 0
  %t954 = load i64, ptr %t953, !tbaa !24
  %t955 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  %t958 = icmp eq i64 %t954, %t955
  br i1 %t958, label %bb256, label %bb257
bb256:
  %t960 = load i1, ptr %l59, !tbaa !21
  %t962 = xor i1 %t960, true
  store i1 %t962, ptr %l524, !tbaa !21
  br label %bb258
bb257:
  store i1 false, ptr %l524, !tbaa !21
  br label %bb258
bb258:
  %t964 = load i1, ptr %l524, !tbaa !21
  br i1 %t964, label %bb259, label %bb260
bb259:
  store i64 0, ptr %l60, !tbaa !24
  %t965 = load i64, ptr %l1, !tbaa !24
  store i64 %t965, ptr %l61, !tbaa !24
  store i64 1, ptr %l62, !tbaa !24
  %t967 = load i64, ptr %l61, !tbaa !24
  %t968 = load i64, ptr %l60, !tbaa !24
  %t971 = icmp sgt i64 %t967, %t968
  br i1 %t971, label %bb261, label %bb262
bb260:
  br label %bb274
bb261:
  %t973 = load i64, ptr %l62, !tbaa !24
  %t975 = icmp sgt i64 %t973, 0
  br i1 %t975, label %bb263, label %bb264
bb262:
  store i64 0, ptr %l531, !tbaa !24
  br label %bb266
bb263:
  %t977 = load i64, ptr %l61, !tbaa !24
  %t978 = load i64, ptr %l60, !tbaa !24
  %t981 = sub i64 %t977, %t978
  %t982 = load i64, ptr %l62, !tbaa !24
  %t985 = add i64 %t981, %t982
  %t987 = sub i64 %t985, 1
  %t988 = load i64, ptr %l62, !tbaa !24
  %t991 = sdiv i64 %t987, %t988
  store i64 %t991, ptr %l534, !tbaa !24
  br label %bb265
bb264:
  store i64 0, ptr %l534, !tbaa !24
  br label %bb265
bb265:
  %t993 = load i64, ptr %l534, !tbaa !24
  store i64 %t993, ptr %l531, !tbaa !24
  br label %bb266
bb266:
  %t994 = load i64, ptr %l531, !tbaa !24
  store i64 %t994, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb267
bb267:
  %t995 = load i64, ptr %l64, !tbaa !24
  %t996 = load i64, ptr %l63, !tbaa !24
  %t999 = icmp slt i64 %t995, %t996
  %t1001 = xor i1 %t999, true
  br i1 %t1001, label %bb268, label %bb269
bb268:
  br label %bb273
bb269:
  br label %bb270
bb270:
  %t1003 = load i64, ptr %l60, !tbaa !24
  %t1004 = load i64, ptr %l64, !tbaa !24
  %t1005 = load i64, ptr %l62, !tbaa !24
  %t1008 = mul i64 %t1004, %t1005
  %t1011 = add i64 %t1003, %t1008
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1015 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  %t1016 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 2
  %t1017 = load i64, ptr %t1016, !tbaa !24
  %t1018 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 4
  %t1019 = load %"compiler/source:Span", ptr %t1018
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1013, i64 %t1011, i64 %t1015, i64 %t1017, %"compiler/source:Span" %t1019, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb271
bb271:
  br label %bb272
bb272:
  %t1025 = load i64, ptr %l64, !tbaa !24
  %t1028 = add i64 %t1025, 1
  store i64 %t1028, ptr %l64, !tbaa !24
  br label %bb267
bb273:
  br label %bb274
bb274:
  %t1030 = load ptr, ptr %l0, !tbaa !29
  %t1031 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 0
  %t1032 = load i64, ptr %t1031, !tbaa !24
  %t1033 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  %t1034 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 2
  %t1035 = load i64, ptr %t1034, !tbaa !24
  %t1036 = getelementptr %"compiler/free:letGo", ptr %l58, i32 0, i32 4
  %t1037 = load %"compiler/source:Span", ptr %t1036
  %t1038 = load ptr, ptr %lp30
  %t1039 = load { i64, ptr }, ptr %t1038, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1030, i64 %t1032, i64 %t1033, i64 %t1035, %"compiler/source:Span" %t1037, { i64, ptr } %t1039)
  br label %bb275
bb275:
  br label %bb276
bb276:
  %t1046 = load i64, ptr %l56, !tbaa !24
  %t1049 = add i64 %t1046, 1
  store i64 %t1049, ptr %l56, !tbaa !24
  br label %bb237
bb277:
  %t1051 = load ptr, ptr %l0, !tbaa !29
  %t1053 = getelementptr %"compiler/free:Free", ptr %t1051, i32 0, i32 108
  store ptr %t1053, ptr %l66, !tbaa !29
  store i64 0, ptr %l67, !tbaa !24
  br label %bb278
bb278:
  %t1055 = load i64, ptr %l67, !tbaa !24
  store i64 %t1055, ptr %l571, !tbaa !24
  %t1056 = load ptr, ptr %l66, !tbaa !29
  %t1058 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t1056)
  store i64 %t1058, ptr %l573
  br label %bb279
bb279:
  %t1059 = load i64, ptr %l571, !tbaa !24
  %t1060 = load i64, ptr %l573, !tbaa !24
  %t1061 = icmp slt i64 %t1059, %t1060
  %t1063 = xor i1 %t1061, true
  br i1 %t1063, label %bb280, label %bb281
bb280:
  br label %bb290
bb281:
  br label %bb282
bb282:
  %t1065 = load ptr, ptr %l66, !tbaa !29
  %t1066 = load i64, ptr %l67, !tbaa !24
  %t1069 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t1065, i64 %t1066)
  store %"compiler/free:orStore" %t1069, ptr %l578
  br label %bb283
bb283:
  %t1070 = load %"compiler/free:orStore", ptr %l578
  store %"compiler/free:orStore" %t1070, ptr %l68
  %t1071 = getelementptr %"compiler/free:orStore", ptr %l68, i32 0, i32 0
  %t1072 = load i64, ptr %t1071, !tbaa !24
  %t1074 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1075 = load ptr, ptr %t1074, !tbaa !27
  %t1076 = getelementptr i1, ptr %t1075, i64 %t1072
  %t1077 = load i1, ptr %t1076, !tbaa !31
  br i1 %t1077, label %bb284, label %bb285
bb284:
  store %olang.scope zeroinitializer, ptr %s54
  %t1079 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1079, ptr %l581, !tbaa !29
  %t1080 = getelementptr %"compiler/free:orStore", ptr %l68, i32 0, i32 1
  %t1081 = load i64, ptr %t1080, !tbaa !24
  store i64 %t1081, ptr %l582, !tbaa !24
  %t1082 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t1082, ptr %l583, !tbaa !24
  %t1083 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s54, i32 0, i32 0)
  store %"compiler/source:Span" %t1083, ptr %l584
  br label %bb286
bb285:
  br label %bb288
bb286:
  %t1084 = load ptr, ptr %lp30
  %t1085 = load { i64, ptr }, ptr %t1084, !tbaa !27
  %t1086 = load ptr, ptr %l581, !tbaa !29
  %t1087 = load i64, ptr %l582, !tbaa !24
  %t1088 = load i64, ptr %l583, !tbaa !24
  %t1089 = load %"compiler/source:Span", ptr %l584
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1086, i64 %t1087, i64 %t1088, i64 -1, %"compiler/source:Span" %t1089, { i64, ptr } %t1085)
  br label %bb287
bb287:
  call void @__olang_scope_close(ptr %s54)
  br label %bb288
bb288:
  br label %bb289
bb289:
  %t1091 = load i64, ptr %l67, !tbaa !24
  %t1094 = add i64 %t1091, 1
  store i64 %t1094, ptr %l67, !tbaa !24
  br label %bb278
bb290:
  %t1096 = load ptr, ptr %l0, !tbaa !29
  %t1098 = getelementptr %"compiler/free:Free", ptr %t1096, i32 0, i32 107
  store ptr %t1098, ptr %l69, !tbaa !29
  store i64 0, ptr %l70, !tbaa !24
  br label %bb291
bb291:
  %t1100 = load i64, ptr %l70, !tbaa !24
  store i64 %t1100, ptr %l591, !tbaa !24
  %t1101 = load ptr, ptr %l69, !tbaa !29
  %t1103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t1101)
  store i64 %t1103, ptr %l593
  br label %bb292
bb292:
  %t1104 = load i64, ptr %l591, !tbaa !24
  %t1105 = load i64, ptr %l593, !tbaa !24
  %t1106 = icmp slt i64 %t1104, %t1105
  %t1108 = xor i1 %t1106, true
  br i1 %t1108, label %bb293, label %bb294
bb293:
  br label %bb303
bb294:
  br label %bb295
bb295:
  %t1110 = load ptr, ptr %l69, !tbaa !29
  %t1111 = load i64, ptr %l70, !tbaa !24
  %t1114 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t1110, i64 %t1111)
  store %"compiler/free:orCall" %t1114, ptr %l598
  br label %bb296
bb296:
  %t1115 = load %"compiler/free:orCall", ptr %l598
  store %"compiler/free:orCall" %t1115, ptr %l71
  %t1116 = getelementptr %"compiler/free:orCall", ptr %l71, i32 0, i32 0
  %t1117 = load i64, ptr %t1116, !tbaa !24
  %t1119 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1120 = load ptr, ptr %t1119, !tbaa !27
  %t1121 = getelementptr i1, ptr %t1120, i64 %t1117
  %t1122 = load i1, ptr %t1121, !tbaa !31
  br i1 %t1122, label %bb297, label %bb298
bb297:
  store %olang.scope zeroinitializer, ptr %s58
  %t1124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1124, ptr %l601, !tbaa !29
  %t1125 = getelementptr %"compiler/free:orCall", ptr %l71, i32 0, i32 4
  %t1126 = load i64, ptr %t1125, !tbaa !24
  store i64 %t1126, ptr %l602, !tbaa !24
  %t1127 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t1127, ptr %l603, !tbaa !24
  %t1128 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s58, i32 0, i32 0)
  store %"compiler/source:Span" %t1128, ptr %l604
  br label %bb299
bb298:
  br label %bb301
bb299:
  %t1129 = load ptr, ptr %lp30
  %t1130 = load { i64, ptr }, ptr %t1129, !tbaa !27
  %t1131 = load ptr, ptr %l601, !tbaa !29
  %t1132 = load i64, ptr %l602, !tbaa !24
  %t1133 = load i64, ptr %l603, !tbaa !24
  %t1134 = load %"compiler/source:Span", ptr %l604
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1131, i64 %t1132, i64 %t1133, i64 -1, %"compiler/source:Span" %t1134, { i64, ptr } %t1130)
  br label %bb300
bb300:
  call void @__olang_scope_close(ptr %s58)
  br label %bb301
bb301:
  br label %bb302
bb302:
  %t1136 = load i64, ptr %l70, !tbaa !24
  %t1139 = add i64 %t1136, 1
  store i64 %t1139, ptr %l70, !tbaa !24
  br label %bb291
bb303:
  %t1141 = load ptr, ptr %l0, !tbaa !29
  %t1143 = getelementptr %"compiler/free:Free", ptr %t1141, i32 0, i32 174
  store ptr %t1143, ptr %l72, !tbaa !29
  store i64 0, ptr %l73, !tbaa !24
  br label %bb304
bb304:
  %t1145 = load i64, ptr %l73, !tbaa !24
  store i64 %t1145, ptr %l611, !tbaa !24
  %t1146 = load ptr, ptr %l72, !tbaa !29
  %t1148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t1146)
  store i64 %t1148, ptr %l613
  br label %bb305
bb305:
  %t1149 = load i64, ptr %l611, !tbaa !24
  %t1150 = load i64, ptr %l613, !tbaa !24
  %t1151 = icmp slt i64 %t1149, %t1150
  %t1153 = xor i1 %t1151, true
  br i1 %t1153, label %bb306, label %bb307
bb306:
  br label %bb316
bb307:
  br label %bb308
bb308:
  %t1155 = load ptr, ptr %l72, !tbaa !29
  %t1156 = load i64, ptr %l73, !tbaa !24
  %t1159 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t1155, i64 %t1156)
  store %"compiler/free:feed" %t1159, ptr %l618
  br label %bb309
bb309:
  %t1160 = load %"compiler/free:feed", ptr %l618
  store %"compiler/free:feed" %t1160, ptr %l74
  %t1161 = getelementptr %"compiler/free:feed", ptr %l74, i32 0, i32 0
  %t1162 = load i64, ptr %t1161, !tbaa !24
  %t1164 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1165 = load ptr, ptr %t1164, !tbaa !27
  %t1166 = getelementptr i1, ptr %t1165, i64 %t1162
  %t1167 = load i1, ptr %t1166, !tbaa !31
  br i1 %t1167, label %bb310, label %bb311
bb310:
  store %olang.scope zeroinitializer, ptr %s62
  %t1169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1169, ptr %l621, !tbaa !29
  %t1170 = getelementptr %"compiler/free:feed", ptr %l74, i32 0, i32 2
  %t1171 = load i64, ptr %t1170, !tbaa !24
  store i64 %t1171, ptr %l622, !tbaa !24
  %t1172 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t1172, ptr %l623, !tbaa !24
  %t1173 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s62, i32 0, i32 0)
  store %"compiler/source:Span" %t1173, ptr %l624
  br label %bb312
bb311:
  br label %bb314
bb312:
  %t1174 = load ptr, ptr %lp30
  %t1175 = load { i64, ptr }, ptr %t1174, !tbaa !27
  %t1176 = load ptr, ptr %l621, !tbaa !29
  %t1177 = load i64, ptr %l622, !tbaa !24
  %t1178 = load i64, ptr %l623, !tbaa !24
  %t1179 = load %"compiler/source:Span", ptr %l624
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1176, i64 %t1177, i64 %t1178, i64 -1, %"compiler/source:Span" %t1179, { i64, ptr } %t1175)
  br label %bb313
bb313:
  call void @__olang_scope_close(ptr %s62)
  br label %bb314
bb314:
  br label %bb315
bb315:
  %t1181 = load i64, ptr %l73, !tbaa !24
  %t1184 = add i64 %t1181, 1
  store i64 %t1184, ptr %l73, !tbaa !24
  br label %bb304
bb316:
  %t1186 = load ptr, ptr %l0, !tbaa !29
  %t1188 = getelementptr %"compiler/free:Free", ptr %t1186, i32 0, i32 137
  store ptr %t1188, ptr %l75, !tbaa !29
  store i64 0, ptr %l76, !tbaa !24
  br label %bb317
bb317:
  %t1190 = load i64, ptr %l76, !tbaa !24
  store i64 %t1190, ptr %l631, !tbaa !24
  %t1191 = load ptr, ptr %l75, !tbaa !29
  %t1193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t1191)
  store i64 %t1193, ptr %l633
  br label %bb318
bb318:
  %t1194 = load i64, ptr %l631, !tbaa !24
  %t1195 = load i64, ptr %l633, !tbaa !24
  %t1196 = icmp slt i64 %t1194, %t1195
  %t1198 = xor i1 %t1196, true
  br i1 %t1198, label %bb319, label %bb320
bb319:
  br label %bb325
bb320:
  br label %bb321
bb321:
  %t1200 = load ptr, ptr %l75, !tbaa !29
  %t1201 = load i64, ptr %l76, !tbaa !24
  %t1204 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t1200, i64 %t1201)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1204, ptr %l638
  br label %bb322
bb322:
  %t1205 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l638
  %t1206 = load ptr, ptr %l0, !tbaa !29
  %t1208 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ejoinReached(ptr %v0, ptr %t1206, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1205, i64 %t1208)
  br label %bb323
bb323:
  br label %bb324
bb324:
  %t1212 = load i64, ptr %l76, !tbaa !24
  %t1215 = add i64 %t1212, 1
  store i64 %t1215, ptr %l76, !tbaa !24
  br label %bb317
bb325:
  %t1217 = load ptr, ptr %l0, !tbaa !29
  %t1219 = getelementptr %"compiler/free:Free", ptr %t1217, i32 0, i32 139
  store ptr %t1219, ptr %l78, !tbaa !29
  store i64 0, ptr %l79, !tbaa !24
  br label %bb326
bb326:
  %t1221 = load i64, ptr %l79, !tbaa !24
  store i64 %t1221, ptr %l647, !tbaa !24
  %t1222 = load ptr, ptr %l78, !tbaa !29
  %t1224 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t1222)
  store i64 %t1224, ptr %l649
  br label %bb327
bb327:
  %t1225 = load i64, ptr %l647, !tbaa !24
  %t1226 = load i64, ptr %l649, !tbaa !24
  %t1227 = icmp slt i64 %t1225, %t1226
  %t1229 = xor i1 %t1227, true
  br i1 %t1229, label %bb328, label %bb329
bb328:
  br label %bb334
bb329:
  br label %bb330
bb330:
  %t1231 = load ptr, ptr %l78, !tbaa !29
  %t1232 = load i64, ptr %l79, !tbaa !24
  %t1235 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t1231, i64 %t1232)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1235, ptr %l654
  br label %bb331
bb331:
  %t1236 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l654
  %t1237 = load ptr, ptr %l0, !tbaa !29
  %t1239 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ejoinReached(ptr %v0, ptr %t1237, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1236, i64 %t1239)
  br label %bb332
bb332:
  br label %bb333
bb333:
  %t1243 = load i64, ptr %l79, !tbaa !24
  %t1246 = add i64 %t1243, 1
  store i64 %t1246, ptr %l79, !tbaa !24
  br label %bb326
bb334:
  %t1248 = load ptr, ptr %l0, !tbaa !29
  %t1250 = getelementptr %"compiler/free:Free", ptr %t1248, i32 0, i32 137
  store ptr %t1250, ptr %l81, !tbaa !29
  store i64 0, ptr %l82, !tbaa !24
  br label %bb335
bb335:
  %t1252 = load i64, ptr %l82, !tbaa !24
  store i64 %t1252, ptr %l663, !tbaa !24
  %t1253 = load ptr, ptr %l81, !tbaa !29
  %t1255 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t1253)
  store i64 %t1255, ptr %l665
  br label %bb336
bb336:
  %t1256 = load i64, ptr %l663, !tbaa !24
  %t1257 = load i64, ptr %l665, !tbaa !24
  %t1258 = icmp slt i64 %t1256, %t1257
  %t1260 = xor i1 %t1258, true
  br i1 %t1260, label %bb337, label %bb338
bb337:
  br label %bb361
bb338:
  br label %bb339
bb339:
  %t1262 = load ptr, ptr %l81, !tbaa !29
  %t1263 = load i64, ptr %l82, !tbaa !24
  %t1266 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t1262, i64 %t1263)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1266, ptr %l670
  br label %bb340
bb340:
  %t1267 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l670
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1267, ptr %l83
  %t1268 = load ptr, ptr %l0, !tbaa !29
  %t1270 = getelementptr %"compiler/free:Free", ptr %t1268, i32 0, i32 146
  store ptr %t1270, ptr %l84, !tbaa !29
  store i64 0, ptr %l85, !tbaa !24
  br label %bb341
bb341:
  store %olang.scope zeroinitializer, ptr %s73
  %t1272 = load i64, ptr %l85, !tbaa !24
  store i64 %t1272, ptr %l673, !tbaa !24
  %t1273 = load ptr, ptr %l84, !tbaa !29
  %t1275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t1273)
  store i64 %t1275, ptr %l675
  br label %bb342
bb342:
  %t1276 = load i64, ptr %l673, !tbaa !24
  %t1277 = load i64, ptr %l675, !tbaa !24
  %t1278 = icmp slt i64 %t1276, %t1277
  %t1280 = xor i1 %t1278, true
  br i1 %t1280, label %bb343, label %bb344
bb343:
  call void @__olang_scope_close(ptr %s73)
  br label %bb359
bb344:
  br label %bb345
bb345:
  %t1282 = load ptr, ptr %l84, !tbaa !29
  %t1283 = load i64, ptr %l85, !tbaa !24
  %t1286 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t1282, i64 %t1283)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1286, ptr %l680
  br label %bb346
bb346:
  %t1287 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l680
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1287, ptr %l86
  %t1288 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l86, i32 0, i32 0
  %t1289 = load i64, ptr %t1288, !tbaa !24
  %t1290 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l83, i32 0, i32 0
  %t1291 = load i64, ptr %t1290, !tbaa !24
  %t1294 = icmp ne i64 %t1289, %t1291
  br i1 %t1294, label %bb347, label %bb348
bb347:
  store i1 true, ptr %l684, !tbaa !21
  br label %bb352
bb348:
  %t1296 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l83, i32 0, i32 1
  %t1297 = load i64, ptr %t1296, !tbaa !24
  %t1298 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  %t1301 = icmp ne i64 %t1297, %t1298
  br i1 %t1301, label %bb349, label %bb350
bb349:
  %t1303 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l83, i32 0, i32 1
  %t1304 = load i64, ptr %t1303, !tbaa !24
  %t1305 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l86, i32 0, i32 1
  %t1306 = load i64, ptr %t1305, !tbaa !24
  %t1309 = icmp ne i64 %t1304, %t1306
  store i1 %t1309, ptr %l688, !tbaa !21
  br label %bb351
bb350:
  store i1 false, ptr %l688, !tbaa !21
  br label %bb351
bb351:
  %t1311 = load i1, ptr %l688, !tbaa !21
  store i1 %t1311, ptr %l684, !tbaa !21
  br label %bb352
bb352:
  %t1312 = load i1, ptr %l684, !tbaa !21
  br i1 %t1312, label %bb353, label %bb354
bb353:
  call void @__olang_scope_close(ptr %s73)
  br label %bb358
bb354:
  br label %bb355
bb355:
  %t1313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1313, ptr %l692, !tbaa !29
  %t1314 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l86, i32 0, i32 1
  %t1315 = load i64, ptr %t1314, !tbaa !24
  store i64 %t1315, ptr %l693, !tbaa !24
  %t1316 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t1316, ptr %l694, !tbaa !24
  %t1317 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s73, i32 0, i32 0)
  store %"compiler/source:Span" %t1317, ptr %l695
  br label %bb356
bb356:
  %t1318 = load ptr, ptr %l692, !tbaa !29
  %t1319 = load i64, ptr %l693, !tbaa !24
  %t1320 = load i64, ptr %l694, !tbaa !24
  %t1321 = load %"compiler/source:Span", ptr %l695
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1318, i64 %t1319, i64 %t1320, i64 -1, %"compiler/source:Span" %t1321, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb357
bb357:
  call void @__olang_scope_close(ptr %s73)
  br label %bb358
bb358:
  %t1322 = load i64, ptr %l85, !tbaa !24
  %t1325 = add i64 %t1322, 1
  store i64 %t1325, ptr %l85, !tbaa !24
  br label %bb341
bb359:
  br label %bb360
bb360:
  %t1327 = load i64, ptr %l82, !tbaa !24
  %t1330 = add i64 %t1327, 1
  store i64 %t1330, ptr %l82, !tbaa !24
  br label %bb335
bb361:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Text", ptr %a1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb15
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 2}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { ptr }, ptr %t37, i32 0, i32 0
  %t39 = load ptr, ptr %t38
  %t45 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %t39)
  store i1 %t45, ptr %l28
  br label %bb9
bb8:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t46 = load i1, ptr %l28, !tbaa !21
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { ptr }, ptr %t50, i32 0, i32 0
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l7, !tbaa !29
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb1
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etryMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7b3dede47d025484_fbd5a3b64af54730)
  unreachable
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t22, ptr %t21)
  store i1 %t24, ptr %l21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Try", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb29
bb13:
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l5, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Clause", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Clause", ptr %t63, i32 0, i32 4
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t80, ptr %l47, !tbaa !27
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr ptr, ptr %t84, i64 %t81
  %t86 = load ptr, ptr %t85, !tbaa !39
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t88, ptr %t86)
  store i1 %t92, ptr %l52
  br label %bb22
bb22:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb18
bb27:
  br label %bb28
bb28:
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l3, !tbaa !24
  br label %bb11
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewriteFeedCalls(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/free:feedCall"
  %l4 = alloca %"compiler/free:feed"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/free:feedCall"
  %l40 = alloca %"compiler/free:feed"
  %l43 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l66 = alloca i64
  %l75 = alloca { i64, [2 x i64] }
  %l76 = alloca { i64, [2 x i64] }
  %l78 = alloca { i64, [2 x i64] }
  %l80 = alloca i1
  %l85 = alloca ptr
  %l94 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l126 = alloca i64
  %l143 = alloca i64
  %l146 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i1
  %l173 = alloca i1
  %l175 = alloca i64
  %l179 = alloca i1
  %l184 = alloca { i64, ptr }
  %l189 = alloca i64
  %l192 = alloca i1
  %l194 = alloca { i64, ptr }
  %l198 = alloca i1
  %l200 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l207 = alloca { i64, [2 x i64] }
  %l209 = alloca { i64, [2 x i64] }
  %l211 = alloca i1
  %l213 = alloca { i64, ptr }
  %t156 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 176
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l29, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l31
  br label %bb2
bb2:
  %t9 = load i64, ptr %l29, !tbaa !24
  %t10 = load i64, ptr %l31, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb97
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:feedCall" %t19, ptr %l36
  br label %bb6
bb6:
  %t20 = load %"compiler/free:feedCall", ptr %l36
  store %"compiler/free:feedCall" %t20, ptr %l3
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 174
  %t24 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 4
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t23, i64 %t25)
  store %"compiler/free:feed" %t28, ptr %l40
  br label %bb7
bb7:
  %t29 = load %"compiler/free:feed", ptr %l40
  store %"compiler/free:feed" %t29, ptr %l4
  %t30 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb15
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 29
  %t38 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t37, i64 %t39)
  store i1 %t42, ptr %l47
  br label %bb10
bb10:
  %t43 = load i1, ptr %l47, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 109
  %t47 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t46, i64 %t48)
  store i1 %t51, ptr %l52
  br label %bb13
bb12:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb14
bb13:
  %t52 = load i1, ptr %l52, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l48, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l48, !tbaa !21
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l43, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb96
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 3
  %t60 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t61)
  store ptr %t64, ptr %l57
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l57, !tbaa !29
  store ptr %t65, ptr %l5, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Plan", ptr %t66, i32 0, i32 6
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l59, !tbaa !27
  %t70 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t78 = icmp ne i64 %t76, 1
  br i1 %t78, label %bb20, label %bb21
bb20:
  br label %bb96
bb21:
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i64 %t88, ptr %l66
  br label %bb23
bb23:
  %t89 = load i64, ptr %l66, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb24, label %bb25
bb24:
  br label %bb96
bb25:
  br label %bb26
bb26:
  %t94 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store i32 %t97, ptr %l7, !tbaa !23
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t101 = load i32, ptr %l7, !tbaa !23
  %t102 = load i64, ptr %l6, !tbaa !24
  %t106 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t100, i32 %t101, i64 %t102)
  store { i64, [2 x i64] } %t106, ptr %l75
  br label %bb27
bb27:
  %t107 = load { i64, [2 x i64] }, ptr %l75
  store { i64, [2 x i64] } %t107, ptr %l8
  %t108 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t108, ptr %l76
  %t109 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 4
  %t110 = load { i64, [2 x i64] }, ptr %t109
  store { i64, [2 x i64] } %t110, ptr %l78
  %t113 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l76, ptr %l78)
  store i1 %t113, ptr %l80
  br label %bb28
bb28:
  %t114 = load i1, ptr %l80, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb96
bb30:
  br label %bb31
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t125 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v0, ptr %t117, i64 %t119, i64 %t121)
  store ptr %t125, ptr %l85
  br label %bb32
bb32:
  %t126 = load ptr, ptr %l85, !tbaa !29
  store ptr %t126, ptr %l9, !tbaa !29
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb33, label %bb34
bb33:
  br label %bb96
bb34:
  br label %bb35
bb35:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load ptr, ptr %l9, !tbaa !29
  %t135 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = load { i64, [2 x i64] }, ptr %l8
  %t138 = load i64, ptr %l6, !tbaa !24
  %t145 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t131, i64 %t133, ptr %t134, i64 %t136, { i64, [2 x i64] } %t137, i64 %t138)
  store i64 %t145, ptr %l94
  br label %bb36
bb36:
  %t146 = load i64, ptr %l94, !tbaa !24
  store i64 %t146, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp slt i64 %t147, 0
  br i1 %t149, label %bb37, label %bb38
bb37:
  br label %bb96
bb38:
  br label %bb39
bb39:
  %t151 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t152 = load i64, ptr %t151, !tbaa !24
  %t154 = trunc i64 %t152 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 4, ptr %t157
  %t159 = insertvalue { i32 } undef, i32 %t154, 0
  %t160 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 1
  store { i32 } %t159, ptr %t160
  %t161 = load { i64, [2 x i64] }, ptr %t156
  store { i64, [2 x i64] } %t161, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  store i64 63, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t163 = load i64, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = icmp sgt i64 %t163, %t164
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb45
bb42:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t183 = sub i64 %t181, 1
  %t184 = load i64, ptr %l14, !tbaa !24
  %t187 = sdiv i64 %t183, %t184
  store i64 %t187, ptr %l107, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb44
bb44:
  %t189 = load i64, ptr %l107, !tbaa !24
  store i64 %t189, ptr %l104, !tbaa !24
  br label %bb45
bb45:
  %t190 = load i64, ptr %l104, !tbaa !24
  store i64 %t190, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb46
bb46:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb47, label %bb48
bb47:
  br label %bb55
bb48:
  br label %bb49
bb49:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l17, !tbaa !24
  %t209 = load i64, ptr %l10, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  store i64 %t210, ptr %l126, !tbaa !24
  %t211 = load i64, ptr %l126, !tbaa !24
  %t212 = load i64, ptr %l126, !tbaa !24
  %t213 = shl i64 1, %t212
  %t216 = and i64 %t209, %t213
  %t218 = icmp ne i64 %t216, 0
  br i1 %t218, label %bb50, label %bb51
bb50:
  %t220 = load ptr, ptr %l5, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  %t222 = load i64, ptr %l17, !tbaa !24
  %t223 = load { i64, [2 x i64] }, ptr %l11
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t220, i32 %t221, i64 %t222, { i64, [2 x i64] } %t223)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t228 = load i64, ptr %l16, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l16, !tbaa !24
  br label %bb46
bb55:
  store i64 0, ptr %l18, !tbaa !24
  %t233 = load ptr, ptr %l9, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Call", ptr %t233, i32 0, i32 1
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  store i64 %t238, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp sgt i64 %t240, %t241
  br i1 %t244, label %bb56, label %bb57
bb56:
  %t246 = load i64, ptr %l20, !tbaa !24
  %t248 = icmp sgt i64 %t246, 0
  br i1 %t248, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb61
bb58:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = sub i64 %t250, %t251
  %t255 = load i64, ptr %l20, !tbaa !24
  %t258 = add i64 %t254, %t255
  %t260 = sub i64 %t258, 1
  %t261 = load i64, ptr %l20, !tbaa !24
  %t264 = sdiv i64 %t260, %t261
  store i64 %t264, ptr %l146, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb60
bb60:
  %t266 = load i64, ptr %l146, !tbaa !24
  store i64 %t266, ptr %l143, !tbaa !24
  br label %bb61
bb61:
  %t267 = load i64, ptr %l143, !tbaa !24
  store i64 %t267, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb62
bb62:
  %t268 = load i64, ptr %l22, !tbaa !24
  %t269 = load i64, ptr %l21, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb63, label %bb64
bb63:
  br label %bb95
bb64:
  br label %bb65
bb65:
  %t276 = load i64, ptr %l18, !tbaa !24
  %t277 = load i64, ptr %l22, !tbaa !24
  %t278 = load i64, ptr %l20, !tbaa !24
  %t281 = mul i64 %t277, %t278
  %t284 = add i64 %t276, %t281
  store i64 %t284, ptr %l23, !tbaa !24
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 2
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load i64, ptr %l23, !tbaa !24
  %t293 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t286, i64 %t288, i64 %t289)
  store i64 %t293, ptr %l167
  br label %bb66
bb66:
  %t294 = load i64, ptr %l167, !tbaa !24
  store i64 %t294, ptr %l24, !tbaa !24
  %t295 = load i64, ptr %l24, !tbaa !24
  %t297 = icmp slt i64 %t295, 0
  br i1 %t297, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb69
bb68:
  %t299 = load i64, ptr %l24, !tbaa !24
  %t301 = icmp sge i64 %t299, 63
  store i1 %t301, ptr %l170, !tbaa !21
  br label %bb69
bb69:
  %t303 = load i1, ptr %l170, !tbaa !21
  br i1 %t303, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb72
bb71:
  %t304 = load i64, ptr %l10, !tbaa !24
  %t305 = load i64, ptr %l24, !tbaa !24
  store i64 %t305, ptr %l175, !tbaa !24
  %t306 = load i64, ptr %l175, !tbaa !24
  %t307 = load i64, ptr %l175, !tbaa !24
  %t308 = shl i64 1, %t307
  %t311 = and i64 %t304, %t308
  %t313 = icmp eq i64 %t311, 0
  store i1 %t313, ptr %l173, !tbaa !21
  br label %bb72
bb72:
  %t315 = load i1, ptr %l173, !tbaa !21
  br i1 %t315, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb75
bb74:
  %t316 = load i64, ptr %l24, !tbaa !24
  %t317 = load i64, ptr %l6, !tbaa !24
  %t320 = icmp eq i64 %t316, %t317
  store i1 %t320, ptr %l179, !tbaa !21
  br label %bb75
bb75:
  %t322 = load i1, ptr %l179, !tbaa !21
  br i1 %t322, label %bb76, label %bb77
bb76:
  br label %bb94
bb77:
  br label %bb78
bb78:
  %t323 = load ptr, ptr %l9, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Call", ptr %t323, i32 0, i32 1
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l184, !tbaa !27
  %t327 = load i64, ptr %l23, !tbaa !24
  %t329 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr ptr, ptr %t330, i64 %t327
  %t332 = load ptr, ptr %t331, !tbaa !39
  store ptr %t332, ptr %l25, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l25, !tbaa !29
  %t338 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t334, ptr %t335)
  store i64 %t338, ptr %l189
  br label %bb79
bb79:
  %t339 = load i64, ptr %l189, !tbaa !24
  store i64 %t339, ptr %l26, !tbaa !24
  %t340 = load i64, ptr %l26, !tbaa !24
  %t342 = icmp sge i64 %t340, 0
  br i1 %t342, label %bb80, label %bb81
bb80:
  %t344 = load ptr, ptr %l5, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Plan", ptr %t344, i32 0, i32 6
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  store { i64, ptr } %t347, ptr %l194, !tbaa !27
  %t348 = load i64, ptr %l26, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i64, ptr %t351, i64 %t348
  %t353 = load i64, ptr %t352, !tbaa !34
  %t355 = icmp eq i64 %t353, 1
  br i1 %t355, label %bb82, label %bb83
bb81:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb85
bb82:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb84
bb83:
  %t357 = load ptr, ptr %l5, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Plan", ptr %t357, i32 0, i32 6
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l200, !tbaa !27
  %t361 = load i64, ptr %l26, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr i64, ptr %t364, i64 %t361
  %t366 = load i64, ptr %t365, !tbaa !34
  %t368 = icmp eq i64 %t366, 3
  store i1 %t368, ptr %l198, !tbaa !21
  br label %bb84
bb84:
  %t370 = load i1, ptr %l198, !tbaa !21
  store i1 %t370, ptr %l192, !tbaa !21
  br label %bb85
bb85:
  %t371 = load i1, ptr %l192, !tbaa !21
  br i1 %t371, label %bb86, label %bb87
bb86:
  %t372 = load ptr, ptr %l5, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Plan", ptr %t372, i32 0, i32 7
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  store { i64, ptr } %t375, ptr %l205, !tbaa !27
  %t376 = load i64, ptr %l26, !tbaa !24
  %t378 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = getelementptr { i64, [2 x i64] }, ptr %t379, i64 %t376
  %t381 = load { i64, [2 x i64] }, ptr %t380
  store { i64, [2 x i64] } %t381, ptr %l207
  %t382 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t382, ptr %l209
  %t385 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l207, ptr %l209)
  store i1 %t385, ptr %l211
  br label %bb88
bb87:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t388 = load i64, ptr %t387, !tbaa !24
  %t389 = load ptr, ptr %l25, !tbaa !29
  %t390 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t391 = load i64, ptr %t390, !tbaa !24
  %t392 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t386, i64 %t388, ptr %t389, i64 %t391, { i64, [2 x i64] } %t392, i1 false, i1 false)
  br label %bb92
bb88:
  %t398 = load i1, ptr %l211, !tbaa !21
  br i1 %t398, label %bb89, label %bb90
bb89:
  %t399 = load ptr, ptr %l5, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Plan", ptr %t399, i32 0, i32 7
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !27
  store { i64, ptr } %t402, ptr %l213, !tbaa !27
  %t403 = load i64, ptr %l26, !tbaa !24
  %t404 = load { i64, [2 x i64] }, ptr %l11
  %t407 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr { i64, [2 x i64] }, ptr %t408, i64 %t403
  store { i64, [2 x i64] } %t404, ptr %t409
  br label %bb91
bb90:
  br label %bb91
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t410 = load i64, ptr %l22, !tbaa !24
  %t413 = add i64 %t410, 1
  store i64 %t413, ptr %l22, !tbaa !24
  br label %bb62
bb95:
  br label %bb96
bb96:
  %t415 = load i64, ptr %l2, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l2, !tbaa !24
  br label %bb1
bb97:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca ptr
  %l81 = alloca ptr
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l11, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2earm_2elocal_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l11
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2earm_2elocal_2e2
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l11
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Arm", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb8:
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l6, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Alt", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t47, ptr %t51)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Alt", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t72 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l10, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l41, !tbaa !29
  %t81 = load ptr, ptr %l10, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Bind", ptr %t81, i32 0, i32 0
  %t84 = load i32, ptr %t83, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l44, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l10, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Bind", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s4, ptr %t87, ptr %t91)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l48
  br label %bb15
bb15:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t96 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %t96
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s4, ptr %t97, i64 %t98, ptr %t96)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l8, !tbaa !24
  br label %bb11
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l4, !tbaa !24
  br label %bb6
bb20:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Arm", ptr %t110, i32 0, i32 2
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l60, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Arm", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb23, label %bb24
bb22:
  br label %bb27
bb23:
  call void @__olang_check_failed(ptr @olang_loc_304dd9f782c5c299_7aedab6f7faf5da5)
  unreachable
bb24:
  br label %bb25
bb25:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Arm", ptr %t127, i32 0, i32 2
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l60, !tbaa !29
  %t133 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t131, ptr %t130)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l66
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb27
bb27:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Arm", ptr %t134, i32 0, i32 3
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb28, label %bb29
bb28:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l71, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Arm", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb30, label %bb31
bb29:
  br label %bb34
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ceff65db82d42b72_bd0ee798a65f80fe)
  unreachable
bb31:
  br label %bb32
bb32:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Arm", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load ptr, ptr %l71, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t155, ptr %t154)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Arm", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb35, label %bb36
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l81, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Arm", ptr %t167, i32 0, i32 4
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = icmp eq ptr %t170, null
  br i1 %t172, label %bb37, label %bb38
bb36:
  br label %bb45
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1c2ece56a8f93bb3_9a04e0623a4a84af)
  unreachable
bb38:
  br label %bb39
bb39:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Arm", ptr %t174, i32 0, i32 4
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = load ptr, ptr %l81, !tbaa !29
  %t180 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t178, ptr %t177)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l87
  br label %bb40
bb40:
  %t181 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l88
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l2
  %t183 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2earm_2elocal_2e2
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = call ptr @__olang_region_home(ptr %t188)
  %t190 = icmp ne ptr %t189, null
  %t191 = select i1 %t190, ptr %t189, ptr null
  call void @__olang_region_drop(ptr %t191)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l88
  br label %bb42
bb42:
  %t192 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t192, label %bb43, label %bb44
bb43:
  %t194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = extractvalue { i64, ptr } %t195, 1
  call void @__olang_region_release_part(ptr %t197, i64 %t196)
  store { i64, ptr } zeroinitializer, ptr %t194
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t198 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca i64
  %l59 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 36
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  store i1 %t11, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 27
  store ptr %t16, ptr %l17, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i64 @compiler_2ffree_2elvRootLocal(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l19
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t21 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t20, i64 %t21)
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 28
  store ptr %t24, ptr %l21, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l23
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t28, %"compiler/source:Span" %t29)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:walker", ptr %t30, i32 0, i32 51
  %t33 = load i64, ptr %t32, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l26, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 8}
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load %"compiler/source:Span", ptr %t48
  store %"compiler/source:Span" %t49, ptr %l5
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l7, !tbaa !23
  store i64 -1, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l38, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/free:walker", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t71 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i64 %t71, ptr %l42
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i64, ptr %l42, !tbaa !24
  %t76 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownerSplitOf(ptr %v0, ptr %v2, ptr %t73, i64 %t74, ptr %t72)
  store i64 %t76, ptr %l44
  br label %bb16
bb16:
  %t77 = load i64, ptr %l44, !tbaa !24
  store i64 %t77, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l31, !tbaa !24
  %t79 = load ptr, ptr %l26, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 51
  store i64 %t78, ptr %t80, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 39
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/free:walker", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eWidenedMake(ptr %v0, ptr %v2, ptr %v2, ptr %t89, ptr %t90)
  store ptr %t93, ptr %l50
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l50, !tbaa !29
  store ptr %t94, ptr %l9, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l51, !tbaa !29
  %t96 = load ptr, ptr %l9, !tbaa !29
  %t98 = icmp eq ptr %t96, null
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb19, label %bb20
bb19:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/free:walker", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load ptr, ptr %l9, !tbaa !29
  %t109 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v2, ptr %t105, ptr %t106)
  store i64 %t109, ptr %l59
  br label %bb21
bb20:
  store i64 -1, ptr %l55, !tbaa !24
  br label %bb22
bb21:
  %t110 = load i64, ptr %l59, !tbaa !24
  store i64 %t110, ptr %l55, !tbaa !24
  br label %bb22
bb22:
  %t111 = load i64, ptr %l55, !tbaa !24
  %t112 = load ptr, ptr %l51, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t112, i32 0, i32 39
  store i64 %t111, ptr %t113, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassignTo(ptr %v0, ptr %v1, ptr %v2, ptr %t114, %"compiler/source:Span" %a1, ptr %t116, ptr %t117)
  br label %bb23
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = getelementptr %"compiler/free:walker", ptr %t122, i32 0, i32 39
  store i64 %t123, ptr %t126, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/free:walker", ptr %t127, i32 0, i32 52
  %t130 = load i32, ptr %t129, !tbaa !23
  %t131 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t134 = icmp ne i32 %t130, %t131
  br i1 %t134, label %bb24, label %bb25
bb24:
  %t136 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownerSettle(ptr %v0, ptr %t136, i64 -1)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l4, !tbaa !24
  %t142 = getelementptr %"compiler/free:walker", ptr %t138, i32 0, i32 51
  store i64 %t139, ptr %t142, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecallTaskLets(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i64
  %l50 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i64
  %l58 = alloca i64
  %l63 = alloca ptr
  %l65 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 76
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  store ptr %t12, ptr %l14
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l14, !tbaa !29
  store ptr %t13, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l15, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = call ptr @__olang_scope_hold(ptr %v0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l17, !tbaa !24
  %t18 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr %v0)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l17, !tbaa !24
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t25 = load i64, ptr %l17
  %t26 = inttoptr i64 %t25 to ptr
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t26, ptr %t24)
  store i64 %t28, ptr %l20
  br label %bb5
bb5:
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  br label %bb18
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = call ptr @__olang_scope_hold(ptr %v0)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr %v0)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l24
  %t47 = inttoptr i64 %t46 to ptr
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t47, ptr %t44, i64 %t45)
  store i64 %t50, ptr %l28
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/free:Free", ptr %t52, i32 0, i32 76
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:walker", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t54, i64 %t58)
  store ptr %t61, ptr %l33
  br label %bb12
bb12:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t63, i64 %t62)
  store i64 %t65, ptr %l35
  br label %bb13
bb13:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = icmp sgt i64 %t66, 0
  br i1 %t67, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 95
  store i1 true, ptr %t71, !tbaa !21
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l4, !tbaa !24
  br label %bb2
bb18:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 77
  %t80 = load i64, ptr %l1, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l44
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l44, !tbaa !29
  store ptr %t84, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  %t85 = load i64, ptr %l7, !tbaa !24
  store i64 %t85, ptr %l45, !tbaa !24
  %t86 = load ptr, ptr %l6, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  %t87 = call ptr @__olang_scope_hold(ptr %v0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l47, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l46, !tbaa !29
  %t92 = call ptr @__olang_region_or(ptr %t91, ptr %v0)
  %t93 = call ptr @__olang_scope_hold(ptr %t92)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l47, !tbaa !24
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t96 = load i64, ptr %l47
  %t97 = inttoptr i64 %t96 to ptr
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t97, ptr %t95)
  store i64 %t99, ptr %l50
  br label %bb23
bb23:
  %t100 = load i64, ptr %l45, !tbaa !24
  %t101 = load i64, ptr %l50, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb24, label %bb25
bb24:
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l6, !tbaa !29
  store ptr %t106, ptr %l53, !tbaa !29
  %t107 = call ptr @__olang_scope_hold(ptr %v0)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l54, !tbaa !24
  %t109 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t109, label %bb27, label %bb28
bb27:
  %t111 = load ptr, ptr %l53, !tbaa !29
  %t112 = call ptr @__olang_region_or(ptr %t111, ptr %v0)
  %t113 = call ptr @__olang_scope_hold(ptr %t112)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l54, !tbaa !24
  br label %bb28
bb28:
  %t115 = load ptr, ptr %l6, !tbaa !29
  %t116 = load i64, ptr %l7, !tbaa !24
  %t117 = load i64, ptr %l54
  %t118 = inttoptr i64 %t117 to ptr
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t118, ptr %t115, i64 %t116)
  store i64 %t121, ptr %l58
  br label %bb29
bb29:
  %t122 = load i64, ptr %l58, !tbaa !24
  store i64 %t122, ptr %l8, !tbaa !24
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/free:Free", ptr %t123, i32 0, i32 77
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 1
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t125, i64 %t129)
  store ptr %t132, ptr %l63
  br label %bb30
bb30:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t134 = load ptr, ptr %l63, !tbaa !29
  %t136 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t134, i64 %t133)
  store i64 %t136, ptr %l65
  br label %bb31
bb31:
  %t137 = load i64, ptr %l65, !tbaa !24
  %t138 = icmp sgt i64 %t137, 0
  br i1 %t138, label %bb32, label %bb33
bb32:
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t142 = getelementptr %"compiler/free:Free", ptr %t140, i32 0, i32 95
  store i1 true, ptr %t142, !tbaa !21
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t143 = load i64, ptr %l7, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l7, !tbaa !24
  br label %bb20
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopiedView(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l17 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca i1
  %l33 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca i64
  %l42 = alloca i1
  %l48 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca i1
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 7
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t15)
  store %"compiler/typed:Local" %t18, ptr %l15
  br label %bb3
bb3:
  %t19 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 2
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t21, i32 %t20)
  store i1 %t23, ptr %l17
  br label %bb4
bb4:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %a2)
  store ptr %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  store ptr %t30, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t36)
  store i64 %t38, ptr %l26
  br label %bb12
bb12:
  %t39 = load i64, ptr %l26, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 1
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t47)
  store ptr %t50, ptr %l33
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l33, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 11
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb20
bb18:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l40
  br label %bb19
bb19:
  %t64 = load i64, ptr %l40, !tbaa !24
  %t65 = icmp eq i64 %t64, 0
  store i1 %t65, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l37, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:walker", ptr %t71, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  %t79 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efreshCtor(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i64 %t70, i64 %t74)
  store i1 %t79, ptr %l48
  br label %bb23
bb23:
  %t80 = load i1, ptr %l48, !tbaa !21
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:walker", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t90 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedLocals(ptr %v0, ptr %s0, ptr %t83, i64 %t87)
  store { i64, ptr } %t90, ptr %l53
  br label %bb28
bb28:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t91
  %t96 = load i1, ptr %t95, !tbaa !31
  br i1 %t96, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb32
bb30:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/free:walker", ptr %t99, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t103 = load i64, ptr %l1, !tbaa !24
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t105 = load i64, ptr %l5, !tbaa !24
  %t111 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunheldViews(ptr %v0, ptr %v1, ptr %t98, i64 %t102, i64 %t103, ptr %t104, i64 %t105)
  store i1 %t111, ptr %l63
  br label %bb31
bb31:
  %t112 = load i1, ptr %l63, !tbaa !21
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load i1, ptr %l56, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/free:leaf"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca %"compiler/free:leaf"
  %l39 = alloca ptr
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l62 = alloca i1
  %l65 = alloca i64
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i1
  %l79 = alloca i1
  %l84 = alloca i64
  %l86 = alloca i64
  %l91 = alloca %"compiler/free:leaf"
  %l92 = alloca %"compiler/free:leaf"
  %l93 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l103 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i64
  %l109 = alloca i64
  %l111 = alloca ptr
  %l119 = alloca %"compiler/free:store"
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l139 = alloca i64
  %l141 = alloca i64
  %l144 = alloca i1
  %l148 = alloca ptr
  %l153 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca ptr
  %l161 = alloca i64
  %l164 = alloca i1
  %l165 = alloca ptr
  %l169 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l175 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca ptr
  %l182 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l187 = alloca i32
  %l190 = alloca i32
  %l191 = alloca i1
  %l194 = alloca i64
  %l196 = alloca i1
  %l199 = alloca ptr
  %l202 = alloca i64
  %l203 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca ptr
  %l212 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l213 = alloca ptr
  %l217 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l229 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l235 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l242 = alloca ptr
  %l243 = alloca i64
  %l244 = alloca ptr
  %l245 = alloca i64
  %l248 = alloca i64
  %l251 = alloca ptr
  %l252 = alloca i64
  %l256 = alloca i64
  %l264 = alloca ptr
  %l271 = alloca i1
  %l275 = alloca ptr
  %l280 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i1
  %l286 = alloca ptr
  %l290 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca i1
  %l297 = alloca ptr
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l303 = alloca ptr
  %l306 = alloca { i64, ptr }
  %l308 = alloca i32
  %l311 = alloca i32
  %l312 = alloca i1
  %l313 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l314 = alloca ptr
  %l318 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l330 = alloca { i64, ptr }
  %l333 = alloca ptr
  %l336 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l343 = alloca ptr
  %l344 = alloca i64
  %l345 = alloca ptr
  %l346 = alloca i64
  %l349 = alloca i64
  %l352 = alloca ptr
  %l353 = alloca i64
  %l357 = alloca i64
  %l365 = alloca ptr
  %l370 = alloca ptr
  %l371 = alloca i1
  %l374 = alloca ptr
  %l375 = alloca i1
  %l379 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l380 = alloca i64
  %l382 = alloca { i64, ptr }
  %l383 = alloca i64
  %l384 = alloca { i64, ptr }
  %l390 = alloca i1
  %l395 = alloca i64
  %l397 = alloca i64
  %l402 = alloca %"compiler/free:leaf"
  %l403 = alloca %"compiler/free:leaf"
  %l404 = alloca i64
  %l406 = alloca { i64, ptr }
  %l407 = alloca i64
  %l408 = alloca { i64, ptr }
  %l414 = alloca i1
  %l416 = alloca ptr
  %l417 = alloca i64
  %l419 = alloca i64
  %l421 = alloca ptr
  %l428 = alloca %"compiler/free:store"
  %l429 = alloca ptr
  %l430 = alloca i64
  %l431 = alloca i64
  %l433 = alloca ptr
  %l435 = alloca i64
  %l436 = alloca %"compiler/source:Span"
  %l437 = alloca i64
  %l439 = alloca ptr
  %l441 = alloca %"compiler/source:Span"
  %l442 = alloca { i64, ptr }
  %l449 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l450 = alloca i64
  %l452 = alloca { i64, ptr }
  %l453 = alloca i64
  %l454 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l39
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l39, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v4, ptr %t16, ptr %t17, ptr %t18, %"compiler/source:Span" %t19)
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l48
  %t27 = call ptr @__olang_scope_hold(ptr %v5)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l49, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = call ptr @__olang_region_make_part(ptr %v5)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l49, !tbaa !24
  br label %bb6
bb6:
  %t33 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l51, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l52, !tbaa !24
  %t37 = load i64, ptr %l52, !tbaa !24
  %t38 = mul i64 %t37, 8
  %t39 = load i64, ptr %l49
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = call ptr @__olang_held_alloc(ptr %t40, i64 %t38)
  %t42 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l53, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l52, !tbaa !24
  %t49 = mul i64 %t48, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  store { i64, ptr } %t50, ptr %t51, !tbaa !27
  %t52 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t52, label %bb7, label %bb8
bb7:
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %rv
  br label %ret
bb9:
  %t61 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t61, !tbaa !27
  br label %bb10
bb10:
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48, i32 0, i32 0
  %t63 = load i64, ptr %l49
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = load { i64, ptr }, ptr %t62
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = call ptr @__olang_region_or(ptr %t66, ptr null)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr null
  call void @__olang_region_settle_in(ptr %t64, ptr %t69)
  br label %bb8
bb11:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call ptr @compiler_2ffree_2etakenOf(ptr %v2, ptr %v2, ptr %t70)
  store ptr %t72, ptr %l58
  br label %bb12
bb12:
  %t73 = load ptr, ptr %l58, !tbaa !29
  store ptr %t73, ptr %l9, !tbaa !29
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v2, ptr %t80, ptr %t81)
  store i64 %t84, ptr %l65
  br label %bb15
bb14:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb16
bb15:
  %t85 = load i64, ptr %l65, !tbaa !24
  %t86 = icmp slt i64 %t85, 0
  store i1 %t86, ptr %l62, !tbaa !21
  br label %bb16
bb16:
  %t88 = load i1, ptr %l62, !tbaa !21
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t89 = load ptr, ptr %l8, !tbaa !29
  store ptr %t89, ptr %l68, !tbaa !29
  %t90 = load ptr, ptr %l8, !tbaa !29
  store ptr %t90, ptr %l69, !tbaa !29
  %t91 = load ptr, ptr %l9, !tbaa !29
  %t93 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v2, ptr %t91)
  store i32 %t93, ptr %l71
  br label %bb19
bb18:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb23
bb19:
  %t94 = load ptr, ptr %l69, !tbaa !29
  %t95 = load i32, ptr %l71, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t96, ptr %l72
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l75
  br label %bb21
bb21:
  %t102 = load ptr, ptr %l68, !tbaa !29
  %t103 = load i32, ptr %l72, !tbaa !23
  %t104 = load i32, ptr %l75, !tbaa !23
  %t105 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t102, i32 %t103, i32 %t104)
  store i1 %t105, ptr %l76
  br label %bb22
bb22:
  %t106 = load i1, ptr %l76, !tbaa !21
  store i1 %t106, ptr %l67, !tbaa !21
  br label %bb23
bb23:
  %t107 = load i1, ptr %l67, !tbaa !21
  br i1 %t107, label %bb24, label %bb25
bb24:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 2
  %t111 = load i1, ptr %t110, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb25:
  br label %bb59
bb26:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 36
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp eq i64 %t116, 0
  store i1 %t118, ptr %l79, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb28
bb28:
  %t120 = load i1, ptr %l79, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb31
bb30:
  br label %bb52
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t123 = load i64, ptr %l11, !tbaa !24
  store i64 %t123, ptr %l84, !tbaa !24
  %t124 = load ptr, ptr %l10, !tbaa !29
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t124)
  store i64 %t126, ptr %l86
  br label %bb32
bb32:
  %t127 = load i64, ptr %l84, !tbaa !24
  %t128 = load i64, ptr %l86, !tbaa !24
  %t129 = icmp slt i64 %t127, %t128
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb34:
  br label %bb35
bb35:
  %t133 = load ptr, ptr %l10, !tbaa !29
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t133, i64 %t134)
  store %"compiler/free:leaf" %t137, ptr %l91
  br label %bb36
bb36:
  %t138 = load %"compiler/free:leaf", ptr %l91
  store %"compiler/free:leaf" %t138, ptr %l92
  %t139 = call ptr @__olang_scope_hold(ptr %s5)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l93, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t141, label %bb37, label %bb38
bb37:
  %t143 = call ptr @__olang_region_make_part(ptr %s5)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l93, !tbaa !24
  br label %bb38
bb38:
  %t145 = getelementptr %"compiler/free:leaf", ptr %l92, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l95, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l96, !tbaa !24
  %t149 = load i64, ptr %l96, !tbaa !24
  %t150 = mul i64 %t149, 8
  %t151 = load i64, ptr %l93
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_held_alloc(ptr %t152, i64 %t150)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l97, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l96, !tbaa !24
  %t161 = mul i64 %t160, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t157, ptr %t159, i64 %t161, i1 false)
  %t162 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t163 = getelementptr %"compiler/free:leaf", ptr %l92, i32 0, i32 0
  store { i64, ptr } %t162, ptr %t163, !tbaa !27
  %t164 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t164, label %bb39, label %bb40
bb39:
  %t166 = getelementptr %"compiler/free:leaf", ptr %l92, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = icmp eq i64 %t168, 0
  br i1 %t170, label %bb41, label %bb42
bb40:
  %t172 = load %"compiler/free:leaf", ptr %l92
  store %"compiler/free:leaf" %t172, ptr %l12
  %t173 = load ptr, ptr %l7, !tbaa !29
  %t174 = getelementptr %"compiler/free:leaf", ptr %l12, i32 0, i32 1
  %t175 = load i64, ptr %t174, !tbaa !24
  %t178 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t173, i64 %t175)
  store i1 %t178, ptr %l103
  br label %bb43
bb41:
  %t179 = getelementptr %"compiler/free:leaf", ptr %l92, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t179, !tbaa !27
  br label %bb42
bb42:
  %t180 = getelementptr %"compiler/free:leaf", ptr %l92, i32 0, i32 0
  %t181 = load i64, ptr %l93
  %t182 = inttoptr i64 %t181 to ptr
  %t183 = load { i64, ptr }, ptr %t180
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = call ptr @__olang_region_or(ptr %t184, ptr null)
  %t186 = icmp ne ptr %t185, null
  %t187 = select i1 %t186, ptr %t185, ptr null
  call void @__olang_region_settle_in(ptr %t182, ptr %t187)
  br label %bb40
bb43:
  %t188 = load i1, ptr %l103, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb44, label %bb45
bb44:
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t193 = getelementptr %"compiler/free:Free", ptr %t191, i32 0, i32 101
  store ptr %t193, ptr %l106, !tbaa !29
  %t194 = getelementptr %"compiler/free:leaf", ptr %l12, i32 0, i32 1
  %t195 = load i64, ptr %t194, !tbaa !24
  store i64 %t195, ptr %l107, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/free:walker", ptr %t196, i32 0, i32 1
  %t199 = load i64, ptr %t198, !tbaa !24
  store i64 %t199, ptr %l109, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t200)
  store ptr %t202, ptr %l111
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t203 = load ptr, ptr %l111, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Body", ptr %t203, i32 0, i32 3
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load %"compiler/source:Span", ptr %l5
  %t208 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t209 = getelementptr %"compiler/free:leaf", ptr %l12, i32 0, i32 1
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t213 = load i64, ptr %l107, !tbaa !24
  %t214 = load i64, ptr %l109, !tbaa !24
  %t220 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t213, i64 %t214, i64 %t206, %"compiler/source:Span" %t207, i64 %t208, i64 %t210, i64 -1, ptr %t211, ptr null)
  store %"compiler/free:store" %t220, ptr %l119
  br label %bb47
bb47:
  %t221 = load ptr, ptr %l106, !tbaa !29
  %t222 = load %"compiler/free:store", ptr %l119
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t221, %"compiler/free:store" %t222)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  %t223 = load i64, ptr %l11, !tbaa !24
  %t226 = add i64 %t223, 1
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb31
bb51:
  br label %bb52
bb52:
  %t228 = load ptr, ptr %l4, !tbaa !29
  %t230 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t228
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l124
  %t231 = call ptr @__olang_scope_hold(ptr %v5)
  %t232 = ptrtoint ptr %t231 to i64
  store i64 %t232, ptr %l125, !tbaa !24
  %t233 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t233, label %bb53, label %bb54
bb53:
  %t235 = call ptr @__olang_region_make_part(ptr %v5)
  %t236 = ptrtoint ptr %t235 to i64
  store i64 %t236, ptr %l125, !tbaa !24
  br label %bb54
bb54:
  %t237 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l127, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l128, !tbaa !24
  %t241 = load i64, ptr %l128, !tbaa !24
  %t242 = mul i64 %t241, 8
  %t243 = load i64, ptr %l125
  %t244 = inttoptr i64 %t243 to ptr
  %t245 = call ptr @__olang_held_alloc(ptr %t244, i64 %t242)
  %t246 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l129, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l128, !tbaa !24
  %t253 = mul i64 %t252, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t255 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  store { i64, ptr } %t254, ptr %t255, !tbaa !27
  %t256 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t256, label %bb55, label %bb56
bb55:
  %t258 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  %t262 = icmp eq i64 %t260, 0
  br i1 %t262, label %bb57, label %bb58
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t264 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %rv
  br label %ret
bb57:
  %t265 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t265, !tbaa !27
  br label %bb58
bb58:
  %t266 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  %t267 = load i64, ptr %l125
  %t268 = inttoptr i64 %t267 to ptr
  %t269 = load { i64, ptr }, ptr %t266
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = call ptr @__olang_region_or(ptr %t270, ptr null)
  %t272 = icmp ne ptr %t271, null
  %t273 = select i1 %t272, ptr %t271, ptr null
  call void @__olang_region_settle_in(ptr %t268, ptr %t273)
  br label %bb56
bb59:
  %t274 = load ptr, ptr %l3, !tbaa !29
  %t277 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t274)
  store ptr %t277, ptr %l135
  br label %bb60
bb60:
  %t278 = load ptr, ptr %l135, !tbaa !29
  store ptr %t278, ptr %l13, !tbaa !29
  %t279 = load ptr, ptr %l13, !tbaa !29
  %t281 = icmp eq ptr %t279, null
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb61, label %bb62
bb61:
  %t285 = load ptr, ptr %l13, !tbaa !29
  %t287 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t285)
  store i64 %t287, ptr %l141
  br label %bb63
bb62:
  store i64 -1, ptr %l139, !tbaa !24
  br label %bb64
bb63:
  %t288 = load i64, ptr %l141, !tbaa !24
  store i64 %t288, ptr %l139, !tbaa !24
  br label %bb64
bb64:
  %t289 = load i64, ptr %l139, !tbaa !24
  store i64 %t289, ptr %l14, !tbaa !24
  %t290 = load i64, ptr %l14, !tbaa !24
  %t292 = icmp sge i64 %t290, 0
  br i1 %t292, label %bb65, label %bb66
bb65:
  %t294 = load ptr, ptr %l7, !tbaa !29
  %t296 = getelementptr %"compiler/free:Free", ptr %t294, i32 0, i32 1
  %t297 = load i64, ptr %l14, !tbaa !24
  %t300 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t296, i64 %t297)
  store ptr %t300, ptr %l148
  br label %bb67
bb66:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb68
bb67:
  %t301 = load ptr, ptr %l148, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Body", ptr %t301, i32 0, i32 11
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = icmp eq ptr %t304, null
  %t308 = xor i1 %t306, true
  store i1 %t308, ptr %l144, !tbaa !21
  br label %bb68
bb68:
  %t310 = load i1, ptr %l144, !tbaa !21
  br i1 %t310, label %bb69, label %bb70
bb69:
  %t311 = load ptr, ptr %l8, !tbaa !29
  store ptr %t311, ptr %l154, !tbaa !29
  %t312 = load ptr, ptr %l7, !tbaa !29
  %t314 = getelementptr %"compiler/free:Free", ptr %t312, i32 0, i32 1
  %t315 = load i64, ptr %l14, !tbaa !24
  %t318 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t314, i64 %t315)
  store ptr %t318, ptr %l158
  br label %bb71
bb70:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb73
bb71:
  %t319 = load ptr, ptr %l158, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Body", ptr %t319, i32 0, i32 2
  %t322 = load i32, ptr %t321, !tbaa !23
  %t323 = load ptr, ptr %l154, !tbaa !29
  %t325 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t323, i32 %t322)
  store i64 %t325, ptr %l161
  br label %bb72
bb72:
  %t326 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t327 = load i64, ptr %l161, !tbaa !24
  %t329 = icmp eq i64 %t327, %t326
  store i1 %t329, ptr %l153, !tbaa !21
  br label %bb73
bb73:
  %t331 = load i1, ptr %l153, !tbaa !21
  br i1 %t331, label %bb74, label %bb75
bb74:
  %t332 = load ptr, ptr %l8, !tbaa !29
  store ptr %t332, ptr %l165, !tbaa !29
  %t333 = load ptr, ptr %l7, !tbaa !29
  %t335 = getelementptr %"compiler/free:Free", ptr %t333, i32 0, i32 1
  %t336 = load i64, ptr %l14, !tbaa !24
  %t339 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t335, i64 %t336)
  store ptr %t339, ptr %l169
  br label %bb76
bb75:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb78
bb76:
  %t340 = load ptr, ptr %l169, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Body", ptr %t340, i32 0, i32 2
  %t343 = load i32, ptr %t342, !tbaa !23
  %t344 = load ptr, ptr %l165, !tbaa !29
  %t346 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t344, i32 %t343)
  store { i64, ptr } %t346, ptr %l172
  br label %bb77
bb77:
  %t347 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 0
  %t350 = icmp eq i64 %t348, 1
  store i1 %t350, ptr %l164, !tbaa !21
  br label %bb78
bb78:
  %t352 = load i1, ptr %l164, !tbaa !21
  br i1 %t352, label %bb79, label %bb80
bb79:
  %t353 = load ptr, ptr %l8, !tbaa !29
  store ptr %t353, ptr %l176, !tbaa !29
  %t354 = load ptr, ptr %l8, !tbaa !29
  store ptr %t354, ptr %l177, !tbaa !29
  %t355 = load ptr, ptr %l8, !tbaa !29
  store ptr %t355, ptr %l178, !tbaa !29
  %t356 = load ptr, ptr %l7, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 1
  %t359 = load i64, ptr %l14, !tbaa !24
  %t362 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t358, i64 %t359)
  store ptr %t362, ptr %l182
  br label %bb81
bb80:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb86
bb81:
  %t363 = load ptr, ptr %l182, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Body", ptr %t363, i32 0, i32 2
  %t366 = load i32, ptr %t365, !tbaa !23
  %t367 = load ptr, ptr %l178, !tbaa !29
  %t369 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t367, i32 %t366)
  store { i64, ptr } %t369, ptr %l185
  br label %bb82
bb82:
  %t370 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i32, ptr %t371, i64 0
  %t373 = load i32, ptr %t372, !tbaa !33
  %t374 = load ptr, ptr %l177, !tbaa !29
  %t376 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t374, i32 %t373)
  store i32 %t376, ptr %l187
  br label %bb83
bb83:
  %t377 = load ptr, ptr %l8, !tbaa !29
  %t378 = load i32, ptr %l2, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l190
  br label %bb84
bb84:
  %t382 = load ptr, ptr %l176, !tbaa !29
  %t383 = load i32, ptr %l187, !tbaa !23
  %t384 = load i32, ptr %l190, !tbaa !23
  %t385 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t382, i32 %t383, i32 %t384)
  store i1 %t385, ptr %l191
  br label %bb85
bb85:
  %t386 = load i1, ptr %l191, !tbaa !21
  store i1 %t386, ptr %l175, !tbaa !21
  br label %bb86
bb86:
  %t387 = load i1, ptr %l175, !tbaa !21
  br i1 %t387, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s8
  %t388 = load ptr, ptr %l7, !tbaa !29
  %t389 = load i64, ptr %l14, !tbaa !24
  %t392 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t388, i64 %t389)
  store i64 %t392, ptr %l194
  br label %bb89
bb88:
  br label %bb132
bb89:
  %t393 = load i64, ptr %l194, !tbaa !24
  %t394 = icmp ne i64 %t393, 0
  br i1 %t394, label %bb90, label %bb91
bb90:
  %t396 = load ptr, ptr %l13, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb97
bb92:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb93:
  br label %bb94
bb94:
  %t400 = load ptr, ptr %l13, !tbaa !29
  store ptr %t400, ptr %l199, !tbaa !29
  %t401 = load ptr, ptr %l7, !tbaa !29
  %t402 = load i64, ptr %l14, !tbaa !24
  %t405 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t401, i64 %t402)
  store i64 %t405, ptr %l202
  br label %bb95
bb95:
  %t406 = load ptr, ptr %l199, !tbaa !29
  %t407 = load i64, ptr %l202, !tbaa !24
  %t408 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v2, ptr %t406, i64 %t407)
  store i1 %t408, ptr %l203
  br label %bb96
bb96:
  %t409 = load i1, ptr %l203, !tbaa !21
  %t410 = xor i1 %t409, true
  store i1 %t410, ptr %l196, !tbaa !21
  br label %bb97
bb97:
  %t412 = load i1, ptr %l196, !tbaa !21
  br i1 %t412, label %bb98, label %bb99
bb98:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l205, !tbaa !29
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l206, !tbaa !29
  %t415 = load ptr, ptr %l13, !tbaa !29
  %t417 = icmp eq ptr %t415, null
  br i1 %t417, label %bb100, label %bb101
bb99:
  br label %bb104
bb100:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb101:
  br label %bb102
bb102:
  %t419 = load ptr, ptr %l13, !tbaa !29
  %t420 = load ptr, ptr %l3, !tbaa !29
  %t421 = load %"compiler/source:Span", ptr %l5
  %t422 = load ptr, ptr %l205, !tbaa !29
  %t423 = load ptr, ptr %l206, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t422, ptr %t423, ptr %t419, ptr %t420, %"compiler/source:Span" %t421)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t427 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t427, ptr %l212
  br label %bb105
bb105:
  %t428 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t428, ptr %l15
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l213, !tbaa !29
  %t430 = load ptr, ptr %l213, !tbaa !29
  %t431 = getelementptr %"compiler/free:walker", ptr %t430, i32 0, i32 36
  %t432 = load i64, ptr %t431, !tbaa !24
  %t435 = add i64 %t432, 1
  %t437 = load ptr, ptr %l213, !tbaa !29
  %t438 = getelementptr %"compiler/free:walker", ptr %t437, i32 0, i32 36
  store i64 %t435, ptr %t438, !tbaa !24
  %t439 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t439, ptr %l217
  br label %bb106
bb106:
  %t440 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l217
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t440, ptr %l16
  %t441 = load ptr, ptr %l13, !tbaa !29
  %t443 = icmp eq ptr %t441, null
  br i1 %t443, label %bb107, label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237)
  unreachable
bb108:
  br label %bb109
bb109:
  %t445 = load ptr, ptr %l13, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Call", ptr %t445, i32 0, i32 1
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !27
  store { i64, ptr } %t449, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t451 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t451, 0
  store i64 %t453, ptr %l19, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s11
  %t455 = load i64, ptr %l18, !tbaa !24
  %t456 = load i64, ptr %l19, !tbaa !24
  %t459 = icmp slt i64 %t455, %t456
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb112:
  br label %bb113
bb113:
  %t463 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t463, ptr %l229, !tbaa !27
  %t464 = load i64, ptr %l18, !tbaa !24
  %t466 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr ptr, ptr %t467, i64 %t464
  %t469 = load ptr, ptr %t468, !tbaa !39
  store ptr %l16, ptr %l232, !tbaa !29
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t475 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s11, ptr %t471, ptr %t469)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t475, ptr %l235
  br label %bb114
bb114:
  %t476 = load ptr, ptr %l232, !tbaa !29
  %t477 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l235
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s8, ptr %s11, ptr %t476, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t477)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s11)
  br label %bb116
bb116:
  %t478 = load i64, ptr %l18, !tbaa !24
  %t481 = add i64 %t478, 1
  store i64 %t481, ptr %l18, !tbaa !24
  br label %bb110
bb117:
  %t483 = load ptr, ptr %l7, !tbaa !29
  %t485 = getelementptr %"compiler/free:Free", ptr %t483, i32 0, i32 69
  %t486 = load i64, ptr %l14, !tbaa !24
  %t489 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t485, i64 %t486)
  store ptr %t489, ptr %l242
  br label %bb118
bb118:
  %t490 = load ptr, ptr %l242, !tbaa !29
  store ptr %t490, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb119
bb119:
  %t491 = load i64, ptr %l22, !tbaa !24
  store i64 %t491, ptr %l243, !tbaa !24
  %t492 = load ptr, ptr %l21, !tbaa !29
  store ptr %t492, ptr %l244, !tbaa !29
  %t493 = call ptr @__olang_scope_hold(ptr %v0)
  %t494 = ptrtoint ptr %t493 to i64
  store i64 %t494, ptr %l245, !tbaa !24
  %t495 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t495, label %bb120, label %bb121
bb120:
  %t497 = load ptr, ptr %l244, !tbaa !29
  %t498 = call ptr @__olang_region_or(ptr %t497, ptr %v0)
  %t499 = call ptr @__olang_scope_hold(ptr %t498)
  %t500 = ptrtoint ptr %t499 to i64
  store i64 %t500, ptr %l245, !tbaa !24
  br label %bb121
bb121:
  %t501 = load ptr, ptr %l21, !tbaa !29
  %t502 = load i64, ptr %l245
  %t503 = inttoptr i64 %t502 to ptr
  %t505 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t503, ptr %t501)
  store i64 %t505, ptr %l248
  br label %bb122
bb122:
  %t506 = load i64, ptr %l243, !tbaa !24
  %t507 = load i64, ptr %l248, !tbaa !24
  %t508 = icmp slt i64 %t506, %t507
  %t510 = xor i1 %t508, true
  br i1 %t510, label %bb123, label %bb124
bb123:
  br label %bb131
bb124:
  br label %bb125
bb125:
  %t512 = load ptr, ptr %l21, !tbaa !29
  store ptr %t512, ptr %l251, !tbaa !29
  %t513 = call ptr @__olang_scope_hold(ptr %v0)
  %t514 = ptrtoint ptr %t513 to i64
  store i64 %t514, ptr %l252, !tbaa !24
  %t515 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t515, label %bb126, label %bb127
bb126:
  %t517 = load ptr, ptr %l251, !tbaa !29
  %t518 = call ptr @__olang_region_or(ptr %t517, ptr %v0)
  %t519 = call ptr @__olang_scope_hold(ptr %t518)
  %t520 = ptrtoint ptr %t519 to i64
  store i64 %t520, ptr %l252, !tbaa !24
  br label %bb127
bb127:
  %t521 = load ptr, ptr %l21, !tbaa !29
  %t522 = load i64, ptr %l22, !tbaa !24
  %t523 = load i64, ptr %l252
  %t524 = inttoptr i64 %t523 to ptr
  %t527 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t524, ptr %t521, i64 %t522)
  store i64 %t527, ptr %l256
  br label %bb128
bb128:
  %t528 = load i64, ptr %l256, !tbaa !24
  %t529 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %s8, ptr %v5, ptr %t529, i64 %t528, ptr %l16, ptr %l15)
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t535 = load i64, ptr %l22, !tbaa !24
  %t538 = add i64 %t535, 1
  store i64 %t538, ptr %l22, !tbaa !24
  br label %bb119
bb131:
  %t540 = load ptr, ptr %l0, !tbaa !29
  store ptr %t540, ptr %l264, !tbaa !29
  %t541 = load ptr, ptr %l264, !tbaa !29
  %t542 = getelementptr %"compiler/free:walker", ptr %t541, i32 0, i32 36
  %t543 = load i64, ptr %t542, !tbaa !24
  %t546 = sub i64 %t543, 1
  %t548 = load ptr, ptr %l264, !tbaa !29
  %t549 = getelementptr %"compiler/free:walker", ptr %t548, i32 0, i32 36
  store i64 %t546, ptr %t549, !tbaa !24
  %t550 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t550, ptr %rv
  br label %ret
bb132:
  %t552 = load i64, ptr %l14, !tbaa !24
  %t554 = icmp sge i64 %t552, 0
  br i1 %t554, label %bb133, label %bb134
bb133:
  %t556 = load ptr, ptr %l7, !tbaa !29
  %t558 = getelementptr %"compiler/free:Free", ptr %t556, i32 0, i32 1
  %t559 = load i64, ptr %l14, !tbaa !24
  %t562 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t558, i64 %t559)
  store ptr %t562, ptr %l275
  br label %bb135
bb134:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb136
bb135:
  %t563 = load ptr, ptr %l275, !tbaa !29
  %t565 = getelementptr %"compiler/typed:Body", ptr %t563, i32 0, i32 11
  %t566 = load ptr, ptr %t565, !tbaa !29
  %t568 = icmp eq ptr %t566, null
  %t570 = xor i1 %t568, true
  store i1 %t570, ptr %l271, !tbaa !21
  br label %bb136
bb136:
  %t572 = load i1, ptr %l271, !tbaa !21
  br i1 %t572, label %bb137, label %bb138
bb137:
  %t573 = load ptr, ptr %l7, !tbaa !29
  %t575 = getelementptr %"compiler/free:Free", ptr %t573, i32 0, i32 90
  %t576 = load i64, ptr %l14, !tbaa !24
  %t579 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t575, i64 %t576)
  store i1 %t579, ptr %l284
  br label %bb139
bb138:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb140
bb139:
  %t580 = load i1, ptr %l284, !tbaa !21
  store i1 %t580, ptr %l280, !tbaa !21
  br label %bb140
bb140:
  %t581 = load i1, ptr %l280, !tbaa !21
  br i1 %t581, label %bb141, label %bb142
bb141:
  %t582 = load ptr, ptr %l8, !tbaa !29
  store ptr %t582, ptr %l286, !tbaa !29
  %t583 = load ptr, ptr %l7, !tbaa !29
  %t585 = getelementptr %"compiler/free:Free", ptr %t583, i32 0, i32 1
  %t586 = load i64, ptr %l14, !tbaa !24
  %t589 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t585, i64 %t586)
  store ptr %t589, ptr %l290
  br label %bb143
bb142:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb145
bb143:
  %t590 = load ptr, ptr %l290, !tbaa !29
  %t592 = getelementptr %"compiler/typed:Body", ptr %t590, i32 0, i32 2
  %t593 = load i32, ptr %t592, !tbaa !23
  %t594 = load ptr, ptr %l286, !tbaa !29
  %t596 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t594, i32 %t593)
  store { i64, ptr } %t596, ptr %l293
  br label %bb144
bb144:
  %t597 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t598 = extractvalue { i64, ptr } %t597, 0
  %t600 = icmp eq i64 %t598, 1
  store i1 %t600, ptr %l285, !tbaa !21
  br label %bb145
bb145:
  %t602 = load i1, ptr %l285, !tbaa !21
  br i1 %t602, label %bb146, label %bb147
bb146:
  %t603 = load ptr, ptr %l8, !tbaa !29
  store ptr %t603, ptr %l297, !tbaa !29
  %t604 = load ptr, ptr %l8, !tbaa !29
  store ptr %t604, ptr %l298, !tbaa !29
  %t605 = load ptr, ptr %l8, !tbaa !29
  store ptr %t605, ptr %l299, !tbaa !29
  %t606 = load ptr, ptr %l7, !tbaa !29
  %t608 = getelementptr %"compiler/free:Free", ptr %t606, i32 0, i32 1
  %t609 = load i64, ptr %l14, !tbaa !24
  %t612 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t608, i64 %t609)
  store ptr %t612, ptr %l303
  br label %bb148
bb147:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb153
bb148:
  %t613 = load ptr, ptr %l303, !tbaa !29
  %t615 = getelementptr %"compiler/typed:Body", ptr %t613, i32 0, i32 2
  %t616 = load i32, ptr %t615, !tbaa !23
  %t617 = load ptr, ptr %l299, !tbaa !29
  %t619 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t617, i32 %t616)
  store { i64, ptr } %t619, ptr %l306
  br label %bb149
bb149:
  %t620 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !27
  %t622 = getelementptr i32, ptr %t621, i64 0
  %t623 = load i32, ptr %t622, !tbaa !33
  %t624 = load ptr, ptr %l298, !tbaa !29
  %t626 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t624, i32 %t623)
  store i32 %t626, ptr %l308
  br label %bb150
bb150:
  %t627 = load ptr, ptr %l8, !tbaa !29
  %t628 = load i32, ptr %l2, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t627, i32 %t628)
  store i32 %t631, ptr %l311
  br label %bb151
bb151:
  %t632 = load ptr, ptr %l297, !tbaa !29
  %t633 = load i32, ptr %l308, !tbaa !23
  %t634 = load i32, ptr %l311, !tbaa !23
  %t635 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t632, i32 %t633, i32 %t634)
  store i1 %t635, ptr %l312
  br label %bb152
bb152:
  %t636 = load i1, ptr %l312, !tbaa !21
  store i1 %t636, ptr %l296, !tbaa !21
  br label %bb153
bb153:
  %t637 = load i1, ptr %l296, !tbaa !21
  br i1 %t637, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s16
  %t638 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t638, ptr %l313
  br label %bb156
bb155:
  br label %bb183
bb156:
  %t639 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l313
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t639, ptr %l24
  %t640 = load ptr, ptr %l0, !tbaa !29
  store ptr %t640, ptr %l314, !tbaa !29
  %t641 = load ptr, ptr %l314, !tbaa !29
  %t642 = getelementptr %"compiler/free:walker", ptr %t641, i32 0, i32 36
  %t643 = load i64, ptr %t642, !tbaa !24
  %t646 = add i64 %t643, 1
  %t648 = load ptr, ptr %l314, !tbaa !29
  %t649 = getelementptr %"compiler/free:walker", ptr %t648, i32 0, i32 36
  store i64 %t646, ptr %t649, !tbaa !24
  %t650 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s16, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t650, ptr %l318
  br label %bb157
bb157:
  %t651 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t651, ptr %l25
  %t652 = load ptr, ptr %l13, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  br i1 %t654, label %bb158, label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_bdcaa592caab98ca_bd3b16c434097b46)
  unreachable
bb159:
  br label %bb160
bb160:
  %t656 = load ptr, ptr %l13, !tbaa !29
  %t659 = getelementptr %"compiler/typed:Call", ptr %t656, i32 0, i32 1
  %t660 = load { i64, ptr }, ptr %t659, !tbaa !27
  store { i64, ptr } %t660, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t662 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t664 = extractvalue { i64, ptr } %t662, 0
  store i64 %t664, ptr %l28, !tbaa !24
  br label %bb161
bb161:
  store %olang.scope zeroinitializer, ptr %s18
  %t666 = load i64, ptr %l27, !tbaa !24
  %t667 = load i64, ptr %l28, !tbaa !24
  %t670 = icmp slt i64 %t666, %t667
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb162, label %bb163
bb162:
  call void @__olang_scope_close(ptr %s18)
  br label %bb168
bb163:
  br label %bb164
bb164:
  %t674 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t674, ptr %l330, !tbaa !27
  %t675 = load i64, ptr %l27, !tbaa !24
  %t677 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !27
  %t679 = getelementptr ptr, ptr %t678, i64 %t675
  %t680 = load ptr, ptr %t679, !tbaa !39
  store ptr %l25, ptr %l333, !tbaa !29
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t686 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s18, ptr %t682, ptr %t680)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t686, ptr %l336
  br label %bb165
bb165:
  %t687 = load ptr, ptr %l333, !tbaa !29
  %t688 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l336
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s16, ptr %s18, ptr %t687, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t688)
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s18)
  br label %bb167
bb167:
  %t689 = load i64, ptr %l27, !tbaa !24
  %t692 = add i64 %t689, 1
  store i64 %t692, ptr %l27, !tbaa !24
  br label %bb161
bb168:
  %t694 = load ptr, ptr %l7, !tbaa !29
  %t696 = getelementptr %"compiler/free:Free", ptr %t694, i32 0, i32 69
  %t697 = load i64, ptr %l14, !tbaa !24
  %t700 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t696, i64 %t697)
  store ptr %t700, ptr %l343
  br label %bb169
bb169:
  %t701 = load ptr, ptr %l343, !tbaa !29
  store ptr %t701, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb170
bb170:
  %t702 = load i64, ptr %l31, !tbaa !24
  store i64 %t702, ptr %l344, !tbaa !24
  %t703 = load ptr, ptr %l30, !tbaa !29
  store ptr %t703, ptr %l345, !tbaa !29
  %t704 = call ptr @__olang_scope_hold(ptr %v0)
  %t705 = ptrtoint ptr %t704 to i64
  store i64 %t705, ptr %l346, !tbaa !24
  %t706 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t706, label %bb171, label %bb172
bb171:
  %t708 = load ptr, ptr %l345, !tbaa !29
  %t709 = call ptr @__olang_region_or(ptr %t708, ptr %v0)
  %t710 = call ptr @__olang_scope_hold(ptr %t709)
  %t711 = ptrtoint ptr %t710 to i64
  store i64 %t711, ptr %l346, !tbaa !24
  br label %bb172
bb172:
  %t712 = load ptr, ptr %l30, !tbaa !29
  %t713 = load i64, ptr %l346
  %t714 = inttoptr i64 %t713 to ptr
  %t716 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t714, ptr %t712)
  store i64 %t716, ptr %l349
  br label %bb173
bb173:
  %t717 = load i64, ptr %l344, !tbaa !24
  %t718 = load i64, ptr %l349, !tbaa !24
  %t719 = icmp slt i64 %t717, %t718
  %t721 = xor i1 %t719, true
  br i1 %t721, label %bb174, label %bb175
bb174:
  br label %bb182
bb175:
  br label %bb176
bb176:
  %t723 = load ptr, ptr %l30, !tbaa !29
  store ptr %t723, ptr %l352, !tbaa !29
  %t724 = call ptr @__olang_scope_hold(ptr %v0)
  %t725 = ptrtoint ptr %t724 to i64
  store i64 %t725, ptr %l353, !tbaa !24
  %t726 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t726, label %bb177, label %bb178
bb177:
  %t728 = load ptr, ptr %l352, !tbaa !29
  %t729 = call ptr @__olang_region_or(ptr %t728, ptr %v0)
  %t730 = call ptr @__olang_scope_hold(ptr %t729)
  %t731 = ptrtoint ptr %t730 to i64
  store i64 %t731, ptr %l353, !tbaa !24
  br label %bb178
bb178:
  %t732 = load ptr, ptr %l30, !tbaa !29
  %t733 = load i64, ptr %l31, !tbaa !24
  %t734 = load i64, ptr %l353
  %t735 = inttoptr i64 %t734 to ptr
  %t738 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t735, ptr %t732, i64 %t733)
  store i64 %t738, ptr %l357
  br label %bb179
bb179:
  %t739 = load i64, ptr %l357, !tbaa !24
  %t740 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %s16, ptr %v5, ptr %t740, i64 %t739, ptr %l25, ptr %l24)
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t746 = load i64, ptr %l31, !tbaa !24
  %t749 = add i64 %t746, 1
  store i64 %t749, ptr %l31, !tbaa !24
  br label %bb170
bb182:
  %t751 = load ptr, ptr %l0, !tbaa !29
  store ptr %t751, ptr %l365, !tbaa !29
  %t752 = load ptr, ptr %l365, !tbaa !29
  %t753 = getelementptr %"compiler/free:walker", ptr %t752, i32 0, i32 36
  %t754 = load i64, ptr %t753, !tbaa !24
  %t757 = sub i64 %t754, 1
  %t759 = load ptr, ptr %l365, !tbaa !29
  %t760 = getelementptr %"compiler/free:walker", ptr %t759, i32 0, i32 36
  store i64 %t757, ptr %t760, !tbaa !24
  %t761 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t761, ptr %rv
  br label %ret
bb183:
  %t763 = load ptr, ptr %l3, !tbaa !29
  store ptr %t763, ptr %l370, !tbaa !29
  store i1 false, ptr %l371, !tbaa !21
  %t764 = load ptr, ptr %l370, !tbaa !29
  %t765 = icmp ne ptr %t764, null
  br i1 %t765, label %bb184, label %bb185
bb184:
  %t767 = load ptr, ptr %l370, !tbaa !29
  %t768 = load i64, ptr %t767, !range !{i64 0, i64 18}
  %t770 = icmp eq i64 %t768, 0
  store i1 %t770, ptr %l371, !tbaa !21
  br label %bb185
bb185:
  %t771 = load i1, ptr %l371, !tbaa !21
  br i1 %t771, label %bb186, label %bb187
bb186:
  br label %bb192
bb187:
  %t772 = load ptr, ptr %l3, !tbaa !29
  store ptr %t772, ptr %l374, !tbaa !29
  store i1 false, ptr %l375, !tbaa !21
  %t773 = load ptr, ptr %l374, !tbaa !29
  %t774 = icmp ne ptr %t773, null
  br i1 %t774, label %bb188, label %bb189
bb188:
  %t776 = load ptr, ptr %l374, !tbaa !29
  %t777 = load i64, ptr %t776, !range !{i64 0, i64 18}
  %t779 = icmp eq i64 %t777, 1
  store i1 %t779, ptr %l375, !tbaa !21
  br label %bb189
bb189:
  %t780 = load i1, ptr %l375, !tbaa !21
  br i1 %t780, label %bb190, label %bb191
bb190:
  br label %bb192
bb191:
  br label %bb199
bb192:
  %t781 = load ptr, ptr %l4, !tbaa !29
  %t783 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t781
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t783, ptr %l379
  %t784 = call ptr @__olang_scope_hold(ptr %v5)
  %t785 = ptrtoint ptr %t784 to i64
  store i64 %t785, ptr %l380, !tbaa !24
  %t786 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t786, label %bb193, label %bb194
bb193:
  %t788 = call ptr @__olang_region_make_part(ptr %v5)
  %t789 = ptrtoint ptr %t788 to i64
  store i64 %t789, ptr %l380, !tbaa !24
  br label %bb194
bb194:
  %t790 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379, i32 0, i32 0
  %t791 = load { i64, ptr }, ptr %t790, !tbaa !27
  store { i64, ptr } %t791, ptr %l382, !tbaa !27
  %t792 = load { i64, ptr }, ptr %l382, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t792, 0
  store i64 %t793, ptr %l383, !tbaa !24
  %t794 = load i64, ptr %l383, !tbaa !24
  %t795 = mul i64 %t794, 8
  %t796 = load i64, ptr %l380
  %t797 = inttoptr i64 %t796 to ptr
  %t798 = call ptr @__olang_held_alloc(ptr %t797, i64 %t795)
  %t799 = insertvalue { i64, ptr } undef, i64 %t794, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  store { i64, ptr } %t800, ptr %l384, !tbaa !27
  %t801 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t802 = load ptr, ptr %t801, !tbaa !27
  %t803 = getelementptr { i64, ptr }, ptr %l382, i32 0, i32 1
  %t804 = load ptr, ptr %t803, !tbaa !27
  %t805 = load i64, ptr %l383, !tbaa !24
  %t806 = mul i64 %t805, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t802, ptr %t804, i64 %t806, i1 false)
  %t807 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t808 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379, i32 0, i32 0
  store { i64, ptr } %t807, ptr %t808, !tbaa !27
  %t809 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t809, label %bb195, label %bb196
bb195:
  %t811 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379, i32 0, i32 0
  %t812 = load { i64, ptr }, ptr %t811, !tbaa !27
  %t813 = extractvalue { i64, ptr } %t812, 0
  %t815 = icmp eq i64 %t813, 0
  br i1 %t815, label %bb197, label %bb198
bb196:
  call void @__olang_scope_close(ptr %s0)
  %t817 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t817, ptr %rv
  br label %ret
bb197:
  %t818 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t818, !tbaa !27
  br label %bb198
bb198:
  %t819 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379, i32 0, i32 0
  %t820 = load i64, ptr %l380
  %t821 = inttoptr i64 %t820 to ptr
  %t822 = load { i64, ptr }, ptr %t819
  %t823 = extractvalue { i64, ptr } %t822, 1
  %t824 = call ptr @__olang_region_or(ptr %t823, ptr null)
  %t825 = icmp ne ptr %t824, null
  %t826 = select i1 %t825, ptr %t824, ptr null
  call void @__olang_region_settle_in(ptr %t821, ptr %t826)
  br label %bb196
bb199:
  br i1 true, label %bb200, label %bb201
bb200:
  br label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb204
bb203:
  call void @__olang_check_failed(ptr @olang_loc_fd03f9e0e77d658_c5fe745f2729a3d4)
  unreachable
bb204:
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t829 = getelementptr %"compiler/free:walker", ptr %t827, i32 0, i32 2
  %t830 = load i1, ptr %t829, !tbaa !21
  br i1 %t830, label %bb205, label %bb206
bb205:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t834 = getelementptr %"compiler/free:walker", ptr %t832, i32 0, i32 36
  %t835 = load i64, ptr %t834, !tbaa !24
  %t837 = icmp eq i64 %t835, 0
  store i1 %t837, ptr %l390, !tbaa !21
  br label %bb207
bb206:
  store i1 false, ptr %l390, !tbaa !21
  br label %bb207
bb207:
  %t839 = load i1, ptr %l390, !tbaa !21
  br i1 %t839, label %bb208, label %bb209
bb208:
  %t840 = load ptr, ptr %l1, !tbaa !29
  store ptr %t840, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb210
bb209:
  br label %bb237
bb210:
  store %olang.scope zeroinitializer, ptr %s27
  %t842 = load i64, ptr %l34, !tbaa !24
  store i64 %t842, ptr %l395, !tbaa !24
  %t843 = load ptr, ptr %l33, !tbaa !29
  %t845 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t843)
  store i64 %t845, ptr %l397
  br label %bb211
bb211:
  %t846 = load i64, ptr %l395, !tbaa !24
  %t847 = load i64, ptr %l397, !tbaa !24
  %t848 = icmp slt i64 %t846, %t847
  %t850 = xor i1 %t848, true
  br i1 %t850, label %bb212, label %bb213
bb212:
  call void @__olang_scope_close(ptr %s27)
  br label %bb236
bb213:
  br label %bb214
bb214:
  %t852 = load ptr, ptr %l33, !tbaa !29
  %t853 = load i64, ptr %l34, !tbaa !24
  %t856 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t852, i64 %t853)
  store %"compiler/free:leaf" %t856, ptr %l402
  br label %bb215
bb215:
  %t857 = load %"compiler/free:leaf", ptr %l402
  store %"compiler/free:leaf" %t857, ptr %l403
  %t858 = call ptr @__olang_scope_hold(ptr %s27)
  %t859 = ptrtoint ptr %t858 to i64
  store i64 %t859, ptr %l404, !tbaa !24
  %t860 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t860, label %bb216, label %bb217
bb216:
  %t862 = call ptr @__olang_region_make_part(ptr %s27)
  %t863 = ptrtoint ptr %t862 to i64
  store i64 %t863, ptr %l404, !tbaa !24
  br label %bb217
bb217:
  %t864 = getelementptr %"compiler/free:leaf", ptr %l403, i32 0, i32 0
  %t865 = load { i64, ptr }, ptr %t864, !tbaa !27
  store { i64, ptr } %t865, ptr %l406, !tbaa !27
  %t866 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 0
  store i64 %t867, ptr %l407, !tbaa !24
  %t868 = load i64, ptr %l407, !tbaa !24
  %t869 = mul i64 %t868, 8
  %t870 = load i64, ptr %l404
  %t871 = inttoptr i64 %t870 to ptr
  %t872 = call ptr @__olang_held_alloc(ptr %t871, i64 %t869)
  %t873 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t874 = insertvalue { i64, ptr } %t873, ptr %t872, 1
  store { i64, ptr } %t874, ptr %l408, !tbaa !27
  %t875 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !27
  %t877 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t878 = load ptr, ptr %t877, !tbaa !27
  %t879 = load i64, ptr %l407, !tbaa !24
  %t880 = mul i64 %t879, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t876, ptr %t878, i64 %t880, i1 false)
  %t881 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t882 = getelementptr %"compiler/free:leaf", ptr %l403, i32 0, i32 0
  store { i64, ptr } %t881, ptr %t882, !tbaa !27
  %t883 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t883, label %bb218, label %bb219
bb218:
  %t885 = getelementptr %"compiler/free:leaf", ptr %l403, i32 0, i32 0
  %t886 = load { i64, ptr }, ptr %t885, !tbaa !27
  %t887 = extractvalue { i64, ptr } %t886, 0
  %t889 = icmp eq i64 %t887, 0
  br i1 %t889, label %bb220, label %bb221
bb219:
  %t891 = load %"compiler/free:leaf", ptr %l403
  store %"compiler/free:leaf" %t891, ptr %l35
  %t892 = load ptr, ptr %l7, !tbaa !29
  %t893 = getelementptr %"compiler/free:leaf", ptr %l35, i32 0, i32 1
  %t894 = load i64, ptr %t893, !tbaa !24
  %t897 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t892, i64 %t894)
  store i1 %t897, ptr %l414
  br label %bb222
bb220:
  %t898 = getelementptr %"compiler/free:leaf", ptr %l403, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t898, !tbaa !27
  br label %bb221
bb221:
  %t899 = getelementptr %"compiler/free:leaf", ptr %l403, i32 0, i32 0
  %t900 = load i64, ptr %l404
  %t901 = inttoptr i64 %t900 to ptr
  %t902 = load { i64, ptr }, ptr %t899
  %t903 = extractvalue { i64, ptr } %t902, 1
  %t904 = call ptr @__olang_region_or(ptr %t903, ptr null)
  %t905 = icmp ne ptr %t904, null
  %t906 = select i1 %t905, ptr %t904, ptr null
  call void @__olang_region_settle_in(ptr %t901, ptr %t906)
  br label %bb219
bb222:
  %t907 = load i1, ptr %l414, !tbaa !21
  br i1 %t907, label %bb223, label %bb224
bb223:
  call void @__olang_scope_close(ptr %s27)
  br label %bb235
bb224:
  br label %bb225
bb225:
  %t908 = load ptr, ptr %l7, !tbaa !29
  %t910 = getelementptr %"compiler/free:Free", ptr %t908, i32 0, i32 101
  store ptr %t910, ptr %l416, !tbaa !29
  %t911 = getelementptr %"compiler/free:leaf", ptr %l35, i32 0, i32 1
  %t912 = load i64, ptr %t911, !tbaa !24
  store i64 %t912, ptr %l417, !tbaa !24
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t915 = getelementptr %"compiler/free:walker", ptr %t913, i32 0, i32 1
  %t916 = load i64, ptr %t915, !tbaa !24
  store i64 %t916, ptr %l419, !tbaa !24
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t919 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t917)
  store ptr %t919, ptr %l421
  br label %bb226
bb226:
  %t920 = load ptr, ptr %l421, !tbaa !29
  %t922 = getelementptr %"compiler/typed:Body", ptr %t920, i32 0, i32 3
  %t923 = load i64, ptr %t922, !tbaa !24
  %t924 = load %"compiler/source:Span", ptr %l5
  %t925 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t926 = load ptr, ptr %l3, !tbaa !29
  %t928 = load i64, ptr %l417, !tbaa !24
  %t929 = load i64, ptr %l419, !tbaa !24
  %t934 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t928, i64 %t929, i64 %t923, %"compiler/source:Span" %t924, i64 %t925, i64 -1, i64 -1, ptr %t926, ptr null)
  store %"compiler/free:store" %t934, ptr %l428
  br label %bb227
bb227:
  %t935 = load ptr, ptr %l416, !tbaa !29
  %t936 = load %"compiler/free:store", ptr %l428
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t935, %"compiler/free:store" %t936)
  br label %bb228
bb228:
  %t937 = load ptr, ptr %l7, !tbaa !29
  store ptr %t937, ptr %l429, !tbaa !29
  %t938 = getelementptr %"compiler/free:leaf", ptr %l35, i32 0, i32 1
  %t939 = load i64, ptr %t938, !tbaa !24
  store i64 %t939, ptr %l430, !tbaa !24
  %t940 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t940, ptr %l431, !tbaa !24
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t943 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t941)
  store ptr %t943, ptr %l433
  br label %bb229
bb229:
  %t944 = load ptr, ptr %l433, !tbaa !29
  %t946 = getelementptr %"compiler/typed:Body", ptr %t944, i32 0, i32 3
  %t947 = load i64, ptr %t946, !tbaa !24
  store i64 %t947, ptr %l435, !tbaa !24
  %t948 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t948, ptr %l436
  %t949 = call ptr @__olang_scope_hold(ptr %v0)
  %t950 = ptrtoint ptr %t949 to i64
  store i64 %t950, ptr %l437, !tbaa !24
  %t951 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t951, label %bb230, label %bb231
bb230:
  %t953 = call ptr @__olang_region_make(ptr %v0)
  %t954 = ptrtoint ptr %t953 to i64
  store i64 %t954, ptr %l437, !tbaa !24
  br label %bb231
bb231:
  %t955 = load ptr, ptr %l0, !tbaa !29
  store ptr %t955, ptr %l439, !tbaa !29
  %t956 = load ptr, ptr %l3, !tbaa !29
  %t958 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t956)
  store %"compiler/source:Span" %t958, ptr %l441
  br label %bb232
bb232:
  %t959 = load ptr, ptr %l439, !tbaa !29
  %t960 = load %"compiler/source:Span", ptr %l441
  %t961 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s27, ptr %t959, %"compiler/source:Span" %t960)
  store { i64, ptr } %t961, ptr %l442
  br label %bb233
bb233:
  %t962 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t963 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t964 = load { i64, ptr }, ptr %l442, !tbaa !27
  %t965 = extractvalue { i64, ptr } %t964, 1
  %t966 = extractvalue { i64, ptr } %t964, 0
  %t967 = add i64 %t963, %t966
  %t968 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t969 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t970 = add i64 %t967, %t969
  %t971 = load i64, ptr %l437
  %t972 = inttoptr i64 %t971 to ptr
  %t973 = call ptr @__olang_held_alloc(ptr %t972, i64 %t970)
  call void @olang_textcopy(ptr %t973, ptr %t962, i64 %t963)
  %t974 = getelementptr i8, ptr %t973, i64 %t963
  call void @olang_textcopy(ptr %t974, ptr %t965, i64 %t966)
  %t975 = getelementptr i8, ptr %t974, i64 %t966
  call void @olang_textcopy(ptr %t975, ptr %t968, i64 %t969)
  %t976 = insertvalue { i64, ptr } undef, i64 %t970, 0
  %t977 = insertvalue { i64, ptr } %t976, ptr %t973, 1
  %t979 = load ptr, ptr %l429, !tbaa !29
  %t980 = load i64, ptr %l430, !tbaa !24
  %t981 = load i64, ptr %l431, !tbaa !24
  %t982 = load i64, ptr %l435, !tbaa !24
  %t983 = load %"compiler/source:Span", ptr %l436
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t979, i64 %t980, i64 %t981, i64 %t982, %"compiler/source:Span" %t983, { i64, ptr } %t977)
  br label %bb234
bb234:
  call void @__olang_scope_close(ptr %s27)
  br label %bb235
bb235:
  %t985 = load i64, ptr %l34, !tbaa !24
  %t988 = add i64 %t985, 1
  store i64 %t988, ptr %l34, !tbaa !24
  br label %bb210
bb236:
  br label %bb237
bb237:
  %t990 = load ptr, ptr %l4, !tbaa !29
  %t992 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t990
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t992, ptr %l449
  %t993 = call ptr @__olang_scope_hold(ptr %v5)
  %t994 = ptrtoint ptr %t993 to i64
  store i64 %t994, ptr %l450, !tbaa !24
  %t995 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t995, label %bb238, label %bb239
bb238:
  %t997 = call ptr @__olang_region_make_part(ptr %v5)
  %t998 = ptrtoint ptr %t997 to i64
  store i64 %t998, ptr %l450, !tbaa !24
  br label %bb239
bb239:
  %t999 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l449, i32 0, i32 0
  %t1000 = load { i64, ptr }, ptr %t999, !tbaa !27
  store { i64, ptr } %t1000, ptr %l452, !tbaa !27
  %t1001 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t1002 = extractvalue { i64, ptr } %t1001, 0
  store i64 %t1002, ptr %l453, !tbaa !24
  %t1003 = load i64, ptr %l453, !tbaa !24
  %t1004 = mul i64 %t1003, 8
  %t1005 = load i64, ptr %l450
  %t1006 = inttoptr i64 %t1005 to ptr
  %t1007 = call ptr @__olang_held_alloc(ptr %t1006, i64 %t1004)
  %t1008 = insertvalue { i64, ptr } undef, i64 %t1003, 0
  %t1009 = insertvalue { i64, ptr } %t1008, ptr %t1007, 1
  store { i64, ptr } %t1009, ptr %l454, !tbaa !27
  %t1010 = getelementptr { i64, ptr }, ptr %l454, i32 0, i32 1
  %t1011 = load ptr, ptr %t1010, !tbaa !27
  %t1012 = getelementptr { i64, ptr }, ptr %l452, i32 0, i32 1
  %t1013 = load ptr, ptr %t1012, !tbaa !27
  %t1014 = load i64, ptr %l453, !tbaa !24
  %t1015 = mul i64 %t1014, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1011, ptr %t1013, i64 %t1015, i1 false)
  %t1016 = load { i64, ptr }, ptr %l454, !tbaa !27
  %t1017 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l449, i32 0, i32 0
  store { i64, ptr } %t1016, ptr %t1017, !tbaa !27
  %t1018 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1018, label %bb240, label %bb241
bb240:
  %t1020 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l449, i32 0, i32 0
  %t1021 = load { i64, ptr }, ptr %t1020, !tbaa !27
  %t1022 = extractvalue { i64, ptr } %t1021, 0
  %t1024 = icmp eq i64 %t1022, 0
  br i1 %t1024, label %bb242, label %bb243
bb241:
  call void @__olang_scope_close(ptr %s0)
  %t1026 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l449
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1026, ptr %rv
  br label %ret
bb242:
  %t1027 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l449, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1027, !tbaa !27
  br label %bb243
bb243:
  %t1028 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l449, i32 0, i32 0
  %t1029 = load i64, ptr %l450
  %t1030 = inttoptr i64 %t1029 to ptr
  %t1031 = load { i64, ptr }, ptr %t1028
  %t1032 = extractvalue { i64, ptr } %t1031, 1
  %t1033 = call ptr @__olang_region_or(ptr %t1032, ptr null)
  %t1034 = icmp ne ptr %t1033, null
  %t1035 = select i1 %t1034, ptr %t1033, ptr null
  call void @__olang_region_settle_in(ptr %t1030, ptr %t1035)
  br label %bb241
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, i1 %a6, i64 %a7, i32 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i64
  %l52 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca i64
  %l72 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i1
  %l84 = alloca ptr
  %l86 = alloca i64
  %l91 = alloca i1
  %l95 = alloca i1
  %l100 = alloca ptr
  %l102 = alloca i64
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l140 = alloca i1
  %l141 = alloca i64
  %l144 = alloca i64
  %l148 = alloca ptr
  %l152 = alloca i64
  %l154 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l156 = alloca ptr
  %l160 = alloca i64
  %l162 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l167 = alloca i1
  %l171 = alloca i1
  %l177 = alloca i64
  %l185 = alloca ptr
  %l189 = alloca i64
  %l200 = alloca ptr
  %l204 = alloca i1
  %l207 = alloca i64
  %l209 = alloca i64
  %l211 = alloca ptr
  %l214 = alloca i64
  %l216 = alloca i64
  %l230 = alloca ptr
  %l234 = alloca i1
  %l238 = alloca i1
  %l242 = alloca i1
  %l246 = alloca i1
  %l251 = alloca i1
  %l256 = alloca ptr
  %l259 = alloca i64
  %l261 = alloca ptr
  %l262 = alloca i64
  %l264 = alloca i64
  %l266 = alloca ptr
  %l268 = alloca i64
  %l270 = alloca %"compiler/source:Span"
  %l271 = alloca %"compiler/source:Span"
  %l272 = alloca i64
  %l273 = alloca %"compiler/source:Span"
  %l274 = alloca i64
  %l278 = alloca i1
  %l280 = alloca i1
  %l281 = alloca %"compiler/free:letGo"
  %l283 = alloca ptr
  %l286 = alloca i1
  %l290 = alloca i1
  %l293 = alloca i1
  %l296 = alloca i1
  %l300 = alloca ptr
  %l302 = alloca i1
  %l304 = alloca i1
  %l308 = alloca ptr
  %l310 = alloca i1
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  store i64 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l9, !tbaa !29
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 36
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb8:
  br label %bb64
bb9:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l29, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 78
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t36, i64 %t40)
  store i1 %t43, ptr %l37
  br label %bb14
bb13:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb15
bb14:
  %t44 = load i1, ptr %l37, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l32, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l9, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 79
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/free:walker", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t50, i64 %t54)
  store ptr %t57, ptr %l44
  br label %bb18
bb17:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb20
bb18:
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load ptr, ptr %l44, !tbaa !29
  %t61 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t59, i64 %t58)
  store i64 %t61, ptr %l46
  br label %bb19
bb19:
  %t62 = load i64, ptr %l46, !tbaa !24
  %t63 = icmp sgt i64 %t62, 0
  store i1 %t63, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l39, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l9, !tbaa !29
  %t68 = getelementptr %"compiler/free:Free", ptr %t66, i32 0, i32 95
  store i1 true, ptr %t68, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t73 = icmp ne i64 %t69, %t70
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t75 = load i64, ptr %l1, !tbaa !24
  %t77 = icmp sge i64 %t75, 0
  store i1 %t77, ptr %l52, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l52, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 81
  %t83 = load i1, ptr %t82, !tbaa !21
  %t85 = xor i1 %t83, true
  store i1 %t85, ptr %l55, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb29
bb29:
  %t87 = load i1, ptr %l55, !tbaa !21
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l9, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 77
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:walker", ptr %t91, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  %t97 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t90, i64 %t94)
  store ptr %t97, ptr %l64
  br label %bb32
bb31:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb34
bb32:
  %t98 = load i64, ptr %l1, !tbaa !24
  %t99 = load ptr, ptr %l64, !tbaa !29
  %t101 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t99, i64 %t98)
  store i64 %t101, ptr %l66
  br label %bb33
bb33:
  %t102 = load i64, ptr %l66, !tbaa !24
  %t103 = icmp sgt i64 %t102, 0
  store i1 %t103, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t105 = load i1, ptr %l59, !tbaa !21
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t106 = load ptr, ptr %l9, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 95
  store i1 true, ptr %t108, !tbaa !21
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t109 = load i1, ptr %l6, !tbaa !21
  br i1 %t109, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t111 = load i64, ptr %l1, !tbaa !24
  %t113 = icmp sge i64 %t111, 0
  br i1 %t113, label %bb41, label %bb42
bb41:
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/free:Free", ptr %t115, i32 0, i32 78
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/free:walker", ptr %t118, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t124 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t117, i64 %t121)
  store i1 %t124, ptr %l77
  br label %bb43
bb42:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb44
bb43:
  %t125 = load i1, ptr %l77, !tbaa !21
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l72, !tbaa !21
  br label %bb44
bb44:
  %t128 = load i1, ptr %l72, !tbaa !21
  br i1 %t128, label %bb45, label %bb46
bb45:
  %t129 = load ptr, ptr %l9, !tbaa !29
  %t131 = getelementptr %"compiler/free:Free", ptr %t129, i32 0, i32 75
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 1
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t131, i64 %t135)
  store ptr %t138, ptr %l84
  br label %bb47
bb46:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb49
bb47:
  %t139 = load i64, ptr %l1, !tbaa !24
  %t140 = load ptr, ptr %l84, !tbaa !29
  %t142 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t140, i64 %t139)
  store i64 %t142, ptr %l86
  br label %bb48
bb48:
  %t143 = load i64, ptr %l86, !tbaa !24
  %t144 = icmp sgt i64 %t143, 0
  store i1 %t144, ptr %l79, !tbaa !21
  br label %bb49
bb49:
  %t146 = load i1, ptr %l79, !tbaa !21
  br i1 %t146, label %bb50, label %bb51
bb50:
  %t147 = load ptr, ptr %l9, !tbaa !29
  %t149 = getelementptr %"compiler/free:Free", ptr %t147, i32 0, i32 95
  store i1 true, ptr %t149, !tbaa !21
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t150 = load i64, ptr %l1, !tbaa !24
  %t152 = icmp sge i64 %t150, 0
  br i1 %t152, label %bb53, label %bb54
bb53:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/free:walker", ptr %t154, i32 0, i32 81
  %t157 = load i1, ptr %t156, !tbaa !21
  %t159 = xor i1 %t157, true
  store i1 %t159, ptr %l91, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb55
bb55:
  %t161 = load i1, ptr %l91, !tbaa !21
  br i1 %t161, label %bb56, label %bb57
bb56:
  %t162 = load ptr, ptr %l9, !tbaa !29
  %t164 = getelementptr %"compiler/free:Free", ptr %t162, i32 0, i32 76
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:walker", ptr %t165, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t171 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t164, i64 %t168)
  store ptr %t171, ptr %l100
  br label %bb58
bb57:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb60
bb58:
  %t172 = load i64, ptr %l1, !tbaa !24
  %t173 = load ptr, ptr %l100, !tbaa !29
  %t175 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t173, i64 %t172)
  store i64 %t175, ptr %l102
  br label %bb59
bb59:
  %t176 = load i64, ptr %l102, !tbaa !24
  %t177 = icmp sgt i64 %t176, 0
  store i1 %t177, ptr %l95, !tbaa !21
  br label %bb60
bb60:
  %t179 = load i1, ptr %l95, !tbaa !21
  br i1 %t179, label %bb61, label %bb62
bb61:
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 95
  store i1 true, ptr %t182, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t183, i32 0, i32 36
  %t186 = load i64, ptr %t185, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  br i1 %t188, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  br label %bb67
bb67:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/free:walker", ptr %t190, i32 0, i32 79
  %t193 = load i1, ptr %t192, !tbaa !21
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb68, label %bb69
bb68:
  store i64 0, ptr %l10, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 42
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t199)
  store i64 %t201, ptr %l113
  br label %bb70
bb69:
  br label %bb96
bb70:
  %t202 = load i64, ptr %l113, !tbaa !24
  store i64 %t202, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t203 = load i64, ptr %l11, !tbaa !24
  %t204 = load i64, ptr %l10, !tbaa !24
  %t207 = icmp sgt i64 %t203, %t204
  br i1 %t207, label %bb71, label %bb72
bb71:
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = icmp sgt i64 %t209, 0
  br i1 %t211, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb76
bb73:
  %t213 = load i64, ptr %l11, !tbaa !24
  %t214 = load i64, ptr %l10, !tbaa !24
  %t217 = sub i64 %t213, %t214
  %t218 = load i64, ptr %l12, !tbaa !24
  %t221 = add i64 %t217, %t218
  %t223 = sub i64 %t221, 1
  %t224 = load i64, ptr %l12, !tbaa !24
  %t227 = sdiv i64 %t223, %t224
  store i64 %t227, ptr %l120, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb75
bb75:
  %t229 = load i64, ptr %l120, !tbaa !24
  store i64 %t229, ptr %l117, !tbaa !24
  br label %bb76
bb76:
  %t230 = load i64, ptr %l117, !tbaa !24
  store i64 %t230, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb77
bb77:
  %t231 = load i64, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l13, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb78, label %bb79
bb78:
  br label %bb95
bb79:
  br label %bb80
bb80:
  %t239 = load i64, ptr %l10, !tbaa !24
  %t240 = load i64, ptr %l14, !tbaa !24
  %t241 = load i64, ptr %l12, !tbaa !24
  %t244 = mul i64 %t240, %t241
  %t247 = add i64 %t239, %t244
  store i64 %t247, ptr %l15, !tbaa !24
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/free:walker", ptr %t249, i32 0, i32 80
  %t252 = load i1, ptr %t251, !tbaa !21
  br i1 %t252, label %bb81, label %bb82
bb81:
  %t254 = load i64, ptr %l15, !tbaa !24
  store i64 %t254, ptr %l141, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/free:walker", ptr %t255, i32 0, i32 42
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l144
  br label %bb83
bb82:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb84
bb83:
  %t260 = load i64, ptr %l144, !tbaa !24
  %t261 = sub i64 %t260, 1
  %t262 = load i64, ptr %l141, !tbaa !24
  %t264 = icmp eq i64 %t262, %t261
  store i1 %t264, ptr %l140, !tbaa !21
  br label %bb84
bb84:
  %t266 = load i1, ptr %l140, !tbaa !21
  br i1 %t266, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s12
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t269 = getelementptr %"compiler/free:Free", ptr %t267, i32 0, i32 139
  store ptr %t269, ptr %l148, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/free:walker", ptr %t270, i32 0, i32 42
  %t273 = load i64, ptr %l15, !tbaa !24
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t272, i64 %t273)
  store i64 %t276, ptr %l152
  br label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t277 = load ptr, ptr %l9, !tbaa !29
  %t279 = getelementptr %"compiler/free:Free", ptr %t277, i32 0, i32 137
  store ptr %t279, ptr %l156, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/free:walker", ptr %t280, i32 0, i32 42
  %t283 = load i64, ptr %l15, !tbaa !24
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t282, i64 %t283)
  store i64 %t286, ptr %l160
  br label %bb90
bb87:
  %t287 = load i64, ptr %l1, !tbaa !24
  %t288 = load i64, ptr %l152, !tbaa !24
  %t290 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t288, i64 %t287)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t290, ptr %l154
  br label %bb88
bb88:
  %t291 = load ptr, ptr %l148, !tbaa !29
  %t292 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l154
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t291, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t292)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb90:
  %t293 = load i64, ptr %l1, !tbaa !24
  %t294 = load i64, ptr %l160, !tbaa !24
  %t296 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s13, i64 %t294, i64 %t293)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t296, ptr %l162
  br label %bb91
bb91:
  %t297 = load ptr, ptr %l156, !tbaa !29
  %t298 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l162
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t297, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t298)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s13)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t299 = load i64, ptr %l14, !tbaa !24
  %t302 = add i64 %t299, 1
  store i64 %t302, ptr %l14, !tbaa !24
  br label %bb77
bb95:
  br label %bb96
bb96:
  %t304 = load i1, ptr %l6, !tbaa !21
  br i1 %t304, label %bb97, label %bb98
bb97:
  %t306 = load i64, ptr %l7, !tbaa !24
  %t307 = load i64, ptr @G_2ecompiler_2ffree_2eWalkIn, !tbaa !24
  %t310 = icmp eq i64 %t306, %t307
  store i1 %t310, ptr %l167, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb99
bb99:
  %t312 = load i1, ptr %l167, !tbaa !21
  br i1 %t312, label %bb100, label %bb101
bb100:
  %t313 = load i64, ptr %l1, !tbaa !24
  %t315 = icmp sge i64 %t313, 0
  store i1 %t315, ptr %l171, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb102
bb102:
  %t317 = load i1, ptr %l171, !tbaa !21
  br i1 %t317, label %bb103, label %bb104
bb103:
  %t318 = load ptr, ptr %l9, !tbaa !29
  %t320 = getelementptr %"compiler/free:Free", ptr %t318, i32 0, i32 80
  %t321 = load i64, ptr %l1, !tbaa !24
  %t324 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t320, i64 %t321)
  store i64 %t324, ptr %l177
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb106
bb106:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/free:walker", ptr %t325, i32 0, i32 84
  %t328 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t327, i64 %t328)
  br label %bb107
bb107:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/free:walker", ptr %t331, i32 0, i32 85
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t333, i32 %a8)
  br label %bb108
bb108:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/free:walker", ptr %t337, i32 0, i32 86
  store ptr %t339, ptr %l185, !tbaa !29
  %t340 = load i64, ptr %l7, !tbaa !24
  %t341 = load i64, ptr @G_2ecompiler_2ffree_2eWalkIn, !tbaa !24
  %t344 = icmp eq i64 %t340, %t341
  br i1 %t344, label %bb109, label %bb110
bb109:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/free:walker", ptr %t346, i32 0, i32 87
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l189, !tbaa !24
  br label %bb111
bb110:
  store i64 -1, ptr %l189, !tbaa !24
  br label %bb111
bb111:
  %t351 = load ptr, ptr %l185, !tbaa !29
  %t352 = load i64, ptr %l189, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t351, i64 %t352)
  br label %bb112
bb112:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/free:walker", ptr %t353, i32 0, i32 71
  %t356 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t355, i64 %t356)
  br label %bb113
bb113:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/free:walker", ptr %t359, i32 0, i32 72
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/free:walker", ptr %t362, i32 0, i32 15
  %t365 = load i64, ptr %t364, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t361, i64 %t365)
  br label %bb114
bb114:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/free:walker", ptr %t368, i32 0, i32 57
  store ptr %t370, ptr %l200, !tbaa !29
  %t371 = load i64, ptr %l2, !tbaa !24
  %t372 = load i64, ptr @G_2ecompiler_2ffree_2eLHeld, !tbaa !24
  %t375 = icmp eq i64 %t371, %t372
  br i1 %t375, label %bb115, label %bb116
bb115:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/free:walker", ptr %t377, i32 0, i32 100
  %t381 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t379)
  store i64 %t381, ptr %l207
  br label %bb117
bb116:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb118
bb117:
  %t382 = load i64, ptr %l207, !tbaa !24
  %t383 = icmp sgt i64 %t382, 0
  store i1 %t383, ptr %l204, !tbaa !21
  br label %bb118
bb118:
  %t385 = load i1, ptr %l204, !tbaa !21
  br i1 %t385, label %bb119, label %bb120
bb119:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:walker", ptr %t386, i32 0, i32 100
  store ptr %t388, ptr %l211, !tbaa !29
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/free:walker", ptr %t389, i32 0, i32 100
  %t393 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t391)
  store i64 %t393, ptr %l214
  br label %bb121
bb120:
  store i64 -1, ptr %l209, !tbaa !24
  br label %bb123
bb121:
  %t394 = load i64, ptr %l214, !tbaa !24
  %t395 = sub i64 %t394, 1
  %t396 = load ptr, ptr %l211, !tbaa !29
  %t398 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t396, i64 %t395)
  store i64 %t398, ptr %l216
  br label %bb122
bb122:
  %t399 = load i64, ptr %l216, !tbaa !24
  store i64 %t399, ptr %l209, !tbaa !24
  br label %bb123
bb123:
  %t400 = load ptr, ptr %l200, !tbaa !29
  %t401 = load i64, ptr %l209, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t400, i64 %t401)
  br label %bb124
bb124:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/free:walker", ptr %t402, i32 0, i32 73
  %t405 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t404, i64 %t405)
  br label %bb125
bb125:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/free:walker", ptr %t408, i32 0, i32 74
  %t411 = load %"compiler/source:Span", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t410, %"compiler/source:Span" %t411)
  br label %bb126
bb126:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/free:walker", ptr %t414, i32 0, i32 75
  %t417 = load %"compiler/source:Span", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t416, %"compiler/source:Span" %t417)
  br label %bb127
bb127:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/free:walker", ptr %t420, i32 0, i32 76
  %t423 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t422, i64 %t423)
  br label %bb128
bb128:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/free:walker", ptr %t426, i32 0, i32 77
  store ptr %t428, ptr %l230, !tbaa !29
  %t429 = load i64, ptr %l2, !tbaa !24
  %t430 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t433 = icmp eq i64 %t429, %t430
  br i1 %t433, label %bb129, label %bb130
bb129:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/free:walker", ptr %t435, i32 0, i32 78
  %t438 = load i1, ptr %t437, !tbaa !21
  store i1 %t438, ptr %l234, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb131
bb131:
  %t440 = load ptr, ptr %l230, !tbaa !29
  %t441 = load i1, ptr %l234, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t440, i1 %t441)
  br label %bb132
bb132:
  %t442 = load i1, ptr %l6, !tbaa !21
  br i1 %t442, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l238, !tbaa !21
  br label %bb135
bb134:
  %t444 = load i64, ptr %l2, !tbaa !24
  %t445 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t448 = icmp eq i64 %t444, %t445
  store i1 %t448, ptr %l238, !tbaa !21
  br label %bb135
bb135:
  %t450 = load i1, ptr %l238, !tbaa !21
  br i1 %t450, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l242, !tbaa !21
  br label %bb142
bb137:
  %t451 = load i64, ptr %l2, !tbaa !24
  %t452 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t455 = icmp eq i64 %t451, %t452
  br i1 %t455, label %bb138, label %bb139
bb138:
  %t457 = load ptr, ptr %l9, !tbaa !29
  %t459 = getelementptr %"compiler/free:Free", ptr %t457, i32 0, i32 30
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/free:walker", ptr %t460, i32 0, i32 1
  %t463 = load i64, ptr %t462, !tbaa !24
  %t466 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t459, i64 %t463)
  store i1 %t466, ptr %l251
  br label %bb140
bb139:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb141
bb140:
  %t467 = load i1, ptr %l251, !tbaa !21
  %t468 = xor i1 %t467, true
  store i1 %t468, ptr %l246, !tbaa !21
  br label %bb141
bb141:
  %t470 = load i1, ptr %l246, !tbaa !21
  store i1 %t470, ptr %l242, !tbaa !21
  br label %bb142
bb142:
  %t471 = load i1, ptr %l242, !tbaa !21
  br i1 %t471, label %bb143, label %bb144
bb143:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/free:walker", ptr %t472, i32 0, i32 83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t474, i64 -1)
  br label %bb145
bb144:
  br label %bb146
bb145:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb146:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/free:walker", ptr %t476, i32 0, i32 83
  store ptr %t478, ptr %l256, !tbaa !29
  %t479 = load ptr, ptr %l9, !tbaa !29
  %t481 = getelementptr %"compiler/free:Free", ptr %t479, i32 0, i32 102
  %t483 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t481)
  store i64 %t483, ptr %l259
  br label %bb147
bb147:
  %t484 = load ptr, ptr %l256, !tbaa !29
  %t485 = load i64, ptr %l259, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t484, i64 %t485)
  br label %bb148
bb148:
  %t486 = load ptr, ptr %l9, !tbaa !29
  %t488 = getelementptr %"compiler/free:Free", ptr %t486, i32 0, i32 102
  store ptr %t488, ptr %l261, !tbaa !29
  %t489 = load i64, ptr %l1, !tbaa !24
  store i64 %t489, ptr %l262, !tbaa !24
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/free:walker", ptr %t490, i32 0, i32 1
  %t493 = load i64, ptr %t492, !tbaa !24
  store i64 %t493, ptr %l264, !tbaa !24
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t494)
  store ptr %t496, ptr %l266
  br label %bb149
bb149:
  %t497 = load ptr, ptr %l266, !tbaa !29
  %t499 = getelementptr %"compiler/typed:Body", ptr %t497, i32 0, i32 3
  %t500 = load i64, ptr %t499, !tbaa !24
  store i64 %t500, ptr %l268, !tbaa !24
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/free:walker", ptr %t501, i32 0, i32 65
  %t504 = load %"compiler/source:Span", ptr %t503
  store %"compiler/source:Span" %t504, ptr %l270
  %t505 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t505, ptr %l271
  %t506 = load i64, ptr %l2, !tbaa !24
  store i64 %t506, ptr %l272, !tbaa !24
  %t507 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t507, ptr %l273
  %t508 = load i64, ptr %l5, !tbaa !24
  store i64 %t508, ptr %l274, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/free:walker", ptr %t509, i32 0, i32 30
  %t512 = load i64, ptr %t511, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb150, label %bb151
bb150:
  store i1 true, ptr %l278, !tbaa !21
  br label %bb153
bb151:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erunsAgain(ptr %v0, ptr %t516)
  store i1 %t518, ptr %l280
  br label %bb152
bb152:
  %t519 = load i1, ptr %l280, !tbaa !21
  store i1 %t519, ptr %l278, !tbaa !21
  br label %bb153
bb153:
  %t520 = load i64, ptr %l262, !tbaa !24
  %t521 = load i64, ptr %l264, !tbaa !24
  %t522 = load i64, ptr %l268, !tbaa !24
  %t523 = load %"compiler/source:Span", ptr %l270
  %t524 = load %"compiler/source:Span", ptr %l271
  %t525 = load i64, ptr %l272, !tbaa !24
  %t526 = load %"compiler/source:Span", ptr %l273
  %t527 = load i64, ptr %l274, !tbaa !24
  %t528 = load i1, ptr %l278, !tbaa !21
  %t529 = call %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %s0, i64 %t520, i64 %t521, i64 %t522, %"compiler/source:Span" %t523, %"compiler/source:Span" %t524, i64 %t525, %"compiler/source:Span" %t526, i64 %t527, i1 %t528)
  store %"compiler/free:letGo" %t529, ptr %l281
  br label %bb154
bb154:
  %t530 = load ptr, ptr %l261, !tbaa !29
  %t531 = load %"compiler/free:letGo", ptr %l281
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t530, %"compiler/free:letGo" %t531)
  br label %bb155
bb155:
  %t532 = load ptr, ptr %l9, !tbaa !29
  %t534 = getelementptr %"compiler/free:Free", ptr %t532, i32 0, i32 103
  store ptr %t534, ptr %l283, !tbaa !29
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/free:walker", ptr %t535, i32 0, i32 81
  %t538 = load i1, ptr %t537, !tbaa !21
  br i1 %t538, label %bb156, label %bb157
bb156:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/free:walker", ptr %t540, i32 0, i32 82
  %t543 = load i1, ptr %t542, !tbaa !21
  %t545 = xor i1 %t543, true
  br i1 %t545, label %bb158, label %bb159
bb157:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb174
bb158:
  store i1 true, ptr %l290, !tbaa !21
  br label %bb173
bb159:
  %t547 = load i64, ptr %l1, !tbaa !24
  %t549 = icmp sge i64 %t547, 0
  br i1 %t549, label %bb160, label %bb161
bb160:
  %t551 = load i64, ptr %l5, !tbaa !24
  %t553 = icmp sge i64 %t551, 0
  store i1 %t553, ptr %l293, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb162
bb162:
  %t555 = load i1, ptr %l293, !tbaa !21
  br i1 %t555, label %bb163, label %bb164
bb163:
  %t556 = load ptr, ptr %l9, !tbaa !29
  %t558 = getelementptr %"compiler/free:Free", ptr %t556, i32 0, i32 76
  %t559 = load i64, ptr %l5, !tbaa !24
  %t562 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t558, i64 %t559)
  store ptr %t562, ptr %l300
  br label %bb165
bb164:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb167
bb165:
  %t563 = load i64, ptr %l1, !tbaa !24
  %t564 = load ptr, ptr %l300, !tbaa !29
  %t566 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t564, i64 %t563)
  store i1 %t566, ptr %l302
  br label %bb166
bb166:
  %t567 = load i1, ptr %l302, !tbaa !21
  %t568 = xor i1 %t567, true
  store i1 %t568, ptr %l296, !tbaa !21
  br label %bb167
bb167:
  %t570 = load i1, ptr %l296, !tbaa !21
  br i1 %t570, label %bb168, label %bb169
bb168:
  %t571 = load ptr, ptr %l9, !tbaa !29
  %t573 = getelementptr %"compiler/free:Free", ptr %t571, i32 0, i32 77
  %t574 = load i64, ptr %l5, !tbaa !24
  %t577 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t573, i64 %t574)
  store ptr %t577, ptr %l308
  br label %bb170
bb169:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb172
bb170:
  %t578 = load i64, ptr %l1, !tbaa !24
  %t579 = load ptr, ptr %l308, !tbaa !29
  %t581 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t579, i64 %t578)
  store i1 %t581, ptr %l310
  br label %bb171
bb171:
  %t582 = load i1, ptr %l310, !tbaa !21
  %t583 = xor i1 %t582, true
  store i1 %t583, ptr %l304, !tbaa !21
  br label %bb172
bb172:
  %t585 = load i1, ptr %l304, !tbaa !21
  store i1 %t585, ptr %l290, !tbaa !21
  br label %bb173
bb173:
  %t586 = load i1, ptr %l290, !tbaa !21
  store i1 %t586, ptr %l286, !tbaa !21
  br label %bb174
bb174:
  %t587 = load ptr, ptr %l283, !tbaa !29
  %t588 = load i1, ptr %l286, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t587, i1 %t588)
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoParts(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:leaf"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i1
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/free:leaf"
  %l32 = alloca %"compiler/free:leaf"
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l60 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i64
  %l101 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i64
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i64
  %l119 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t4, i64 %t5)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 15
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t21, i64 %t22)
  store i32 %t25, ptr %l21
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i32, ptr %l21, !tbaa !23
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReleaseLeaves(ptr %v0, ptr %s2, ptr %t26, i32 %t27, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l22
  br label %bb6
bb6:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t30 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %t30
  store ptr %t30, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l4, !tbaa !24
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %t33)
  store i64 %t35, ptr %l26
  br label %bb8
bb8:
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %s2, ptr %t42, i64 %t43)
  store %"compiler/free:leaf" %t46, ptr %l31
  br label %bb12
bb12:
  %t47 = load %"compiler/free:leaf", ptr %l31
  store %"compiler/free:leaf" %t47, ptr %l32
  %t48 = call ptr @__olang_scope_hold(ptr %s3)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l33, !tbaa !24
  %t50 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = call ptr @__olang_region_make_part(ptr %s3)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t54 = getelementptr %"compiler/free:leaf", ptr %l32, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l36, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = mul i64 %t58, 8
  %t60 = load i64, ptr %l33
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = call ptr @__olang_held_alloc(ptr %t61, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l37, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = mul i64 %t69, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t72 = getelementptr %"compiler/free:leaf", ptr %l32, i32 0, i32 0
  store { i64, ptr } %t71, ptr %t72, !tbaa !27
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = getelementptr %"compiler/free:leaf", ptr %l32, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  %t79 = icmp eq i64 %t77, 0
  br i1 %t79, label %bb17, label %bb18
bb16:
  %t81 = load %"compiler/free:leaf", ptr %l32
  store %"compiler/free:leaf" %t81, ptr %l5
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l41, !tbaa !29
  %t83 = getelementptr %"compiler/free:leaf", ptr %l5, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l42, !tbaa !24
  %t85 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  store i64 %t85, ptr %l43, !tbaa !24
  %t86 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t86, ptr %l44
  %t87 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t87, ptr %l45
  br label %bb19
bb17:
  %t88 = getelementptr %"compiler/free:leaf", ptr %l32, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t88, !tbaa !27
  br label %bb18
bb18:
  %t89 = getelementptr %"compiler/free:leaf", ptr %l32, i32 0, i32 0
  %t90 = load i64, ptr %l33
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = load { i64, ptr }, ptr %t89
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = icmp ne ptr %t94, null
  %t96 = select i1 %t95, ptr %t94, ptr null
  call void @__olang_region_settle_in(ptr %t91, ptr %t96)
  br label %bb16
bb19:
  %t97 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t98 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t99 = load ptr, ptr %l41, !tbaa !29
  %t100 = load i64, ptr %l42, !tbaa !24
  %t101 = load i64, ptr %l43, !tbaa !24
  %t102 = load %"compiler/source:Span", ptr %l44
  %t103 = load %"compiler/source:Span", ptr %l45
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t99, i64 %t100, i64 %t101, %"compiler/source:Span" %t102, %"compiler/source:Span" %t103, i64 -1, i1 false, i64 %t97, i32 %t98)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %l4, !tbaa !24
  br label %bb7
bb22:
  call void @__olang_scope_close(ptr %s2)
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l52, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/free:walker", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/free:Free", ptr %t118, i32 0, i32 15
  %t121 = load i64, ptr %l1, !tbaa !24
  %t124 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t120, i64 %t121)
  store i32 %t124, ptr %l57
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l52, !tbaa !29
  %t126 = load i32, ptr %l57, !tbaa !23
  %t127 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t127, ptr %l58
  br label %bb24
bb24:
  %t128 = load i1, ptr %l58, !tbaa !21
  %t129 = xor i1 %t128, true
  br i1 %t129, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb30
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/free:walker", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l62, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/free:Free", ptr %t138, i32 0, i32 15
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t140, i64 %t141)
  store i32 %t144, ptr %l67
  br label %bb27
bb27:
  %t145 = load ptr, ptr %l62, !tbaa !29
  %t146 = load i32, ptr %l67, !tbaa !23
  %t147 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eVecWalks(ptr %v0, ptr %s0, ptr %t145, i32 %t146)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l68
  br label %bb28
bb28:
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2eLen_3ccompiler_2ffree_3aVecWalk_3e(ptr %s0, ptr %l68)
  store i64 %t149, ptr %l70
  br label %bb29
bb29:
  %t150 = load i64, ptr %l70, !tbaa !24
  %t151 = icmp eq i64 %t150, 0
  store i1 %t151, ptr %l60, !tbaa !21
  br label %bb30
bb30:
  %t153 = load i1, ptr %l60, !tbaa !21
  br i1 %t153, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/free:walker", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  store ptr %t157, ptr %l73, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/free:walker", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/free:Free", ptr %t161, i32 0, i32 15
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t163, i64 %t164)
  store i32 %t167, ptr %l78
  br label %bb34
bb34:
  %t168 = load ptr, ptr %l73, !tbaa !29
  %t169 = load i32, ptr %l78, !tbaa !23
  %t170 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReleaseLeaves(ptr %v0, ptr %s0, ptr %t168, i32 %t169, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l79
  br label %bb35
bb35:
  %t171 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %l6
  store %olang.scope zeroinitializer, ptr %s6
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/free:walker", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  store ptr %t175, ptr %l81, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/free:walker", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/free:Free", ptr %t179, i32 0, i32 15
  %t182 = load i64, ptr %l1, !tbaa !24
  %t185 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t181, i64 %t182)
  store i32 %t185, ptr %l86
  br label %bb36
bb36:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load i32, ptr %l86, !tbaa !23
  %t188 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsLet(ptr %v0, ptr %s6, ptr %t186, i32 %t187, i64 0, i1 false)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l87
  br label %bb37
bb37:
  %t189 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  %t190 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %t190
  store ptr %t190, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb38
bb38:
  %t192 = load i64, ptr %l8, !tbaa !24
  store i64 %t192, ptr %l89, !tbaa !24
  %t193 = load ptr, ptr %l7, !tbaa !29
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s6, ptr %t193)
  store i64 %t195, ptr %l91
  br label %bb39
bb39:
  %t196 = load i64, ptr %l89, !tbaa !24
  %t197 = load i64, ptr %l91, !tbaa !24
  %t198 = icmp slt i64 %t196, %t197
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb40, label %bb41
bb40:
  br label %bb56
bb41:
  br label %bb42
bb42:
  %t202 = load ptr, ptr %l7, !tbaa !29
  %t203 = load i64, ptr %l8, !tbaa !24
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s6, ptr %t202, i64 %t203)
  store i64 %t206, ptr %l96
  br label %bb43
bb43:
  %t207 = load i64, ptr %l96, !tbaa !24
  store i64 %t207, ptr %l9, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:walker", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t212 = load i64, ptr %l9, !tbaa !24
  %t216 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleafOf(ptr %v0, ptr %s0, ptr %t211, ptr %l6, i64 %t212)
  store i1 %t216, ptr %l101
  br label %bb44
bb44:
  %t217 = load i1, ptr %l101, !tbaa !21
  %t218 = xor i1 %t217, true
  br i1 %t218, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l103, !tbaa !29
  %t221 = load i64, ptr %l9, !tbaa !24
  store i64 %t221, ptr %l104, !tbaa !24
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/free:walker", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t226 = load i64, ptr %l9, !tbaa !24
  %t229 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t225, i64 %t226)
  store i1 %t229, ptr %l108
  br label %bb47
bb46:
  br label %bb54
bb47:
  %t230 = load i1, ptr %l108, !tbaa !21
  br i1 %t230, label %bb48, label %bb49
bb48:
  %t231 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  store i64 %t231, ptr %l109, !tbaa !24
  br label %bb50
bb49:
  %t233 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t233, ptr %l109, !tbaa !24
  br label %bb50
bb50:
  %t235 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t235, ptr %l112
  %t236 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t236, ptr %l113
  br label %bb51
bb51:
  %t237 = load i64, ptr @G_2ecompiler_2ffree_2eWalkIn, !tbaa !24
  store i64 %t237, ptr %l114, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/free:walker", ptr %t238, i32 0, i32 0
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 15
  %t244 = load i64, ptr %l1, !tbaa !24
  %t247 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t243, i64 %t244)
  store i32 %t247, ptr %l119
  br label %bb52
bb52:
  %t248 = load ptr, ptr %l103, !tbaa !29
  %t249 = load i64, ptr %l104, !tbaa !24
  %t250 = load i64, ptr %l109, !tbaa !24
  %t251 = load %"compiler/source:Span", ptr %l112
  %t252 = load %"compiler/source:Span", ptr %l113
  %t253 = load i64, ptr %l114, !tbaa !24
  %t254 = load i32, ptr %l119, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t248, i64 %t249, i64 %t250, %"compiler/source:Span" %t251, %"compiler/source:Span" %t252, i64 -1, i1 true, i64 %t253, i32 %t254)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t255 = load i64, ptr %l8, !tbaa !24
  %t258 = add i64 %t255, 1
  store i64 %t258, ptr %l8, !tbaa !24
  br label %bb38
bb56:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eletCtorOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l16 = alloca i1
  %l19 = alloca i64
  %l24 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca i1
  %l38 = alloca ptr
  %l42 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i64
  %l54 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l83 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 4
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb6
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l19
  br label %bb5
bb5:
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v2, ptr %t29)
  store ptr %t32, ptr %l24
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l24, !tbaa !29
  store ptr %t33, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb11, label %bb12
bb11:
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l4, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t44)
  store i64 %t46, ptr %l31
  br label %bb14
bb14:
  %t47 = load i64, ptr %l31, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t48, 0
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/free:Free", ptr %t52, i32 0, i32 1
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l38
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l38, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 11
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  store i1 %t64, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb24
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t67)
  store ptr %t69, ptr %l44
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 1
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l48
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t81, i32 %t80)
  store i64 %t83, ptr %l51
  br label %bb23
bb23:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t85 = load i64, ptr %l51, !tbaa !24
  %t87 = icmp ne i64 %t85, %t84
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb30
bb26:
  %t90 = load ptr, ptr %l4, !tbaa !29
  store ptr %t90, ptr %l55, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t91)
  store i32 %t93, ptr %l57
  br label %bb27
bb27:
  %t94 = load ptr, ptr %l55, !tbaa !29
  %t95 = load i32, ptr %l57, !tbaa !23
  %t96 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t94, i32 %t95)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l58
  br label %bb28
bb28:
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l58)
  store i64 %t98, ptr %l60
  br label %bb29
bb29:
  %t99 = load i64, ptr %l60, !tbaa !24
  %t100 = icmp eq i64 %t99, 0
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb30
bb30:
  %t102 = load i1, ptr %l54, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  store ptr null, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t104, i64 %t105)
  store i64 %t108, ptr %l65
  br label %bb34
bb34:
  %t109 = load i64, ptr %l65, !tbaa !24
  store i64 %t109, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb37
bb36:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t118 = and i64 %t114, %t115
  %t120 = icmp ne i64 %t118, 0
  store i1 %t120, ptr %l68, !tbaa !21
  br label %bb37
bb37:
  %t122 = load i1, ptr %l68, !tbaa !21
  br i1 %t122, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb41
bb39:
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t124 = load i64, ptr %l6, !tbaa !24
  %t127 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v2, ptr %t123, i64 %t124)
  store i1 %t127, ptr %l76
  br label %bb40
bb40:
  %t128 = load i1, ptr %l76, !tbaa !21
  store i1 %t128, ptr %l73, !tbaa !21
  br label %bb41
bb41:
  %t129 = load i1, ptr %l73, !tbaa !21
  br i1 %t129, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb45
bb43:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t132 = load i64, ptr %l5, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  %t141 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efreshCtor(ptr %v0, ptr %v2, ptr %t130, ptr %t131, i64 %t132, i64 %t136)
  store i1 %t141, ptr %l83
  br label %bb44
bb44:
  %t142 = load i1, ptr %l83, !tbaa !21
  store i1 %t142, ptr %l77, !tbaa !21
  br label %bb45
bb45:
  %t143 = load i1, ptr %l77, !tbaa !21
  br i1 %t143, label %bb46, label %bb47
bb46:
  store ptr null, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t145 = load ptr, ptr %l3, !tbaa !29
  store ptr %t145, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedGaps(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l38 = alloca %"compiler/typed:Local"
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l19, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:walker", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i32, ptr %l2, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t39 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEndsLocal(ptr %v0, ptr %t28, i64 %t32, i64 %t35)
  store i1 %t39, ptr %l28
  br label %bb6
bb6:
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l31, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t45)
  store ptr %t47, ptr %l33
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 7
  %t51 = load i32, ptr %l2, !tbaa !23
  %t53 = sext i32 %t51 to i64
  %t56 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t50, i64 %t53)
  store %"compiler/typed:Local" %t56, ptr %l38
  br label %bb10
bb10:
  %t57 = getelementptr %"compiler/typed:Local", ptr %l38, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t61 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t59, i32 %t58)
  store i1 %t61, ptr %l40
  br label %bb11
bb11:
  %t62 = load i1, ptr %l40, !tbaa !21
  store i1 %t62, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l19, !tbaa !29
  %t64 = load ptr, ptr %l21, !tbaa !29
  %t65 = load i1, ptr %l29, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i1 %t65)
  br label %bb13
bb13:
  br label %bb68
bb14:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 17}
  %t73 = icmp eq i64 %t71, 2
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t81, ptr %t82, i1 true)
  br label %bb20
bb20:
  br label %bb68
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPlace(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  br label %bb27
bb27:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l60, !tbaa !29
  %t112 = load ptr, ptr %l6, !tbaa !29
  store ptr %t112, ptr %l62, !tbaa !29
  %t114 = load ptr, ptr %l5, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 8}
  %t121 = icmp eq i64 %t119, 0
  store i1 %t121, ptr %l64, !tbaa !21
  br label %bb29
bb29:
  %t122 = load i1, ptr %l64, !tbaa !21
  %t123 = xor i1 %t122, true
  %t124 = load ptr, ptr %l60, !tbaa !29
  %t125 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i1 %t123)
  br label %bb30
bb30:
  br label %bb68
bb31:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb32, label %bb33
bb32:
  %t131 = load ptr, ptr %l68, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 17}
  %t134 = icmp eq i64 %t132, 6
  store i1 %t134, ptr %l69, !tbaa !21
  br label %bb33
bb33:
  %t135 = load i1, ptr %l69, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [3 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr }, ptr %t138, i32 0, i32 1
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l7, !tbaa !29
  br label %bb40
bb35:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t143 = load ptr, ptr %l74, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb36, label %bb37
bb36:
  %t146 = load ptr, ptr %l74, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 17}
  %t149 = icmp eq i64 %t147, 16
  store i1 %t149, ptr %l75, !tbaa !21
  br label %bb37
bb37:
  %t150 = load i1, ptr %l75, !tbaa !21
  br i1 %t150, label %bb38, label %bb39
bb38:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [3 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t157, ptr %t158, i1 true)
  br label %bb41
bb41:
  br label %bb68
bb42:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb43, label %bb44
bb43:
  %t165 = load ptr, ptr %l82, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 17}
  %t168 = icmp eq i64 %t166, 3
  store i1 %t168, ptr %l83, !tbaa !21
  br label %bb44
bb44:
  %t169 = load i1, ptr %l83, !tbaa !21
  br i1 %t169, label %bb45, label %bb46
bb45:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  %t179 = getelementptr %"compiler/typed:If", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t176, ptr %t180, i1 false)
  br label %bb48
bb48:
  br label %bb68
bb49:
  %t184 = load ptr, ptr %l1, !tbaa !29
  store ptr %t184, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t185 = load ptr, ptr %l92, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb50, label %bb51
bb50:
  %t188 = load ptr, ptr %l92, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 17}
  %t191 = icmp eq i64 %t189, 10
  store i1 %t191, ptr %l93, !tbaa !21
  br label %bb51
bb51:
  %t192 = load i1, ptr %l93, !tbaa !21
  br i1 %t192, label %bb52, label %bb53
bb52:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t195, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t199, ptr %t200, i1 false)
  br label %bb55
bb55:
  br label %bb68
bb56:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t205 = load ptr, ptr %l101, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb57, label %bb58
bb57:
  %t208 = load ptr, ptr %l101, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 17}
  %t211 = icmp eq i64 %t209, 15
  store i1 %t211, ptr %l102, !tbaa !21
  br label %bb58
bb58:
  %t212 = load i1, ptr %l102, !tbaa !21
  br i1 %t212, label %bb59, label %bb60
bb59:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", ptr }, ptr %t215, i32 0, i32 1
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %t219, ptr %t220, i1 false)
  br label %bb62
bb62:
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_9256ac4faaa6057c_c06f1d5f88305ed0)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteReach(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca i1
  %l28 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca i1
  %l53 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca i64
  %l75 = alloca ptr
  %l77 = alloca i64
  %l79 = alloca %"compiler/source:Span"
  %l83 = alloca ptr
  %l84 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca %"compiler/source:Span"
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load i32, ptr %l17, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  store i1 %t15, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l21, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/free:walker", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l28
  br label %bb8
bb8:
  %t26 = load i64, ptr %l28, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp ne i64 %t27, -2
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 94
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 15
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t33, i64 %t37)
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 95
  store ptr %t42, ptr %l36, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t43)
  store %"compiler/source:Span" %t45, ptr %l38
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/free:walker", ptr %t48, i32 0, i32 96
  %t51 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t50, i64 %t51)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t55 = load ptr, ptr %l42, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l42, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 9
  store i1 %t61, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l43, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t65, i32 0, i32 2
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 54}
  store i32 %t67, ptr %l4
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t71, i32 0, i32 4
  %t73 = load { i64, ptr }, ptr %t72
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  br label %bb38
bb20:
  %t75 = load i32, ptr %l4, !range !{i32 0, i32 54}
  %t77 = trunc i64 44 to i32
  %t78 = icmp eq i32 %t75, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i32, ptr %l4, !range !{i32 0, i32 54}
  %t84 = trunc i64 45 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t89 = load i1, ptr %l53, !tbaa !21
  br i1 %t89, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t104, ptr %l64, !tbaa !27
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  store ptr %t110, ptr %l9, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/free:walker", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  store ptr %t115, ptr %l68, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  store ptr %t119, ptr %l70, !tbaa !29
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t120)
  store i32 %t122, ptr %l72
  br label %bb31
bb31:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t124 = load i32, ptr %l72, !tbaa !23
  %t125 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t123, i32 %t124)
  store i64 %t125, ptr %l73
  br label %bb32
bb32:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t126)
  store ptr %t128, ptr %l75
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 3
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l77, !tbaa !24
  %t133 = load ptr, ptr %l9, !tbaa !29
  %t135 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t133)
  store %"compiler/source:Span" %t135, ptr %l79
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l68, !tbaa !29
  %t137 = load i64, ptr %l73, !tbaa !24
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = load %"compiler/source:Span", ptr %l79
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %s6, ptr %t136, i64 %t137, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d30, i32 0, i32 1) }, i64 %t138, %"compiler/source:Span" %t139)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l7, !tbaa !24
  br label %bb27
bb37:
  br label %bb65
bb38:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t146 = load ptr, ptr %l83, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb39, label %bb40
bb39:
  %t149 = load ptr, ptr %l83, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 6
  store i1 %t152, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t153 = load i1, ptr %l84, !tbaa !21
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l10, !tbaa !29
  br label %bb43
bb42:
  br label %bb60
bb43:
  %t160 = load ptr, ptr %l10, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Call", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  store ptr %t163, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t164 = load ptr, ptr %l90, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb44, label %bb45
bb44:
  %t167 = load ptr, ptr %l90, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 5}
  %t170 = icmp eq i64 %t168, 1
  store i1 %t170, ptr %l91, !tbaa !21
  br label %bb45
bb45:
  %t171 = load i1, ptr %l91, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb46, label %bb47
bb46:
  br label %ret
bb47:
  br label %bb48
bb48:
  %t174 = load ptr, ptr %l10, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Call", ptr %t174, i32 0, i32 0
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { i64 }, ptr %t179, i32 0, i32 0
  %t181 = load i64, ptr %t180
  store i64 %t181, ptr %l11, !tbaa !24
  %t183 = load ptr, ptr %l10, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Call", ptr %t183, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t188, 0
  store i64 %t190, ptr %l14, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t192 = load i64, ptr %l13, !tbaa !24
  %t193 = load i64, ptr %l14, !tbaa !24
  %t196 = icmp slt i64 %t192, %t193
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb59
bb51:
  br label %bb52
bb52:
  %t200 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t200, ptr %l106, !tbaa !27
  %t201 = load i64, ptr %l13, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  store ptr %t206, ptr %l15, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:walker", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  store ptr %t211, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/free:walker", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  store ptr %t215, ptr %l112, !tbaa !29
  %t216 = load ptr, ptr %l15, !tbaa !29
  %t218 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t216)
  store i32 %t218, ptr %l114
  br label %bb53
bb53:
  %t219 = load ptr, ptr %l112, !tbaa !29
  %t220 = load i32, ptr %l114, !tbaa !23
  %t221 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t219, i32 %t220)
  store i64 %t221, ptr %l115
  br label %bb54
bb54:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t222)
  store ptr %t224, ptr %l117
  br label %bb55
bb55:
  %t225 = load ptr, ptr %l117, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 3
  %t228 = load i64, ptr %t227, !tbaa !24
  store i64 %t228, ptr %l119, !tbaa !24
  %t229 = load ptr, ptr %l15, !tbaa !29
  %t231 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t229)
  store %"compiler/source:Span" %t231, ptr %l121
  br label %bb56
bb56:
  %t232 = load ptr, ptr %l110, !tbaa !29
  %t233 = load i64, ptr %l115, !tbaa !24
  %t234 = load i64, ptr %l119, !tbaa !24
  %t235 = load %"compiler/source:Span", ptr %l121
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %s11, ptr %t232, i64 %t233, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d31, i32 0, i32 1) }, i64 %t234, %"compiler/source:Span" %t235)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t236 = load i64, ptr %l13, !tbaa !24
  %t239 = add i64 %t236, 1
  store i64 %t239, ptr %l13, !tbaa !24
  br label %bb49
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_3fe28685437e06db_e899c2573511637)
  unreachable
bb65:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eplainFillOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca %"compiler/typed:Local"
  %l12 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i64
  %l22 = alloca i1
  %l25 = alloca i64
  %l30 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 4
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:walker", ptr %t19, i32 0, i32 10
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l20
  br label %bb9
bb9:
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t51 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblockFillOf(ptr %v0, ptr %v1, ptr %t47, ptr %a2)
  store i64 %t51, ptr %l30
  br label %bb18
bb18:
  %t52 = load i64, ptr %l30, !tbaa !24
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l25 = alloca ptr
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp eq i64 %t28, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 69
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t34, i64 %t38)
  store ptr %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t45 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t43, i64 %t42)
  store i64 %t45, ptr %l27
  br label %bb12
bb12:
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 95
  store i1 true, ptr %t51, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l4, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eretCtorOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l21 = alloca ptr
  %l28 = alloca i64
  %l31 = alloca i1
  %l35 = alloca ptr
  %l39 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i64
  %l51 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l80 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store ptr null, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", ptr }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l3
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t28 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v3, ptr %t25)
  store ptr %t28, ptr %l21
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l21, !tbaa !29
  store ptr %t29, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l6, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v3, ptr %t40)
  store i64 %t42, ptr %l28
  br label %bb10
bb10:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb14
bb12:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 1
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  store ptr %t54, ptr %l35
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 11
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t62 = load i1, ptr %l31, !tbaa !21
  br i1 %t62, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb20
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l41
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/free:Free", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l45
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l45, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t77, i32 %t76)
  store i64 %t79, ptr %l48
  br label %bb19
bb19:
  %t80 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t81 = load i64, ptr %l48, !tbaa !24
  %t83 = icmp ne i64 %t81, %t80
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l39, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb26
bb22:
  %t86 = load ptr, ptr %l6, !tbaa !29
  store ptr %t86, ptr %l52, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t87)
  store i32 %t89, ptr %l54
  br label %bb23
bb23:
  %t90 = load ptr, ptr %l52, !tbaa !29
  %t91 = load i32, ptr %l54, !tbaa !23
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t90, i32 %t91)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l55
  br label %bb24
bb24:
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l55)
  store i64 %t94, ptr %l57
  br label %bb25
bb25:
  %t95 = load i64, ptr %l57, !tbaa !24
  %t96 = icmp eq i64 %t95, 0
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l51, !tbaa !21
  br i1 %t98, label %bb27, label %bb28
bb27:
  store ptr null, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l62
  br label %bb30
bb30:
  %t105 = load i64, ptr %l62, !tbaa !24
  store i64 %t105, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = icmp eq i64 %t106, 0
  br i1 %t108, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb33
bb32:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t114 = and i64 %t110, %t111
  %t116 = icmp ne i64 %t114, 0
  store i1 %t116, ptr %l65, !tbaa !21
  br label %bb33
bb33:
  %t118 = load i1, ptr %l65, !tbaa !21
  br i1 %t118, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb37
bb35:
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v3, ptr %t119, i64 %t120)
  store i1 %t123, ptr %l73
  br label %bb36
bb36:
  %t124 = load i1, ptr %l73, !tbaa !21
  store i1 %t124, ptr %l70, !tbaa !21
  br label %bb37
bb37:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb39:
  %t126 = load ptr, ptr %l6, !tbaa !29
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t128 = load i64, ptr %l7, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t137 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efreshCtor(ptr %v0, ptr %v3, ptr %t126, ptr %t127, i64 %t128, i64 %t132)
  store i1 %t137, ptr %l80
  br label %bb40
bb40:
  %t138 = load i1, ptr %l80, !tbaa !21
  store i1 %t138, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t139 = load i1, ptr %l74, !tbaa !21
  br i1 %t139, label %bb42, label %bb43
bb42:
  store ptr null, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t141 = load ptr, ptr %l5, !tbaa !29
  store ptr %t141, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereturnedOwnLocals(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = call i64 @compiler_2ffree_2eokind(i64 %t19)
  store i64 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t25 = icmp eq i64 %t23, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:walker", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = call i64 @compiler_2ffree_2eoval(i64 %t31)
  store i64 %t33, ptr %l23
  br label %bb10
bb9:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t36, ptr %l24
  br label %bb11
bb11:
  %t37 = load i1, ptr %l24, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = call i64 @compiler_2ffree_2eoval(i64 %t43)
  store i64 %t45, ptr %l28
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t47)
  store ptr %t49, ptr %l31
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %l28, !tbaa !24
  %t57 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t55, i64 %t56, i64 %t57, i64 %t53, %"compiler/source:Span" %a2, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t60, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb1
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2espawnLets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l52 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l68 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca i64
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l6, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l12, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_cee14a34e393ae19_ac6e569fdbf289b5)
  unreachable
bb11:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l7, !tbaa !24
  %t25 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l23
  br label %bb12
bb12:
  %t26 = load i64, ptr %l23, !tbaa !24
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load i64, ptr %l8, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l9, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v2, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l30
  br label %bb16
bb16:
  %t40 = load ptr, ptr %l28, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l30
  %t42 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s0, ptr %t40, %"compiler/source:Span" %t41)
  store { i64, ptr } %t42, ptr %l31
  br label %bb17
bb17:
  %t43 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t45 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t43, i64 %t44)
  %t53 = getelementptr i8, ptr %t52, i64 %t44
  call void @olang_textcopy(ptr %t53, ptr %t46, i64 %t47)
  %t54 = getelementptr i8, ptr %t53, i64 %t47
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t52, 1
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t57, ptr %lp10
  %t59 = load ptr, ptr %lp10
  store { i64, ptr } %t56, ptr %t59, !tbaa !27
  %t60 = load ptr, ptr %l9, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:walker", ptr %t61, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t69 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSpawnLets(ptr %v0, ptr %t60, i64 %t64, i64 %t65)
  store i1 %t69, ptr %l37
  br label %bb18
bb18:
  %t70 = load i1, ptr %l37, !tbaa !21
  store i1 %t70, ptr %l11, !tbaa !21
  %t71 = load i1, ptr %l11, !tbaa !21
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb28
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:walker", ptr %t75, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 36
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp eq i64 %t83, 0
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb24, label %bb25
bb24:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedAtWait(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t88, ptr %t89, ptr %t90, ptr %a5)
  store i1 %t96, ptr %l52
  br label %bb26
bb25:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb27
bb26:
  %t97 = load i1, ptr %l52, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb27
bb27:
  %t100 = load i1, ptr %l47, !tbaa !21
  store i1 %t100, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l40, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l9, !tbaa !29
  store ptr %t102, ptr %l54, !tbaa !29
  %t103 = load i64, ptr %l8, !tbaa !24
  store i64 %t103, ptr %l55, !tbaa !24
  %t104 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t104, ptr %l56, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t105)
  store ptr %t107, ptr %l58
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t108 = load ptr, ptr %l58, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 3
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v2, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l62
  br label %bb32
bb32:
  %t115 = load ptr, ptr %lp10
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = load ptr, ptr %l54, !tbaa !29
  %t118 = load i64, ptr %l55, !tbaa !24
  %t119 = load i64, ptr %l56, !tbaa !24
  %t120 = load i64, ptr %l60, !tbaa !24
  %t121 = load %"compiler/source:Span", ptr %l62
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t117, i64 %t118, i64 %t119, i64 %t120, %"compiler/source:Span" %t121, { i64, ptr } %t116)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v3, ptr %t123, i64 %t124, ptr %t125)
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l67, !tbaa !29
  %t130 = load i64, ptr %l8, !tbaa !24
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Spawn", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l70, !tbaa !29
  %t135 = load ptr, ptr %l4, !tbaa !29
  store ptr %t135, ptr %l71, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l72
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s0, ptr %t137, i64 %t138)
  store { i64, ptr } %t141, ptr %l75
  br label %bb36
bb36:
  %t142 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t143 = load ptr, ptr %l67, !tbaa !29
  %t144 = load i64, ptr %l68, !tbaa !24
  %t145 = load ptr, ptr %l70, !tbaa !29
  %t146 = load ptr, ptr %l71, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l72
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v3, ptr %s0, ptr %t143, i64 %t144, ptr %t145, ptr %t146, %"compiler/source:Span" %t147, { i64, ptr } %t142, i1 false)
  br label %bb37
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i1, ptr %l11, !tbaa !21
  %t153 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 80
  store i1 %t150, ptr %t153, !tbaa !21
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l79, !tbaa !29
  %t155 = load i64, ptr %l8, !tbaa !24
  store i64 %t155, ptr %l80, !tbaa !24
  %t156 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t156, ptr %l81, !tbaa !24
  %t157 = load ptr, ptr %l3, !tbaa !29
  %t159 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v2, ptr %t157)
  store %"compiler/source:Span" %t159, ptr %l83
  br label %bb38
bb38:
  %t160 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t160, ptr %l84
  br label %bb39
bb39:
  %t161 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t162 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t163 = load ptr, ptr %l79, !tbaa !29
  %t164 = load i64, ptr %l80, !tbaa !24
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = load %"compiler/source:Span", ptr %l83
  %t167 = load %"compiler/source:Span", ptr %l84
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t163, i64 %t164, i64 %t165, %"compiler/source:Span" %t166, %"compiler/source:Span" %t167, i64 -1, i1 false, i64 %t161, i32 %t162)
  br label %bb40
bb40:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l87, !tbaa !29
  %t171 = load i64, ptr %l8, !tbaa !24
  store i64 %t171, ptr %l88, !tbaa !24
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v2, ptr %t172)
  store %"compiler/source:Span" %t174, ptr %l90
  br label %bb41
bb41:
  %t175 = load ptr, ptr %l87, !tbaa !29
  %t176 = load i64, ptr %l88, !tbaa !24
  %t177 = load %"compiler/source:Span", ptr %l90
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoParts(ptr %v0, ptr %t175, i64 %t176, %"compiler/source:Span" %t177)
  br label %bb42
bb42:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:walker", ptr %t178, i32 0, i32 80
  store i1 false, ptr %t180, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/free:store"
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca %"compiler/free:leaf"
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i64
  %l84 = alloca ptr
  %l97 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l102 = alloca i1
  %l106 = alloca i1
  %l112 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l141 = alloca ptr
  %l143 = alloca i64
  %l145 = alloca %"compiler/source:Span"
  %l147 = alloca ptr
  %l152 = alloca %"compiler/typed:Local"
  %l156 = alloca i1
  %l159 = alloca i64
  %l161 = alloca i64
  %l171 = alloca i1
  %l181 = alloca i1
  %l184 = alloca i64
  %l187 = alloca i64
  %l195 = alloca i64
  %l200 = alloca i64
  %l201 = alloca i32
  %l204 = alloca i1
  %l206 = alloca i64
  %l208 = alloca i1
  %l214 = alloca i64
  %l216 = alloca i1
  %l218 = alloca ptr
  %l220 = alloca i32
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l223 = alloca i64
  %l225 = alloca i1
  %l230 = alloca i64
  %l236 = alloca i1
  %l238 = alloca ptr
  %l240 = alloca i64
  %l245 = alloca ptr
  %l264 = alloca ptr
  %l269 = alloca %"compiler/typed:Local"
  %l275 = alloca ptr
  %l280 = alloca i64
  %l281 = alloca ptr
  %l286 = alloca i64
  %l289 = alloca ptr
  %l292 = alloca i64
  %l293 = alloca ptr
  %l299 = alloca i64
  %l301 = alloca i64
  %l303 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l304 = alloca i64
  %l306 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l310 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l328 = alloca i64
  %l334 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l336 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l339 = alloca ptr
  %l341 = alloca ptr
  %l343 = alloca i32
  %l344 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l351 = alloca i1
  %l356 = alloca i1
  %l357 = alloca i64
  %l363 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l365 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l369 = alloca i64
  %l375 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l377 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l380 = alloca ptr
  %l382 = alloca ptr
  %l384 = alloca i32
  %l385 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l389 = alloca ptr
  %l391 = alloca i64
  %l392 = alloca ptr
  %l396 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l398 = alloca i64
  %l403 = alloca i64
  %l404 = alloca i32
  %l427 = alloca i64
  %l430 = alloca i1
  %l432 = alloca i1
  %l435 = alloca i1
  %l441 = alloca ptr
  %l442 = alloca i64
  %l444 = alloca i64
  %l446 = alloca ptr
  %l453 = alloca %"compiler/free:store"
  %l456 = alloca ptr
  %l457 = alloca i64
  %l458 = alloca ptr
  %l459 = alloca ptr
  %l460 = alloca %"compiler/source:Span"
  %l464 = alloca { i64, ptr }
  %l469 = alloca i64
  %l472 = alloca i1
  %l475 = alloca i1
  %l479 = alloca ptr
  %l484 = alloca %"compiler/free:feed"
  %l490 = alloca ptr
  %l494 = alloca i64
  %l496 = alloca %"compiler/free:store"
  %l504 = alloca ptr
  %l505 = alloca ptr
  %l509 = alloca i64
  %l510 = alloca ptr
  %l511 = alloca i1
  %l524 = alloca ptr
  %l525 = alloca i1
  %l535 = alloca ptr
  %l536 = alloca i1
  %l544 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l559 = alloca ptr
  %l579 = alloca ptr
  %l580 = alloca i1
  %l587 = alloca ptr
  %l598 = alloca ptr
  %l610 = alloca ptr
  %l611 = alloca i1
  %l616 = alloca ptr
  %l617 = alloca i1
  %l628 = alloca ptr
  %l648 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l658 = alloca i64
  %l664 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l666 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l669 = alloca ptr
  %l671 = alloca ptr
  %l673 = alloca i32
  %l674 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l675 = alloca ptr
  %l676 = alloca ptr
  %l677 = alloca ptr
  %l679 = alloca %"compiler/source:Span"
  %l681 = alloca ptr
  %l683 = alloca i32
  %l684 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l686 = alloca i64
  %l688 = alloca i64
  %l693 = alloca %"compiler/free:leaf"
  %l694 = alloca %"compiler/free:leaf"
  %l695 = alloca i64
  %l697 = alloca { i64, ptr }
  %l698 = alloca i64
  %l699 = alloca { i64, ptr }
  %l703 = alloca ptr
  %l706 = alloca i64
  %l707 = alloca i64
  %l718 = alloca i1
  %l724 = alloca i1
  %l725 = alloca ptr
  %l726 = alloca ptr
  %l728 = alloca %"compiler/source:Span"
  %l729 = alloca ptr
  %l730 = alloca i1
  %l735 = alloca ptr
  %l736 = alloca i64
  %l737 = alloca i64
  %l738 = alloca %"compiler/source:Span"
  %l739 = alloca %"compiler/source:Span"
  %l742 = alloca ptr
  %l743 = alloca i1
  %l752 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l758 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l759 = alloca ptr
  %l760 = alloca i1
  %l770 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l771 = alloca ptr
  %l772 = alloca i1
  %l779 = alloca ptr
  %l780 = alloca i1
  %l790 = alloca ptr
  %l799 = alloca i64
  %l802 = alloca i64
  %l803 = alloca i32
  %l804 = alloca ptr
  %l808 = alloca ptr
  %l809 = alloca i1
  %l821 = alloca i1
  %l831 = alloca ptr
  %l840 = alloca i1
  %l844 = alloca i64
  %l847 = alloca i64
  %l848 = alloca i32
  %l857 = alloca { i64, ptr }
  %l864 = alloca ptr
  %l873 = alloca ptr
  %l874 = alloca i1
  %l886 = alloca ptr
  %l888 = alloca ptr
  %l892 = alloca i1
  %l894 = alloca i64
  %l898 = alloca ptr
  %l900 = alloca i64
  %l901 = alloca i64
  %l904 = alloca ptr
  %l908 = alloca i64
  %l915 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l926 = alloca { i64, ptr }
  %l933 = alloca ptr
  %l939 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l951 = alloca { i64, ptr }
  %l957 = alloca ptr
  %l959 = alloca %"compiler/source:Span"
  %l969 = alloca i1
  %l973 = alloca i1
  %l978 = alloca i1
  %l982 = alloca ptr
  %l983 = alloca i1
  %l992 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l995 = alloca i64
  %l998 = alloca ptr
  %l1001 = alloca i64
  %l1003 = alloca ptr
  %l1005 = alloca i64
  %l1008 = alloca i64
  %l1011 = alloca ptr
  %l1014 = alloca i64
  %l1016 = alloca i64
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s66 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l84, !tbaa !29
  %t7 = load ptr, ptr %l84, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 14
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = add i64 %t9, 1
  %t14 = load ptr, ptr %l84, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 14
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 16
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  br label %bb1
bb1:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 15
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:walker", ptr %t27, i32 0, i32 65
  %t30 = load %"compiler/source:Span", ptr %t29
  store %"compiler/source:Span" %t30, ptr %l4
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 15
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l97, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l99
  br label %bb2
bb2:
  %t41 = load %"compiler/source:Span", ptr %l99
  %t42 = load ptr, ptr %l97, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t42, i32 0, i32 65
  store %"compiler/source:Span" %t41, ptr %t43
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:walker", ptr %t44, i32 0, i32 2
  %t47 = load i1, ptr %t46, !tbaa !21
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 36
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = icmp eq i64 %t52, 0
  store i1 %t54, ptr %l102, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb5
bb5:
  %t56 = load i1, ptr %l102, !tbaa !21
  br i1 %t56, label %bb6, label %bb7
bb6:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 30
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t62, i64 %t66)
  store i1 %t69, ptr %l112
  br label %bb8
bb7:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb9
bb8:
  %t70 = load i1, ptr %l112, !tbaa !21
  store i1 %t70, ptr %l106, !tbaa !21
  br label %bb9
bb9:
  %t71 = load i1, ptr %l106, !tbaa !21
  br i1 %t71, label %bb10, label %bb11
bb10:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedGaps(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t77 = load ptr, ptr %l115, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb14, label %bb15
bb14:
  %t80 = load ptr, ptr %l115, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 17}
  %t83 = icmp eq i64 %t81, 0
  store i1 %t83, ptr %l116, !tbaa !21
  br label %bb15
bb15:
  %t84 = load i1, ptr %l116, !tbaa !21
  br i1 %t84, label %bb16, label %bb17
bb16:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 0
  %t89 = load %"compiler/source:Span", ptr %t88
  store %"compiler/source:Span" %t89, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [3 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t93, i32 0, i32 1
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l6, !tbaa !23
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [3 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb210
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/free:walker", ptr %t103, i32 0, i32 18
  %t106 = load i32, ptr %l6, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 30
  %t112 = load i64, ptr %t111, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t105, i64 %t108, i64 %t112)
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 24
  %t119 = load i32, ptr %l6, !tbaa !23
  %t121 = sext i32 %t119 to i64
  %t122 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t118, i64 %t121, i64 %t122)
  br label %bb20
bb20:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 25
  %t129 = load i32, ptr %l6, !tbaa !23
  %t131 = sext i32 %t129 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t128, i64 %t131, i1 true)
  br label %bb21
bb21:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 26
  store ptr %t136, ptr %l141, !tbaa !29
  %t137 = load i32, ptr %l6, !tbaa !23
  %t139 = sext i32 %t137 to i64
  store i64 %t139, ptr %l143, !tbaa !24
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t140)
  store %"compiler/source:Span" %t142, ptr %l145
  br label %bb22
bb22:
  %t143 = load ptr, ptr %l141, !tbaa !29
  %t144 = load i64, ptr %l143, !tbaa !24
  %t145 = load %"compiler/source:Span", ptr %l145
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t143, i64 %t144, %"compiler/source:Span" %t145)
  br label %bb23
bb23:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t146)
  store ptr %t148, ptr %l147
  br label %bb24
bb24:
  %t149 = load ptr, ptr %l147, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Body", ptr %t149, i32 0, i32 7
  %t152 = load i32, ptr %l6, !tbaa !23
  %t154 = sext i32 %t152 to i64
  %t157 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t151, i64 %t154)
  store %"compiler/typed:Local" %t157, ptr %l152
  br label %bb25
bb25:
  %t158 = getelementptr %"compiler/typed:Local", ptr %l152, i32 0, i32 4
  %t159 = load i32, ptr %t158, !range !{i32 0, i32 7}
  store i32 %t159, ptr %l8
  %t161 = load i32, ptr %l8, !range !{i32 0, i32 7}
  %t163 = trunc i64 2 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb28
bb27:
  %t166 = load i32, ptr %l8, !range !{i32 0, i32 7}
  %t168 = trunc i64 3 to i32
  %t169 = icmp eq i32 %t166, %t168
  store i1 %t169, ptr %l156, !tbaa !21
  br label %bb28
bb28:
  %t171 = load i1, ptr %l156, !tbaa !21
  br i1 %t171, label %bb29, label %bb30
bb29:
  %t172 = load ptr, ptr %l7, !tbaa !29
  %t174 = call i64 @compiler_2ffree_2eownCopySite(ptr %v1, ptr %t172)
  store i64 %t174, ptr %l161
  br label %bb31
bb30:
  store i64 -1, ptr %l159, !tbaa !24
  br label %bb32
bb31:
  %t175 = load i64, ptr %l161, !tbaa !24
  store i64 %t175, ptr %l159, !tbaa !24
  br label %bb32
bb32:
  %t176 = load i64, ptr %l159, !tbaa !24
  store i64 %t176, ptr %l9, !tbaa !24
  %t177 = load i64, ptr %l9, !tbaa !24
  %t179 = icmp sge i64 %t177, 0
  br i1 %t179, label %bb33, label %bb34
bb33:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 44
  %t184 = load i32, ptr %l6, !tbaa !23
  %t186 = sext i32 %t184 to i64
  %t187 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t183, i64 %t186, ptr %t187)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t191 = load i64, ptr %l9, !tbaa !24
  %t193 = icmp slt i64 %t191, 0
  br i1 %t193, label %bb37, label %bb38
bb37:
  %t195 = load i32, ptr %l8, !range !{i32 0, i32 7}
  %t197 = trunc i64 2 to i32
  %t198 = icmp eq i32 %t195, %t197
  store i1 %t198, ptr %l171, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb39
bb39:
  %t200 = load i1, ptr %l171, !tbaa !21
  br i1 %t200, label %bb40, label %bb41
bb40:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 46
  %t204 = load i32, ptr %l6, !tbaa !23
  %t206 = sext i32 %t204 to i64
  %t207 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t203, i64 %t206, ptr %t207)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t211 = load i32, ptr %l8, !range !{i32 0, i32 7}
  %t213 = trunc i64 2 to i32
  %t214 = icmp eq i32 %t211, %t213
  br i1 %t214, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb46
bb45:
  %t216 = load i32, ptr %l8, !range !{i32 0, i32 7}
  %t218 = trunc i64 3 to i32
  %t219 = icmp eq i32 %t216, %t218
  store i1 %t219, ptr %l181, !tbaa !21
  br label %bb46
bb46:
  %t221 = load i1, ptr %l181, !tbaa !21
  br i1 %t221, label %bb47, label %bb48
bb47:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l7, !tbaa !29
  %t226 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t222, ptr %t223)
  store i64 %t226, ptr %l187
  br label %bb49
bb48:
  store i64 -1, ptr %l184, !tbaa !24
  br label %bb50
bb49:
  %t227 = load i64, ptr %l187, !tbaa !24
  store i64 %t227, ptr %l184, !tbaa !24
  br label %bb50
bb50:
  %t228 = load i64, ptr %l184, !tbaa !24
  store i64 %t228, ptr %l10, !tbaa !24
  %t229 = load i64, ptr %l10, !tbaa !24
  %t231 = icmp sge i64 %t229, 0
  br i1 %t231, label %bb51, label %bb52
bb51:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/free:walker", ptr %t233, i32 0, i32 63
  %t236 = load i32, ptr %l6, !tbaa !23
  %t238 = sext i32 %t236 to i64
  %t239 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t235, i64 %t238, i64 %t239)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/free:walker", ptr %t243, i32 0, i32 10
  %t246 = load i32, ptr %l6, !tbaa !23
  %t248 = sext i32 %t246 to i64
  %t251 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t245, i64 %t248)
  %t252 = extractvalue { i32, i64 } %t251, 1
  %t253 = extractvalue { i32, i64 } %t251, 0
  store i32 %t253, ptr %l201
  %t254 = icmp ne i32 %t253, 0
  br i1 %t254, label %bb56, label %ok.255, !prof !99
ok.255:
  store i64 %t252, ptr %l200
  br label %bb55
bb55:
  %t256 = load i64, ptr %l200, !tbaa !24
  store i64 %t256, ptr %l195, !tbaa !24
  br label %bb58
bb56:
  br label %bb57
bb57:
  store i64 -1, ptr %l195, !tbaa !24
  br label %bb58
bb58:
  %t257 = load i64, ptr %l195, !tbaa !24
  store i64 %t257, ptr %l11, !tbaa !24
  %t258 = load i64, ptr %l11, !tbaa !24
  %t260 = icmp sge i64 %t258, 0
  br i1 %t260, label %bb59, label %bb60
bb59:
  %t262 = load ptr, ptr %l7, !tbaa !29
  %t264 = call i64 @compiler_2ffree_2eownCopySite(ptr %v1, ptr %t262)
  store i64 %t264, ptr %l206
  br label %bb61
bb60:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb62
bb61:
  %t265 = load i64, ptr %l206, !tbaa !24
  %t266 = icmp sge i64 %t265, 0
  store i1 %t266, ptr %l204, !tbaa !21
  br label %bb62
bb62:
  %t268 = load i1, ptr %l204, !tbaa !21
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/free:walker", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:walker", ptr %t273, i32 0, i32 11
  %t276 = load i32, ptr %t275, !tbaa !23
  %t277 = load i64, ptr %l11, !tbaa !24
  %t281 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t272, i32 %t276, i64 %t277)
  store i64 %t281, ptr %l214
  br label %bb65
bb64:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb66
bb65:
  %t282 = load i64, ptr %l214, !tbaa !24
  %t283 = icmp slt i64 %t282, 0
  store i1 %t283, ptr %l208, !tbaa !21
  br label %bb66
bb66:
  %t285 = load i1, ptr %l208, !tbaa !21
  br i1 %t285, label %bb67, label %bb68
bb67:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/free:walker", ptr %t286, i32 0, i32 0
  %t289 = load ptr, ptr %t288, !tbaa !29
  store ptr %t289, ptr %l218, !tbaa !29
  %t290 = load ptr, ptr %l7, !tbaa !29
  %t292 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t290)
  store i32 %t292, ptr %l220
  br label %bb69
bb68:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb72
bb69:
  %t293 = load ptr, ptr %l218, !tbaa !29
  %t294 = load i32, ptr %l220, !tbaa !23
  %t295 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t293, i32 %t294)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t295, ptr %l221
  br label %bb70
bb70:
  %t297 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l221)
  store i64 %t297, ptr %l223
  br label %bb71
bb71:
  %t298 = load i64, ptr %l223, !tbaa !24
  %t299 = icmp sgt i64 %t298, 0
  store i1 %t299, ptr %l216, !tbaa !21
  br label %bb72
bb72:
  %t301 = load i1, ptr %l216, !tbaa !21
  br i1 %t301, label %bb73, label %bb74
bb73:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/free:walker", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:walker", ptr %t306, i32 0, i32 1
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t305, i64 %t309)
  store i64 %t312, ptr %l230
  br label %bb75
bb74:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb76
bb75:
  %t313 = load i64, ptr %l230, !tbaa !24
  %t314 = icmp eq i64 %t313, 0
  store i1 %t314, ptr %l225, !tbaa !21
  br label %bb76
bb76:
  %t316 = load i1, ptr %l225, !tbaa !21
  store i1 %t316, ptr %l12, !tbaa !21
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/free:walker", ptr %t317, i32 0, i32 47
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l13, !tbaa !24
  %t322 = load i64, ptr %l9, !tbaa !24
  %t324 = icmp sge i64 %t322, 0
  br i1 %t324, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l236, !tbaa !21
  br label %bb79
bb78:
  %t326 = load i1, ptr %l12, !tbaa !21
  store i1 %t326, ptr %l236, !tbaa !21
  br label %bb79
bb79:
  %t328 = load i1, ptr %l236, !tbaa !21
  br i1 %t328, label %bb80, label %bb81
bb80:
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l238, !tbaa !29
  %t330 = load ptr, ptr %l7, !tbaa !29
  %t332 = call i64 @compiler_2ffree_2eownCopySite(ptr %v1, ptr %t330)
  store i64 %t332, ptr %l240
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t333 = load i64, ptr %l240, !tbaa !24
  %t334 = load ptr, ptr %l238, !tbaa !29
  %t335 = getelementptr %"compiler/free:walker", ptr %t334, i32 0, i32 47
  store i64 %t333, ptr %t335, !tbaa !24
  br label %bb83
bb83:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l6, !tbaa !23
  %t339 = sext i32 %t337 to i64
  %t340 = load ptr, ptr %l7, !tbaa !29
  %t344 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eletCtorOf(ptr %v0, ptr %v1, ptr %v1, ptr %t336, i64 %t339, ptr %t340)
  store ptr %t344, ptr %l245
  br label %bb84
bb84:
  %t345 = load ptr, ptr %l245, !tbaa !29
  store ptr %t345, ptr %l14, !tbaa !29
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/free:walker", ptr %t346, i32 0, i32 40
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l15, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/free:walker", ptr %t351, i32 0, i32 43
  %t354 = load i64, ptr %t353, !tbaa !24
  store i64 %t354, ptr %l16, !tbaa !24
  %t356 = load ptr, ptr %l14, !tbaa !29
  %t358 = icmp eq ptr %t356, null
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb85, label %bb86
bb85:
  %t362 = load ptr, ptr %l14, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Call", ptr %t362, i32 0, i32 2
  %t365 = load i32, ptr %t364, !tbaa !23
  %t367 = sext i32 %t365 to i64
  %t369 = load ptr, ptr %l14, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Call", ptr %t369, i32 0, i32 2
  %t372 = load i32, ptr %t371, !tbaa !23
  %t374 = sext i32 %t372 to i64
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/free:walker", ptr %t376, i32 0, i32 40
  store i64 %t367, ptr %t380, !tbaa !24
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/free:walker", ptr %t381, i32 0, i32 43
  store i64 %t374, ptr %t385, !tbaa !24
  br label %bb87
bb86:
  br label %bb87
bb87:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t386)
  store ptr %t388, ptr %l264
  br label %bb88
bb88:
  %t389 = load ptr, ptr %l264, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Body", ptr %t389, i32 0, i32 7
  %t392 = load i32, ptr %l6, !tbaa !23
  %t394 = sext i32 %t392 to i64
  %t397 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t391, i64 %t394)
  store %"compiler/typed:Local" %t397, ptr %l269
  br label %bb89
bb89:
  %t398 = getelementptr %"compiler/typed:Local", ptr %l269, i32 0, i32 6
  %t399 = load i1, ptr %t398, !tbaa !21
  store i1 %t399, ptr %l19, !tbaa !21
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/free:walker", ptr %t401, i32 0, i32 60
  %t404 = load i64, ptr %t403, !tbaa !24
  store i64 %t404, ptr %l20, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/free:walker", ptr %t406, i32 0, i32 49
  %t409 = load i64, ptr %t408, !tbaa !24
  store i64 %t409, ptr %l21, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l275, !tbaa !29
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l6, !tbaa !23
  %t415 = sext i32 %t413 to i64
  %t416 = load ptr, ptr %l7, !tbaa !29
  %t420 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eplainFillOf(ptr %v0, ptr %v1, ptr %t412, i64 %t415, ptr %t416)
  store i64 %t420, ptr %l280
  br label %bb90
bb90:
  %t421 = load i64, ptr %l280, !tbaa !24
  %t422 = load ptr, ptr %l275, !tbaa !29
  %t423 = getelementptr %"compiler/free:walker", ptr %t422, i32 0, i32 60
  store i64 %t421, ptr %t423, !tbaa !24
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l281, !tbaa !29
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i32, ptr %l6, !tbaa !23
  %t428 = sext i32 %t426 to i64
  %t429 = load ptr, ptr %l7, !tbaa !29
  %t433 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esplitLetOf(ptr %v0, ptr %v1, ptr %t425, i64 %t428, ptr %t429)
  store i64 %t433, ptr %l286
  br label %bb91
bb91:
  %t434 = load i64, ptr %l286, !tbaa !24
  %t435 = load ptr, ptr %l281, !tbaa !29
  %t436 = getelementptr %"compiler/free:walker", ptr %t435, i32 0, i32 49
  store i64 %t434, ptr %t436, !tbaa !24
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/free:walker", ptr %t437, i32 0, i32 51
  %t440 = load i64, ptr %t439, !tbaa !24
  store i64 %t440, ptr %l22, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l289, !tbaa !29
  %t443 = load i64, ptr %l11, !tbaa !24
  %t445 = icmp sge i64 %t443, 0
  br i1 %t445, label %bb92, label %bb93
bb92:
  %t447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t447, ptr %l293, !tbaa !29
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/free:walker", ptr %t448, i32 0, i32 0
  %t451 = load ptr, ptr %t450, !tbaa !29
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/free:walker", ptr %t452, i32 0, i32 11
  %t455 = load i32, ptr %t454, !tbaa !23
  %t456 = load i64, ptr %l11, !tbaa !24
  %t460 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t451, i32 %t455, i64 %t456)
  store i64 %t460, ptr %l299
  br label %bb94
bb93:
  store i64 -1, ptr %l292, !tbaa !24
  br label %bb96
bb94:
  %t461 = load ptr, ptr %l7, !tbaa !29
  %t462 = load ptr, ptr %l293, !tbaa !29
  %t463 = load i64, ptr %l299, !tbaa !24
  %t465 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownerSplitOf(ptr %v0, ptr %v1, ptr %t462, i64 %t463, ptr %t461)
  store i64 %t465, ptr %l301
  br label %bb95
bb95:
  %t466 = load i64, ptr %l301, !tbaa !24
  store i64 %t466, ptr %l292, !tbaa !24
  br label %bb96
bb96:
  %t467 = load i64, ptr %l292, !tbaa !24
  %t468 = load ptr, ptr %l289, !tbaa !29
  %t469 = getelementptr %"compiler/free:walker", ptr %t468, i32 0, i32 51
  store i64 %t467, ptr %t469, !tbaa !24
  %t470 = load i1, ptr %l19, !tbaa !21
  br i1 %t470, label %bb97, label %bb98
bb97:
  %t472 = call ptr @__olang_scope_hold(ptr %s2)
  %t473 = ptrtoint ptr %t472 to i64
  store i64 %t473, ptr %l304, !tbaa !24
  %t474 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t474, label %bb99, label %bb100
bb98:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load ptr, ptr %l7, !tbaa !29
  %t480 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t476, ptr %t477)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t480, ptr %l310
  br label %bb104
bb99:
  %t481 = call ptr @__olang_region_make(ptr %s2)
  %t482 = ptrtoint ptr %t481 to i64
  store i64 %t482, ptr %l304, !tbaa !24
  br label %bb100
bb100:
  %t483 = load i64, ptr %l304
  %t484 = inttoptr i64 %t483 to ptr
  %t485 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t484, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t485, ptr %l306
  br label %bb101
bb101:
  %t486 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t486, label %bb102, label %bb103
bb102:
  %t488 = load i64, ptr %l304
  %t489 = inttoptr i64 %t488 to ptr
  %t490 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l306, i32 0, i32 0
  %t491 = load { i64, ptr }, ptr %t490
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = call ptr @__olang_region_or(ptr %t492, ptr null)
  %t494 = call ptr @__olang_region_home(ptr %t493)
  %t495 = icmp ne ptr %t494, null
  %t496 = select i1 %t495, ptr %t494, ptr null
  call void @__olang_region_settle_in(ptr %t489, ptr %t496)
  br label %bb103
bb103:
  %t497 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l306
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t497, ptr %l303
  br label %bb105
bb104:
  %t498 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l310
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %l303
  br label %bb105
bb105:
  %t499 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l303
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t499, ptr %l23
  %t500 = load i64, ptr %l20, !tbaa !24
  %t502 = load i64, ptr %l21, !tbaa !24
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/free:walker", ptr %t504, i32 0, i32 60
  store i64 %t500, ptr %t508, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/free:walker", ptr %t509, i32 0, i32 49
  store i64 %t502, ptr %t513, !tbaa !24
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i64, ptr %l13, !tbaa !24
  %t518 = getelementptr %"compiler/free:walker", ptr %t514, i32 0, i32 47
  store i64 %t515, ptr %t518, !tbaa !24
  %t519 = load i64, ptr %l15, !tbaa !24
  %t521 = load i64, ptr %l16, !tbaa !24
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/free:walker", ptr %t523, i32 0, i32 40
  store i64 %t519, ptr %t527, !tbaa !24
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t532 = getelementptr %"compiler/free:walker", ptr %t528, i32 0, i32 43
  store i64 %t521, ptr %t532, !tbaa !24
  %t533 = load ptr, ptr %l14, !tbaa !29
  %t535 = icmp eq ptr %t533, null
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s8
  %t539 = call ptr @__olang_scope_hold(ptr %s2)
  %t540 = ptrtoint ptr %t539 to i64
  store i64 %t540, ptr %l328, !tbaa !24
  %t541 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t541, label %bb108, label %bb109
bb107:
  br label %bb120
bb108:
  %t543 = call ptr @__olang_region_make(ptr %s2)
  %t544 = ptrtoint ptr %t543 to i64
  store i64 %t544, ptr %l328, !tbaa !24
  br label %bb109
bb109:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/free:walker", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t549 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t551 = load i64, ptr %l328
  %t552 = inttoptr i64 %t551 to ptr
  %t553 = call ptr @__olang_scope_alloc_a(ptr %t552, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t549, ptr %t553
  %t554 = load i64, ptr %l328
  %t555 = inttoptr i64 %t554 to ptr
  %t556 = load i64, ptr %l328
  %t557 = inttoptr i64 %t556 to ptr
  %t560 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t555, ptr %t557, ptr %t548, ptr %t553)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t560, ptr %l334
  br label %bb110
bb110:
  %t561 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t561, label %bb111, label %bb112
bb111:
  %t563 = load i64, ptr %l328
  %t564 = inttoptr i64 %t563 to ptr
  %t565 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l334, i32 0, i32 0
  %t566 = load { i64, ptr }, ptr %t565
  %t567 = extractvalue { i64, ptr } %t566, 1
  %t568 = call ptr @__olang_region_or(ptr %t567, ptr null)
  %t569 = call ptr @__olang_region_home(ptr %t568)
  %t570 = icmp ne ptr %t569, null
  %t571 = select i1 %t570, ptr %t569, ptr null
  call void @__olang_region_settle_in(ptr %t564, ptr %t571)
  br label %bb112
bb112:
  %t572 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t572, ptr %l336
  %t573 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l334
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t573, ptr %l23
  %t574 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t574, label %bb113, label %bb114
bb113:
  %t576 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l336, i32 0, i32 0
  %t577 = load { i64, ptr }, ptr %t576
  %t578 = extractvalue { i64, ptr } %t577, 1
  %t579 = call ptr @__olang_region_or(ptr %t578, ptr null)
  %t580 = call ptr @__olang_region_home(ptr %t579)
  %t581 = icmp ne ptr %t580, null
  %t582 = select i1 %t581, ptr %t580, ptr null
  call void @__olang_region_drop(ptr %t582)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l336
  br label %bb114
bb114:
  %t583 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t583, label %bb115, label %bb116
bb115:
  %t585 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l336, i32 0, i32 0
  %t586 = load { i64, ptr }, ptr %t585
  %t587 = extractvalue { i64, ptr } %t586, 0
  %t588 = extractvalue { i64, ptr } %t586, 1
  call void @__olang_region_release_part(ptr %t588, i64 %t587)
  store { i64, ptr } zeroinitializer, ptr %t585
  br label %bb116
bb116:
  %t589 = load ptr, ptr %l0, !tbaa !29
  store ptr %t589, ptr %l339, !tbaa !29
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/free:walker", ptr %t590, i32 0, i32 0
  %t593 = load ptr, ptr %t592, !tbaa !29
  store ptr %t593, ptr %l341, !tbaa !29
  %t594 = load ptr, ptr %l7, !tbaa !29
  %t596 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t594)
  store i32 %t596, ptr %l343
  br label %bb117
bb117:
  %t597 = load ptr, ptr %l341, !tbaa !29
  %t598 = load i32, ptr %l343, !tbaa !23
  %t599 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t597, i32 %t598)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t599, ptr %l344
  br label %bb118
bb118:
  %t600 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l344
  %t601 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t600, ptr %t601
  %t602 = load ptr, ptr %l14, !tbaa !29
  %t603 = load ptr, ptr %l7, !tbaa !29
  %t604 = load %"compiler/source:Span", ptr %l5
  %t605 = load ptr, ptr %l339, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t605, ptr %t601, ptr %t602, ptr %t603, %"compiler/source:Span" %t604)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s8)
  br label %bb120
bb120:
  %t610 = load ptr, ptr %l14, !tbaa !29
  %t612 = icmp eq ptr %t610, null
  br i1 %t612, label %bb121, label %bb122
bb121:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l6, !tbaa !23
  %t617 = sext i32 %t615 to i64
  %t618 = load ptr, ptr %l7, !tbaa !29
  %t622 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopiedView(ptr %v0, ptr %v1, ptr %t614, i64 %t617, ptr %t618)
  store i1 %t622, ptr %l356
  br label %bb123
bb122:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb124
bb123:
  %t623 = load i1, ptr %l356, !tbaa !21
  store i1 %t623, ptr %l351, !tbaa !21
  br label %bb124
bb124:
  %t624 = load i1, ptr %l351, !tbaa !21
  br i1 %t624, label %bb125, label %bb126
bb125:
  %t625 = call ptr @__olang_scope_hold(ptr %s2)
  %t626 = ptrtoint ptr %t625 to i64
  store i64 %t626, ptr %l357, !tbaa !24
  %t627 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t627, label %bb127, label %bb128
bb126:
  br label %bb136
bb127:
  %t629 = call ptr @__olang_region_make(ptr %s2)
  %t630 = ptrtoint ptr %t629 to i64
  store i64 %t630, ptr %l357, !tbaa !24
  br label %bb128
bb128:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/free:walker", ptr %t631, i32 0, i32 0
  %t634 = load ptr, ptr %t633, !tbaa !29
  %t635 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t637 = load i64, ptr %l357
  %t638 = inttoptr i64 %t637 to ptr
  %t639 = call ptr @__olang_scope_alloc_a(ptr %t638, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t635, ptr %t639
  %t640 = load i64, ptr %l357
  %t641 = inttoptr i64 %t640 to ptr
  %t642 = load i64, ptr %l357
  %t643 = inttoptr i64 %t642 to ptr
  %t646 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t641, ptr %t643, ptr %t634, ptr %t639)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t646, ptr %l363
  br label %bb129
bb129:
  %t647 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t647, label %bb130, label %bb131
bb130:
  %t649 = load i64, ptr %l357
  %t650 = inttoptr i64 %t649 to ptr
  %t651 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l363, i32 0, i32 0
  %t652 = load { i64, ptr }, ptr %t651
  %t653 = extractvalue { i64, ptr } %t652, 1
  %t654 = call ptr @__olang_region_or(ptr %t653, ptr null)
  %t655 = call ptr @__olang_region_home(ptr %t654)
  %t656 = icmp ne ptr %t655, null
  %t657 = select i1 %t656, ptr %t655, ptr null
  call void @__olang_region_settle_in(ptr %t650, ptr %t657)
  br label %bb131
bb131:
  %t658 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t658, ptr %l365
  %t659 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l363
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t659, ptr %l23
  %t660 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t660, label %bb132, label %bb133
bb132:
  %t662 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l365, i32 0, i32 0
  %t663 = load { i64, ptr }, ptr %t662
  %t664 = extractvalue { i64, ptr } %t663, 1
  %t665 = call ptr @__olang_region_or(ptr %t664, ptr null)
  %t666 = call ptr @__olang_region_home(ptr %t665)
  %t667 = icmp ne ptr %t666, null
  %t668 = select i1 %t667, ptr %t666, ptr null
  call void @__olang_region_drop(ptr %t668)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l365
  br label %bb133
bb133:
  %t669 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t669, label %bb134, label %bb135
bb134:
  %t671 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l365, i32 0, i32 0
  %t672 = load { i64, ptr }, ptr %t671
  %t673 = extractvalue { i64, ptr } %t672, 0
  %t674 = extractvalue { i64, ptr } %t672, 1
  call void @__olang_region_release_part(ptr %t674, i64 %t673)
  store { i64, ptr } zeroinitializer, ptr %t671
  br label %bb135
bb135:
  br label %bb136
bb136:
  %t675 = load i1, ptr %l12, !tbaa !21
  br i1 %t675, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s10
  %t677 = call ptr @__olang_scope_hold(ptr %s2)
  %t678 = ptrtoint ptr %t677 to i64
  store i64 %t678, ptr %l369, !tbaa !24
  %t679 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t679, label %bb139, label %bb140
bb138:
  br label %bb151
bb139:
  %t681 = call ptr @__olang_region_make(ptr %s2)
  %t682 = ptrtoint ptr %t681 to i64
  store i64 %t682, ptr %l369, !tbaa !24
  br label %bb140
bb140:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/free:walker", ptr %t683, i32 0, i32 0
  %t686 = load ptr, ptr %t685, !tbaa !29
  %t687 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t689 = load i64, ptr %l369
  %t690 = inttoptr i64 %t689 to ptr
  %t691 = call ptr @__olang_scope_alloc_a(ptr %t690, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t687, ptr %t691
  %t692 = load i64, ptr %l369
  %t693 = inttoptr i64 %t692 to ptr
  %t694 = load i64, ptr %l369
  %t695 = inttoptr i64 %t694 to ptr
  %t698 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t693, ptr %t695, ptr %t686, ptr %t691)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t698, ptr %l375
  br label %bb141
bb141:
  %t699 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t699, label %bb142, label %bb143
bb142:
  %t701 = load i64, ptr %l369
  %t702 = inttoptr i64 %t701 to ptr
  %t703 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l375, i32 0, i32 0
  %t704 = load { i64, ptr }, ptr %t703
  %t705 = extractvalue { i64, ptr } %t704, 1
  %t706 = call ptr @__olang_region_or(ptr %t705, ptr null)
  %t707 = call ptr @__olang_region_home(ptr %t706)
  %t708 = icmp ne ptr %t707, null
  %t709 = select i1 %t708, ptr %t707, ptr null
  call void @__olang_region_settle_in(ptr %t702, ptr %t709)
  br label %bb143
bb143:
  %t710 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t710, ptr %l377
  %t711 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l375
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t711, ptr %l23
  %t712 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23
  br i1 %t712, label %bb144, label %bb145
bb144:
  %t714 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l377, i32 0, i32 0
  %t715 = load { i64, ptr }, ptr %t714
  %t716 = extractvalue { i64, ptr } %t715, 1
  %t717 = call ptr @__olang_region_or(ptr %t716, ptr null)
  %t718 = call ptr @__olang_region_home(ptr %t717)
  %t719 = icmp ne ptr %t718, null
  %t720 = select i1 %t719, ptr %t718, ptr null
  call void @__olang_region_drop(ptr %t720)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l377
  br label %bb145
bb145:
  %t721 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t721, label %bb146, label %bb147
bb146:
  %t723 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l377, i32 0, i32 0
  %t724 = load { i64, ptr }, ptr %t723
  %t725 = extractvalue { i64, ptr } %t724, 0
  %t726 = extractvalue { i64, ptr } %t724, 1
  call void @__olang_region_release_part(ptr %t726, i64 %t725)
  store { i64, ptr } zeroinitializer, ptr %t723
  br label %bb147
bb147:
  %t727 = load ptr, ptr %l0, !tbaa !29
  store ptr %t727, ptr %l380, !tbaa !29
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = getelementptr %"compiler/free:walker", ptr %t728, i32 0, i32 0
  %t731 = load ptr, ptr %t730, !tbaa !29
  store ptr %t731, ptr %l382, !tbaa !29
  %t732 = load ptr, ptr %l7, !tbaa !29
  %t734 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t732)
  store i32 %t734, ptr %l384
  br label %bb148
bb148:
  %t735 = load ptr, ptr %l382, !tbaa !29
  %t736 = load i32, ptr %l384, !tbaa !23
  %t737 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t735, i32 %t736)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t737, ptr %l385
  br label %bb149
bb149:
  %t738 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l385
  %t739 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t738, ptr %t739
  %t740 = load ptr, ptr %l7, !tbaa !29
  %t741 = load %"compiler/source:Span", ptr %l5
  %t742 = load ptr, ptr %l380, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v0, ptr %v1, ptr %t742, ptr %t739, ptr %t740, %"compiler/source:Span" %t741)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s10)
  br label %bb151
bb151:
  %t746 = load ptr, ptr %l0, !tbaa !29
  store ptr %t746, ptr %l389, !tbaa !29
  %t747 = load i32, ptr %l6, !tbaa !23
  %t749 = sext i32 %t747 to i64
  store i64 %t749, ptr %l391, !tbaa !24
  store ptr %l23, ptr %l392, !tbaa !29
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t751 = load ptr, ptr %l7, !tbaa !29
  %t755 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2erefsOf(ptr %v0, ptr %v1, ptr %s2, ptr %s2, ptr %t750, ptr %t751, ptr %l23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t755, ptr %l396
  br label %bb152
bb152:
  %t756 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l396
  %t757 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t756, ptr %t757
  %t758 = load ptr, ptr %l389, !tbaa !29
  %t759 = load i64, ptr %l391, !tbaa !24
  %t760 = load ptr, ptr %l392, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egiveRefs(ptr %v0, ptr %s2, ptr %s2, ptr %t758, i64 %t759, ptr %t760, ptr %t757)
  br label %bb153
bb153:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t764 = getelementptr %"compiler/free:walker", ptr %t762, i32 0, i32 10
  %t765 = load i32, ptr %l6, !tbaa !23
  %t767 = sext i32 %t765 to i64
  %t770 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t764, i64 %t767)
  %t771 = extractvalue { i32, i64 } %t770, 1
  %t772 = extractvalue { i32, i64 } %t770, 0
  store i32 %t772, ptr %l404
  %t773 = icmp ne i32 %t772, 0
  br i1 %t773, label %bb155, label %ok.774, !prof !99
ok.774:
  store i64 %t771, ptr %l403
  br label %bb154
bb154:
  %t775 = load i64, ptr %l403, !tbaa !24
  store i64 %t775, ptr %l398, !tbaa !24
  br label %bb157
bb155:
  br label %bb156
bb156:
  store i64 -1, ptr %l398, !tbaa !24
  br label %bb157
bb157:
  %t776 = load i64, ptr %l398, !tbaa !24
  store i64 %t776, ptr %l28, !tbaa !24
  %t777 = load i64, ptr %l28, !tbaa !24
  %t779 = icmp sge i64 %t777, 0
  br i1 %t779, label %bb158, label %bb159
bb158:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t782 = load i64, ptr %l28, !tbaa !24
  %t783 = load ptr, ptr %l7, !tbaa !29
  %t784 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %s2, ptr %t781, i64 %t782, ptr %t783, ptr %l23, %"compiler/source:Span" %t784)
  br label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb161
bb161:
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t792 = getelementptr %"compiler/free:walker", ptr %t790, i32 0, i32 52
  %t793 = load i32, ptr %t792, !tbaa !23
  %t794 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t797 = icmp ne i32 %t793, %t794
  br i1 %t797, label %bb162, label %bb163
bb162:
  %t799 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownerSettle(ptr %v0, ptr %t799, i64 -1)
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t802 = load i64, ptr %l22, !tbaa !24
  %t805 = getelementptr %"compiler/free:walker", ptr %t801, i32 0, i32 51
  store i64 %t802, ptr %t805, !tbaa !24
  %t806 = load i64, ptr %l28, !tbaa !24
  %t808 = icmp sge i64 %t806, 0
  br i1 %t808, label %bb166, label %bb167
bb166:
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = load i64, ptr %l28, !tbaa !24
  %t812 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeField(ptr %v0, ptr %v1, ptr %t810, i64 %t811, ptr %t812)
  br label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb169
bb169:
  %t816 = load ptr, ptr %l0, !tbaa !29
  %t817 = load i32, ptr %l6, !tbaa !23
  %t819 = sext i32 %t817 to i64
  %t822 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t816, i64 %t819)
  store i64 %t822, ptr %l427
  br label %bb170
bb170:
  %t823 = load i64, ptr %l427, !tbaa !24
  store i64 %t823, ptr %l29, !tbaa !24
  %t824 = load i64, ptr %l29, !tbaa !24
  %t826 = icmp sge i64 %t824, 0
  br i1 %t826, label %bb171, label %bb172
bb171:
  %t828 = load i1, ptr %l19, !tbaa !21
  store i1 %t828, ptr %l430, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l430, !tbaa !21
  br label %bb173
bb173:
  %t830 = load i1, ptr %l430, !tbaa !21
  br i1 %t830, label %bb174, label %bb175
bb174:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t833 = getelementptr %"compiler/free:walker", ptr %t831, i32 0, i32 2
  %t834 = load i1, ptr %t833, !tbaa !21
  store i1 %t834, ptr %l432, !tbaa !21
  br label %bb176
bb175:
  store i1 false, ptr %l432, !tbaa !21
  br label %bb176
bb176:
  %t836 = load i1, ptr %l432, !tbaa !21
  br i1 %t836, label %bb177, label %bb178
bb177:
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = getelementptr %"compiler/free:walker", ptr %t837, i32 0, i32 36
  %t840 = load i64, ptr %t839, !tbaa !24
  %t842 = icmp eq i64 %t840, 0
  store i1 %t842, ptr %l435, !tbaa !21
  br label %bb179
bb178:
  store i1 false, ptr %l435, !tbaa !21
  br label %bb179
bb179:
  %t844 = load i1, ptr %l435, !tbaa !21
  br i1 %t844, label %bb180, label %bb181
bb180:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t847 = getelementptr %"compiler/free:walker", ptr %t845, i32 0, i32 0
  %t848 = load ptr, ptr %t847, !tbaa !29
  %t850 = getelementptr %"compiler/free:Free", ptr %t848, i32 0, i32 101
  store ptr %t850, ptr %l441, !tbaa !29
  %t851 = load i64, ptr %l29, !tbaa !24
  store i64 %t851, ptr %l442, !tbaa !24
  %t852 = load ptr, ptr %l0, !tbaa !29
  %t854 = getelementptr %"compiler/free:walker", ptr %t852, i32 0, i32 1
  %t855 = load i64, ptr %t854, !tbaa !24
  store i64 %t855, ptr %l444, !tbaa !24
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t858 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t856)
  store ptr %t858, ptr %l446
  br label %bb182
bb181:
  %t859 = load i64, ptr %l29, !tbaa !24
  %t861 = icmp sge i64 %t859, 0
  br i1 %t861, label %bb185, label %bb186
bb182:
  %t863 = load ptr, ptr %l446, !tbaa !29
  %t865 = getelementptr %"compiler/typed:Body", ptr %t863, i32 0, i32 3
  %t866 = load i64, ptr %t865, !tbaa !24
  %t867 = load %"compiler/source:Span", ptr %l5
  %t868 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  %t869 = load ptr, ptr %l7, !tbaa !29
  %t871 = load i64, ptr %l442, !tbaa !24
  %t872 = load i64, ptr %l444, !tbaa !24
  %t877 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t871, i64 %t872, i64 %t866, %"compiler/source:Span" %t867, i64 %t868, i64 -1, i64 -1, ptr %t869, ptr null)
  store %"compiler/free:store" %t877, ptr %l453
  br label %bb183
bb183:
  %t878 = load ptr, ptr %l441, !tbaa !29
  %t879 = load %"compiler/free:store", ptr %l453
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t878, %"compiler/free:store" %t879)
  br label %bb184
bb184:
  br label %bb190
bb185:
  store %olang.scope zeroinitializer, ptr %s16
  %t880 = load ptr, ptr %l0, !tbaa !29
  store ptr %t880, ptr %l456, !tbaa !29
  %t881 = load i64, ptr %l29, !tbaa !24
  store i64 %t881, ptr %l457, !tbaa !24
  %t882 = load ptr, ptr %l7, !tbaa !29
  store ptr %t882, ptr %l458, !tbaa !29
  store ptr %l23, ptr %l459, !tbaa !29
  %t883 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t883, ptr %l460
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = load i32, ptr %l6, !tbaa !23
  %t887 = sext i32 %t885 to i64
  %t890 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s16, ptr %t884, i64 %t887)
  store { i64, ptr } %t890, ptr %l464
  br label %bb187
bb186:
  br label %bb189
bb187:
  %t891 = load { i64, ptr }, ptr %l464, !tbaa !27
  %t892 = load ptr, ptr %l456, !tbaa !29
  %t893 = load i64, ptr %l457, !tbaa !24
  %t894 = load ptr, ptr %l458, !tbaa !29
  %t895 = load ptr, ptr %l459, !tbaa !29
  %t896 = load %"compiler/source:Span", ptr %l460
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %s2, ptr %s16, ptr %t892, i64 %t893, ptr %t894, ptr %t895, %"compiler/source:Span" %t896, { i64, ptr } %t891, i1 false)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s16)
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t898 = load ptr, ptr %l0, !tbaa !29
  %t899 = load i32, ptr %l6, !tbaa !23
  %t901 = sext i32 %t899 to i64
  %t904 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %t898, i64 %t901)
  store i64 %t904, ptr %l469
  br label %bb191
bb191:
  %t905 = load i64, ptr %l469, !tbaa !24
  store i64 %t905, ptr %l30, !tbaa !24
  %t906 = load i64, ptr %l30, !tbaa !24
  %t908 = icmp sge i64 %t906, 0
  br i1 %t908, label %bb192, label %bb193
bb192:
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t912 = getelementptr %"compiler/free:walker", ptr %t910, i32 0, i32 2
  %t913 = load i1, ptr %t912, !tbaa !21
  store i1 %t913, ptr %l472, !tbaa !21
  br label %bb194
bb193:
  store i1 false, ptr %l472, !tbaa !21
  br label %bb194
bb194:
  %t915 = load i1, ptr %l472, !tbaa !21
  br i1 %t915, label %bb195, label %bb196
bb195:
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t918 = getelementptr %"compiler/free:walker", ptr %t916, i32 0, i32 36
  %t919 = load i64, ptr %t918, !tbaa !24
  %t921 = icmp eq i64 %t919, 0
  store i1 %t921, ptr %l475, !tbaa !21
  br label %bb197
bb196:
  store i1 false, ptr %l475, !tbaa !21
  br label %bb197
bb197:
  %t923 = load i1, ptr %l475, !tbaa !21
  br i1 %t923, label %bb198, label %bb199
bb198:
  %t924 = load ptr, ptr %l0, !tbaa !29
  store ptr %t924, ptr %l479, !tbaa !29
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t927 = getelementptr %"compiler/free:walker", ptr %t925, i32 0, i32 0
  %t928 = load ptr, ptr %t927, !tbaa !29
  %t930 = getelementptr %"compiler/free:Free", ptr %t928, i32 0, i32 174
  %t931 = load i64, ptr %l30, !tbaa !24
  %t934 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t930, i64 %t931)
  store %"compiler/free:feed" %t934, ptr %l484
  br label %bb200
bb199:
  br label %bb209
bb200:
  %t935 = getelementptr %"compiler/free:feed", ptr %l484, i32 0, i32 2
  %t936 = load i64, ptr %t935, !tbaa !24
  %t937 = load ptr, ptr %l7, !tbaa !29
  %t938 = load %"compiler/source:Span", ptr %l5
  %t939 = load ptr, ptr %l479, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t939, i64 %t936, ptr %t937, %"compiler/source:Span" %t938, i1 false)
  br label %bb201
bb201:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t945 = getelementptr %"compiler/free:walker", ptr %t943, i32 0, i32 0
  %t946 = load ptr, ptr %t945, !tbaa !29
  %t948 = getelementptr %"compiler/free:Free", ptr %t946, i32 0, i32 101
  store ptr %t948, ptr %l490, !tbaa !29
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t951 = getelementptr %"compiler/free:walker", ptr %t949, i32 0, i32 0
  %t952 = load ptr, ptr %t951, !tbaa !29
  %t954 = getelementptr %"compiler/free:Free", ptr %t952, i32 0, i32 101
  %t956 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t954)
  store i64 %t956, ptr %l494
  br label %bb202
bb202:
  %t957 = load i64, ptr %l494, !tbaa !24
  %t958 = sub i64 %t957, 1
  %t959 = load ptr, ptr %l490, !tbaa !29
  %t961 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t959, i64 %t958)
  store %"compiler/free:store" %t961, ptr %l496
  br label %bb203
bb203:
  %t962 = load %"compiler/free:store", ptr %l496
  store %"compiler/free:store" %t962, ptr %l31
  %t963 = getelementptr %"compiler/free:store", ptr %l31, i32 0, i32 4
  %t964 = load i64, ptr %t963, !tbaa !24
  %t965 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t968 = icmp eq i64 %t964, %t965
  br i1 %t968, label %bb204, label %bb205
bb204:
  %t970 = load ptr, ptr %l0, !tbaa !29
  %t972 = getelementptr %"compiler/free:walker", ptr %t970, i32 0, i32 0
  %t973 = load ptr, ptr %t972, !tbaa !29
  %t975 = getelementptr %"compiler/free:Free", ptr %t973, i32 0, i32 174
  %t976 = load i64, ptr %l30, !tbaa !24
  %t979 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eRefMut_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %v0, ptr %t975, i64 %t976)
  store ptr %t979, ptr %l504
  br label %bb206
bb205:
  br label %bb208
bb206:
  %t980 = load ptr, ptr %l504, !tbaa !29
  store ptr %t980, ptr %l505, !tbaa !29
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t983 = getelementptr %"compiler/free:walker", ptr %t981, i32 0, i32 0
  %t984 = load ptr, ptr %t983, !tbaa !29
  %t985 = load ptr, ptr %l7, !tbaa !29
  %t988 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t984, ptr %t985)
  store i64 %t988, ptr %l509
  br label %bb207
bb207:
  %t989 = load i64, ptr %l509, !tbaa !24
  %t990 = load ptr, ptr %l505, !tbaa !29
  %t991 = getelementptr %"compiler/free:feed", ptr %t990, i32 0, i32 6
  store i64 %t989, ptr %t991, !tbaa !24
  br label %bb208
bb208:
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s2)
  br label %bb502
bb210:
  %t992 = load ptr, ptr %l1, !tbaa !29
  store ptr %t992, ptr %l510, !tbaa !29
  store i1 false, ptr %l511, !tbaa !21
  %t993 = load ptr, ptr %l510, !tbaa !29
  %t994 = icmp ne ptr %t993, null
  br i1 %t994, label %bb211, label %bb212
bb211:
  %t996 = load ptr, ptr %l510, !tbaa !29
  %t997 = load i64, ptr %t996, !range !{i64 0, i64 17}
  %t999 = icmp eq i64 %t997, 1
  store i1 %t999, ptr %l511, !tbaa !21
  br label %bb212
bb212:
  %t1000 = load i1, ptr %l511, !tbaa !21
  br i1 %t1000, label %bb213, label %bb214
bb213:
  %t1001 = load ptr, ptr %l1, !tbaa !29
  %t1003 = getelementptr { i64, [3 x i64] }, ptr %t1001, i32 0, i32 1
  %t1004 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1003, i32 0, i32 0
  %t1005 = load %"compiler/source:Span", ptr %t1004
  store %"compiler/source:Span" %t1005, ptr %l32
  %t1007 = load ptr, ptr %l1, !tbaa !29
  %t1009 = getelementptr { i64, [3 x i64] }, ptr %t1007, i32 0, i32 1
  %t1010 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1009, i32 0, i32 1
  %t1011 = load ptr, ptr %t1010
  store ptr %t1011, ptr %l33, !tbaa !29
  %t1013 = load ptr, ptr %l1, !tbaa !29
  %t1015 = getelementptr { i64, [3 x i64] }, ptr %t1013, i32 0, i32 1
  %t1016 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1015, i32 0, i32 2
  %t1017 = load ptr, ptr %t1016
  store ptr %t1017, ptr %l34, !tbaa !29
  br label %bb215
bb214:
  br label %bb217
bb215:
  %t1019 = load ptr, ptr %l0, !tbaa !29
  %t1020 = load %"compiler/source:Span", ptr %l32
  %t1021 = load ptr, ptr %l33, !tbaa !29
  %t1022 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t1019, %"compiler/source:Span" %t1020, ptr %t1021, ptr %t1022)
  br label %bb216
bb216:
  br label %bb502
bb217:
  %t1027 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1027, ptr %l524, !tbaa !29
  store i1 false, ptr %l525, !tbaa !21
  %t1028 = load ptr, ptr %l524, !tbaa !29
  %t1029 = icmp ne ptr %t1028, null
  br i1 %t1029, label %bb218, label %bb219
bb218:
  %t1031 = load ptr, ptr %l524, !tbaa !29
  %t1032 = load i64, ptr %t1031, !range !{i64 0, i64 17}
  %t1034 = icmp eq i64 %t1032, 2
  store i1 %t1034, ptr %l525, !tbaa !21
  br label %bb219
bb219:
  %t1035 = load i1, ptr %l525, !tbaa !21
  br i1 %t1035, label %bb220, label %bb221
bb220:
  %t1036 = load ptr, ptr %l1, !tbaa !29
  %t1038 = getelementptr { i64, [3 x i64] }, ptr %t1036, i32 0, i32 1
  %t1039 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1038, i32 0, i32 0
  %t1040 = load %"compiler/source:Span", ptr %t1039
  store %"compiler/source:Span" %t1040, ptr %l35
  %t1042 = load ptr, ptr %l1, !tbaa !29
  %t1044 = getelementptr { i64, [3 x i64] }, ptr %t1042, i32 0, i32 1
  %t1045 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1044, i32 0, i32 1
  %t1046 = load ptr, ptr %t1045
  store ptr %t1046, ptr %l36, !tbaa !29
  br label %bb222
bb221:
  br label %bb224
bb222:
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1049 = load %"compiler/source:Span", ptr %l35
  %t1050 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %t1048, %"compiler/source:Span" %t1049, ptr %t1050)
  br label %bb223
bb223:
  br label %bb502
bb224:
  %t1054 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1054, ptr %l535, !tbaa !29
  store i1 false, ptr %l536, !tbaa !21
  %t1055 = load ptr, ptr %l535, !tbaa !29
  %t1056 = icmp ne ptr %t1055, null
  br i1 %t1056, label %bb225, label %bb226
bb225:
  %t1058 = load ptr, ptr %l535, !tbaa !29
  %t1059 = load i64, ptr %t1058, !range !{i64 0, i64 17}
  %t1061 = icmp eq i64 %t1059, 3
  store i1 %t1061, ptr %l536, !tbaa !21
  br label %bb226
bb226:
  %t1062 = load i1, ptr %l536, !tbaa !21
  br i1 %t1062, label %bb227, label %bb228
bb227:
  %t1063 = load ptr, ptr %l1, !tbaa !29
  %t1065 = getelementptr { i64, [3 x i64] }, ptr %t1063, i32 0, i32 1
  %t1066 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1065, i32 0, i32 1
  %t1067 = load ptr, ptr %t1066
  store ptr %t1067, ptr %l37, !tbaa !29
  br label %bb229
bb228:
  br label %bb243
bb229:
  store %olang.scope zeroinitializer, ptr %s21
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1070 = load ptr, ptr %l37, !tbaa !29
  %t1072 = getelementptr %"compiler/typed:If", ptr %t1070, i32 0, i32 0
  %t1073 = load ptr, ptr %t1072, !tbaa !29
  %t1076 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t1069, ptr %t1073)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1076, ptr %l544
  br label %bb230
bb230:
  %t1077 = load ptr, ptr %l0, !tbaa !29
  %t1079 = getelementptr %"compiler/free:walker", ptr %t1077, i32 0, i32 14
  %t1080 = load i64, ptr %t1079, !tbaa !24
  store i64 %t1080, ptr %l38, !tbaa !24
  %t1082 = load ptr, ptr %l0, !tbaa !29
  %t1083 = load ptr, ptr %l37, !tbaa !29
  %t1085 = getelementptr %"compiler/typed:If", ptr %t1083, i32 0, i32 1
  %t1086 = load ptr, ptr %t1085, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1082, ptr %t1086)
  br label %bb231
bb231:
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1091 = getelementptr %"compiler/free:walker", ptr %t1089, i32 0, i32 14
  %t1092 = load i64, ptr %t1091, !tbaa !24
  %t1094 = sub i64 %t1092, 1
  store i64 %t1094, ptr %l39, !tbaa !24
  %t1096 = load ptr, ptr %l0, !tbaa !29
  %t1098 = getelementptr %"compiler/free:walker", ptr %t1096, i32 0, i32 14
  %t1099 = load i64, ptr %t1098, !tbaa !24
  store i64 %t1099, ptr %l40, !tbaa !24
  %t1101 = load ptr, ptr %l37, !tbaa !29
  %t1103 = getelementptr %"compiler/typed:If", ptr %t1101, i32 0, i32 2
  %t1104 = load ptr, ptr %t1103, !tbaa !29
  %t1106 = icmp eq ptr %t1104, null
  %t1108 = xor i1 %t1106, true
  br i1 %t1108, label %bb232, label %bb233
bb232:
  %t1110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1110, ptr %l559, !tbaa !29
  %t1111 = load ptr, ptr %l37, !tbaa !29
  %t1113 = getelementptr %"compiler/typed:If", ptr %t1111, i32 0, i32 2
  %t1114 = load ptr, ptr %t1113, !tbaa !29
  %t1116 = icmp eq ptr %t1114, null
  br i1 %t1116, label %bb234, label %bb235
bb233:
  br label %bb238
bb234:
  call void @__olang_check_failed(ptr @olang_loc_d8246f320a19bbf9_8add34a618744eed)
  unreachable
bb235:
  br label %bb236
bb236:
  %t1118 = load ptr, ptr %l37, !tbaa !29
  %t1120 = getelementptr %"compiler/typed:If", ptr %t1118, i32 0, i32 2
  %t1121 = load ptr, ptr %t1120, !tbaa !29
  %t1122 = load ptr, ptr %l559, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1122, ptr %t1121)
  br label %bb237
bb237:
  br label %bb238
bb238:
  %t1124 = load ptr, ptr %l0, !tbaa !29
  %t1126 = getelementptr %"compiler/free:walker", ptr %t1124, i32 0, i32 20
  %t1127 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1126, i64 %t1127)
  br label %bb239
bb239:
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1132 = getelementptr %"compiler/free:walker", ptr %t1130, i32 0, i32 21
  %t1133 = load i64, ptr %l39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1132, i64 %t1133)
  br label %bb240
bb240:
  %t1136 = load ptr, ptr %l0, !tbaa !29
  %t1138 = getelementptr %"compiler/free:walker", ptr %t1136, i32 0, i32 22
  %t1139 = load i64, ptr %l40, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1138, i64 %t1139)
  br label %bb241
bb241:
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1144 = getelementptr %"compiler/free:walker", ptr %t1142, i32 0, i32 23
  %t1145 = load ptr, ptr %l0, !tbaa !29
  %t1147 = getelementptr %"compiler/free:walker", ptr %t1145, i32 0, i32 14
  %t1148 = load i64, ptr %t1147, !tbaa !24
  %t1150 = sub i64 %t1148, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1144, i64 %t1150)
  br label %bb242
bb242:
  call void @__olang_scope_close(ptr %s21)
  br label %bb502
bb243:
  %t1153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1153, ptr %l579, !tbaa !29
  store i1 false, ptr %l580, !tbaa !21
  %t1154 = load ptr, ptr %l579, !tbaa !29
  %t1155 = icmp ne ptr %t1154, null
  br i1 %t1155, label %bb244, label %bb245
bb244:
  %t1157 = load ptr, ptr %l579, !tbaa !29
  %t1158 = load i64, ptr %t1157, !range !{i64 0, i64 17}
  %t1160 = icmp eq i64 %t1158, 4
  store i1 %t1160, ptr %l580, !tbaa !21
  br label %bb245
bb245:
  %t1161 = load i1, ptr %l580, !tbaa !21
  br i1 %t1161, label %bb246, label %bb247
bb246:
  %t1162 = load ptr, ptr %l1, !tbaa !29
  %t1164 = getelementptr { i64, [3 x i64] }, ptr %t1162, i32 0, i32 1
  %t1165 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1164, i32 0, i32 1
  %t1166 = load ptr, ptr %t1165
  store ptr %t1166, ptr %l41, !tbaa !29
  %t1168 = load ptr, ptr %l1, !tbaa !29
  %t1170 = getelementptr { i64, [3 x i64] }, ptr %t1168, i32 0, i32 1
  %t1171 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1170, i32 0, i32 2
  %t1172 = load ptr, ptr %t1171
  store ptr %t1172, ptr %l42, !tbaa !29
  br label %bb248
bb247:
  br label %bb256
bb248:
  %t1174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1174, ptr %l587, !tbaa !29
  %t1175 = load ptr, ptr %l587, !tbaa !29
  %t1176 = getelementptr %"compiler/free:walker", ptr %t1175, i32 0, i32 30
  %t1177 = load i64, ptr %t1176, !tbaa !24
  %t1180 = add i64 %t1177, 1
  %t1182 = load ptr, ptr %l587, !tbaa !29
  %t1183 = getelementptr %"compiler/free:walker", ptr %t1182, i32 0, i32 30
  store i64 %t1180, ptr %t1183, !tbaa !24
  %t1184 = load ptr, ptr %l0, !tbaa !29
  %t1185 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1184, ptr %t1185)
  br label %bb249
bb249:
  %t1188 = load ptr, ptr %l42, !tbaa !29
  %t1190 = icmp eq ptr %t1188, null
  %t1192 = xor i1 %t1190, true
  br i1 %t1192, label %bb250, label %bb251
bb250:
  %t1194 = load ptr, ptr %l0, !tbaa !29
  %t1195 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1194, ptr %t1195)
  br label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb253
bb253:
  %t1198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1198, ptr %l598, !tbaa !29
  %t1199 = load ptr, ptr %l598, !tbaa !29
  %t1200 = getelementptr %"compiler/free:walker", ptr %t1199, i32 0, i32 30
  %t1201 = load i64, ptr %t1200, !tbaa !24
  %t1204 = sub i64 %t1201, 1
  %t1206 = load ptr, ptr %l598, !tbaa !29
  %t1207 = getelementptr %"compiler/free:walker", ptr %t1206, i32 0, i32 30
  store i64 %t1204, ptr %t1207, !tbaa !24
  %t1208 = load ptr, ptr %l0, !tbaa !29
  %t1210 = getelementptr %"compiler/free:walker", ptr %t1208, i32 0, i32 17
  %t1211 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1210, i64 %t1211)
  br label %bb254
bb254:
  %t1214 = load ptr, ptr %l0, !tbaa !29
  %t1216 = getelementptr %"compiler/free:walker", ptr %t1214, i32 0, i32 19
  %t1217 = load ptr, ptr %l0, !tbaa !29
  %t1219 = getelementptr %"compiler/free:walker", ptr %t1217, i32 0, i32 14
  %t1220 = load i64, ptr %t1219, !tbaa !24
  %t1222 = sub i64 %t1220, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1216, i64 %t1222)
  br label %bb255
bb255:
  br label %bb502
bb256:
  %t1225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1225, ptr %l610, !tbaa !29
  store i1 false, ptr %l611, !tbaa !21
  %t1226 = load ptr, ptr %l610, !tbaa !29
  %t1227 = icmp ne ptr %t1226, null
  br i1 %t1227, label %bb257, label %bb258
bb257:
  %t1229 = load ptr, ptr %l610, !tbaa !29
  %t1230 = load i64, ptr %t1229, !range !{i64 0, i64 17}
  %t1232 = icmp eq i64 %t1230, 6
  store i1 %t1232, ptr %l611, !tbaa !21
  br label %bb258
bb258:
  %t1233 = load i1, ptr %l611, !tbaa !21
  br i1 %t1233, label %bb259, label %bb260
bb259:
  %t1234 = load ptr, ptr %l1, !tbaa !29
  %t1236 = getelementptr { i64, [3 x i64] }, ptr %t1234, i32 0, i32 1
  %t1237 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1236, i32 0, i32 1
  %t1238 = load ptr, ptr %t1237
  store ptr %t1238, ptr %l43, !tbaa !29
  br label %bb265
bb260:
  %t1240 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1240, ptr %l616, !tbaa !29
  store i1 false, ptr %l617, !tbaa !21
  %t1241 = load ptr, ptr %l616, !tbaa !29
  %t1242 = icmp ne ptr %t1241, null
  br i1 %t1242, label %bb261, label %bb262
bb261:
  %t1244 = load ptr, ptr %l616, !tbaa !29
  %t1245 = load i64, ptr %t1244, !range !{i64 0, i64 17}
  %t1247 = icmp eq i64 %t1245, 16
  store i1 %t1247, ptr %l617, !tbaa !21
  br label %bb262
bb262:
  %t1248 = load i1, ptr %l617, !tbaa !21
  br i1 %t1248, label %bb263, label %bb264
bb263:
  %t1249 = load ptr, ptr %l1, !tbaa !29
  %t1251 = getelementptr { i64, [3 x i64] }, ptr %t1249, i32 0, i32 1
  %t1252 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1251, i32 0, i32 1
  %t1253 = load ptr, ptr %t1252
  store ptr %t1253, ptr %l43, !tbaa !29
  br label %bb265
bb264:
  br label %bb334
bb265:
  %t1255 = load ptr, ptr %l43, !tbaa !29
  %t1257 = icmp eq ptr %t1255, null
  %t1259 = xor i1 %t1257, true
  br i1 %t1259, label %bb266, label %bb267
bb266:
  store %olang.scope zeroinitializer, ptr %s26
  %t1261 = load ptr, ptr %l0, !tbaa !29
  %t1262 = load ptr, ptr %l1, !tbaa !29
  %t1263 = load ptr, ptr %l43, !tbaa !29
  %t1267 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eretCtorOf(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t1261, ptr %t1262, ptr %t1263)
  store ptr %t1267, ptr %l628
  br label %bb268
bb267:
  br label %bb320
bb268:
  %t1268 = load ptr, ptr %l628, !tbaa !29
  store ptr %t1268, ptr %l44, !tbaa !29
  %t1269 = load ptr, ptr %l0, !tbaa !29
  %t1271 = getelementptr %"compiler/free:walker", ptr %t1269, i32 0, i32 40
  %t1272 = load i64, ptr %t1271, !tbaa !24
  store i64 %t1272, ptr %l45, !tbaa !24
  %t1274 = load ptr, ptr %l0, !tbaa !29
  %t1276 = getelementptr %"compiler/free:walker", ptr %t1274, i32 0, i32 43
  %t1277 = load i64, ptr %t1276, !tbaa !24
  store i64 %t1277, ptr %l46, !tbaa !24
  %t1279 = load ptr, ptr %l44, !tbaa !29
  %t1281 = icmp eq ptr %t1279, null
  %t1283 = xor i1 %t1281, true
  br i1 %t1283, label %bb269, label %bb270
bb269:
  %t1285 = load ptr, ptr %l44, !tbaa !29
  %t1287 = getelementptr %"compiler/typed:Call", ptr %t1285, i32 0, i32 2
  %t1288 = load i32, ptr %t1287, !tbaa !23
  %t1290 = sext i32 %t1288 to i64
  %t1292 = load ptr, ptr %l44, !tbaa !29
  %t1294 = getelementptr %"compiler/typed:Call", ptr %t1292, i32 0, i32 2
  %t1295 = load i32, ptr %t1294, !tbaa !23
  %t1297 = sext i32 %t1295 to i64
  %t1299 = load ptr, ptr %l0, !tbaa !29
  %t1303 = getelementptr %"compiler/free:walker", ptr %t1299, i32 0, i32 40
  store i64 %t1290, ptr %t1303, !tbaa !24
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1308 = getelementptr %"compiler/free:walker", ptr %t1304, i32 0, i32 43
  store i64 %t1297, ptr %t1308, !tbaa !24
  br label %bb271
bb270:
  br label %bb271
bb271:
  %t1309 = load ptr, ptr %l0, !tbaa !29
  %t1310 = load ptr, ptr %l43, !tbaa !29
  %t1313 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s26, ptr %t1309, ptr %t1310)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1313, ptr %l648
  br label %bb272
bb272:
  %t1314 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l648
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1314, ptr %l49
  %t1315 = load i64, ptr %l45, !tbaa !24
  %t1317 = load i64, ptr %l46, !tbaa !24
  %t1319 = load ptr, ptr %l0, !tbaa !29
  %t1323 = getelementptr %"compiler/free:walker", ptr %t1319, i32 0, i32 40
  store i64 %t1315, ptr %t1323, !tbaa !24
  %t1324 = load ptr, ptr %l0, !tbaa !29
  %t1328 = getelementptr %"compiler/free:walker", ptr %t1324, i32 0, i32 43
  store i64 %t1317, ptr %t1328, !tbaa !24
  %t1329 = load ptr, ptr %l44, !tbaa !29
  %t1331 = icmp eq ptr %t1329, null
  %t1333 = xor i1 %t1331, true
  br i1 %t1333, label %bb273, label %bb274
bb273:
  store %olang.scope zeroinitializer, ptr %s28
  %t1335 = call ptr @__olang_scope_hold(ptr %s26)
  %t1336 = ptrtoint ptr %t1335 to i64
  store i64 %t1336, ptr %l658, !tbaa !24
  %t1337 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e49
  br i1 %t1337, label %bb275, label %bb276
bb274:
  br label %bb306
bb275:
  %t1339 = call ptr @__olang_region_make(ptr %s26)
  %t1340 = ptrtoint ptr %t1339 to i64
  store i64 %t1340, ptr %l658, !tbaa !24
  br label %bb276
bb276:
  %t1341 = load ptr, ptr %l0, !tbaa !29
  %t1343 = getelementptr %"compiler/free:walker", ptr %t1341, i32 0, i32 0
  %t1344 = load ptr, ptr %t1343, !tbaa !29
  %t1345 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  %t1347 = load i64, ptr %l658
  %t1348 = inttoptr i64 %t1347 to ptr
  %t1349 = call ptr @__olang_scope_alloc_a(ptr %t1348, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1345, ptr %t1349
  %t1350 = load i64, ptr %l658
  %t1351 = inttoptr i64 %t1350 to ptr
  %t1352 = load i64, ptr %l658
  %t1353 = inttoptr i64 %t1352 to ptr
  %t1356 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t1351, ptr %t1353, ptr %t1344, ptr %t1349)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1356, ptr %l664
  br label %bb277
bb277:
  %t1357 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e49
  br i1 %t1357, label %bb278, label %bb279
bb278:
  %t1359 = load i64, ptr %l658
  %t1360 = inttoptr i64 %t1359 to ptr
  %t1361 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l664, i32 0, i32 0
  %t1362 = load { i64, ptr }, ptr %t1361
  %t1363 = extractvalue { i64, ptr } %t1362, 1
  %t1364 = call ptr @__olang_region_or(ptr %t1363, ptr null)
  %t1365 = call ptr @__olang_region_home(ptr %t1364)
  %t1366 = icmp ne ptr %t1365, null
  %t1367 = select i1 %t1366, ptr %t1365, ptr null
  call void @__olang_region_settle_in(ptr %t1360, ptr %t1367)
  br label %bb279
bb279:
  %t1368 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1368, ptr %l666
  %t1369 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l664
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1369, ptr %l49
  %t1370 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e49
  br i1 %t1370, label %bb280, label %bb281
bb280:
  %t1372 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l666, i32 0, i32 0
  %t1373 = load { i64, ptr }, ptr %t1372
  %t1374 = extractvalue { i64, ptr } %t1373, 1
  %t1375 = call ptr @__olang_region_or(ptr %t1374, ptr null)
  %t1376 = call ptr @__olang_region_home(ptr %t1375)
  %t1377 = icmp ne ptr %t1376, null
  %t1378 = select i1 %t1377, ptr %t1376, ptr null
  call void @__olang_region_drop(ptr %t1378)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l666
  br label %bb281
bb281:
  %t1379 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1379, label %bb282, label %bb283
bb282:
  %t1381 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l666, i32 0, i32 0
  %t1382 = load { i64, ptr }, ptr %t1381
  %t1383 = extractvalue { i64, ptr } %t1382, 0
  %t1384 = extractvalue { i64, ptr } %t1382, 1
  call void @__olang_region_release_part(ptr %t1384, i64 %t1383)
  store { i64, ptr } zeroinitializer, ptr %t1381
  br label %bb283
bb283:
  %t1385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1385, ptr %l669, !tbaa !29
  %t1386 = load ptr, ptr %l0, !tbaa !29
  %t1388 = getelementptr %"compiler/free:walker", ptr %t1386, i32 0, i32 0
  %t1389 = load ptr, ptr %t1388, !tbaa !29
  store ptr %t1389, ptr %l671, !tbaa !29
  %t1390 = load ptr, ptr %l43, !tbaa !29
  %t1392 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1390)
  store i32 %t1392, ptr %l673
  br label %bb284
bb284:
  %t1393 = load ptr, ptr %l671, !tbaa !29
  %t1394 = load i32, ptr %l673, !tbaa !23
  %t1395 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t1393, i32 %t1394)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1395, ptr %l674
  br label %bb285
bb285:
  %t1396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l674
  %t1397 = call ptr @__olang_scope_alloc_a(ptr %s28, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1396, ptr %t1397
  store ptr %t1397, ptr %l675, !tbaa !29
  %t1398 = load ptr, ptr %l44, !tbaa !29
  store ptr %t1398, ptr %l676, !tbaa !29
  %t1399 = load ptr, ptr %l43, !tbaa !29
  store ptr %t1399, ptr %l677, !tbaa !29
  %t1400 = load ptr, ptr %l1, !tbaa !29
  %t1402 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t1400)
  store %"compiler/source:Span" %t1402, ptr %l679
  br label %bb286
bb286:
  %t1403 = load ptr, ptr %l669, !tbaa !29
  %t1404 = load ptr, ptr %l675, !tbaa !29
  %t1405 = load ptr, ptr %l676, !tbaa !29
  %t1406 = load ptr, ptr %l677, !tbaa !29
  %t1407 = load %"compiler/source:Span", ptr %l679
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t1403, ptr %t1404, ptr %t1405, ptr %t1406, %"compiler/source:Span" %t1407)
  br label %bb287
bb287:
  store %olang.scope zeroinitializer, ptr %s29
  %t1408 = load ptr, ptr %l0, !tbaa !29
  %t1410 = getelementptr %"compiler/free:walker", ptr %t1408, i32 0, i32 0
  %t1411 = load ptr, ptr %t1410, !tbaa !29
  store ptr %t1411, ptr %l681, !tbaa !29
  %t1412 = load ptr, ptr %l43, !tbaa !29
  %t1414 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1412)
  store i32 %t1414, ptr %l683
  br label %bb288
bb288:
  %t1415 = load ptr, ptr %l681, !tbaa !29
  %t1416 = load i32, ptr %l683, !tbaa !23
  %t1417 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s29, ptr %t1415, i32 %t1416)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1417, ptr %l684
  br label %bb289
bb289:
  %t1418 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l684
  %t1419 = call ptr @__olang_scope_alloc_a(ptr %s29, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1418, ptr %t1419
  store ptr %t1419, ptr %l52, !tbaa !29
  store i64 0, ptr %l53, !tbaa !24
  br label %bb290
bb290:
  store %olang.scope zeroinitializer, ptr %s30
  %t1421 = load i64, ptr %l53, !tbaa !24
  store i64 %t1421, ptr %l686, !tbaa !24
  %t1422 = load ptr, ptr %l52, !tbaa !29
  %t1424 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s29, ptr %t1422)
  store i64 %t1424, ptr %l688
  br label %bb291
bb291:
  %t1425 = load i64, ptr %l686, !tbaa !24
  %t1426 = load i64, ptr %l688, !tbaa !24
  %t1427 = icmp slt i64 %t1425, %t1426
  %t1429 = xor i1 %t1427, true
  br i1 %t1429, label %bb292, label %bb293
bb292:
  call void @__olang_scope_close(ptr %s30)
  br label %bb305
bb293:
  br label %bb294
bb294:
  %t1431 = load ptr, ptr %l52, !tbaa !29
  %t1432 = load i64, ptr %l53, !tbaa !24
  %t1435 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s29, ptr %s29, ptr %t1431, i64 %t1432)
  store %"compiler/free:leaf" %t1435, ptr %l693
  br label %bb295
bb295:
  %t1436 = load %"compiler/free:leaf", ptr %l693
  store %"compiler/free:leaf" %t1436, ptr %l694
  %t1437 = call ptr @__olang_scope_hold(ptr %s30)
  %t1438 = ptrtoint ptr %t1437 to i64
  store i64 %t1438, ptr %l695, !tbaa !24
  %t1439 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t1439, label %bb296, label %bb297
bb296:
  %t1441 = call ptr @__olang_region_make_part(ptr %s30)
  %t1442 = ptrtoint ptr %t1441 to i64
  store i64 %t1442, ptr %l695, !tbaa !24
  br label %bb297
bb297:
  %t1443 = getelementptr %"compiler/free:leaf", ptr %l694, i32 0, i32 0
  %t1444 = load { i64, ptr }, ptr %t1443, !tbaa !27
  store { i64, ptr } %t1444, ptr %l697, !tbaa !27
  %t1445 = load { i64, ptr }, ptr %l697, !tbaa !27
  %t1446 = extractvalue { i64, ptr } %t1445, 0
  store i64 %t1446, ptr %l698, !tbaa !24
  %t1447 = load i64, ptr %l698, !tbaa !24
  %t1448 = mul i64 %t1447, 8
  %t1449 = load i64, ptr %l695
  %t1450 = inttoptr i64 %t1449 to ptr
  %t1451 = call ptr @__olang_held_alloc(ptr %t1450, i64 %t1448)
  %t1452 = insertvalue { i64, ptr } undef, i64 %t1447, 0
  %t1453 = insertvalue { i64, ptr } %t1452, ptr %t1451, 1
  store { i64, ptr } %t1453, ptr %l699, !tbaa !27
  %t1454 = getelementptr { i64, ptr }, ptr %l699, i32 0, i32 1
  %t1455 = load ptr, ptr %t1454, !tbaa !27
  %t1456 = getelementptr { i64, ptr }, ptr %l697, i32 0, i32 1
  %t1457 = load ptr, ptr %t1456, !tbaa !27
  %t1458 = load i64, ptr %l698, !tbaa !24
  %t1459 = mul i64 %t1458, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1455, ptr %t1457, i64 %t1459, i1 false)
  %t1460 = load { i64, ptr }, ptr %l699, !tbaa !27
  %t1461 = getelementptr %"compiler/free:leaf", ptr %l694, i32 0, i32 0
  store { i64, ptr } %t1460, ptr %t1461, !tbaa !27
  %t1462 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t1462, label %bb298, label %bb299
bb298:
  %t1464 = getelementptr %"compiler/free:leaf", ptr %l694, i32 0, i32 0
  %t1465 = load { i64, ptr }, ptr %t1464, !tbaa !27
  %t1466 = extractvalue { i64, ptr } %t1465, 0
  %t1468 = icmp eq i64 %t1466, 0
  br i1 %t1468, label %bb300, label %bb301
bb299:
  %t1470 = load %"compiler/free:leaf", ptr %l694
  store %"compiler/free:leaf" %t1470, ptr %l54
  store ptr %l49, ptr %l703, !tbaa !29
  %t1471 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t1472 = getelementptr %"compiler/free:leaf", ptr %l54, i32 0, i32 1
  %t1473 = load i64, ptr %t1472, !tbaa !24
  %t1476 = call i64 @compiler_2ffree_2eorig(i64 %t1471, i64 %t1473)
  store i64 %t1476, ptr %l706
  br label %bb302
bb300:
  %t1477 = getelementptr %"compiler/free:leaf", ptr %l694, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1477, !tbaa !27
  br label %bb301
bb301:
  %t1478 = getelementptr %"compiler/free:leaf", ptr %l694, i32 0, i32 0
  %t1479 = load i64, ptr %l695
  %t1480 = inttoptr i64 %t1479 to ptr
  %t1481 = load { i64, ptr }, ptr %t1478
  %t1482 = extractvalue { i64, ptr } %t1481, 1
  %t1483 = call ptr @__olang_region_or(ptr %t1482, ptr null)
  %t1484 = icmp ne ptr %t1483, null
  %t1485 = select i1 %t1484, ptr %t1483, ptr null
  call void @__olang_region_settle_in(ptr %t1480, ptr %t1485)
  br label %bb299
bb302:
  %t1486 = load ptr, ptr %l703, !tbaa !29
  %t1487 = load i64, ptr %l706, !tbaa !24
  %t1488 = call i64 @compiler_2ffree_2eaddTo(ptr %s26, ptr %t1486, i64 %t1487)
  store i64 %t1488, ptr %l707
  br label %bb303
bb303:
  call void @__olang_scope_close(ptr %s30)
  br label %bb304
bb304:
  %t1489 = load i64, ptr %l53, !tbaa !24
  %t1492 = add i64 %t1489, 1
  store i64 %t1492, ptr %l53, !tbaa !24
  br label %bb290
bb305:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  br label %bb306
bb306:
  %t1494 = load ptr, ptr %l0, !tbaa !29
  %t1496 = getelementptr %"compiler/free:walker", ptr %t1494, i32 0, i32 2
  %t1497 = load i1, ptr %t1496, !tbaa !21
  %t1499 = xor i1 %t1497, true
  br i1 %t1499, label %bb307, label %bb308
bb307:
  %t1501 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %s26, ptr %t1501, ptr %l49)
  br label %bb309
bb308:
  br label %bb310
bb309:
  br label %bb310
bb310:
  %t1504 = load ptr, ptr %l0, !tbaa !29
  %t1506 = getelementptr %"compiler/free:walker", ptr %t1504, i32 0, i32 2
  %t1507 = load i1, ptr %t1506, !tbaa !21
  br i1 %t1507, label %bb311, label %bb312
bb311:
  %t1509 = load ptr, ptr %l0, !tbaa !29
  %t1511 = getelementptr %"compiler/free:walker", ptr %t1509, i32 0, i32 0
  %t1512 = load ptr, ptr %t1511, !tbaa !29
  %t1514 = getelementptr %"compiler/free:Free", ptr %t1512, i32 0, i32 156
  %t1515 = load ptr, ptr %l0, !tbaa !29
  %t1517 = getelementptr %"compiler/free:walker", ptr %t1515, i32 0, i32 1
  %t1518 = load i64, ptr %t1517, !tbaa !24
  %t1521 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1514, i64 %t1518)
  store i1 %t1521, ptr %l724
  br label %bb313
bb312:
  store i1 false, ptr %l718, !tbaa !21
  br label %bb314
bb313:
  %t1522 = load i1, ptr %l724, !tbaa !21
  store i1 %t1522, ptr %l718, !tbaa !21
  br label %bb314
bb314:
  %t1523 = load i1, ptr %l718, !tbaa !21
  br i1 %t1523, label %bb315, label %bb316
bb315:
  %t1524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1524, ptr %l725, !tbaa !29
  store ptr %l49, ptr %l726, !tbaa !29
  %t1525 = load ptr, ptr %l1, !tbaa !29
  %t1527 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t1525)
  store %"compiler/source:Span" %t1527, ptr %l728
  br label %bb317
bb316:
  br label %bb319
bb317:
  %t1528 = load ptr, ptr %l725, !tbaa !29
  %t1529 = load ptr, ptr %l726, !tbaa !29
  %t1530 = load %"compiler/source:Span", ptr %l728
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereturnedOwnLocals(ptr %v0, ptr %s26, ptr %t1528, ptr %t1529, %"compiler/source:Span" %t1530)
  br label %bb318
bb318:
  br label %bb319
bb319:
  call void @__olang_scope_close(ptr %s26)
  br label %bb320
bb320:
  %t1531 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1531, ptr %l729, !tbaa !29
  store i1 false, ptr %l730, !tbaa !21
  %t1532 = load ptr, ptr %l729, !tbaa !29
  %t1533 = icmp ne ptr %t1532, null
  br i1 %t1533, label %bb321, label %bb322
bb321:
  %t1535 = load ptr, ptr %l729, !tbaa !29
  %t1536 = load i64, ptr %t1535, !range !{i64 0, i64 17}
  %t1538 = icmp eq i64 %t1536, 16
  store i1 %t1538, ptr %l730, !tbaa !21
  br label %bb322
bb322:
  %t1539 = load i1, ptr %l730, !tbaa !21
  br i1 %t1539, label %bb323, label %bb324
bb323:
  %t1540 = load ptr, ptr %l1, !tbaa !29
  %t1542 = getelementptr { i64, [3 x i64] }, ptr %t1540, i32 0, i32 1
  %t1543 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1542, i32 0, i32 0
  %t1544 = load %"compiler/source:Span", ptr %t1543
  store %"compiler/source:Span" %t1544, ptr %l55
  br label %bb325
bb324:
  br label %bb328
bb325:
  store %olang.scope zeroinitializer, ptr %s34
  %t1546 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1546, ptr %l735, !tbaa !29
  %t1547 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t1547, ptr %l736, !tbaa !24
  %t1548 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  store i64 %t1548, ptr %l737, !tbaa !24
  %t1549 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t1549, ptr %l738
  %t1550 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s34, i32 0, i32 0)
  store %"compiler/source:Span" %t1550, ptr %l739
  br label %bb326
bb326:
  %t1551 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t1552 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1553 = load ptr, ptr %l735, !tbaa !29
  %t1554 = load i64, ptr %l736, !tbaa !24
  %t1555 = load i64, ptr %l737, !tbaa !24
  %t1556 = load %"compiler/source:Span", ptr %l738
  %t1557 = load %"compiler/source:Span", ptr %l739
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t1553, i64 %t1554, i64 %t1555, %"compiler/source:Span" %t1556, %"compiler/source:Span" %t1557, i64 -1, i1 false, i64 %t1551, i32 %t1552)
  br label %bb327
bb327:
  call void @__olang_scope_close(ptr %s34)
  br label %bb333
bb328:
  br i1 true, label %bb329, label %bb330
bb329:
  br label %bb331
bb330:
  br label %bb332
bb331:
  br label %bb333
bb332:
  call void @__olang_check_failed(ptr @olang_loc_5d7536cc463ccac1_135a9313c745645)
  unreachable
bb333:
  br label %bb502
bb334:
  %t1560 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1560, ptr %l742, !tbaa !29
  store i1 false, ptr %l743, !tbaa !21
  %t1561 = load ptr, ptr %l742, !tbaa !29
  %t1562 = icmp ne ptr %t1561, null
  br i1 %t1562, label %bb335, label %bb336
bb335:
  %t1564 = load ptr, ptr %l742, !tbaa !29
  %t1565 = load i64, ptr %t1564, !range !{i64 0, i64 17}
  %t1567 = icmp eq i64 %t1565, 10
  store i1 %t1567, ptr %l743, !tbaa !21
  br label %bb336
bb336:
  %t1568 = load i1, ptr %l743, !tbaa !21
  br i1 %t1568, label %bb337, label %bb338
bb337:
  %t1569 = load ptr, ptr %l1, !tbaa !29
  %t1571 = getelementptr { i64, [3 x i64] }, ptr %t1569, i32 0, i32 1
  %t1572 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1571, i32 0, i32 1
  %t1573 = load ptr, ptr %t1572
  store ptr %t1573, ptr %l56, !tbaa !29
  %t1575 = load ptr, ptr %l1, !tbaa !29
  %t1577 = getelementptr { i64, [3 x i64] }, ptr %t1575, i32 0, i32 1
  %t1578 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t1577, i32 0, i32 2
  %t1579 = load ptr, ptr %t1578
  store ptr %t1579, ptr %l57, !tbaa !29
  br label %bb339
bb338:
  br label %bb345
bb339:
  store %olang.scope zeroinitializer, ptr %s36
  %t1581 = load ptr, ptr %l0, !tbaa !29
  %t1582 = load ptr, ptr %l56, !tbaa !29
  %t1585 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s36, ptr %t1581, ptr %t1582)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1585, ptr %l752
  br label %bb340
bb340:
  %t1586 = load ptr, ptr %l57, !tbaa !29
  %t1588 = icmp eq ptr %t1586, null
  %t1590 = xor i1 %t1588, true
  br i1 %t1590, label %bb341, label %bb342
bb341:
  store %olang.scope zeroinitializer, ptr %s37
  %t1592 = load ptr, ptr %l0, !tbaa !29
  %t1593 = load ptr, ptr %l57, !tbaa !29
  %t1596 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s37, ptr %t1592, ptr %t1593)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1596, ptr %l758
  br label %bb343
bb342:
  br label %bb344
bb343:
  call void @__olang_scope_close(ptr %s37)
  br label %bb344
bb344:
  call void @__olang_scope_close(ptr %s36)
  br label %bb502
bb345:
  %t1597 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1597, ptr %l759, !tbaa !29
  store i1 false, ptr %l760, !tbaa !21
  %t1598 = load ptr, ptr %l759, !tbaa !29
  %t1599 = icmp ne ptr %t1598, null
  br i1 %t1599, label %bb346, label %bb347
bb346:
  %t1601 = load ptr, ptr %l759, !tbaa !29
  %t1602 = load i64, ptr %t1601, !range !{i64 0, i64 17}
  %t1604 = icmp eq i64 %t1602, 9
  store i1 %t1604, ptr %l760, !tbaa !21
  br label %bb347
bb347:
  %t1605 = load i1, ptr %l760, !tbaa !21
  br i1 %t1605, label %bb348, label %bb349
bb348:
  %t1606 = load ptr, ptr %l1, !tbaa !29
  %t1608 = getelementptr { i64, [3 x i64] }, ptr %t1606, i32 0, i32 1
  %t1609 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1608, i32 0, i32 2
  %t1610 = load ptr, ptr %t1609
  store ptr %t1610, ptr %l58, !tbaa !29
  br label %bb350
bb349:
  br label %bb355
bb350:
  %t1612 = load ptr, ptr %l58, !tbaa !29
  %t1614 = icmp eq ptr %t1612, null
  %t1616 = xor i1 %t1614, true
  br i1 %t1616, label %bb351, label %bb352
bb351:
  store %olang.scope zeroinitializer, ptr %s39
  %t1618 = load ptr, ptr %l0, !tbaa !29
  %t1619 = load ptr, ptr %l58, !tbaa !29
  %t1622 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s39, ptr %t1618, ptr %t1619)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1622, ptr %l770
  br label %bb353
bb352:
  br label %bb354
bb353:
  call void @__olang_scope_close(ptr %s39)
  br label %bb354
bb354:
  br label %bb502
bb355:
  %t1623 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1623, ptr %l771, !tbaa !29
  store i1 false, ptr %l772, !tbaa !21
  %t1624 = load ptr, ptr %l771, !tbaa !29
  %t1625 = icmp ne ptr %t1624, null
  br i1 %t1625, label %bb356, label %bb357
bb356:
  %t1627 = load ptr, ptr %l771, !tbaa !29
  %t1628 = load i64, ptr %t1627, !range !{i64 0, i64 17}
  %t1630 = icmp eq i64 %t1628, 11
  store i1 %t1630, ptr %l772, !tbaa !21
  br label %bb357
bb357:
  %t1631 = load i1, ptr %l772, !tbaa !21
  br i1 %t1631, label %bb358, label %bb359
bb358:
  %t1632 = load ptr, ptr %l1, !tbaa !29
  %t1634 = getelementptr { i64, [3 x i64] }, ptr %t1632, i32 0, i32 1
  %t1635 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1634, i32 0, i32 1
  %t1636 = load ptr, ptr %t1635
  store ptr %t1636, ptr %l59, !tbaa !29
  br label %bb360
bb359:
  br label %bb362
bb360:
  %t1638 = load ptr, ptr %l0, !tbaa !29
  %t1639 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1638, ptr %t1639)
  br label %bb361
bb361:
  br label %bb502
bb362:
  %t1642 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1642, ptr %l779, !tbaa !29
  store i1 false, ptr %l780, !tbaa !21
  %t1643 = load ptr, ptr %l779, !tbaa !29
  %t1644 = icmp ne ptr %t1643, null
  br i1 %t1644, label %bb363, label %bb364
bb363:
  %t1646 = load ptr, ptr %l779, !tbaa !29
  %t1647 = load i64, ptr %t1646, !range !{i64 0, i64 17}
  %t1649 = icmp eq i64 %t1647, 12
  store i1 %t1649, ptr %l780, !tbaa !21
  br label %bb364
bb364:
  %t1650 = load i1, ptr %l780, !tbaa !21
  br i1 %t1650, label %bb365, label %bb366
bb365:
  %t1651 = load ptr, ptr %l1, !tbaa !29
  %t1653 = getelementptr { i64, [3 x i64] }, ptr %t1651, i32 0, i32 1
  %t1654 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1653, i32 0, i32 1
  %t1655 = load ptr, ptr %t1654
  store ptr %t1655, ptr %l60, !tbaa !29
  br label %bb367
bb366:
  br label %bb378
bb367:
  %t1657 = load ptr, ptr %l0, !tbaa !29
  %t1659 = getelementptr %"compiler/free:walker", ptr %t1657, i32 0, i32 2
  %t1660 = load i1, ptr %t1659, !tbaa !21
  %t1662 = xor i1 %t1660, true
  br i1 %t1662, label %bb368, label %bb369
bb368:
  %t1664 = load ptr, ptr %l0, !tbaa !29
  %t1665 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescapedHolder(ptr %v0, ptr %v1, ptr %t1664, ptr %t1665)
  br label %bb370
bb369:
  br label %bb371
bb370:
  br label %bb371
bb371:
  %t1668 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1668, ptr %l790, !tbaa !29
  %t1669 = load ptr, ptr %l790, !tbaa !29
  %t1670 = getelementptr %"compiler/free:walker", ptr %t1669, i32 0, i32 35
  %t1671 = load i64, ptr %t1670, !tbaa !24
  %t1674 = add i64 %t1671, 1
  %t1676 = load ptr, ptr %l790, !tbaa !29
  %t1677 = getelementptr %"compiler/free:walker", ptr %t1676, i32 0, i32 35
  store i64 %t1674, ptr %t1677, !tbaa !24
  %t1678 = load ptr, ptr %l0, !tbaa !29
  %t1680 = getelementptr %"compiler/free:walker", ptr %t1678, i32 0, i32 100
  %t1681 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1680, i64 %t1681)
  br label %bb372
bb372:
  %t1684 = load ptr, ptr %l0, !tbaa !29
  %t1685 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1684, ptr %t1685)
  br label %bb373
bb373:
  %t1688 = load ptr, ptr %l0, !tbaa !29
  %t1690 = getelementptr %"compiler/free:walker", ptr %t1688, i32 0, i32 100
  %t1692 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t1690)
  %t1693 = extractvalue { i32, i64 } %t1692, 1
  %t1694 = extractvalue { i32, i64 } %t1692, 0
  store i32 %t1694, ptr %l803
  %t1695 = icmp ne i32 %t1694, 0
  br i1 %t1695, label %bb375, label %ok.1696, !prof !99
ok.1696:
  store i64 %t1693, ptr %l802
  br label %bb374
bb374:
  %t1697 = load i64, ptr %l802, !tbaa !24
  store i64 %t1697, ptr %l799, !tbaa !24
  br label %bb377
bb375:
  br label %bb376
bb376:
  br label %bb377
bb377:
  %t1698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1698, ptr %l804, !tbaa !29
  %t1699 = load ptr, ptr %l804, !tbaa !29
  %t1700 = getelementptr %"compiler/free:walker", ptr %t1699, i32 0, i32 35
  %t1701 = load i64, ptr %t1700, !tbaa !24
  %t1704 = sub i64 %t1701, 1
  %t1706 = load ptr, ptr %l804, !tbaa !29
  %t1707 = getelementptr %"compiler/free:walker", ptr %t1706, i32 0, i32 35
  store i64 %t1704, ptr %t1707, !tbaa !24
  br label %bb502
bb378:
  %t1708 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1708, ptr %l808, !tbaa !29
  store i1 false, ptr %l809, !tbaa !21
  %t1709 = load ptr, ptr %l808, !tbaa !29
  %t1710 = icmp ne ptr %t1709, null
  br i1 %t1710, label %bb379, label %bb380
bb379:
  %t1712 = load ptr, ptr %l808, !tbaa !29
  %t1713 = load i64, ptr %t1712, !range !{i64 0, i64 17}
  %t1715 = icmp eq i64 %t1713, 13
  store i1 %t1715, ptr %l809, !tbaa !21
  br label %bb380
bb380:
  %t1716 = load i1, ptr %l809, !tbaa !21
  br i1 %t1716, label %bb381, label %bb382
bb381:
  %t1717 = load ptr, ptr %l1, !tbaa !29
  %t1719 = getelementptr { i64, [3 x i64] }, ptr %t1717, i32 0, i32 1
  %t1720 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1719, i32 0, i32 1
  %t1721 = load ptr, ptr %t1720
  store ptr %t1721, ptr %l61, !tbaa !29
  br label %bb383
bb382:
  br label %bb416
bb383:
  %t1723 = load ptr, ptr %l0, !tbaa !29
  %t1725 = getelementptr %"compiler/free:walker", ptr %t1723, i32 0, i32 0
  %t1726 = load ptr, ptr %t1725, !tbaa !29
  %t1728 = getelementptr %"compiler/free:Free", ptr %t1726, i32 0, i32 97
  %t1729 = load ptr, ptr %l0, !tbaa !29
  %t1731 = getelementptr %"compiler/free:walker", ptr %t1729, i32 0, i32 1
  %t1732 = load i64, ptr %t1731, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1728, i64 %t1732, i1 true)
  br label %bb384
bb384:
  %t1735 = load ptr, ptr %l0, !tbaa !29
  %t1737 = getelementptr %"compiler/free:walker", ptr %t1735, i32 0, i32 2
  %t1738 = load i1, ptr %t1737, !tbaa !21
  br i1 %t1738, label %bb385, label %bb386
bb385:
  %t1740 = load ptr, ptr %l0, !tbaa !29
  %t1742 = getelementptr %"compiler/free:walker", ptr %t1740, i32 0, i32 36
  %t1743 = load i64, ptr %t1742, !tbaa !24
  %t1745 = icmp eq i64 %t1743, 0
  store i1 %t1745, ptr %l821, !tbaa !21
  br label %bb387
bb386:
  store i1 false, ptr %l821, !tbaa !21
  br label %bb387
bb387:
  %t1747 = load i1, ptr %l821, !tbaa !21
  br i1 %t1747, label %bb388, label %bb389
bb388:
  %t1748 = load ptr, ptr %l0, !tbaa !29
  %t1750 = getelementptr %"compiler/free:walker", ptr %t1748, i32 0, i32 42
  %t1751 = load ptr, ptr %l0, !tbaa !29
  %t1753 = getelementptr %"compiler/free:walker", ptr %t1751, i32 0, i32 0
  %t1754 = load ptr, ptr %t1753, !tbaa !29
  %t1756 = getelementptr %"compiler/free:Free", ptr %t1754, i32 0, i32 136
  %t1757 = load i64, ptr %t1756, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t1750, i64 %t1757)
  br label %bb390
bb389:
  br label %bb391
bb390:
  %t1760 = load ptr, ptr %l0, !tbaa !29
  %t1762 = getelementptr %"compiler/free:walker", ptr %t1760, i32 0, i32 0
  %t1763 = load ptr, ptr %t1762, !tbaa !29
  store ptr %t1763, ptr %l831, !tbaa !29
  %t1764 = load ptr, ptr %l831, !tbaa !29
  %t1765 = getelementptr %"compiler/free:Free", ptr %t1764, i32 0, i32 136
  %t1766 = load i64, ptr %t1765, !tbaa !24
  %t1769 = add i64 %t1766, 1
  %t1771 = load ptr, ptr %l831, !tbaa !29
  %t1772 = getelementptr %"compiler/free:Free", ptr %t1771, i32 0, i32 136
  store i64 %t1769, ptr %t1772, !tbaa !24
  br label %bb391
bb391:
  %t1773 = load ptr, ptr %l0, !tbaa !29
  %t1774 = load ptr, ptr %l61, !tbaa !29
  %t1776 = getelementptr %"compiler/typed:Join", ptr %t1774, i32 0, i32 0
  %t1777 = load ptr, ptr %t1776, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1773, ptr %t1777)
  br label %bb392
bb392:
  %t1780 = load ptr, ptr %l0, !tbaa !29
  %t1782 = getelementptr %"compiler/free:walker", ptr %t1780, i32 0, i32 2
  %t1783 = load i1, ptr %t1782, !tbaa !21
  br i1 %t1783, label %bb393, label %bb394
bb393:
  %t1785 = load ptr, ptr %l0, !tbaa !29
  %t1787 = getelementptr %"compiler/free:walker", ptr %t1785, i32 0, i32 36
  %t1788 = load i64, ptr %t1787, !tbaa !24
  %t1790 = icmp eq i64 %t1788, 0
  store i1 %t1790, ptr %l840, !tbaa !21
  br label %bb395
bb394:
  store i1 false, ptr %l840, !tbaa !21
  br label %bb395
bb395:
  %t1792 = load i1, ptr %l840, !tbaa !21
  br i1 %t1792, label %bb396, label %bb397
bb396:
  %t1793 = load ptr, ptr %l0, !tbaa !29
  %t1795 = getelementptr %"compiler/free:walker", ptr %t1793, i32 0, i32 42
  %t1797 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t1795)
  %t1798 = extractvalue { i32, i64 } %t1797, 1
  %t1799 = extractvalue { i32, i64 } %t1797, 0
  store i32 %t1799, ptr %l848
  %t1800 = icmp ne i32 %t1799, 0
  br i1 %t1800, label %bb399, label %ok.1801, !prof !99
ok.1801:
  store i64 %t1798, ptr %l847
  br label %bb398
bb397:
  br label %bb402
bb398:
  %t1802 = load i64, ptr %l847, !tbaa !24
  store i64 %t1802, ptr %l844, !tbaa !24
  br label %bb401
bb399:
  br label %bb400
bb400:
  br label %bb401
bb401:
  br label %bb402
bb402:
  %t1803 = load ptr, ptr %l61, !tbaa !29
  %t1805 = getelementptr %"compiler/typed:Join", ptr %t1803, i32 0, i32 2
  %t1806 = load { i64, ptr }, ptr %t1805, !tbaa !27
  store { i64, ptr } %t1806, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t1808 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1810 = extractvalue { i64, ptr } %t1808, 0
  store i64 %t1810, ptr %l64, !tbaa !24
  br label %bb403
bb403:
  %t1812 = load i64, ptr %l63, !tbaa !24
  %t1813 = load i64, ptr %l64, !tbaa !24
  %t1816 = icmp slt i64 %t1812, %t1813
  %t1818 = xor i1 %t1816, true
  br i1 %t1818, label %bb404, label %bb405
bb404:
  br label %bb415
bb405:
  br label %bb406
bb406:
  %t1820 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t1820, ptr %l857, !tbaa !27
  %t1821 = load i64, ptr %l63, !tbaa !24
  %t1823 = getelementptr { i64, ptr }, ptr %l857, i32 0, i32 1
  %t1824 = load ptr, ptr %t1823, !tbaa !27
  %t1825 = getelementptr ptr, ptr %t1824, i64 %t1821
  %t1826 = load ptr, ptr %t1825, !tbaa !39
  store ptr %t1826, ptr %l65, !tbaa !29
  %t1828 = load ptr, ptr %l65, !tbaa !29
  %t1830 = getelementptr %"compiler/typed:Clause", ptr %t1828, i32 0, i32 3
  %t1831 = load ptr, ptr %t1830, !tbaa !29
  %t1833 = icmp eq ptr %t1831, null
  %t1835 = xor i1 %t1833, true
  br i1 %t1835, label %bb407, label %bb408
bb407:
  %t1837 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1837, ptr %l864, !tbaa !29
  %t1838 = load ptr, ptr %l65, !tbaa !29
  %t1840 = getelementptr %"compiler/typed:Clause", ptr %t1838, i32 0, i32 3
  %t1841 = load ptr, ptr %t1840, !tbaa !29
  %t1843 = icmp eq ptr %t1841, null
  br i1 %t1843, label %bb409, label %bb410
bb408:
  br label %bb413
bb409:
  call void @__olang_check_failed(ptr @olang_loc_11c10ff2df4ccb13_a4bbf1166c590ff7)
  unreachable
bb410:
  br label %bb411
bb411:
  %t1845 = load ptr, ptr %l65, !tbaa !29
  %t1847 = getelementptr %"compiler/typed:Clause", ptr %t1845, i32 0, i32 3
  %t1848 = load ptr, ptr %t1847, !tbaa !29
  %t1849 = load ptr, ptr %l864, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1849, ptr %t1848)
  br label %bb412
bb412:
  br label %bb413
bb413:
  br label %bb414
bb414:
  %t1851 = load i64, ptr %l63, !tbaa !24
  %t1854 = add i64 %t1851, 1
  store i64 %t1854, ptr %l63, !tbaa !24
  br label %bb403
bb415:
  br label %bb502
bb416:
  %t1856 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1856, ptr %l873, !tbaa !29
  store i1 false, ptr %l874, !tbaa !21
  %t1857 = load ptr, ptr %l873, !tbaa !29
  %t1858 = icmp ne ptr %t1857, null
  br i1 %t1858, label %bb417, label %bb418
bb417:
  %t1860 = load ptr, ptr %l873, !tbaa !29
  %t1861 = load i64, ptr %t1860, !range !{i64 0, i64 17}
  %t1863 = icmp eq i64 %t1861, 14
  store i1 %t1863, ptr %l874, !tbaa !21
  br label %bb418
bb418:
  %t1864 = load i1, ptr %l874, !tbaa !21
  br i1 %t1864, label %bb419, label %bb420
bb419:
  %t1865 = load ptr, ptr %l1, !tbaa !29
  %t1867 = getelementptr { i64, [3 x i64] }, ptr %t1865, i32 0, i32 1
  %t1868 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1867, i32 0, i32 1
  %t1869 = load ptr, ptr %t1868
  store ptr %t1869, ptr %l66, !tbaa !29
  br label %bb421
bb420:
  br label %bb473
bb421:
  store %olang.scope zeroinitializer, ptr %s52
  %t1871 = load ptr, ptr %l0, !tbaa !29
  %t1873 = getelementptr %"compiler/free:walker", ptr %t1871, i32 0, i32 0
  %t1874 = load ptr, ptr %t1873, !tbaa !29
  %t1876 = getelementptr %"compiler/free:Free", ptr %t1874, i32 0, i32 97
  %t1877 = load ptr, ptr %l0, !tbaa !29
  %t1879 = getelementptr %"compiler/free:walker", ptr %t1877, i32 0, i32 1
  %t1880 = load i64, ptr %t1879, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1876, i64 %t1880, i1 true)
  br label %bb422
bb422:
  %t1883 = load ptr, ptr %l66, !tbaa !29
  %t1885 = getelementptr %"compiler/typed:Spawn", ptr %t1883, i32 0, i32 1
  %t1886 = load ptr, ptr %t1885, !tbaa !29
  %t1888 = call ptr @compiler_2ffree_2etaskCall(ptr %v1, ptr %s52, ptr %t1886)
  store ptr %t1888, ptr %l886
  br label %bb423
bb423:
  %t1889 = load ptr, ptr %l886, !tbaa !29
  %t1891 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %s52, ptr %s52, ptr %t1889)
  store ptr %t1891, ptr %l888
  br label %bb424
bb424:
  %t1892 = load ptr, ptr %l888, !tbaa !29
  store ptr %t1892, ptr %l67, !tbaa !29
  %t1893 = load ptr, ptr %l67, !tbaa !29
  %t1895 = icmp eq ptr %t1893, null
  %t1897 = xor i1 %t1895, true
  br i1 %t1897, label %bb425, label %bb426
bb425:
  %t1899 = load ptr, ptr %l67, !tbaa !29
  %t1901 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %s52, ptr %t1899)
  store i64 %t1901, ptr %l894
  br label %bb427
bb426:
  store i1 false, ptr %l892, !tbaa !21
  br label %bb428
bb427:
  %t1902 = load i64, ptr %l894, !tbaa !24
  %t1903 = icmp sge i64 %t1902, 0
  store i1 %t1903, ptr %l892, !tbaa !21
  br label %bb428
bb428:
  %t1905 = load i1, ptr %l892, !tbaa !21
  br i1 %t1905, label %bb429, label %bb430
bb429:
  %t1906 = load ptr, ptr %l0, !tbaa !29
  %t1908 = getelementptr %"compiler/free:walker", ptr %t1906, i32 0, i32 0
  %t1909 = load ptr, ptr %t1908, !tbaa !29
  %t1911 = getelementptr %"compiler/free:Free", ptr %t1909, i32 0, i32 124
  store ptr %t1911, ptr %l898, !tbaa !29
  %t1912 = load ptr, ptr %l67, !tbaa !29
  %t1914 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %s52, ptr %t1912)
  store i64 %t1914, ptr %l900
  br label %bb431
bb430:
  br label %bb433
bb431:
  %t1915 = load ptr, ptr %l898, !tbaa !29
  %t1916 = load i64, ptr %l900, !tbaa !24
  %t1917 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t1915, i64 %t1916)
  store i64 %t1917, ptr %l901
  br label %bb432
bb432:
  br label %bb433
bb433:
  %t1918 = load ptr, ptr %l0, !tbaa !29
  %t1920 = getelementptr %"compiler/free:walker", ptr %t1918, i32 0, i32 41
  %t1921 = load i64, ptr %t1920, !tbaa !24
  store i64 %t1921, ptr %l68, !tbaa !24
  %t1923 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1923, ptr %l904, !tbaa !29
  %t1924 = load ptr, ptr %l67, !tbaa !29
  %t1926 = icmp eq ptr %t1924, null
  %t1928 = xor i1 %t1926, true
  br i1 %t1928, label %bb434, label %bb435
bb434:
  %t1930 = load ptr, ptr %l67, !tbaa !29
  %t1932 = getelementptr %"compiler/typed:Call", ptr %t1930, i32 0, i32 2
  %t1933 = load i32, ptr %t1932, !tbaa !23
  %t1935 = sext i32 %t1933 to i64
  store i64 %t1935, ptr %l908, !tbaa !24
  br label %bb436
bb435:
  store i64 -1, ptr %l908, !tbaa !24
  br label %bb436
bb436:
  %t1937 = load i64, ptr %l908, !tbaa !24
  %t1938 = load ptr, ptr %l904, !tbaa !29
  %t1939 = getelementptr %"compiler/free:walker", ptr %t1938, i32 0, i32 41
  store i64 %t1937, ptr %t1939, !tbaa !24
  %t1940 = load ptr, ptr %l0, !tbaa !29
  %t1941 = load ptr, ptr %l66, !tbaa !29
  %t1943 = getelementptr %"compiler/typed:Spawn", ptr %t1941, i32 0, i32 1
  %t1944 = load ptr, ptr %t1943, !tbaa !29
  %t1947 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s52, ptr %t1940, ptr %t1944)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1947, ptr %l915
  br label %bb437
bb437:
  %t1948 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l915
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1948, ptr %l69
  %t1949 = load ptr, ptr %l0, !tbaa !29
  %t1950 = load i64, ptr %l68, !tbaa !24
  %t1953 = getelementptr %"compiler/free:walker", ptr %t1949, i32 0, i32 41
  store i64 %t1950, ptr %t1953, !tbaa !24
  %t1954 = load ptr, ptr %l66, !tbaa !29
  %t1956 = getelementptr %"compiler/typed:Spawn", ptr %t1954, i32 0, i32 2
  %t1957 = load { i64, ptr }, ptr %t1956, !tbaa !27
  store { i64, ptr } %t1957, ptr %l70, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  %t1959 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t1961 = extractvalue { i64, ptr } %t1959, 0
  store i64 %t1961, ptr %l72, !tbaa !24
  br label %bb438
bb438:
  %t1963 = load i64, ptr %l71, !tbaa !24
  %t1964 = load i64, ptr %l72, !tbaa !24
  %t1967 = icmp slt i64 %t1963, %t1964
  %t1969 = xor i1 %t1967, true
  br i1 %t1969, label %bb439, label %bb440
bb439:
  br label %bb450
bb440:
  br label %bb441
bb441:
  %t1971 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t1971, ptr %l926, !tbaa !27
  %t1972 = load i64, ptr %l71, !tbaa !24
  %t1974 = getelementptr { i64, ptr }, ptr %l926, i32 0, i32 1
  %t1975 = load ptr, ptr %t1974, !tbaa !27
  %t1976 = getelementptr ptr, ptr %t1975, i64 %t1972
  %t1977 = load ptr, ptr %t1976, !tbaa !39
  store ptr %t1977, ptr %l73, !tbaa !29
  %t1979 = load ptr, ptr %l73, !tbaa !29
  %t1981 = getelementptr %"compiler/typed:TaskClause", ptr %t1979, i32 0, i32 3
  %t1982 = load ptr, ptr %t1981, !tbaa !29
  %t1984 = icmp eq ptr %t1982, null
  %t1986 = xor i1 %t1984, true
  br i1 %t1986, label %bb442, label %bb443
bb442:
  store %olang.scope zeroinitializer, ptr %s56
  %t1988 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1988, ptr %l933, !tbaa !29
  %t1989 = load ptr, ptr %l73, !tbaa !29
  %t1991 = getelementptr %"compiler/typed:TaskClause", ptr %t1989, i32 0, i32 3
  %t1992 = load ptr, ptr %t1991, !tbaa !29
  %t1994 = icmp eq ptr %t1992, null
  br i1 %t1994, label %bb444, label %bb445
bb443:
  br label %bb448
bb444:
  call void @__olang_check_failed(ptr @olang_loc_407beb7582aa5744_e540dc6ed5e7bfd8)
  unreachable
bb445:
  br label %bb446
bb446:
  %t1996 = load ptr, ptr %l73, !tbaa !29
  %t1998 = getelementptr %"compiler/typed:TaskClause", ptr %t1996, i32 0, i32 3
  %t1999 = load ptr, ptr %t1998, !tbaa !29
  %t2000 = load ptr, ptr %l933, !tbaa !29
  %t2002 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s56, ptr %t2000, ptr %t1999)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2002, ptr %l939
  br label %bb447
bb447:
  call void @__olang_scope_close(ptr %s56)
  br label %bb448
bb448:
  br label %bb449
bb449:
  %t2003 = load i64, ptr %l71, !tbaa !24
  %t2006 = add i64 %t2003, 1
  store i64 %t2006, ptr %l71, !tbaa !24
  br label %bb438
bb450:
  %t2008 = load ptr, ptr %l66, !tbaa !29
  %t2010 = getelementptr %"compiler/typed:Spawn", ptr %t2008, i32 0, i32 0
  %t2011 = load { i64, ptr }, ptr %t2010, !tbaa !27
  store { i64, ptr } %t2011, ptr %l74, !tbaa !27
  store i64 0, ptr %l75, !tbaa !24
  %t2013 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2015 = extractvalue { i64, ptr } %t2013, 0
  store i64 %t2015, ptr %l76, !tbaa !24
  br label %bb451
bb451:
  %t2017 = load i64, ptr %l75, !tbaa !24
  %t2018 = load i64, ptr %l76, !tbaa !24
  %t2021 = icmp slt i64 %t2017, %t2018
  %t2023 = xor i1 %t2021, true
  br i1 %t2023, label %bb452, label %bb453
bb452:
  br label %bb461
bb453:
  br label %bb454
bb454:
  %t2025 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t2025, ptr %l951, !tbaa !27
  %t2026 = load i64, ptr %l75, !tbaa !24
  %t2028 = getelementptr { i64, ptr }, ptr %l951, i32 0, i32 1
  %t2029 = load ptr, ptr %t2028, !tbaa !27
  %t2030 = getelementptr ptr, ptr %t2029, i64 %t2026
  %t2031 = load ptr, ptr %t2030, !tbaa !39
  store ptr %t2031, ptr %l77, !tbaa !29
  %t2033 = load ptr, ptr %l77, !tbaa !29
  %t2035 = icmp eq ptr %t2033, null
  %t2037 = xor i1 %t2035, true
  br i1 %t2037, label %bb455, label %bb456
bb455:
  %t2039 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2039, ptr %l957, !tbaa !29
  %t2040 = load ptr, ptr %l1, !tbaa !29
  %t2042 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t2040)
  store %"compiler/source:Span" %t2042, ptr %l959
  br label %bb457
bb456:
  br label %bb459
bb457:
  %t2043 = load ptr, ptr %l66, !tbaa !29
  %t2044 = load ptr, ptr %l77, !tbaa !29
  %t2045 = load ptr, ptr %l67, !tbaa !29
  %t2046 = load ptr, ptr %l957, !tbaa !29
  %t2047 = load %"compiler/source:Span", ptr %l959
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2espawnLets(ptr %v0, ptr %v1, ptr %v1, ptr %s52, ptr %s52, ptr %t2046, %"compiler/source:Span" %t2047, ptr %t2043, ptr %t2044, ptr %l69, ptr %t2045)
  br label %bb458
bb458:
  br label %bb459
bb459:
  br label %bb460
bb460:
  %t2052 = load i64, ptr %l75, !tbaa !24
  %t2055 = add i64 %t2052, 1
  store i64 %t2055, ptr %l75, !tbaa !24
  br label %bb451
bb461:
  %t2057 = load ptr, ptr %l0, !tbaa !29
  %t2059 = getelementptr %"compiler/free:walker", ptr %t2057, i32 0, i32 2
  %t2060 = load i1, ptr %t2059, !tbaa !21
  br i1 %t2060, label %bb462, label %bb463
bb462:
  %t2062 = load ptr, ptr %l0, !tbaa !29
  %t2064 = getelementptr %"compiler/free:walker", ptr %t2062, i32 0, i32 36
  %t2065 = load i64, ptr %t2064, !tbaa !24
  %t2067 = icmp eq i64 %t2065, 0
  store i1 %t2067, ptr %l969, !tbaa !21
  br label %bb464
bb463:
  store i1 false, ptr %l969, !tbaa !21
  br label %bb464
bb464:
  %t2069 = load i1, ptr %l969, !tbaa !21
  br i1 %t2069, label %bb465, label %bb466
bb465:
  %t2070 = load ptr, ptr %l0, !tbaa !29
  %t2072 = getelementptr %"compiler/free:walker", ptr %t2070, i32 0, i32 0
  %t2073 = load ptr, ptr %t2072, !tbaa !29
  %t2074 = load ptr, ptr %l0, !tbaa !29
  %t2076 = getelementptr %"compiler/free:walker", ptr %t2074, i32 0, i32 1
  %t2077 = load i64, ptr %t2076, !tbaa !24
  %t2080 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisLive(ptr %v0, ptr %t2073, i64 %t2077)
  store i1 %t2080, ptr %l978
  br label %bb467
bb466:
  store i1 false, ptr %l973, !tbaa !21
  br label %bb468
bb467:
  %t2081 = load i1, ptr %l978, !tbaa !21
  store i1 %t2081, ptr %l973, !tbaa !21
  br label %bb468
bb468:
  %t2082 = load i1, ptr %l973, !tbaa !21
  br i1 %t2082, label %bb469, label %bb470
bb469:
  %t2083 = load ptr, ptr %l0, !tbaa !29
  %t2084 = load ptr, ptr %l66, !tbaa !29
  %t2085 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2espawnSite(ptr %v0, ptr %v1, ptr %s52, ptr %t2083, ptr %t2084, ptr %t2085)
  br label %bb471
bb470:
  br label %bb472
bb471:
  br label %bb472
bb472:
  call void @__olang_scope_close(ptr %s52)
  br label %bb502
bb473:
  %t2089 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2089, ptr %l982, !tbaa !29
  store i1 false, ptr %l983, !tbaa !21
  %t2090 = load ptr, ptr %l982, !tbaa !29
  %t2091 = icmp ne ptr %t2090, null
  br i1 %t2091, label %bb474, label %bb475
bb474:
  %t2093 = load ptr, ptr %l982, !tbaa !29
  %t2094 = load i64, ptr %t2093, !range !{i64 0, i64 17}
  %t2096 = icmp eq i64 %t2094, 15
  store i1 %t2096, ptr %l983, !tbaa !21
  br label %bb475
bb475:
  %t2097 = load i1, ptr %l983, !tbaa !21
  br i1 %t2097, label %bb476, label %bb477
bb476:
  %t2098 = load ptr, ptr %l1, !tbaa !29
  %t2100 = getelementptr { i64, [3 x i64] }, ptr %t2098, i32 0, i32 1
  %t2101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t2100, i32 0, i32 0
  %t2102 = load %"compiler/source:Span", ptr %t2101
  store %"compiler/source:Span" %t2102, ptr %l78
  %t2104 = load ptr, ptr %l1, !tbaa !29
  %t2106 = getelementptr { i64, [3 x i64] }, ptr %t2104, i32 0, i32 1
  %t2107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t2106, i32 0, i32 1
  %t2108 = load ptr, ptr %t2107
  store ptr %t2108, ptr %l79, !tbaa !29
  br label %bb478
bb477:
  br label %bb497
bb478:
  store %olang.scope zeroinitializer, ptr %s63
  %t2110 = load ptr, ptr %l0, !tbaa !29
  %t2111 = load ptr, ptr %l79, !tbaa !29
  %t2114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s63, ptr %t2110, ptr %t2111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2114, ptr %l992
  br label %bb479
bb479:
  %t2115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l992
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2115, ptr %l80
  %t2116 = load ptr, ptr %l0, !tbaa !29
  %t2118 = getelementptr %"compiler/free:walker", ptr %t2116, i32 0, i32 64
  %t2120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t2118)
  store i64 %t2120, ptr %l995
  br label %bb480
bb480:
  %t2121 = load i64, ptr %l995, !tbaa !24
  %t2122 = icmp sgt i64 %t2121, 0
  br i1 %t2122, label %bb481, label %bb482
bb481:
  %t2124 = load ptr, ptr %l0, !tbaa !29
  %t2126 = getelementptr %"compiler/free:walker", ptr %t2124, i32 0, i32 64
  store ptr %t2126, ptr %l998, !tbaa !29
  %t2127 = load ptr, ptr %l0, !tbaa !29
  %t2129 = getelementptr %"compiler/free:walker", ptr %t2127, i32 0, i32 64
  %t2131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t2129)
  store i64 %t2131, ptr %l1001
  br label %bb483
bb482:
  br label %bb486
bb483:
  %t2132 = load i64, ptr %l1001, !tbaa !24
  %t2133 = sub i64 %t2132, 1
  %t2134 = load ptr, ptr %l998, !tbaa !29
  %t2136 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t2134, i64 %t2133)
  store ptr %t2136, ptr %l1003
  br label %bb484
bb484:
  %t2137 = load ptr, ptr %l1003, !tbaa !29
  %t2139 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %s63, ptr %t2137, ptr %l80)
  store i64 %t2139, ptr %l1005
  br label %bb485
bb485:
  br label %bb486
bb486:
  %t2140 = load ptr, ptr %l0, !tbaa !29
  %t2142 = getelementptr %"compiler/free:walker", ptr %t2140, i32 0, i32 13
  %t2144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t2142)
  store i64 %t2144, ptr %l1008
  br label %bb487
bb487:
  %t2145 = load i64, ptr %l1008, !tbaa !24
  %t2146 = icmp sgt i64 %t2145, 0
  br i1 %t2146, label %bb488, label %bb489
bb488:
  %t2148 = load ptr, ptr %l0, !tbaa !29
  %t2150 = getelementptr %"compiler/free:walker", ptr %t2148, i32 0, i32 13
  store ptr %t2150, ptr %l1011, !tbaa !29
  %t2151 = load ptr, ptr %l0, !tbaa !29
  %t2153 = getelementptr %"compiler/free:walker", ptr %t2151, i32 0, i32 13
  %t2155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t2153)
  store i64 %t2155, ptr %l1014
  br label %bb490
bb489:
  br label %bb496
bb490:
  %t2156 = load i64, ptr %l1014, !tbaa !24
  %t2157 = sub i64 %t2156, 1
  %t2158 = load ptr, ptr %l1011, !tbaa !29
  %t2160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t2158, i64 %t2157)
  store i64 %t2160, ptr %l1016
  br label %bb491
bb491:
  %t2161 = load i64, ptr %l1016, !tbaa !24
  store i64 %t2161, ptr %l81, !tbaa !24
  %t2162 = load i64, ptr %l81, !tbaa !24
  %t2164 = icmp sge i64 %t2162, 0
  br i1 %t2164, label %bb492, label %bb493
bb492:
  store %olang.scope zeroinitializer, ptr %s66
  %t2166 = load ptr, ptr %l0, !tbaa !29
  %t2167 = load i64, ptr %l81, !tbaa !24
  %t2168 = load ptr, ptr %l79, !tbaa !29
  %t2169 = load %"compiler/source:Span", ptr %l78
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %s63, ptr %s66, ptr %t2166, i64 %t2167, ptr %t2168, ptr %l80, %"compiler/source:Span" %t2169, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, i1 true)
  br label %bb494
bb493:
  br label %bb495
bb494:
  call void @__olang_scope_close(ptr %s66)
  br label %bb495
bb495:
  br label %bb496
bb496:
  call void @__olang_scope_close(ptr %s63)
  br label %bb502
bb497:
  br i1 true, label %bb498, label %bb499
bb498:
  br label %bb500
bb499:
  br label %bb501
bb500:
  br label %bb502
bb501:
  call void @__olang_check_failed(ptr @olang_loc_ec0dfed271d7eacc_f2c899624053798)
  unreachable
bb502:
  %t2175 = load ptr, ptr %l0, !tbaa !29
  %t2177 = getelementptr %"compiler/free:walker", ptr %t2175, i32 0, i32 16
  %t2178 = load i64, ptr %l2, !tbaa !24
  %t2179 = load ptr, ptr %l0, !tbaa !29
  %t2181 = getelementptr %"compiler/free:walker", ptr %t2179, i32 0, i32 14
  %t2182 = load i64, ptr %t2181, !tbaa !24
  %t2184 = sub i64 %t2182, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t2177, i64 %t2178, i64 %t2184)
  br label %bb503
bb503:
  %t2188 = load ptr, ptr %l0, !tbaa !29
  %t2189 = load i64, ptr %l3, !tbaa !24
  %t2192 = getelementptr %"compiler/free:walker", ptr %t2188, i32 0, i32 15
  store i64 %t2189, ptr %t2192, !tbaa !24
  %t2193 = load ptr, ptr %l0, !tbaa !29
  %t2194 = load %"compiler/source:Span", ptr %l4
  %t2197 = getelementptr %"compiler/free:walker", ptr %t2193, i32 0, i32 65
  store %"compiler/source:Span" %t2194, ptr %t2197
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"compiler/typed:Local"
  %l60 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca %"compiler/typed:Local"
  %l71 = alloca i64
  %l81 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i1
  %l118 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Body", ptr %t5, i32 0, i32 7
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load i64, ptr %l22, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l30, !tbaa !24
  store i64 %t39, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l10, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l48, !tbaa !29
  %t60 = call ptr @__olang_scope_hold(ptr %v2)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l49, !tbaa !24
  %t62 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = call ptr @__olang_region_make(ptr %v2)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l49, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l49
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t67, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l51
  br label %bb15
bb15:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  %t70 = load i64, ptr %l49
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call ptr @__olang_scope_alloc_a(ptr %t71, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t72
  %t73 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v2, ptr %v2, ptr %t73, ptr %t72)
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t75, i32 0, i32 7
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t77, i64 %t78)
  store %"compiler/typed:Local" %t81, ptr %l56
  br label %bb17
bb17:
  %t82 = getelementptr %"compiler/typed:Local", ptr %l56, i32 0, i32 4
  %t83 = load i32, ptr %t82, !range !{i32 0, i32 7}
  %t85 = trunc i64 5 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb18, label %bb19
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:walker", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 35
  store ptr %t95, ptr %l63, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t96)
  store ptr %t98, ptr %l65
  br label %bb20
bb19:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb23
bb20:
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 7
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t101, i64 %t102)
  store %"compiler/typed:Local" %t105, ptr %l69
  br label %bb21
bb21:
  %t106 = getelementptr %"compiler/typed:Local", ptr %l69, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load ptr, ptr %l63, !tbaa !29
  %t109 = load ptr, ptr %l65, !tbaa !29
  %t111 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v0, ptr %t108, ptr %t109, i32 %t107)
  store i64 %t111, ptr %l71
  br label %bb22
bb22:
  %t112 = load i64, ptr @G_2ecompiler_2fmir_2eViewNone, !tbaa !24
  %t113 = load i64, ptr %l71, !tbaa !24
  %t115 = icmp ne i64 %t113, %t112
  store i1 %t115, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t117 = load i1, ptr %l60, !tbaa !21
  br i1 %t117, label %bb24, label %bb25
bb24:
  %t119 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %a1, i64 %t119)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l9, !tbaa !24
  br label %bb9
bb29:
  store i64 0, ptr %l11, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/free:walker", ptr %t127, i32 0, i32 31
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l81
  br label %bb30
bb30:
  %t132 = load i64, ptr %l81, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = icmp sgt i64 %t133, %t134
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load i64, ptr %l13, !tbaa !24
  %t141 = icmp sgt i64 %t139, 0
  br i1 %t141, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb36
bb33:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l11, !tbaa !24
  %t147 = sub i64 %t143, %t144
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = add i64 %t147, %t148
  %t153 = sub i64 %t151, 1
  %t154 = load i64, ptr %l13, !tbaa !24
  %t157 = sdiv i64 %t153, %t154
  store i64 %t157, ptr %l88, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb35
bb35:
  %t159 = load i64, ptr %l88, !tbaa !24
  store i64 %t159, ptr %l85, !tbaa !24
  br label %bb36
bb36:
  %t160 = load i64, ptr %l85, !tbaa !24
  store i64 %t160, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb37
bb37:
  %t161 = load i64, ptr %l15, !tbaa !24
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb38, label %bb39
bb38:
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l13, !tbaa !24
  %t174 = mul i64 %t170, %t171
  %t177 = add i64 %t169, %t174
  store i64 %t177, ptr %l16, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/free:walker", ptr %t179, i32 0, i32 31
  %t182 = load i64, ptr %l16, !tbaa !24
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182)
  store i64 %t185, ptr %l109
  br label %bb41
bb41:
  %t186 = load i64, ptr %l109, !tbaa !24
  store i64 %t186, ptr %l17, !tbaa !24
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sge i64 %t187, 0
  br i1 %t189, label %bb42, label %bb43
bb42:
  %t191 = load i64, ptr %l17, !tbaa !24
  %t192 = load i64, ptr %l4, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  store i1 %t195, ptr %l112, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb44
bb44:
  %t197 = load i1, ptr %l112, !tbaa !21
  br i1 %t197, label %bb45, label %bb46
bb45:
  %t198 = load ptr, ptr %l2, !tbaa !29
  %t199 = load i64, ptr %l17, !tbaa !24
  %t202 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v2, ptr %v2, ptr %t198, i64 %t199)
  store ptr %t202, ptr %l118
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t203 = load i64, ptr %l16, !tbaa !24
  %t204 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t204, i64 %t203)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t206 = load i64, ptr %l15, !tbaa !24
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %l15, !tbaa !24
  br label %bb37
bb51:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2efnRecOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t20 = mul i64 2, %t18
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb19
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 3}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l2, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t37 = load i32, ptr %l2, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t41 = mul i64 2, %t39
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb19
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 3}
  %t50 = icmp eq i64 %t48, 2
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { i32, ptr, i32 }, ptr %t54, i32 0, i32 0
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l3, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t58 = load i32, ptr %l3, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t62 = mul i64 2, %t60
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l4, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d719bd699dd81eb8_57808ee921a55224)
  unreachable
bb19:
  %t66 = load i64, ptr %l4, !tbaa !24
  store i64 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2elvRootLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb32
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2ffree_2elvRootLocal(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l21
  br label %bb12
bb12:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb32
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Elem", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2ffree_2elvRootLocal(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l30
  br label %bb19
bb19:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb32
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 8}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Payload", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call i64 @compiler_2ffree_2elvRootLocal(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l39
  br label %bb26
bb26:
  %t82 = load i64, ptr %l39, !tbaa !24
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_c9e9f8077eba1692_49188e33d38a4896)
  unreachable
bb32:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2etakenOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  br label %bb18
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 17
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2etakenOf(ptr %v0, ptr %v1, ptr %t34)
  store ptr %t36, ptr %l19
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l19, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_86cff9656251f047_ec3335fc0049a713)
  unreachable
bb18:
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i32
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i32
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i1
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i1
  %l84 = alloca i1
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca { i64, ptr }
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i32
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %t16)
  %t19 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t18, 1
  %t20 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t18, 0
  store i32 %t20, ptr %l20
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb7, label %ok.22, !prof !99
ok.22:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l19
  br label %bb6
bb6:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l17
  br label %bb8
bb7:
  %t24 = load i32, ptr %l20, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t24, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t26
  %t32 = select i1 %t29, i32 0, i32 %t31
  %t34 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t32, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t34, ptr %rv
  br label %ret
bb8:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t36 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 11
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Cond", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t60 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t60, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Cond", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9500bd9cb83e9e6a_a32a388bbeb50dae)
  unreachable
bb19:
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Cond", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %t71)
  %t74 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t73, 1
  %t75 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t73, 0
  store i32 %t75, ptr %l39
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb22, label %ok.77, !prof !99
ok.77:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l38
  br label %bb21
bb21:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l32
  br label %bb23
bb22:
  %t79 = load i32, ptr %l39, !tbaa !23
  %t80 = lshr i32 %t79, 16
  %t81 = and i32 %t79, 65535
  %t82 = icmp eq i32 %t80, 1
  %t83 = select i1 %t82, i32 1, i32 0
  %t84 = icmp eq i32 %t79, 0
  %t85 = shl i32 %t83, 16
  %t86 = or i32 %t85, %t81
  %t87 = select i1 %t84, i32 0, i32 %t86
  %t89 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t87, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t89, ptr %rv
  br label %ret
bb23:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l3
  store %olang.scope zeroinitializer, ptr %s4
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Cond", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %s4, ptr %t94)
  %t97 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t96, 1
  %t98 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t96, 0
  store i32 %t98, ptr %l44
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb25, label %ok.100, !prof !99
ok.100:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l43
  br label %bb24
bb24:
  %t101 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t102 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %t102
  store ptr %t102, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb26
bb25:
  %t104 = load i32, ptr %l44, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  call void @__olang_scope_close(ptr %s4)
  %t114 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t112, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t114, ptr %rv
  br label %ret
bb26:
  %t115 = load i64, ptr %l5, !tbaa !24
  store i64 %t115, ptr %l47, !tbaa !24
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t116)
  store i64 %t118, ptr %l49
  br label %bb27
bb27:
  %t119 = load i64, ptr %l47, !tbaa !24
  %t120 = load i64, ptr %l49, !tbaa !24
  %t121 = icmp slt i64 %t119, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t126 = load i64, ptr %l5, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l54
  br label %bb31
bb31:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t134 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %l3, i64 %t130)
  store i64 %t134, ptr %l57
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l5, !tbaa !24
  br label %bb26
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t142 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t142, ptr %rv
  br label %ret
bb36:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t144 = load ptr, ptr %l62, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb37, label %bb38
bb37:
  %t147 = load ptr, ptr %l62, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 15
  store i1 %t150, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l63, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t158 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %l68
  br label %bb42
bb42:
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l8
  store ptr %l8, ptr %l69, !tbaa !29
  %t160 = load ptr, ptr %l7, !tbaa !29
  %t162 = call i64 @compiler_2ffree_2efnRecOf(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l71
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l69, !tbaa !29
  %t164 = load i64, ptr %l71, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t163, i64 %t164)
  br label %bb44
bb44:
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t167 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t167, ptr %rv
  br label %ret
bb45:
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t169 = load ptr, ptr %l73, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb46, label %bb47
bb46:
  %t172 = load ptr, ptr %l73, !tbaa !29
  %t173 = load i64, ptr %t172, !range !{i64 0, i64 18}
  %t175 = icmp eq i64 %t173, 9
  store i1 %t175, ptr %l74, !tbaa !21
  br label %bb47
bb47:
  %t176 = load i1, ptr %l74, !tbaa !21
  br i1 %t176, label %bb48, label %bb49
bb48:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t179, i32 0, i32 2
  %t181 = load i32, ptr %t180, !range !{i32 0, i32 54}
  store i32 %t181, ptr %l9
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t185, i32 0, i32 4
  %t187 = load { i64, ptr }, ptr %t186
  store { i64, ptr } %t187, ptr %l10, !tbaa !27
  br label %bb50
bb49:
  br label %bb60
bb50:
  %t189 = load i32, ptr %l9, !range !{i32 0, i32 54}
  %t191 = trunc i64 20 to i32
  %t192 = icmp eq i32 %t189, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb53
bb52:
  %t196 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t200 = icmp ne i64 %t198, 1
  store i1 %t200, ptr %l84, !tbaa !21
  br label %bb53
bb53:
  %t202 = load i1, ptr %l84, !tbaa !21
  br i1 %t202, label %bb54, label %bb55
bb54:
  %t204 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t204, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t205 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t205, ptr %l90, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr ptr, ptr %t207, i64 0
  %t209 = load ptr, ptr %t208, !tbaa !39
  %t211 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %t209)
  %t212 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t211, 1
  %t213 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t211, 0
  store i32 %t213, ptr %l93
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb58, label %ok.215, !prof !99
ok.215:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l92
  br label %bb57
bb57:
  %t216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %l89
  br label %bb59
bb58:
  %t217 = load i32, ptr %l93, !tbaa !23
  %t218 = lshr i32 %t217, 16
  %t219 = and i32 %t217, 65535
  %t220 = icmp eq i32 %t218, 1
  %t221 = select i1 %t220, i32 1, i32 0
  %t222 = icmp eq i32 %t217, 0
  %t223 = shl i32 %t221, 16
  %t224 = or i32 %t223, %t219
  %t225 = select i1 %t222, i32 0, i32 %t224
  %t227 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t225, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t227, ptr %rv
  br label %ret
bb59:
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  %t229 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t229, ptr %rv
  br label %ret
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t231 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t231, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_624ae5f0ecf6c3f8_e9900904abc8988c)
  unreachable
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8) #0 {
entry:
  %rv = alloca %"compiler/free:letGo"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:letGo" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:letGo" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:letGo" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:letGo" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:letGo" %t26, %"compiler/source:Span" %a4, 4
  %t30 = insertvalue %"compiler/free:letGo" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:letGo" %t30, %"compiler/source:Span" %a6, 6
  %t34 = insertvalue %"compiler/free:letGo" %t32, i64 %a7, 7
  %t36 = insertvalue %"compiler/free:letGo" %t34, i1 %a8, 8
  store %"compiler/free:letGo" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:letGo", ptr %rv
  ret %"compiler/free:letGo" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2ffree_3aleaf_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d0 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"free: hidden let-go in " }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2ejoinReached_2elocal_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_region_release(ptr) noinline
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c", and the join's code lets go of it while the task may run" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ffree_3aleaf_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/std/" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c": memory: '" }>, align 8
@.d9 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"' keeps what it lets go of until its collection's scope closes: a let-go early freeing does not follow (O8f)\0A" }>, align 8
@.d10 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"the program's scope" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2escopeName_2elocal_2e4 = weak hidden constant i1 false
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"the " }>, align 8
@.d14 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d15 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"its scope" }>, align 8
@.d17 = private constant <{ i64, [128 x i8] }> <{ i64 0, [128 x i8] c"C is given a function value that is no export fn, which it may call from a thread of its own: nothing is freed early where it is" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2ffree_3aFree_2e129 = weak hidden constant i1 false
@.d19 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"a task calls through a function value or an any, or code not checked" }>, align 8
declare void @__olang_region_release_part(ptr, i64) noinline
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2ffree_3aFree_2e130 = weak hidden constant i1 false
@.d21 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a task reads a global that may reach it" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2ffree_3areason_2e3 = weak hidden constant i1 false
@.d23 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c": nothing is freed early where it does" }>, align 8
@.d24 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a task's code changes it, on a thread of its own" }>, align 8
@.d25 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"a task's code may let go of any place" }>, align 8
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@.d26 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"a task's code may let go of any place" }>, align 8
@.d27 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"a task's result is stored into a place holding it, and the join's code lets go of it while the task may run" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2earm_2elocal_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
@.d28 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d29 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"'; give it new storage - a constructor call, '$...', 'Copy()'" }>, align 8
@.d30 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"an 'any' is made of a reference that may reach one, which nothing counts" }>, align 8
@.d31 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"C is given a reference that may reach one" }>, align 8
@.d32 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"its value is handed back here" }>, align 8
@.d33 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"a task's result is stored into it, made on the task's thread: '" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2estmt_2elocal_2e49 = weak hidden constant i1 false
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ffree_3aleaf_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/free:leaf"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 24
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/free:leaf", ptr %t14, i64 %t12
  %t17 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %t15)
  store %"compiler/free:leaf" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/free:leaf", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/free:leaf", ptr %t22, i64 %t20
  store %"compiler/free:leaf" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8ade3a8f9c8eb28_5e24e0670bb9abf4 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eendPlaces(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emovedLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aLastUses_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_3996fae1d7559477_f511e22967edef5b = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eRestLeaves(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_509723034437c60f_ef8201934b6b99c3 = external constant [0 x i8]
@olang_loc_1457ae29cfe5ec6d_4b85493a75c45e71 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownersSplit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitOwners(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eRTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2eHas_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobReach(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2ePut_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cBool_3e_3e_2eGet_3cI64_2c_20Array_3cBool_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_af64c4abd7ad73bb_8da5f4f674882a7f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He7b3466db9a608577543dd7c0832d3d6(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H39ca684a9144c6cba1af5dc2ea7b2e34(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
@olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epartsFree(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRemovalNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ffree_2eGapCalls = external constant <{ [8 x i8], ptr, [8 x i8], ptr }>
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitPart(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ffree_2eRView = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleafLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_90a48e1653e30d13_61ffec3ea9309927 = external constant [0 x i8]
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db = external constant [0 x i8]
@olang_loc_fc2fcdbc2f007840_c2f2791b7eb787ec = external constant [0 x i8]
@olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8 = external constant [0 x i8]
@olang_loc_c329a7357b4632ae_1972f4ce8b92321a = external constant [0 x i8]
@olang_loc_ce4a56608212b1d3_28564c72fb26107 = external constant [0 x i8]
@olang_loc_8c3ff88e405c7c2b_15d3403d537d031f = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4d387e337fecd808_d73c070d6177d604 = external constant [0 x i8]
@olang_loc_a4118a366f7ca1d5_524409770a0878b9 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b71f5ffe7a4b5626_fc1be7c1ddcacd52 = external constant [0 x i8]
@olang_loc_80901eaab4a643b4_757281eb5f4291b0 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_521e7ccdaf7a192e_299b0461ce1a73ca = external constant [0 x i8]
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereached(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eCalleeVia = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eCalleeViaGiven = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FB\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0)
declare %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7b3dede47d025484_fbd5a3b64af54730 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [2 x i64] } %a3)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i1 %a5, i1 %a6)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_304dd9f782c5c299_7aedab6f7faf5da5 = external constant [0 x i8]
@olang_loc_ceff65db82d42b72_bd0ee798a65f80fe = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1c2ece56a8f93bb3_9a04e0623a4a84af = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownerSplitOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eWidenedMake(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassignTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownerSettle(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efreshCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedLocals(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunheldViews(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3, i64 %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
@olang_loc_3ed6c54977104fdc_6fa493e2929cd018 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eViewsMoved(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
@olang_loc_bdcaa592caab98ca_bd3b16c434097b46 = external constant [0 x i8]
@olang_loc_fd03f9e0e77d658_c5fe745f2729a3d4 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eSFail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ffree_2eWalkNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@G_2ecompiler_2ffree_2eWalkIn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eLHeld = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@G_2ecompiler_2ffree_2eLYield = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erunsAgain(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReleaseLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eVecWalks(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2eLen_3ccompiler_2ffree_3aVecWalk_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsLet(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i1 %a3)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleafOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eEndsLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9256ac4faaa6057c_c06f1d5f88305ed0 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_3fe28685437e06db_e899c2573511637 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblockFillOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2eokind(i64 %a0)
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_cee14a34e393ae19_ac6e569fdbf289b5 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSpawnLets(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedAtWait(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esplitLetOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2erefsOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egiveRefs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeField(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2ffree_2eSOk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eRefMut_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_d8246f320a19bbf9_8add34a618744eed = external constant [0 x i8]
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
@olang_loc_5d7536cc463ccac1_135a9313c745645 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescapedHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_11c10ff2df4ccb13_a4bbf1166c590ff7 = external constant [0 x i8]
declare ptr @compiler_2ffree_2etaskCall(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_407beb7582aa5744_e540dc6ed5e7bfd8 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisLive(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2espawnSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %a0)
@olang_loc_ec0dfed271d7eacc_f2c899624053798 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fmir_2eViewNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d719bd699dd81eb8_57808ee921a55224 = external constant [0 x i8]
@olang_loc_c9e9f8077eba1692_49188e33d38a4896 = external constant [0 x i8]
@olang_loc_86cff9656251f047_ec3335fc0049a713 = external constant [0 x i8]
@olang_loc_9500bd9cb83e9e6a_a32a388bbeb50dae = external constant [0 x i8]
@olang_loc_624ae5f0ecf6c3f8_e9900904abc8988c = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
