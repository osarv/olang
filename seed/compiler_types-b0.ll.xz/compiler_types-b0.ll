; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/types:data" = type { i32, i64, i64, i64, i64, i64, i64, i64 }
%"compiler/types:DtorWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:codeWalk" = type { ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/types:refWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i8
  %lp6 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l84 = alloca i64
  %l92 = alloca i1
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i1
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = icmp eq i64 %t5, 122
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l12, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l13, !tbaa !24
  %t12 = icmp sge i64 88, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb10
bb3:
  %t14 = icmp sle i64 88, 90
  br i1 %t14, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c38cb1fa51df222a_dffb1d180717405e)
  unreachable
bb5:
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp sle i64 90, %t16
  br i1 %t17, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c38cb1fa51df222a_dffb1d180717405e)
  unreachable
bb7:
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 88
  %t22 = sub i64 90, 88
  %t23 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t26, ptr %l18
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c38cb1fa51df222a_dffb1d180717405e)
  unreachable
bb9:
  %t27 = load i1, ptr %l18, !tbaa !21
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t34 = icmp sle i64 0, 88
  br i1 %t34, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_84fae12c7c668807_3becc0cabb21395b)
  unreachable
bb15:
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = icmp sle i64 88, %t36
  br i1 %t37, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_84fae12c7c668807_3becc0cabb21395b)
  unreachable
bb17:
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 0
  %t42 = sub i64 88, 0
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  store { i64, ptr } %t44, ptr %l1, !tbaa !27
  store i1 true, ptr %l2, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_84fae12c7c668807_3becc0cabb21395b)
  unreachable
bb19:
  %t46 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t46, ptr %l25
  br label %bb20
bb20:
  %t47 = load %"std/prelude/text:StringBuilder", ptr %l25
  store %"std/prelude/text:StringBuilder" %t47, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t54 = icmp slt i64 %t48, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb22, label %bb23
bb22:
  br label %bb57
bb23:
  br label %bb24
bb24:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  store i8 %t64, ptr %l5, !tbaa !22
  %t66 = load i8, ptr %l5, !tbaa !22
  %t68 = icmp ne i8 %t66, 95
  br i1 %t68, label %bb25, label %bb26
bb25:
  %t70 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 %t70)
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l4, !tbaa !24
  br label %bb56
bb28:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t78, 1
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t86 = icmp slt i64 %t80, %t83
  br i1 %t86, label %bb29, label %bb30
bb29:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t88, ptr %l47, !tbaa !27
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t89, 1
  %t93 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 95
  store i1 %t98, ptr %l46, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb31
bb31:
  %t100 = load i1, ptr %l46, !tbaa !21
  br i1 %t100, label %bb32, label %bb33
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 95)
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = add i64 %t102, 2
  store i64 %t105, ptr %l4, !tbaa !24
  br label %bb56
bb35:
  %t107 = load i64, ptr %l4, !tbaa !24
  %t109 = add i64 %t107, 2
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp slt i64 %t109, %t112
  br i1 %t115, label %bb36, label %bb37
bb36:
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t117, ptr %l62, !tbaa !27
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = add i64 %t118, 1
  %t122 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = call i1 @compiler_2ftypes_2esymbolHexDigit(i8 %t125)
  store i1 %t127, ptr %l66
  br label %bb38
bb37:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb39
bb38:
  %t128 = load i1, ptr %l66, !tbaa !21
  store i1 %t128, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t129 = load i1, ptr %l61, !tbaa !21
  br i1 %t129, label %bb40, label %bb41
bb40:
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t130, ptr %l68, !tbaa !27
  %t131 = load i64, ptr %l4, !tbaa !24
  %t133 = add i64 %t131, 2
  %t135 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i8, ptr %t136, i64 %t133
  %t138 = load i8, ptr %t137, !tbaa !32
  %t140 = call i1 @compiler_2ftypes_2esymbolHexDigit(i8 %t138)
  store i1 %t140, ptr %l72
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb42:
  %t141 = load i1, ptr %l72, !tbaa !21
  store i1 %t141, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t142 = load i1, ptr %l67, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store ptr %l3, ptr %l73, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t143, ptr %l74, !tbaa !27
  %t144 = load i64, ptr %l4, !tbaa !24
  %t146 = add i64 %t144, 1
  %t148 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i8, ptr %t149, i64 %t146
  %t151 = load i8, ptr %t150, !tbaa !32
  %t153 = call i64 @compiler_2ftypes_2esymbolHexValue(i8 %t151)
  store i64 %t153, ptr %l78
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t154 = load i64, ptr %l78, !tbaa !24
  %t155 = mul i64 %t154, 16
  store i64 %t155, ptr %l79, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t156, ptr %l80, !tbaa !27
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = add i64 %t157, 2
  %t161 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i8, ptr %t162, i64 %t159
  %t164 = load i8, ptr %t163, !tbaa !32
  %t166 = call i64 @compiler_2ftypes_2esymbolHexValue(i8 %t164)
  store i64 %t166, ptr %l84
  br label %bb47
bb47:
  %t167 = load i64, ptr %l79, !tbaa !24
  %t168 = load i64, ptr %l84, !tbaa !24
  %t169 = add i64 %t167, %t168
  %t171 = trunc i64 %t169 to i8
  %t173 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t173, i8 %t171)
  br label %bb48
bb48:
  %t175 = load i64, ptr %l4, !tbaa !24
  %t178 = add i64 %t175, 3
  store i64 %t178, ptr %l4, !tbaa !24
  br label %bb56
bb49:
  %t180 = load i1, ptr %l2, !tbaa !21
  br i1 %t180, label %bb50, label %bb51
bb50:
  %t182 = load i64, ptr %l4, !tbaa !24
  %t184 = add i64 %t182, 2
  %t185 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t190 = icmp sge i64 %t184, %t187
  store i1 %t190, ptr %l92, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb52
bb52:
  %t192 = load i1, ptr %l92, !tbaa !21
  br i1 %t192, label %bb53, label %bb54
bb53:
  br label %bb57
bb54:
  br label %bb55
bb55:
  %t193 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t193, ptr %rv
  br label %ret
bb56:
  br label %bb21
bb57:
  %t197 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t197, ptr %l101
  br label %bb58
bb58:
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t198, ptr %lp6
  %t199 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t200 = load ptr, ptr %lp6
  store { i64, ptr } %t199, ptr %t200, !tbaa !27
  %t201 = load ptr, ptr %lp6
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t205 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t202, { i64, ptr } %t204)
  store i1 %t205, ptr %l104
  br label %bb59
bb59:
  %t206 = load i1, ptr %l104, !tbaa !21
  %t207 = xor i1 %t206, true
  br i1 %t207, label %bb60, label %bb61
bb60:
  %t209 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = extractvalue { i64, ptr } %t209, 0
  %t213 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t212)
  call void @olang_textcopy(ptr %t213, ptr %t211, i64 %t212)
  %t214 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t215, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t217 = load i1, ptr %l2, !tbaa !21
  br i1 %t217, label %bb63, label %bb64
bb63:
  %t219 = load ptr, ptr %lp6
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = extractvalue { i64, ptr } %t220, 0
  %t224 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = getelementptr i8, ptr %t227, i64 %t223
  call void @olang_textcopy(ptr %t228, ptr %t224, i64 %t225)
  %t229 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t227, 1
  store { i64, ptr } %t230, ptr %l109, !tbaa !27
  br label %bb65
bb64:
  %t232 = load ptr, ptr %lp6
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l109, !tbaa !27
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t235 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t235, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l52 = alloca { i64, i64 }
  %l55 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l20, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l6, !tbaa !22
  %t27 = load i8, ptr %l6, !tbaa !22
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t27)
  store i1 %t29, ptr %l24
  br label %bb6
bb6:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb8:
  %t31 = load i8, ptr %l6, !tbaa !22
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l27
  br label %bb9
bb9:
  %t34 = load i1, ptr %l27, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l28, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l28, !tbaa !21
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load i8, ptr %l6, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t41)
  br label %bb16
bb15:
  %t44 = load i8, ptr %l6, !tbaa !22
  %t46 = icmp eq i8 %t44, 95
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb24
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb20:
  store ptr %l1, ptr %l37, !tbaa !29
  %t50 = load i8, ptr %l6, !tbaa !22
  %t53 = call { i64, ptr } @compiler_2ftypes_2ehex2(ptr %s6, i8 %t50)
  store { i64, ptr } %t53, ptr %l40
  br label %bb21
bb21:
  %t54 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t55 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t55, { i64, ptr } %t54)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %l3, !tbaa !24
  br label %bb2
bb26:
  %t63 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t63, ptr %l46
  br label %bb27
bb27:
  %t64 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = icmp sle i64 %t67, 120
  br i1 %t69, label %bb28, label %bb29
bb28:
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t71, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %t73)
  store { i64, i64 } %t75, ptr %l52
  br label %bb31
bb31:
  %t76 = load { i64, i64 }, ptr %l52
  store { i64, i64 } %t76, ptr %l8
  %t77 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !65
  store i64 %t78, ptr %l9, !tbaa !65
  %t80 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !65
  store i64 %t81, ptr %l10, !tbaa !65
  %t83 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l55, !tbaa !24
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb32, label %bb33
bb32:
  %t87 = icmp sle i64 0, 88
  br i1 %t87, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb34:
  %t89 = load i64, ptr %l55, !tbaa !24
  %t90 = icmp sle i64 88, %t89
  br i1 %t90, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb36:
  %t92 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i8, ptr %t93, i64 0
  %t95 = sub i64 88, 0
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  store { i64, ptr } %t97, ptr %l59, !tbaa !27
  %t98 = load i64, ptr %l9, !tbaa !65
  %t100 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t98)
  store { i64, ptr } %t100, ptr %l61
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9)
  unreachable
bb38:
  %t101 = load i64, ptr %l10, !tbaa !65
  %t103 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t101)
  store { i64, ptr } %t103, ptr %l63
  br label %bb39
bb39:
  %t104 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = add i64 %t109, %t112
  %t114 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t105, i64 %t106)
  %t119 = getelementptr i8, ptr %t118, i64 %t106
  call void @olang_textcopy(ptr %t119, ptr %t107, i64 %t108)
  %t120 = getelementptr i8, ptr %t119, i64 %t108
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  call void @olang_textcopy(ptr %t121, ptr %t115, i64 %t116)
  %t122 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t118, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t123, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2eTable_2eNew(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l20 = alloca %"compiler/types:Table"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l65 = alloca [18 x i32]
  %l76 = alloca ptr
  %l78 = alloca %"compiler/types:data"
  %l79 = alloca i32
  %l88 = alloca i64
  %l91 = alloca i64
  %l112 = alloca i64
  %l115 = alloca i64
  %l136 = alloca i64
  %l139 = alloca ptr
  %l143 = alloca i32
  %l145 = alloca ptr
  %l150 = alloca %"compiler/types:data"
  %l151 = alloca i32
  %l158 = alloca %"compiler/types:Table"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t2 = alloca %"compiler/types:Table", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftypes_3aTable_2ector(ptr %t2, ptr %v0, ptr %v1, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t2, i64 2192, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 2192, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l20, i64 2192, i1 false)
  %t6 = load ptr, ptr %lp1
  %t7 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 5
  store ptr %t7, ptr %l21, !tbaa !29
  %t8 = call ptr @__olang_scope_hold(ptr %v1)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l22, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2eArray_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2e_2d1
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = call ptr @__olang_region_make(ptr %v1)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l22, !tbaa !24
  br label %bb3
bb3:
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = icmp sle i64 0, 2305843009213693951
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_bd6aedfbb004cefb_a7e94c49277e6337)
  unreachable
bb6:
  %t18 = mul i64 0, 4
  %t19 = load i64, ptr %l22
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = insertvalue { i64, ptr } undef, i64 0, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t23 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H5d6217f1de626e258ec0008385e9bf9b(ptr %v1, ptr %v1, ptr %t23, { i64, ptr } %t22)
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_bd6aedfbb004cefb_a7e94c49277e6337)
  unreachable
bb8:
  %t25 = load ptr, ptr %lp1
  %t26 = getelementptr %"compiler/types:Table", ptr %t25, i32 0, i32 28
  store ptr %t26, ptr %l27, !tbaa !29
  %t27 = call ptr @__olang_scope_hold(ptr %v1)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l28, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = call ptr @__olang_region_make(ptr %v1)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l28, !tbaa !24
  br label %bb10
bb10:
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = icmp sle i64 0, 1152921504606846975
  br i1 %t35, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_f54586e6a50c1e66_9f53f9bdb86e8e82)
  unreachable
bb13:
  %t37 = mul i64 0, 8
  %t38 = load i64, ptr %l28
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = insertvalue { i64, ptr } undef, i64 0, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t42 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t42, { i64, ptr } %t41)
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f54586e6a50c1e66_9f53f9bdb86e8e82)
  unreachable
bb15:
  %t44 = load ptr, ptr %lp1
  %t45 = getelementptr %"compiler/types:Table", ptr %t44, i32 0, i32 30
  store ptr %t45, ptr %l33, !tbaa !29
  %t46 = call ptr @__olang_scope_hold(ptr %v1)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l34, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t48, label %bb16, label %bb17
bb16:
  %t50 = call ptr @__olang_region_make(ptr %v1)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l34, !tbaa !24
  br label %bb17
bb17:
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = icmp sle i64 0, 1152921504606846975
  br i1 %t54, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ede49b2874c89d85_5f433bfacafc8ba1)
  unreachable
bb20:
  %t56 = mul i64 0, 8
  %t57 = load i64, ptr %l34
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = insertvalue { i64, ptr } undef, i64 0, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t61 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t61, { i64, ptr } %t60)
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ede49b2874c89d85_5f433bfacafc8ba1)
  unreachable
bb22:
  %t63 = load ptr, ptr %lp1
  %t64 = getelementptr %"compiler/types:Table", ptr %t63, i32 0, i32 32
  store ptr %t64, ptr %l39, !tbaa !29
  %t65 = call ptr @__olang_scope_hold(ptr %v1)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l40, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = call ptr @__olang_region_make(ptr %v1)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l40, !tbaa !24
  br label %bb24
bb24:
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb25, label %bb26
bb25:
  %t73 = icmp sle i64 0, 1152921504606846975
  br i1 %t73, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_500fe07468cf8918_1c2da4555a1cce94)
  unreachable
bb27:
  %t75 = mul i64 0, 8
  %t76 = load i64, ptr %l40
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = insertvalue { i64, ptr } undef, i64 0, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t80 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t80, { i64, ptr } %t79)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_500fe07468cf8918_1c2da4555a1cce94)
  unreachable
bb29:
  %t82 = load ptr, ptr %lp1
  %t83 = getelementptr %"compiler/types:Table", ptr %t82, i32 0, i32 33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t83, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb30
bb30:
  %t85 = load ptr, ptr %lp1
  %t86 = getelementptr %"compiler/types:Table", ptr %t85, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v1, ptr %v1, ptr %t86, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i64] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s1
  %t106 = getelementptr [18 x i32], ptr %l65, i64 0, i64 0
  store i32 0, ptr %t106
  %t107 = getelementptr [18 x i32], ptr %l65, i64 0, i64 1
  store i32 1, ptr %t107
  %t108 = getelementptr [18 x i32], ptr %l65, i64 0, i64 2
  store i32 2, ptr %t108
  %t109 = getelementptr [18 x i32], ptr %l65, i64 0, i64 3
  store i32 3, ptr %t109
  %t110 = getelementptr [18 x i32], ptr %l65, i64 0, i64 4
  store i32 4, ptr %t110
  %t111 = getelementptr [18 x i32], ptr %l65, i64 0, i64 5
  store i32 5, ptr %t111
  %t112 = getelementptr [18 x i32], ptr %l65, i64 0, i64 6
  store i32 6, ptr %t112
  %t113 = getelementptr [18 x i32], ptr %l65, i64 0, i64 7
  store i32 7, ptr %t113
  %t114 = getelementptr [18 x i32], ptr %l65, i64 0, i64 8
  store i32 8, ptr %t114
  %t115 = getelementptr [18 x i32], ptr %l65, i64 0, i64 9
  store i32 9, ptr %t115
  %t116 = getelementptr [18 x i32], ptr %l65, i64 0, i64 10
  store i32 10, ptr %t116
  %t117 = getelementptr [18 x i32], ptr %l65, i64 0, i64 11
  store i32 11, ptr %t117
  %t118 = getelementptr [18 x i32], ptr %l65, i64 0, i64 12
  store i32 12, ptr %t118
  %t119 = getelementptr [18 x i32], ptr %l65, i64 0, i64 13
  store i32 13, ptr %t119
  %t120 = getelementptr [18 x i32], ptr %l65, i64 0, i64 14
  store i32 14, ptr %t120
  %t121 = getelementptr [18 x i32], ptr %l65, i64 0, i64 15
  store i32 15, ptr %t121
  %t122 = getelementptr [18 x i32], ptr %l65, i64 0, i64 16
  store i32 16, ptr %t122
  %t123 = getelementptr [18 x i32], ptr %l65, i64 0, i64 17
  store i32 17, ptr %t123
  %t124 = load [18 x i32], ptr %l65
  %t125 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 72, i64 8)
  store [18 x i32] %t124, ptr %t125
  store ptr %t125, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t127 = load ptr, ptr %l2
  store i64 18, ptr %l4, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s2
  %t130 = load i64, ptr %l3, !tbaa !24
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb34:
  br label %bb35
bb35:
  %t138 = load ptr, ptr %l2
  %t139 = load i64, ptr %l3, !tbaa !24
  %t142 = getelementptr [18 x i32], ptr %t138, i64 0, i64 %t139
  %t143 = load i32, ptr %t142, !range !{i32 0, i32 33}
  %t145 = load ptr, ptr %lp1
  store ptr %t145, ptr %l76, !tbaa !29
  %t148 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s2, i32 %t143, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t148, ptr %l78
  br label %bb36
bb36:
  %t149 = load ptr, ptr %l76, !tbaa !29
  %t150 = load %"compiler/types:data", ptr %l78
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t149, %"compiler/types:data" %t150, i32 1)
  store i32 %t151, ptr %l79
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  %t152 = load i64, ptr %l3, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l3, !tbaa !24
  br label %bb32
bb39:
  call void @__olang_scope_close(ptr %s1)
  %t157 = load ptr, ptr %lp1
  %t158 = getelementptr %"compiler/types:Table", ptr %t157, i32 0, i32 39
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t158, i32 %t159)
  br label %bb40
bb40:
  store i64 0, ptr %l6, !tbaa !24
  store i64 2, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t162 = load i64, ptr %l7, !tbaa !24
  %t163 = load i64, ptr %l6, !tbaa !24
  %t166 = icmp sgt i64 %t162, %t163
  br i1 %t166, label %bb41, label %bb42
bb41:
  %t168 = load i64, ptr %l8, !tbaa !24
  %t170 = icmp sgt i64 %t168, 0
  br i1 %t170, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb46
bb43:
  %t172 = load i64, ptr %l7, !tbaa !24
  %t173 = load i64, ptr %l6, !tbaa !24
  %t176 = sub i64 %t172, %t173
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = add i64 %t176, %t177
  %t182 = sub i64 %t180, 1
  %t183 = load i64, ptr %l8, !tbaa !24
  %t186 = sdiv i64 %t182, %t183
  store i64 %t186, ptr %l91, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb45
bb45:
  %t188 = load i64, ptr %l91, !tbaa !24
  store i64 %t188, ptr %l88, !tbaa !24
  br label %bb46
bb46:
  %t189 = load i64, ptr %l88, !tbaa !24
  store i64 %t189, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb47
bb47:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t191 = load i64, ptr %l9, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb48, label %bb49
bb48:
  br label %bb71
bb49:
  br label %bb50
bb50:
  %t198 = load i64, ptr %l6, !tbaa !24
  %t199 = load i64, ptr %l10, !tbaa !24
  %t200 = load i64, ptr %l8, !tbaa !24
  %t203 = mul i64 %t199, %t200
  %t206 = add i64 %t198, %t203
  store i64 %t206, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  store i64 129, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t208 = load i64, ptr %l13, !tbaa !24
  %t209 = load i64, ptr %l12, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb51, label %bb52
bb51:
  %t214 = load i64, ptr %l14, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb56
bb53:
  %t218 = load i64, ptr %l13, !tbaa !24
  %t219 = load i64, ptr %l12, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l14, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l14, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l115, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb55
bb55:
  %t234 = load i64, ptr %l115, !tbaa !24
  store i64 %t234, ptr %l112, !tbaa !24
  br label %bb56
bb56:
  %t235 = load i64, ptr %l112, !tbaa !24
  store i64 %t235, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s7
  %t236 = load i64, ptr %l16, !tbaa !24
  %t237 = load i64, ptr %l15, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb59:
  br label %bb60
bb60:
  %t244 = load i64, ptr %l12, !tbaa !24
  %t245 = load i64, ptr %l16, !tbaa !24
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l17, !tbaa !24
  %t254 = load i64, ptr %l17, !tbaa !24
  %t255 = load i64, ptr %l11, !tbaa !24
  %t257 = icmp eq i64 %t255, 1
  %t260 = call i64 @compiler_2ftypes_2eprimIndex(i64 %t254, i1 %t257)
  store i64 %t260, ptr %l136
  br label %bb61
bb61:
  %t261 = load i64, ptr %l136, !tbaa !24
  %t262 = trunc i64 %t261 to i32
  store i32 %t262, ptr %l18, !tbaa !23
  %t265 = load ptr, ptr %lp1
  %t266 = getelementptr %"compiler/types:Table", ptr %t265, i32 0, i32 39
  store ptr %t266, ptr %l139, !tbaa !29
  %t267 = load i32, ptr %l18, !tbaa !23
  %t268 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t271 = icmp ne i32 %t267, %t268
  br i1 %t271, label %bb62, label %bb63
bb62:
  %t273 = load i32, ptr %l18, !tbaa !23
  store i32 %t273, ptr %l143, !tbaa !23
  br label %bb66
bb63:
  %t275 = load ptr, ptr %lp1
  store ptr %t275, ptr %l145, !tbaa !29
  %t276 = load i64, ptr %l17, !tbaa !24
  %t277 = load i64, ptr %l11, !tbaa !24
  %t279 = sub i64 1, %t277
  %t283 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s7, i32 31, i64 %t276, i64 %t279, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t283, ptr %l150
  br label %bb64
bb64:
  %t284 = load ptr, ptr %l145, !tbaa !29
  %t285 = load %"compiler/types:data", ptr %l150
  %t286 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v1, ptr %t284, %"compiler/types:data" %t285, i32 1)
  store i32 %t286, ptr %l151
  br label %bb65
bb65:
  %t287 = load i32, ptr %l151, !tbaa !23
  store i32 %t287, ptr %l143, !tbaa !23
  br label %bb66
bb66:
  %t288 = load ptr, ptr %l139, !tbaa !29
  %t289 = load i32, ptr %l143, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t288, i32 %t289)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb68:
  %t290 = load i64, ptr %l16, !tbaa !24
  %t293 = add i64 %t290, 1
  store i64 %t293, ptr %l16, !tbaa !24
  br label %bb57
bb69:
  br label %bb70
bb70:
  %t295 = load i64, ptr %l10, !tbaa !24
  %t298 = add i64 %t295, 1
  store i64 %t298, ptr %l10, !tbaa !24
  br label %bb47
bb71:
  %t300 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l158, ptr %t300, i64 2192, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l158, i64 2192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 %a0, ptr %l2, !tbaa !65
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !65
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %t8, i64 %t9)
  store { i64, ptr } %t10, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_30e02956f84eec46_91b8152c5eb3aca)
  unreachable
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca i32
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca i32
  %l90 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i32
  %l104 = alloca { i64, ptr }
  %l106 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:DtorWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l11
  br label %bb1
bb1:
  %t17 = load i32, ptr %l11, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:DtorWalk", ptr %t18, i32 0, i32 1
  %t21 = load i32, ptr %l3, !tbaa !23
  %t24 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l15
  br label %bb2
bb2:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/types:DtorWalk", ptr %t26, i32 0, i32 1
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %t28, i32 %t29)
  %t33 = extractvalue { i32, i1 } %t32, 1
  %t34 = extractvalue { i32, i1 } %t32, 0
  store i32 %t34, ptr %l21
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb6, label %ok.36, !prof !99
ok.36:
  store i1 %t33, ptr %l20
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t37 = load i1, ptr %l20, !tbaa !21
  store i1 %t37, ptr %l16, !tbaa !21
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t38 = load i1, ptr %l16, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/types:DtorWalk", ptr %t39, i32 0, i32 1
  %t42 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t41, i32 %t42, i1 false)
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l25, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = call ptr @__olang_scope_or(ptr %v1, ptr %t47)
  %t49 = call ptr @__olang_scope_hold(ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t52, ptr %t53, i32 %t46)
  store i32 %t55, ptr %l28
  br label %bb11
bb11:
  %t56 = load i32, ptr %l28, !range !{i32 0, i32 33}
  store i32 %t56, ptr %l4
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t59 = trunc i64 20 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l32, !tbaa !29
  %t63 = load ptr, ptr %l2, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v1, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l33, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t70, ptr %t71, i32 %t64)
  store i32 %t73, ptr %l36
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = load i32, ptr %l36, !tbaa !23
  %t76 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %v1, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l37
  br label %bb16
bb16:
  %t77 = load i1, ptr %l37, !tbaa !21
  store i1 %t77, ptr %l29, !tbaa !21
  br label %bb64
bb17:
  %t78 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t80 = trunc i64 29 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t83 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t85 = trunc i64 25 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb64
bb23:
  %t88 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t90 = trunc i64 19 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  store ptr %t94, ptr %l45, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  %t96 = load ptr, ptr %l45, !tbaa !29
  %t97 = call ptr @__olang_scope_or(ptr %v1, ptr %t96)
  %t98 = call ptr @__olang_scope_hold(ptr %t97)
  %t99 = ptrtoint ptr %t98 to i64
  %t101 = inttoptr i64 %t99 to ptr
  %t102 = load ptr, ptr %l45, !tbaa !29
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t101, ptr %t102, i32 %t95)
  store i32 %t104, ptr %l48
  br label %bb27
bb27:
  %t105 = load ptr, ptr %l44, !tbaa !29
  %t106 = load i32, ptr %l48, !tbaa !23
  %t107 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %v1, ptr %t105, i32 %t106)
  store i1 %t107, ptr %l49
  br label %bb28
bb28:
  %t108 = load i1, ptr %l49, !tbaa !21
  store i1 %t108, ptr %l29, !tbaa !21
  br label %bb64
bb29:
  %t109 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t111 = trunc i64 22 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t114 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t116 = trunc i64 23 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l54, !tbaa !29
  %t120 = load ptr, ptr %l2, !tbaa !29
  store ptr %t120, ptr %l55, !tbaa !29
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l56, !tbaa !29
  %t122 = load i32, ptr %l3, !tbaa !23
  %t123 = load ptr, ptr %l56, !tbaa !29
  %t124 = call ptr @__olang_scope_or(ptr %v1, ptr %t123)
  %t125 = call ptr @__olang_scope_hold(ptr %t124)
  %t126 = ptrtoint ptr %t125 to i64
  %t128 = inttoptr i64 %t126 to ptr
  %t129 = load ptr, ptr %l56, !tbaa !29
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t128, ptr %t129, i32 %t122)
  store i32 %t131, ptr %l59
  br label %bb35
bb35:
  %t132 = load ptr, ptr %l55, !tbaa !29
  %t133 = call ptr @__olang_scope_or(ptr %v1, ptr %t132)
  %t134 = call ptr @__olang_scope_hold(ptr %t133)
  %t135 = ptrtoint ptr %t134 to i64
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/types:DtorWalk", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = call ptr @__olang_scope_or(ptr %v1, ptr %t139)
  %t142 = call ptr @__olang_scope_hold(ptr %t141)
  %t143 = ptrtoint ptr %t142 to i64
  %t145 = inttoptr i64 %t135 to ptr
  %t147 = inttoptr i64 %t143 to ptr
  %t148 = load ptr, ptr %l55, !tbaa !29
  %t149 = load i32, ptr %l59, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t145, ptr %t147, ptr %t148, i32 %t149)
  store { i64, ptr } %t150, ptr %l64
  br label %bb36
bb36:
  %t151 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = call ptr @__olang_scope_or(ptr %v1, ptr %t152)
  %t154 = call ptr @__olang_scope_hold(ptr %t153)
  %t155 = ptrtoint ptr %t154 to i64
  %t157 = inttoptr i64 %t155 to ptr
  %t158 = load ptr, ptr %l54, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t160 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %t157, ptr %v1, ptr %t158, { i64, ptr } %t159)
  store i1 %t160, ptr %l66
  br label %bb37
bb37:
  %t161 = load i1, ptr %l66, !tbaa !21
  store i1 %t161, ptr %l29, !tbaa !21
  br label %bb64
bb38:
  %t162 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb59
bb41:
  %t167 = load ptr, ptr %l2, !tbaa !29
  store ptr %t167, ptr %l69, !tbaa !29
  %t168 = load i32, ptr %l3, !tbaa !23
  %t169 = load ptr, ptr %l69, !tbaa !29
  %t170 = call ptr @__olang_scope_or(ptr %v1, ptr %t169)
  %t171 = call ptr @__olang_scope_hold(ptr %t170)
  %t172 = ptrtoint ptr %t171 to i64
  %t174 = inttoptr i64 %t172 to ptr
  %t175 = load ptr, ptr %l69, !tbaa !29
  %t177 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t174, ptr %t175, i32 %t168)
  store i1 %t177, ptr %l72
  br label %bb42
bb42:
  %t178 = load i1, ptr %l72, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb46
bb44:
  %t181 = load ptr, ptr %l2, !tbaa !29
  store ptr %t181, ptr %l75, !tbaa !29
  %t182 = load i32, ptr %l3, !tbaa !23
  %t183 = load ptr, ptr %l75, !tbaa !29
  %t184 = call ptr @__olang_scope_or(ptr %v1, ptr %t183)
  %t185 = call ptr @__olang_scope_hold(ptr %t184)
  %t186 = ptrtoint ptr %t185 to i64
  %t188 = inttoptr i64 %t186 to ptr
  %t189 = load ptr, ptr %l75, !tbaa !29
  %t191 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %t188, ptr %t189, i32 %t182)
  store i1 %t191, ptr %l78
  br label %bb45
bb45:
  %t192 = load i1, ptr %l78, !tbaa !21
  store i1 %t192, ptr %l74, !tbaa !21
  br label %bb46
bb46:
  %t193 = load i1, ptr %l74, !tbaa !21
  br i1 %t193, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb52
bb48:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l80, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  store ptr %t195, ptr %l81, !tbaa !29
  %t196 = load ptr, ptr %l2, !tbaa !29
  store ptr %t196, ptr %l82, !tbaa !29
  %t197 = load i32, ptr %l3, !tbaa !23
  %t198 = load ptr, ptr %l82, !tbaa !29
  %t199 = call ptr @__olang_scope_or(ptr %v1, ptr %t198)
  %t200 = call ptr @__olang_scope_hold(ptr %t199)
  %t201 = ptrtoint ptr %t200 to i64
  %t203 = inttoptr i64 %t201 to ptr
  %t204 = load ptr, ptr %l82, !tbaa !29
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t203, ptr %t204, i32 %t197)
  store i32 %t206, ptr %l85
  br label %bb49
bb49:
  %t207 = load ptr, ptr %l81, !tbaa !29
  %t208 = call ptr @__olang_scope_or(ptr %v1, ptr %t207)
  %t209 = call ptr @__olang_scope_hold(ptr %t208)
  %t210 = ptrtoint ptr %t209 to i64
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/types:DtorWalk", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = call ptr @__olang_scope_or(ptr %v1, ptr %t214)
  %t217 = call ptr @__olang_scope_hold(ptr %t216)
  %t218 = ptrtoint ptr %t217 to i64
  %t220 = inttoptr i64 %t210 to ptr
  %t222 = inttoptr i64 %t218 to ptr
  %t223 = load ptr, ptr %l81, !tbaa !29
  %t224 = load i32, ptr %l85, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t220, ptr %t222, ptr %t223, i32 %t224)
  store { i64, ptr } %t225, ptr %l90
  br label %bb50
bb50:
  %t226 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_scope_or(ptr %v1, ptr %t227)
  %t229 = call ptr @__olang_scope_hold(ptr %t228)
  %t230 = ptrtoint ptr %t229 to i64
  %t232 = inttoptr i64 %t230 to ptr
  %t233 = load ptr, ptr %l80, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t235 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %t232, ptr %v1, ptr %t233, { i64, ptr } %t234)
  store i1 %t235, ptr %l92
  br label %bb51
bb51:
  %t236 = load i1, ptr %l92, !tbaa !21
  store i1 %t236, ptr %l79, !tbaa !21
  br label %bb52
bb52:
  %t237 = load i1, ptr %l79, !tbaa !21
  br i1 %t237, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb58
bb54:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l94, !tbaa !29
  %t239 = load ptr, ptr %l2, !tbaa !29
  store ptr %t239, ptr %l95, !tbaa !29
  %t240 = load ptr, ptr %l2, !tbaa !29
  store ptr %t240, ptr %l96, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t242 = load ptr, ptr %l96, !tbaa !29
  %t243 = call ptr @__olang_scope_or(ptr %v1, ptr %t242)
  %t244 = call ptr @__olang_scope_hold(ptr %t243)
  %t245 = ptrtoint ptr %t244 to i64
  %t247 = inttoptr i64 %t245 to ptr
  %t248 = load ptr, ptr %l96, !tbaa !29
  %t250 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %t247, ptr %t248, i32 %t241)
  store i32 %t250, ptr %l99
  br label %bb55
bb55:
  %t251 = load ptr, ptr %l95, !tbaa !29
  %t252 = call ptr @__olang_scope_or(ptr %v1, ptr %t251)
  %t253 = call ptr @__olang_scope_hold(ptr %t252)
  %t254 = ptrtoint ptr %t253 to i64
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/types:DtorWalk", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = call ptr @__olang_scope_or(ptr %v1, ptr %t258)
  %t261 = call ptr @__olang_scope_hold(ptr %t260)
  %t262 = ptrtoint ptr %t261 to i64
  %t264 = inttoptr i64 %t254 to ptr
  %t266 = inttoptr i64 %t262 to ptr
  %t267 = load ptr, ptr %l95, !tbaa !29
  %t268 = load i32, ptr %l99, !tbaa !23
  %t269 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t264, ptr %t266, ptr %t267, i32 %t268)
  store { i64, ptr } %t269, ptr %l104
  br label %bb56
bb56:
  %t270 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 1
  %t272 = call ptr @__olang_scope_or(ptr %v1, ptr %t271)
  %t273 = call ptr @__olang_scope_hold(ptr %t272)
  %t274 = ptrtoint ptr %t273 to i64
  %t276 = inttoptr i64 %t274 to ptr
  %t277 = load ptr, ptr %l94, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t279 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %t276, ptr %v1, ptr %t277, { i64, ptr } %t278)
  store i1 %t279, ptr %l106
  br label %bb57
bb57:
  %t280 = load i1, ptr %l106, !tbaa !21
  store i1 %t280, ptr %l93, !tbaa !21
  br label %bb58
bb58:
  %t281 = load i1, ptr %l93, !tbaa !21
  store i1 %t281, ptr %l29, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_5cbd31595b499a54_61b0a2a5664e21e0)
  unreachable
bb64:
  %t282 = load i1, ptr %l29, !tbaa !21
  store i1 %t282, ptr %l5, !tbaa !21
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/types:DtorWalk", ptr %t283, i32 0, i32 1
  %t286 = load i32, ptr %l3, !tbaa !23
  %t287 = load i1, ptr %l5, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t285, i32 %t286, i1 %t287)
  br label %bb65
bb65:
  %t291 = load i1, ptr %l5, !tbaa !21
  store i1 %t291, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2esome(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %v2, ptr %a0, i32 %t28)
  store i1 %t31, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnonEnum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i32
  %l64 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i1
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l108 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca i64
  %l129 = alloca i1
  %l133 = alloca { i64, ptr }
  %l137 = alloca i64
  %l146 = alloca i64
  %l149 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i1
  %l171 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l186 = alloca %"compiler/types:data"
  %l189 = alloca i32
  %l191 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i32, ptr %l28, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l29
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t8, ptr %l5
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t23, ptr %l37, !tbaa !27
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i32, ptr %t27, i64 %t24
  %t29 = load i32, ptr %t28, !tbaa !33
  %t34 = sext i32 %t29 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t34)
  %t41 = getelementptr i8, ptr %t39, i64 %t35
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t43)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l7, !tbaa !24
  br label %bb3
bb9:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t57 = sext i32 %t52 to i64
  %t58 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t59 = add i64 %t55, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t54, i64 %t55)
  %t61 = getelementptr i8, ptr %t60, i64 %t55
  %t62 = call i64 @__olang_fmt_i64(ptr %t61, i64 %t57)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t64)
  br label %bb10
bb10:
  %t69 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l5)
  store { i64, ptr } %t69, ptr %l54
  br label %bb11
bb11:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t70, ptr %lp10
  %t71 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t72 = load ptr, ptr %lp10
  store { i64, ptr } %t71, ptr %t72, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/types:Table", ptr %t73, i32 0, i32 10
  %t76 = load ptr, ptr %lp10
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t80 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t75, { i64, ptr } %t77)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l60
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb13, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l59
  br label %bb12
bb12:
  %t85 = load i64, ptr %l59, !tbaa !24
  store i64 %t85, ptr %l55, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l55, !tbaa !24
  br label %bb15
bb15:
  %t86 = load i64, ptr %l55, !tbaa !24
  store i64 %t86, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l64, !tbaa !24
  %t94 = load i64, ptr %l64, !tbaa !24
  %t95 = icmp sge i64 %t94, 0
  br i1 %t95, label %bb18, label %bb19
bb17:
  br label %bb45
bb18:
  %t97 = load i64, ptr %l64, !tbaa !24
  %t98 = icmp sle i64 %t97, 2305843009213693951
  br i1 %t98, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_363cc534119e1b58_f5bd72046473679c)
  unreachable
bb20:
  %t100 = load i64, ptr %l64, !tbaa !24
  %t101 = mul i64 %t100, 4
  %t102 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l14, !tbaa !24
  %t111 = load i64, ptr %l13, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_363cc534119e1b58_f5bd72046473679c)
  unreachable
bb22:
  %t116 = load i64, ptr %l15, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb27
bb24:
  %t120 = load i64, ptr %l14, !tbaa !24
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l15, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l15, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l76, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb26
bb26:
  %t136 = load i64, ptr %l76, !tbaa !24
  store i64 %t136, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t137 = load i64, ptr %l73, !tbaa !24
  store i64 %t137, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t138 = load i64, ptr %l16, !tbaa !24
  %t139 = sub i64 %t138, 1
  store i64 %t139, ptr %l85, !tbaa !24
  %t140 = load i64, ptr %l16, !tbaa !24
  %t141 = icmp slt i64 %t140, 2147483648
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = icmp sge i64 %t142, 0
  %t146 = and i1 %t141, %t143
  store i1 %t146, ptr %l88, !tbaa !21
  br label %bb28
bb28:
  %t147 = load i64, ptr %l17, !tbaa !24
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l17, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l18, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t165, ptr %l98, !tbaa !27
  %t166 = load i64, ptr %l18, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t167, ptr %l100, !tbaa !27
  %t168 = load i64, ptr %l18, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 %t168
  %t173 = load i32, ptr %t172, !tbaa !33
  %t176 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 %t166
  store i32 %t173, ptr %t178, !tbaa !33
  br label %bb32
bb32:
  %t179 = load i64, ptr %l17, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb28
bb33:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/types:Table", ptr %t184, i32 0, i32 7
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H69e9af7ee32b7ff0c8685324094a29a4(ptr %v0, ptr %t186)
  store i64 %t188, ptr %l108
  br label %bb34
bb34:
  %t189 = load i64, ptr %l108, !tbaa !24
  store i64 %t189, ptr %l11, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/types:Table", ptr %t190, i32 0, i32 7
  %t193 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v0, ptr %t192, { i64, ptr } %t193)
  br label %bb35
bb35:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/types:Table", ptr %t196, i32 0, i32 8
  %t199 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %t198, i32 %t199)
  br label %bb36
bb36:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/types:Table", ptr %t202, i32 0, i32 9
  store ptr %t204, ptr %l116, !tbaa !29
  %t205 = call ptr @__olang_scope_hold(ptr %v0)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l117, !tbaa !24
  %t207 = load i1, ptr @olang_2esole_2eArray_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2e_2d1
  br i1 %t207, label %bb37, label %bb38
bb37:
  %t209 = call ptr @__olang_region_make(ptr %v0)
  %t210 = ptrtoint ptr %t209 to i64
  store i64 %t210, ptr %l117, !tbaa !24
  br label %bb38
bb38:
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb39, label %bb40
bb39:
  %t213 = icmp sle i64 0, 2305843009213693951
  br i1 %t213, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969)
  unreachable
bb41:
  %t215 = mul i64 0, 4
  %t216 = load i64, ptr %l117
  %t217 = inttoptr i64 %t216 to ptr
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t220 = load ptr, ptr %l116, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v0, ptr %t220, { i64, ptr } %t219)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969)
  unreachable
bb43:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/types:Table", ptr %t222, i32 0, i32 10
  %t225 = load ptr, ptr %lp10
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t224, { i64, ptr } %t226, i64 %t227)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t231 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb46, label %bb47
bb46:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/types:Table", ptr %t237, i32 0, i32 9
  %t240 = load i64, ptr %l11, !tbaa !24
  %t243 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H37377f924b66ff741793959f79fef546(ptr %v0, ptr %s0, ptr %t239, i64 %t240)
  store { i64, ptr } %t243, ptr %l133
  br label %bb48
bb47:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb49
bb48:
  %t244 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t247 = icmp eq i64 %t245, 0
  store i1 %t247, ptr %l129, !tbaa !21
  br label %bb49
bb49:
  %t249 = load i1, ptr %l129, !tbaa !21
  br i1 %t249, label %bb50, label %bb51
bb50:
  %t250 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l137, !tbaa !24
  %t253 = load i64, ptr %l137, !tbaa !24
  %t254 = icmp sge i64 %t253, 0
  br i1 %t254, label %bb52, label %bb53
bb51:
  br label %bb69
bb52:
  %t256 = load i64, ptr %l137, !tbaa !24
  %t257 = icmp sle i64 %t256, 2305843009213693951
  br i1 %t257, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a)
  unreachable
bb54:
  %t259 = load i64, ptr %l137, !tbaa !24
  %t260 = mul i64 %t259, 4
  %t261 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t260)
  %t262 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  store i64 %t267, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t269 = load i64, ptr %l21, !tbaa !24
  %t270 = load i64, ptr %l20, !tbaa !24
  %t273 = icmp sgt i64 %t269, %t270
  br i1 %t273, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a)
  unreachable
bb56:
  %t275 = load i64, ptr %l22, !tbaa !24
  %t277 = icmp sgt i64 %t275, 0
  br i1 %t277, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb61
bb58:
  %t279 = load i64, ptr %l21, !tbaa !24
  %t280 = load i64, ptr %l20, !tbaa !24
  %t283 = sub i64 %t279, %t280
  %t284 = load i64, ptr %l22, !tbaa !24
  %t287 = add i64 %t283, %t284
  %t289 = sub i64 %t287, 1
  %t290 = load i64, ptr %l22, !tbaa !24
  %t293 = sdiv i64 %t289, %t290
  store i64 %t293, ptr %l149, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb60
bb60:
  %t295 = load i64, ptr %l149, !tbaa !24
  store i64 %t295, ptr %l146, !tbaa !24
  br label %bb61
bb61:
  %t296 = load i64, ptr %l146, !tbaa !24
  store i64 %t296, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  %t297 = load i64, ptr %l23, !tbaa !24
  %t298 = sub i64 %t297, 1
  store i64 %t298, ptr %l158, !tbaa !24
  %t299 = load i64, ptr %l23, !tbaa !24
  %t300 = icmp slt i64 %t299, 2147483648
  %t301 = load i64, ptr %l24, !tbaa !24
  %t302 = icmp sge i64 %t301, 0
  %t305 = and i1 %t300, %t302
  store i1 %t305, ptr %l161, !tbaa !21
  br label %bb62
bb62:
  %t306 = load i64, ptr %l24, !tbaa !24
  %t307 = load i64, ptr %l23, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t314 = load i64, ptr %l20, !tbaa !24
  %t315 = load i64, ptr %l24, !tbaa !24
  %t316 = load i64, ptr %l22, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l25, !tbaa !24
  %t324 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t324, ptr %l171, !tbaa !27
  %t325 = load i64, ptr %l25, !tbaa !24
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t326, ptr %l173, !tbaa !27
  %t327 = load i64, ptr %l25, !tbaa !24
  %t329 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr i32, ptr %t330, i64 %t327
  %t332 = load i32, ptr %t331, !tbaa !33
  %t335 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr i32, ptr %t336, i64 %t325
  store i32 %t332, ptr %t337, !tbaa !33
  br label %bb66
bb66:
  %t338 = load i64, ptr %l24, !tbaa !24
  %t341 = add i64 %t338, 1
  store i64 %t341, ptr %l24, !tbaa !24
  br label %bb62
bb67:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/types:Table", ptr %t343, i32 0, i32 9
  %t346 = load i64, ptr %l11, !tbaa !24
  %t347 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H6938bdf4910ae806791e4f0f97041ba1(ptr %v0, ptr %v0, ptr %t345, i64 %t346, { i64, ptr } %t347)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t351 = load ptr, ptr %l0, !tbaa !29
  store ptr %t351, ptr %l183, !tbaa !29
  %t352 = load i64, ptr %l11, !tbaa !24
  %t355 = call %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %s0, i32 24, i64 %t352, i64 0, i64 0, i64 0, i64 0, i64 0, i64 0)
  store %"compiler/types:data" %t355, ptr %l186
  br label %bb70
bb70:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l4, !tbaa !23
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %t356, i32 %t357)
  store i32 %t360, ptr %l189
  br label %bb71
bb71:
  %t361 = load i32, ptr %l189, !tbaa !23
  %t362 = add i32 %t361, 1
  %t363 = load ptr, ptr %l183, !tbaa !29
  %t364 = load %"compiler/types:data", ptr %l186
  %t366 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %t363, %"compiler/types:data" %t364, i32 %t362)
  store i32 %t366, ptr %l191
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t367 = load i32, ptr %l191, !tbaa !23
  store i32 %t367, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i32
  %l44 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i1
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i1
  %l99 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  %t15 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t17 = trunc i64 25 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  %t20 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t22 = trunc i64 27 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  %t25 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t27 = trunc i64 15 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb89
bb11:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 18 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t37 = trunc i64 22 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t42 = trunc i64 23 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 33}
  %t49 = trunc i64 18 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb19, label %bb20
bb19:
  %t52 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l26, !tbaa !24
  br label %bb21
bb20:
  %t55 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l26, !tbaa !24
  br label %bb21
bb21:
  %t58 = load i64, ptr %l26, !tbaa !24
  %t59 = trunc i64 %t58 to i32
  %t61 = load ptr, ptr %l23, !tbaa !29
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t61, i32 %t59)
  store i1 %t63, ptr %l31
  br label %bb22
bb22:
  %t64 = load i1, ptr %l31, !tbaa !21
  store i1 %t64, ptr %l8, !tbaa !21
  br label %bb89
bb23:
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb38
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l34, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l1, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l37
  br label %bb27
bb27:
  %t76 = load ptr, ptr %l34, !tbaa !29
  %t77 = load i32, ptr %l37, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t78, ptr %l38
  br label %bb28
bb28:
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l42
  br label %bb31
bb30:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb37
bb31:
  %t85 = load i32, ptr %l42, !tbaa !23
  %t86 = icmp eq i32 %t85, 0
  br i1 %t86, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb36
bb33:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l45, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i32, ptr %l48, !tbaa !23
  %t96 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l49
  br label %bb35
bb35:
  %t97 = load i1, ptr %l49, !tbaa !21
  store i1 %t97, ptr %l44, !tbaa !21
  br label %bb36
bb36:
  %t98 = load i1, ptr %l44, !tbaa !21
  store i1 %t98, ptr %l39, !tbaa !21
  br label %bb37
bb37:
  %t99 = load i1, ptr %l39, !tbaa !21
  store i1 %t99, ptr %l8, !tbaa !21
  br label %bb89
bb38:
  %t100 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t102 = trunc i64 20 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l52, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l55
  br label %bb42
bb42:
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l55, !tbaa !23
  %t113 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t113, ptr %l56
  br label %bb43
bb43:
  %t114 = load i1, ptr %l56, !tbaa !21
  store i1 %t114, ptr %l8, !tbaa !21
  br label %bb89
bb44:
  %t115 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t117 = trunc i64 21 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb60
bb47:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l59, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l62
  br label %bb48
bb48:
  %t126 = load ptr, ptr %l59, !tbaa !29
  %t127 = load i32, ptr %l62, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t126, i32 %t127)
  store i1 %t128, ptr %l63
  br label %bb49
bb49:
  %t129 = load i1, ptr %l63, !tbaa !21
  br i1 %t129, label %bb50, label %bb51
bb50:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l68
  br label %bb52
bb51:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb54
bb52:
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load i32, ptr %l68, !tbaa !23
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t136, i32 %t137)
  store i1 %t138, ptr %l69
  br label %bb53
bb53:
  %t139 = load i1, ptr %l69, !tbaa !21
  store i1 %t139, ptr %l64, !tbaa !21
  br label %bb54
bb54:
  %t140 = load i1, ptr %l64, !tbaa !21
  br i1 %t140, label %bb55, label %bb56
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l71, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l74
  br label %bb57
bb56:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb59
bb57:
  %t147 = load ptr, ptr %l71, !tbaa !29
  %t148 = load i32, ptr %l74, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t147, i32 %t148)
  store i1 %t149, ptr %l75
  br label %bb58
bb58:
  %t150 = load i1, ptr %l75, !tbaa !21
  store i1 %t150, ptr %l70, !tbaa !21
  br label %bb59
bb59:
  %t151 = load i1, ptr %l70, !tbaa !21
  store i1 %t151, ptr %l8, !tbaa !21
  br label %bb89
bb60:
  %t152 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t154 = trunc i64 24 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l78, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l81
  br label %bb64
bb64:
  %t163 = load ptr, ptr %l78, !tbaa !29
  %t164 = load i32, ptr %l81, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t165, ptr %l82
  br label %bb65
bb65:
  %t166 = load i1, ptr %l82, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb89
bb66:
  %t167 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t169 = trunc i64 26 to i32
  %t170 = icmp eq i32 %t167, %t169
  br i1 %t170, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l85, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l88
  br label %bb70
bb70:
  %t178 = load ptr, ptr %l85, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t180 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t180, ptr %l89
  br label %bb71
bb71:
  %t181 = load i1, ptr %l89, !tbaa !21
  store i1 %t181, ptr %l8, !tbaa !21
  br label %bb89
bb72:
  %t182 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t184 = trunc i64 29 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l92, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l1, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l95
  br label %bb76
bb76:
  %t193 = load ptr, ptr %l92, !tbaa !29
  %t194 = load i32, ptr %l95, !tbaa !23
  %t195 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t195, ptr %l96
  br label %bb77
bb77:
  %t196 = load i1, ptr %l96, !tbaa !21
  store i1 %t196, ptr %l8, !tbaa !21
  br label %bb89
bb78:
  %t197 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t199 = trunc i64 30 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb84
bb81:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l99, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l1, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l102
  br label %bb82
bb82:
  %t208 = load ptr, ptr %l99, !tbaa !29
  %t209 = load i32, ptr %l102, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %t208, i32 %t209)
  store i1 %t210, ptr %l103
  br label %bb83
bb83:
  %t211 = load i1, ptr %l103, !tbaa !21
  store i1 %t211, ptr %l8, !tbaa !21
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_3a86b0904acb017a_fb1793104580b26e)
  unreachable
bb89:
  %t212 = load i1, ptr %l8, !tbaa !21
  store i1 %t212, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i64
  %l26 = alloca { i64, i64 }
  %l27 = alloca { i64, i64 }
  %l28 = alloca i32
  %l29 = alloca { i64, i64 }
  %l30 = alloca { i64, i64 }
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca %"compiler/types:data"
  %l73 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i64
  %l95 = alloca i32
  %l102 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l120 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca i32
  %l141 = alloca i32
  %l145 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca i32
  %l156 = alloca i32
  %l159 = alloca i64
  %l160 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i64
  %l168 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca i32
  %l179 = alloca i32
  %l180 = alloca { i64, i64 }
  %l185 = alloca ptr
  %l186 = alloca i32
  %l189 = alloca i32
  %l190 = alloca { i64, i64 }
  %l197 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l204 = alloca i32
  %l209 = alloca i1
  %l210 = alloca { i64, i64 }
  %l213 = alloca { i64, i64 }
  %l214 = alloca ptr
  %l215 = alloca i32
  %l218 = alloca i32
  %l219 = alloca { i64, i64 }
  %l224 = alloca ptr
  %l225 = alloca i32
  %l228 = alloca i32
  %l229 = alloca { i64, i64 }
  %l240 = alloca i32
  %l243 = alloca i64
  %l249 = alloca i64
  %l252 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l38
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l38
  store %"compiler/types:data" %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l5
  %t10 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t17 = trunc i64 17 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb166
bb7:
  %t20 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  %t25 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  %t35 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t37 = trunc i64 5 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb14, label %bb15
bb14:
  br label %bb34
bb15:
  %t40 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t42 = trunc i64 6 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb34
bb17:
  %t45 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t47 = trunc i64 7 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb18, label %bb19
bb18:
  br label %bb34
bb19:
  %t50 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t52 = trunc i64 8 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  %t55 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t57 = trunc i64 9 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  %t60 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t62 = trunc i64 10 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb24, label %bb25
bb24:
  br label %bb34
bb25:
  %t65 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t67 = trunc i64 11 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  %t70 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t72 = trunc i64 12 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  %t75 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t77 = trunc i64 13 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t80 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t82 = trunc i64 14 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = icmp ne i32 %t85, %t86
  br i1 %t89, label %bb35, label %bb36
bb35:
  %t91 = load i32, ptr %l1, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t95 = getelementptr [15 x i64], ptr @G_2ecompiler_2ftypes_2eprimBits, i64 0, i64 %t93
  %t96 = load i64, ptr %t95, !tbaa !34
  %t98 = sdiv i64 %t96, 8
  store i64 %t98, ptr %l73, !tbaa !24
  br label %bb37
bb36:
  store i64 1, ptr %l73, !tbaa !24
  br label %bb37
bb37:
  %t100 = load i64, ptr %l73, !tbaa !24
  store i64 %t100, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb166
bb38:
  %t103 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t105 = trunc i64 31 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t108 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = call i64 @compiler_2ftypes_2eIntBytes(i64 %t109)
  store i64 %t111, ptr %l82
  br label %bb42
bb42:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l6, !tbaa !24
  %t113 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = call i64 @compiler_2ftypes_2eIntBytes(i64 %t114)
  store i64 %t116, ptr %l84
  br label %bb43
bb43:
  %t117 = load i64, ptr %l84, !tbaa !24
  %t118 = load i64, ptr %l6, !tbaa !24
  store i64 %t118, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l4, !tbaa !24
  br label %bb166
bb44:
  %t122 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t124 = trunc i64 16 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb166
bb48:
  %t131 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t133 = trunc i64 32 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb62
bb51:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l95
  br label %bb52
bb52:
  %t141 = load i32, ptr %l95, !tbaa !23
  store i32 %t141, ptr %l10, !tbaa !23
  %t142 = load i32, ptr %l10, !tbaa !23
  %t144 = icmp eq i32 %t142, 5
  br i1 %t144, label %bb53, label %bb54
bb53:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb61
bb54:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l10, !tbaa !23
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l102
  br label %bb55
bb55:
  %t155 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t156 = load i64, ptr %l102, !tbaa !24
  %t158 = icmp ne i64 %t156, %t155
  br i1 %t158, label %bb56, label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l10, !tbaa !23
  %t165 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t161, i32 %t162)
  store i64 %t165, ptr %l108
  br label %bb59
bb59:
  %t166 = load i64, ptr %l108, !tbaa !24
  store i64 %t166, ptr %l13, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l10, !tbaa !23
  %t171 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t167, i32 %t168)
  store i64 %t171, ptr %l111
  br label %bb60
bb60:
  %t172 = load i64, ptr %l111, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  store i64 %t173, ptr %l3, !tbaa !24
  store i64 %t172, ptr %l4, !tbaa !24
  br label %bb61
bb61:
  br label %bb166
bb62:
  %t177 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t179 = trunc i64 21 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb166
bb66:
  %t186 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t188 = trunc i64 20 to i32
  %t189 = icmp eq i32 %t186, %t188
  br i1 %t189, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb80
bb69:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l120, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l123
  br label %bb70
bb70:
  %t197 = load ptr, ptr %l120, !tbaa !29
  %t198 = load i32, ptr %l123, !tbaa !23
  %t199 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t199, ptr %l124
  br label %bb71
bb71:
  %t200 = load i1, ptr %l124, !tbaa !21
  br i1 %t200, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb76
bb73:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l126, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l1, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l129
  br label %bb74
bb74:
  %t207 = load ptr, ptr %l126, !tbaa !29
  %t208 = load i32, ptr %l129, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t209, ptr %l130
  br label %bb75
bb75:
  %t210 = load i32, ptr %l130, !range !{i32 0, i32 33}
  %t212 = trunc i64 29 to i32
  %t213 = icmp eq i32 %t210, %t212
  store i1 %t213, ptr %l125, !tbaa !21
  br label %bb76
bb76:
  %t215 = load i1, ptr %l125, !tbaa !21
  br i1 %t215, label %bb77, label %bb78
bb77:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb79
bb78:
  store i64 8, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb79
bb79:
  br label %bb166
bb80:
  %t224 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t226 = trunc i64 19 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb98
bb83:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l1, !tbaa !23
  %t233 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t233, ptr %l141
  br label %bb84
bb84:
  %t234 = load i32, ptr %l141, !tbaa !23
  %t235 = icmp eq i32 %t234, 0
  br i1 %t235, label %bb85, label %bb86
bb85:
  store i64 16, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  br label %bb97
bb86:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l145, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l1, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l148
  br label %bb87
bb87:
  %t247 = load ptr, ptr %l145, !tbaa !29
  %t248 = load i32, ptr %l148, !tbaa !23
  %t249 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t247, i32 %t248)
  store i32 %t249, ptr %l149
  br label %bb88
bb88:
  %t250 = load i32, ptr %l149, !range !{i32 0, i32 33}
  %t252 = trunc i64 26 to i32
  %t253 = icmp eq i32 %t250, %t252
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb89, label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l1, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l156
  br label %bb92
bb92:
  %t263 = load i32, ptr %l156, !tbaa !23
  store i32 %t263, ptr %l23, !tbaa !23
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l23, !tbaa !23
  %t268 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t264, i32 %t265)
  store i64 %t268, ptr %l159
  br label %bb93
bb93:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l160, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l1, !tbaa !23
  %t274 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t274, ptr %l163
  br label %bb94
bb94:
  %t275 = load ptr, ptr %l160, !tbaa !29
  %t276 = load i32, ptr %l163, !tbaa !23
  %t277 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t275, i32 %t276)
  store i64 %t277, ptr %l164
  br label %bb95
bb95:
  %t278 = load i64, ptr %l159, !tbaa !24
  %t279 = load i64, ptr %l164, !tbaa !24
  %t280 = mul i64 %t278, %t279
  store i64 %t280, ptr %l24, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l23, !tbaa !23
  %t286 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t282, i32 %t283)
  store i64 %t286, ptr %l168
  br label %bb96
bb96:
  %t287 = load i64, ptr %l168, !tbaa !24
  %t288 = load i64, ptr %l24, !tbaa !24
  store i64 %t288, ptr %l3, !tbaa !24
  store i64 %t287, ptr %l4, !tbaa !24
  br label %bb97
bb97:
  br label %bb166
bb98:
  %t292 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t294 = trunc i64 22 to i32
  %t295 = icmp eq i32 %t292, %t294
  br i1 %t295, label %bb99, label %bb100
bb99:
  br label %bb103
bb100:
  %t297 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t299 = trunc i64 23 to i32
  %t300 = icmp eq i32 %t297, %t299
  br i1 %t300, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l175, !tbaa !29
  %t303 = load i32, ptr %l1, !tbaa !23
  store i32 %t303, ptr %l176, !tbaa !23
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i32, ptr %l1, !tbaa !23
  %t308 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t304, i32 %t305)
  store i32 %t308, ptr %l179
  br label %bb104
bb104:
  %t309 = load ptr, ptr %l175, !tbaa !29
  %t310 = load i32, ptr %l176, !tbaa !23
  %t311 = load i32, ptr %l179, !tbaa !23
  %t312 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t309, i32 %t310, i32 %t311)
  store { i64, i64 } %t312, ptr %l180
  br label %bb105
bb105:
  %t313 = load { i64, i64 }, ptr %l180
  store { i64, i64 } %t313, ptr %l26
  %t314 = getelementptr { i64, i64 }, ptr %l26, i32 0, i32 0
  %t315 = load i64, ptr %t314, !tbaa !24
  store i64 %t315, ptr %l3, !tbaa !24
  %t317 = getelementptr { i64, i64 }, ptr %l26, i32 0, i32 1
  %t318 = load i64, ptr %t317, !tbaa !24
  store i64 %t318, ptr %l4, !tbaa !24
  br label %bb166
bb106:
  %t320 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t322 = trunc i64 24 to i32
  %t323 = icmp eq i32 %t320, %t322
  br i1 %t323, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l185, !tbaa !29
  %t326 = load i32, ptr %l1, !tbaa !23
  store i32 %t326, ptr %l186, !tbaa !23
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i32, ptr %l1, !tbaa !23
  %t331 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t327, i32 %t328)
  store i32 %t331, ptr %l189
  br label %bb110
bb110:
  %t332 = load ptr, ptr %l185, !tbaa !29
  %t333 = load i32, ptr %l186, !tbaa !23
  %t334 = load i32, ptr %l189, !tbaa !23
  %t335 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t332, i32 %t333, i32 %t334)
  store { i64, i64 } %t335, ptr %l190
  br label %bb111
bb111:
  %t336 = load { i64, i64 }, ptr %l190
  store { i64, i64 } %t336, ptr %l27
  %t337 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 0
  %t338 = load i64, ptr %t337, !tbaa !24
  store i64 %t338, ptr %l3, !tbaa !24
  %t340 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 1
  %t341 = load i64, ptr %t340, !tbaa !24
  store i64 %t341, ptr %l4, !tbaa !24
  br label %bb166
bb112:
  %t343 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t345 = trunc i64 18 to i32
  %t346 = icmp eq i32 %t343, %t345
  br i1 %t346, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb161
bb115:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l1, !tbaa !23
  %t352 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t348, i32 %t349)
  store i1 %t352, ptr %l197
  br label %bb116
bb116:
  %t353 = load i1, ptr %l197, !tbaa !21
  %t354 = xor i1 %t353, true
  br i1 %t354, label %bb117, label %bb118
bb117:
  store i1 false, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l200, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l1, !tbaa !23
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t362, ptr %l203
  br label %bb120
bb120:
  %t363 = load ptr, ptr %l200, !tbaa !29
  %t364 = load i32, ptr %l203, !tbaa !23
  %t365 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t363, i32 %t364)
  store i32 %t365, ptr %l204
  br label %bb121
bb121:
  %t366 = load i32, ptr %l204, !range !{i32 0, i32 6}
  store i32 %t366, ptr %l28
  %t367 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t369 = trunc i64 0 to i32
  %t370 = icmp eq i32 %t367, %t369
  br i1 %t370, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb132
bb124:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i32, ptr %l1, !tbaa !23
  %t376 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t372, i32 %t373)
  store i1 %t376, ptr %l209
  br label %bb125
bb125:
  %t377 = load i1, ptr %l209, !tbaa !21
  br i1 %t377, label %bb126, label %bb127
bb126:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l1, !tbaa !23
  %t382 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayPacked(ptr %v0, ptr %t378, i32 %t379)
  store { i64, i64 } %t382, ptr %l213
  br label %bb128
bb127:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l214, !tbaa !29
  %t384 = load i32, ptr %l1, !tbaa !23
  store i32 %t384, ptr %l215, !tbaa !23
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i32, ptr %l1, !tbaa !23
  %t389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t389, ptr %l218
  br label %bb129
bb128:
  %t390 = load { i64, i64 }, ptr %l213
  store { i64, i64 } %t390, ptr %l210
  br label %bb131
bb129:
  %t391 = load ptr, ptr %l214, !tbaa !29
  %t392 = load i32, ptr %l215, !tbaa !23
  %t393 = load i32, ptr %l218, !tbaa !23
  %t394 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %t391, i32 %t392, i32 %t393)
  store { i64, i64 } %t394, ptr %l219
  br label %bb130
bb130:
  %t395 = load { i64, i64 }, ptr %l219
  store { i64, i64 } %t395, ptr %l210
  br label %bb131
bb131:
  %t396 = load { i64, i64 }, ptr %l210
  store { i64, i64 } %t396, ptr %l29
  %t397 = getelementptr { i64, i64 }, ptr %l29, i32 0, i32 0
  %t398 = load i64, ptr %t397, !tbaa !24
  store i64 %t398, ptr %l3, !tbaa !24
  %t400 = getelementptr { i64, i64 }, ptr %l29, i32 0, i32 1
  %t401 = load i64, ptr %t400, !tbaa !24
  store i64 %t401, ptr %l4, !tbaa !24
  br label %bb160
bb132:
  %t403 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t405 = trunc i64 1 to i32
  %t406 = icmp eq i32 %t403, %t405
  br i1 %t406, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb138
bb135:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l224, !tbaa !29
  %t409 = load i32, ptr %l1, !tbaa !23
  store i32 %t409, ptr %l225, !tbaa !23
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i32, ptr %l1, !tbaa !23
  %t414 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t410, i32 %t411)
  store i32 %t414, ptr %l228
  br label %bb136
bb136:
  %t415 = load ptr, ptr %l224, !tbaa !29
  %t416 = load i32, ptr %l225, !tbaa !23
  %t417 = load i32, ptr %l228, !tbaa !23
  %t418 = call { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %t415, i32 %t416, i32 %t417)
  store { i64, i64 } %t418, ptr %l229
  br label %bb137
bb137:
  %t419 = load { i64, i64 }, ptr %l229
  store { i64, i64 } %t419, ptr %l30
  %t420 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 0
  %t421 = load i64, ptr %t420, !tbaa !24
  store i64 %t421, ptr %l3, !tbaa !24
  %t423 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 1
  %t424 = load i64, ptr %t423, !tbaa !24
  store i64 %t424, ptr %l4, !tbaa !24
  br label %bb160
bb138:
  %t426 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t428 = trunc i64 2 to i32
  %t429 = icmp eq i32 %t426, %t428
  br i1 %t429, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  store i64 4, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  br label %bb160
bb142:
  %t435 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t437 = trunc i64 4 to i32
  %t438 = icmp eq i32 %t435, %t437
  br i1 %t438, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb153
bb145:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i32, ptr %l1, !tbaa !23
  %t444 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t440, i32 %t441)
  store i32 %t444, ptr %l240
  br label %bb146
bb146:
  %t445 = load i32, ptr %l240, !tbaa !23
  store i32 %t445, ptr %l33, !tbaa !23
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i32, ptr %l33, !tbaa !23
  %t450 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t446, i32 %t447)
  store i64 %t450, ptr %l243
  br label %bb147
bb147:
  %t451 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t452 = load i64, ptr %l243, !tbaa !24
  %t454 = icmp ne i64 %t452, %t451
  br i1 %t454, label %bb148, label %bb149
bb148:
  store i1 false, ptr %rv
  br label %ret
bb149:
  br label %bb150
bb150:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load i32, ptr %l33, !tbaa !23
  %t461 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t457, i32 %t458)
  store i64 %t461, ptr %l249
  br label %bb151
bb151:
  %t462 = load i64, ptr %l249, !tbaa !24
  store i64 %t462, ptr %l34, !tbaa !24
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load i32, ptr %l33, !tbaa !23
  %t467 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t463, i32 %t464)
  store i64 %t467, ptr %l252
  br label %bb152
bb152:
  %t468 = load i64, ptr %l252, !tbaa !24
  %t469 = load i64, ptr %l34, !tbaa !24
  store i64 %t469, ptr %l3, !tbaa !24
  store i64 %t468, ptr %l4, !tbaa !24
  br label %bb160
bb153:
  %t473 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t475 = trunc i64 3 to i32
  %t476 = icmp eq i32 %t473, %t475
  br i1 %t476, label %bb154, label %bb155
bb154:
  br label %bb158
bb155:
  %t478 = load i32, ptr %l28, !range !{i32 0, i32 6}
  %t480 = trunc i64 5 to i32
  %t481 = icmp eq i32 %t478, %t480
  br i1 %t481, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb159
bb158:
  store i1 false, ptr %rv
  br label %ret
bb159:
  call void @__olang_check_failed(ptr @olang_loc_448c58e2e97e944f_f556e6dbd0c75243)
  unreachable
bb160:
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store i1 false, ptr %rv
  br label %ret
bb165:
  call void @__olang_check_failed(ptr @olang_loc_136e48f5d148640e_b95a40c005170ac2)
  unreachable
bb166:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/types:Table", ptr %t485, i32 0, i32 21
  %t488 = load i32, ptr %l1, !tbaa !23
  %t490 = sext i32 %t488 to i64
  %t491 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t487, i64 %t490, i64 %t491)
  br label %bb167
bb167:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/types:Table", ptr %t495, i32 0, i32 22
  %t498 = load i32, ptr %l1, !tbaa !23
  %t500 = sext i32 %t498 to i64
  %t501 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t497, i64 %t500, i64 %t501)
  br label %bb168
bb168:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHeldParts(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca i32
  %l24 = alloca i32
  %l30 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l48 = alloca i32
  %l54 = alloca i32
  %l60 = alloca i32
  %l64 = alloca i32
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !range !{i32 0, i32 33}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t9 = trunc i64 18 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb27
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l12
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !range !{i32 0, i32 6}
  store i32 %t21, ptr %l3
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i32, ptr %l18, !tbaa !23
  %t33 = insertvalue { i32, i32 } undef, i32 %t32, 0
  %t34 = insertvalue { i32, i32 } %t33, i32 0, 1
  store { i32, i32 } %t34, ptr %rv
  br label %ret
bb11:
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t38 = trunc i64 1 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l24
  br label %bb15
bb15:
  %t46 = load i32, ptr %l24, !tbaa !23
  %t47 = insertvalue { i32, i32 } undef, i32 %t46, 0
  %t48 = insertvalue { i32, i32 } %t47, i32 0, 1
  store { i32, i32 } %t48, ptr %rv
  br label %ret
bb16:
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t52 = trunc i64 4 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l30
  br label %bb20
bb20:
  %t60 = insertvalue { i32, i32 } undef, i32 0, 0
  %t61 = load i32, ptr %l30, !tbaa !23
  %t62 = insertvalue { i32, i32 } %t60, i32 %t61, 1
  store { i32, i32 } %t62, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ec5192bc038e766b_2cb8f0109ffb07d7)
  unreachable
bb26:
  br label %bb62
bb27:
  %t64 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t66 = trunc i64 19 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb31
bb31:
  %t74 = load i32, ptr %l36, !tbaa !23
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb32, label %bb33
bb32:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l40
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t82 = insertvalue { i32, i32 } undef, i32 0, 0
  %t83 = load i32, ptr %l40, !tbaa !23
  %t84 = insertvalue { i32, i32 } %t82, i32 %t83, 1
  store { i32, i32 } %t84, ptr %rv
  br label %ret
bb35:
  br label %bb62
bb36:
  %t86 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t88 = trunc i64 22 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t91 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t93 = trunc i64 23 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l48
  br label %bb42
bb42:
  %t101 = load i32, ptr %l48, !tbaa !23
  %t102 = insertvalue { i32, i32 } undef, i32 %t101, 0
  %t103 = insertvalue { i32, i32 } %t102, i32 0, 1
  store { i32, i32 } %t103, ptr %rv
  br label %ret
bb43:
  %t105 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t107 = trunc i64 24 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l1, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l54
  br label %bb47
bb47:
  %t115 = load i32, ptr %l54, !tbaa !23
  %t116 = insertvalue { i32, i32 } undef, i32 %t115, 0
  %t117 = insertvalue { i32, i32 } %t116, i32 0, 1
  store { i32, i32 } %t117, ptr %rv
  br label %ret
bb48:
  %t119 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t121 = trunc i64 32 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb57
bb51:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l60
  br label %bb52
bb52:
  %t129 = load i32, ptr %l60, !tbaa !23
  %t130 = icmp ne i32 %t129, 5
  br i1 %t130, label %bb53, label %bb54
bb53:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l64
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t137 = insertvalue { i32, i32 } undef, i32 0, 0
  %t138 = load i32, ptr %l64, !tbaa !23
  %t139 = insertvalue { i32, i32 } %t137, i32 %t138, 1
  store { i32, i32 } %t139, ptr %rv
  br label %ret
bb56:
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_86988b21a5fa47aa_49c23f488b207436)
  unreachable
bb62:
  %t141 = insertvalue { i32, i32 } undef, i32 0, 0
  %t142 = insertvalue { i32, i32 } %t141, i32 0, 1
  store { i32, i32 } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l9 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i8
  %l80 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l101 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i1
  %l108 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca i1
  %l121 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca i1
  %l128 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i1
  %l135 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i32
  %l144 = alloca i8
  %l146 = alloca i8
  %l147 = alloca ptr
  %l150 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t9 = trunc i64 32 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/types:Table", ptr %t12, i32 0, i32 19
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l15
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb7
bb6:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t28, ptr %l21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l21, !tbaa !21
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l24
  br label %bb11
bb11:
  %t36 = load i1, ptr %l24, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t38 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t40 = trunc i64 20 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t45 = trunc i64 21 to i32
  %t46 = icmp eq i32 %t43, %t45
  store i1 %t46, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l28, !tbaa !21
  br i1 %t48, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb19:
  %t49 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t51 = trunc i64 25 to i32
  %t52 = icmp eq i32 %t49, %t51
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb23
bb22:
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t57 = trunc i64 29 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t64 = trunc i64 18 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t71 = trunc i64 19 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb30, label %bb31
bb30:
  %t77 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t79 = trunc i64 22 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t87 = trunc i64 23 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t92 = load i1, ptr %l49, !tbaa !21
  br i1 %t92, label %bb36, label %bb37
bb36:
  %t93 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t95 = trunc i64 24 to i32
  %t96 = icmp eq i32 %t93, %t95
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb38
bb38:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t102 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb42, label %bb43
bb42:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l63
  br label %bb44
bb43:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb45
bb44:
  %t112 = load i1, ptr %l63, !tbaa !21
  %t113 = xor i1 %t112, true
  store i1 %t113, ptr %l60, !tbaa !21
  br label %bb45
bb45:
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb46, label %bb47
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l1, !tbaa !23
  %t121 = call i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %t117, i32 %t118)
  store i8 %t121, ptr %l68
  br label %bb49
bb49:
  %t122 = load i8, ptr %l68, !tbaa !22
  store i8 %t122, ptr %l3, !tbaa !22
  %t123 = load i8, ptr %l3, !tbaa !22
  %t125 = icmp ne i8 %t123, 0
  br i1 %t125, label %bb50, label %bb51
bb50:
  %t127 = load i8, ptr %l3, !tbaa !22
  %t129 = icmp eq i8 %t127, 3
  store i1 %t129, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t131, i32 %t132, i8 1)
  br label %bb53
bb53:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/types:Table", ptr %t135, i32 0, i32 37
  %t138 = load i1, ptr %t137, !tbaa !21
  store i1 %t138, ptr %l4, !tbaa !21
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/types:Table", ptr %t140, i32 0, i32 37
  store i1 false, ptr %t142, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  %t143 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t145 = trunc i64 18 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb82
bb56:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l80, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l83
  br label %bb57
bb57:
  %t154 = load ptr, ptr %l80, !tbaa !29
  %t155 = load i32, ptr %l83, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l84
  br label %bb58
bb58:
  %t157 = load i32, ptr %l84, !range !{i32 0, i32 6}
  store i32 %t157, ptr %l6
  %t158 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t160 = trunc i64 0 to i32
  %t161 = icmp eq i32 %t158, %t160
  br i1 %t161, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l87, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l1, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t164, i32 %t165)
  store i32 %t168, ptr %l90
  br label %bb62
bb62:
  %t169 = load ptr, ptr %l87, !tbaa !29
  %t170 = load i32, ptr %l90, !tbaa !23
  %t171 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t169, i32 %t170, i1 false, i1 true)
  store i1 %t171, ptr %l91
  br label %bb63
bb63:
  %t172 = load i1, ptr %l91, !tbaa !21
  store i1 %t172, ptr %l5, !tbaa !21
  br label %bb81
bb64:
  %t173 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t175 = trunc i64 1 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l94, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t179, i32 %t180)
  store i32 %t183, ptr %l97
  br label %bb68
bb68:
  %t184 = load ptr, ptr %l94, !tbaa !29
  %t185 = load i32, ptr %l97, !tbaa !23
  %t186 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t184, i32 %t185, i1 true, i1 true)
  store i1 %t186, ptr %l98
  br label %bb69
bb69:
  %t187 = load i1, ptr %l98, !tbaa !21
  store i1 %t187, ptr %l5, !tbaa !21
  br label %bb81
bb70:
  %t188 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t190 = trunc i64 4 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l101, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l104
  br label %bb74
bb74:
  %t199 = load ptr, ptr %l101, !tbaa !29
  %t200 = load i32, ptr %l104, !tbaa !23
  %t201 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t201, ptr %l105
  br label %bb75
bb75:
  %t202 = load i1, ptr %l105, !tbaa !21
  store i1 %t202, ptr %l5, !tbaa !21
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_d3e704bcd06f7d56_ed5a4209a5557c8a)
  unreachable
bb81:
  br label %bb116
bb82:
  %t203 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t205 = trunc i64 19 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb93
bb85:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l108, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l1, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t213, ptr %l111
  br label %bb86
bb86:
  %t214 = load ptr, ptr %l108, !tbaa !29
  %t215 = load i32, ptr %l111, !tbaa !23
  %t216 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t216, ptr %l112
  br label %bb87
bb87:
  %t217 = load i1, ptr %l112, !tbaa !21
  br i1 %t217, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb92
bb89:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l114, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l1, !tbaa !23
  %t223 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t219, i32 %t220)
  store i32 %t223, ptr %l117
  br label %bb90
bb90:
  %t224 = load ptr, ptr %l114, !tbaa !29
  %t225 = load i32, ptr %l117, !tbaa !23
  %t226 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t224, i32 %t225)
  store i1 %t226, ptr %l118
  br label %bb91
bb91:
  %t227 = load i1, ptr %l118, !tbaa !21
  store i1 %t227, ptr %l113, !tbaa !21
  br label %bb92
bb92:
  %t228 = load i1, ptr %l113, !tbaa !21
  store i1 %t228, ptr %l5, !tbaa !21
  br label %bb116
bb93:
  %t229 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t231 = trunc i64 22 to i32
  %t232 = icmp eq i32 %t229, %t231
  br i1 %t232, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l121, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l1, !tbaa !23
  %t239 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t235, i32 %t236)
  store i32 %t239, ptr %l124
  br label %bb97
bb97:
  %t240 = load ptr, ptr %l121, !tbaa !29
  %t241 = load i32, ptr %l124, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t240, i32 %t241, i1 false, i1 false)
  store i1 %t242, ptr %l125
  br label %bb98
bb98:
  %t243 = load i1, ptr %l125, !tbaa !21
  store i1 %t243, ptr %l5, !tbaa !21
  br label %bb116
bb99:
  %t244 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t246 = trunc i64 23 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l128, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l1, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l131
  br label %bb103
bb103:
  %t255 = load ptr, ptr %l128, !tbaa !29
  %t256 = load i32, ptr %l131, !tbaa !23
  %t257 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t255, i32 %t256, i1 false, i1 true)
  store i1 %t257, ptr %l132
  br label %bb104
bb104:
  %t258 = load i1, ptr %l132, !tbaa !21
  store i1 %t258, ptr %l5, !tbaa !21
  br label %bb116
bb105:
  %t259 = load i32, ptr %l2, !range !{i32 0, i32 33}
  %t261 = trunc i64 24 to i32
  %t262 = icmp eq i32 %t259, %t261
  br i1 %t262, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l135, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i32, ptr %l1, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l138
  br label %bb109
bb109:
  %t270 = load ptr, ptr %l135, !tbaa !29
  %t271 = load i32, ptr %l138, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %t270, i32 %t271, i1 true, i1 true)
  store i1 %t272, ptr %l139
  br label %bb110
bb110:
  %t273 = load i1, ptr %l139, !tbaa !21
  store i1 %t273, ptr %l5, !tbaa !21
  br label %bb116
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_b4be3b7b6cfde177_2b1bada5393bc0cb)
  unreachable
bb116:
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l140, !tbaa !29
  %t275 = load i32, ptr %l1, !tbaa !23
  store i32 %t275, ptr %l141, !tbaa !23
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/types:Table", ptr %t276, i32 0, i32 37
  %t279 = load i1, ptr %t278, !tbaa !21
  br i1 %t279, label %bb117, label %bb118
bb117:
  store i8 0, ptr %l144, !tbaa !22
  br label %bb122
bb118:
  %t281 = load i1, ptr %l5, !tbaa !21
  br i1 %t281, label %bb119, label %bb120
bb119:
  store i8 3, ptr %l146, !tbaa !22
  br label %bb121
bb120:
  store i8 2, ptr %l146, !tbaa !22
  br label %bb121
bb121:
  %t283 = load i8, ptr %l146, !tbaa !22
  store i8 %t283, ptr %l144, !tbaa !22
  br label %bb122
bb122:
  %t284 = load ptr, ptr %l140, !tbaa !29
  %t285 = load i32, ptr %l141, !tbaa !23
  %t286 = load i8, ptr %l144, !tbaa !22
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %t284, i32 %t285, i8 %t286)
  br label %bb123
bb123:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l147, !tbaa !29
  %t288 = load ptr, ptr %l147, !tbaa !29
  %t289 = getelementptr %"compiler/types:Table", ptr %t288, i32 0, i32 37
  %t290 = load i1, ptr %t289, !tbaa !21
  br i1 %t290, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb126
bb125:
  %t293 = load i1, ptr %l4, !tbaa !21
  store i1 %t293, ptr %l150, !tbaa !21
  br label %bb126
bb126:
  %t295 = load i1, ptr %l150, !tbaa !21
  %t296 = load ptr, ptr %l147, !tbaa !29
  %t297 = getelementptr %"compiler/types:Table", ptr %t296, i32 0, i32 37
  store i1 %t295, ptr %t297, !tbaa !21
  %t298 = load i1, ptr %l5, !tbaa !21
  store i1 %t298, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eKeepsHome, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t9 = load i64, ptr %l2, !tbaa !24
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamName(ptr %v0, ptr %s1, ptr %v2, ptr %t7, i32 %t8, i64 %t9)
  store { i64, ptr } %t13, ptr %l12
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = add i64 %t15, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = getelementptr i8, ptr %t20, i64 %t15
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/types:Table", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = trunc i64 %t33 to i32
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = call ptr @__olang_scope_or(ptr %v2, ptr %t37)
  %t39 = call ptr @__olang_scope_hold(ptr %t38)
  %t40 = ptrtoint ptr %t39 to i64
  %t42 = inttoptr i64 %t40 to ptr
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t42, ptr %s0, ptr %t43, i32 %t35)
  store { i64, ptr } %t45, ptr %l23
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb8
bb7:
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t48 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  store { i64, ptr } %t55, ptr %l16, !tbaa !27
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t61 = load i64, ptr %l2, !tbaa !24
  %t65 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamName(ptr %v0, ptr %s0, ptr %v2, ptr %t59, i32 %t60, i64 %t61)
  store { i64, ptr } %t65, ptr %l29
  br label %bb9
bb9:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l1, !tbaa !23
  %t68 = load i64, ptr %l3, !tbaa !24
  %t72 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamName(ptr %v0, ptr %s0, ptr %v2, ptr %t66, i32 %t67, i64 %t68)
  store { i64, ptr } %t72, ptr %l33
  br label %bb10
bb10:
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t88 = extractvalue { i64, ptr } %t73, 1
  %t89 = extractvalue { i64, ptr } %t73, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t74, i64 %t75)
  %t92 = getelementptr i8, ptr %t91, i64 %t75
  call void @olang_textcopy(ptr %t92, ptr %t77, i64 %t78)
  %t93 = getelementptr i8, ptr %t92, i64 %t78
  call void @olang_textcopy(ptr %t93, ptr %t80, i64 %t81)
  %t94 = getelementptr i8, ptr %t93, i64 %t81
  call void @olang_textcopy(ptr %t94, ptr %t84, i64 %t85)
  %t95 = getelementptr i8, ptr %t94, i64 %t85
  call void @olang_textcopy(ptr %t95, ptr %t88, i64 %t89)
  %t96 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t91, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNamesWith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca i1
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i1
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i1
  %l147 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l159 = alloca i64
  %l163 = alloca i64
  %l164 = alloca i32
  %l170 = alloca i64
  %l172 = alloca i64
  %l181 = alloca i64
  %l184 = alloca i64
  %l193 = alloca i64
  %l196 = alloca i1
  %l206 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l215 = alloca i64
  %l227 = alloca i64
  %l230 = alloca i64
  %l239 = alloca i64
  %l242 = alloca i1
  %l252 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l3, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t15 = sub i64 %t14, 1
  store i64 %t15, ptr %l44, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t16, 2147483648
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  %t22 = and i1 %t17, %t19
  store i1 %t22, ptr %l47, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l52, !tbaa !27
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t32
  %t37 = load i64, ptr %t36, !tbaa !34
  store i64 %t37, ptr %l7, !tbaa !24
  %t39 = load i1, ptr %l3, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb10
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp ne i64 %t42, 0
  store i1 %t44, ptr %l57, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l57, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l5, !tbaa !24
  br label %bb4
bb12:
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l64, !tbaa !24
  %t55 = load i1, ptr %l3, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l66, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l64, !tbaa !24
  %t64 = load i64, ptr %l66, !tbaa !24
  %t65 = add i64 %t63, %t64
  store i64 %t65, ptr %l71, !tbaa !24
  %t68 = load i64, ptr %l71, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = load i64, ptr %l71, !tbaa !24
  %t72 = icmp sle i64 %t71, 1152921504606846975
  br i1 %t72, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_93ecd4e0e0e07c38_b4b07d2ce290cdc4)
  unreachable
bb18:
  %t74 = load i64, ptr %l71, !tbaa !24
  %t75 = mul i64 %t74, 8
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_93ecd4e0e0e07c38_b4b07d2ce290cdc4)
  unreachable
bb20:
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb25
bb22:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l12, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l83, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb24
bb24:
  %t110 = load i64, ptr %l83, !tbaa !24
  store i64 %t110, ptr %l80, !tbaa !24
  br label %bb25
bb25:
  %t111 = load i64, ptr %l80, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t113 = sub i64 %t112, 1
  store i64 %t113, ptr %l92, !tbaa !24
  %t114 = load i64, ptr %l13, !tbaa !24
  %t115 = icmp slt i64 %t114, 2147483648
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = icmp sge i64 %t116, 0
  %t120 = and i1 %t115, %t117
  store i1 %t120, ptr %l95, !tbaa !21
  br label %bb26
bb26:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l15, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t139, ptr %l105, !tbaa !27
  %t140 = load i64, ptr %l15, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t141, ptr %l107, !tbaa !27
  %t142 = load i64, ptr %l15, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 %t142
  %t147 = load i64, ptr %t146, !tbaa !34
  %t150 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i64, ptr %t151, i64 %t140
  store i64 %t147, ptr %t152, !tbaa !34
  br label %bb30
bb30:
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = add i64 %t153, 1
  store i64 %t156, ptr %l14, !tbaa !24
  br label %bb26
bb31:
  %t158 = load i1, ptr %l3, !tbaa !21
  br i1 %t158, label %bb32, label %bb33
bb32:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t160, ptr %l114, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t165 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i64, ptr %t166, i64 %t163
  store i64 -1, ptr %t167, !tbaa !34
  store i64 0, ptr %l16, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t172 = load i64, ptr %l17, !tbaa !24
  %t173 = load i64, ptr %l16, !tbaa !24
  %t176 = icmp sgt i64 %t172, %t173
  br i1 %t176, label %bb34, label %bb35
bb33:
  br label %bb46
bb34:
  %t178 = load i64, ptr %l18, !tbaa !24
  %t180 = icmp sgt i64 %t178, 0
  br i1 %t180, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb39
bb36:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = sub i64 %t182, %t183
  %t187 = load i64, ptr %l18, !tbaa !24
  %t190 = add i64 %t186, %t187
  %t192 = sub i64 %t190, 1
  %t193 = load i64, ptr %l18, !tbaa !24
  %t196 = sdiv i64 %t192, %t193
  store i64 %t196, ptr %l125, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb38
bb38:
  %t198 = load i64, ptr %l125, !tbaa !24
  store i64 %t198, ptr %l122, !tbaa !24
  br label %bb39
bb39:
  %t199 = load i64, ptr %l122, !tbaa !24
  store i64 %t199, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t200 = load i64, ptr %l19, !tbaa !24
  %t201 = sub i64 %t200, 1
  store i64 %t201, ptr %l134, !tbaa !24
  %t202 = load i64, ptr %l19, !tbaa !24
  %t203 = icmp slt i64 %t202, 2147483648
  %t204 = load i64, ptr %l20, !tbaa !24
  %t205 = icmp sge i64 %t204, 0
  %t208 = and i1 %t203, %t205
  store i1 %t208, ptr %l137, !tbaa !21
  br label %bb40
bb40:
  %t209 = load i64, ptr %l20, !tbaa !24
  %t210 = load i64, ptr %l19, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb41, label %bb42
bb41:
  br label %bb45
bb42:
  br label %bb43
bb43:
  %t217 = load i64, ptr %l16, !tbaa !24
  %t218 = load i64, ptr %l20, !tbaa !24
  %t219 = load i64, ptr %l18, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t225 = add i64 %t217, %t222
  store i64 %t225, ptr %l21, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t227, ptr %l147, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t232 = add i64 %t230, 1
  %t233 = load i64, ptr %l21, !tbaa !24
  %t236 = add i64 %t232, %t233
  %t237 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t237, ptr %l153, !tbaa !27
  %t238 = load i64, ptr %l21, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i64, ptr %t241, i64 %t238
  %t243 = load i64, ptr %t242, !tbaa !34
  %t246 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i64, ptr %t247, i64 %t236
  store i64 %t243, ptr %t248, !tbaa !34
  br label %bb44
bb44:
  %t249 = load i64, ptr %l20, !tbaa !24
  %t252 = add i64 %t249, 1
  store i64 %t252, ptr %l20, !tbaa !24
  br label %bb40
bb45:
  br label %bb46
bb46:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/types:Table", ptr %t254, i32 0, i32 31
  %t257 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t260 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t256, { i64, ptr } %t257)
  %t261 = extractvalue { i32, i64 } %t260, 1
  %t262 = extractvalue { i32, i64 } %t260, 0
  store i32 %t262, ptr %l164
  %t263 = icmp ne i32 %t262, 0
  br i1 %t263, label %bb48, label %ok.264, !prof !99
ok.264:
  store i64 %t261, ptr %l163
  br label %bb47
bb47:
  %t265 = load i64, ptr %l163, !tbaa !24
  store i64 %t265, ptr %l159, !tbaa !24
  br label %bb50
bb48:
  br label %bb49
bb49:
  store i64 -1, ptr %l159, !tbaa !24
  br label %bb50
bb50:
  %t266 = load i64, ptr %l159, !tbaa !24
  store i64 %t266, ptr %l22, !tbaa !24
  %t267 = load i64, ptr %l22, !tbaa !24
  %t269 = icmp sge i64 %t267, 0
  br i1 %t269, label %bb51, label %bb52
bb51:
  %t271 = load i64, ptr %l22, !tbaa !24
  store i64 %t271, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/types:Table", ptr %t273, i32 0, i32 30
  %t277 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t275)
  store i64 %t277, ptr %l170
  br label %bb54
bb54:
  %t278 = load i64, ptr %l170, !tbaa !24
  store i64 %t278, ptr %l22, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  store i64 %t281, ptr %l172, !tbaa !24
  %t282 = load i64, ptr %l172, !tbaa !24
  %t283 = icmp sge i64 %t282, 0
  br i1 %t283, label %bb55, label %bb56
bb55:
  %t285 = load i64, ptr %l172, !tbaa !24
  %t286 = icmp sle i64 %t285, 1152921504606846975
  br i1 %t286, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_a8733e64b1dc76a5_71d130d56df9fbd1)
  unreachable
bb57:
  %t288 = load i64, ptr %l172, !tbaa !24
  %t289 = mul i64 %t288, 8
  %t290 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t289)
  %t291 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  store i64 %t296, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t298 = load i64, ptr %l25, !tbaa !24
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = icmp sgt i64 %t298, %t299
  br i1 %t302, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_a8733e64b1dc76a5_71d130d56df9fbd1)
  unreachable
bb59:
  %t304 = load i64, ptr %l26, !tbaa !24
  %t306 = icmp sgt i64 %t304, 0
  br i1 %t306, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l181, !tbaa !24
  br label %bb64
bb61:
  %t308 = load i64, ptr %l25, !tbaa !24
  %t309 = load i64, ptr %l24, !tbaa !24
  %t312 = sub i64 %t308, %t309
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = add i64 %t312, %t313
  %t318 = sub i64 %t316, 1
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = sdiv i64 %t318, %t319
  store i64 %t322, ptr %l184, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l184, !tbaa !24
  br label %bb63
bb63:
  %t324 = load i64, ptr %l184, !tbaa !24
  store i64 %t324, ptr %l181, !tbaa !24
  br label %bb64
bb64:
  %t325 = load i64, ptr %l181, !tbaa !24
  store i64 %t325, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  %t326 = load i64, ptr %l27, !tbaa !24
  %t327 = sub i64 %t326, 1
  store i64 %t327, ptr %l193, !tbaa !24
  %t328 = load i64, ptr %l27, !tbaa !24
  %t329 = icmp slt i64 %t328, 2147483648
  %t330 = load i64, ptr %l28, !tbaa !24
  %t331 = icmp sge i64 %t330, 0
  %t334 = and i1 %t329, %t331
  store i1 %t334, ptr %l196, !tbaa !21
  br label %bb65
bb65:
  %t335 = load i64, ptr %l28, !tbaa !24
  %t336 = load i64, ptr %l27, !tbaa !24
  %t339 = icmp slt i64 %t335, %t336
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb66, label %bb67
bb66:
  br label %bb70
bb67:
  br label %bb68
bb68:
  %t343 = load i64, ptr %l24, !tbaa !24
  %t344 = load i64, ptr %l28, !tbaa !24
  %t345 = load i64, ptr %l26, !tbaa !24
  %t348 = mul i64 %t344, %t345
  %t351 = add i64 %t343, %t348
  store i64 %t351, ptr %l29, !tbaa !24
  %t353 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t353, ptr %l206, !tbaa !27
  %t354 = load i64, ptr %l29, !tbaa !24
  %t355 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t355, ptr %l208, !tbaa !27
  %t356 = load i64, ptr %l29, !tbaa !24
  %t358 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr i64, ptr %t359, i64 %t356
  %t361 = load i64, ptr %t360, !tbaa !34
  %t364 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i64, ptr %t365, i64 %t354
  store i64 %t361, ptr %t366, !tbaa !34
  br label %bb69
bb69:
  %t367 = load i64, ptr %l28, !tbaa !24
  %t370 = add i64 %t367, 1
  store i64 %t370, ptr %l28, !tbaa !24
  br label %bb65
bb70:
  %t372 = load i1, ptr %l3, !tbaa !21
  br i1 %t372, label %bb71, label %bb72
bb71:
  %t374 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l215, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb73
bb73:
  %t378 = load i64, ptr %l215, !tbaa !24
  %t379 = icmp sge i64 %t378, 0
  br i1 %t379, label %bb74, label %bb75
bb74:
  %t381 = load i64, ptr %l215, !tbaa !24
  %t382 = icmp sle i64 %t381, 1152921504606846975
  br i1 %t382, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_2503dd88f5595486_6b85ccba56568eb2)
  unreachable
bb76:
  %t384 = load i64, ptr %l215, !tbaa !24
  %t385 = mul i64 %t384, 8
  %t386 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t385)
  %t387 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  store { i64, ptr } %t388, ptr %l30, !tbaa !27
  %t390 = load i1, ptr %l3, !tbaa !21
  br i1 %t390, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_2503dd88f5595486_6b85ccba56568eb2)
  unreachable
bb78:
  store i64 0, ptr %l31, !tbaa !24
  %t392 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t392, 0
  store i64 %t394, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t396 = load i64, ptr %l32, !tbaa !24
  %t397 = load i64, ptr %l31, !tbaa !24
  %t400 = icmp sgt i64 %t396, %t397
  br i1 %t400, label %bb80, label %bb81
bb79:
  br label %bb92
bb80:
  %t402 = load i64, ptr %l33, !tbaa !24
  %t404 = icmp sgt i64 %t402, 0
  br i1 %t404, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l227, !tbaa !24
  br label %bb85
bb82:
  %t406 = load i64, ptr %l32, !tbaa !24
  %t407 = load i64, ptr %l31, !tbaa !24
  %t410 = sub i64 %t406, %t407
  %t411 = load i64, ptr %l33, !tbaa !24
  %t414 = add i64 %t410, %t411
  %t416 = sub i64 %t414, 1
  %t417 = load i64, ptr %l33, !tbaa !24
  %t420 = sdiv i64 %t416, %t417
  store i64 %t420, ptr %l230, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l230, !tbaa !24
  br label %bb84
bb84:
  %t422 = load i64, ptr %l230, !tbaa !24
  store i64 %t422, ptr %l227, !tbaa !24
  br label %bb85
bb85:
  %t423 = load i64, ptr %l227, !tbaa !24
  store i64 %t423, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t424 = load i64, ptr %l34, !tbaa !24
  %t425 = sub i64 %t424, 1
  store i64 %t425, ptr %l239, !tbaa !24
  %t426 = load i64, ptr %l34, !tbaa !24
  %t427 = icmp slt i64 %t426, 2147483648
  %t428 = load i64, ptr %l35, !tbaa !24
  %t429 = icmp sge i64 %t428, 0
  %t432 = and i1 %t427, %t429
  store i1 %t432, ptr %l242, !tbaa !21
  br label %bb86
bb86:
  %t433 = load i64, ptr %l35, !tbaa !24
  %t434 = load i64, ptr %l34, !tbaa !24
  %t437 = icmp slt i64 %t433, %t434
  %t439 = xor i1 %t437, true
  br i1 %t439, label %bb87, label %bb88
bb87:
  br label %bb91
bb88:
  br label %bb89
bb89:
  %t441 = load i64, ptr %l31, !tbaa !24
  %t442 = load i64, ptr %l35, !tbaa !24
  %t443 = load i64, ptr %l33, !tbaa !24
  %t446 = mul i64 %t442, %t443
  %t449 = add i64 %t441, %t446
  store i64 %t449, ptr %l36, !tbaa !24
  %t451 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t451, ptr %l252, !tbaa !27
  %t452 = load i64, ptr %l36, !tbaa !24
  %t453 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t453, ptr %l254, !tbaa !27
  %t454 = load i64, ptr %l36, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i64, ptr %t457, i64 %t454
  %t459 = load i64, ptr %t458, !tbaa !34
  %t462 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr i64, ptr %t463, i64 %t452
  store i64 %t459, ptr %t464, !tbaa !34
  br label %bb90
bb90:
  %t465 = load i64, ptr %l35, !tbaa !24
  %t468 = add i64 %t465, 1
  store i64 %t468, ptr %l35, !tbaa !24
  br label %bb86
bb91:
  br label %bb92
bb92:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/types:Table", ptr %t470, i32 0, i32 30
  %t473 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t472, { i64, ptr } %t473)
  br label %bb93
bb93:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/types:Table", ptr %t476, i32 0, i32 32
  %t479 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t478, { i64, ptr } %t479)
  br label %bb94
bb94:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/types:Table", ptr %t482, i32 0, i32 31
  %t485 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t486 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t484, { i64, ptr } %t485, i64 %t486)
  br label %bb95
bb95:
  %t490 = load i64, ptr %l22, !tbaa !24
  store i64 %t490, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t4, i32 %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l32 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l60 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l104 = alloca i64
  %l107 = alloca i64
  %l125 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesOf(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load i64, ptr %l23, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t9, ptr %l26, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l27, !tbaa !24
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l28, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t23, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t25, ptr %l29
  br label %bb5
bb5:
  %t26 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t26, ptr %l2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %t27, i32 %t28)
  store i64 %t31, ptr %l32
  br label %bb6
bb6:
  %t32 = load i64, ptr %l32, !tbaa !24
  store i64 %t32, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t33 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb12
bb9:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l41, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l41, !tbaa !24
  store i64 %t62, ptr %l38, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l38, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  store i64 %t83, ptr %l60, !tbaa !24
  %t84 = load i64, ptr %l60, !tbaa !24
  %t85 = load i64, ptr %l60, !tbaa !24
  %t86 = shl i64 1, %t85
  %t89 = and i64 %t82, %t86
  %t91 = icmp ne i64 %t89, 0
  br i1 %t91, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t93
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !37
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t100 = extractvalue { i64, ptr } %t96, 1
  %t101 = extractvalue { i64, ptr } %t96, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t97, i64 %t98)
  %t104 = getelementptr i8, ptr %t103, i64 %t98
  call void @olang_textcopy(ptr %t104, ptr %t100, i64 %t101)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } %t106)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb13
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l1, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBorrowsOf(ptr %v0, ptr %s7, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l74
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t120, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t126 = load i64, ptr %l11, !tbaa !24
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t134 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t134, ptr %l82, !tbaa !27
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i64, ptr %t138, i64 %t135
  %t140 = load i64, ptr %t139, !tbaa !34
  store ptr %l2, ptr %l85, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l1, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamName(ptr %v0, ptr %s8, ptr %v2, ptr %t142, i32 %t143, i64 %t140)
  store { i64, ptr } %t148, ptr %l89
  br label %bb28
bb28:
  %t149 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t151 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = add i64 %t150, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t149, i64 %t150)
  %t156 = getelementptr i8, ptr %t155, i64 %t150
  call void @olang_textcopy(ptr %t156, ptr %t152, i64 %t153)
  %t157 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  %t160 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t160, { i64, ptr } %t158)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  %t162 = load i64, ptr %l11, !tbaa !24
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %l11, !tbaa !24
  br label %bb24
bb31:
  call void @__olang_scope_close(ptr %s7)
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l1, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsOf(ptr %v0, ptr %s0, ptr %t167, i32 %t168)
  store { i64, ptr } %t171, ptr %l97
  br label %bb32
bb32:
  %t172 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t172, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t177 = sdiv i64 %t175, 3
  store i64 %t177, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t179 = load i64, ptr %l16, !tbaa !24
  %t180 = load i64, ptr %l15, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb33, label %bb34
bb33:
  %t185 = load i64, ptr %l17, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb38
bb35:
  %t189 = load i64, ptr %l16, !tbaa !24
  %t190 = load i64, ptr %l15, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l17, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l107, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb37
bb37:
  %t205 = load i64, ptr %l107, !tbaa !24
  store i64 %t205, ptr %l104, !tbaa !24
  br label %bb38
bb38:
  %t206 = load i64, ptr %l104, !tbaa !24
  store i64 %t206, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t207 = load i64, ptr %l19, !tbaa !24
  %t208 = load i64, ptr %l18, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t215 = load i64, ptr %l15, !tbaa !24
  %t216 = load i64, ptr %l19, !tbaa !24
  %t217 = load i64, ptr %l17, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  store i64 %t223, ptr %l20, !tbaa !24
  store ptr %l2, ptr %l125, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l1, !tbaa !23
  %t227 = load i64, ptr %l20, !tbaa !24
  %t229 = mul i64 3, %t227
  %t231 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i64, ptr %t232, i64 %t229
  %t234 = load i64, ptr %t233, !tbaa !34
  %t235 = load i64, ptr %l20, !tbaa !24
  %t237 = mul i64 3, %t235
  %t239 = add i64 %t237, 1
  %t241 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i64, ptr %t242, i64 %t239
  %t244 = load i64, ptr %t243, !tbaa !34
  %t245 = load i64, ptr %l20, !tbaa !24
  %t247 = mul i64 3, %t245
  %t249 = add i64 %t247, 2
  %t251 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i64, ptr %t252, i64 %t249
  %t254 = load i64, ptr %t253, !tbaa !34
  %t260 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsText(ptr %v0, ptr %s12, ptr %v2, ptr %t225, i32 %t226, i64 %t234, i64 %t244, i64 %t254)
  store { i64, ptr } %t260, ptr %l139
  br label %bb43
bb43:
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t263 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = add i64 %t262, %t265
  %t267 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t261, i64 %t262)
  %t268 = getelementptr i8, ptr %t267, i64 %t262
  call void @olang_textcopy(ptr %t268, ptr %t264, i64 %t265)
  %t269 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t267, 1
  %t272 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t272, { i64, ptr } %t270)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb45:
  %t274 = load i64, ptr %l19, !tbaa !24
  %t277 = add i64 %t274, 1
  store i64 %t277, ptr %l19, !tbaa !24
  br label %bb39
bb46:
  %t280 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t280, ptr %l146
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t281 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t281, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i1
  %l35 = alloca i64
  %l39 = alloca i64
  %l43 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l80 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i1
  %l122 = alloca { i64, ptr }
  %l136 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i32
  %l147 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp eq i64 %t7, 0
  store i1 %t9, ptr %l21, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l21, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l25, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l25, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = add i64 2, %t22
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t30 = add i64 %t24, %t27
  store i64 %t30, ptr %l35, !tbaa !24
  %t31 = load i64, ptr %l35, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load i64, ptr %l35, !tbaa !24
  %t35 = icmp sle i64 %t34, 1152921504606846975
  br i1 %t35, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8822c3adad84af9f_bf049295f8c08d23)
  unreachable
bb12:
  %t37 = load i64, ptr %l35, !tbaa !24
  %t38 = mul i64 %t37, 8
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t42, ptr %lp4
  %t44 = load ptr, ptr %lp4
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l39, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8822c3adad84af9f_bf049295f8c08d23)
  unreachable
bb14:
  %t52 = load i64, ptr @G_2ecompiler_2ftypes_2ePromBorrows, !tbaa !24
  store i64 %t52, ptr %l43, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t54 = load i64, ptr %l39, !tbaa !24
  %t55 = load i64, ptr %l43, !tbaa !24
  %t56 = or i64 %t54, %t55
  %t58 = load ptr, ptr %lp4
  %t59 = getelementptr { i64, ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 0
  store i64 %t56, ptr %t61, !tbaa !34
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = load ptr, ptr %lp4
  %t67 = getelementptr { i64, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i64, ptr %t68, i64 1
  store i64 %t64, ptr %t69, !tbaa !34
  store i64 0, ptr %l5, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = icmp sgt i64 %t74, %t75
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t80, 0
  br i1 %t82, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb22
bb19:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t94 = sub i64 %t92, 1
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = sdiv i64 %t94, %t95
  store i64 %t98, ptr %l56, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l56, !tbaa !24
  store i64 %t100, ptr %l53, !tbaa !24
  br label %bb22
bb22:
  %t101 = load i64, ptr %l53, !tbaa !24
  store i64 %t101, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = sub i64 %t102, 1
  store i64 %t103, ptr %l65, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t104, 2147483648
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  %t110 = and i1 %t105, %t107
  store i1 %t110, ptr %l68, !tbaa !21
  br label %bb23
bb23:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t119 = load i64, ptr %l5, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t131 = add i64 2, %t129
  %t132 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t132, ptr %l80, !tbaa !27
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i64, ptr %t136, i64 %t133
  %t138 = load i64, ptr %t137, !tbaa !34
  %t140 = load ptr, ptr %lp4
  %t142 = getelementptr { i64, ptr }, ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t131
  store i64 %t138, ptr %t144, !tbaa !34
  br label %bb27
bb27:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb23
bb28:
  %t150 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t154 = add i64 2, %t152
  store i64 %t154, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  store i64 %t158, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l12, !tbaa !24
  %t164 = icmp sgt i64 %t160, %t161
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = load i64, ptr %l14, !tbaa !24
  %t168 = icmp sgt i64 %t166, 0
  br i1 %t168, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb34
bb31:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = sub i64 %t170, %t171
  %t175 = load i64, ptr %l14, !tbaa !24
  %t178 = add i64 %t174, %t175
  %t180 = sub i64 %t178, 1
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = sdiv i64 %t180, %t181
  store i64 %t184, ptr %l97, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb33
bb33:
  %t186 = load i64, ptr %l97, !tbaa !24
  store i64 %t186, ptr %l94, !tbaa !24
  br label %bb34
bb34:
  %t187 = load i64, ptr %l94, !tbaa !24
  store i64 %t187, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = sub i64 %t188, 1
  store i64 %t189, ptr %l106, !tbaa !24
  %t190 = load i64, ptr %l15, !tbaa !24
  %t191 = icmp slt i64 %t190, 2147483648
  %t192 = load i64, ptr %l16, !tbaa !24
  %t193 = icmp sge i64 %t192, 0
  %t196 = and i1 %t191, %t193
  store i1 %t196, ptr %l109, !tbaa !21
  br label %bb35
bb35:
  %t197 = load i64, ptr %l16, !tbaa !24
  %t198 = load i64, ptr %l15, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t205 = load i64, ptr %l12, !tbaa !24
  %t206 = load i64, ptr %l16, !tbaa !24
  %t207 = load i64, ptr %l14, !tbaa !24
  %t210 = mul i64 %t206, %t207
  %t213 = add i64 %t205, %t210
  store i64 %t213, ptr %l17, !tbaa !24
  %t215 = load i64, ptr %l11, !tbaa !24
  %t216 = load i64, ptr %l17, !tbaa !24
  %t219 = add i64 %t215, %t216
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t220, ptr %l122, !tbaa !27
  %t221 = load i64, ptr %l17, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i64, ptr %t224, i64 %t221
  %t226 = load i64, ptr %t225, !tbaa !34
  %t228 = load ptr, ptr %lp4
  %t230 = getelementptr { i64, ptr }, ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i64, ptr %t231, i64 %t219
  store i64 %t226, ptr %t232, !tbaa !34
  br label %bb39
bb39:
  %t233 = load i64, ptr %l16, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l16, !tbaa !24
  br label %bb35
bb40:
  %t238 = load ptr, ptr %lp4
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  call void @compiler_2ftypes_2esortRuns(ptr %v0, { i64, ptr } %t239, i64 2, i64 %t242, i64 1)
  br label %bb41
bb41:
  %t245 = load ptr, ptr %lp4
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l11, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t252 = sdiv i64 %t250, 3
  call void @compiler_2ftypes_2esortRuns(ptr %v0, { i64, ptr } %t246, i64 %t247, i64 %t252, i64 3)
  br label %bb42
bb42:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/types:Table", ptr %t256, i32 0, i32 35
  %t259 = load ptr, ptr %lp4
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t263 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t258, { i64, ptr } %t260)
  %t264 = extractvalue { i32, i64 } %t263, 1
  %t265 = extractvalue { i32, i64 } %t263, 0
  store i32 %t265, ptr %l141
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb44, label %ok.267, !prof !99
ok.267:
  store i64 %t264, ptr %l140
  br label %bb43
bb43:
  %t268 = load i64, ptr %l140, !tbaa !24
  store i64 %t268, ptr %l136, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  store i64 -1, ptr %l136, !tbaa !24
  br label %bb46
bb46:
  %t269 = load i64, ptr %l136, !tbaa !24
  store i64 %t269, ptr %l18, !tbaa !24
  %t270 = load i64, ptr %l18, !tbaa !24
  %t272 = icmp sge i64 %t270, 0
  br i1 %t272, label %bb47, label %bb48
bb47:
  %t274 = load i64, ptr %l18, !tbaa !24
  store i64 %t274, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/types:Table", ptr %t276, i32 0, i32 34
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t278)
  store i64 %t280, ptr %l147
  br label %bb50
bb50:
  %t281 = load i64, ptr %l147, !tbaa !24
  store i64 %t281, ptr %l18, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/types:Table", ptr %t282, i32 0, i32 34
  %t285 = load ptr, ptr %lp4
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t284, { i64, ptr } %t286)
  br label %bb51
bb51:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/types:Table", ptr %t289, i32 0, i32 35
  %t292 = load ptr, ptr %lp4
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t294 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t291, { i64, ptr } %t293, i64 %t294)
  br label %bb52
bb52:
  %t298 = load i64, ptr %l18, !tbaa !24
  store i64 %t298, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReceiverPromises(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l23 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i1
  %l54 = alloca i64
  %l63 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i1
  %l103 = alloca i64
  %l110 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca i64
  %l125 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesOf(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBorrowsOf(ptr %v0, ptr %s0, ptr %t10, i32 %t11)
  store { i64, ptr } %t14, ptr %l23
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb8:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l32, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb10
bb10:
  %t46 = load i64, ptr %l32, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l29, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = sub i64 %t48, 1
  store i64 %t49, ptr %l41, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t50, 2147483648
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp sge i64 %t52, 0
  %t56 = and i1 %t51, %t53
  store i1 %t56, ptr %l44, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l54, !tbaa !24
  %t76 = load i64, ptr %l54, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i64, ptr %t78, i64 %t76
  %t80 = load i64, ptr %t79, !tbaa !34
  %t83 = add i64 %t80, 1
  %t85 = load i64, ptr %l54, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i64, ptr %t87, i64 %t85
  store i64 %t83, ptr %t88, !tbaa !34
  br label %bb16
bb16:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = add i64 %t89, 1
  store i64 %t92, ptr %l7, !tbaa !24
  br label %bb12
bb17:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsOf(ptr %v0, ptr %s0, ptr %t94, i32 %t95)
  store { i64, ptr } %t98, ptr %l63
  br label %bb18
bb18:
  %t99 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t99, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = sdiv i64 %t102, 3
  store i64 %t104, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = icmp sgt i64 %t106, %t107
  br i1 %t110, label %bb19, label %bb20
bb19:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb24
bb21:
  %t116 = load i64, ptr %l11, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = sub i64 %t116, %t117
  %t121 = load i64, ptr %l12, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t126 = sub i64 %t124, 1
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = sdiv i64 %t126, %t127
  store i64 %t130, ptr %l73, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb23
bb23:
  %t132 = load i64, ptr %l73, !tbaa !24
  store i64 %t132, ptr %l70, !tbaa !24
  br label %bb24
bb24:
  %t133 = load i64, ptr %l70, !tbaa !24
  store i64 %t133, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = sub i64 %t134, 1
  store i64 %t135, ptr %l82, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  %t137 = icmp slt i64 %t136, 2147483648
  %t138 = load i64, ptr %l14, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  %t142 = and i1 %t137, %t139
  store i1 %t142, ptr %l85, !tbaa !21
  br label %bb25
bb25:
  %t143 = load i64, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb26, label %bb27
bb26:
  br label %bb33
bb27:
  br label %bb28
bb28:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t152 = load i64, ptr %l14, !tbaa !24
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l15, !tbaa !24
  %t163 = mul i64 3, %t161
  %t164 = load i64, ptr %l15, !tbaa !24
  %t166 = mul i64 3, %t164
  %t168 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i64, ptr %t169, i64 %t166
  %t171 = load i64, ptr %t170, !tbaa !34
  %t173 = add i64 %t171, 1
  %t176 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t163
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l15, !tbaa !24
  %t181 = mul i64 3, %t179
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l103, !tbaa !24
  %t184 = load i64, ptr %l15, !tbaa !24
  %t186 = mul i64 3, %t184
  %t188 = add i64 %t186, 1
  %t190 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t194 = load i64, ptr @G_2ecompiler_2ftypes_2eKeepsHome, !tbaa !24
  %t197 = icmp eq i64 %t193, %t194
  br i1 %t197, label %bb29, label %bb30
bb29:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb31
bb30:
  %t199 = load i64, ptr %l15, !tbaa !24
  %t201 = mul i64 3, %t199
  %t203 = add i64 %t201, 1
  %t205 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i64, ptr %t206, i64 %t203
  %t208 = load i64, ptr %t207, !tbaa !34
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l110, !tbaa !24
  br label %bb31
bb31:
  %t212 = load i64, ptr %l110, !tbaa !24
  %t213 = load i64, ptr %l103, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t212, ptr %t216, !tbaa !34
  br label %bb32
bb32:
  %t217 = load i64, ptr %l14, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l14, !tbaa !24
  br label %bb25
bb33:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l119, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l1, !tbaa !23
  %t227 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %t223, i32 %t224)
  store i64 %t227, ptr %l122
  br label %bb34
bb34:
  %t228 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t230 = load ptr, ptr %l119, !tbaa !29
  %t231 = load i64, ptr %l122, !tbaa !24
  %t234 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromises(ptr %v0, ptr %s0, ptr %s0, ptr %t230, i64 %t231, { i64, ptr } %t228, { i64, ptr } %t229)
  store i64 %t234, ptr %l125
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t235 = load i64, ptr %l125, !tbaa !24
  store i64 %t235, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i32
  %l22 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l66 = alloca { i64, ptr }
  %l74 = alloca [1 x i32]
  %l75 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i32, ptr %l13, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = icmp sle i64 0, 2305843009213693951
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f7b42ec29d1607_26e89eedc9b3128b)
  unreachable
bb6:
  %t17 = mul i64 0, 4
  %t18 = insertvalue { i64, ptr } undef, i64 0, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f7b42ec29d1607_26e89eedc9b3128b)
  unreachable
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l22
  br label %bb9
bb9:
  %t26 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t28 = trunc i64 22 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l28
  br label %bb12
bb11:
  br label %bb30
bb12:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load i32, ptr %l28, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l31, !tbaa !24
  %t48 = icmp sle i64 %t47, 2305843009213693951
  br i1 %t48, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2df495a001b30f12_f15d21f3e8677f6)
  unreachable
bb16:
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = mul i64 %t50, 4
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2df495a001b30f12_f15d21f3e8677f6)
  unreachable
bb18:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb23
bb20:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l43, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t86 = load i64, ptr %l43, !tbaa !24
  store i64 %t86, ptr %l40, !tbaa !24
  br label %bb23
bb23:
  %t87 = load i64, ptr %l40, !tbaa !24
  store i64 %t87, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t90, 2147483648
  %t92 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  %t96 = and i1 %t91, %t93
  store i1 %t96, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t116, ptr %l66, !tbaa !27
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t117
  %t122 = load i32, ptr %t121, !tbaa !33
  %t125 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t115
  store i32 %t122, ptr %t127, !tbaa !33
  br label %bb28
bb28:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t128, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb24
bb29:
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t133, ptr %rv
  br label %ret
bb30:
  %t135 = load i32, ptr %l2, !tbaa !23
  %t137 = insertvalue [1 x i32] undef, i32 %t135, 0
  store [1 x i32] %t137, ptr %l74
  %t138 = mul i64 1, 4
  %t139 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 1, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l75, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %l74, i64 %t144, i1 false)
  %t145 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t145, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t13, i32 %t14)
  store { i64, ptr } %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t19 = icmp sgt i64 %t17, 0
  store i1 %t19, ptr %l3, !tbaa !21
  %t21 = load i32, ptr %l2, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t25 = icmp ne i32 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l20
  br label %bb6
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load i1, ptr %l3, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l27, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t53, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load i1, ptr %l3, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s2, ptr %v2, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l33
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t64 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t69, ptr %rv
  br label %ret
bb17:
  %t71 = load i32, ptr %l2, !tbaa !23
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t75 = icmp eq i32 %t71, %t72
  br i1 %t75, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l40, !tbaa !24
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l41, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t91, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s0, ptr %v2, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l44
  br label %bb21
bb21:
  %t98 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l27 = alloca [1 x i64]
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %l81 = alloca i1
  %l87 = alloca { i64, ptr }
  %l93 = alloca i64
  %l96 = alloca i64
  %l117 = alloca i64
  %l121 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i1
  %l130 = alloca i1
  %l134 = alloca i1
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca i64
  %l145 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleDtor, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t15 = insertvalue [1 x i64] undef, i64 %t13, 0
  store [1 x i64] %t15, ptr %l27
  %t16 = mul i64 1, 8
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 1, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l28, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = mul i64 1, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l27, i64 %t22, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l29
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l3
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l30, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l33
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load i32, ptr %l33, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l34
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb13
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l43, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l43, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l1, !tbaa !23
  %t88 = load i64, ptr %l10, !tbaa !24
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t86, i32 %t87, i64 %t88)
  store i64 %t92, ptr %l64
  br label %bb18
bb18:
  %t93 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t94 = load i64, ptr %l64, !tbaa !24
  %t96 = icmp eq i64 %t94, %t93
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l69, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t98, i32 %t105)
  store i1 %t108, ptr %l72
  br label %bb21
bb20:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb22
bb21:
  %t109 = load i1, ptr %l72, !tbaa !21
  store i1 %t109, ptr %l67, !tbaa !21
  br label %bb22
bb22:
  %t110 = load i1, ptr %l67, !tbaa !21
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t111 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t111)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %l9, !tbaa !24
  br label %bb14
bb28:
  %t119 = load i64, ptr %l2, !tbaa !24
  %t120 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  br i1 %t123, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb31
bb30:
  %t125 = load i64, ptr %l2, !tbaa !24
  %t126 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleTail, !tbaa !24
  %t129 = icmp eq i64 %t125, %t126
  store i1 %t129, ptr %l81, !tbaa !21
  br label %bb31
bb31:
  %t131 = load i1, ptr %l81, !tbaa !21
  store i1 %t131, ptr %l11, !tbaa !21
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l87
  br label %bb32
bb32:
  %t137 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t137, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb33, label %bb34
bb33:
  %t148 = load i64, ptr %l15, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb38
bb35:
  %t152 = load i64, ptr %l14, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l96, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb37
bb37:
  %t168 = load i64, ptr %l96, !tbaa !24
  store i64 %t168, ptr %l93, !tbaa !24
  br label %bb38
bb38:
  %t169 = load i64, ptr %l93, !tbaa !24
  store i64 %t169, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t170 = load i64, ptr %l17, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb40, label %bb41
bb40:
  br label %bb59
bb41:
  br label %bb42
bb42:
  %t178 = load i64, ptr %l13, !tbaa !24
  %t179 = load i64, ptr %l17, !tbaa !24
  %t180 = load i64, ptr %l15, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l18, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l1, !tbaa !23
  %t190 = load i64, ptr %l18, !tbaa !24
  %t194 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t188, i32 %t189, i64 %t190)
  store i64 %t194, ptr %l117
  br label %bb43
bb43:
  %t195 = load i64, ptr %l117, !tbaa !24
  store i64 %t195, ptr %l19, !tbaa !24
  %t196 = load i64, ptr %l19, !tbaa !24
  %t197 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t200 = icmp eq i64 %t196, %t197
  br i1 %t200, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb46
bb45:
  %t202 = load i64, ptr %l19, !tbaa !24
  %t203 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t206 = icmp eq i64 %t202, %t203
  store i1 %t206, ptr %l121, !tbaa !21
  br label %bb46
bb46:
  %t208 = load i1, ptr %l121, !tbaa !21
  br i1 %t208, label %bb47, label %bb48
bb47:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i32, ptr %t213, i64 %t210
  %t215 = load i32, ptr %t214, !tbaa !33
  %t218 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t209, i32 %t215)
  store i1 %t218, ptr %l129
  br label %bb49
bb48:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb54
bb49:
  %t219 = load i1, ptr %l129, !tbaa !21
  br i1 %t219, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb53
bb51:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i64, ptr %l18, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i32, ptr %t224, i64 %t221
  %t226 = load i32, ptr %t225, !tbaa !33
  %t229 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t220, i32 %t226)
  store i1 %t229, ptr %l134
  br label %bb52
bb52:
  %t230 = load i1, ptr %l134, !tbaa !21
  store i1 %t230, ptr %l130, !tbaa !21
  br label %bb53
bb53:
  %t231 = load i1, ptr %l130, !tbaa !21
  store i1 %t231, ptr %l125, !tbaa !21
  br label %bb54
bb54:
  %t232 = load i1, ptr %l125, !tbaa !21
  br i1 %t232, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t233 = load i64, ptr %l17, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l17, !tbaa !24
  br label %bb39
bb59:
  %t238 = load i1, ptr %l11, !tbaa !21
  br i1 %t238, label %bb60, label %bb61
bb60:
  %t240 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t240)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t244 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t244, ptr %l142
  br label %bb64
bb64:
  %t245 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t245, ptr %l143, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  store i64 %t247, ptr %l144, !tbaa !24
  %t248 = load i64, ptr %l144, !tbaa !24
  %t249 = mul i64 %t248, 8
  %t250 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t249)
  %t251 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  store { i64, ptr } %t252, ptr %l145, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = load i64, ptr %l144, !tbaa !24
  %t258 = mul i64 %t257, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t254, ptr %t256, i64 %t258, i1 false)
  %t259 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t260 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t260, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i1
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l58 = alloca i64
  %l61 = alloca i1
  %l66 = alloca { i64, ptr }
  %l71 = alloca i1
  %l85 = alloca i64
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l101 = alloca i64
  %l104 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l140 = alloca i64
  %l143 = alloca i64
  %l152 = alloca i64
  %l155 = alloca i1
  %l165 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l177 = alloca i32
  %l181 = alloca i32
  %l182 = alloca i32
  %l188 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  store i1 %t5, ptr %l4, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = sub i64 %t13, 1
  store i64 %t14, ptr %l35, !tbaa !24
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t15, 2147483648
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  %t21 = and i1 %t16, %t18
  store i1 %t21, ptr %l38, !tbaa !21
  br label %bb1
bb1:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t30, ptr %l43, !tbaa !27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i64, ptr %t34, i64 %t31
  %t36 = load i64, ptr %t35, !tbaa !34
  store i64 %t36, ptr %l8, !tbaa !24
  %t38 = load i1, ptr %l4, !tbaa !21
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  store i1 %t45, ptr %l48, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb7
bb7:
  %t47 = load i1, ptr %l48, !tbaa !21
  store i1 %t47, ptr %l4, !tbaa !21
  br label %bb8
bb8:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l6, !tbaa !24
  br label %bb1
bb9:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t53, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l11, !tbaa !24
  %t59 = load i64, ptr %l11, !tbaa !24
  %t60 = sub i64 %t59, 1
  store i64 %t60, ptr %l58, !tbaa !24
  %t61 = load i64, ptr %l11, !tbaa !24
  %t62 = icmp slt i64 %t61, 2147483648
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  %t67 = and i1 %t62, %t64
  store i1 %t67, ptr %l61, !tbaa !21
  br label %bb10
bb10:
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb11, label %bb12
bb11:
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t76 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t76, ptr %l66, !tbaa !27
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  store i64 %t82, ptr %l12, !tbaa !24
  %t84 = load i1, ptr %l4, !tbaa !21
  br i1 %t84, label %bb14, label %bb15
bb14:
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  store i1 %t91, ptr %l71, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb16
bb16:
  %t93 = load i1, ptr %l71, !tbaa !21
  store i1 %t93, ptr %l4, !tbaa !21
  br label %bb17
bb17:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  %t99 = load i1, ptr %l4, !tbaa !21
  br i1 %t99, label %bb19, label %bb20
bb19:
  store i32 0, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = add i64 2, %t104
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t112 = add i64 %t106, %t109
  store i64 %t112, ptr %l85, !tbaa !24
  %t113 = load i64, ptr %l85, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l85, !tbaa !24
  %t117 = icmp sle i64 %t116, 1152921504606846975
  br i1 %t117, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_63e623ceae63df16_2a862fe3f0344bd2)
  unreachable
bb24:
  %t119 = load i64, ptr %l85, !tbaa !24
  %t120 = mul i64 %t119, 8
  %t121 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l13, !tbaa !27
  %t125 = load i64, ptr %l1, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t131, ptr %l92, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i64, ptr %t135, i64 0
  store i64 %t125, ptr %t136, !tbaa !34
  %t137 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t137, ptr %l94, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i64, ptr %t141, i64 1
  store i64 %t129, ptr %t142, !tbaa !34
  store i64 0, ptr %l16, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t147 = load i64, ptr %l17, !tbaa !24
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = icmp sgt i64 %t147, %t148
  br i1 %t151, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_63e623ceae63df16_2a862fe3f0344bd2)
  unreachable
bb26:
  %t153 = load i64, ptr %l18, !tbaa !24
  %t155 = icmp sgt i64 %t153, 0
  br i1 %t155, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb31
bb28:
  %t157 = load i64, ptr %l17, !tbaa !24
  %t158 = load i64, ptr %l16, !tbaa !24
  %t161 = sub i64 %t157, %t158
  %t162 = load i64, ptr %l18, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = sub i64 %t165, 1
  %t168 = load i64, ptr %l18, !tbaa !24
  %t171 = sdiv i64 %t167, %t168
  store i64 %t171, ptr %l104, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb30
bb30:
  %t173 = load i64, ptr %l104, !tbaa !24
  store i64 %t173, ptr %l101, !tbaa !24
  br label %bb31
bb31:
  %t174 = load i64, ptr %l101, !tbaa !24
  store i64 %t174, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t175 = load i64, ptr %l19, !tbaa !24
  %t176 = sub i64 %t175, 1
  store i64 %t176, ptr %l113, !tbaa !24
  %t177 = load i64, ptr %l19, !tbaa !24
  %t178 = icmp slt i64 %t177, 2147483648
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = icmp sge i64 %t179, 0
  %t183 = and i1 %t178, %t180
  store i1 %t183, ptr %l116, !tbaa !21
  br label %bb32
bb32:
  %t184 = load i64, ptr %l20, !tbaa !24
  %t185 = load i64, ptr %l19, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t193 = load i64, ptr %l20, !tbaa !24
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  store i64 %t200, ptr %l21, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t202, ptr %l126, !tbaa !27
  %t203 = load i64, ptr %l21, !tbaa !24
  %t205 = add i64 2, %t203
  %t206 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t206, ptr %l129, !tbaa !27
  %t207 = load i64, ptr %l21, !tbaa !24
  %t209 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i64, ptr %t210, i64 %t207
  %t212 = load i64, ptr %t211, !tbaa !34
  %t215 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i64, ptr %t216, i64 %t205
  store i64 %t212, ptr %t217, !tbaa !34
  br label %bb36
bb36:
  %t218 = load i64, ptr %l20, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l20, !tbaa !24
  br label %bb32
bb37:
  store i64 0, ptr %l22, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  store i64 %t225, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t227 = load i64, ptr %l23, !tbaa !24
  %t228 = load i64, ptr %l22, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb38, label %bb39
bb38:
  %t233 = load i64, ptr %l24, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb43
bb40:
  %t237 = load i64, ptr %l23, !tbaa !24
  %t238 = load i64, ptr %l22, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l24, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l24, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l143, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb42
bb42:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l140, !tbaa !24
  br label %bb43
bb43:
  %t254 = load i64, ptr %l140, !tbaa !24
  store i64 %t254, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t255 = load i64, ptr %l25, !tbaa !24
  %t256 = sub i64 %t255, 1
  store i64 %t256, ptr %l152, !tbaa !24
  %t257 = load i64, ptr %l25, !tbaa !24
  %t258 = icmp slt i64 %t257, 2147483648
  %t259 = load i64, ptr %l26, !tbaa !24
  %t260 = icmp sge i64 %t259, 0
  %t263 = and i1 %t258, %t260
  store i1 %t263, ptr %l155, !tbaa !21
  br label %bb44
bb44:
  %t264 = load i64, ptr %l26, !tbaa !24
  %t265 = load i64, ptr %l25, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t272 = load i64, ptr %l22, !tbaa !24
  %t273 = load i64, ptr %l26, !tbaa !24
  %t274 = load i64, ptr %l24, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l27, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t282, ptr %l165, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t287 = add i64 2, %t285
  %t288 = load i64, ptr %l27, !tbaa !24
  %t291 = add i64 %t287, %t288
  %t292 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t292, ptr %l171, !tbaa !27
  %t293 = load i64, ptr %l27, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i64, ptr %t296, i64 %t293
  %t298 = load i64, ptr %t297, !tbaa !34
  %t301 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i64, ptr %t302, i64 %t291
  store i64 %t298, ptr %t303, !tbaa !34
  br label %bb48
bb48:
  %t304 = load i64, ptr %l26, !tbaa !24
  %t307 = add i64 %t304, 1
  store i64 %t307, ptr %l26, !tbaa !24
  br label %bb44
bb49:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/types:Table", ptr %t309, i32 0, i32 29
  %t312 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t315 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v0, ptr %t311, { i64, ptr } %t312)
  %t316 = extractvalue { i32, i32 } %t315, 1
  %t317 = extractvalue { i32, i32 } %t315, 0
  store i32 %t317, ptr %l182
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb51, label %ok.319, !prof !99
ok.319:
  store i32 %t316, ptr %l181
  br label %bb50
bb50:
  %t320 = load i32, ptr %l181, !tbaa !23
  store i32 %t320, ptr %l177, !tbaa !23
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i32 -1, ptr %l177, !tbaa !23
  br label %bb53
bb53:
  %t321 = load i32, ptr %l177, !tbaa !23
  store i32 %t321, ptr %l28, !tbaa !23
  %t322 = load i32, ptr %l28, !tbaa !23
  %t324 = icmp sge i32 %t322, 0
  br i1 %t324, label %bb54, label %bb55
bb54:
  %t326 = load i32, ptr %l28, !tbaa !23
  store i32 %t326, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/types:Table", ptr %t328, i32 0, i32 28
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t330)
  store i64 %t332, ptr %l188
  br label %bb57
bb57:
  %t333 = load i64, ptr %l188, !tbaa !24
  %t334 = trunc i64 %t333 to i32
  store i32 %t334, ptr %l28, !tbaa !23
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/types:Table", ptr %t337, i32 0, i32 28
  %t340 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t339, { i64, ptr } %t340)
  br label %bb58
bb58:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/types:Table", ptr %t343, i32 0, i32 29
  %t346 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t347 = load i32, ptr %l28, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v0, ptr %t345, { i64, ptr } %t346, i32 %t347)
  br label %bb59
bb59:
  %t351 = load i32, ptr %l28, !tbaa !23
  store i32 %t351, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %l36 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l82 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca i1
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l134 = alloca i64
  %l137 = alloca i64
  %l162 = alloca i64
  %l166 = alloca i64
  %l170 = alloca i1
  %l174 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l193 = alloca i1
  %l202 = alloca ptr
  %l205 = alloca i32
  %l208 = alloca i32
  %l209 = alloca i1
  %l212 = alloca ptr
  %l215 = alloca i32
  %l218 = alloca i32
  %l219 = alloca i1
  %l222 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l230 = alloca i32
  %l231 = alloca { i64, ptr }
  %l237 = alloca i64
  %l240 = alloca i64
  %l262 = alloca i1
  %l264 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l270 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb6
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l36
  br label %bb3
bb3:
  store ptr %l36, ptr %l37, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l40
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l37, !tbaa !29
  %t19 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %t17, ptr %l40)
  store i1 %t19, ptr %l42
  br label %bb5
bb5:
  %t20 = load i1, ptr %l42, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l33, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l47
  br label %bb10
bb10:
  %t30 = load i32, ptr %l47, !range !{i32 0, i32 33}
  store i32 %t30, ptr %l3
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t33 = trunc i64 21 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb85
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t40, ptr %l52
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l55
  br label %bb15
bb15:
  %t46 = load i64, ptr %l52, !tbaa !24
  %t47 = load i64, ptr %l55, !tbaa !24
  %t48 = icmp ne i64 %t46, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l58, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l61
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l58, !tbaa !29
  %t58 = load i32, ptr %l61, !tbaa !23
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t57, i32 %t58)
  store { i64, ptr } %t59, ptr %l62
  br label %bb20
bb20:
  %t60 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l63, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l66
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l63, !tbaa !29
  %t68 = load i32, ptr %l66, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l67
  br label %bb22
bb22:
  %t70 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t70, ptr %l5, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t79 = icmp ne i64 %t73, %t76
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb31
bb28:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l82, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb30
bb30:
  %t112 = load i64, ptr %l82, !tbaa !24
  store i64 %t112, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t113 = load i64, ptr %l79, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb33, label %bb34
bb33:
  br label %bb46
bb34:
  br label %bb35
bb35:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l1, !tbaa !23
  %t134 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  store i64 %t138, ptr %l103
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l2, !tbaa !23
  %t141 = load i64, ptr %l11, !tbaa !24
  %t145 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t139, i32 %t140, i64 %t141)
  store i64 %t145, ptr %l107
  br label %bb37
bb37:
  %t146 = load i64, ptr %l103, !tbaa !24
  %t147 = load i64, ptr %l107, !tbaa !24
  %t148 = icmp ne i64 %t146, %t147
  br i1 %t148, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb41
bb39:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l111, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i32, ptr %t155, i64 %t152
  %t157 = load i32, ptr %t156, !tbaa !33
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t158, ptr %l114, !tbaa !27
  %t159 = load i64, ptr %l11, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t150, i32 %t157, i32 %t164)
  store i1 %t168, ptr %l117
  br label %bb40
bb40:
  %t169 = load i1, ptr %l117, !tbaa !21
  %t170 = xor i1 %t169, true
  store i1 %t170, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t172 = load i1, ptr %l109, !tbaa !21
  br i1 %t172, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l1, !tbaa !23
  %t183 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t179, i32 %t180)
  store { i64, ptr } %t183, ptr %l125
  br label %bb47
bb47:
  %t184 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t184, ptr %l12, !tbaa !27
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l2, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t185, i32 %t186)
  store { i64, ptr } %t189, ptr %l128
  br label %bb48
bb48:
  %t190 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t190, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l15, !tbaa !24
  %t196 = load i64, ptr %l14, !tbaa !24
  %t199 = icmp sgt i64 %t195, %t196
  br i1 %t199, label %bb49, label %bb50
bb49:
  %t201 = load i64, ptr %l16, !tbaa !24
  %t203 = icmp sgt i64 %t201, 0
  br i1 %t203, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb54
bb51:
  %t205 = load i64, ptr %l15, !tbaa !24
  %t206 = load i64, ptr %l14, !tbaa !24
  %t209 = sub i64 %t205, %t206
  %t210 = load i64, ptr %l16, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t215 = sub i64 %t213, 1
  %t216 = load i64, ptr %l16, !tbaa !24
  %t219 = sdiv i64 %t215, %t216
  store i64 %t219, ptr %l137, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb53
bb53:
  %t221 = load i64, ptr %l137, !tbaa !24
  store i64 %t221, ptr %l134, !tbaa !24
  br label %bb54
bb54:
  %t222 = load i64, ptr %l134, !tbaa !24
  store i64 %t222, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb55
bb55:
  %t223 = load i64, ptr %l18, !tbaa !24
  %t224 = load i64, ptr %l17, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb56, label %bb57
bb56:
  br label %bb84
bb57:
  br label %bb58
bb58:
  %t231 = load i64, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l16, !tbaa !24
  %t236 = mul i64 %t232, %t233
  %t239 = add i64 %t231, %t236
  store i64 %t239, ptr %l19, !tbaa !24
  %t241 = load i64, ptr %l19, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t247 = icmp sge i64 %t241, %t244
  br i1 %t247, label %bb59, label %bb60
bb59:
  br label %bb84
bb60:
  br label %bb61
bb61:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i32, ptr %l1, !tbaa !23
  %t251 = load i64, ptr %l19, !tbaa !24
  %t255 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t249, i32 %t250, i64 %t251)
  store i64 %t255, ptr %l162
  br label %bb62
bb62:
  %t256 = load i64, ptr %l162, !tbaa !24
  store i64 %t256, ptr %l20, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l2, !tbaa !23
  %t259 = load i64, ptr %l19, !tbaa !24
  %t263 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t257, i32 %t258, i64 %t259)
  store i64 %t263, ptr %l166
  br label %bb63
bb63:
  %t264 = load i64, ptr %l166, !tbaa !24
  store i64 %t264, ptr %l21, !tbaa !24
  %t265 = load i64, ptr %l20, !tbaa !24
  %t266 = load i64, ptr %l21, !tbaa !24
  %t269 = icmp ne i64 %t265, %t266
  br i1 %t269, label %bb64, label %bb65
bb64:
  %t271 = load i64, ptr %l20, !tbaa !24
  %t272 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t275 = icmp eq i64 %t271, %t272
  br i1 %t275, label %bb66, label %bb67
bb65:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb75
bb66:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb68
bb67:
  %t277 = load i64, ptr %l20, !tbaa !24
  %t278 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t281 = icmp eq i64 %t277, %t278
  store i1 %t281, ptr %l174, !tbaa !21
  br label %bb68
bb68:
  %t283 = load i1, ptr %l174, !tbaa !21
  br i1 %t283, label %bb69, label %bb70
bb69:
  %t284 = load i64, ptr %l21, !tbaa !24
  %t285 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t288 = icmp eq i64 %t284, %t285
  br i1 %t288, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb74
bb71:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb73
bb72:
  %t290 = load i64, ptr %l21, !tbaa !24
  %t291 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t294 = icmp eq i64 %t290, %t291
  store i1 %t294, ptr %l182, !tbaa !21
  br label %bb73
bb73:
  %t296 = load i1, ptr %l182, !tbaa !21
  store i1 %t296, ptr %l178, !tbaa !21
  br label %bb74
bb74:
  %t297 = load i1, ptr %l178, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l170, !tbaa !21
  br label %bb75
bb75:
  %t300 = load i1, ptr %l170, !tbaa !21
  br i1 %t300, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l19, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i32, ptr %t306, i64 %t303
  %t308 = load i32, ptr %t307, !tbaa !33
  %t309 = load i64, ptr %l19, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr i32, ptr %t312, i64 %t309
  %t314 = load i32, ptr %t313, !tbaa !33
  %t318 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t302, i32 %t308, i32 %t314)
  store i1 %t318, ptr %l193
  br label %bb79
bb79:
  %t319 = load i1, ptr %l193, !tbaa !21
  %t320 = xor i1 %t319, true
  br i1 %t320, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t323 = load i64, ptr %l18, !tbaa !24
  %t326 = add i64 %t323, 1
  store i64 %t326, ptr %l18, !tbaa !24
  br label %bb55
bb84:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb85:
  %t329 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t331 = trunc i64 19 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l202, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l1, !tbaa !23
  %t339 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t335, i32 %t336)
  store i32 %t339, ptr %l205
  br label %bb89
bb89:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load i32, ptr %l2, !tbaa !23
  %t344 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t340, i32 %t341)
  store i32 %t344, ptr %l208
  br label %bb90
bb90:
  %t345 = load ptr, ptr %l202, !tbaa !29
  %t346 = load i32, ptr %l205, !tbaa !23
  %t347 = load i32, ptr %l208, !tbaa !23
  %t348 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t345, i32 %t346, i32 %t347)
  store i1 %t348, ptr %l209
  br label %bb91
bb91:
  %t349 = load i1, ptr %l209, !tbaa !21
  store i1 %t349, ptr %rv
  br label %ret
bb92:
  %t350 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t352 = trunc i64 20 to i32
  %t353 = icmp eq i32 %t350, %t352
  br i1 %t353, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l212, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t356, i32 %t357)
  store i32 %t360, ptr %l215
  br label %bb96
bb96:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l2, !tbaa !23
  %t365 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t361, i32 %t362)
  store i32 %t365, ptr %l218
  br label %bb97
bb97:
  %t366 = load ptr, ptr %l212, !tbaa !29
  %t367 = load i32, ptr %l215, !tbaa !23
  %t368 = load i32, ptr %l218, !tbaa !23
  %t369 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t366, i32 %t367, i32 %t368)
  store i1 %t369, ptr %l219
  br label %bb98
bb98:
  %t370 = load i1, ptr %l219, !tbaa !21
  store i1 %t370, ptr %rv
  br label %ret
bb99:
  %t371 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t373 = trunc i64 22 to i32
  %t374 = icmp eq i32 %t371, %t373
  br i1 %t374, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb126
bb102:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l222, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i32, ptr %l1, !tbaa !23
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t377, i32 %t378)
  store i32 %t381, ptr %l225
  br label %bb103
bb103:
  %t382 = load ptr, ptr %l222, !tbaa !29
  %t383 = load i32, ptr %l225, !tbaa !23
  %t384 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t382, i32 %t383)
  store { i64, ptr } %t384, ptr %l226
  br label %bb104
bb104:
  %t385 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t385, ptr %l22, !tbaa !27
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l227, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l2, !tbaa !23
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t387, i32 %t388)
  store i32 %t391, ptr %l230
  br label %bb105
bb105:
  %t392 = load ptr, ptr %l227, !tbaa !29
  %t393 = load i32, ptr %l230, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t392, i32 %t393)
  store { i64, ptr } %t394, ptr %l231
  br label %bb106
bb106:
  %t395 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t395, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t396 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t396, 0
  store i64 %t398, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t400 = load i64, ptr %l25, !tbaa !24
  %t401 = load i64, ptr %l24, !tbaa !24
  %t404 = icmp sgt i64 %t400, %t401
  br i1 %t404, label %bb107, label %bb108
bb107:
  %t406 = load i64, ptr %l26, !tbaa !24
  %t408 = icmp sgt i64 %t406, 0
  br i1 %t408, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l237, !tbaa !24
  br label %bb112
bb109:
  %t410 = load i64, ptr %l25, !tbaa !24
  %t411 = load i64, ptr %l24, !tbaa !24
  %t414 = sub i64 %t410, %t411
  %t415 = load i64, ptr %l26, !tbaa !24
  %t418 = add i64 %t414, %t415
  %t420 = sub i64 %t418, 1
  %t421 = load i64, ptr %l26, !tbaa !24
  %t424 = sdiv i64 %t420, %t421
  store i64 %t424, ptr %l240, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l240, !tbaa !24
  br label %bb111
bb111:
  %t426 = load i64, ptr %l240, !tbaa !24
  store i64 %t426, ptr %l237, !tbaa !24
  br label %bb112
bb112:
  %t427 = load i64, ptr %l237, !tbaa !24
  store i64 %t427, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  %t428 = load i64, ptr %l28, !tbaa !24
  %t429 = load i64, ptr %l27, !tbaa !24
  %t432 = icmp slt i64 %t428, %t429
  %t434 = xor i1 %t432, true
  br i1 %t434, label %bb114, label %bb115
bb114:
  br label %bb125
bb115:
  br label %bb116
bb116:
  %t436 = load i64, ptr %l24, !tbaa !24
  %t437 = load i64, ptr %l28, !tbaa !24
  %t438 = load i64, ptr %l26, !tbaa !24
  %t441 = mul i64 %t437, %t438
  %t444 = add i64 %t436, %t441
  store i64 %t444, ptr %l29, !tbaa !24
  %t446 = load i64, ptr %l29, !tbaa !24
  %t447 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t452 = icmp slt i64 %t446, %t449
  br i1 %t452, label %bb117, label %bb118
bb117:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t455, ptr %l264, !tbaa !27
  %t456 = load i64, ptr %l29, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr i32, ptr %t459, i64 %t456
  %t461 = load i32, ptr %t460, !tbaa !33
  %t462 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t462, ptr %l267, !tbaa !27
  %t463 = load i64, ptr %l29, !tbaa !24
  %t465 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr i32, ptr %t466, i64 %t463
  %t468 = load i32, ptr %t467, !tbaa !33
  %t472 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t454, i32 %t461, i32 %t468)
  store i1 %t472, ptr %l270
  br label %bb119
bb118:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb120
bb119:
  %t473 = load i1, ptr %l270, !tbaa !21
  %t474 = xor i1 %t473, true
  store i1 %t474, ptr %l262, !tbaa !21
  br label %bb120
bb120:
  %t476 = load i1, ptr %l262, !tbaa !21
  br i1 %t476, label %bb121, label %bb122
bb121:
  store i1 false, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t478 = load i64, ptr %l28, !tbaa !24
  %t481 = add i64 %t478, 1
  store i64 %t481, ptr %l28, !tbaa !24
  br label %bb113
bb125:
  store i1 true, ptr %rv
  br label %ret
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  store i1 true, ptr %rv
  br label %ret
bb130:
  call void @__olang_check_failed(ptr @olang_loc_888c44700641ffaa_fbe810d9adf00e56)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithRole(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca i64
  %l59 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca i64
  %l101 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca i32
  %l109 = alloca i32
  %l112 = alloca i32
  %l115 = alloca i32
  %l120 = alloca i32
  %l123 = alloca %"compiler/types:data"
  %l125 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l22
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = load i32, ptr %l22, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l25, !tbaa !24
  %t14 = load i64, ptr %l25, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l25, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_bf031f4f448c1291_890a9ad18176d2c5)
  unreachable
bb5:
  %t20 = load i64, ptr %l25, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_bf031f4f448c1291_890a9ad18176d2c5)
  unreachable
bb7:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  store i64 %t76, ptr %l55, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t79 = load i64, ptr %l10, !tbaa !24
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t77, i32 %t78, i64 %t79)
  store i64 %t83, ptr %l59
  br label %bb17
bb17:
  %t84 = load i64, ptr %l59, !tbaa !24
  %t85 = load i64, ptr %l55, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i64, ptr %t87, i64 %t85
  store i64 %t84, ptr %t88, !tbaa !34
  br label %bb18
bb18:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t89, 1
  store i64 %t92, ptr %l9, !tbaa !24
  br label %bb13
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t94, i32 %t95)
  store { i64, ptr } %t98, ptr %l65
  br label %bb20
bb20:
  %t99 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t99, ptr %l11, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l67, !tbaa !24
  %t103 = load i64, ptr %l67, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb21, label %bb22
bb21:
  %t106 = load i64, ptr %l67, !tbaa !24
  %t107 = icmp sle i64 %t106, 1152921504606846975
  br i1 %t107, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ac68e58e8d4c9184_1653a4c5d9050158)
  unreachable
bb23:
  %t109 = load i64, ptr %l67, !tbaa !24
  %t110 = mul i64 %t109, 8
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l14, !tbaa !24
  %t120 = load i64, ptr %l13, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ac68e58e8d4c9184_1653a4c5d9050158)
  unreachable
bb25:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb30
bb27:
  %t129 = load i64, ptr %l14, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l15, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l15, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l79, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb29
bb29:
  %t145 = load i64, ptr %l79, !tbaa !24
  store i64 %t145, ptr %l76, !tbaa !24
  br label %bb30
bb30:
  %t146 = load i64, ptr %l76, !tbaa !24
  store i64 %t146, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb31
bb31:
  %t147 = load i64, ptr %l17, !tbaa !24
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l17, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l18, !tbaa !24
  %t165 = load i64, ptr %l18, !tbaa !24
  store i64 %t165, ptr %l97, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l1, !tbaa !23
  %t168 = load i64, ptr %l18, !tbaa !24
  %t172 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t166, i32 %t167, i64 %t168)
  store i64 %t172, ptr %l101
  br label %bb35
bb35:
  %t173 = load i64, ptr %l101, !tbaa !24
  %t174 = load i64, ptr %l97, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i64, ptr %t176, i64 %t174
  store i64 %t173, ptr %t177, !tbaa !34
  br label %bb36
bb36:
  %t178 = load i64, ptr %l17, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l17, !tbaa !24
  br label %bb31
bb37:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l105, !tbaa !29
  %t184 = load i32, ptr %l1, !tbaa !23
  store i32 %t184, ptr %l106, !tbaa !23
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l109
  br label %bb38
bb38:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l112
  br label %bb39
bb39:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l115
  br label %bb40
bb40:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t200, i64 %a2, { i64, ptr } %t202, { i64, ptr } %t203)
  store i32 %t208, ptr %l120
  br label %bb41
bb41:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l1, !tbaa !23
  %t213 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t209, i32 %t210)
  store %"compiler/types:data" %t213, ptr %l123
  br label %bb42
bb42:
  %t214 = getelementptr %"compiler/types:data", ptr %l123, i32 0, i32 5
  %t215 = load i64, ptr %t214, !tbaa !24
  %t216 = load ptr, ptr %l105, !tbaa !29
  %t217 = load i32, ptr %l106, !tbaa !23
  %t218 = load i32, ptr %l109, !tbaa !23
  %t219 = load i32, ptr %l112, !tbaa !23
  %t220 = load i32, ptr %l115, !tbaa !23
  %t221 = load i32, ptr %l120, !tbaa !23
  %t223 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %t216, i32 %t217, i32 %t218, i32 %t219, i32 %t220, i32 %t221, i64 %t215)
  store i32 %t223, ptr %l125
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t224 = load i32, ptr %l125, !tbaa !23
  store i32 %t224, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eanchorsInto(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l49 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l84 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i1
  %l119 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l136 = alloca { i64, ptr }
  %l139 = alloca i1
  %l141 = alloca i1
  %l143 = alloca { i64, ptr }
  %l146 = alloca i1
  %l149 = alloca { i64, ptr }
  %l156 = alloca i32
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l5, !tbaa !23
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l5, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l28
  br label %bb4
bb4:
  %t16 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l35
  br label %bb8
bb8:
  %t29 = load i1, ptr %l35, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l32, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb14
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l38, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l5, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l41
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l38, !tbaa !29
  %t40 = load i32, ptr %l41, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l42
  br label %bb13
bb13:
  %t42 = load i32, ptr %l42, !range !{i32 0, i32 6}
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l37, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l37, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i32 65536, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l5, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l49
  br label %bb18
bb18:
  %t56 = load i1, ptr %l49, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  store i32 65536, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l51, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l54
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l51, !tbaa !29
  %t65 = load i32, ptr %l54, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l55
  br label %bb23
bb23:
  %t67 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb29
bb26:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l64, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb28
bb28:
  %t98 = load i64, ptr %l64, !tbaa !24
  store i64 %t98, ptr %l61, !tbaa !24
  br label %bb29
bb29:
  %t99 = load i64, ptr %l61, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb32:
  br label %bb33
bb33:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l12, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l84, !tbaa !24
  %t123 = load i64, ptr %l84, !tbaa !24
  %t124 = icmp sge i64 %t123, 0
  br i1 %t124, label %bb34, label %bb35
bb34:
  %t126 = load i64, ptr %l84, !tbaa !24
  %t127 = icmp sle i64 %t126, 1152921504606846975
  br i1 %t127, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_ab5d312677a1c76d_705ca0c9b87dcf79)
  unreachable
bb36:
  %t129 = load i64, ptr %l84, !tbaa !24
  %t130 = mul i64 %t129, 8
  %t131 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t130)
  %t132 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = icmp sgt i64 %t139, %t140
  br i1 %t143, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ab5d312677a1c76d_705ca0c9b87dcf79)
  unreachable
bb38:
  %t145 = load i64, ptr %l16, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb43
bb40:
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = sub i64 %t149, %t150
  %t154 = load i64, ptr %l16, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = sub i64 %t157, 1
  %t160 = load i64, ptr %l16, !tbaa !24
  %t163 = sdiv i64 %t159, %t160
  store i64 %t163, ptr %l96, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb42
bb42:
  %t165 = load i64, ptr %l96, !tbaa !24
  store i64 %t165, ptr %l93, !tbaa !24
  br label %bb43
bb43:
  %t166 = load i64, ptr %l93, !tbaa !24
  store i64 %t166, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t167 = load i64, ptr %l17, !tbaa !24
  %t168 = sub i64 %t167, 1
  store i64 %t168, ptr %l105, !tbaa !24
  %t169 = load i64, ptr %l17, !tbaa !24
  %t170 = icmp slt i64 %t169, 2147483648
  %t171 = load i64, ptr %l18, !tbaa !24
  %t172 = icmp sge i64 %t171, 0
  %t175 = and i1 %t170, %t172
  store i1 %t175, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t176 = load i64, ptr %l18, !tbaa !24
  %t177 = load i64, ptr %l17, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t184 = load i64, ptr %l14, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = mul i64 %t185, %t186
  %t192 = add i64 %t184, %t189
  store i64 %t192, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l19, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t195, ptr %l119, !tbaa !27
  %t196 = load i64, ptr %l19, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i64, ptr %t199, i64 %t196
  %t201 = load i64, ptr %t200, !tbaa !34
  %t204 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i64, ptr %t205, i64 %t194
  store i64 %t201, ptr %t206, !tbaa !34
  br label %bb48
bb48:
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l18, !tbaa !24
  br label %bb44
bb49:
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = load i64, ptr %l12, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i64, ptr %t219, i64 %t214
  store i64 %t215, ptr %t220, !tbaa !34
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t222, ptr %l129, !tbaa !27
  %t223 = load i64, ptr %l12, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t221, i32 %t228)
  store i1 %t231, ptr %l132
  br label %bb50
bb50:
  %t232 = load i1, ptr %l132, !tbaa !21
  br i1 %t232, label %bb51, label %bb52
bb51:
  %t233 = load ptr, ptr %l3, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v2, ptr %t233, { i64, ptr } %t234)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb54:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t238, ptr %l136, !tbaa !27
  %t239 = load i64, ptr %l12, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i32, ptr %t242, i64 %t239
  %t244 = load i32, ptr %t243, !tbaa !33
  %t247 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t237, i32 %t244)
  store i1 %t247, ptr %l139
  br label %bb55
bb55:
  %t248 = load i1, ptr %l139, !tbaa !21
  %t249 = xor i1 %t248, true
  br i1 %t249, label %bb56, label %bb57
bb56:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t252, ptr %l143, !tbaa !27
  %t253 = load i64, ptr %l12, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i32, ptr %t256, i64 %t253
  %t258 = load i32, ptr %t257, !tbaa !33
  %t261 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t251, i32 %t258)
  store i1 %t261, ptr %l146
  br label %bb58
bb57:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb59
bb58:
  %t262 = load i1, ptr %l146, !tbaa !21
  %t263 = xor i1 %t262, true
  store i1 %t263, ptr %l141, !tbaa !21
  br label %bb59
bb59:
  %t265 = load i1, ptr %l141, !tbaa !21
  br i1 %t265, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t267, ptr %l149, !tbaa !27
  %t268 = load i64, ptr %l12, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  %t274 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t275 = load ptr, ptr %l3, !tbaa !29
  %t276 = load i64, ptr %l4, !tbaa !24
  %t278 = add i64 %t276, 1
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eanchorsInto(ptr %v0, ptr %s4, ptr %v2, ptr %t266, i32 %t273, { i64, ptr } %t274, ptr %t275, i64 %t278)
  store i32 %t284, ptr %l156
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb64, label %ok.286, !prof !99
ok.286:
  br label %bb63
bb63:
  br label %bb65
bb64:
  %t287 = load i32, ptr %l156, !tbaa !23
  %t288 = lshr i32 %t287, 16
  %t289 = and i32 %t287, 65535
  %t290 = icmp eq i32 %t288, 1
  %t291 = select i1 %t290, i32 1, i32 0
  %t292 = icmp eq i32 %t287, 0
  %t293 = shl i32 %t291, 16
  %t294 = or i32 %t293, %t289
  %t295 = select i1 %t292, i32 0, i32 %t294
  call void @__olang_scope_close(ptr %s4)
  store i32 %t295, ptr %rv
  br label %ret
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb66:
  %t297 = load i64, ptr %l11, !tbaa !24
  %t300 = add i64 %t297, 1
  store i64 %t300, ptr %l11, !tbaa !24
  br label %bb30
bb67:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp eq i32 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l13
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = load i32, ptr %l13, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t33, ptr %l14
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l18
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l15, !tbaa !29
  %t41 = load i32, ptr %l18, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s0, ptr %v2, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l19
  br label %bb8
bb8:
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t43, i64 %t44)
  %t59 = getelementptr i8, ptr %t58, i64 %t44
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t45)
  %t61 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t58, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca %"compiler/types:data"
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l101 = alloca i32
  %l104 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l111 = alloca i32
  %l117 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca i32
  %l130 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i32
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca i32
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l175 = alloca i32
  %l182 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca { i64, ptr }
  %l193 = alloca i64
  %l196 = alloca i64
  %l217 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l235 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l240 = alloca i32
  %l257 = alloca i32
  %l261 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l267 = alloca i1
  %l268 = alloca i1
  %l271 = alloca ptr
  %l273 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l284 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l294 = alloca i32
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l302 = alloca i32
  %l307 = alloca ptr
  %l308 = alloca ptr
  %l309 = alloca ptr
  %l312 = alloca i32
  %l313 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l17
  store %"compiler/types:data" %t6, ptr %l3
  %t7 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l4
  %t10 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t15, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb231
bb6:
  %t17 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t19 = trunc i64 15 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb231
bb11:
  %t24 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t26 = trunc i64 16 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t29, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb231
bb16:
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t33 = trunc i64 17 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t36, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb231
bb21:
  %t38 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t40 = trunc i64 28 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l33, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l34, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l37
  br label %bb25
bb25:
  %t50 = load ptr, ptr %l33, !tbaa !29
  %t51 = load ptr, ptr %l34, !tbaa !29
  %t52 = load i32, ptr %l37, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t50, ptr %t51, i32 %t52)
  br label %bb26
bb26:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l38, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l41
  br label %bb27
bb27:
  %t59 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t61 = load i64, ptr %l41, !tbaa !65
  %t62 = call i64 @__olang_fmt_u64(ptr null, i64 %t61)
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  %t66 = call i64 @__olang_fmt_u64(ptr %t65, i64 %t61)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  %t70 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t70, { i64, ptr } %t68)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb231
bb29:
  %t72 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t74 = trunc i64 1 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb30, label %bb31
bb30:
  br label %bb58
bb31:
  %t77 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t79 = trunc i64 2 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb32, label %bb33
bb32:
  br label %bb58
bb33:
  %t82 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t84 = trunc i64 3 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb34, label %bb35
bb34:
  br label %bb58
bb35:
  %t87 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t89 = trunc i64 4 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb36, label %bb37
bb36:
  br label %bb58
bb37:
  %t92 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t94 = trunc i64 5 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  %t97 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t99 = trunc i64 6 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb40, label %bb41
bb40:
  br label %bb58
bb41:
  %t102 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t104 = trunc i64 7 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb42, label %bb43
bb42:
  br label %bb58
bb43:
  %t107 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t109 = trunc i64 8 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb44, label %bb45
bb44:
  br label %bb58
bb45:
  %t112 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t114 = trunc i64 9 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb46, label %bb47
bb46:
  br label %bb58
bb47:
  %t117 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t119 = trunc i64 10 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb48, label %bb49
bb48:
  br label %bb58
bb49:
  %t122 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t124 = trunc i64 11 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  %t127 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t129 = trunc i64 12 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  %t132 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t134 = trunc i64 13 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  %t137 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t139 = trunc i64 14 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l72, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  br i1 %t147, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb61
bb60:
  %t149 = load i32, ptr %l2, !tbaa !23
  %t151 = sext i32 %t149 to i64
  %t153 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimNames, i64 0, i64 %t151
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !37
  store { i64, ptr } %t154, ptr %l76, !tbaa !27
  br label %bb61
bb61:
  %t156 = load ptr, ptr @__olang_prog_scope
  %t157 = load ptr, ptr %l72, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l76, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t156, ptr %t157, { i64, ptr } %t158)
  br label %bb62
bb62:
  br label %bb231
bb63:
  %t159 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t161 = trunc i64 31 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb71
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l82, !tbaa !29
  %t165 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t166 = load i64, ptr %t165, !tbaa !24
  %t168 = icmp eq i64 %t166, 1
  br i1 %t168, label %bb67, label %bb68
bb67:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l85, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l85, !tbaa !27
  br label %bb69
bb69:
  %t170 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t171 = load i64, ptr %t170, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t171)
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t173, i64 %t174)
  %t179 = getelementptr i8, ptr %t178, i64 %t174
  %t180 = call i64 @__olang_fmt_i64(ptr %t179, i64 %t171)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t178, 1
  %t184 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s8, ptr %t184, { i64, ptr } %t182)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  br label %bb231
bb71:
  %t186 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t188 = trunc i64 18 to i32
  %t189 = icmp eq i32 %t186, %t188
  br i1 %t189, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t193 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonNamed(ptr %v0, ptr %v1, ptr %v2, ptr %t191, ptr %t192, i32 %t193)
  br label %bb75
bb75:
  br label %bb231
bb76:
  %t197 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t199 = trunc i64 19 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb91
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t202 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s11, ptr %t202, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb80
bb80:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l97, !tbaa !29
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l98, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l2, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l101
  br label %bb81
bb81:
  %t211 = load ptr, ptr %l97, !tbaa !29
  %t212 = load ptr, ptr %l98, !tbaa !29
  %t213 = load i32, ptr %l101, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t211, ptr %t212, i32 %t213)
  br label %bb82
bb82:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l2, !tbaa !23
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t214, i32 %t215)
  store i32 %t218, ptr %l104
  br label %bb83
bb83:
  %t219 = load i32, ptr %l104, !tbaa !23
  %t220 = icmp ne i32 %t219, 0
  br i1 %t220, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s12
  %t222 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s12, ptr %t222, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l107, !tbaa !29
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l108, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l2, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l111
  br label %bb87
bb87:
  %t231 = load ptr, ptr %l107, !tbaa !29
  %t232 = load ptr, ptr %l108, !tbaa !29
  %t233 = load i32, ptr %l111, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t231, ptr %t232, i32 %t233)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t234 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t234, i8 62)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s11)
  br label %bb231
bb91:
  %t236 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t238 = trunc i64 20 to i32
  %t239 = icmp eq i32 %t236, %t238
  br i1 %t239, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb119
bb94:
  store %olang.scope zeroinitializer, ptr %s13
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l2, !tbaa !23
  %t245 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t241, i32 %t242)
  store i64 %t245, ptr %l117
  br label %bb95
bb95:
  %t246 = load i64, ptr %l117, !tbaa !24
  store i64 %t246, ptr %l5, !tbaa !24
  %t247 = load i64, ptr %l5, !tbaa !24
  %t248 = load i64, ptr @G_2ecompiler_2ftypes_2eSpread, !tbaa !24
  %t251 = and i64 %t247, %t248
  %t253 = icmp ne i64 %t251, 0
  br i1 %t253, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s14
  %t255 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t255, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb98
bb97:
  br label %bb102
bb98:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l123, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  store ptr %t258, ptr %l124, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l125, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i32, ptr %l2, !tbaa !23
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l128
  br label %bb99
bb99:
  %t265 = load ptr, ptr %l125, !tbaa !29
  %t266 = load i32, ptr %l128, !tbaa !23
  %t267 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t267, ptr %l129
  br label %bb100
bb100:
  %t268 = load ptr, ptr %l123, !tbaa !29
  %t269 = load ptr, ptr %l124, !tbaa !29
  %t270 = load i32, ptr %l129, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t268, ptr %t269, i32 %t270)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  br label %ret
bb102:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l130, !tbaa !29
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr %l2, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l133
  br label %bb103
bb103:
  %t277 = load ptr, ptr %l130, !tbaa !29
  %t278 = load i32, ptr %l133, !tbaa !23
  %t279 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t277, i32 %t278)
  store i32 %t279, ptr %l134
  br label %bb104
bb104:
  %t280 = load i32, ptr %l134, !range !{i32 0, i32 33}
  %t282 = trunc i64 21 to i32
  %t283 = icmp eq i32 %t280, %t282
  br i1 %t283, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s15
  %t285 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t285, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb107
bb106:
  br label %bb108
bb107:
  call void @__olang_scope_close(ptr %s15)
  br label %bb108
bb108:
  %t287 = load i64, ptr %l5, !tbaa !24
  %t288 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t291 = and i64 %t287, %t288
  %t293 = icmp ne i64 %t291, 0
  br i1 %t293, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s16
  %t295 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t295, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s16)
  br label %bb112
bb112:
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l143, !tbaa !29
  %t298 = load ptr, ptr %l1, !tbaa !29
  store ptr %t298, ptr %l144, !tbaa !29
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load i32, ptr %l2, !tbaa !23
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t299, i32 %t300)
  store i32 %t303, ptr %l147
  br label %bb113
bb113:
  %t304 = load ptr, ptr %l143, !tbaa !29
  %t305 = load ptr, ptr %l144, !tbaa !29
  %t306 = load i32, ptr %l147, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t304, ptr %t305, i32 %t306)
  br label %bb114
bb114:
  %t307 = load ptr, ptr %l1, !tbaa !29
  store ptr %t307, ptr %l148, !tbaa !29
  %t308 = load i64, ptr %l5, !tbaa !24
  %t309 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t312 = and i64 %t308, %t309
  %t314 = icmp ne i64 %t312, 0
  br i1 %t314, label %bb115, label %bb116
bb115:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l153, !tbaa !27
  br label %bb117
bb116:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l153, !tbaa !27
  br label %bb117
bb117:
  %t316 = load ptr, ptr %l148, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l153, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t316, { i64, ptr } %t317)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s13)
  br label %bb231
bb119:
  %t318 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t320 = trunc i64 21 to i32
  %t321 = icmp eq i32 %t318, %t320
  br i1 %t321, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t325 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonFunc(ptr %v0, ptr %v1, ptr %v2, ptr %t323, ptr %t324, i32 %t325)
  br label %bb123
bb123:
  br label %bb231
bb124:
  %t329 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t331 = trunc i64 22 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb132
bb127:
  %t334 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t334, i8 40)
  br label %bb128
bb128:
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l162, !tbaa !29
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l163, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l2, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l166
  br label %bb129
bb129:
  %t343 = load ptr, ptr %l162, !tbaa !29
  %t344 = load ptr, ptr %l163, !tbaa !29
  %t345 = load i32, ptr %l166, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %v2, ptr %t343, ptr %t344, i32 %t345)
  br label %bb130
bb130:
  %t346 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t346, i8 41)
  br label %bb131
bb131:
  br label %bb231
bb132:
  %t348 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t350 = trunc i64 23 to i32
  %t351 = icmp eq i32 %t348, %t350
  br i1 %t351, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb140
bb135:
  store %olang.scope zeroinitializer, ptr %s19
  %t353 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t353, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb136
bb136:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l171, !tbaa !29
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l172, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l2, !tbaa !23
  %t361 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t357, i32 %t358)
  store i32 %t361, ptr %l175
  br label %bb137
bb137:
  %t362 = load ptr, ptr %l171, !tbaa !29
  %t363 = load ptr, ptr %l172, !tbaa !29
  %t364 = load i32, ptr %l175, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %v2, ptr %t362, ptr %t363, i32 %t364)
  br label %bb138
bb138:
  %t365 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t365, i8 41)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s19)
  br label %bb231
bb140:
  %t367 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t369 = trunc i64 24 to i32
  %t370 = icmp eq i32 %t367, %t369
  br i1 %t370, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb174
bb143:
  store %olang.scope zeroinitializer, ptr %s20
  %t372 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s20, ptr %t372, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb144
bb144:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load i32, ptr %l2, !tbaa !23
  %t378 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v0, ptr %t374, i32 %t375)
  store { i64, ptr } %t378, ptr %l182
  br label %bb145
bb145:
  %t379 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t379, ptr %l6, !tbaa !27
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l183, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i32, ptr %l2, !tbaa !23
  %t385 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t381, i32 %t382)
  store i32 %t385, ptr %l186
  br label %bb146
bb146:
  %t386 = load ptr, ptr %l183, !tbaa !29
  %t387 = load i32, ptr %l186, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t386, i32 %t387)
  store { i64, ptr } %t388, ptr %l187
  br label %bb147
bb147:
  %t389 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t389, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t390 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 0
  store i64 %t392, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t394 = load i64, ptr %l9, !tbaa !24
  %t395 = load i64, ptr %l8, !tbaa !24
  %t398 = icmp sgt i64 %t394, %t395
  br i1 %t398, label %bb148, label %bb149
bb148:
  %t400 = load i64, ptr %l10, !tbaa !24
  %t402 = icmp sgt i64 %t400, 0
  br i1 %t402, label %bb150, label %bb151
bb149:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb153
bb150:
  %t404 = load i64, ptr %l9, !tbaa !24
  %t405 = load i64, ptr %l8, !tbaa !24
  %t408 = sub i64 %t404, %t405
  %t409 = load i64, ptr %l10, !tbaa !24
  %t412 = add i64 %t408, %t409
  %t414 = sub i64 %t412, 1
  %t415 = load i64, ptr %l10, !tbaa !24
  %t418 = sdiv i64 %t414, %t415
  store i64 %t418, ptr %l196, !tbaa !24
  br label %bb152
bb151:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb152
bb152:
  %t420 = load i64, ptr %l196, !tbaa !24
  store i64 %t420, ptr %l193, !tbaa !24
  br label %bb153
bb153:
  %t421 = load i64, ptr %l193, !tbaa !24
  store i64 %t421, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb154
bb154:
  %t422 = load i64, ptr %l12, !tbaa !24
  %t423 = load i64, ptr %l11, !tbaa !24
  %t426 = icmp slt i64 %t422, %t423
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb155, label %bb156
bb155:
  br label %bb172
bb156:
  br label %bb157
bb157:
  %t430 = load i64, ptr %l8, !tbaa !24
  %t431 = load i64, ptr %l12, !tbaa !24
  %t432 = load i64, ptr %l10, !tbaa !24
  %t435 = mul i64 %t431, %t432
  %t438 = add i64 %t430, %t435
  store i64 %t438, ptr %l13, !tbaa !24
  %t440 = load i64, ptr %l13, !tbaa !24
  %t442 = icmp sgt i64 %t440, 0
  br i1 %t442, label %bb158, label %bb159
bb158:
  %t444 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t444, i8 32)
  br label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb161
bb161:
  %t446 = load ptr, ptr %l1, !tbaa !29
  store ptr %t446, ptr %l217, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/types:Table", ptr %t447, i32 0, i32 0
  %t450 = load ptr, ptr %t449, !tbaa !29
  store ptr %t450, ptr %l219, !tbaa !29
  %t451 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t451, ptr %l220, !tbaa !27
  %t452 = load i64, ptr %l13, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr i32, ptr %t455, i64 %t452
  %t457 = load i32, ptr %t456, !tbaa !33
  %t458 = load ptr, ptr %l219, !tbaa !29
  %t459 = call ptr @__olang_scope_or(ptr %v2, ptr %t458)
  %t460 = call ptr @__olang_scope_hold(ptr %t459)
  %t461 = ptrtoint ptr %t460 to i64
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/types:Table", ptr %t462, i32 0, i32 0
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t467 = call ptr @__olang_scope_or(ptr %v2, ptr %t465)
  %t468 = call ptr @__olang_scope_hold(ptr %t467)
  %t469 = ptrtoint ptr %t468 to i64
  %t471 = inttoptr i64 %t461 to ptr
  %t473 = inttoptr i64 %t469 to ptr
  %t474 = load ptr, ptr %l219, !tbaa !29
  %t476 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t471, ptr %t473, ptr %t474, i32 %t457)
  store { i64, ptr } %t476, ptr %l227
  br label %bb162
bb162:
  %t477 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 1
  %t479 = call ptr @__olang_scope_or(ptr %v2, ptr %t478)
  %t480 = call ptr @__olang_scope_hold(ptr %t479)
  %t481 = ptrtoint ptr %t480 to i64
  %t483 = inttoptr i64 %t481 to ptr
  %t484 = load ptr, ptr %l217, !tbaa !29
  %t485 = load { i64, ptr }, ptr %l227, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t483, ptr %t484, { i64, ptr } %t485)
  br label %bb163
bb163:
  %t486 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t486, ptr %l229, !tbaa !27
  %t487 = load i64, ptr %l13, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr i32, ptr %t490, i64 %t487
  %t492 = load i32, ptr %t491, !tbaa !33
  %t494 = icmp ne i32 %t492, 0
  br i1 %t494, label %bb164, label %bb165
bb164:
  %t496 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t496, i8 40)
  br label %bb166
bb165:
  br label %bb170
bb166:
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l234, !tbaa !29
  %t499 = load ptr, ptr %l1, !tbaa !29
  store ptr %t499, ptr %l235, !tbaa !29
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t501, ptr %l237, !tbaa !27
  %t502 = load i64, ptr %l13, !tbaa !24
  %t504 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr i32, ptr %t505, i64 %t502
  %t507 = load i32, ptr %t506, !tbaa !33
  %t510 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t500, i32 %t507)
  store i32 %t510, ptr %l240
  br label %bb167
bb167:
  %t511 = load ptr, ptr %l234, !tbaa !29
  %t512 = load ptr, ptr %l235, !tbaa !29
  %t513 = load i32, ptr %l240, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %v2, ptr %t511, ptr %t512, i32 %t513)
  br label %bb168
bb168:
  %t514 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t514, i8 41)
  br label %bb169
bb169:
  br label %bb170
bb170:
  br label %bb171
bb171:
  %t516 = load i64, ptr %l12, !tbaa !24
  %t519 = add i64 %t516, 1
  store i64 %t519, ptr %l12, !tbaa !24
  br label %bb154
bb172:
  %t521 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t521, i8 125)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s20)
  br label %bb231
bb174:
  %t523 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t525 = trunc i64 25 to i32
  %t526 = icmp eq i32 %t523, %t525
  br i1 %t526, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb179
bb177:
  store %olang.scope zeroinitializer, ptr %s26
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 1
  %t530 = load i64, ptr %t529, !tbaa !24
  %t531 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t532 = load i64, ptr %t531, !tbaa !24
  %t533 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t534 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t536 = call i64 @__olang_fmt_i64(ptr null, i64 %t530)
  %t537 = add i64 %t534, %t536
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t540 = add i64 %t537, %t539
  %t542 = call i64 @__olang_fmt_i64(ptr null, i64 %t532)
  %t543 = add i64 %t540, %t542
  %t544 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t546 = add i64 %t543, %t545
  %t547 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t546)
  call void @olang_textcopy(ptr %t547, ptr %t533, i64 %t534)
  %t548 = getelementptr i8, ptr %t547, i64 %t534
  %t549 = call i64 @__olang_fmt_i64(ptr %t548, i64 %t530)
  %t550 = getelementptr i8, ptr %t548, i64 %t536
  call void @olang_textcopy(ptr %t550, ptr %t538, i64 %t539)
  %t551 = getelementptr i8, ptr %t550, i64 %t539
  %t552 = call i64 @__olang_fmt_i64(ptr %t551, i64 %t532)
  %t553 = getelementptr i8, ptr %t551, i64 %t542
  call void @olang_textcopy(ptr %t553, ptr %t544, i64 %t545)
  %t554 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t555 = insertvalue { i64, ptr } %t554, ptr %t547, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s26, ptr %t528, { i64, ptr } %t555)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s26)
  br label %bb231
bb179:
  %t559 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t561 = trunc i64 26 to i32
  %t562 = icmp eq i32 %t559, %t561
  br i1 %t562, label %bb180, label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb201
bb182:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load i32, ptr %l2, !tbaa !23
  %t568 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t564, i32 %t565)
  store i32 %t568, ptr %l257
  br label %bb183
bb183:
  %t569 = load i32, ptr %l257, !tbaa !23
  store i32 %t569, ptr %l14, !tbaa !23
  %t570 = load i32, ptr %l14, !tbaa !23
  %t571 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t574 = icmp eq i32 %t570, %t571
  br i1 %t574, label %bb184, label %bb185
bb184:
  store %olang.scope zeroinitializer, ptr %s29
  %t576 = load ptr, ptr %l1, !tbaa !29
  store ptr %t576, ptr %l261, !tbaa !29
  %t577 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t578 = load i64, ptr %t577, !tbaa !24
  %t580 = icmp ne i64 %t578, 0
  br i1 %t580, label %bb186, label %bb187
bb185:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load i32, ptr %l14, !tbaa !23
  %t586 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t582, i32 %t583)
  store i1 %t586, ptr %l267
  br label %bb190
bb186:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l264, !tbaa !27
  br label %bb188
bb187:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l264, !tbaa !27
  br label %bb188
bb188:
  %t587 = load ptr, ptr %l261, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l264, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s29, ptr %t587, { i64, ptr } %t588)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s29)
  br label %bb200
bb190:
  %t589 = load i1, ptr %l267, !tbaa !21
  br i1 %t589, label %bb191, label %bb192
bb191:
  %t590 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t591 = load i64, ptr %t590, !tbaa !24
  %t593 = icmp slt i64 %t591, 0
  store i1 %t593, ptr %l268, !tbaa !21
  br label %bb193
bb192:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb193
bb193:
  %t595 = load i1, ptr %l268, !tbaa !21
  br i1 %t595, label %bb194, label %bb195
bb194:
  store %olang.scope zeroinitializer, ptr %s31
  %t596 = load ptr, ptr %l1, !tbaa !29
  store ptr %t596, ptr %l271, !tbaa !29
  %t597 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t598 = load i64, ptr %t597, !tbaa !24
  %t600 = call { i64, ptr } @compiler_2ftypes_2eUnsignedText(ptr %s31, i64 %t598)
  store { i64, ptr } %t600, ptr %l273
  br label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s32
  %t601 = load ptr, ptr %l1, !tbaa !29
  %t602 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 2
  %t603 = load i64, ptr %t602, !tbaa !24
  %t605 = call i64 @__olang_fmt_i64(ptr null, i64 %t603)
  %t606 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t605)
  %t607 = call i64 @__olang_fmt_i64(ptr %t606, i64 %t603)
  %t608 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t606, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t601, { i64, ptr } %t609)
  br label %bb198
bb196:
  %t613 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t614 = load ptr, ptr %l271, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s31, ptr %t614, { i64, ptr } %t613)
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s31)
  br label %bb199
bb198:
  call void @__olang_scope_close(ptr %s32)
  br label %bb199
bb199:
  br label %bb200
bb200:
  br label %bb231
bb201:
  %t616 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t618 = trunc i64 27 to i32
  %t619 = icmp eq i32 %t616, %t618
  br i1 %t619, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb207
bb204:
  store %olang.scope zeroinitializer, ptr %s34
  %t621 = load ptr, ptr %l1, !tbaa !29
  store ptr %t621, ptr %l281, !tbaa !29
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load i32, ptr %l2, !tbaa !23
  %t626 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePattern(ptr %v0, ptr %s34, ptr %t622, i32 %t623)
  store { i64, ptr } %t626, ptr %l284
  br label %bb205
bb205:
  %t627 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t628 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t629 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t630 = extractvalue { i64, ptr } %t629, 1
  %t631 = extractvalue { i64, ptr } %t629, 0
  %t632 = add i64 %t628, %t631
  %t633 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t634 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t635 = add i64 %t632, %t634
  %t636 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t635)
  call void @olang_textcopy(ptr %t636, ptr %t627, i64 %t628)
  %t637 = getelementptr i8, ptr %t636, i64 %t628
  call void @olang_textcopy(ptr %t637, ptr %t630, i64 %t631)
  %t638 = getelementptr i8, ptr %t637, i64 %t631
  call void @olang_textcopy(ptr %t638, ptr %t633, i64 %t634)
  %t639 = insertvalue { i64, ptr } undef, i64 %t635, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t636, 1
  %t642 = load ptr, ptr %l281, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s34, ptr %t642, { i64, ptr } %t640)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s34)
  br label %bb231
bb207:
  %t644 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t646 = trunc i64 29 to i32
  %t647 = icmp eq i32 %t644, %t646
  br i1 %t647, label %bb208, label %bb209
bb208:
  br label %bb210
bb209:
  br label %bb214
bb210:
  store %olang.scope zeroinitializer, ptr %s36
  %t649 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s36, ptr %t649, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb211
bb211:
  %t651 = load ptr, ptr %l0, !tbaa !29
  store ptr %t651, ptr %l290, !tbaa !29
  %t652 = load ptr, ptr %l1, !tbaa !29
  store ptr %t652, ptr %l291, !tbaa !29
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load i32, ptr %l2, !tbaa !23
  %t657 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t653, i32 %t654)
  store i32 %t657, ptr %l294
  br label %bb212
bb212:
  %t658 = load ptr, ptr %l290, !tbaa !29
  %t659 = load ptr, ptr %l291, !tbaa !29
  %t660 = load i32, ptr %l294, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t658, ptr %t659, i32 %t660)
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s36)
  br label %bb231
bb214:
  %t661 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t663 = trunc i64 32 to i32
  %t664 = icmp eq i32 %t661, %t663
  br i1 %t664, label %bb215, label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb222
bb217:
  store %olang.scope zeroinitializer, ptr %s37
  %t666 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s37, ptr %t666, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb218
bb218:
  %t668 = load ptr, ptr %l0, !tbaa !29
  store ptr %t668, ptr %l298, !tbaa !29
  %t669 = load ptr, ptr %l1, !tbaa !29
  store ptr %t669, ptr %l299, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load i32, ptr %l2, !tbaa !23
  %t674 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t670, i32 %t671)
  store i32 %t674, ptr %l302
  br label %bb219
bb219:
  %t675 = load ptr, ptr %l298, !tbaa !29
  %t676 = load ptr, ptr %l299, !tbaa !29
  %t677 = load i32, ptr %l302, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %v2, ptr %t675, ptr %t676, i32 %t677)
  br label %bb220
bb220:
  %t678 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t678, i8 125)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s37)
  br label %bb231
bb222:
  %t680 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t682 = trunc i64 30 to i32
  %t683 = icmp eq i32 %t680, %t682
  br i1 %t683, label %bb223, label %bb224
bb223:
  br label %bb225
bb224:
  br label %bb230
bb225:
  %t685 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t685, i8 63)
  br label %bb226
bb226:
  %t687 = load ptr, ptr %l0, !tbaa !29
  store ptr %t687, ptr %l307, !tbaa !29
  %t688 = load ptr, ptr %l1, !tbaa !29
  store ptr %t688, ptr %l308, !tbaa !29
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l309, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load i32, ptr %l2, !tbaa !23
  %t694 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t690, i32 %t691)
  store i32 %t694, ptr %l312
  br label %bb227
bb227:
  %t695 = load ptr, ptr %l309, !tbaa !29
  %t696 = load i32, ptr %l312, !tbaa !23
  %t697 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t695, i32 %t696)
  store { i64, ptr } %t697, ptr %l313
  br label %bb228
bb228:
  %t698 = load ptr, ptr %l307, !tbaa !29
  %t699 = load ptr, ptr %l308, !tbaa !29
  %t700 = load { i64, ptr }, ptr %l313, !tbaa !27
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonErrs(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t698, ptr %t699, { i64, ptr } %t700)
  br label %bb229
bb229:
  br label %bb231
bb230:
  call void @__olang_check_failed(ptr @olang_loc_bd4ce41e1f7e504b_596b58263987420f)
  unreachable
bb231:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonFunc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:data"
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l24 = alloca %"compiler/types:data"
  %l25 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca i32
  %l51 = alloca i32
  %l57 = alloca i32
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca { i64, ptr }
  %l98 = alloca i1
  %l105 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l115 = alloca i64
  %l118 = alloca i64
  %l139 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l157 = alloca i1
  %l158 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l187 = alloca i64
  %l190 = alloca i64
  %l212 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l24
  store %"compiler/types:data" %t6, ptr %l3
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l25, !tbaa !29
  %t8 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 6
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t13 = and i64 %t9, %t10
  %t15 = icmp ne i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l30, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l30, !tbaa !27
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l25, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t17, { i64, ptr } %t18)
  br label %bb5
bb5:
  %t19 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 6
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = ashr i64 %t20, 8
  %t24 = icmp ne i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t26, i8 91)
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 6
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = ashr i64 %t31, 8
  %t35 = trunc i64 %t33 to i32
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t28, ptr %t29, i32 %t35)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t40, i8 93)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t42, i8 40)
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l43, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l44, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l47
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l43, !tbaa !29
  %t52 = load ptr, ptr %l44, !tbaa !29
  %t53 = load i32, ptr %l47, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %v2, ptr %t51, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t54, i8 41)
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l51
  br label %bb16
bb16:
  %t61 = load i32, ptr %l51, !tbaa !23
  store i32 %t61, ptr %l4, !tbaa !23
  %t62 = load i32, ptr %l4, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t66 = icmp ne i32 %t62, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l57
  br label %bb19
bb18:
  br label %bb29
bb19:
  %t73 = load i32, ptr %l57, !range !{i32 0, i32 33}
  %t75 = trunc i64 21 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l5, !tbaa !21
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l60, !tbaa !29
  %t79 = load i1, ptr %l5, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l60, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t81, { i64, ptr } %t82)
  br label %bb23
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t83, ptr %t84, i32 %t85)
  br label %bb24
bb24:
  %t89 = load i1, ptr %l5, !tbaa !21
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t91, i8 41)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l68, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t98, ptr %l71
  br label %bb30
bb30:
  %t99 = load ptr, ptr %l68, !tbaa !29
  %t100 = load i32, ptr %l71, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t99, i32 %t100)
  store { i64, ptr } %t101, ptr %l72
  br label %bb31
bb31:
  %t102 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t102, ptr %l6, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t109, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t111 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp eq i64 %t113, 1
  br i1 %t115, label %bb35, label %bb36
bb35:
  %t117 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t117, ptr %l81, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i32, ptr %t119, i64 0
  %t121 = load i32, ptr %t120, !tbaa !33
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t125 = icmp eq i32 %t121, %t122
  store i1 %t125, ptr %l80, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  %t127 = load i1, ptr %l80, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb38, label %bb39
bb38:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonErrs(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t130, ptr %t131, { i64, ptr } %t132)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb42:
  %t136 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 7
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = icmp ne i64 %t137, 0
  br i1 %t139, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s6, ptr %t141, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t145 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonPromises(ptr %v0, ptr %v1, ptr %v2, ptr %t143, ptr %t144, i32 %t145)
  br label %bb46
bb46:
  %t149 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t149, i8 93)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/types:Table", ptr %t151, i32 0, i32 3
  %t154 = load i1, ptr %t153, !tbaa !21
  br i1 %t154, label %bb49, label %bb50
bb49:
  %t156 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t157 = load i64, ptr %t156, !tbaa !24
  %t159 = icmp ne i64 %t157, 0
  store i1 %t159, ptr %l98, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb51
bb51:
  %t161 = load i1, ptr %l98, !tbaa !21
  br i1 %t161, label %bb52, label %bb53
bb52:
  %t162 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t162, i8 123)
  br label %bb54
bb53:
  br label %bb84
bb54:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/types:Table", ptr %t164, i32 0, i32 30
  %t167 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t168 = load i64, ptr %t167, !tbaa !24
  %t171 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t166, i64 %t168)
  store { i64, ptr } %t171, ptr %l105
  br label %bb55
bb55:
  %t172 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t172, ptr %l7, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/types:Table", ptr %t173, i32 0, i32 32
  %t176 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 5
  %t177 = load i64, ptr %t176, !tbaa !24
  %t180 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t175, i64 %t177)
  store { i64, ptr } %t180, ptr %l109
  br label %bb56
bb56:
  %t181 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t181, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t186 = load i64, ptr %l10, !tbaa !24
  %t187 = load i64, ptr %l9, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb57, label %bb58
bb57:
  %t192 = load i64, ptr %l11, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb62
bb59:
  %t196 = load i64, ptr %l10, !tbaa !24
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l11, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l11, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l118, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb61
bb61:
  %t212 = load i64, ptr %l118, !tbaa !24
  store i64 %t212, ptr %l115, !tbaa !24
  br label %bb62
bb62:
  %t213 = load i64, ptr %l115, !tbaa !24
  store i64 %t213, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb63
bb63:
  %t214 = load i64, ptr %l13, !tbaa !24
  %t215 = load i64, ptr %l12, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb64, label %bb65
bb64:
  br label %bb82
bb65:
  br label %bb66
bb66:
  %t222 = load i64, ptr %l9, !tbaa !24
  %t223 = load i64, ptr %l13, !tbaa !24
  %t224 = load i64, ptr %l11, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  store i64 %t230, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l14, !tbaa !24
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t236, i8 44)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l139, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/types:Table", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  store ptr %t242, ptr %l141, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t243, ptr %l142, !tbaa !27
  %t244 = load i64, ptr %l14, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i64, ptr %t247, i64 %t244
  %t249 = load i64, ptr %t248, !tbaa !34
  %t251 = trunc i64 %t249 to i32
  %t253 = load ptr, ptr %l141, !tbaa !29
  %t254 = call ptr @__olang_scope_or(ptr %v2, ptr %t253)
  %t255 = call ptr @__olang_scope_hold(ptr %t254)
  %t256 = ptrtoint ptr %t255 to i64
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/types:Table", ptr %t257, i32 0, i32 0
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = call ptr @__olang_scope_or(ptr %v2, ptr %t260)
  %t263 = call ptr @__olang_scope_hold(ptr %t262)
  %t264 = ptrtoint ptr %t263 to i64
  %t266 = inttoptr i64 %t256 to ptr
  %t268 = inttoptr i64 %t264 to ptr
  %t269 = load ptr, ptr %l141, !tbaa !29
  %t271 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t266, ptr %t268, ptr %t269, i32 %t251)
  store { i64, ptr } %t271, ptr %l151
  br label %bb71
bb71:
  %t272 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = call ptr @__olang_scope_or(ptr %v2, ptr %t273)
  %t275 = call ptr @__olang_scope_hold(ptr %t274)
  %t276 = ptrtoint ptr %t275 to i64
  %t278 = inttoptr i64 %t276 to ptr
  %t279 = load ptr, ptr %l139, !tbaa !29
  %t280 = load { i64, ptr }, ptr %l151, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t278, ptr %t279, { i64, ptr } %t280)
  br label %bb72
bb72:
  %t281 = load i64, ptr %l14, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t287 = icmp slt i64 %t281, %t284
  br i1 %t287, label %bb73, label %bb74
bb73:
  %t289 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t289, ptr %l158, !tbaa !27
  %t290 = load i64, ptr %l14, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr i64, ptr %t293, i64 %t290
  %t295 = load i64, ptr %t294, !tbaa !34
  %t297 = icmp ne i64 %t295, 0
  store i1 %t297, ptr %l157, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb75
bb75:
  %t299 = load i1, ptr %l157, !tbaa !21
  br i1 %t299, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s11
  %t300 = load ptr, ptr %l1, !tbaa !29
  store ptr %t300, ptr %l162, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/types:Table", ptr %t301, i32 0, i32 33
  %t304 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t304, ptr %l165, !tbaa !27
  %t305 = load i64, ptr %l14, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i64, ptr %t308, i64 %t305
  %t310 = load i64, ptr %t309, !tbaa !34
  %t313 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s11, ptr %t303, i64 %t310)
  store { i64, ptr } %t313, ptr %l168
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t316 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = add i64 %t315, %t318
  %t320 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t319)
  call void @olang_textcopy(ptr %t320, ptr %t314, i64 %t315)
  %t321 = getelementptr i8, ptr %t320, i64 %t315
  call void @olang_textcopy(ptr %t321, ptr %t317, i64 %t318)
  %t322 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t320, 1
  %t325 = load ptr, ptr %l162, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s11, ptr %t325, { i64, ptr } %t323)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t327 = load i64, ptr %l13, !tbaa !24
  %t330 = add i64 %t327, 1
  store i64 %t330, ptr %l13, !tbaa !24
  br label %bb63
bb82:
  %t332 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t332, i8 125)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t334 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t335 = load i64, ptr %t334, !tbaa !24
  %t337 = icmp ne i64 %t335, 0
  br i1 %t337, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s14
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/types:Table", ptr %t339, i32 0, i32 28
  %t342 = getelementptr %"compiler/types:data", ptr %l3, i32 0, i32 4
  %t343 = load i64, ptr %t342, !tbaa !24
  %t346 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t341, i64 %t343)
  store { i64, ptr } %t346, ptr %l180
  br label %bb87
bb86:
  br label %bb107
bb87:
  %t347 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t347, ptr %l15, !tbaa !27
  %t348 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s14, ptr %t348, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb88
bb88:
  store i64 0, ptr %l16, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t350, 0
  store i64 %t352, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t354 = load i64, ptr %l17, !tbaa !24
  %t355 = load i64, ptr %l16, !tbaa !24
  %t358 = icmp sgt i64 %t354, %t355
  br i1 %t358, label %bb89, label %bb90
bb89:
  %t360 = load i64, ptr %l18, !tbaa !24
  %t362 = icmp sgt i64 %t360, 0
  br i1 %t362, label %bb91, label %bb92
bb90:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb94
bb91:
  %t364 = load i64, ptr %l17, !tbaa !24
  %t365 = load i64, ptr %l16, !tbaa !24
  %t368 = sub i64 %t364, %t365
  %t369 = load i64, ptr %l18, !tbaa !24
  %t372 = add i64 %t368, %t369
  %t374 = sub i64 %t372, 1
  %t375 = load i64, ptr %l18, !tbaa !24
  %t378 = sdiv i64 %t374, %t375
  store i64 %t378, ptr %l190, !tbaa !24
  br label %bb93
bb92:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb93
bb93:
  %t380 = load i64, ptr %l190, !tbaa !24
  store i64 %t380, ptr %l187, !tbaa !24
  br label %bb94
bb94:
  %t381 = load i64, ptr %l187, !tbaa !24
  store i64 %t381, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s16
  %t382 = load i64, ptr %l20, !tbaa !24
  %t383 = load i64, ptr %l19, !tbaa !24
  %t386 = icmp slt i64 %t382, %t383
  %t388 = xor i1 %t386, true
  br i1 %t388, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s16)
  br label %bb105
bb97:
  br label %bb98
bb98:
  %t390 = load i64, ptr %l16, !tbaa !24
  %t391 = load i64, ptr %l20, !tbaa !24
  %t392 = load i64, ptr %l18, !tbaa !24
  %t395 = mul i64 %t391, %t392
  %t398 = add i64 %t390, %t395
  store i64 %t398, ptr %l21, !tbaa !24
  %t400 = load i64, ptr %l21, !tbaa !24
  %t402 = icmp sgt i64 %t400, 0
  br i1 %t402, label %bb99, label %bb100
bb99:
  %t404 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t404, i8 44)
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t407 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t407, ptr %l212, !tbaa !27
  %t408 = load i64, ptr %l21, !tbaa !24
  %t410 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !27
  %t412 = getelementptr i64, ptr %t411, i64 %t408
  %t413 = load i64, ptr %t412, !tbaa !34
  %t415 = call i64 @__olang_fmt_i64(ptr null, i64 %t413)
  %t416 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t415)
  %t417 = call i64 @__olang_fmt_i64(ptr %t416, i64 %t413)
  %t418 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t416, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t406, { i64, ptr } %t419)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s16)
  br label %bb104
bb104:
  %t423 = load i64, ptr %l20, !tbaa !24
  %t426 = add i64 %t423, 1
  store i64 %t426, ptr %l20, !tbaa !24
  br label %bb95
bb105:
  %t428 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t428, i8 93)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s14)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i32
  %l53 = alloca i1
  %l55 = alloca { i64, ptr }
  %l59 = alloca i32
  %l71 = alloca i64
  %l74 = alloca i64
  %l94 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l99 = alloca i32
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i32, ptr %l14, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l15, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/types:Table", ptr %t8, i32 0, i32 14
  store ptr %t10, ptr %l17, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l20
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = load i64, ptr %l20, !tbaa !24
  %t18 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store { i64, ptr } %t18, ptr %l21
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t19, { i64, ptr } %t20)
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t21, i8 58)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/types:Table", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l28
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v2, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/types:Table", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v2, ptr %t40)
  %t43 = call ptr @__olang_scope_hold(ptr %t42)
  %t44 = ptrtoint ptr %t43 to i64
  %t46 = inttoptr i64 %t36 to ptr
  %t48 = inttoptr i64 %t44 to ptr
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = load i32, ptr %l28, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t46, ptr %t48, ptr %t49, i32 %t50)
  store { i64, ptr } %t51, ptr %l33
  br label %bb7
bb7:
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = call ptr @__olang_scope_or(ptr %v2, ptr %t53)
  %t55 = call ptr @__olang_scope_hold(ptr %t54)
  %t56 = ptrtoint ptr %t55 to i64
  %t58 = inttoptr i64 %t56 to ptr
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %t58, ptr %t59, { i64, ptr } %t60)
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l38
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l39
  br label %bb10
bb10:
  %t70 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l5, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb11, label %bb12
bb11:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l46, !tbaa !27
  %t81 = load i64, ptr %l5, !tbaa !24
  %t83 = sub i64 %t81, 1
  %t85 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t88)
  store i32 %t91, ptr %l50
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb14
bb13:
  %t92 = load i32, ptr %l50, !range !{i32 0, i32 33}
  %t94 = trunc i64 30 to i32
  %t95 = icmp eq i32 %t92, %t94
  store i1 %t95, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t97 = load i1, ptr %l44, !tbaa !21
  br i1 %t97, label %bb15, label %bb16
bb15:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  %t100 = load i64, ptr %l5, !tbaa !24
  %t102 = sub i64 %t100, 1
  %t104 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i32, ptr %t105, i64 %t102
  %t107 = load i32, ptr %t106, !tbaa !33
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t98, i32 %t107)
  store i32 %t110, ptr %l59
  br label %bb17
bb16:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb18
bb17:
  %t111 = load i32, ptr %l59, !tbaa !23
  %t112 = icmp eq i32 %t111, 0
  store i1 %t112, ptr %l53, !tbaa !21
  br label %bb18
bb18:
  %t114 = load i1, ptr %l53, !tbaa !21
  br i1 %t114, label %bb19, label %bb20
bb19:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t118 = sub i64 %t115, 1
  store i64 %t118, ptr %l5, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb22, label %bb23
bb22:
  %t124 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t124, i8 60)
  br label %bb24
bb23:
  br label %bb47
bb24:
  store i64 0, ptr %l6, !tbaa !24
  %t126 = load i64, ptr %l5, !tbaa !24
  store i64 %t126, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t129 = load i64, ptr %l6, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb30
bb27:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l74, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb29
bb29:
  %t154 = load i64, ptr %l74, !tbaa !24
  store i64 %t154, ptr %l71, !tbaa !24
  br label %bb30
bb30:
  %t155 = load i64, ptr %l71, !tbaa !24
  store i64 %t155, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t156 = load i64, ptr %l10, !tbaa !24
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb32, label %bb33
bb32:
  br label %bb45
bb33:
  br label %bb34
bb34:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t165 = load i64, ptr %l10, !tbaa !24
  %t166 = load i64, ptr %l8, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t176 = icmp sgt i64 %t174, 0
  br i1 %t176, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l94, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t180, ptr %l96, !tbaa !27
  %t181 = load i64, ptr %l11, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t181
  %t186 = load i32, ptr %t185, !tbaa !33
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t179, i32 %t186)
  store i32 %t189, ptr %l99
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t190 = load i32, ptr %l99, !range !{i32 0, i32 33}
  %t192 = trunc i64 30 to i32
  %t193 = icmp eq i32 %t190, %t192
  br i1 %t193, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l102, !tbaa !27
  br label %bb40
bb40:
  %t195 = load ptr, ptr %l94, !tbaa !29
  %t196 = load { i64, ptr }, ptr %l102, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t195, { i64, ptr } %t196)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t199, ptr %l105, !tbaa !27
  %t200 = load i64, ptr %l11, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i32, ptr %t203, i64 %t200
  %t205 = load i32, ptr %t204, !tbaa !33
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanon(ptr %v0, ptr %v1, ptr %v2, ptr %t197, ptr %t198, i32 %t205)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l10, !tbaa !24
  br label %bb31
bb45:
  %t214 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t214, i8 62)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonPromises(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l105 = alloca i64
  %l108 = alloca i64
  %l133 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l157 = alloca ptr
  %l165 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames
  store i64 8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l35, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l35, !tbaa !24
  store i64 %t38, ptr %l32, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l32, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  store i64 %t59, ptr %l54, !tbaa !24
  %t60 = load i64, ptr %l54, !tbaa !24
  %t61 = load i64, ptr %l54, !tbaa !24
  %t62 = shl i64 1, %t61
  %t65 = and i64 %t58, %t62
  %t67 = icmp eq i64 %t65, 0
  br i1 %t67, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t71 = load i64, ptr %l10, !tbaa !24
  %t73 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2ePromiseNames, i64 0, i64 %t71
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !37
  %t76 = extractvalue { i64, ptr } %t70, 1
  %t77 = extractvalue { i64, ptr } %t70, 0
  %t79 = extractvalue { i64, ptr } %t74, 1
  %t80 = extractvalue { i64, ptr } %t74, 0
  %t81 = add i64 %t77, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t76, i64 %t77)
  %t83 = getelementptr i8, ptr %t82, i64 %t77
  call void @olang_textcopy(ptr %t83, ptr %t79, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t69, { i64, ptr } %t85)
  br label %bb15
bb15:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l66, !tbaa !27
  store { i64, ptr } %t89, ptr %l4, !tbaa !27
  %t92 = load i1, ptr @olang_2esole_2ecompiler__2ftypes__2ecompiler__2ftypes__3aTable__2ecanonPromises_2elocal_2e4
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load { i64, ptr }, ptr %l66
  %t95 = extractvalue { i64, ptr } %t94, 1
  call void @__olang_region_release(ptr %t95)
  store { i64, ptr } zeroinitializer, ptr %l66
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l9, !tbaa !24
  br label %bb8
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l2, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBorrowsOf(ptr %v0, ptr %s6, ptr %t101, i32 %t102)
  store { i64, ptr } %t105, ptr %l73
  br label %bb20
bb20:
  %t106 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t106, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t112 = load i64, ptr %l12, !tbaa !24
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t120 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t120, ptr %l81, !tbaa !27
  %t121 = load i64, ptr %l12, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i64, ptr %t124, i64 %t121
  %t126 = load i64, ptr %t125, !tbaa !34
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = extractvalue { i64, ptr } %t129, 0
  %t134 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t126)
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t132, i64 %t133)
  %t141 = getelementptr i8, ptr %t140, i64 %t133
  call void @olang_textcopy(ptr %t141, ptr %t134, i64 %t135)
  %t142 = getelementptr i8, ptr %t141, i64 %t135
  %t143 = call i64 @__olang_fmt_i64(ptr %t142, i64 %t126)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t140, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t128, { i64, ptr } %t145)
  br label %bb25
bb25:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l89, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t150, ptr %l91, !tbaa !27
  store { i64, ptr } %t149, ptr %l4, !tbaa !27
  %t152 = load i1, ptr @olang_2esole_2ecompiler__2ftypes__2ecompiler__2ftypes__3aTable__2ecanonPromises_2elocal_2e4
  br i1 %t152, label %bb26, label %bb27
bb26:
  %t154 = load { i64, ptr }, ptr %l91
  %t155 = extractvalue { i64, ptr } %t154, 1
  call void @__olang_region_release(ptr %t155)
  store { i64, ptr } zeroinitializer, ptr %l91
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l12, !tbaa !24
  br label %bb21
bb29:
  call void @__olang_scope_close(ptr %s6)
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l2, !tbaa !23
  %t165 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsOf(ptr %v0, ptr %s0, ptr %t161, i32 %t162)
  store { i64, ptr } %t165, ptr %l98
  br label %bb30
bb30:
  %t166 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t166, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = sdiv i64 %t169, 3
  store i64 %t171, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t173 = load i64, ptr %l17, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t177 = icmp sgt i64 %t173, %t174
  br i1 %t177, label %bb31, label %bb32
bb31:
  %t179 = load i64, ptr %l18, !tbaa !24
  %t181 = icmp sgt i64 %t179, 0
  br i1 %t181, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb36
bb33:
  %t183 = load i64, ptr %l17, !tbaa !24
  %t184 = load i64, ptr %l16, !tbaa !24
  %t187 = sub i64 %t183, %t184
  %t188 = load i64, ptr %l18, !tbaa !24
  %t191 = add i64 %t187, %t188
  %t193 = sub i64 %t191, 1
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = sdiv i64 %t193, %t194
  store i64 %t197, ptr %l108, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb35
bb35:
  %t199 = load i64, ptr %l108, !tbaa !24
  store i64 %t199, ptr %l105, !tbaa !24
  br label %bb36
bb36:
  %t200 = load i64, ptr %l105, !tbaa !24
  store i64 %t200, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s11
  %t201 = load i64, ptr %l20, !tbaa !24
  %t202 = load i64, ptr %l19, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb39:
  br label %bb40
bb40:
  %t209 = load i64, ptr %l16, !tbaa !24
  %t210 = load i64, ptr %l20, !tbaa !24
  %t211 = load i64, ptr %l18, !tbaa !24
  %t214 = mul i64 %t210, %t211
  %t217 = add i64 %t209, %t214
  store i64 %t217, ptr %l21, !tbaa !24
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t221 = load i64, ptr %l21, !tbaa !24
  %t223 = mul i64 3, %t221
  %t225 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i64, ptr %t226, i64 %t223
  %t228 = load i64, ptr %t227, !tbaa !34
  %t230 = extractvalue { i64, ptr } %t220, 1
  %t231 = extractvalue { i64, ptr } %t220, 0
  %t232 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t236 = call i64 @__olang_fmt_i64(ptr null, i64 %t228)
  %t237 = add i64 %t234, %t236
  %t238 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t230, i64 %t231)
  %t239 = getelementptr i8, ptr %t238, i64 %t231
  call void @olang_textcopy(ptr %t239, ptr %t232, i64 %t233)
  %t240 = getelementptr i8, ptr %t239, i64 %t233
  %t241 = call i64 @__olang_fmt_i64(ptr %t240, i64 %t228)
  %t242 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t238, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s11, ptr %t219, { i64, ptr } %t243)
  br label %bb41
bb41:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l133, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t248, ptr %l135, !tbaa !27
  store { i64, ptr } %t247, ptr %l4, !tbaa !27
  %t250 = load i1, ptr @olang_2esole_2ecompiler__2ftypes__2ecompiler__2ftypes__3aTable__2ecanonPromises_2elocal_2e4
  br i1 %t250, label %bb42, label %bb43
bb42:
  %t252 = load { i64, ptr }, ptr %l135
  %t253 = extractvalue { i64, ptr } %t252, 1
  call void @__olang_region_release(ptr %t253)
  store { i64, ptr } zeroinitializer, ptr %l135
  br label %bb43
bb43:
  %t254 = load i64, ptr %l21, !tbaa !24
  %t256 = mul i64 3, %t254
  %t258 = add i64 %t256, 1
  %t260 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i64, ptr %t261, i64 %t258
  %t263 = load i64, ptr %t262, !tbaa !34
  %t264 = load i64, ptr @G_2ecompiler_2ftypes_2eKeepsHome, !tbaa !24
  %t267 = icmp eq i64 %t263, %t264
  br i1 %t267, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s11)
  br label %bb53
bb45:
  br label %bb46
bb46:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t270 = load i64, ptr %l21, !tbaa !24
  %t272 = mul i64 3, %t270
  %t274 = add i64 %t272, 1
  %t276 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i64, ptr %t277, i64 %t274
  %t279 = load i64, ptr %t278, !tbaa !34
  %t280 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t283 = call i64 @__olang_fmt_i64(ptr null, i64 %t279)
  %t284 = add i64 %t281, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t280, i64 %t281)
  %t286 = getelementptr i8, ptr %t285, i64 %t281
  %t287 = call i64 @__olang_fmt_i64(ptr %t286, i64 %t279)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t285, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s11, ptr %t269, { i64, ptr } %t289)
  br label %bb47
bb47:
  %t293 = load i64, ptr %l21, !tbaa !24
  %t295 = mul i64 3, %t293
  %t297 = add i64 %t295, 2
  %t299 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i64, ptr %t300, i64 %t297
  %t302 = load i64, ptr %t301, !tbaa !34
  %t304 = icmp ne i64 %t302, 0
  br i1 %t304, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s15
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l155, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/types:Table", ptr %t307, i32 0, i32 0
  %t310 = load ptr, ptr %t309, !tbaa !29
  store ptr %t310, ptr %l157, !tbaa !29
  %t311 = load i64, ptr %l21, !tbaa !24
  %t313 = mul i64 3, %t311
  %t315 = add i64 %t313, 2
  %t317 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr i64, ptr %t318, i64 %t315
  %t320 = load i64, ptr %t319, !tbaa !34
  %t322 = trunc i64 %t320 to i32
  %t324 = load ptr, ptr %l157, !tbaa !29
  %t325 = call ptr @__olang_scope_or(ptr %v2, ptr %t324)
  %t326 = call ptr @__olang_scope_hold(ptr %t325)
  %t327 = ptrtoint ptr %t326 to i64
  %t329 = inttoptr i64 %t327 to ptr
  %t330 = load ptr, ptr %l157, !tbaa !29
  %t332 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t329, ptr %s15, ptr %t330, i32 %t322)
  store { i64, ptr } %t332, ptr %l165
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t335 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t333, i64 %t334)
  %t340 = getelementptr i8, ptr %t339, i64 %t334
  call void @olang_textcopy(ptr %t340, ptr %t336, i64 %t337)
  %t341 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t339, 1
  %t344 = load ptr, ptr %l155, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t344, { i64, ptr } %t342)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s15)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s11)
  br label %bb53
bb53:
  %t346 = load i64, ptr %l20, !tbaa !24
  %t349 = add i64 %t346, 1
  store i64 %t349, ptr %l20, !tbaa !24
  br label %bb37
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eclosedList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l5, !tbaa !23
  %t27 = load i32, ptr %l5, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l5, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eholdsState(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i8
  %l14 = alloca i8
  %rv = alloca i8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/types:Table", ptr %t6, i32 0, i32 36
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/types:Table", ptr %t15, i32 0, i32 36
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t17, i64 %t18)
  store i8 %t21, ptr %l14
  br label %bb4
bb3:
  store i8 0, ptr %l10, !tbaa !22
  br label %bb5
bb4:
  %t22 = load i8, ptr %l14, !tbaa !22
  store i8 %t22, ptr %l10, !tbaa !22
  br label %bb5
bb5:
  %t23 = load i8, ptr %l10, !tbaa !22
  store i8 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayEnum(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca i1
  %l16 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i64
  %l36 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = insertvalue { i64, i64 } undef, i64 4, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 4, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l16
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i32, ptr %t34, i64 %t31
  %t36 = load i32, ptr %t35, !tbaa !33
  store i32 %t36, ptr %l7, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = icmp ne i32 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t50 = icmp sgt i64 %t48, %t47
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l36
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t58 = load i64, ptr %l36, !tbaa !24
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t59, 1
  store i64 %t62, ptr %l5, !tbaa !24
  br label %bb6
bb19:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = add i64 %t64, 7
  %t68 = sdiv i64 %t66, 8
  %t70 = mul i64 %t68, 8
  store i64 %t70, ptr %l8, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/types:Table", ptr %t72, i32 0, i32 25
  %t77 = sext i32 %a1 to i64
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t77, i64 %t78)
  br label %bb20
bb20:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 8, %t82
  %t86 = insertvalue { i64, i64 } undef, i64 %t84, 0
  %t87 = insertvalue { i64, i64 } %t86, i64 8, 1
  store { i64, i64 } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayFields(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l31 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 23
  store ptr %t3, ptr %l11, !tbaa !29
  %t6 = sext i32 %a1 to i64
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/types:Table", ptr %t7, i32 0, i32 24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13, i64 %t14)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t15, i32 %a2)
  store { i64, ptr } %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  store i32 %t39, ptr %l8, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l8, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l31
  br label %bb8
bb8:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = add i64 %t55, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = mul i64 %t66, %t67
  store i64 %t70, ptr %l3, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/types:Table", ptr %t72, i32 0, i32 24
  %t75 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  br label %bb12
bb12:
  %t78 = load i64, ptr %l3, !tbaa !24
  store i64 %t78, ptr %l48, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l8, !tbaa !23
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t79, i32 %t80)
  store i64 %t83, ptr %l51
  br label %bb13
bb13:
  %t84 = load i64, ptr %l48, !tbaa !24
  %t85 = load i64, ptr %l51, !tbaa !24
  %t86 = add i64 %t84, %t85
  store i64 %t86, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l6, !tbaa !24
  br label %bb4
bb15:
  %t93 = load i64, ptr %l3, !tbaa !24
  %t94 = load i64, ptr %l4, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  %t104 = load i64, ptr %l4, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = insertvalue { i64, i64 } undef, i64 %t107, 0
  %t112 = insertvalue { i64, i64 } %t110, i64 %t108, 1
  store { i64, i64 } %t112, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elayPacked(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:Table", ptr %t1, i32 0, i32 23
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/types:Table", ptr %t7, i32 0, i32 24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13, i64 %t14)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l17
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = load i32, ptr %l17, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t23, ptr %l18
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  %t43 = load i32, ptr %t42, !tbaa !33
  store i32 %t43, ptr %l6, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/types:Table", ptr %t45, i32 0, i32 24
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = sdiv i64 %t48, 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t47, i64 %t50)
  br label %bb9
bb9:
  %t53 = load i64, ptr %l2, !tbaa !24
  store i64 %t53, ptr %l32, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l6, !tbaa !23
  %t58 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldBits(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l35
  br label %bb10
bb10:
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = load i64, ptr %l35, !tbaa !24
  %t61 = add i64 %t59, %t60
  store i64 %t61, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb5
bb12:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t70 = add i64 %t68, 7
  %t72 = sdiv i64 %t70, 8
  %t74 = insertvalue { i64, i64 } undef, i64 %t72, 0
  %t75 = insertvalue { i64, i64 } %t74, i64 1, 1
  store { i64, i64 } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistHolds(ptr %v0, ptr %a0, i32 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a2, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l7, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l27
  br label %bb11
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 37
  store i1 true, ptr %t42, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb22
bb11:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb18
bb13:
  br i1 %a3, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l7, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l33
  br label %bb16
bb15:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb2
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a3, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l7, !tbaa !23
  %t39 = add i64 %a2, 1
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %t35, i32 %t36, i64 %t39)
  store i1 %t43, ptr %l29
  br label %bb11
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb15
bb11:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l5, !tbaa !24
  br label %bb2
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !range !{i32 0, i32 6}
  store i32 %t10, ptr %l2
  %t11 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t13 = trunc i64 0 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t22, i32 %t23)
  store i64 %t26, ptr %l17
  br label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %v2, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l21
  br label %bb10
bb9:
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t34 = load i64, ptr %l17, !tbaa !24
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = add i64 %t33, %t35
  %t37 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t32, i64 %t33)
  %t41 = getelementptr i8, ptr %t40, i64 %t33
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t34)
  %t43 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  br label %bb11
bb10:
  %t47 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t47, ptr %l14, !tbaa !27
  br label %bb11
bb11:
  %t48 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t48, ptr %l8, !tbaa !27
  br label %bb32
bb12:
  %t49 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t51 = trunc i64 1 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t54, i32 %t55)
  store { i64, ptr } %t58, ptr %l26
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t59, ptr %l8, !tbaa !27
  br label %bb32
bb17:
  %t60 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t62 = trunc i64 2 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t65, ptr %l8, !tbaa !27
  br label %bb32
bb21:
  %t67 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t69 = trunc i64 4 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb27
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l33, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l36
  br label %bb25
bb25:
  %t78 = load ptr, ptr %l33, !tbaa !29
  %t79 = load i32, ptr %l36, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s5, ptr %v2, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l37
  br label %bb26
bb26:
  %t81 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t88, ptr %l8, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_b0143a025c7cdb06_8f46c74feff323b2)
  unreachable
bb32:
  %t90 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l41, !tbaa !24
  %t92 = load i64, ptr %l41, !tbaa !24
  %t93 = mul i64 %t92, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l42, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l41, !tbaa !24
  %t102 = mul i64 %t101, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t98, ptr %t100, i64 %t102, i1 false)
  %t103 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t103, ptr %l8, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i32, ptr %t23, i64 %t20
  %t25 = load i32, ptr %t24, !tbaa !33
  store i32 %t25, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t29 = icmp eq i32 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t33 = xor i1 %a3, true
  br i1 %t33, label %bb8, label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l7, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l27
  br label %bb11
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/types:Table", ptr %t40, i32 0, i32 37
  store i1 true, ptr %t42, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb19
bb11:
  %t43 = load i1, ptr %l27, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l7, !tbaa !23
  %t50 = add i64 %a2, 1
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t46, i32 %t47, i64 %t50)
  store i1 %t54, ptr %l34
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb15
bb14:
  %t55 = load i1, ptr %l34, !tbaa !21
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb2
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esetHolds(ptr %v0, ptr %a0, i32 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/types:Table", ptr %t5, i32 0, i32 36
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sle i64 %t11, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/types:Table", ptr %t17, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t19, i8 0)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %bb1
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/types:Table", ptr %t21, i32 0, i32 36
  %t24 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t23, i64 %t24, i8 %a2)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca i32
  %l71 = alloca i1
  %l74 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i1
  %l82 = alloca ptr
  %l85 = alloca i32
  %l88 = alloca i1
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i32
  %l103 = alloca i1
  %l108 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca i1
  %l116 = alloca ptr
  %l119 = alloca i32
  %l121 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l14
  br label %bb4
bb4:
  %t11 = load i1, ptr %l14, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l18
  br label %bb8
bb8:
  %t18 = load i32, ptr %l18, !range !{i32 0, i32 33}
  store i32 %t18, ptr %l3
  %t19 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t21 = trunc i64 20 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 21 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 25 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t38 = trunc i64 29 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l27, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t45 = trunc i64 18 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb69
bb23:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l35
  br label %bb24
bb24:
  %t53 = load i1, ptr %l35, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/types:Table", ptr %t57, i32 0, i32 38
  store ptr %t59, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb28
bb28:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l42
  br label %bb29
bb29:
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t71, i64 %t72)
  store i32 %t75, ptr %l47
  br label %bb33
bb33:
  %t76 = load i32, ptr %l47, !tbaa !23
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = icmp eq i32 %t76, %t78
  br i1 %t81, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l5, !tbaa !24
  br label %bb28
bb38:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/types:Table", ptr %t89, i32 0, i32 38
  %t92 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t91, i32 %t92)
  br label %bb39
bb39:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l58, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l61
  br label %bb40
bb40:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load i32, ptr %l61, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t103, ptr %l62
  br label %bb41
bb41:
  %t104 = load i32, ptr %l62, !range !{i32 0, i32 6}
  store i32 %t104, ptr %l7
  %t105 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t107 = trunc i64 0 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l66, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l69
  br label %bb45
bb45:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t117 = load ptr, ptr %l66, !tbaa !29
  %t118 = load i32, ptr %l69, !tbaa !23
  %t120 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t117, i32 %t118, i64 %t116, i1 false)
  store i1 %t120, ptr %l71
  br label %bb46
bb46:
  %t121 = load i1, ptr %l71, !tbaa !21
  store i1 %t121, ptr %l63, !tbaa !21
  br label %bb64
bb47:
  %t122 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t124 = trunc i64 1 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l74, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l77
  br label %bb51
bb51:
  %t133 = load i64, ptr %l2, !tbaa !24
  %t134 = load ptr, ptr %l74, !tbaa !29
  %t135 = load i32, ptr %l77, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t134, i32 %t135, i64 %t133, i1 true)
  store i1 %t137, ptr %l79
  br label %bb52
bb52:
  %t138 = load i1, ptr %l79, !tbaa !21
  store i1 %t138, ptr %l63, !tbaa !21
  br label %bb64
bb53:
  %t139 = load i32, ptr %l7, !range !{i32 0, i32 6}
  %t141 = trunc i64 4 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l1, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l85
  br label %bb57
bb57:
  %t150 = load i64, ptr %l2, !tbaa !24
  %t152 = add i64 %t150, 1
  %t153 = load ptr, ptr %l82, !tbaa !29
  %t154 = load i32, ptr %l85, !tbaa !23
  %t156 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %t153, i32 %t154, i64 %t152)
  store i1 %t156, ptr %l88
  br label %bb58
bb58:
  %t157 = load i1, ptr %l88, !tbaa !21
  store i1 %t157, ptr %l63, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_e8197a4e96a8cf74_6f7a0b4ee9272b70)
  unreachable
bb64:
  %t158 = load i1, ptr %l63, !tbaa !21
  store i1 %t158, ptr %l8, !tbaa !21
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/types:Table", ptr %t159, i32 0, i32 38
  %t163 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePop_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t161)
  %t164 = extractvalue { i32, i32 } %t163, 1
  %t165 = extractvalue { i32, i32 } %t163, 0
  store i32 %t165, ptr %l93
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb66, label %ok.167, !prof !99
ok.167:
  store i32 %t164, ptr %l92
  br label %bb65
bb65:
  %t168 = load i32, ptr %l92, !tbaa !23
  store i32 %t168, ptr %l89, !tbaa !23
  br label %bb68
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t169 = load i1, ptr %l8, !tbaa !21
  store i1 %t169, ptr %rv
  br label %ret
bb69:
  %t171 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t173 = trunc i64 19 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l97, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l100
  br label %bb73
bb73:
  %t182 = load i64, ptr %l2, !tbaa !24
  %t184 = add i64 %t182, 1
  %t185 = load ptr, ptr %l97, !tbaa !29
  %t186 = load i32, ptr %l100, !tbaa !23
  %t188 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2esharesRefs(ptr %v0, ptr %t185, i32 %t186, i64 %t184)
  store i1 %t188, ptr %l103
  br label %bb74
bb74:
  %t189 = load i1, ptr %l103, !tbaa !21
  store i1 %t189, ptr %rv
  br label %ret
bb75:
  %t190 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t192 = trunc i64 22 to i32
  %t193 = icmp eq i32 %t190, %t192
  br i1 %t193, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  %t195 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t197 = trunc i64 23 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l108, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l1, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l111
  br label %bb81
bb81:
  %t206 = load i64, ptr %l2, !tbaa !24
  %t207 = load ptr, ptr %l108, !tbaa !29
  %t208 = load i32, ptr %l111, !tbaa !23
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t207, i32 %t208, i64 %t206, i1 false)
  store i1 %t210, ptr %l113
  br label %bb82
bb82:
  %t211 = load i1, ptr %l113, !tbaa !21
  store i1 %t211, ptr %rv
  br label %ret
bb83:
  %t212 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t214 = trunc i64 24 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l116, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l1, !tbaa !23
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t218, i32 %t219)
  store i32 %t222, ptr %l119
  br label %bb87
bb87:
  %t223 = load i64, ptr %l2, !tbaa !24
  %t224 = load ptr, ptr %l116, !tbaa !29
  %t225 = load i32, ptr %l119, !tbaa !23
  %t227 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2elistShares(ptr %v0, ptr %t224, i32 %t225, i64 %t223, i1 true)
  store i1 %t227, ptr %l121
  br label %bb88
bb88:
  %t228 = load i1, ptr %l121, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  store i1 false, ptr %rv
  br label %ret
bb93:
  call void @__olang_check_failed(ptr @olang_loc_e0765d015d87e9a5_6d8cc8ea93d2cf01)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2espellLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/types:data"
  %l3 = alloca i32
  %l6 = alloca %"compiler/types:data"
  %l8 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/types:data" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/types:data", ptr %l6
  store %"compiler/types:data" %t6, ptr %l2
  %t7 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 33}
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  %t15 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  %t20 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t22 = trunc i64 3 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb30
bb7:
  %t25 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t27 = trunc i64 4 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb30
bb9:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t32 = trunc i64 5 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb30
bb11:
  %t35 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb12, label %bb13
bb12:
  br label %bb30
bb13:
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t42 = trunc i64 7 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t47 = trunc i64 8 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t52 = trunc i64 9 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb18, label %bb19
bb18:
  br label %bb30
bb19:
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t57 = trunc i64 10 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb20, label %bb21
bb20:
  br label %bb30
bb21:
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t62 = trunc i64 11 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t67 = trunc i64 12 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t70 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t72 = trunc i64 13 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t75 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t77 = trunc i64 14 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t80 = load i32, ptr %l1, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t84 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2ftypes_2eprimLlvm, i64 0, i64 %t82
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !37
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  br label %bb99
bb31:
  %t93 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t95 = trunc i64 31 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t98 = getelementptr %"compiler/types:data", ptr %l2, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t99)
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t100, i64 %t101)
  %t106 = getelementptr i8, ptr %t105, i64 %t101
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t99)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  br label %bb99
bb35:
  %t111 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t113 = trunc i64 16 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t116, ptr %l8, !tbaa !27
  br label %bb99
bb39:
  %t118 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t120 = trunc i64 32 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l1, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l53
  br label %bb43
bb43:
  %t128 = load i32, ptr %l53, !tbaa !23
  %t129 = icmp eq i32 %t128, 5
  br i1 %t129, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t131, ptr %l55, !tbaa !27
  br label %bb48
bb45:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l58, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l61
  br label %bb46
bb46:
  %t139 = load ptr, ptr %l58, !tbaa !29
  %t140 = load i32, ptr %l61, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %t139, i32 %t140)
  store { i64, ptr } %t141, ptr %l62
  br label %bb47
bb47:
  %t142 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t142, ptr %l55, !tbaa !27
  br label %bb48
bb48:
  %t144 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t144, ptr %l8, !tbaa !27
  br label %bb99
bb49:
  %t145 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t147 = trunc i64 17 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  br label %bb99
bb53:
  %t152 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t154 = trunc i64 21 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l8, !tbaa !27
  br label %bb99
bb57:
  %t159 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t161 = trunc i64 20 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb71
bb60:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l74, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l1, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l77
  br label %bb61
bb61:
  %t170 = load ptr, ptr %l74, !tbaa !29
  %t171 = load i32, ptr %l77, !tbaa !23
  %t172 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t172, ptr %l78
  br label %bb62
bb62:
  %t173 = load i1, ptr %l78, !tbaa !21
  br i1 %t173, label %bb63, label %bb64
bb63:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t174, ptr %l79, !tbaa !27
  br label %bb70
bb64:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l82, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l85
  br label %bb65
bb65:
  %t182 = load ptr, ptr %l82, !tbaa !29
  %t183 = load i32, ptr %l85, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t184, ptr %l86
  br label %bb66
bb66:
  %t185 = load i32, ptr %l86, !range !{i32 0, i32 33}
  %t187 = trunc i64 29 to i32
  %t188 = icmp eq i32 %t185, %t187
  br i1 %t188, label %bb67, label %bb68
bb67:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l90, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t190, ptr %l89, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t192, ptr %l89, !tbaa !27
  br label %bb69
bb69:
  %t194 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t194, ptr %l79, !tbaa !27
  br label %bb70
bb70:
  %t195 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  br label %bb99
bb71:
  %t196 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t198 = trunc i64 19 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l1, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2earrayLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l98
  br label %bb75
bb75:
  %t206 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t206, ptr %l8, !tbaa !27
  br label %bb99
bb76:
  %t207 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t209 = trunc i64 22 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb77, label %bb78
bb77:
  br label %bb81
bb78:
  %t212 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t214 = trunc i64 23 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb84
bb81:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l103, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l1, !tbaa !23
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t218, i32 %t219)
  store i32 %t222, ptr %l106
  br label %bb82
bb82:
  %t223 = load ptr, ptr %l103, !tbaa !29
  %t224 = load i32, ptr %l106, !tbaa !23
  %t225 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %v2, ptr %t223, i32 %t224)
  store { i64, ptr } %t225, ptr %l107
  br label %bb83
bb83:
  %t226 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t226, ptr %l8, !tbaa !27
  br label %bb99
bb84:
  %t227 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t229 = trunc i64 24 to i32
  %t230 = icmp eq i32 %t227, %t229
  br i1 %t230, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %t232, i32 %t233)
  store { i64, ptr } %t236, ptr %l112
  br label %bb88
bb88:
  %t237 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t237, ptr %l8, !tbaa !27
  br label %bb99
bb89:
  %t238 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t240 = trunc i64 18 to i32
  %t241 = icmp eq i32 %t238, %t240
  br i1 %t241, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l1, !tbaa !23
  %t247 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2enamedLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %t243, i32 %t244)
  store { i64, ptr } %t247, ptr %l117
  br label %bb93
bb93:
  %t248 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t248, ptr %l8, !tbaa !27
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l118, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t249, ptr %l8, !tbaa !27
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_bbfcd5581dbe335b_bbf57adf6fe10b0f)
  unreachable
bb99:
  %t251 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l120, !tbaa !24
  %t253 = load i64, ptr %l120, !tbaa !24
  %t254 = mul i64 %t253, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t254)
  %t256 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l121, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = load i64, ptr %l120, !tbaa !24
  %t263 = mul i64 %t262, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %t261, i64 %t263, i1 false)
  %t264 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t264, ptr %l8, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2estructName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, i64 }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %v2, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  %t13 = icmp eq i32 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t16, i64 %t17)
  %t26 = getelementptr i8, ptr %t25, i64 %t17
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = getelementptr i8, ptr %t26, i64 %t20
  call void @olang_textcopy(ptr %t27, ptr %t22, i64 %t23)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) })
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l19
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l18
  br label %bb6
bb6:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %s0, ptr %v2, ptr %t44, i32 %t45)
  store { i64, ptr } %t48, ptr %l24
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t51 = call { i64, i64 } @compiler_2ftypes_2ehash128(ptr %s0, { i64, ptr } %t49)
  store { i64, i64 } %t51, ptr %l26
  br label %bb11
bb11:
  %t52 = load { i64, i64 }, ptr %l26
  store { i64, i64 } %t52, ptr %l4
  %t53 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t54 = load i64, ptr %t53, !tbaa !65
  store i64 %t54, ptr %l5, !tbaa !65
  %t56 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !65
  store i64 %t57, ptr %l6, !tbaa !65
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l29, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l30, !tbaa !24
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = load i64, ptr %l29, !tbaa !24
  %t65 = icmp sle i64 0, %t64
  br i1 %t65, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb14:
  %t67 = load i64, ptr %l29, !tbaa !24
  %t68 = load i64, ptr %l30, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb16:
  %t71 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = getelementptr i8, ptr %t72, i64 0
  %t75 = sub i64 %t73, 0
  %t76 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  store { i64, ptr } %t77, ptr %l34, !tbaa !27
  %t78 = load i64, ptr %l5, !tbaa !65
  %t80 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t78)
  store { i64, ptr } %t80, ptr %l36
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077)
  unreachable
bb18:
  %t81 = load i64, ptr %l6, !tbaa !65
  %t83 = call { i64, ptr } @compiler_2ftypes_2ehex16(ptr %s0, i64 %t81)
  store { i64, ptr } %t83, ptr %l38
  br label %bb19
bb19:
  %t84 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t86 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t84, i64 %t85)
  %t105 = getelementptr i8, ptr %t104, i64 %t85
  call void @olang_textcopy(ptr %t105, ptr %t87, i64 %t88)
  %t106 = getelementptr i8, ptr %t105, i64 %t88
  call void @olang_textcopy(ptr %t106, ptr %t90, i64 %t91)
  %t107 = getelementptr i8, ptr %t106, i64 %t91
  call void @olang_textcopy(ptr %t107, ptr %t94, i64 %t95)
  %t108 = getelementptr i8, ptr %t107, i64 %t95
  call void @olang_textcopy(ptr %t108, ptr %t98, i64 %t99)
  %t109 = getelementptr i8, ptr %t108, i64 %t99
  call void @olang_textcopy(ptr %t109, ptr %t101, i64 %t102)
  %t110 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t104, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l10 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l44 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l10
  br label %bb4
bb4:
  %t11 = load i32, ptr %l10, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/types:Table", ptr %t16, i32 0, i32 41
  store ptr %t18, ptr %l14, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l17
  br label %bb7
bb6:
  br label %bb45
bb7:
  %t24 = load i32, ptr %l17, !tbaa !23
  %t25 = sext i32 %t24 to i64
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t28 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t26, i64 %t25)
  store i1 %t28, ptr %l19
  br label %bb8
bb8:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb12
bb12:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l27
  br label %bb16
bb16:
  %t43 = load i1, ptr %l27, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb17, label %bb18
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/types:Table", ptr %t46, i32 0, i32 37
  store i1 true, ptr %t48, !tbaa !21
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l34
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = load i32, ptr %l34, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l35
  br label %bb21
bb21:
  %t59 = load i32, ptr %l35, !range !{i32 0, i32 6}
  store i32 %t59, ptr %l3
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t62 = trunc i64 0 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l42
  br label %bb25
bb25:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = load i32, ptr %l42, !tbaa !23
  %t75 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t72, i32 %t73, i64 %t71, i1 false)
  store i1 %t75, ptr %l44
  br label %bb26
bb26:
  %t76 = load i1, ptr %l44, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb44
bb27:
  %t77 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t79 = trunc i64 1 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l50
  br label %bb31
bb31:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = load i32, ptr %l50, !tbaa !23
  %t92 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t89, i32 %t90, i64 %t88, i1 true)
  store i1 %t92, ptr %l52
  br label %bb32
bb32:
  %t93 = load i1, ptr %l52, !tbaa !21
  store i1 %t93, ptr %l36, !tbaa !21
  br label %bb44
bb33:
  %t94 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t96 = trunc i64 4 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l55, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l1, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l58
  br label %bb37
bb37:
  %t105 = load i64, ptr %l2, !tbaa !24
  %t107 = add i64 %t105, 1
  %t108 = load ptr, ptr %l55, !tbaa !29
  %t109 = load i32, ptr %l58, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t108, i32 %t109, i64 %t107)
  store i1 %t111, ptr %l61
  br label %bb38
bb38:
  %t112 = load i1, ptr %l61, !tbaa !21
  store i1 %t112, ptr %l36, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_983e1053235c526f_18c94ea801ade2a3)
  unreachable
bb44:
  %t113 = load i1, ptr %l36, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb45:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l64
  br label %bb46
bb46:
  %t119 = load i32, ptr %l64, !range !{i32 0, i32 33}
  store i32 %t119, ptr %l4
  %t120 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t122 = trunc i64 19 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l68, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l71
  br label %bb50
bb50:
  %t131 = load i64, ptr %l2, !tbaa !24
  %t133 = add i64 %t131, 1
  %t134 = load ptr, ptr %l68, !tbaa !29
  %t135 = load i32, ptr %l71, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eunique(ptr %v0, ptr %t134, i32 %t135, i64 %t133)
  store i1 %t137, ptr %l74
  br label %bb51
bb51:
  %t138 = load i1, ptr %l74, !tbaa !21
  store i1 %t138, ptr %l65, !tbaa !21
  br label %bb69
bb52:
  %t139 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t141 = trunc i64 23 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l77, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l1, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l80
  br label %bb56
bb56:
  %t150 = load i64, ptr %l2, !tbaa !24
  %t151 = load ptr, ptr %l77, !tbaa !29
  %t152 = load i32, ptr %l80, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t151, i32 %t152, i64 %t150, i1 false)
  store i1 %t154, ptr %l82
  br label %bb57
bb57:
  %t155 = load i1, ptr %l82, !tbaa !21
  store i1 %t155, ptr %l65, !tbaa !21
  br label %bb69
bb58:
  %t156 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t158 = trunc i64 24 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l85, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l1, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l88
  br label %bb62
bb62:
  %t167 = load i64, ptr %l2, !tbaa !24
  %t168 = load ptr, ptr %l85, !tbaa !29
  %t169 = load i32, ptr %l88, !tbaa !23
  %t171 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2epartsUnique(ptr %v0, ptr %t168, i32 %t169, i64 %t167, i1 true)
  store i1 %t171, ptr %l90
  br label %bb63
bb63:
  %t172 = load i1, ptr %l90, !tbaa !21
  store i1 %t172, ptr %l65, !tbaa !21
  br label %bb69
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_427e8c4f545bd5ae_655f412a6751c1a2)
  unreachable
bb69:
  %t173 = load i1, ptr %l65, !tbaa !21
  store i1 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2enamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:codeWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t13, ptr %t14, i32 %t7)
  store i1 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v1, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t29 = inttoptr i64 %t27 to ptr
  %t30 = load ptr, ptr %l13, !tbaa !29
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t29, ptr %t30, i32 %t23)
  store i32 %t32, ptr %l16
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l12, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l12, !tbaa !29
  %t40 = load i32, ptr %l16, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %t38, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l18
  br label %bb6
bb6:
  %t42 = load i32, ptr %l18, !range !{i32 0, i32 6}
  store i32 %t42, ptr %l3
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t45 = trunc i64 0 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l22, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l23, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v1, ptr %t51)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t54 to ptr
  %t57 = load ptr, ptr %l23, !tbaa !29
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t56, ptr %t57, i32 %t50)
  store i32 %t59, ptr %l26
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l22, !tbaa !29
  %t61 = load i32, ptr %l26, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %v1, ptr %t60, i32 %t61)
  store i1 %t62, ptr %l27
  br label %bb11
bb11:
  %t63 = load i1, ptr %l27, !tbaa !21
  store i1 %t63, ptr %l19, !tbaa !21
  br label %bb29
bb12:
  %t64 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t66 = trunc i64 1 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l30, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  store ptr %t70, ptr %l31, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v1, ptr %t72)
  %t74 = call ptr @__olang_scope_hold(ptr %t73)
  %t75 = ptrtoint ptr %t74 to i64
  %t77 = inttoptr i64 %t75 to ptr
  %t78 = load ptr, ptr %l31, !tbaa !29
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %t77, ptr %t78, i32 %t71)
  store i32 %t80, ptr %l34
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l30, !tbaa !29
  %t82 = load i32, ptr %l34, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %v1, ptr %t81, i32 %t82)
  store i1 %t83, ptr %l35
  br label %bb17
bb17:
  %t84 = load i1, ptr %l35, !tbaa !21
  store i1 %t84, ptr %l19, !tbaa !21
  br label %bb29
bb18:
  %t85 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t87 = trunc i64 4 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l38, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  store ptr %t91, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  %t93 = load ptr, ptr %l39, !tbaa !29
  %t94 = call ptr @__olang_scope_or(ptr %v1, ptr %t93)
  %t95 = call ptr @__olang_scope_hold(ptr %t94)
  %t96 = ptrtoint ptr %t95 to i64
  %t98 = inttoptr i64 %t96 to ptr
  %t99 = load ptr, ptr %l39, !tbaa !29
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %t98, ptr %t99, i32 %t92)
  store i32 %t101, ptr %l42
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l38, !tbaa !29
  %t103 = load i32, ptr %l42, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %v1, ptr %t102, i32 %t103)
  store i1 %t104, ptr %l43
  br label %bb23
bb23:
  %t105 = load i1, ptr %l43, !tbaa !21
  store i1 %t105, ptr %l19, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_99f937c00427181_9a6d61fc7809e035)
  unreachable
bb29:
  %t106 = load i1, ptr %l19, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i64
  %l62 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i1
  %l101 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:codeWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %t13, ptr %t14, i32 %t7)
  store i1 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l11, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = call ptr @__olang_scope_or(ptr %v1, ptr %t21)
  %t23 = call ptr @__olang_scope_hold(ptr %t22)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %t26, ptr %t27, i32 %t20)
  store i1 %t29, ptr %l14
  br label %bb5
bb5:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb9
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/types:codeWalk", ptr %t31, i32 0, i32 3
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l19
  br label %bb8
bb8:
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l15, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l2, !tbaa !29
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = call ptr @__olang_scope_or(ptr %v1, ptr %t43)
  %t45 = call ptr @__olang_scope_hold(ptr %t44)
  %t46 = ptrtoint ptr %t45 to i64
  %t48 = inttoptr i64 %t46 to ptr
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t48, ptr %t49, i32 %t42)
  store i32 %t51, ptr %l24
  br label %bb13
bb13:
  %t52 = load i32, ptr %l24, !range !{i32 0, i32 33}
  store i32 %t52, ptr %l3
  %t53 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t55 = trunc i64 21 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/types:codeWalk", ptr %t58, i32 0, i32 2
  %t61 = load i1, ptr %t60, !tbaa !21
  store i1 %t61, ptr %l27, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l31, !tbaa !29
  %t65 = load i32, ptr %l1, !tbaa !23
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = call ptr @__olang_scope_or(ptr %v1, ptr %t66)
  %t68 = call ptr @__olang_scope_hold(ptr %t67)
  %t69 = ptrtoint ptr %t68 to i64
  %t71 = inttoptr i64 %t69 to ptr
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %t71, ptr %t72, i32 %t65)
  store i1 %t74, ptr %l34
  br label %bb19
bb18:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb20
bb19:
  %t75 = load i1, ptr %l34, !tbaa !21
  store i1 %t75, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t76 = load i1, ptr %l30, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t78 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t80 = trunc i64 21 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb25:
  %t83 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t85 = trunc i64 25 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l38, !tbaa !21
  br i1 %t88, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t91 = trunc i64 29 to i32
  %t92 = icmp eq i32 %t89, %t91
  store i1 %t92, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l41, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/types:codeWalk", ptr %t96, i32 0, i32 1
  %t99 = load i1, ptr %t98, !tbaa !21
  br i1 %t99, label %bb33, label %bb34
bb33:
  %t101 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t103 = trunc i64 20 to i32
  %t104 = icmp eq i32 %t101, %t103
  store i1 %t104, ptr %l47, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l47, !tbaa !21
  br i1 %t106, label %bb36, label %bb37
bb36:
  %t107 = load ptr, ptr %l2, !tbaa !29
  store ptr %t107, ptr %l51, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t109 = load ptr, ptr %l51, !tbaa !29
  %t110 = call ptr @__olang_scope_or(ptr %v1, ptr %t109)
  %t111 = call ptr @__olang_scope_hold(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t114 = inttoptr i64 %t112 to ptr
  %t115 = load ptr, ptr %l51, !tbaa !29
  %t117 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t114, ptr %t115, i32 %t108)
  store i64 %t117, ptr %l54
  br label %bb38
bb37:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb39
bb38:
  %t118 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t119 = load i64, ptr %l54, !tbaa !24
  %t121 = and i64 %t119, %t118
  %t123 = icmp ne i64 %t121, 0
  store i1 %t123, ptr %l50, !tbaa !21
  br label %bb39
bb39:
  %t125 = load i1, ptr %l50, !tbaa !21
  br i1 %t125, label %bb40, label %bb41
bb40:
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/types:codeWalk", ptr %t127, i32 0, i32 3
  %t130 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t129, i32 %t130)
  br label %bb43
bb43:
  %t133 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t135 = trunc i64 20 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l65, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  store ptr %t139, ptr %l66, !tbaa !29
  %t140 = load i32, ptr %l1, !tbaa !23
  %t141 = load ptr, ptr %l66, !tbaa !29
  %t142 = call ptr @__olang_scope_or(ptr %v1, ptr %t141)
  %t143 = call ptr @__olang_scope_hold(ptr %t142)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l66, !tbaa !29
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t146, ptr %t147, i32 %t140)
  store i32 %t149, ptr %l69
  br label %bb47
bb47:
  %t150 = load ptr, ptr %l65, !tbaa !29
  %t151 = load i32, ptr %l69, !tbaa !23
  %t152 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %v1, ptr %t150, i32 %t151)
  store i1 %t152, ptr %l70
  br label %bb48
bb48:
  %t153 = load i1, ptr %l70, !tbaa !21
  store i1 %t153, ptr %l62, !tbaa !21
  br label %bb79
bb49:
  %t154 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t156 = trunc i64 19 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l73, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  store ptr %t160, ptr %l74, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t162 = load ptr, ptr %l74, !tbaa !29
  %t163 = call ptr @__olang_scope_or(ptr %v1, ptr %t162)
  %t164 = call ptr @__olang_scope_hold(ptr %t163)
  %t165 = ptrtoint ptr %t164 to i64
  %t167 = inttoptr i64 %t165 to ptr
  %t168 = load ptr, ptr %l74, !tbaa !29
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t167, ptr %t168, i32 %t161)
  store i32 %t170, ptr %l77
  br label %bb53
bb53:
  %t171 = load ptr, ptr %l73, !tbaa !29
  %t172 = load i32, ptr %l77, !tbaa !23
  %t173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2ereaches(ptr %v0, ptr %v1, ptr %t171, i32 %t172)
  store i1 %t173, ptr %l78
  br label %bb54
bb54:
  %t174 = load i1, ptr %l78, !tbaa !21
  store i1 %t174, ptr %l62, !tbaa !21
  br label %bb79
bb55:
  %t175 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t177 = trunc i64 22 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  %t180 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t182 = trunc i64 23 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l83, !tbaa !29
  %t186 = load ptr, ptr %l2, !tbaa !29
  store ptr %t186, ptr %l84, !tbaa !29
  %t187 = load i32, ptr %l1, !tbaa !23
  %t188 = load ptr, ptr %l84, !tbaa !29
  %t189 = call ptr @__olang_scope_or(ptr %v1, ptr %t188)
  %t190 = call ptr @__olang_scope_hold(ptr %t189)
  %t191 = ptrtoint ptr %t190 to i64
  %t193 = inttoptr i64 %t191 to ptr
  %t194 = load ptr, ptr %l84, !tbaa !29
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t193, ptr %t194, i32 %t187)
  store i32 %t196, ptr %l87
  br label %bb61
bb61:
  %t197 = load ptr, ptr %l83, !tbaa !29
  %t198 = load i32, ptr %l87, !tbaa !23
  %t199 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %v1, ptr %t197, i32 %t198)
  store i1 %t199, ptr %l88
  br label %bb62
bb62:
  %t200 = load i1, ptr %l88, !tbaa !21
  store i1 %t200, ptr %l62, !tbaa !21
  br label %bb79
bb63:
  %t201 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t203 = trunc i64 24 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l91, !tbaa !29
  %t207 = load ptr, ptr %l2, !tbaa !29
  store ptr %t207, ptr %l92, !tbaa !29
  %t208 = load i32, ptr %l1, !tbaa !23
  %t209 = load ptr, ptr %l92, !tbaa !29
  %t210 = call ptr @__olang_scope_or(ptr %v1, ptr %t209)
  %t211 = call ptr @__olang_scope_hold(ptr %t210)
  %t212 = ptrtoint ptr %t211 to i64
  %t214 = inttoptr i64 %t212 to ptr
  %t215 = load ptr, ptr %l92, !tbaa !29
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %t214, ptr %t215, i32 %t208)
  store i32 %t217, ptr %l95
  br label %bb67
bb67:
  %t218 = load ptr, ptr %l91, !tbaa !29
  %t219 = load i32, ptr %l95, !tbaa !23
  %t220 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %v1, ptr %t218, i32 %t219)
  store i1 %t220, ptr %l96
  br label %bb68
bb68:
  %t221 = load i1, ptr %l96, !tbaa !21
  store i1 %t221, ptr %l62, !tbaa !21
  br label %bb79
bb69:
  %t222 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t224 = trunc i64 18 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l1, !tbaa !23
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2enamed(ptr %v0, ptr %v1, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l101
  br label %bb73
bb73:
  %t232 = load i1, ptr %l101, !tbaa !21
  store i1 %t232, ptr %l62, !tbaa !21
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_60c82cde6ffdb5d3_c68082b86ff4ff17)
  unreachable
bb79:
  %t233 = load i1, ptr %l62, !tbaa !21
  store i1 %t233, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2elands(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l50 = alloca i32
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:refWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t13, ptr %t14, i32 %a1)
  store i32 %t16, ptr %l13
  br label %bb1
bb1:
  %t17 = load i32, ptr %l13, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:refWalk", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v2, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t31 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %t28, ptr %t29, i32 %t22)
  store i1 %t31, ptr %l18
  br label %bb2
bb2:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = call ptr @__olang_scope_or(ptr %v1, ptr %t36)
  %t38 = call ptr @__olang_scope_hold(ptr %t37)
  %t39 = ptrtoint ptr %t38 to i64
  %t41 = inttoptr i64 %t39 to ptr
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t41, ptr %t42, i32 %t35)
  store i32 %t44, ptr %l23
  br label %bb6
bb6:
  %t45 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t47 = trunc i64 19 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = call ptr @__olang_scope_or(ptr %v1, ptr %t56)
  %t58 = call ptr @__olang_scope_hold(ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load ptr, ptr %l29, !tbaa !29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t61, ptr %t62, i32 %t55)
  store i32 %t64, ptr %l32
  br label %bb10
bb10:
  %t65 = load ptr, ptr %l28, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v1, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l28, !tbaa !29
  %t72 = load i32, ptr %l32, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t70, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l34
  br label %bb11
bb11:
  %t74 = load i32, ptr %l34, !tbaa !23
  store i32 %t74, ptr %l4, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/types:refWalk", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t80 = load i64, ptr %l6, !tbaa !24
  store i64 %t80, ptr %l37, !tbaa !24
  %t81 = load ptr, ptr %l5, !tbaa !29
  store ptr %t81, ptr %l38, !tbaa !29
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = call ptr @__olang_scope_or(ptr %v2, ptr %t82)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t87 = inttoptr i64 %t85 to ptr
  %t88 = load ptr, ptr %l38, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %t87, ptr %t88)
  store i64 %t89, ptr %l40
  br label %bb13
bb13:
  %t90 = load i64, ptr %l37, !tbaa !24
  %t91 = load i64, ptr %l40, !tbaa !24
  %t92 = icmp slt i64 %t90, %t91
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb14, label %bb15
bb14:
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l5, !tbaa !29
  store ptr %t96, ptr %l43, !tbaa !29
  %t97 = load i64, ptr %l6, !tbaa !24
  %t98 = load ptr, ptr %l43, !tbaa !29
  %t99 = call ptr @__olang_scope_or(ptr %v2, ptr %t98)
  %t100 = call ptr @__olang_scope_hold(ptr %t99)
  %t101 = ptrtoint ptr %t100 to i64
  %t103 = inttoptr i64 %t101 to ptr
  %t104 = load ptr, ptr %l43, !tbaa !29
  %t106 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %t103, ptr %t104, i64 %t97)
  store i32 %t106, ptr %l46
  br label %bb17
bb17:
  %t107 = load i32, ptr %l46, !tbaa !23
  store i32 %t107, ptr %l7, !tbaa !23
  %t108 = load ptr, ptr %l2, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  %t109 = load i32, ptr %l7, !tbaa !23
  %t110 = load ptr, ptr %l47, !tbaa !29
  %t111 = call ptr @__olang_scope_or(ptr %v1, ptr %t110)
  %t112 = call ptr @__olang_scope_hold(ptr %t111)
  %t113 = ptrtoint ptr %t112 to i64
  %t115 = inttoptr i64 %t113 to ptr
  %t116 = load ptr, ptr %l47, !tbaa !29
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t115, ptr %t116, i32 %t109)
  store i32 %t118, ptr %l50
  br label %bb18
bb18:
  %t119 = load i32, ptr %l50, !range !{i32 0, i32 33}
  %t121 = trunc i64 19 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb19, label %bb20
bb19:
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l54, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  store ptr %t125, ptr %l55, !tbaa !29
  %t126 = load i32, ptr %l7, !tbaa !23
  %t127 = load ptr, ptr %l55, !tbaa !29
  %t128 = call ptr @__olang_scope_or(ptr %v1, ptr %t127)
  %t129 = call ptr @__olang_scope_hold(ptr %t128)
  %t130 = ptrtoint ptr %t129 to i64
  %t132 = inttoptr i64 %t130 to ptr
  %t133 = load ptr, ptr %l55, !tbaa !29
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t132, ptr %t133, i32 %t126)
  store i32 %t135, ptr %l58
  br label %bb21
bb20:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb21:
  %t136 = load ptr, ptr %l54, !tbaa !29
  %t137 = call ptr @__olang_scope_or(ptr %v1, ptr %t136)
  %t138 = call ptr @__olang_scope_hold(ptr %t137)
  %t139 = ptrtoint ptr %t138 to i64
  %t141 = inttoptr i64 %t139 to ptr
  %t142 = load ptr, ptr %l54, !tbaa !29
  %t143 = load i32, ptr %l58, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t141, ptr %t142, i32 %t143)
  store i32 %t144, ptr %l60
  br label %bb22
bb22:
  %t145 = load i32, ptr %l4, !tbaa !23
  %t146 = load i32, ptr %l60, !tbaa !23
  %t148 = icmp eq i32 %t146, %t145
  store i1 %t148, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t150 = load i1, ptr %l53, !tbaa !21
  br i1 %t150, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l6, !tbaa !24
  br label %bb12
bb28:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:refWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t13, ptr %t14, i32 %t7)
  store i1 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = call ptr @__olang_scope_or(ptr %v1, ptr %t24)
  %t26 = call ptr @__olang_scope_hold(ptr %t25)
  %t27 = ptrtoint ptr %t26 to i64
  %t29 = inttoptr i64 %t27 to ptr
  %t30 = load ptr, ptr %l13, !tbaa !29
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t29, ptr %t30, i32 %t23)
  store i32 %t32, ptr %l16
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l12, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l12, !tbaa !29
  %t40 = load i32, ptr %l16, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %t38, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l18
  br label %bb6
bb6:
  %t42 = load i32, ptr %l18, !range !{i32 0, i32 6}
  store i32 %t42, ptr %l3
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t45 = trunc i64 0 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l22, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l23, !tbaa !29
  %t50 = load i32, ptr %l1, !tbaa !23
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = call ptr @__olang_scope_or(ptr %v1, ptr %t51)
  %t53 = call ptr @__olang_scope_hold(ptr %t52)
  %t54 = ptrtoint ptr %t53 to i64
  %t56 = inttoptr i64 %t54 to ptr
  %t57 = load ptr, ptr %l23, !tbaa !29
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %t56, ptr %t57, i32 %t50)
  store i32 %t59, ptr %l26
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l22, !tbaa !29
  %t61 = load i32, ptr %l26, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2esome(ptr %v0, ptr %v1, ptr %v2, ptr %t60, i32 %t61)
  store i1 %t62, ptr %l27
  br label %bb11
bb11:
  %t63 = load i1, ptr %l27, !tbaa !21
  store i1 %t63, ptr %l19, !tbaa !21
  br label %bb29
bb12:
  %t64 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t66 = trunc i64 1 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l30, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  store ptr %t70, ptr %l31, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v1, ptr %t72)
  %t74 = call ptr @__olang_scope_hold(ptr %t73)
  %t75 = ptrtoint ptr %t74 to i64
  %t77 = inttoptr i64 %t75 to ptr
  %t78 = load ptr, ptr %l31, !tbaa !29
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %t77, ptr %t78, i32 %t71)
  store i32 %t80, ptr %l34
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l30, !tbaa !29
  %t82 = load i32, ptr %l34, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2esome(ptr %v0, ptr %v1, ptr %v2, ptr %t81, i32 %t82)
  store i1 %t83, ptr %l35
  br label %bb17
bb17:
  %t84 = load i1, ptr %l35, !tbaa !21
  store i1 %t84, ptr %l19, !tbaa !21
  br label %bb29
bb18:
  %t85 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t87 = trunc i64 4 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l38, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  store ptr %t91, ptr %l39, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  %t93 = load ptr, ptr %l39, !tbaa !29
  %t94 = call ptr @__olang_scope_or(ptr %v1, ptr %t93)
  %t95 = call ptr @__olang_scope_hold(ptr %t94)
  %t96 = ptrtoint ptr %t95 to i64
  %t98 = inttoptr i64 %t96 to ptr
  %t99 = load ptr, ptr %l39, !tbaa !29
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %t98, ptr %t99, i32 %t92)
  store i32 %t101, ptr %l42
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l38, !tbaa !29
  %t103 = load i32, ptr %l42, !tbaa !23
  %t104 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2ereaches(ptr %v0, ptr %v1, ptr %v2, ptr %t102, i32 %t103)
  store i1 %t104, ptr %l43
  br label %bb23
bb23:
  %t105 = load i1, ptr %l43, !tbaa !21
  store i1 %t105, ptr %l19, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_322c78cc145e2005_c2be1492b317e4d9)
  unreachable
bb29:
  %t106 = load i1, ptr %l19, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2ereaches(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i1
  %l81 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/types:refWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = call ptr @__olang_scope_hold(ptr %t9)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %t13, ptr %t14, i32 %t7)
  store i1 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/types:refWalk", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l14
  br label %bb4
bb4:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = call ptr @__olang_scope_or(ptr %v1, ptr %t30)
  %t32 = call ptr @__olang_scope_hold(ptr %t31)
  %t33 = ptrtoint ptr %t32 to i64
  %t35 = inttoptr i64 %t33 to ptr
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t35, ptr %t36, i32 %t29)
  store i32 %t38, ptr %l19
  br label %bb9
bb9:
  %t39 = load i32, ptr %l19, !range !{i32 0, i32 33}
  store i32 %t39, ptr %l3
  %t40 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t42 = trunc i64 21 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t47 = trunc i64 25 to i32
  %t48 = icmp eq i32 %t45, %t47
  store i1 %t48, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l22, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb15
bb14:
  %t51 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t53 = trunc i64 29 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l25, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb18
bb17:
  %t57 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t59 = trunc i64 0 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l28, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/types:refWalk", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t66, i32 %t67)
  br label %bb22
bb22:
  %t70 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t72 = trunc i64 20 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  store ptr %t76, ptr %l39, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = call ptr @__olang_scope_or(ptr %v1, ptr %t78)
  %t80 = call ptr @__olang_scope_hold(ptr %t79)
  %t81 = ptrtoint ptr %t80 to i64
  %t83 = inttoptr i64 %t81 to ptr
  %t84 = load ptr, ptr %l39, !tbaa !29
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t83, ptr %t84, i32 %t77)
  store i32 %t86, ptr %l42
  br label %bb26
bb26:
  %t87 = load ptr, ptr %l38, !tbaa !29
  %t88 = load i32, ptr %l42, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2elands(ptr %v0, ptr %v1, ptr %v2, ptr %t87, i32 %t88)
  store i1 %t89, ptr %l43
  br label %bb27
bb27:
  %t90 = load i1, ptr %l43, !tbaa !21
  br i1 %t90, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb32
bb29:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l45, !tbaa !29
  %t92 = load ptr, ptr %l2, !tbaa !29
  store ptr %t92, ptr %l46, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  %t94 = load ptr, ptr %l46, !tbaa !29
  %t95 = call ptr @__olang_scope_or(ptr %v1, ptr %t94)
  %t96 = call ptr @__olang_scope_hold(ptr %t95)
  %t97 = ptrtoint ptr %t96 to i64
  %t99 = inttoptr i64 %t97 to ptr
  %t100 = load ptr, ptr %l46, !tbaa !29
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t99, ptr %t100, i32 %t93)
  store i32 %t102, ptr %l49
  br label %bb30
bb30:
  %t103 = load ptr, ptr %l45, !tbaa !29
  %t104 = load i32, ptr %l49, !tbaa !23
  %t105 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2ereaches(ptr %v0, ptr %v1, ptr %v2, ptr %t103, i32 %t104)
  store i1 %t105, ptr %l50
  br label %bb31
bb31:
  %t106 = load i1, ptr %l50, !tbaa !21
  store i1 %t106, ptr %l44, !tbaa !21
  br label %bb32
bb32:
  %t107 = load i1, ptr %l44, !tbaa !21
  store i1 %t107, ptr %l35, !tbaa !21
  br label %bb63
bb33:
  %t108 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t110 = trunc i64 19 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l53, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l54, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t116 = load ptr, ptr %l54, !tbaa !29
  %t117 = call ptr @__olang_scope_or(ptr %v1, ptr %t116)
  %t118 = call ptr @__olang_scope_hold(ptr %t117)
  %t119 = ptrtoint ptr %t118 to i64
  %t121 = inttoptr i64 %t119 to ptr
  %t122 = load ptr, ptr %l54, !tbaa !29
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t121, ptr %t122, i32 %t115)
  store i32 %t124, ptr %l57
  br label %bb37
bb37:
  %t125 = load ptr, ptr %l53, !tbaa !29
  %t126 = load i32, ptr %l57, !tbaa !23
  %t127 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2ereaches(ptr %v0, ptr %v1, ptr %v2, ptr %t125, i32 %t126)
  store i1 %t127, ptr %l58
  br label %bb38
bb38:
  %t128 = load i1, ptr %l58, !tbaa !21
  store i1 %t128, ptr %l35, !tbaa !21
  br label %bb63
bb39:
  %t129 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t131 = trunc i64 22 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  %t134 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t136 = trunc i64 23 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l63, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  store ptr %t140, ptr %l64, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t142 = load ptr, ptr %l64, !tbaa !29
  %t143 = call ptr @__olang_scope_or(ptr %v1, ptr %t142)
  %t144 = call ptr @__olang_scope_hold(ptr %t143)
  %t145 = ptrtoint ptr %t144 to i64
  %t147 = inttoptr i64 %t145 to ptr
  %t148 = load ptr, ptr %l64, !tbaa !29
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t147, ptr %t148, i32 %t141)
  store i32 %t150, ptr %l67
  br label %bb45
bb45:
  %t151 = load ptr, ptr %l63, !tbaa !29
  %t152 = load i32, ptr %l67, !tbaa !23
  %t153 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2esome(ptr %v0, ptr %v1, ptr %v2, ptr %t151, i32 %t152)
  store i1 %t153, ptr %l68
  br label %bb46
bb46:
  %t154 = load i1, ptr %l68, !tbaa !21
  store i1 %t154, ptr %l35, !tbaa !21
  br label %bb63
bb47:
  %t155 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t157 = trunc i64 24 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l71, !tbaa !29
  %t161 = load ptr, ptr %l2, !tbaa !29
  store ptr %t161, ptr %l72, !tbaa !29
  %t162 = load i32, ptr %l1, !tbaa !23
  %t163 = load ptr, ptr %l72, !tbaa !29
  %t164 = call ptr @__olang_scope_or(ptr %v1, ptr %t163)
  %t165 = call ptr @__olang_scope_hold(ptr %t164)
  %t166 = ptrtoint ptr %t165 to i64
  %t168 = inttoptr i64 %t166 to ptr
  %t169 = load ptr, ptr %l72, !tbaa !29
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %t168, ptr %t169, i32 %t162)
  store i32 %t171, ptr %l75
  br label %bb51
bb51:
  %t172 = load ptr, ptr %l71, !tbaa !29
  %t173 = load i32, ptr %l75, !tbaa !23
  %t174 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2esome(ptr %v0, ptr %v1, ptr %v2, ptr %t172, i32 %t173)
  store i1 %t174, ptr %l76
  br label %bb52
bb52:
  %t175 = load i1, ptr %l76, !tbaa !21
  store i1 %t175, ptr %l35, !tbaa !21
  br label %bb63
bb53:
  %t176 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t178 = trunc i64 18 to i32
  %t179 = icmp eq i32 %t176, %t178
  br i1 %t179, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l1, !tbaa !23
  %t185 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l81
  br label %bb57
bb57:
  %t186 = load i1, ptr %l81, !tbaa !21
  store i1 %t186, ptr %l35, !tbaa !21
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_d452eab293f44e67_f9a4b0317fd8e9b)
  unreachable
bb63:
  %t187 = load i1, ptr %l35, !tbaa !21
  store i1 %t187, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftypes_2ehex2(ptr %v0, i8 %a0) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = zext i8 %a0 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %t9, i64 %t10)
  store { i64, ptr } %t11, ptr %l5
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a384a4bbbe0ebea1_23bacf7041e0bcc5)
  unreachable
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v0, { i64, ptr } %t12, i64 2, i8 48)
  store { i64, ptr } %t14, ptr %l7
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l8, !tbaa !24
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l9, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l8, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftypes_2eprimIndex(i64 %a0, i1 %a1) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp eq i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb21
bb4:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = icmp eq i64 %t5, 16
  br i1 %t7, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb21
bb8:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = icmp eq i64 %t9, 32
  br i1 %t11, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 2, ptr %l3, !tbaa !24
  br label %bb21
bb12:
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = icmp eq i64 %t13, 64
  br i1 %t15, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 3, ptr %l3, !tbaa !24
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_99e2f46192b0b63e_14d40f533c20e2f2)
  unreachable
bb21:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb22, label %bb23
bb22:
  store i64 0, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = add i64 3, %t23
  store i64 %t25, ptr %l16, !tbaa !24
  br i1 %a1, label %bb25, label %bb26
bb25:
  store i64 4, ptr %l18, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb27
bb27:
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = add i64 %t28, %t29
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftypes_2erunLess(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l39 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a3, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l26, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l39, !tbaa !27
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i64, ptr %t66, i64 %t63
  %t68 = load i64, ptr %t67, !tbaa !34
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = load i64, ptr %l2, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = add i64 %t70, %t71
  %t76 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  %t79 = load i64, ptr %t78, !tbaa !34
  %t82 = icmp ne i64 %t68, %t79
  br i1 %t82, label %bb11, label %bb12
bb11:
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l1, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i64, ptr %t92, i64 %t89
  %t94 = load i64, ptr %t93, !tbaa !34
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  %t96 = load i64, ptr %l2, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i64, ptr %t103, i64 %t100
  %t105 = load i64, ptr %t104, !tbaa !34
  %t108 = icmp slt i64 %t94, %t105
  store i1 %t108, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb7
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftypes_2esortRuns(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i1
  %l61 = alloca i1
  %l67 = alloca i64
  %l70 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i1
  %l92 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l26, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l26, !tbaa !24
  store i64 %t29, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l23, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l10, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = load i64, ptr %l10, !tbaa !24
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l3, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t65, %t72
  %t76 = load i64, ptr %l3, !tbaa !24
  %t81 = call i1 @compiler_2ftypes_2erunLess(ptr %v0, { i64, ptr } %t55, i64 %t64, i64 %t75, i64 %t76)
  store i1 %t81, ptr %l61
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb15
bb14:
  %t82 = load i1, ptr %l61, !tbaa !21
  store i1 %t82, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t83 = load i1, ptr %l47, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb16, label %bb17
bb16:
  br label %bb32
bb17:
  br label %bb18
bb18:
  store i64 0, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb19, label %bb20
bb19:
  %t94 = load i64, ptr %l13, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb24
bb21:
  %t98 = load i64, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l70, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb23
bb23:
  %t114 = load i64, ptr %l70, !tbaa !24
  store i64 %t114, ptr %l67, !tbaa !24
  br label %bb24
bb24:
  %t115 = load i64, ptr %l67, !tbaa !24
  store i64 %t115, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = sub i64 %t116, 1
  store i64 %t117, ptr %l79, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t119 = icmp slt i64 %t118, 2147483648
  %t120 = load i64, ptr %l15, !tbaa !24
  %t121 = icmp sge i64 %t120, 0
  %t124 = and i1 %t119, %t121
  store i1 %t124, ptr %l82, !tbaa !21
  br label %bb25
bb25:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t143, ptr %l92, !tbaa !27
  %t144 = load i64, ptr %l1, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t147 = sub i64 %t145, 1
  %t148 = load i64, ptr %l3, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t144, %t151
  %t155 = load i64, ptr %l16, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t160 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i64, ptr %t161, i64 %t158
  %t163 = load i64, ptr %t162, !tbaa !34
  %t165 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t165, ptr %l102, !tbaa !27
  %t166 = load i64, ptr %l1, !tbaa !24
  %t167 = load i64, ptr %l10, !tbaa !24
  %t168 = load i64, ptr %l3, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  %t175 = load i64, ptr %l16, !tbaa !24
  %t178 = add i64 %t174, %t175
  %t180 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i64, ptr %t181, i64 %t178
  %t183 = load i64, ptr %t182, !tbaa !34
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t185, ptr %l111, !tbaa !27
  %t186 = load i64, ptr %l1, !tbaa !24
  %t187 = load i64, ptr %l10, !tbaa !24
  %t188 = load i64, ptr %l3, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t194 = add i64 %t186, %t191
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = add i64 %t194, %t195
  %t202 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 %t198
  store i64 %t163, ptr %t204, !tbaa !34
  %t205 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t205, ptr %l120, !tbaa !27
  %t206 = load i64, ptr %l1, !tbaa !24
  %t207 = load i64, ptr %l10, !tbaa !24
  %t209 = sub i64 %t207, 1
  %t210 = load i64, ptr %l3, !tbaa !24
  %t213 = mul i64 %t209, %t210
  %t216 = add i64 %t206, %t213
  %t217 = load i64, ptr %l16, !tbaa !24
  %t220 = add i64 %t216, %t217
  %t224 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i64, ptr %t225, i64 %t220
  store i64 %t183, ptr %t226, !tbaa !34
  br label %bb29
bb29:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l15, !tbaa !24
  br label %bb25
bb30:
  %t232 = load i64, ptr %l10, !tbaa !24
  %t235 = sub i64 %t232, 1
  store i64 %t235, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  br label %bb11
bb32:
  br label %bb33
bb33:
  %t237 = load i64, ptr %l8, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l8, !tbaa !24
  br label %bb7
bb34:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftypes_2esymbolHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 48
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 57
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 97
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 102
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftypes_2esymbolHexValue(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i64
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp ule i8 %t1, 57
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = sub i8 %t5, 48
  %t9 = zext i8 %t7 to i64
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i8, ptr %l0, !tbaa !22
  %t13 = sub i8 %t11, 97
  %t15 = zext i8 %t13 to i64
  %t17 = add i64 %t15, 10
  store i64 %t17, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftypes_3aTable_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i1
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l44 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l45 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l46 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l51 = alloca i64
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l63 = alloca i64
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca i64
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l77 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l79 = alloca i64
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l94 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l96 = alloca i64
  %l98 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l100 = alloca i64
  %l102 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l104 = alloca i64
  %l106 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l108 = alloca i64
  %l110 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l112 = alloca i64
  %l114 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca i64
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca i64
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca i64
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca i64
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca i64
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca i64
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca i64
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca i64
  %l146 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l148 = alloca i64
  %l150 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l152 = alloca i64
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca i64
  %l158 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l160 = alloca i64
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca i64
  %l166 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l168 = alloca i64
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca i64
  %l174 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l176 = alloca i64
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l180 = alloca i64
  %l182 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l184 = alloca i64
  %l186 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l188 = alloca i64
  %l190 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l192 = alloca i64
  %l194 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l196 = alloca i64
  %l198 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l200 = alloca i64
  %l202 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l204 = alloca i64
  %l206 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l208 = alloca i64
  %l210 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l212 = alloca i64
  %l214 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l216 = alloca %"compiler/types:Table"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l49
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l50
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t7 = call ptr @__olang_scope_hold(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l51, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e4
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = call ptr @__olang_region_make(ptr %v1)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l51, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l51
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t14, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l53
  br label %bb5
bb5:
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e4
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l51
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = call ptr @__olang_region_or(ptr %t22, ptr null)
  %t24 = call ptr @__olang_region_home(ptr %t23)
  %t25 = icmp ne ptr %t24, null
  %t26 = select i1 %t25, ptr %t24, ptr null
  call void @__olang_region_settle_in(ptr %t19, ptr %t26)
  br label %bb7
bb7:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l5
  %t28 = call ptr @__olang_scope_hold(ptr %v1)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l55, !tbaa !24
  %t30 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e5
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = call ptr @__olang_region_make(ptr %v1)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l55, !tbaa !24
  br label %bb9
bb9:
  %t34 = load i64, ptr %l55
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %t35, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l57
  br label %bb10
bb10:
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e5
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load i64, ptr %l55
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t42 = load { i64, ptr }, ptr %t41
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = call ptr @__olang_region_or(ptr %t43, ptr null)
  %t45 = call ptr @__olang_region_home(ptr %t44)
  %t46 = icmp ne ptr %t45, null
  %t47 = select i1 %t46, ptr %t45, ptr null
  call void @__olang_region_settle_in(ptr %t40, ptr %t47)
  br label %bb12
bb12:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l6
  %t49 = call ptr @__olang_scope_hold(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l59, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e6
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = call ptr @__olang_region_make(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l59, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l59
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3_H67866d893b0e235fefa60e815142be68(ptr %t56)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t57, ptr %l61
  br label %bb15
bb15:
  %t58 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e6
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load i64, ptr %l59
  %t61 = inttoptr i64 %t60 to ptr
  %t62 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61, i32 0, i32 2
  %t63 = load { i64, ptr }, ptr %t62
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = call ptr @__olang_region_or(ptr %t64, ptr null)
  %t66 = call ptr @__olang_region_home(ptr %t65)
  %t67 = icmp ne ptr %t66, null
  %t68 = select i1 %t67, ptr %t66, ptr null
  %t69 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = call ptr @__olang_region_or(ptr %t71, ptr null)
  %t73 = call ptr @__olang_region_home(ptr %t72)
  %t74 = icmp ne ptr %t73, null
  %t75 = select i1 %t74, ptr %t73, ptr %t68
  %t76 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61, i32 0, i32 0
  %t77 = load { i64, ptr }, ptr %t76
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = call ptr @__olang_region_or(ptr %t78, ptr null)
  %t80 = call ptr @__olang_region_home(ptr %t79)
  %t81 = icmp ne ptr %t80, null
  %t82 = select i1 %t81, ptr %t80, ptr %t75
  call void @__olang_region_settle_in(ptr %t61, ptr %t82)
  br label %bb17
bb17:
  %t83 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t83, ptr %l7
  %t84 = call ptr @__olang_scope_hold(ptr %v1)
  %t85 = ptrtoint ptr %t84 to i64
  store i64 %t85, ptr %l63, !tbaa !24
  %t86 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e7
  br i1 %t86, label %bb18, label %bb19
bb18:
  %t88 = call ptr @__olang_region_make(ptr %v1)
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l63, !tbaa !24
  br label %bb19
bb19:
  %t90 = load i64, ptr %l63
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t91, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l65
  br label %bb20
bb20:
  %t93 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e7
  br i1 %t93, label %bb21, label %bb22
bb21:
  %t95 = load i64, ptr %l63
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = call ptr @__olang_region_home(ptr %t100)
  %t102 = icmp ne ptr %t101, null
  %t103 = select i1 %t102, ptr %t101, ptr null
  call void @__olang_region_settle_in(ptr %t96, ptr %t103)
  br label %bb22
bb22:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l8
  %t105 = call ptr @__olang_scope_hold(ptr %v1)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l67, !tbaa !24
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e8
  br i1 %t107, label %bb23, label %bb24
bb23:
  %t109 = call ptr @__olang_region_make(ptr %v1)
  %t110 = ptrtoint ptr %t109 to i64
  store i64 %t110, ptr %l67, !tbaa !24
  br label %bb24
bb24:
  %t111 = load i64, ptr %l67
  %t112 = inttoptr i64 %t111 to ptr
  %t113 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %t112, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %l69
  br label %bb25
bb25:
  %t114 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e8
  br i1 %t114, label %bb26, label %bb27
bb26:
  %t116 = load i64, ptr %l67
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = call ptr @__olang_region_or(ptr %t120, ptr null)
  %t122 = call ptr @__olang_region_home(ptr %t121)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  call void @__olang_region_settle_in(ptr %t117, ptr %t124)
  br label %bb27
bb27:
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %l9
  %t126 = call ptr @__olang_scope_hold(ptr %v1)
  %t127 = ptrtoint ptr %t126 to i64
  store i64 %t127, ptr %l71, !tbaa !24
  %t128 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e9
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = call ptr @__olang_region_make(ptr %v1)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l71, !tbaa !24
  br label %bb29
bb29:
  %t132 = load i64, ptr %l71
  %t133 = inttoptr i64 %t132 to ptr
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t133, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l73
  br label %bb30
bb30:
  %t135 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e9
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load i64, ptr %l71
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73, i32 0, i32 0
  %t140 = load { i64, ptr }, ptr %t139
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = call ptr @__olang_region_or(ptr %t141, ptr null)
  %t143 = call ptr @__olang_region_home(ptr %t142)
  %t144 = icmp ne ptr %t143, null
  %t145 = select i1 %t144, ptr %t143, ptr null
  call void @__olang_region_settle_in(ptr %t138, ptr %t145)
  br label %bb32
bb32:
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %l10
  %t147 = call ptr @__olang_scope_hold(ptr %v1)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l75, !tbaa !24
  %t149 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e10
  br i1 %t149, label %bb33, label %bb34
bb33:
  %t151 = call ptr @__olang_region_make(ptr %v1)
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l75, !tbaa !24
  br label %bb34
bb34:
  %t153 = load i64, ptr %l75
  %t154 = inttoptr i64 %t153 to ptr
  %t155 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t154)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t155, ptr %l77
  br label %bb35
bb35:
  %t156 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e10
  br i1 %t156, label %bb36, label %bb37
bb36:
  %t158 = load i64, ptr %l75
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = call ptr @__olang_region_or(ptr %t162, ptr null)
  %t164 = call ptr @__olang_region_home(ptr %t163)
  %t165 = icmp ne ptr %t164, null
  %t166 = select i1 %t165, ptr %t164, ptr null
  %t167 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = call ptr @__olang_region_or(ptr %t169, ptr null)
  %t171 = call ptr @__olang_region_home(ptr %t170)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr %t166
  %t174 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = call ptr @__olang_region_or(ptr %t176, ptr null)
  %t178 = call ptr @__olang_region_home(ptr %t177)
  %t179 = icmp ne ptr %t178, null
  %t180 = select i1 %t179, ptr %t178, ptr %t173
  call void @__olang_region_settle_in(ptr %t159, ptr %t180)
  br label %bb37
bb37:
  %t181 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t181, ptr %l11
  %t182 = call ptr @__olang_scope_hold(ptr %v1)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l79, !tbaa !24
  %t184 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e11
  br i1 %t184, label %bb38, label %bb39
bb38:
  %t186 = call ptr @__olang_region_make(ptr %v1)
  %t187 = ptrtoint ptr %t186 to i64
  store i64 %t187, ptr %l79, !tbaa !24
  br label %bb39
bb39:
  %t188 = load i64, ptr %l79
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t189, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t190, ptr %l81
  br label %bb40
bb40:
  %t191 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e11
  br i1 %t191, label %bb41, label %bb42
bb41:
  %t193 = load i64, ptr %l79
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81, i32 0, i32 0
  %t196 = load { i64, ptr }, ptr %t195
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = call ptr @__olang_region_or(ptr %t197, ptr null)
  %t199 = call ptr @__olang_region_home(ptr %t198)
  %t200 = icmp ne ptr %t199, null
  %t201 = select i1 %t200, ptr %t199, ptr null
  call void @__olang_region_settle_in(ptr %t194, ptr %t201)
  br label %bb42
bb42:
  %t202 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t202, ptr %l12
  %t203 = call ptr @__olang_scope_hold(ptr %v1)
  %t204 = ptrtoint ptr %t203 to i64
  store i64 %t204, ptr %l83, !tbaa !24
  %t205 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e12
  br i1 %t205, label %bb43, label %bb44
bb43:
  %t207 = call ptr @__olang_region_make(ptr %v1)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l83, !tbaa !24
  br label %bb44
bb44:
  %t209 = load i64, ptr %l83
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t210)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t211, ptr %l85
  br label %bb45
bb45:
  %t212 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e12
  br i1 %t212, label %bb46, label %bb47
bb46:
  %t214 = load i64, ptr %l83
  %t215 = inttoptr i64 %t214 to ptr
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85, i32 0, i32 2
  %t217 = load { i64, ptr }, ptr %t216
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = call ptr @__olang_region_or(ptr %t218, ptr null)
  %t220 = call ptr @__olang_region_home(ptr %t219)
  %t221 = icmp ne ptr %t220, null
  %t222 = select i1 %t221, ptr %t220, ptr null
  %t223 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85, i32 0, i32 1
  %t224 = load { i64, ptr }, ptr %t223
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = call ptr @__olang_region_home(ptr %t226)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr %t222
  %t230 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85, i32 0, i32 0
  %t231 = load { i64, ptr }, ptr %t230
  %t232 = extractvalue { i64, ptr } %t231, 1
  %t233 = call ptr @__olang_region_or(ptr %t232, ptr null)
  %t234 = call ptr @__olang_region_home(ptr %t233)
  %t235 = icmp ne ptr %t234, null
  %t236 = select i1 %t235, ptr %t234, ptr %t229
  call void @__olang_region_settle_in(ptr %t215, ptr %t236)
  br label %bb47
bb47:
  %t237 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t237, ptr %l13
  %t238 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l87
  br label %bb48
bb48:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l14
  %t240 = call ptr @__olang_scope_hold(ptr %v1)
  %t241 = ptrtoint ptr %t240 to i64
  store i64 %t241, ptr %l88, !tbaa !24
  %t242 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e14
  br i1 %t242, label %bb49, label %bb50
bb49:
  %t244 = call ptr @__olang_region_make(ptr %v1)
  %t245 = ptrtoint ptr %t244 to i64
  store i64 %t245, ptr %l88, !tbaa !24
  br label %bb50
bb50:
  %t246 = load i64, ptr %l88
  %t247 = inttoptr i64 %t246 to ptr
  %t248 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t247, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %l90
  br label %bb51
bb51:
  %t249 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e14
  br i1 %t249, label %bb52, label %bb53
bb52:
  %t251 = load i64, ptr %l88
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = call ptr @__olang_region_home(ptr %t256)
  %t258 = icmp ne ptr %t257, null
  %t259 = select i1 %t258, ptr %t257, ptr null
  call void @__olang_region_settle_in(ptr %t252, ptr %t259)
  br label %bb53
bb53:
  %t260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %l15
  %t261 = call ptr @__olang_scope_hold(ptr %v1)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l92, !tbaa !24
  %t263 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e15
  br i1 %t263, label %bb54, label %bb55
bb54:
  %t265 = call ptr @__olang_region_make(ptr %v1)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l92, !tbaa !24
  br label %bb55
bb55:
  %t267 = load i64, ptr %l92
  %t268 = inttoptr i64 %t267 to ptr
  %t269 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_Hdaf48aaf31e9845c659408ae38f7f59c(ptr %t268)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t269, ptr %l94
  br label %bb56
bb56:
  %t270 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e15
  br i1 %t270, label %bb57, label %bb58
bb57:
  %t272 = load i64, ptr %l92
  %t273 = inttoptr i64 %t272 to ptr
  %t274 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l94, i32 0, i32 2
  %t275 = load { i64, ptr }, ptr %t274
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = call ptr @__olang_region_or(ptr %t276, ptr null)
  %t278 = call ptr @__olang_region_home(ptr %t277)
  %t279 = icmp ne ptr %t278, null
  %t280 = select i1 %t279, ptr %t278, ptr null
  %t281 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l94, i32 0, i32 1
  %t282 = load { i64, ptr }, ptr %t281
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = call ptr @__olang_region_or(ptr %t283, ptr null)
  %t285 = call ptr @__olang_region_home(ptr %t284)
  %t286 = icmp ne ptr %t285, null
  %t287 = select i1 %t286, ptr %t285, ptr %t280
  %t288 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l94, i32 0, i32 0
  %t289 = load { i64, ptr }, ptr %t288
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = call ptr @__olang_region_or(ptr %t290, ptr null)
  %t292 = call ptr @__olang_region_home(ptr %t291)
  %t293 = icmp ne ptr %t292, null
  %t294 = select i1 %t293, ptr %t292, ptr %t287
  call void @__olang_region_settle_in(ptr %t273, ptr %t294)
  br label %bb58
bb58:
  %t295 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l94
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t295, ptr %l16
  %t296 = call ptr @__olang_scope_hold(ptr %v1)
  %t297 = ptrtoint ptr %t296 to i64
  store i64 %t297, ptr %l96, !tbaa !24
  %t298 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e16
  br i1 %t298, label %bb59, label %bb60
bb59:
  %t300 = call ptr @__olang_region_make(ptr %v1)
  %t301 = ptrtoint ptr %t300 to i64
  store i64 %t301, ptr %l96, !tbaa !24
  br label %bb60
bb60:
  %t302 = load i64, ptr %l96
  %t303 = inttoptr i64 %t302 to ptr
  %t304 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %t303)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t304, ptr %l98
  br label %bb61
bb61:
  %t305 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e16
  br i1 %t305, label %bb62, label %bb63
bb62:
  %t307 = load i64, ptr %l96
  %t308 = inttoptr i64 %t307 to ptr
  %t309 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 2
  %t310 = load { i64, ptr }, ptr %t309
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = call ptr @__olang_region_or(ptr %t311, ptr null)
  %t313 = call ptr @__olang_region_home(ptr %t312)
  %t314 = icmp ne ptr %t313, null
  %t315 = select i1 %t314, ptr %t313, ptr null
  %t316 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 1
  %t317 = load { i64, ptr }, ptr %t316
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = call ptr @__olang_region_or(ptr %t318, ptr null)
  %t320 = call ptr @__olang_region_home(ptr %t319)
  %t321 = icmp ne ptr %t320, null
  %t322 = select i1 %t321, ptr %t320, ptr %t315
  %t323 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = call ptr @__olang_region_or(ptr %t325, ptr null)
  %t327 = call ptr @__olang_region_home(ptr %t326)
  %t328 = icmp ne ptr %t327, null
  %t329 = select i1 %t328, ptr %t327, ptr %t322
  call void @__olang_region_settle_in(ptr %t308, ptr %t329)
  br label %bb63
bb63:
  %t330 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t330, ptr %l17
  %t331 = call ptr @__olang_scope_hold(ptr %v1)
  %t332 = ptrtoint ptr %t331 to i64
  store i64 %t332, ptr %l100, !tbaa !24
  %t333 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e17
  br i1 %t333, label %bb64, label %bb65
bb64:
  %t335 = call ptr @__olang_region_make(ptr %v1)
  %t336 = ptrtoint ptr %t335 to i64
  store i64 %t336, ptr %l100, !tbaa !24
  br label %bb65
bb65:
  %t337 = load i64, ptr %l100
  %t338 = inttoptr i64 %t337 to ptr
  %t339 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hbfe39cc2b71dbabe830cee24ccf915b6(ptr %t338)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t339, ptr %l102
  br label %bb66
bb66:
  %t340 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e17
  br i1 %t340, label %bb67, label %bb68
bb67:
  %t342 = load i64, ptr %l100
  %t343 = inttoptr i64 %t342 to ptr
  %t344 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102, i32 0, i32 2
  %t345 = load { i64, ptr }, ptr %t344
  %t346 = extractvalue { i64, ptr } %t345, 1
  %t347 = call ptr @__olang_region_or(ptr %t346, ptr null)
  %t348 = call ptr @__olang_region_home(ptr %t347)
  %t349 = icmp ne ptr %t348, null
  %t350 = select i1 %t349, ptr %t348, ptr null
  %t351 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102, i32 0, i32 1
  %t352 = load { i64, ptr }, ptr %t351
  %t353 = extractvalue { i64, ptr } %t352, 1
  %t354 = call ptr @__olang_region_or(ptr %t353, ptr null)
  %t355 = call ptr @__olang_region_home(ptr %t354)
  %t356 = icmp ne ptr %t355, null
  %t357 = select i1 %t356, ptr %t355, ptr %t350
  %t358 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102, i32 0, i32 0
  %t359 = load { i64, ptr }, ptr %t358
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = call ptr @__olang_region_or(ptr %t360, ptr null)
  %t362 = call ptr @__olang_region_home(ptr %t361)
  %t363 = icmp ne ptr %t362, null
  %t364 = select i1 %t363, ptr %t362, ptr %t357
  call void @__olang_region_settle_in(ptr %t343, ptr %t364)
  br label %bb68
bb68:
  %t365 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t365, ptr %l18
  %t366 = call ptr @__olang_scope_hold(ptr %v1)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l104, !tbaa !24
  %t368 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e18
  br i1 %t368, label %bb69, label %bb70
bb69:
  %t370 = call ptr @__olang_region_make(ptr %v1)
  %t371 = ptrtoint ptr %t370 to i64
  store i64 %t371, ptr %l104, !tbaa !24
  br label %bb70
bb70:
  %t372 = load i64, ptr %l104
  %t373 = inttoptr i64 %t372 to ptr
  %t374 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hb60d9b83e890412eba8d9d5191d2497d(ptr %t373)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t374, ptr %l106
  br label %bb71
bb71:
  %t375 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e18
  br i1 %t375, label %bb72, label %bb73
bb72:
  %t377 = load i64, ptr %l104
  %t378 = inttoptr i64 %t377 to ptr
  %t379 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l106, i32 0, i32 2
  %t380 = load { i64, ptr }, ptr %t379
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = call ptr @__olang_region_or(ptr %t381, ptr null)
  %t383 = call ptr @__olang_region_home(ptr %t382)
  %t384 = icmp ne ptr %t383, null
  %t385 = select i1 %t384, ptr %t383, ptr null
  %t386 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l106, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386
  %t388 = extractvalue { i64, ptr } %t387, 1
  %t389 = call ptr @__olang_region_or(ptr %t388, ptr null)
  %t390 = call ptr @__olang_region_home(ptr %t389)
  %t391 = icmp ne ptr %t390, null
  %t392 = select i1 %t391, ptr %t390, ptr %t385
  %t393 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l106, i32 0, i32 0
  %t394 = load { i64, ptr }, ptr %t393
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = call ptr @__olang_region_or(ptr %t395, ptr null)
  %t397 = call ptr @__olang_region_home(ptr %t396)
  %t398 = icmp ne ptr %t397, null
  %t399 = select i1 %t398, ptr %t397, ptr %t392
  call void @__olang_region_settle_in(ptr %t378, ptr %t399)
  br label %bb73
bb73:
  %t400 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l106
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t400, ptr %l19
  %t401 = call ptr @__olang_scope_hold(ptr %v1)
  %t402 = ptrtoint ptr %t401 to i64
  store i64 %t402, ptr %l108, !tbaa !24
  %t403 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e19
  br i1 %t403, label %bb74, label %bb75
bb74:
  %t405 = call ptr @__olang_region_make(ptr %v1)
  %t406 = ptrtoint ptr %t405 to i64
  store i64 %t406, ptr %l108, !tbaa !24
  br label %bb75
bb75:
  %t407 = load i64, ptr %l108
  %t408 = inttoptr i64 %t407 to ptr
  %t409 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hc9d5028d9efd264605c80efeddc4ccf9(ptr %t408)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t409, ptr %l110
  br label %bb76
bb76:
  %t410 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e19
  br i1 %t410, label %bb77, label %bb78
bb77:
  %t412 = load i64, ptr %l108
  %t413 = inttoptr i64 %t412 to ptr
  %t414 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 2
  %t415 = load { i64, ptr }, ptr %t414
  %t416 = extractvalue { i64, ptr } %t415, 1
  %t417 = call ptr @__olang_region_or(ptr %t416, ptr null)
  %t418 = call ptr @__olang_region_home(ptr %t417)
  %t419 = icmp ne ptr %t418, null
  %t420 = select i1 %t419, ptr %t418, ptr null
  %t421 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 1
  %t422 = load { i64, ptr }, ptr %t421
  %t423 = extractvalue { i64, ptr } %t422, 1
  %t424 = call ptr @__olang_region_or(ptr %t423, ptr null)
  %t425 = call ptr @__olang_region_home(ptr %t424)
  %t426 = icmp ne ptr %t425, null
  %t427 = select i1 %t426, ptr %t425, ptr %t420
  %t428 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110, i32 0, i32 0
  %t429 = load { i64, ptr }, ptr %t428
  %t430 = extractvalue { i64, ptr } %t429, 1
  %t431 = call ptr @__olang_region_or(ptr %t430, ptr null)
  %t432 = call ptr @__olang_region_home(ptr %t431)
  %t433 = icmp ne ptr %t432, null
  %t434 = select i1 %t433, ptr %t432, ptr %t427
  call void @__olang_region_settle_in(ptr %t413, ptr %t434)
  br label %bb78
bb78:
  %t435 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l110
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t435, ptr %l20
  %t436 = call ptr @__olang_scope_hold(ptr %v1)
  %t437 = ptrtoint ptr %t436 to i64
  store i64 %t437, ptr %l112, !tbaa !24
  %t438 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e20
  br i1 %t438, label %bb79, label %bb80
bb79:
  %t440 = call ptr @__olang_region_make(ptr %v1)
  %t441 = ptrtoint ptr %t440 to i64
  store i64 %t441, ptr %l112, !tbaa !24
  br label %bb80
bb80:
  %t442 = load i64, ptr %l112
  %t443 = inttoptr i64 %t442 to ptr
  %t444 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t443, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t444, ptr %l114
  br label %bb81
bb81:
  %t445 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e20
  br i1 %t445, label %bb82, label %bb83
bb82:
  %t447 = load i64, ptr %l112
  %t448 = inttoptr i64 %t447 to ptr
  %t449 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l114, i32 0, i32 0
  %t450 = load { i64, ptr }, ptr %t449
  %t451 = extractvalue { i64, ptr } %t450, 1
  %t452 = call ptr @__olang_region_or(ptr %t451, ptr null)
  %t453 = call ptr @__olang_region_home(ptr %t452)
  %t454 = icmp ne ptr %t453, null
  %t455 = select i1 %t454, ptr %t453, ptr null
  call void @__olang_region_settle_in(ptr %t448, ptr %t455)
  br label %bb83
bb83:
  %t456 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l114
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t456, ptr %l21
  %t457 = call ptr @__olang_scope_hold(ptr %v1)
  %t458 = ptrtoint ptr %t457 to i64
  store i64 %t458, ptr %l116, !tbaa !24
  %t459 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e21
  br i1 %t459, label %bb84, label %bb85
bb84:
  %t461 = call ptr @__olang_region_make(ptr %v1)
  %t462 = ptrtoint ptr %t461 to i64
  store i64 %t462, ptr %l116, !tbaa !24
  br label %bb85
bb85:
  %t463 = load i64, ptr %l116
  %t464 = inttoptr i64 %t463 to ptr
  %t465 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t464, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t465, ptr %l118
  br label %bb86
bb86:
  %t466 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e21
  br i1 %t466, label %bb87, label %bb88
bb87:
  %t468 = load i64, ptr %l116
  %t469 = inttoptr i64 %t468 to ptr
  %t470 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118, i32 0, i32 0
  %t471 = load { i64, ptr }, ptr %t470
  %t472 = extractvalue { i64, ptr } %t471, 1
  %t473 = call ptr @__olang_region_or(ptr %t472, ptr null)
  %t474 = call ptr @__olang_region_home(ptr %t473)
  %t475 = icmp ne ptr %t474, null
  %t476 = select i1 %t475, ptr %t474, ptr null
  call void @__olang_region_settle_in(ptr %t469, ptr %t476)
  br label %bb88
bb88:
  %t477 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t477, ptr %l22
  %t478 = call ptr @__olang_scope_hold(ptr %v1)
  %t479 = ptrtoint ptr %t478 to i64
  store i64 %t479, ptr %l120, !tbaa !24
  %t480 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e22
  br i1 %t480, label %bb89, label %bb90
bb89:
  %t482 = call ptr @__olang_region_make(ptr %v1)
  %t483 = ptrtoint ptr %t482 to i64
  store i64 %t483, ptr %l120, !tbaa !24
  br label %bb90
bb90:
  %t484 = load i64, ptr %l120
  %t485 = inttoptr i64 %t484 to ptr
  %t486 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t485, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t486, ptr %l122
  br label %bb91
bb91:
  %t487 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e22
  br i1 %t487, label %bb92, label %bb93
bb92:
  %t489 = load i64, ptr %l120
  %t490 = inttoptr i64 %t489 to ptr
  %t491 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122, i32 0, i32 0
  %t492 = load { i64, ptr }, ptr %t491
  %t493 = extractvalue { i64, ptr } %t492, 1
  %t494 = call ptr @__olang_region_or(ptr %t493, ptr null)
  %t495 = call ptr @__olang_region_home(ptr %t494)
  %t496 = icmp ne ptr %t495, null
  %t497 = select i1 %t496, ptr %t495, ptr null
  call void @__olang_region_settle_in(ptr %t490, ptr %t497)
  br label %bb93
bb93:
  %t498 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %l23
  %t499 = call ptr @__olang_scope_hold(ptr %v1)
  %t500 = ptrtoint ptr %t499 to i64
  store i64 %t500, ptr %l124, !tbaa !24
  %t501 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e23
  br i1 %t501, label %bb94, label %bb95
bb94:
  %t503 = call ptr @__olang_region_make(ptr %v1)
  %t504 = ptrtoint ptr %t503 to i64
  store i64 %t504, ptr %l124, !tbaa !24
  br label %bb95
bb95:
  %t505 = load i64, ptr %l124
  %t506 = inttoptr i64 %t505 to ptr
  %t507 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t506, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t507, ptr %l126
  br label %bb96
bb96:
  %t508 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e23
  br i1 %t508, label %bb97, label %bb98
bb97:
  %t510 = load i64, ptr %l124
  %t511 = inttoptr i64 %t510 to ptr
  %t512 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126, i32 0, i32 0
  %t513 = load { i64, ptr }, ptr %t512
  %t514 = extractvalue { i64, ptr } %t513, 1
  %t515 = call ptr @__olang_region_or(ptr %t514, ptr null)
  %t516 = call ptr @__olang_region_home(ptr %t515)
  %t517 = icmp ne ptr %t516, null
  %t518 = select i1 %t517, ptr %t516, ptr null
  call void @__olang_region_settle_in(ptr %t511, ptr %t518)
  br label %bb98
bb98:
  %t519 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t519, ptr %l24
  %t520 = call ptr @__olang_scope_hold(ptr %v1)
  %t521 = ptrtoint ptr %t520 to i64
  store i64 %t521, ptr %l128, !tbaa !24
  %t522 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e24
  br i1 %t522, label %bb99, label %bb100
bb99:
  %t524 = call ptr @__olang_region_make(ptr %v1)
  %t525 = ptrtoint ptr %t524 to i64
  store i64 %t525, ptr %l128, !tbaa !24
  br label %bb100
bb100:
  %t526 = load i64, ptr %l128
  %t527 = inttoptr i64 %t526 to ptr
  %t528 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t527, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t528, ptr %l130
  br label %bb101
bb101:
  %t529 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e24
  br i1 %t529, label %bb102, label %bb103
bb102:
  %t531 = load i64, ptr %l128
  %t532 = inttoptr i64 %t531 to ptr
  %t533 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130, i32 0, i32 0
  %t534 = load { i64, ptr }, ptr %t533
  %t535 = extractvalue { i64, ptr } %t534, 1
  %t536 = call ptr @__olang_region_or(ptr %t535, ptr null)
  %t537 = call ptr @__olang_region_home(ptr %t536)
  %t538 = icmp ne ptr %t537, null
  %t539 = select i1 %t538, ptr %t537, ptr null
  call void @__olang_region_settle_in(ptr %t532, ptr %t539)
  br label %bb103
bb103:
  %t540 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t540, ptr %l25
  %t541 = call ptr @__olang_scope_hold(ptr %v1)
  %t542 = ptrtoint ptr %t541 to i64
  store i64 %t542, ptr %l132, !tbaa !24
  %t543 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e25
  br i1 %t543, label %bb104, label %bb105
bb104:
  %t545 = call ptr @__olang_region_make(ptr %v1)
  %t546 = ptrtoint ptr %t545 to i64
  store i64 %t546, ptr %l132, !tbaa !24
  br label %bb105
bb105:
  %t547 = load i64, ptr %l132
  %t548 = inttoptr i64 %t547 to ptr
  %t549 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t548, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t549, ptr %l134
  br label %bb106
bb106:
  %t550 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e25
  br i1 %t550, label %bb107, label %bb108
bb107:
  %t552 = load i64, ptr %l132
  %t553 = inttoptr i64 %t552 to ptr
  %t554 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134, i32 0, i32 0
  %t555 = load { i64, ptr }, ptr %t554
  %t556 = extractvalue { i64, ptr } %t555, 1
  %t557 = call ptr @__olang_region_or(ptr %t556, ptr null)
  %t558 = call ptr @__olang_region_home(ptr %t557)
  %t559 = icmp ne ptr %t558, null
  %t560 = select i1 %t559, ptr %t558, ptr null
  call void @__olang_region_settle_in(ptr %t553, ptr %t560)
  br label %bb108
bb108:
  %t561 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t561, ptr %l26
  %t562 = call ptr @__olang_scope_hold(ptr %v1)
  %t563 = ptrtoint ptr %t562 to i64
  store i64 %t563, ptr %l136, !tbaa !24
  %t564 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e26
  br i1 %t564, label %bb109, label %bb110
bb109:
  %t566 = call ptr @__olang_region_make(ptr %v1)
  %t567 = ptrtoint ptr %t566 to i64
  store i64 %t567, ptr %l136, !tbaa !24
  br label %bb110
bb110:
  %t568 = load i64, ptr %l136
  %t569 = inttoptr i64 %t568 to ptr
  %t570 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t569, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t570, ptr %l138
  br label %bb111
bb111:
  %t571 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e26
  br i1 %t571, label %bb112, label %bb113
bb112:
  %t573 = load i64, ptr %l136
  %t574 = inttoptr i64 %t573 to ptr
  %t575 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138, i32 0, i32 0
  %t576 = load { i64, ptr }, ptr %t575
  %t577 = extractvalue { i64, ptr } %t576, 1
  %t578 = call ptr @__olang_region_or(ptr %t577, ptr null)
  %t579 = call ptr @__olang_region_home(ptr %t578)
  %t580 = icmp ne ptr %t579, null
  %t581 = select i1 %t580, ptr %t579, ptr null
  call void @__olang_region_settle_in(ptr %t574, ptr %t581)
  br label %bb113
bb113:
  %t582 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t582, ptr %l27
  %t583 = call ptr @__olang_scope_hold(ptr %v1)
  %t584 = ptrtoint ptr %t583 to i64
  store i64 %t584, ptr %l140, !tbaa !24
  %t585 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e27
  br i1 %t585, label %bb114, label %bb115
bb114:
  %t587 = call ptr @__olang_region_make(ptr %v1)
  %t588 = ptrtoint ptr %t587 to i64
  store i64 %t588, ptr %l140, !tbaa !24
  br label %bb115
bb115:
  %t589 = load i64, ptr %l140
  %t590 = inttoptr i64 %t589 to ptr
  %t591 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t590, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t591, ptr %l142
  br label %bb116
bb116:
  %t592 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e27
  br i1 %t592, label %bb117, label %bb118
bb117:
  %t594 = load i64, ptr %l140
  %t595 = inttoptr i64 %t594 to ptr
  %t596 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142, i32 0, i32 0
  %t597 = load { i64, ptr }, ptr %t596
  %t598 = extractvalue { i64, ptr } %t597, 1
  %t599 = call ptr @__olang_region_or(ptr %t598, ptr null)
  %t600 = call ptr @__olang_region_home(ptr %t599)
  %t601 = icmp ne ptr %t600, null
  %t602 = select i1 %t601, ptr %t600, ptr null
  call void @__olang_region_settle_in(ptr %t595, ptr %t602)
  br label %bb118
bb118:
  %t603 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t603, ptr %l28
  %t604 = call ptr @__olang_scope_hold(ptr %v1)
  %t605 = ptrtoint ptr %t604 to i64
  store i64 %t605, ptr %l144, !tbaa !24
  %t606 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e28
  br i1 %t606, label %bb119, label %bb120
bb119:
  %t608 = call ptr @__olang_region_make(ptr %v1)
  %t609 = ptrtoint ptr %t608 to i64
  store i64 %t609, ptr %l144, !tbaa !24
  br label %bb120
bb120:
  %t610 = load i64, ptr %l144
  %t611 = inttoptr i64 %t610 to ptr
  %t612 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %t611, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t612, ptr %l146
  br label %bb121
bb121:
  %t613 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e28
  br i1 %t613, label %bb122, label %bb123
bb122:
  %t615 = load i64, ptr %l144
  %t616 = inttoptr i64 %t615 to ptr
  %t617 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l146, i32 0, i32 0
  %t618 = load { i64, ptr }, ptr %t617
  %t619 = extractvalue { i64, ptr } %t618, 1
  %t620 = call ptr @__olang_region_or(ptr %t619, ptr null)
  %t621 = call ptr @__olang_region_home(ptr %t620)
  %t622 = icmp ne ptr %t621, null
  %t623 = select i1 %t622, ptr %t621, ptr null
  call void @__olang_region_settle_in(ptr %t616, ptr %t623)
  br label %bb123
bb123:
  %t624 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l146
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t624, ptr %l29
  %t625 = call ptr @__olang_scope_hold(ptr %v1)
  %t626 = ptrtoint ptr %t625 to i64
  store i64 %t626, ptr %l148, !tbaa !24
  %t627 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e29
  br i1 %t627, label %bb124, label %bb125
bb124:
  %t629 = call ptr @__olang_region_make(ptr %v1)
  %t630 = ptrtoint ptr %t629 to i64
  store i64 %t630, ptr %l148, !tbaa !24
  br label %bb125
bb125:
  %t631 = load i64, ptr %l148
  %t632 = inttoptr i64 %t631 to ptr
  %t633 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %t632)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t633, ptr %l150
  br label %bb126
bb126:
  %t634 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e29
  br i1 %t634, label %bb127, label %bb128
bb127:
  %t636 = load i64, ptr %l148
  %t637 = inttoptr i64 %t636 to ptr
  %t638 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150, i32 0, i32 2
  %t639 = load { i64, ptr }, ptr %t638
  %t640 = extractvalue { i64, ptr } %t639, 1
  %t641 = call ptr @__olang_region_or(ptr %t640, ptr null)
  %t642 = call ptr @__olang_region_home(ptr %t641)
  %t643 = icmp ne ptr %t642, null
  %t644 = select i1 %t643, ptr %t642, ptr null
  %t645 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150, i32 0, i32 1
  %t646 = load { i64, ptr }, ptr %t645
  %t647 = extractvalue { i64, ptr } %t646, 1
  %t648 = call ptr @__olang_region_or(ptr %t647, ptr null)
  %t649 = call ptr @__olang_region_home(ptr %t648)
  %t650 = icmp ne ptr %t649, null
  %t651 = select i1 %t650, ptr %t649, ptr %t644
  %t652 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150, i32 0, i32 0
  %t653 = load { i64, ptr }, ptr %t652
  %t654 = extractvalue { i64, ptr } %t653, 1
  %t655 = call ptr @__olang_region_or(ptr %t654, ptr null)
  %t656 = call ptr @__olang_region_home(ptr %t655)
  %t657 = icmp ne ptr %t656, null
  %t658 = select i1 %t657, ptr %t656, ptr %t651
  call void @__olang_region_settle_in(ptr %t637, ptr %t658)
  br label %bb128
bb128:
  %t659 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l150
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t659, ptr %l30
  %t660 = call ptr @__olang_scope_hold(ptr %v1)
  %t661 = ptrtoint ptr %t660 to i64
  store i64 %t661, ptr %l152, !tbaa !24
  %t662 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e30
  br i1 %t662, label %bb129, label %bb130
bb129:
  %t664 = call ptr @__olang_region_make(ptr %v1)
  %t665 = ptrtoint ptr %t664 to i64
  store i64 %t665, ptr %l152, !tbaa !24
  br label %bb130
bb130:
  %t666 = load i64, ptr %l152
  %t667 = inttoptr i64 %t666 to ptr
  %t668 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %t667, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t668, ptr %l154
  br label %bb131
bb131:
  %t669 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e30
  br i1 %t669, label %bb132, label %bb133
bb132:
  %t671 = load i64, ptr %l152
  %t672 = inttoptr i64 %t671 to ptr
  %t673 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154, i32 0, i32 0
  %t674 = load { i64, ptr }, ptr %t673
  %t675 = extractvalue { i64, ptr } %t674, 1
  %t676 = call ptr @__olang_region_or(ptr %t675, ptr null)
  %t677 = call ptr @__olang_region_home(ptr %t676)
  %t678 = icmp ne ptr %t677, null
  %t679 = select i1 %t678, ptr %t677, ptr null
  call void @__olang_region_settle_in(ptr %t672, ptr %t679)
  br label %bb133
bb133:
  %t680 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t680, ptr %l31
  %t681 = call ptr @__olang_scope_hold(ptr %v1)
  %t682 = ptrtoint ptr %t681 to i64
  store i64 %t682, ptr %l156, !tbaa !24
  %t683 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e31
  br i1 %t683, label %bb134, label %bb135
bb134:
  %t685 = call ptr @__olang_region_make(ptr %v1)
  %t686 = ptrtoint ptr %t685 to i64
  store i64 %t686, ptr %l156, !tbaa !24
  br label %bb135
bb135:
  %t687 = load i64, ptr %l156
  %t688 = inttoptr i64 %t687 to ptr
  %t689 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %t688)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t689, ptr %l158
  br label %bb136
bb136:
  %t690 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e31
  br i1 %t690, label %bb137, label %bb138
bb137:
  %t692 = load i64, ptr %l156
  %t693 = inttoptr i64 %t692 to ptr
  %t694 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158, i32 0, i32 2
  %t695 = load { i64, ptr }, ptr %t694
  %t696 = extractvalue { i64, ptr } %t695, 1
  %t697 = call ptr @__olang_region_or(ptr %t696, ptr null)
  %t698 = call ptr @__olang_region_home(ptr %t697)
  %t699 = icmp ne ptr %t698, null
  %t700 = select i1 %t699, ptr %t698, ptr null
  %t701 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158, i32 0, i32 1
  %t702 = load { i64, ptr }, ptr %t701
  %t703 = extractvalue { i64, ptr } %t702, 1
  %t704 = call ptr @__olang_region_or(ptr %t703, ptr null)
  %t705 = call ptr @__olang_region_home(ptr %t704)
  %t706 = icmp ne ptr %t705, null
  %t707 = select i1 %t706, ptr %t705, ptr %t700
  %t708 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158, i32 0, i32 0
  %t709 = load { i64, ptr }, ptr %t708
  %t710 = extractvalue { i64, ptr } %t709, 1
  %t711 = call ptr @__olang_region_or(ptr %t710, ptr null)
  %t712 = call ptr @__olang_region_home(ptr %t711)
  %t713 = icmp ne ptr %t712, null
  %t714 = select i1 %t713, ptr %t712, ptr %t707
  call void @__olang_region_settle_in(ptr %t693, ptr %t714)
  br label %bb138
bb138:
  %t715 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l158
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t715, ptr %l32
  %t716 = call ptr @__olang_scope_hold(ptr %v1)
  %t717 = ptrtoint ptr %t716 to i64
  store i64 %t717, ptr %l160, !tbaa !24
  %t718 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e32
  br i1 %t718, label %bb139, label %bb140
bb139:
  %t720 = call ptr @__olang_region_make(ptr %v1)
  %t721 = ptrtoint ptr %t720 to i64
  store i64 %t721, ptr %l160, !tbaa !24
  br label %bb140
bb140:
  %t722 = load i64, ptr %l160
  %t723 = inttoptr i64 %t722 to ptr
  %t724 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %t723, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t724, ptr %l162
  br label %bb141
bb141:
  %t725 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e32
  br i1 %t725, label %bb142, label %bb143
bb142:
  %t727 = load i64, ptr %l160
  %t728 = inttoptr i64 %t727 to ptr
  %t729 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162, i32 0, i32 0
  %t730 = load { i64, ptr }, ptr %t729
  %t731 = extractvalue { i64, ptr } %t730, 1
  %t732 = call ptr @__olang_region_or(ptr %t731, ptr null)
  %t733 = call ptr @__olang_region_home(ptr %t732)
  %t734 = icmp ne ptr %t733, null
  %t735 = select i1 %t734, ptr %t733, ptr null
  call void @__olang_region_settle_in(ptr %t728, ptr %t735)
  br label %bb143
bb143:
  %t736 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t736, ptr %l33
  %t737 = call ptr @__olang_scope_hold(ptr %v1)
  %t738 = ptrtoint ptr %t737 to i64
  store i64 %t738, ptr %l164, !tbaa !24
  %t739 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e33
  br i1 %t739, label %bb144, label %bb145
bb144:
  %t741 = call ptr @__olang_region_make(ptr %v1)
  %t742 = ptrtoint ptr %t741 to i64
  store i64 %t742, ptr %l164, !tbaa !24
  br label %bb145
bb145:
  %t743 = load i64, ptr %l164
  %t744 = inttoptr i64 %t743 to ptr
  %t745 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t744, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t745, ptr %l166
  br label %bb146
bb146:
  %t746 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e33
  br i1 %t746, label %bb147, label %bb148
bb147:
  %t748 = load i64, ptr %l164
  %t749 = inttoptr i64 %t748 to ptr
  %t750 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l166, i32 0, i32 0
  %t751 = load { i64, ptr }, ptr %t750
  %t752 = extractvalue { i64, ptr } %t751, 1
  %t753 = call ptr @__olang_region_or(ptr %t752, ptr null)
  %t754 = call ptr @__olang_region_home(ptr %t753)
  %t755 = icmp ne ptr %t754, null
  %t756 = select i1 %t755, ptr %t754, ptr null
  call void @__olang_region_settle_in(ptr %t749, ptr %t756)
  br label %bb148
bb148:
  %t757 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l166
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t757, ptr %l34
  %t758 = call ptr @__olang_scope_hold(ptr %v1)
  %t759 = ptrtoint ptr %t758 to i64
  store i64 %t759, ptr %l168, !tbaa !24
  %t760 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e34
  br i1 %t760, label %bb149, label %bb150
bb149:
  %t762 = call ptr @__olang_region_make(ptr %v1)
  %t763 = ptrtoint ptr %t762 to i64
  store i64 %t763, ptr %l168, !tbaa !24
  br label %bb150
bb150:
  %t764 = load i64, ptr %l168
  %t765 = inttoptr i64 %t764 to ptr
  %t766 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %t765, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t766, ptr %l170
  br label %bb151
bb151:
  %t767 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e34
  br i1 %t767, label %bb152, label %bb153
bb152:
  %t769 = load i64, ptr %l168
  %t770 = inttoptr i64 %t769 to ptr
  %t771 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170, i32 0, i32 0
  %t772 = load { i64, ptr }, ptr %t771
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = call ptr @__olang_region_or(ptr %t773, ptr null)
  %t775 = call ptr @__olang_region_home(ptr %t774)
  %t776 = icmp ne ptr %t775, null
  %t777 = select i1 %t776, ptr %t775, ptr null
  call void @__olang_region_settle_in(ptr %t770, ptr %t777)
  br label %bb153
bb153:
  %t778 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t778, ptr %l35
  %t779 = call ptr @__olang_scope_hold(ptr %v1)
  %t780 = ptrtoint ptr %t779 to i64
  store i64 %t780, ptr %l172, !tbaa !24
  %t781 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e35
  br i1 %t781, label %bb154, label %bb155
bb154:
  %t783 = call ptr @__olang_region_make(ptr %v1)
  %t784 = ptrtoint ptr %t783 to i64
  store i64 %t784, ptr %l172, !tbaa !24
  br label %bb155
bb155:
  %t785 = load i64, ptr %l172
  %t786 = inttoptr i64 %t785 to ptr
  %t787 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %t786)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t787, ptr %l174
  br label %bb156
bb156:
  %t788 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e35
  br i1 %t788, label %bb157, label %bb158
bb157:
  %t790 = load i64, ptr %l172
  %t791 = inttoptr i64 %t790 to ptr
  %t792 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174, i32 0, i32 2
  %t793 = load { i64, ptr }, ptr %t792
  %t794 = extractvalue { i64, ptr } %t793, 1
  %t795 = call ptr @__olang_region_or(ptr %t794, ptr null)
  %t796 = call ptr @__olang_region_home(ptr %t795)
  %t797 = icmp ne ptr %t796, null
  %t798 = select i1 %t797, ptr %t796, ptr null
  %t799 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174, i32 0, i32 1
  %t800 = load { i64, ptr }, ptr %t799
  %t801 = extractvalue { i64, ptr } %t800, 1
  %t802 = call ptr @__olang_region_or(ptr %t801, ptr null)
  %t803 = call ptr @__olang_region_home(ptr %t802)
  %t804 = icmp ne ptr %t803, null
  %t805 = select i1 %t804, ptr %t803, ptr %t798
  %t806 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174, i32 0, i32 0
  %t807 = load { i64, ptr }, ptr %t806
  %t808 = extractvalue { i64, ptr } %t807, 1
  %t809 = call ptr @__olang_region_or(ptr %t808, ptr null)
  %t810 = call ptr @__olang_region_home(ptr %t809)
  %t811 = icmp ne ptr %t810, null
  %t812 = select i1 %t811, ptr %t810, ptr %t805
  call void @__olang_region_settle_in(ptr %t791, ptr %t812)
  br label %bb158
bb158:
  %t813 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l174
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t813, ptr %l36
  %t814 = call ptr @__olang_scope_hold(ptr %v1)
  %t815 = ptrtoint ptr %t814 to i64
  store i64 %t815, ptr %l176, !tbaa !24
  %t816 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e36
  br i1 %t816, label %bb159, label %bb160
bb159:
  %t818 = call ptr @__olang_region_make(ptr %v1)
  %t819 = ptrtoint ptr %t818 to i64
  store i64 %t819, ptr %l176, !tbaa !24
  br label %bb160
bb160:
  %t820 = load i64, ptr %l176
  %t821 = inttoptr i64 %t820 to ptr
  %t822 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %t821, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t822, ptr %l178
  br label %bb161
bb161:
  %t823 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e36
  br i1 %t823, label %bb162, label %bb163
bb162:
  %t825 = load i64, ptr %l176
  %t826 = inttoptr i64 %t825 to ptr
  %t827 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178, i32 0, i32 0
  %t828 = load { i64, ptr }, ptr %t827
  %t829 = extractvalue { i64, ptr } %t828, 1
  %t830 = call ptr @__olang_region_or(ptr %t829, ptr null)
  %t831 = call ptr @__olang_region_home(ptr %t830)
  %t832 = icmp ne ptr %t831, null
  %t833 = select i1 %t832, ptr %t831, ptr null
  call void @__olang_region_settle_in(ptr %t826, ptr %t833)
  br label %bb163
bb163:
  %t834 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t834, ptr %l37
  store i1 false, ptr %l38, !tbaa !21
  %t835 = call ptr @__olang_scope_hold(ptr %v1)
  %t836 = ptrtoint ptr %t835 to i64
  store i64 %t836, ptr %l180, !tbaa !24
  %t837 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e38
  br i1 %t837, label %bb164, label %bb165
bb164:
  %t839 = call ptr @__olang_region_make(ptr %v1)
  %t840 = ptrtoint ptr %t839 to i64
  store i64 %t840, ptr %l180, !tbaa !24
  br label %bb165
bb165:
  %t841 = load i64, ptr %l180
  %t842 = inttoptr i64 %t841 to ptr
  %t843 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t842, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t843, ptr %l182
  br label %bb166
bb166:
  %t844 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e38
  br i1 %t844, label %bb167, label %bb168
bb167:
  %t846 = load i64, ptr %l180
  %t847 = inttoptr i64 %t846 to ptr
  %t848 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l182, i32 0, i32 0
  %t849 = load { i64, ptr }, ptr %t848
  %t850 = extractvalue { i64, ptr } %t849, 1
  %t851 = call ptr @__olang_region_or(ptr %t850, ptr null)
  %t852 = call ptr @__olang_region_home(ptr %t851)
  %t853 = icmp ne ptr %t852, null
  %t854 = select i1 %t853, ptr %t852, ptr null
  call void @__olang_region_settle_in(ptr %t847, ptr %t854)
  br label %bb168
bb168:
  %t855 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l182
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t855, ptr %l39
  %t856 = call ptr @__olang_scope_hold(ptr %v1)
  %t857 = ptrtoint ptr %t856 to i64
  store i64 %t857, ptr %l184, !tbaa !24
  %t858 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e39
  br i1 %t858, label %bb169, label %bb170
bb169:
  %t860 = call ptr @__olang_region_make(ptr %v1)
  %t861 = ptrtoint ptr %t860 to i64
  store i64 %t861, ptr %l184, !tbaa !24
  br label %bb170
bb170:
  %t862 = load i64, ptr %l184
  %t863 = inttoptr i64 %t862 to ptr
  %t864 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t863, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t864, ptr %l186
  br label %bb171
bb171:
  %t865 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e39
  br i1 %t865, label %bb172, label %bb173
bb172:
  %t867 = load i64, ptr %l184
  %t868 = inttoptr i64 %t867 to ptr
  %t869 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l186, i32 0, i32 0
  %t870 = load { i64, ptr }, ptr %t869
  %t871 = extractvalue { i64, ptr } %t870, 1
  %t872 = call ptr @__olang_region_or(ptr %t871, ptr null)
  %t873 = call ptr @__olang_region_home(ptr %t872)
  %t874 = icmp ne ptr %t873, null
  %t875 = select i1 %t874, ptr %t873, ptr null
  call void @__olang_region_settle_in(ptr %t868, ptr %t875)
  br label %bb173
bb173:
  %t876 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l186
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t876, ptr %l40
  %t877 = call ptr @__olang_scope_hold(ptr %v1)
  %t878 = ptrtoint ptr %t877 to i64
  store i64 %t878, ptr %l188, !tbaa !24
  %t879 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e40
  br i1 %t879, label %bb174, label %bb175
bb174:
  %t881 = call ptr @__olang_region_make(ptr %v1)
  %t882 = ptrtoint ptr %t881 to i64
  store i64 %t882, ptr %l188, !tbaa !24
  br label %bb175
bb175:
  %t883 = load i64, ptr %l188
  %t884 = inttoptr i64 %t883 to ptr
  %t885 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t884)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t885, ptr %l190
  br label %bb176
bb176:
  %t886 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e40
  br i1 %t886, label %bb177, label %bb178
bb177:
  %t888 = load i64, ptr %l188
  %t889 = inttoptr i64 %t888 to ptr
  %t890 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190, i32 0, i32 2
  %t891 = load { i64, ptr }, ptr %t890
  %t892 = extractvalue { i64, ptr } %t891, 1
  %t893 = call ptr @__olang_region_or(ptr %t892, ptr null)
  %t894 = call ptr @__olang_region_home(ptr %t893)
  %t895 = icmp ne ptr %t894, null
  %t896 = select i1 %t895, ptr %t894, ptr null
  %t897 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190, i32 0, i32 1
  %t898 = load { i64, ptr }, ptr %t897
  %t899 = extractvalue { i64, ptr } %t898, 1
  %t900 = call ptr @__olang_region_or(ptr %t899, ptr null)
  %t901 = call ptr @__olang_region_home(ptr %t900)
  %t902 = icmp ne ptr %t901, null
  %t903 = select i1 %t902, ptr %t901, ptr %t896
  %t904 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190, i32 0, i32 0
  %t905 = load { i64, ptr }, ptr %t904
  %t906 = extractvalue { i64, ptr } %t905, 1
  %t907 = call ptr @__olang_region_or(ptr %t906, ptr null)
  %t908 = call ptr @__olang_region_home(ptr %t907)
  %t909 = icmp ne ptr %t908, null
  %t910 = select i1 %t909, ptr %t908, ptr %t903
  call void @__olang_region_settle_in(ptr %t889, ptr %t910)
  br label %bb178
bb178:
  %t911 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l190
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t911, ptr %l41
  %t912 = call ptr @__olang_scope_hold(ptr %v1)
  %t913 = ptrtoint ptr %t912 to i64
  store i64 %t913, ptr %l192, !tbaa !24
  %t914 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e41
  br i1 %t914, label %bb179, label %bb180
bb179:
  %t916 = call ptr @__olang_region_make(ptr %v1)
  %t917 = ptrtoint ptr %t916 to i64
  store i64 %t917, ptr %l192, !tbaa !24
  br label %bb180
bb180:
  %t918 = load i64, ptr %l192
  %t919 = inttoptr i64 %t918 to ptr
  %t920 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t919)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t920, ptr %l194
  br label %bb181
bb181:
  %t921 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e41
  br i1 %t921, label %bb182, label %bb183
bb182:
  %t923 = load i64, ptr %l192
  %t924 = inttoptr i64 %t923 to ptr
  %t925 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l194, i32 0, i32 2
  %t926 = load { i64, ptr }, ptr %t925
  %t927 = extractvalue { i64, ptr } %t926, 1
  %t928 = call ptr @__olang_region_or(ptr %t927, ptr null)
  %t929 = call ptr @__olang_region_home(ptr %t928)
  %t930 = icmp ne ptr %t929, null
  %t931 = select i1 %t930, ptr %t929, ptr null
  %t932 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l194, i32 0, i32 1
  %t933 = load { i64, ptr }, ptr %t932
  %t934 = extractvalue { i64, ptr } %t933, 1
  %t935 = call ptr @__olang_region_or(ptr %t934, ptr null)
  %t936 = call ptr @__olang_region_home(ptr %t935)
  %t937 = icmp ne ptr %t936, null
  %t938 = select i1 %t937, ptr %t936, ptr %t931
  %t939 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l194, i32 0, i32 0
  %t940 = load { i64, ptr }, ptr %t939
  %t941 = extractvalue { i64, ptr } %t940, 1
  %t942 = call ptr @__olang_region_or(ptr %t941, ptr null)
  %t943 = call ptr @__olang_region_home(ptr %t942)
  %t944 = icmp ne ptr %t943, null
  %t945 = select i1 %t944, ptr %t943, ptr %t938
  call void @__olang_region_settle_in(ptr %t924, ptr %t945)
  br label %bb183
bb183:
  %t946 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l194
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t946, ptr %l42
  %t947 = call ptr @__olang_scope_hold(ptr %v1)
  %t948 = ptrtoint ptr %t947 to i64
  store i64 %t948, ptr %l196, !tbaa !24
  %t949 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e42
  br i1 %t949, label %bb184, label %bb185
bb184:
  %t951 = call ptr @__olang_region_make(ptr %v1)
  %t952 = ptrtoint ptr %t951 to i64
  store i64 %t952, ptr %l196, !tbaa !24
  br label %bb185
bb185:
  %t953 = load i64, ptr %l196
  %t954 = inttoptr i64 %t953 to ptr
  %t955 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t954)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t955, ptr %l198
  br label %bb186
bb186:
  %t956 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e42
  br i1 %t956, label %bb187, label %bb188
bb187:
  %t958 = load i64, ptr %l196
  %t959 = inttoptr i64 %t958 to ptr
  %t960 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l198, i32 0, i32 2
  %t961 = load { i64, ptr }, ptr %t960
  %t962 = extractvalue { i64, ptr } %t961, 1
  %t963 = call ptr @__olang_region_or(ptr %t962, ptr null)
  %t964 = call ptr @__olang_region_home(ptr %t963)
  %t965 = icmp ne ptr %t964, null
  %t966 = select i1 %t965, ptr %t964, ptr null
  %t967 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l198, i32 0, i32 1
  %t968 = load { i64, ptr }, ptr %t967
  %t969 = extractvalue { i64, ptr } %t968, 1
  %t970 = call ptr @__olang_region_or(ptr %t969, ptr null)
  %t971 = call ptr @__olang_region_home(ptr %t970)
  %t972 = icmp ne ptr %t971, null
  %t973 = select i1 %t972, ptr %t971, ptr %t966
  %t974 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l198, i32 0, i32 0
  %t975 = load { i64, ptr }, ptr %t974
  %t976 = extractvalue { i64, ptr } %t975, 1
  %t977 = call ptr @__olang_region_or(ptr %t976, ptr null)
  %t978 = call ptr @__olang_region_home(ptr %t977)
  %t979 = icmp ne ptr %t978, null
  %t980 = select i1 %t979, ptr %t978, ptr %t973
  call void @__olang_region_settle_in(ptr %t959, ptr %t980)
  br label %bb188
bb188:
  %t981 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l198
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t981, ptr %l43
  %t982 = call ptr @__olang_scope_hold(ptr %v1)
  %t983 = ptrtoint ptr %t982 to i64
  store i64 %t983, ptr %l200, !tbaa !24
  %t984 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e43
  br i1 %t984, label %bb189, label %bb190
bb189:
  %t986 = call ptr @__olang_region_make(ptr %v1)
  %t987 = ptrtoint ptr %t986 to i64
  store i64 %t987, ptr %l200, !tbaa !24
  br label %bb190
bb190:
  %t988 = load i64, ptr %l200
  %t989 = inttoptr i64 %t988 to ptr
  %t990 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %t989)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t990, ptr %l202
  br label %bb191
bb191:
  %t991 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e43
  br i1 %t991, label %bb192, label %bb193
bb192:
  %t993 = load i64, ptr %l200
  %t994 = inttoptr i64 %t993 to ptr
  %t995 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l202, i32 0, i32 2
  %t996 = load { i64, ptr }, ptr %t995
  %t997 = extractvalue { i64, ptr } %t996, 1
  %t998 = call ptr @__olang_region_or(ptr %t997, ptr null)
  %t999 = call ptr @__olang_region_home(ptr %t998)
  %t1000 = icmp ne ptr %t999, null
  %t1001 = select i1 %t1000, ptr %t999, ptr null
  %t1002 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l202, i32 0, i32 1
  %t1003 = load { i64, ptr }, ptr %t1002
  %t1004 = extractvalue { i64, ptr } %t1003, 1
  %t1005 = call ptr @__olang_region_or(ptr %t1004, ptr null)
  %t1006 = call ptr @__olang_region_home(ptr %t1005)
  %t1007 = icmp ne ptr %t1006, null
  %t1008 = select i1 %t1007, ptr %t1006, ptr %t1001
  %t1009 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l202, i32 0, i32 0
  %t1010 = load { i64, ptr }, ptr %t1009
  %t1011 = extractvalue { i64, ptr } %t1010, 1
  %t1012 = call ptr @__olang_region_or(ptr %t1011, ptr null)
  %t1013 = call ptr @__olang_region_home(ptr %t1012)
  %t1014 = icmp ne ptr %t1013, null
  %t1015 = select i1 %t1014, ptr %t1013, ptr %t1008
  call void @__olang_region_settle_in(ptr %t994, ptr %t1015)
  br label %bb193
bb193:
  %t1016 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l202
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1016, ptr %l44
  %t1017 = call ptr @__olang_scope_hold(ptr %v1)
  %t1018 = ptrtoint ptr %t1017 to i64
  store i64 %t1018, ptr %l204, !tbaa !24
  %t1019 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e44
  br i1 %t1019, label %bb194, label %bb195
bb194:
  %t1021 = call ptr @__olang_region_make(ptr %v1)
  %t1022 = ptrtoint ptr %t1021 to i64
  store i64 %t1022, ptr %l204, !tbaa !24
  br label %bb195
bb195:
  %t1023 = load i64, ptr %l204
  %t1024 = inttoptr i64 %t1023 to ptr
  %t1025 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_26_3e(ptr %t1024)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1025, ptr %l206
  br label %bb196
bb196:
  %t1026 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e44
  br i1 %t1026, label %bb197, label %bb198
bb197:
  %t1028 = load i64, ptr %l204
  %t1029 = inttoptr i64 %t1028 to ptr
  %t1030 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l206, i32 0, i32 2
  %t1031 = load { i64, ptr }, ptr %t1030
  %t1032 = extractvalue { i64, ptr } %t1031, 1
  %t1033 = call ptr @__olang_region_or(ptr %t1032, ptr null)
  %t1034 = call ptr @__olang_region_home(ptr %t1033)
  %t1035 = icmp ne ptr %t1034, null
  %t1036 = select i1 %t1035, ptr %t1034, ptr null
  %t1037 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l206, i32 0, i32 1
  %t1038 = load { i64, ptr }, ptr %t1037
  %t1039 = extractvalue { i64, ptr } %t1038, 1
  %t1040 = call ptr @__olang_region_or(ptr %t1039, ptr null)
  %t1041 = call ptr @__olang_region_home(ptr %t1040)
  %t1042 = icmp ne ptr %t1041, null
  %t1043 = select i1 %t1042, ptr %t1041, ptr %t1036
  %t1044 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l206, i32 0, i32 0
  %t1045 = load { i64, ptr }, ptr %t1044
  %t1046 = extractvalue { i64, ptr } %t1045, 1
  %t1047 = call ptr @__olang_region_or(ptr %t1046, ptr null)
  %t1048 = call ptr @__olang_region_home(ptr %t1047)
  %t1049 = icmp ne ptr %t1048, null
  %t1050 = select i1 %t1049, ptr %t1048, ptr %t1043
  call void @__olang_region_settle_in(ptr %t1029, ptr %t1050)
  br label %bb198
bb198:
  %t1051 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l206
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1051, ptr %l45
  %t1052 = call ptr @__olang_scope_hold(ptr %v1)
  %t1053 = ptrtoint ptr %t1052 to i64
  store i64 %t1053, ptr %l208, !tbaa !24
  %t1054 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e45
  br i1 %t1054, label %bb199, label %bb200
bb199:
  %t1056 = call ptr @__olang_region_make(ptr %v1)
  %t1057 = ptrtoint ptr %t1056 to i64
  store i64 %t1057, ptr %l208, !tbaa !24
  br label %bb200
bb200:
  %t1058 = load i64, ptr %l208
  %t1059 = inttoptr i64 %t1058 to ptr
  %t1060 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1059)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1060, ptr %l210
  br label %bb201
bb201:
  %t1061 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e45
  br i1 %t1061, label %bb202, label %bb203
bb202:
  %t1063 = load i64, ptr %l208
  %t1064 = inttoptr i64 %t1063 to ptr
  %t1065 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l210, i32 0, i32 2
  %t1066 = load { i64, ptr }, ptr %t1065
  %t1067 = extractvalue { i64, ptr } %t1066, 1
  %t1068 = call ptr @__olang_region_or(ptr %t1067, ptr null)
  %t1069 = call ptr @__olang_region_home(ptr %t1068)
  %t1070 = icmp ne ptr %t1069, null
  %t1071 = select i1 %t1070, ptr %t1069, ptr null
  %t1072 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l210, i32 0, i32 1
  %t1073 = load { i64, ptr }, ptr %t1072
  %t1074 = extractvalue { i64, ptr } %t1073, 1
  %t1075 = call ptr @__olang_region_or(ptr %t1074, ptr null)
  %t1076 = call ptr @__olang_region_home(ptr %t1075)
  %t1077 = icmp ne ptr %t1076, null
  %t1078 = select i1 %t1077, ptr %t1076, ptr %t1071
  %t1079 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l210, i32 0, i32 0
  %t1080 = load { i64, ptr }, ptr %t1079
  %t1081 = extractvalue { i64, ptr } %t1080, 1
  %t1082 = call ptr @__olang_region_or(ptr %t1081, ptr null)
  %t1083 = call ptr @__olang_region_home(ptr %t1082)
  %t1084 = icmp ne ptr %t1083, null
  %t1085 = select i1 %t1084, ptr %t1083, ptr %t1078
  call void @__olang_region_settle_in(ptr %t1064, ptr %t1085)
  br label %bb203
bb203:
  %t1086 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l210
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1086, ptr %l46
  %t1087 = call ptr @__olang_scope_hold(ptr %v1)
  %t1088 = ptrtoint ptr %t1087 to i64
  store i64 %t1088, ptr %l212, !tbaa !24
  %t1089 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e46
  br i1 %t1089, label %bb204, label %bb205
bb204:
  %t1091 = call ptr @__olang_region_make(ptr %v1)
  %t1092 = ptrtoint ptr %t1091 to i64
  store i64 %t1092, ptr %l212, !tbaa !24
  br label %bb205
bb205:
  %t1093 = load i64, ptr %l212
  %t1094 = inttoptr i64 %t1093 to ptr
  %t1095 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t1094)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1095, ptr %l214
  br label %bb206
bb206:
  %t1096 = load i1, ptr @olang_2esole_2ecompiler_2ftypes_3aTable_2e46
  br i1 %t1096, label %bb207, label %bb208
bb207:
  %t1098 = load i64, ptr %l212
  %t1099 = inttoptr i64 %t1098 to ptr
  %t1100 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l214, i32 0, i32 2
  %t1101 = load { i64, ptr }, ptr %t1100
  %t1102 = extractvalue { i64, ptr } %t1101, 1
  %t1103 = call ptr @__olang_region_or(ptr %t1102, ptr null)
  %t1104 = call ptr @__olang_region_home(ptr %t1103)
  %t1105 = icmp ne ptr %t1104, null
  %t1106 = select i1 %t1105, ptr %t1104, ptr null
  %t1107 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l214, i32 0, i32 1
  %t1108 = load { i64, ptr }, ptr %t1107
  %t1109 = extractvalue { i64, ptr } %t1108, 1
  %t1110 = call ptr @__olang_region_or(ptr %t1109, ptr null)
  %t1111 = call ptr @__olang_region_home(ptr %t1110)
  %t1112 = icmp ne ptr %t1111, null
  %t1113 = select i1 %t1112, ptr %t1111, ptr %t1106
  %t1114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l214, i32 0, i32 0
  %t1115 = load { i64, ptr }, ptr %t1114
  %t1116 = extractvalue { i64, ptr } %t1115, 1
  %t1117 = call ptr @__olang_region_or(ptr %t1116, ptr null)
  %t1118 = call ptr @__olang_region_home(ptr %t1117)
  %t1119 = icmp ne ptr %t1118, null
  %t1120 = select i1 %t1119, ptr %t1118, ptr %t1113
  call void @__olang_region_settle_in(ptr %t1099, ptr %t1120)
  br label %bb208
bb208:
  %t1121 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l214
  %t1122 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 0
  %t1123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1123, ptr %t1122, !tbaa !29
  %t1124 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 1
  %t1125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1125, ptr %t1124
  %t1126 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 2
  %t1127 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1127, ptr %t1126
  %t1128 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 3
  %t1129 = load i1, ptr %l4, !tbaa !21
  store i1 %t1129, ptr %t1128, !tbaa !21
  %t1130 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 4
  %t1131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1131, ptr %t1130
  %t1132 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 5
  %t1133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1133, ptr %t1132
  %t1134 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 6
  %t1135 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1135, ptr %t1134
  %t1136 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 7
  %t1137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1137, ptr %t1136
  %t1138 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 8
  %t1139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1139, ptr %t1138
  %t1140 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 9
  %t1141 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1141, ptr %t1140
  %t1142 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 10
  %t1143 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1143, ptr %t1142
  %t1144 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 11
  %t1145 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1145, ptr %t1144
  %t1146 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 12
  %t1147 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1147, ptr %t1146
  %t1148 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 13
  %t1149 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1149, ptr %t1148
  %t1150 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 14
  %t1151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1151, ptr %t1150
  %t1152 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 15
  %t1153 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1153, ptr %t1152
  %t1154 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 16
  %t1155 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1155, ptr %t1154
  %t1156 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 17
  %t1157 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1157, ptr %t1156
  %t1158 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 18
  %t1159 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1159, ptr %t1158
  %t1160 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 19
  %t1161 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1161, ptr %t1160
  %t1162 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 20
  %t1163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1163, ptr %t1162
  %t1164 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 21
  %t1165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1165, ptr %t1164
  %t1166 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 22
  %t1167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1167, ptr %t1166
  %t1168 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 23
  %t1169 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1169, ptr %t1168
  %t1170 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 24
  %t1171 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1171, ptr %t1170
  %t1172 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 25
  %t1173 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1173, ptr %t1172
  %t1174 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 26
  %t1175 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1175, ptr %t1174
  %t1176 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 27
  %t1177 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1177, ptr %t1176
  %t1178 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 28
  %t1179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1179, ptr %t1178
  %t1180 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 29
  %t1181 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l30
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1181, ptr %t1180
  %t1182 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 30
  %t1183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1183, ptr %t1182
  %t1184 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 31
  %t1185 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1185, ptr %t1184
  %t1186 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 32
  %t1187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1187, ptr %t1186
  %t1188 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 33
  %t1189 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1189, ptr %t1188
  %t1190 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 34
  %t1191 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1191, ptr %t1190
  %t1192 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 35
  %t1193 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1193, ptr %t1192
  %t1194 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 36
  %t1195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1195, ptr %t1194
  %t1196 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 37
  %t1197 = load i1, ptr %l38, !tbaa !21
  store i1 %t1197, ptr %t1196, !tbaa !21
  %t1198 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 38
  %t1199 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1199, ptr %t1198
  %t1200 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 39
  %t1201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1201, ptr %t1200
  %t1202 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 40
  %t1203 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1203, ptr %t1202
  %t1204 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 41
  %t1205 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1205, ptr %t1204
  %t1206 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 42
  %t1207 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l43
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1207, ptr %t1206
  %t1208 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 43
  %t1209 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l44
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1209, ptr %t1208
  %t1210 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 44
  %t1211 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1211, ptr %t1210
  %t1212 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 45
  %t1213 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1213, ptr %t1212
  %t1214 = getelementptr %"compiler/types:Table", ptr %l216, i32 0, i32 46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1121, ptr %t1214
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l216, i64 2192, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_H" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"__" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_H" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@__olang_empty_array = external constant [16 x i64]
@olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [2 x i64] }> <{ i64 0, [2 x i64] [i64 0, i64 0] }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2eArray_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"keeps " }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"keeps " }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" borrows " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d21 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"{ i32, " }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d23 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d29 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"default" }>, align 8
@.d30 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"noreturn" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".#" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d42 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct(" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"enum{" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d48 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d51 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d52 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error{" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn?" }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ![" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d60 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ~[" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@olang_2esole_2ecompiler__2ftypes__2ecompiler__2ftypes__3aTable__2ecanonPromises_2elocal_2e4 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"borrows " }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d67 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"keeps " }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d69 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d72 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d78 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d79 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d80 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d81 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ ptr, ptr }" }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d83 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%\22" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%\22" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2ftypes_3aTable_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e6 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3_H67866d893b0e235fefa60e815142be68(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e10 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e15 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_Hdaf48aaf31e9845c659408ae38f7f59c(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e16 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e17 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hbfe39cc2b71dbabe830cee24ccf915b6(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e18 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hb60d9b83e890412eba8d9d5191d2497d(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e19 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId__Hc9d5028d9efd264605c80efeddc4ccf9(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e20 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e24 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e25 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e26 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e27 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e28 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e29 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e30 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e31 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e32 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e33 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e34 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e35 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e36 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e38 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e39 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e40 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e41 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e42 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e43 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e44 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftypes_3aTable_2e45 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftypes_3aTable_2e46 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
@olang_loc_c38cb1fa51df222a_dffb1d180717405e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_84fae12c7c668807_3becc0cabb21395b = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, i64 } @compiler_2ftypes_2ehash128(ptr %v0, { i64, ptr } %a0)
@olang_loc_a031dfbe8d9d2eb5_ead73bcf09c7e3f9 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ehex16(ptr %v0, i64 %a0)
@olang_loc_bd6aedfbb004cefb_a7e94c49277e6337 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_2_H5d6217f1de626e258ec0008385e9bf9b(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f54586e6a50c1e66_9f53f9bdb86e8e82 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_ede49b2874c89d85_5f433bfacafc8ba1 = external constant [0 x i8]
@olang_loc_500fe07468cf8918_1c2da4555a1cce94 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/types:data" @compiler_2ftypes_3adata_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eintern(ptr %v0, ptr %a0, %"compiler/types:data" %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_30e02956f84eec46_91b8152c5eb3aca = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5cbd31595b499a54_61b0a2a5664e21e0 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlainList(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_363cc534119e1b58_f5bd72046473679c = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H69e9af7ee32b7ff0c8685324094a29a4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H41a2935585cca595f0dd127aea20d09e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ePush_3ccompiler_2ftypes_3aListId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a8f3bb3fba0fecc5_79768dea68ad9969 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H37377f924b66ff741793959f79fef546(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_fab351c77a2932a6_cae3bbf023c8ab2a = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e__H6938bdf4910ae806791e4f0f97041ba1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2edeepest(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/types:data" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3a86b0904acb017a_fb1793104580b26e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eprimBits = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00" }>, align 64
declare i64 @compiler_2ftypes_2eIntBytes(i64 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eLaidOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2erunTimeArray(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_448c58e2e97e944f_f556e6dbd0c75243 = external constant [0 x i8]
@olang_loc_136e48f5d148640e_b95a40c005170ac2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_ec5192bc038e766b_2cb8f0109ffb07d7 = external constant [0 x i8]
@olang_loc_86988b21a5fa47aa_49c23f488b207436 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_H5a37a20f375ed653adc00b592f5745cf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d3e704bcd06f7d56_ed5a4209a5557c8a = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b4be3b7b6cfde177_2b1bada5393bc0cb = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eKeepsHome = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_93ecd4e0e0e07c38_b4b07d2ce290cdc4 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2eGet_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
@olang_loc_a8733e64b1dc76a5_71d130d56df9fbd1 = external constant [0 x i8]
@olang_loc_2503dd88f5595486_6b85ccba56568eb2 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ePut_3cArray_3cI64_3e_26_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromiseWords(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2ePromiseNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBorrowsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_8822c3adad84af9f_bf049295f8c08d23 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2ePromBorrows = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\01\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@olang_loc_f7b42ec29d1607_26e89eedc9b3128b = external constant [0 x i8]
@olang_loc_2df495a001b30f12_f15d21f3e8677f6 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eRoleTail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2eRoleFn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_63e623ceae63df16_2a862fe3f0344bd2 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H6f9f964c6e47aa337ef4265757211d88(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftype_H453784843b408e8ae093d39318df1aed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_888c44700641ffaa_fbe810d9adf00e56 = external constant [0 x i8]
@olang_loc_bf031f4f448c1291_890a9ad18176d2c5 = external constant [0 x i8]
@olang_loc_ac68e58e8d4c9184_1653a4c5d9050158 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i32 %a5, i64 %a6)
@olang_loc_ab5d312677a1c76d_705ca0c9b87dcf79 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eprimNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eSpread = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ejoined(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ecanonErrs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_bd4ce41e1f7e504b_596b58263987420f = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2efieldBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eenumLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b0143a025c7cdb06_8f46c74feff323b2 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e8197a4e96a8cf74_6f7a0b4ee9272b70 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePop_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@olang_loc_e0765d015d87e9a5_6d8cc8ea93d2cf01 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eprimLlvm = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eaggregate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_bbfcd5581dbe335b_bbf57adf6fe10b0f = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_ddaa3828305a2e93_9dde6ac7f2fcd077 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_983e1053235c526f_18c94ea801ade2a3 = external constant [0 x i8]
@olang_loc_427e8c4f545bd5ae_655f412a6751c1a2 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3acodeWalk_2esome(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_99f937c00427181_9a6d61fc7809e035 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCFunc(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_60c82cde6ffdb5d3_c68082b86ff4ff17 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3arefWalk_2esome(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_322c78cc145e2005_c2be1492b317e4d9 = external constant [0 x i8]
@olang_loc_d452eab293f44e67_f9a4b0317fd8e9b = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_a384a4bbbe0ebea1_23bacf7041e0bcc5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
@olang_loc_99e2f46192b0b63e_14d40f533c20e2f2 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adata_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aListId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3adecl_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3adata_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3ccompiler_2ftypes_3aTypeId_3e_26_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3abody_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aDeclId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20compiler_2ftypes_3aScopesId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cArray_3cI64_3e_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
