; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/prompt:Session" = type { ptr, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/eval:Snapshot", { ptr, ptr }, i1, i1, %"compiler/cells:Worker", %"compiler/build:Config", { i64, ptr } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/cells:Worker" = type { i1, i32, i32, i32, i32, i32, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/lineedit:Editor" = type { i1, i1, i64, { i64, ptr }, i64, i1, %"std/prelude/text:StringBuilder", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, i1, i1, i1, { i64, ptr }, { i64, ptr }, i64, i1, { i64, ptr }, i64, i64, i64, i8, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/io:Lines" = type { i32, %"std/prelude/input:InputBuffer" }
%"std/prelude/input:InputBuffer" = type { i32, i1, { i64, ptr }, i64, i64 }
%"compiler/prompt:Reply" = type { i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/prompt:item" = type { i64, i64, i64, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/prompt:Decl" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/prompt:Value" = type { { i64, ptr }, { i64, ptr }, i1, i64, { i64, ptr }, { i64, ptr } }
%"compiler/prompt:cell" = type { { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/prompt:program" = type { %"std/prelude/text:StringBuilder", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/views:Kept" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/interp:Exec" = type { ptr, ptr, i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/eval:Machine" = type { ptr, i32, i64, { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fsBody", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, i1, i1, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"compiler/source:Span", i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:Gap", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/scope:fsBody" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:instTree" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { ptr, ptr }, { ptr, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/cells:Plan" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/cells:Outcome" = type { i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"<poll.h>:pollfd" = type { i32, i16, i16 }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i32 @compiler_2fprompt_2eRun(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/prompt:Session"
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca %"compiler/lineedit:Editor"
  %l5 = alloca %"std/io:Lines"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca %"compiler/prompt:Session"
  %l10 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca %"compiler/lineedit:Editor"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca %"std/io:Lines"
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca i1
  %l50 = alloca %"compiler/prompt:Reply"
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/prompt:Session", align 8
  %t15 = alloca %"compiler/lineedit:Editor", align 8
  %t87 = alloca %"compiler/prompt:Reply", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fprompt_3aSession_2ector(ptr %t2, ptr %v0, ptr %s0, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %t2, i64 1152, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %l9, i64 1152, i1 false)
  %t4 = call i1 @std_2fos_2eIsTerminal(i32 0)
  store i1 %t4, ptr %l10
  br label %bb2
bb2:
  %t5 = load i1, ptr %l10, !tbaa !21
  store i1 %t5, ptr %l2, !tbaa !21
  %t6 = load i1, ptr %l2, !tbaa !21
  br i1 %t6, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  call void @compiler_2fprompt_2esay(ptr %s1, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t8 = load i1, ptr %l2, !tbaa !21
  br i1 %t8, label %bb7, label %bb8
bb7:
  %t10 = call i1 @std_2fos_2eIsTerminal(i32 1)
  store i1 %t10, ptr %l14
  br label %bb9
bb8:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb9:
  %t11 = load i1, ptr %l14, !tbaa !21
  store i1 %t11, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t12 = load i1, ptr %l13, !tbaa !21
  store i1 %t12, ptr %l3, !tbaa !21
  %t13 = call i1 @compiler_2flineedit_2eViChosen()
  store i1 %t13, ptr %l15
  br label %bb11
bb11:
  %t14 = call i1 @compiler_2fpaint_2eWanted(i32 1)
  store i1 %t14, ptr %l16
  br label %bb12
bb12:
  %t16 = load i1, ptr %l15, !tbaa !21
  %t17 = load i1, ptr %l16, !tbaa !21
  call void @compiler_2flineedit_3aEditor_2ector(ptr %t15, ptr %s0, i1 %t16, i1 %t17, i64 80)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t15, i64 432, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l17, i64 432, i1 false)
  %t18 = load i1, ptr %l3, !tbaa !21
  br i1 %t18, label %bb14, label %bb15
bb14:
  store ptr %l4, ptr %l19, !tbaa !29
  %t20 = call ptr @__olang_scope_hold(ptr %s0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l20, !tbaa !24
  %t22 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e8
  br i1 %t22, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  %t24 = call ptr @__olang_region_make(ptr %s0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l20, !tbaa !24
  br label %bb17
bb17:
  %t26 = load i64, ptr %l20
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call { i64, ptr } @compiler_2flineedit_2eHistoryPath(ptr %t27)
  store { i64, ptr } %t28, ptr %l22
  br label %bb18
bb18:
  %t29 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t30 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eLoad(ptr %s0, ptr %s0, ptr %t30, { i64, ptr } %t29)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t32 = load i32, ptr @G_2estd_2fio_2eStdin, !tbaa !23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 4, i64 8)
  store i32 %t32, ptr %t34
  %t36 = insertvalue { ptr, ptr } undef, ptr %t34, 0
  %t37 = icmp ne ptr %t34, null
  %t38 = select i1 %t37, ptr @olang_2etable_2eI32_7cstd_2fio_3aDescriptor, ptr null
  %t39 = insertvalue { ptr, ptr } %t36, ptr %t38, 1
  %t41 = call %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %s0, ptr %s0, { ptr, ptr } %t39)
  store %"std/io:Lines" %t41, ptr %l27
  br label %bb21
bb21:
  %t42 = load %"std/io:Lines", ptr %l27
  store %"std/io:Lines" %t42, ptr %l5
  %t43 = load i1, ptr %l3, !tbaa !21
  %t45 = getelementptr %"compiler/prompt:Session", ptr %l1, i32 0, i32 8
  store i1 %t43, ptr %t45, !tbaa !21
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb23, label %bb24
bb23:
  %t48 = getelementptr %"compiler/prompt:Session", ptr %l1, i32 0, i32 9
  %t49 = getelementptr %"compiler/cells:Worker", ptr %t48, i32 0, i32 7
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb25
bb25:
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  call void @compiler_2fprompt_2esay(ptr %s4, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb29:
  %t53 = getelementptr %"compiler/prompt:Session", ptr %l1, i32 0, i32 9
  %t54 = getelementptr %"compiler/cells:Worker", ptr %t53, i32 0, i32 7
  store i1 false, ptr %t54, !tbaa !21
  %t55 = load i1, ptr %l3, !tbaa !21
  %t56 = load i1, ptr %l2, !tbaa !21
  %t61 = call { i32, { i64, ptr } } @compiler_2fprompt_2enextEntry(ptr %s0, ptr %s0, ptr %s0, ptr %l4, ptr %l5, i1 %t55, i1 %t56)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l38
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb31, label %ok.65, !prof !99
ok.65:
  store { i64, ptr } %t62, ptr %l37
  br label %bb30
bb30:
  %t66 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t66, ptr %l32, !tbaa !27
  br label %bb33
bb31:
  %t67 = load i32, ptr %l38, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb33:
  %t71 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l42
  br label %bb34
bb34:
  %t75 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t75, ptr %l7, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t78, ptr %l44
  br label %bb35
bb35:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb37:
  br label %bb38
bb38:
  %t80 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t80, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t82, ptr %l46
  br label %bb39
bb39:
  %t83 = load i1, ptr %l46, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %t87, ptr %s0, ptr %s0, ptr %s7, ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t87, i64 144, i1 false)
  br label %bb42
bb41:
  br label %bb44
bb42:
  call void @compiler_2fprompt_2etell(ptr %s0, ptr %l50)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb44:
  %t91 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t91, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t93, ptr %l53
  br label %bb45
bb45:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb49
bb47:
  %t95 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t95, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t97, ptr %l56
  br label %bb48
bb48:
  %t98 = load i1, ptr %l56, !tbaa !21
  store i1 %t98, ptr %l54, !tbaa !21
  br label %bb49
bb49:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fprompt_2ecommand(ptr %s0, ptr %s0, ptr %s0, ptr %v0, ptr %l1, ptr %l4, { i64, ptr } %t100)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb54:
  br label %bb22
bb55:
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %s0, ptr %v0, ptr %l1)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fprompt_2eassigns(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 78 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb11
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t8 = trunc i64 80 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t13 = trunc i64 82 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t18 = trunc i64 83 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t23 = trunc i64 84 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb41
bb12:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t28 = trunc i64 85 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t33 = trunc i64 86 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 87 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t41 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t43 = trunc i64 88 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t46 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t48 = trunc i64 89 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb41
bb24:
  %t51 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t53 = trunc i64 90 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb25, label %bb26
bb25:
  br label %bb35
bb26:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t58 = trunc i64 91 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t63 = trunc i64 92 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t68 = trunc i64 93 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  %t71 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t73 = trunc i64 94 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3b31a6a49e369ce3_e623b02dcf14b57)
  unreachable
bb41:
  %t76 = load i1, ptr %l1, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca %"std/prelude/text:StringBuilder"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  %t5 = call ptr @__olang_scope_hold(ptr %s0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l9, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecellRows_2elocal_2e4
  br i1 %t7, label %bb3, label %bb4
bb3:
  %t9 = call ptr @__olang_region_make(ptr %s0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l9
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t12)
  store %"std/prelude/text:StringBuilder" %t13, ptr %l11
  br label %bb5
bb5:
  %t14 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecellRows_2elocal_2e4
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = load i64, ptr %l9
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/text:StringBuilder", ptr %l11, i32 0, i32 0
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = call ptr @__olang_region_or(ptr %t21, ptr null)
  %t23 = call ptr @__olang_region_home(ptr %t22)
  %t24 = icmp ne ptr %t23, null
  %t25 = select i1 %t24, ptr %t23, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t25)
  br label %bb7
bb7:
  %t26 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t26, ptr %l4
  %t29 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t29, ptr %l14
  br label %bb8
bb8:
  %t30 = load %"std/prelude/text:LineIter", ptr %l14
  store %"std/prelude/text:LineIter" %t30, ptr %l5
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l5)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l18
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb11, label %ok.36, !prof !99
ok.36:
  store { i64, ptr } %t33, ptr %l17
  br label %bb10
bb10:
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  br label %bb13
bb11:
  %t38 = load i32, ptr %l18, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb13:
  %t42 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t45, ptr %l22
  br label %bb14
bb14:
  %t46 = load i1, ptr %l22, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t53 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t49, { i64, ptr } %t52)
  store i1 %t53, ptr %l28
  br label %bb17
bb16:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb22
bb17:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb21
bb19:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t59 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t55, { i64, ptr } %t58)
  store i1 %t59, ptr %l33
  br label %bb20
bb20:
  %t60 = load i1, ptr %l33, !tbaa !21
  store i1 %t60, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l29, !tbaa !21
  store i1 %t61, ptr %l24, !tbaa !21
  br label %bb22
bb22:
  %t62 = load i1, ptr %l24, !tbaa !21
  br i1 %t62, label %bb23, label %bb24
bb23:
  store ptr %l2, ptr %l34, !tbaa !29
  %t63 = call ptr @__olang_scope_hold(ptr %s0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t65, label %bb25, label %bb26
bb24:
  br label %bb40
bb25:
  %t67 = call ptr @__olang_region_make(ptr %s0)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l35, !tbaa !24
  br label %bb26
bb26:
  %t69 = load i64, ptr %l35
  %t70 = inttoptr i64 %t69 to ptr
  %t72 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t70, ptr %l4)
  store { i64, ptr } %t72, ptr %l38
  br label %bb27
bb27:
  %t73 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fprompt_2eflushRow(ptr %s0, ptr %s0, ptr %v1, ptr %s0, ptr %t75, { i64, ptr } %t73, { i64, ptr } %t74, ptr %l3)
  br label %bb28
bb28:
  %t79 = call ptr @__olang_scope_hold(ptr %s0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l42, !tbaa !24
  %t81 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecellRows_2elocal_2e4
  br i1 %t81, label %bb29, label %bb30
bb29:
  %t83 = call ptr @__olang_region_make(ptr %s0)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l42, !tbaa !24
  br label %bb30
bb30:
  %t85 = load i64, ptr %l42
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t86)
  store %"std/prelude/text:StringBuilder" %t87, ptr %l44
  br label %bb31
bb31:
  %t88 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecellRows_2elocal_2e4
  br i1 %t88, label %bb32, label %bb33
bb32:
  %t90 = load i64, ptr %l42
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = getelementptr %"std/prelude/text:StringBuilder", ptr %l44, i32 0, i32 0
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t92, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = call ptr @__olang_region_or(ptr %t95, ptr null)
  %t97 = call ptr @__olang_region_home(ptr %t96)
  %t98 = icmp ne ptr %t97, null
  %t99 = select i1 %t98, ptr %t97, ptr null
  call void @__olang_region_settle_in(ptr %t91, ptr %t99)
  br label %bb33
bb33:
  %t100 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t100, ptr %l46
  %t101 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t101, ptr %l4
  %t102 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecellRows_2elocal_2e4
  br i1 %t102, label %bb34, label %bb35
bb34:
  %t104 = getelementptr %"std/prelude/text:StringBuilder", ptr %l46, i32 0, i32 0
  %t105 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t104, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = call ptr @__olang_region_or(ptr %t107, ptr null)
  %t109 = call ptr @__olang_region_home(ptr %t108)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr null
  call void @__olang_region_drop(ptr %t111)
  store %"std/prelude/text:StringBuilder" zeroinitializer, ptr %l46
  br label %bb35
bb35:
  %t112 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aStringBuilder_2e0
  br i1 %t112, label %bb36, label %bb37
bb36:
  %t114 = getelementptr %"std/prelude/text:StringBuilder", ptr %l46, i32 0, i32 0
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t114, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = call ptr @__olang_region_home(ptr %t118)
  %t120 = icmp ne ptr %t119, null
  %t121 = select i1 %t120, ptr %t119, ptr null
  call void @__olang_region_drop(ptr %t121)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t114
  br label %bb37
bb37:
  %t122 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2e0
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t124 = getelementptr %"std/prelude/text:StringBuilder", ptr %l46, i32 0, i32 0
  %t125 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t124, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125
  %t127 = extractvalue { i64, ptr } %t126, 0
  %t128 = extractvalue { i64, ptr } %t126, 1
  call void @__olang_region_release_part(ptr %t128, i64 %t127)
  store { i64, ptr } zeroinitializer, ptr %t125
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = extractvalue { i64, ptr } %t129, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t131, i64 %t132)
  %t137 = getelementptr i8, ptr %t136, i64 %t132
  call void @olang_textcopy(ptr %t137, ptr %t133, i64 %t134)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l4, { i64, ptr } %t139)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  br label %bb9
bb43:
  store ptr %l2, ptr %l54, !tbaa !29
  %t143 = call ptr @__olang_scope_hold(ptr %s0)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l55, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t147 = call ptr @__olang_region_make(ptr %s0)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l55, !tbaa !24
  br label %bb45
bb45:
  %t149 = load i64, ptr %l55
  %t150 = inttoptr i64 %t149 to ptr
  %t152 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t150, ptr %l4)
  store { i64, ptr } %t152, ptr %l58
  br label %bb46
bb46:
  %t153 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t155 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2fprompt_2eflushRow(ptr %s0, ptr %s0, ptr %v1, ptr %s0, ptr %t155, { i64, ptr } %t153, { i64, ptr } %t154, ptr %l3)
  br label %bb47
bb47:
  %t160 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t160, ptr %l63
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t161, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprompt_2ecommand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca i32
  %l17 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/prompt:Reply"
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l56 = alloca i1
  %l65 = alloca %"compiler/prompt:Reply"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t79 = alloca %"compiler/prompt:Reply", align 8
  %t151 = alloca %"compiler/prompt:Reply", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t7, ptr %l9
  br label %bb4
bb4:
  %t8 = load i1, ptr %l9, !tbaa !21
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s1, { i64, ptr } %t11, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t13, ptr %l12
  br label %bb8
bb7:
  br label %bb16
bb8:
  %t14 = load i1, ptr %l12, !tbaa !21
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 0
  store i1 %t14, ptr %t16, !tbaa !21
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/lineedit:Editor", ptr %t17, i32 0, i32 0
  %t20 = load i1, ptr %t19, !tbaa !21
  %t22 = call i32 @compiler_2flineedit_2eChoose(i1 %t20)
  store i32 %t22, ptr %l15
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb10, label %ok.24, !prof !99
ok.24:
  br label %bb9
bb9:
  br label %bb15
bb10:
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  store i1 %t28, ptr %l17, !tbaa !21
  %t29 = load i32, ptr %l15, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  call void @compiler_2fprompt_2esayErr(ptr %s2, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t36, ptr %l21
  br label %bb17
bb17:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eHelpText, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = extractvalue { i64, ptr } %t38, 0
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t40, i64 %t41)
  %t46 = getelementptr i8, ptr %t45, i64 %t41
  call void @olang_textcopy(ptr %t46, ptr %t42, i64 %t43)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  call void @compiler_2fprompt_2esay(ptr %s3, { i64, ptr } %t48)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t51, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t53, ptr %l26
  br label %bb22
bb22:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l27, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l28, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t57, 0
  store i64 %t60, ptr %l31, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l32, !tbaa !24
  %t63 = icmp sge i64 6, 0
  br i1 %t63, label %bb25, label %bb26
bb24:
  br label %bb33
bb25:
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = icmp sle i64 6, %t65
  br i1 %t66, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_2254b4c3038ee739_37193e0925765975)
  unreachable
bb27:
  %t68 = load i64, ptr %l31, !tbaa !24
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = icmp sle i64 %t68, %t69
  br i1 %t70, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_2254b4c3038ee739_37193e0925765975)
  unreachable
bb29:
  %t72 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = getelementptr i8, ptr %t73, i64 6
  %t76 = sub i64 %t74, 6
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  %t80 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eTypeOf(ptr %t79, ptr %v0, ptr %v2, ptr %s5, ptr %t80, { i64, ptr } %t78)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t79, i64 144, i1 false)
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_2254b4c3038ee739_37193e0925765975)
  unreachable
bb31:
  call void @compiler_2fprompt_2etell(ptr %s5, ptr %l37)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t83, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t85, ptr %l40
  br label %bb34
bb34:
  %t86 = load i1, ptr %l40, !tbaa !21
  br i1 %t86, label %bb35, label %bb36
bb35:
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t88, 0
  store i64 %t91, ptr %l44, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l45, !tbaa !24
  %t94 = icmp sge i64 6, 0
  br i1 %t94, label %bb37, label %bb38
bb36:
  br label %bb53
bb37:
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = icmp sle i64 6, %t96
  br i1 %t97, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_33ed6a85eb60430c_36f1732cc3964218)
  unreachable
bb39:
  %t99 = load i64, ptr %l44, !tbaa !24
  %t100 = load i64, ptr %l45, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_33ed6a85eb60430c_36f1732cc3964218)
  unreachable
bb41:
  %t103 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l44, !tbaa !24
  %t106 = getelementptr i8, ptr %t104, i64 6
  %t107 = sub i64 %t105, 6
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v2, ptr %v2, { i64, ptr } %t109)
  store { i64, ptr } %t111, ptr %l50
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_33ed6a85eb60430c_36f1732cc3964218)
  unreachable
bb43:
  %t112 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t112, ptr %l3, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v2, ptr %v0, { i64, ptr } %t113)
  %t116 = extractvalue { i32, { i64, ptr } } %t115, 1
  %t117 = extractvalue { i32, { i64, ptr } } %t115, 0
  store i32 %t117, ptr %l54
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb45, label %ok.119, !prof !99
ok.119:
  store { i64, ptr } %t116, ptr %l53
  br label %bb44
bb44:
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t120, ptr %l51, !tbaa !27
  br label %bb50
bb45:
  %t121 = load i32, ptr %l54, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  store i1 %t124, ptr %l56, !tbaa !21
  %t125 = load i32, ptr %l54, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  br i1 %t128, label %bb46, label %bb47
bb46:
  call void @__olang_errpay_pop()
  br label %bb47
bb47:
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t130 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t131 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t134 = extractvalue { i64, ptr } %t130, 1
  %t135 = extractvalue { i64, ptr } %t130, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t134, i64 %t135)
  %t142 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  call void @compiler_2fprompt_2esayErr(ptr %s7, { i64, ptr } %t144)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  %t147 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %t151, ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %t148, { i64, ptr } %t147, { i64, ptr } %t150)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t151, i64 144, i1 false)
  br label %bb51
bb51:
  call void @compiler_2fprompt_2etell(ptr %v0, ptr %l65)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t156 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t156, 1
  %t161 = extractvalue { i64, ptr } %t156, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  call void @olang_textcopy(ptr %t166, ptr %t157, i64 %t158)
  %t167 = getelementptr i8, ptr %t166, i64 %t158
  call void @olang_textcopy(ptr %t167, ptr %t160, i64 %t161)
  %t168 = getelementptr i8, ptr %t167, i64 %t161
  call void @olang_textcopy(ptr %t168, ptr %t163, i64 %t164)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t166, 1
  call void @compiler_2fprompt_2esayErr(ptr %s0, { i64, ptr } %t170)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/prompt:item"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/prompt:Decl"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/prompt:Value"
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca %"compiler/prompt:item"
  %l28 = alloca %"std/prelude/text:StringBuilder"
  %lp29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca %"compiler/prompt:Value"
  %lp34 = alloca ptr
  %l35 = alloca ptr
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l48 = alloca i64
  %l55 = alloca %"compiler/prompt:cell"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca %"compiler/prompt:item"
  %l67 = alloca %"compiler/prompt:item"
  %l68 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l81 = alloca %"compiler/prompt:Reply"
  %l83 = alloca i64
  %l85 = alloca %"compiler/prompt:Reply"
  %l86 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca %"compiler/prompt:item"
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l99 = alloca i64
  %l101 = alloca i64
  %l106 = alloca %"compiler/prompt:item"
  %l107 = alloca %"compiler/prompt:item"
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l138 = alloca i64
  %l140 = alloca i64
  %l145 = alloca %"compiler/prompt:Decl"
  %l149 = alloca i1
  %l158 = alloca i64
  %l160 = alloca i64
  %l165 = alloca %"compiler/prompt:Value"
  %l169 = alloca i1
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca %"compiler/prompt:item"
  %l185 = alloca %"compiler/prompt:item"
  %l186 = alloca i64
  %l188 = alloca { i64, ptr }
  %l189 = alloca i64
  %l190 = alloca { i64, ptr }
  %l195 = alloca ptr
  %l196 = alloca i64
  %l200 = alloca { i64, ptr }
  %l201 = alloca i64
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca i64
  %l206 = alloca i64
  %l212 = alloca { i64, ptr }
  %l213 = alloca i64
  %l219 = alloca %"compiler/prompt:Decl"
  %l223 = alloca %"std/prelude/text:StringBuilder"
  %l228 = alloca %"compiler/prompt:Reply"
  %l229 = alloca %"compiler/prompt:Reply"
  %l239 = alloca i64
  %l241 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l243 = alloca i64
  %l245 = alloca i64
  %l250 = alloca %"compiler/prompt:Value"
  %l254 = alloca i1
  %l264 = alloca i64
  %l267 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l268 = alloca i64
  %l270 = alloca { i64, ptr }
  %l271 = alloca i64
  %l272 = alloca { i64, ptr }
  %l277 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l281 = alloca i1
  %l288 = alloca %"compiler/prompt:Reply"
  %l290 = alloca i1
  %l292 = alloca i64
  %l294 = alloca i64
  %l296 = alloca %"compiler/prompt:Reply"
  %l298 = alloca %"compiler/prompt:Reply"
  %l299 = alloca %"compiler/prompt:Reply"
  %l308 = alloca i64
  %l311 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l317 = alloca %"compiler/prompt:Reply"
  %s0 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %t148 = alloca %"compiler/prompt:Reply", align 8
  %t558 = alloca %"compiler/prompt:Reply", align 8
  %t777 = alloca %"compiler/prompt:Reply", align 8
  %t804 = alloca %"compiler/prompt:Reply", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l35, !tbaa !29
  %t2 = load ptr, ptr %l35, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l35, !tbaa !29
  %t10 = getelementptr %"compiler/prompt:Session", ptr %t9, i32 0, i32 1
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t13, ptr %l40
  br label %bb1
bb1:
  %t14 = load i1, ptr %l40, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = call ptr @__olang_scope_hold(ptr %v3)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l43, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e0
  br i1 %t19, label %bb4, label %bb5
bb3:
  %t21 = call ptr @__olang_scope_hold(ptr %v3)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l48, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e0
  br i1 %t23, label %bb6, label %bb7
bb4:
  %t25 = call ptr @__olang_region_make(ptr %v3)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l43, !tbaa !24
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = load i64, ptr %l43
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_held_alloc(ptr %t32, i64 %t30)
  call void @olang_textcopy(ptr %t33, ptr %t29, i64 %t30)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l42, !tbaa !27
  br label %bb8
bb6:
  %t38 = call ptr @__olang_region_make(ptr %v3)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l48, !tbaa !24
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/prompt:Session", ptr %t40, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t43)
  %t48 = add i64 %t45, %t47
  %t49 = load i64, ptr %l48
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = getelementptr i8, ptr %t51, i64 %t45
  %t53 = call i64 @__olang_fmt_i64(ptr %t52, i64 %t43)
  %t54 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  store { i64, ptr } %t55, ptr %l42, !tbaa !27
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t61 = call %"compiler/prompt:cell" @compiler_2fprompt_3acell_2ector(ptr %v3, ptr %v1, ptr %v3, { i64, ptr } %t59, { i64, ptr } %t58)
  store %"compiler/prompt:cell" %t61, ptr %l55
  br label %bb9
bb9:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 104, i64 8)
  store ptr %t62, ptr %lp3
  %t63 = load %"compiler/prompt:cell", ptr %l55
  %t64 = load ptr, ptr %lp3
  store %"compiler/prompt:cell" %t63, ptr %t64
  %t65 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2epieces(ptr %v1, ptr %v3, { i64, ptr } %t65)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l57
  br label %bb10
bb10:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t69
  store ptr %t69, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l59, !tbaa !24
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t72)
  store i64 %t74, ptr %l61
  br label %bb12
bb12:
  %t75 = load i64, ptr %l59, !tbaa !24
  %t76 = load i64, ptr %l61, !tbaa !24
  %t77 = icmp slt i64 %t75, %t76
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %v3, ptr %t81, i64 %t82)
  store %"compiler/prompt:item" %t85, ptr %l66
  br label %bb16
bb16:
  %t86 = load %"compiler/prompt:item", ptr %l66
  store %"compiler/prompt:item" %t86, ptr %l67
  %t87 = call ptr @__olang_scope_hold(ptr %v3)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l68, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t91 = call ptr @__olang_region_make_part(ptr %v3)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l68, !tbaa !24
  br label %bb18
bb18:
  %t93 = getelementptr %"compiler/prompt:item", ptr %l67, i32 0, i32 5
  %t94 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t93, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l70, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l71, !tbaa !24
  %t98 = load i64, ptr %l71, !tbaa !24
  %t99 = mul i64 %t98, 16
  %t100 = load i64, ptr %l68
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_held_alloc(ptr %t101, i64 %t99)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l72, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l71, !tbaa !24
  %t110 = mul i64 %t109, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t112 = getelementptr %"compiler/prompt:item", ptr %l67, i32 0, i32 5
  %t113 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t112, i32 0, i32 0
  store { i64, ptr } %t111, ptr %t113, !tbaa !27
  %t114 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t114, label %bb19, label %bb20
bb19:
  %t116 = getelementptr %"compiler/prompt:item", ptr %l67, i32 0, i32 5
  %t117 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t116, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t121 = icmp eq i64 %t119, 0
  br i1 %t121, label %bb21, label %bb22
bb20:
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 88, i64 8)
  store ptr %t123, ptr %lp6
  %t124 = load %"compiler/prompt:item", ptr %l67
  %t125 = load ptr, ptr %lp6
  store %"compiler/prompt:item" %t124, ptr %t125
  %t126 = load ptr, ptr %lp3
  %t127 = getelementptr %"compiler/prompt:cell", ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %lp6
  %t129 = load %"compiler/prompt:item", ptr %t128
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ePush_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %v3, ptr %t127, %"compiler/prompt:item" %t129)
  br label %bb23
bb21:
  %t132 = getelementptr %"compiler/prompt:item", ptr %l67, i32 0, i32 5
  %t133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t132, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t133, !tbaa !27
  br label %bb22
bb22:
  %t134 = getelementptr %"compiler/prompt:item", ptr %l67, i32 0, i32 5
  %t135 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t134, i32 0, i32 0
  %t136 = load i64, ptr %l68
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = load { i64, ptr }, ptr %t135
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr null
  call void @__olang_region_settle_in(ptr %t137, ptr %t142)
  br label %bb20
bb23:
  br label %bb24
bb24:
  %t143 = load i64, ptr %l5, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l5, !tbaa !24
  br label %bb11
bb25:
  call void @compiler_2fprompt_3aReply_2ector(ptr %t148, ptr %v3)
  call void @llvm.memmove.p0.p0.i64(ptr %l81, ptr %t148, i64 144, i1 false)
  br label %bb26
bb26:
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 144, i64 8)
  store ptr %t149, ptr %lp7
  %t150 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t150, ptr %l81, i64 144, i1 false)
  %t151 = load ptr, ptr %lp3
  %t152 = getelementptr %"compiler/prompt:cell", ptr %t151, i32 0, i32 2
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t152)
  store i64 %t154, ptr %l83
  br label %bb27
bb27:
  %t155 = load i64, ptr %l83, !tbaa !24
  %t156 = icmp eq i64 %t155, 0
  br i1 %t156, label %bb28, label %bb29
bb28:
  %t158 = load ptr, ptr %lp7
  %t159 = getelementptr %"compiler/prompt:Reply", ptr %t158, i32 0, i32 0
  store i1 true, ptr %t159, !tbaa !21
  %t160 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l85, ptr %t160, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l85, i64 144, i1 false)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t161 = load ptr, ptr %lp3
  %t162 = getelementptr %"compiler/prompt:cell", ptr %t161, i32 0, i32 2
  store ptr %t162, ptr %l86, !tbaa !29
  %t163 = load ptr, ptr %lp3
  %t164 = getelementptr %"compiler/prompt:cell", ptr %t163, i32 0, i32 2
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t164)
  store i64 %t166, ptr %l88
  br label %bb31
bb31:
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = sub i64 %t167, 1
  %t169 = load ptr, ptr %l86, !tbaa !29
  %t171 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %s0, ptr %t169, i64 %t168)
  store %"compiler/prompt:item" %t171, ptr %l90
  br label %bb32
bb32:
  %t172 = getelementptr %"compiler/prompt:item", ptr %l90, i32 0, i32 6
  %t173 = load i1, ptr %t172, !tbaa !21
  %t175 = load ptr, ptr %lp3
  %t176 = getelementptr %"compiler/prompt:cell", ptr %t175, i32 0, i32 4
  store i1 %t173, ptr %t176, !tbaa !21
  %t177 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l92
  br label %bb33
bb33:
  %t178 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t178, ptr %lp8
  %t179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t180 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %t180
  %t181 = call ptr @__olang_scope_hold(ptr %v3)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l93, !tbaa !24
  %t183 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2eCell_2elocal_2e9
  br i1 %t183, label %bb34, label %bb35
bb34:
  %t185 = call ptr @__olang_region_make(ptr %v3)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l93, !tbaa !24
  br label %bb35
bb35:
  %t187 = load i64, ptr %l93
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %t188, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %l95
  br label %bb36
bb36:
  %t190 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2eCell_2elocal_2e9
  br i1 %t190, label %bb37, label %bb38
bb37:
  %t192 = load i64, ptr %l93
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = call ptr @__olang_region_home(ptr %t197)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  call void @__olang_region_settle_in(ptr %t193, ptr %t200)
  br label %bb38
bb38:
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t201, ptr %lp9
  %t202 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  %t203 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t202, ptr %t203
  %t204 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t204, ptr %l97
  br label %bb39
bb39:
  %t205 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l97
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t205, ptr %l10
  %t206 = load ptr, ptr %lp3
  %t207 = getelementptr %"compiler/prompt:cell", ptr %t206, i32 0, i32 2
  store ptr %t207, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb40
bb40:
  %t209 = load i64, ptr %l12, !tbaa !24
  store i64 %t209, ptr %l99, !tbaa !24
  %t210 = load ptr, ptr %l11, !tbaa !29
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t210)
  store i64 %t212, ptr %l101
  br label %bb41
bb41:
  %t213 = load i64, ptr %l99, !tbaa !24
  %t214 = load i64, ptr %l101, !tbaa !24
  %t215 = icmp slt i64 %t213, %t214
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb42, label %bb43
bb42:
  br label %bb66
bb43:
  br label %bb44
bb44:
  %t219 = load ptr, ptr %l11, !tbaa !29
  %t220 = load i64, ptr %l12, !tbaa !24
  %t223 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %v3, ptr %t219, i64 %t220)
  store %"compiler/prompt:item" %t223, ptr %l106
  br label %bb45
bb45:
  %t224 = load %"compiler/prompt:item", ptr %l106
  store %"compiler/prompt:item" %t224, ptr %l107
  %t225 = call ptr @__olang_scope_hold(ptr %v3)
  %t226 = ptrtoint ptr %t225 to i64
  store i64 %t226, ptr %l108, !tbaa !24
  %t227 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t227, label %bb46, label %bb47
bb46:
  %t229 = call ptr @__olang_region_make_part(ptr %v3)
  %t230 = ptrtoint ptr %t229 to i64
  store i64 %t230, ptr %l108, !tbaa !24
  br label %bb47
bb47:
  %t231 = getelementptr %"compiler/prompt:item", ptr %l107, i32 0, i32 5
  %t232 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t231, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l110, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  store i64 %t235, ptr %l111, !tbaa !24
  %t236 = load i64, ptr %l111, !tbaa !24
  %t237 = mul i64 %t236, 16
  %t238 = load i64, ptr %l108
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = call ptr @__olang_held_alloc(ptr %t239, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l112, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l111, !tbaa !24
  %t248 = mul i64 %t247, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t244, ptr %t246, i64 %t248, i1 false)
  %t249 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t250 = getelementptr %"compiler/prompt:item", ptr %l107, i32 0, i32 5
  %t251 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t250, i32 0, i32 0
  store { i64, ptr } %t249, ptr %t251, !tbaa !27
  %t252 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t252, label %bb48, label %bb49
bb48:
  %t254 = getelementptr %"compiler/prompt:item", ptr %l107, i32 0, i32 5
  %t255 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t254, i32 0, i32 0
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t259 = icmp eq i64 %t257, 0
  br i1 %t259, label %bb50, label %bb51
bb49:
  %t261 = load %"compiler/prompt:item", ptr %l107
  store %"compiler/prompt:item" %t261, ptr %l13
  %t262 = getelementptr %"compiler/prompt:item", ptr %l13, i32 0, i32 3
  %t263 = load i1, ptr %t262, !tbaa !21
  br i1 %t263, label %bb52, label %bb53
bb50:
  %t265 = getelementptr %"compiler/prompt:item", ptr %l107, i32 0, i32 5
  %t266 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t265, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t266, !tbaa !27
  br label %bb51
bb51:
  %t267 = getelementptr %"compiler/prompt:item", ptr %l107, i32 0, i32 5
  %t268 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t267, i32 0, i32 0
  %t269 = load i64, ptr %l108
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = load { i64, ptr }, ptr %t268
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = call ptr @__olang_region_or(ptr %t272, ptr null)
  %t274 = icmp ne ptr %t273, null
  %t275 = select i1 %t274, ptr %t273, ptr null
  call void @__olang_region_settle_in(ptr %t270, ptr %t275)
  br label %bb49
bb52:
  %t276 = getelementptr %"compiler/prompt:item", ptr %l13, i32 0, i32 4
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v3, ptr %l10, { i64, ptr } %t277, i1 true)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t280 = getelementptr %"compiler/prompt:item", ptr %l13, i32 0, i32 5
  store ptr %t280, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb56
bb56:
  %t282 = load i64, ptr %l15, !tbaa !24
  store i64 %t282, ptr %l120, !tbaa !24
  %t283 = load ptr, ptr %l14, !tbaa !29
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t283)
  store i64 %t285, ptr %l122
  br label %bb57
bb57:
  %t286 = load i64, ptr %l120, !tbaa !24
  %t287 = load i64, ptr %l122, !tbaa !24
  %t288 = icmp slt i64 %t286, %t287
  %t290 = xor i1 %t288, true
  br i1 %t290, label %bb58, label %bb59
bb58:
  br label %bb64
bb59:
  br label %bb60
bb60:
  %t292 = load ptr, ptr %l14, !tbaa !29
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t292, i64 %t293)
  store { i64, ptr } %t296, ptr %l127
  br label %bb61
bb61:
  %t297 = load { i64, ptr }, ptr %l127, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v3, ptr %l10, { i64, ptr } %t297, i1 true)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t301 = load i64, ptr %l15, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l15, !tbaa !24
  br label %bb56
bb64:
  br label %bb65
bb65:
  %t306 = load i64, ptr %l12, !tbaa !24
  %t309 = add i64 %t306, 1
  store i64 %t309, ptr %l12, !tbaa !24
  br label %bb40
bb66:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/prompt:Session", ptr %t311, i32 0, i32 3
  store ptr %t313, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb67
bb67:
  %t315 = load i64, ptr %l18, !tbaa !24
  store i64 %t315, ptr %l138, !tbaa !24
  %t316 = load ptr, ptr %l17, !tbaa !29
  %t318 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %t316)
  store i64 %t318, ptr %l140
  br label %bb68
bb68:
  %t319 = load i64, ptr %l138, !tbaa !24
  %t320 = load i64, ptr %l140, !tbaa !24
  %t321 = icmp slt i64 %t319, %t320
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb69, label %bb70
bb69:
  br label %bb79
bb70:
  br label %bb71
bb71:
  %t325 = load ptr, ptr %l17, !tbaa !29
  %t326 = load i64, ptr %l18, !tbaa !24
  %t329 = call %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %v0, ptr %t325, i64 %t326)
  store %"compiler/prompt:Decl" %t329, ptr %l145
  br label %bb72
bb72:
  %t330 = load %"compiler/prompt:Decl", ptr %l145
  store %"compiler/prompt:Decl" %t330, ptr %l19
  %t331 = getelementptr %"compiler/prompt:Decl", ptr %l19, i32 0, i32 0
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  %t337 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %v0, ptr %l10, { i64, ptr } %t332)
  store i1 %t337, ptr %l149
  br label %bb73
bb73:
  %t338 = load i1, ptr %l149, !tbaa !21
  %t339 = xor i1 %t338, true
  br i1 %t339, label %bb74, label %bb75
bb74:
  %t341 = load ptr, ptr %lp8
  %t342 = load %"compiler/prompt:Decl", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2ePush_3ccompiler_2fprompt_3aDecl_3e(ptr %v3, ptr %v0, ptr %t341, %"compiler/prompt:Decl" %t342)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t345 = load i64, ptr %l18, !tbaa !24
  %t348 = add i64 %t345, 1
  store i64 %t348, ptr %l18, !tbaa !24
  br label %bb67
bb79:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/prompt:Session", ptr %t350, i32 0, i32 4
  store ptr %t352, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb80
bb80:
  %t354 = load i64, ptr %l22, !tbaa !24
  store i64 %t354, ptr %l158, !tbaa !24
  %t355 = load ptr, ptr %l21, !tbaa !29
  %t357 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %t355)
  store i64 %t357, ptr %l160
  br label %bb81
bb81:
  %t358 = load i64, ptr %l158, !tbaa !24
  %t359 = load i64, ptr %l160, !tbaa !24
  %t360 = icmp slt i64 %t358, %t359
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb82, label %bb83
bb82:
  br label %bb92
bb83:
  br label %bb84
bb84:
  %t364 = load ptr, ptr %l21, !tbaa !29
  %t365 = load i64, ptr %l22, !tbaa !24
  %t368 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v0, ptr %t364, i64 %t365)
  store %"compiler/prompt:Value" %t368, ptr %l165
  br label %bb85
bb85:
  %t369 = load %"compiler/prompt:Value", ptr %l165
  store %"compiler/prompt:Value" %t369, ptr %l23
  %t370 = getelementptr %"compiler/prompt:Value", ptr %l23, i32 0, i32 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t376 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %v0, ptr %l10, { i64, ptr } %t371)
  store i1 %t376, ptr %l169
  br label %bb86
bb86:
  %t377 = load i1, ptr %l169, !tbaa !21
  %t378 = xor i1 %t377, true
  br i1 %t378, label %bb87, label %bb88
bb87:
  %t380 = load ptr, ptr %lp9
  %t381 = load %"compiler/prompt:Value", ptr %l23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v0, ptr %t380, %"compiler/prompt:Value" %t381)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t384 = load i64, ptr %l22, !tbaa !24
  %t387 = add i64 %t384, 1
  store i64 %t387, ptr %l22, !tbaa !24
  br label %bb80
bb92:
  %t389 = load ptr, ptr %lp3
  %t390 = getelementptr %"compiler/prompt:cell", ptr %t389, i32 0, i32 2
  store ptr %t390, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb93
bb93:
  %t392 = load i64, ptr %l26, !tbaa !24
  store i64 %t392, ptr %l177, !tbaa !24
  %t393 = load ptr, ptr %l25, !tbaa !29
  %t395 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t393)
  store i64 %t395, ptr %l179
  br label %bb94
bb94:
  %t396 = load i64, ptr %l177, !tbaa !24
  %t397 = load i64, ptr %l179, !tbaa !24
  %t398 = icmp slt i64 %t396, %t397
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb95, label %bb96
bb95:
  br label %bb123
bb96:
  br label %bb97
bb97:
  %t402 = load ptr, ptr %l25, !tbaa !29
  %t403 = load i64, ptr %l26, !tbaa !24
  %t406 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %v3, ptr %t402, i64 %t403)
  store %"compiler/prompt:item" %t406, ptr %l184
  br label %bb98
bb98:
  %t407 = load %"compiler/prompt:item", ptr %l184
  store %"compiler/prompt:item" %t407, ptr %l185
  %t408 = call ptr @__olang_scope_hold(ptr %v3)
  %t409 = ptrtoint ptr %t408 to i64
  store i64 %t409, ptr %l186, !tbaa !24
  %t410 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t410, label %bb99, label %bb100
bb99:
  %t412 = call ptr @__olang_region_make_part(ptr %v3)
  %t413 = ptrtoint ptr %t412 to i64
  store i64 %t413, ptr %l186, !tbaa !24
  br label %bb100
bb100:
  %t414 = getelementptr %"compiler/prompt:item", ptr %l185, i32 0, i32 5
  %t415 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t414, i32 0, i32 0
  %t416 = load { i64, ptr }, ptr %t415, !tbaa !27
  store { i64, ptr } %t416, ptr %l188, !tbaa !27
  %t417 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  store i64 %t418, ptr %l189, !tbaa !24
  %t419 = load i64, ptr %l189, !tbaa !24
  %t420 = mul i64 %t419, 16
  %t421 = load i64, ptr %l186
  %t422 = inttoptr i64 %t421 to ptr
  %t423 = call ptr @__olang_held_alloc(ptr %t422, i64 %t420)
  %t424 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t423, 1
  store { i64, ptr } %t425, ptr %l190, !tbaa !27
  %t426 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = load i64, ptr %l189, !tbaa !24
  %t431 = mul i64 %t430, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t427, ptr %t429, i64 %t431, i1 false)
  %t432 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t433 = getelementptr %"compiler/prompt:item", ptr %l185, i32 0, i32 5
  %t434 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t433, i32 0, i32 0
  store { i64, ptr } %t432, ptr %t434, !tbaa !27
  %t435 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t435, label %bb101, label %bb102
bb101:
  %t437 = getelementptr %"compiler/prompt:item", ptr %l185, i32 0, i32 5
  %t438 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t437, i32 0, i32 0
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  %t442 = icmp eq i64 %t440, 0
  br i1 %t442, label %bb103, label %bb104
bb102:
  %t444 = load %"compiler/prompt:item", ptr %l185
  store %"compiler/prompt:item" %t444, ptr %l27
  %t445 = getelementptr %"compiler/prompt:item", ptr %l27, i32 0, i32 3
  %t446 = load i1, ptr %t445, !tbaa !21
  br i1 %t446, label %bb105, label %bb106
bb103:
  %t448 = getelementptr %"compiler/prompt:item", ptr %l185, i32 0, i32 5
  %t449 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t448, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t449, !tbaa !27
  br label %bb104
bb104:
  %t450 = getelementptr %"compiler/prompt:item", ptr %l185, i32 0, i32 5
  %t451 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t450, i32 0, i32 0
  %t452 = load i64, ptr %l186
  %t453 = inttoptr i64 %t452 to ptr
  %t454 = load { i64, ptr }, ptr %t451
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = call ptr @__olang_region_or(ptr %t455, ptr null)
  %t457 = icmp ne ptr %t456, null
  %t458 = select i1 %t457, ptr %t456, ptr null
  call void @__olang_region_settle_in(ptr %t453, ptr %t458)
  br label %bb102
bb105:
  %t459 = load ptr, ptr %lp8
  store ptr %t459, ptr %l195, !tbaa !29
  %t460 = call ptr @__olang_scope_hold(ptr %v3)
  %t461 = ptrtoint ptr %t460 to i64
  store i64 %t461, ptr %l196, !tbaa !24
  %t462 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aDecl_2e0
  br i1 %t462, label %bb107, label %bb108
bb106:
  br label %bb121
bb107:
  %t464 = call ptr @__olang_region_make(ptr %v3)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l196, !tbaa !24
  br label %bb108
bb108:
  %t466 = getelementptr %"compiler/prompt:item", ptr %l27, i32 0, i32 4
  %t467 = load { i64, ptr }, ptr %t466, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 1
  %t470 = extractvalue { i64, ptr } %t467, 0
  %t471 = load i64, ptr %l196
  %t472 = inttoptr i64 %t471 to ptr
  %t473 = call ptr @__olang_held_alloc(ptr %t472, i64 %t470)
  call void @olang_textcopy(ptr %t473, ptr %t469, i64 %t470)
  %t474 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t473, 1
  store { i64, ptr } %t475, ptr %l200, !tbaa !27
  %t477 = call ptr @__olang_scope_hold(ptr %v3)
  %t478 = ptrtoint ptr %t477 to i64
  store i64 %t478, ptr %l201, !tbaa !24
  %t479 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aDecl_2e1
  br i1 %t479, label %bb109, label %bb110
bb109:
  %t481 = call ptr @__olang_region_make(ptr %v3)
  %t482 = ptrtoint ptr %t481 to i64
  store i64 %t482, ptr %l201, !tbaa !24
  br label %bb110
bb110:
  %t483 = load ptr, ptr %lp3
  %t484 = getelementptr %"compiler/prompt:cell", ptr %t483, i32 0, i32 1
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  store { i64, ptr } %t485, ptr %l203, !tbaa !27
  %t486 = getelementptr %"compiler/prompt:item", ptr %l27, i32 0, i32 0
  %t487 = load i64, ptr %t486, !tbaa !24
  store i64 %t487, ptr %l204, !tbaa !24
  %t488 = getelementptr %"compiler/prompt:item", ptr %l27, i32 0, i32 1
  %t489 = load i64, ptr %t488, !tbaa !24
  store i64 %t489, ptr %l205, !tbaa !24
  %t490 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 0
  store i64 %t491, ptr %l206, !tbaa !24
  %t492 = load i64, ptr %l204, !tbaa !24
  %t493 = icmp sge i64 %t492, 0
  br i1 %t493, label %bb111, label %bb112
bb111:
  %t495 = load i64, ptr %l204, !tbaa !24
  %t496 = load i64, ptr %l205, !tbaa !24
  %t497 = icmp sle i64 %t495, %t496
  br i1 %t497, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_e8da02ec0656f58f_3ce6a8f236b380bb)
  unreachable
bb113:
  %t499 = load i64, ptr %l205, !tbaa !24
  %t500 = load i64, ptr %l206, !tbaa !24
  %t501 = icmp sle i64 %t499, %t500
  br i1 %t501, label %bb115, label %bb116
bb114:
  call void @__olang_check_failed(ptr @olang_loc_e8da02ec0656f58f_3ce6a8f236b380bb)
  unreachable
bb115:
  %t503 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = load i64, ptr %l204, !tbaa !24
  %t506 = load i64, ptr %l205, !tbaa !24
  %t507 = getelementptr i8, ptr %t504, i64 %t505
  %t508 = sub i64 %t506, %t505
  %t509 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t507, 1
  %t512 = extractvalue { i64, ptr } %t510, 1
  %t513 = extractvalue { i64, ptr } %t510, 0
  %t514 = load i64, ptr %l201
  %t515 = inttoptr i64 %t514 to ptr
  %t516 = call ptr @__olang_held_alloc(ptr %t515, i64 %t513)
  call void @olang_textcopy(ptr %t516, ptr %t512, i64 %t513)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  store { i64, ptr } %t518, ptr %l212, !tbaa !27
  %t520 = call ptr @__olang_scope_hold(ptr %v3)
  %t521 = ptrtoint ptr %t520 to i64
  store i64 %t521, ptr %l213, !tbaa !24
  %t522 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aDecl_2e2
  br i1 %t522, label %bb117, label %bb118
bb116:
  call void @__olang_check_failed(ptr @olang_loc_e8da02ec0656f58f_3ce6a8f236b380bb)
  unreachable
bb117:
  %t524 = call ptr @__olang_region_make(ptr %v3)
  %t525 = ptrtoint ptr %t524 to i64
  store i64 %t525, ptr %l213, !tbaa !24
  br label %bb118
bb118:
  %t526 = load ptr, ptr %lp3
  %t527 = getelementptr %"compiler/prompt:cell", ptr %t526, i32 0, i32 0
  %t528 = load { i64, ptr }, ptr %t527, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 1
  %t531 = extractvalue { i64, ptr } %t528, 0
  %t532 = load i64, ptr %l213
  %t533 = inttoptr i64 %t532 to ptr
  %t534 = call ptr @__olang_held_alloc(ptr %t533, i64 %t531)
  call void @olang_textcopy(ptr %t534, ptr %t530, i64 %t531)
  %t535 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t534, 1
  %t538 = getelementptr %"compiler/prompt:item", ptr %l27, i32 0, i32 2
  %t539 = load i64, ptr %t538, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t541 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t544 = call %"compiler/prompt:Decl" @compiler_2fprompt_3aDecl_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t540, { i64, ptr } %t541, { i64, ptr } %t536, i64 %t539)
  store %"compiler/prompt:Decl" %t544, ptr %l219
  br label %bb119
bb119:
  %t545 = load ptr, ptr %l195, !tbaa !29
  %t546 = load %"compiler/prompt:Decl", ptr %l219
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2ePush_3ccompiler_2fprompt_3aDecl_3e(ptr %v3, ptr %v3, ptr %t545, %"compiler/prompt:Decl" %t546)
  br label %bb120
bb120:
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t547 = load i64, ptr %l26, !tbaa !24
  %t550 = add i64 %t547, 1
  store i64 %t550, ptr %l26, !tbaa !24
  br label %bb93
bb123:
  %t552 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t552, ptr %l223
  br label %bb124
bb124:
  %t553 = load %"std/prelude/text:StringBuilder", ptr %l223
  store %"std/prelude/text:StringBuilder" %t553, ptr %l28
  br label %bb125
bb125:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %lp8
  %t556 = load ptr, ptr %lp9
  %t557 = load ptr, ptr %lp3
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eattempt(ptr %t558, ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v4, ptr %t554, ptr %t555, ptr %t556, ptr %t557)
  call void @llvm.memmove.p0.p0.i64(ptr %l228, ptr %t558, i64 144, i1 false)
  br label %bb126
bb126:
  %t563 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l229, ptr %t563, i64 144, i1 false)
  %t564 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t564, ptr %l228, i64 144, i1 false)
  %t565 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t565, label %bb127, label %bb128
bb127:
  %t567 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 1
  %t568 = load { i64, ptr }, ptr %t567
  %t569 = extractvalue { i64, ptr } %t568, 1
  call void @__olang_region_release(ptr %t569)
  store { i64, ptr } zeroinitializer, ptr %t567
  br label %bb128
bb128:
  %t570 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e3
  br i1 %t570, label %bb129, label %bb130
bb129:
  %t572 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 3
  %t573 = load { i64, ptr }, ptr %t572
  %t574 = extractvalue { i64, ptr } %t573, 1
  call void @__olang_region_release(ptr %t574)
  store { i64, ptr } zeroinitializer, ptr %t572
  br label %bb130
bb130:
  %t575 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t575, label %bb131, label %bb132
bb131:
  %t577 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 4
  %t578 = load { i64, ptr }, ptr %t577
  %t579 = extractvalue { i64, ptr } %t578, 1
  call void @__olang_region_release(ptr %t579)
  store { i64, ptr } zeroinitializer, ptr %t577
  br label %bb132
bb132:
  %t580 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e5
  br i1 %t580, label %bb133, label %bb134
bb133:
  %t582 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 5
  %t583 = load { i64, ptr }, ptr %t582
  %t584 = extractvalue { i64, ptr } %t583, 1
  call void @__olang_region_release(ptr %t584)
  store { i64, ptr } zeroinitializer, ptr %t582
  br label %bb134
bb134:
  %t585 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e6
  br i1 %t585, label %bb135, label %bb136
bb135:
  %t587 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 6
  %t588 = load { i64, ptr }, ptr %t587
  %t589 = extractvalue { i64, ptr } %t588, 1
  call void @__olang_region_release(ptr %t589)
  store { i64, ptr } zeroinitializer, ptr %t587
  br label %bb136
bb136:
  %t590 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e7
  br i1 %t590, label %bb137, label %bb138
bb137:
  %t592 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 7
  %t593 = load { i64, ptr }, ptr %t592
  %t594 = extractvalue { i64, ptr } %t593, 1
  call void @__olang_region_release(ptr %t594)
  store { i64, ptr } zeroinitializer, ptr %t592
  br label %bb138
bb138:
  %t595 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e8
  br i1 %t595, label %bb139, label %bb140
bb139:
  %t597 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 8
  %t598 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t597, i32 0, i32 0
  %t599 = load { i64, ptr }, ptr %t598
  %t600 = extractvalue { i64, ptr } %t599, 1
  %t601 = call ptr @__olang_region_or(ptr %t600, ptr null)
  %t602 = call ptr @__olang_region_home(ptr %t601)
  %t603 = icmp ne ptr %t602, null
  %t604 = select i1 %t603, ptr %t602, ptr null
  call void @__olang_region_drop(ptr %t604)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t597
  br label %bb140
bb140:
  %t605 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t605, label %bb141, label %bb142
bb141:
  %t607 = getelementptr %"compiler/prompt:Reply", ptr %l229, i32 0, i32 8
  %t608 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t607, i32 0, i32 0
  %t609 = load { i64, ptr }, ptr %t608
  %t610 = extractvalue { i64, ptr } %t609, 0
  %t611 = extractvalue { i64, ptr } %t609, 1
  call void @__olang_region_release_part(ptr %t611, i64 %t610)
  store { i64, ptr } zeroinitializer, ptr %t608
  br label %bb142
bb142:
  %t612 = load ptr, ptr %lp7
  %t613 = getelementptr %"compiler/prompt:Reply", ptr %t612, i32 0, i32 8
  %t615 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t613)
  store i64 %t615, ptr %l239
  br label %bb143
bb143:
  %t616 = load i64, ptr %l239, !tbaa !24
  %t617 = icmp sgt i64 %t616, 0
  br i1 %t617, label %bb144, label %bb145
bb144:
  %t619 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t619, ptr %l241
  br label %bb146
bb145:
  br label %bb175
bb146:
  %t620 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t620, ptr %lp29
  %t621 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l241
  %t622 = load ptr, ptr %lp29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t621, ptr %t622
  %t623 = load ptr, ptr %lp9
  store ptr %t623, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb147
bb147:
  %t625 = load i64, ptr %l31, !tbaa !24
  store i64 %t625, ptr %l243, !tbaa !24
  %t626 = load ptr, ptr %l30, !tbaa !29
  %t628 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t626)
  store i64 %t628, ptr %l245
  br label %bb148
bb148:
  %t629 = load i64, ptr %l243, !tbaa !24
  %t630 = load i64, ptr %l245, !tbaa !24
  %t631 = icmp slt i64 %t629, %t630
  %t633 = xor i1 %t631, true
  br i1 %t633, label %bb149, label %bb150
bb149:
  br label %bb160
bb150:
  br label %bb151
bb151:
  %t635 = load ptr, ptr %l30, !tbaa !29
  %t636 = load i64, ptr %l31, !tbaa !24
  %t639 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t635, i64 %t636)
  store %"compiler/prompt:Value" %t639, ptr %l250
  br label %bb152
bb152:
  %t640 = load %"compiler/prompt:Value", ptr %l250
  store %"compiler/prompt:Value" %t640, ptr %l32
  %t641 = getelementptr %"compiler/prompt:Value", ptr %l32, i32 0, i32 0
  %t642 = load { i64, ptr }, ptr %t641, !tbaa !27
  %t644 = load ptr, ptr %lp7
  %t645 = getelementptr %"compiler/prompt:Reply", ptr %t644, i32 0, i32 8
  %t649 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v3, ptr %v3, ptr %t645, { i64, ptr } %t642)
  store i1 %t649, ptr %l254
  br label %bb153
bb153:
  %t650 = load i1, ptr %l254, !tbaa !21
  br i1 %t650, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s33
  %t651 = getelementptr %"compiler/prompt:Value", ptr %l32, i32 0, i32 0
  %t652 = load { i64, ptr }, ptr %t651, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 1
  %t655 = extractvalue { i64, ptr } %t652, 0
  %t656 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t657 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t658 = add i64 %t655, %t657
  %t659 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t654, i64 %t655)
  %t660 = getelementptr i8, ptr %t659, i64 %t655
  call void @olang_textcopy(ptr %t660, ptr %t656, i64 %t657)
  %t661 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t662 = insertvalue { i64, ptr } %t661, ptr %t659, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %l28, { i64, ptr } %t662)
  br label %bb156
bb155:
  %t666 = load ptr, ptr %lp29
  %t667 = load %"compiler/prompt:Value", ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t666, %"compiler/prompt:Value" %t667)
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s33)
  br label %bb158
bb157:
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t670 = load i64, ptr %l31, !tbaa !24
  %t673 = add i64 %t670, 1
  store i64 %t673, ptr %l31, !tbaa !24
  br label %bb147
bb160:
  %t675 = call ptr @__olang_scope_hold(ptr %v3)
  %t676 = ptrtoint ptr %t675 to i64
  store i64 %t676, ptr %l264, !tbaa !24
  %t677 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2eCell_2elocal_2e9
  br i1 %t677, label %bb161, label %bb162
bb161:
  %t679 = call ptr @__olang_region_make(ptr %v3)
  %t680 = ptrtoint ptr %t679 to i64
  store i64 %t680, ptr %l264, !tbaa !24
  br label %bb162
bb162:
  %t681 = load ptr, ptr %lp29
  %t682 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t681
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t682, ptr %l267
  %t684 = load i64, ptr %l264
  %t685 = inttoptr i64 %t684 to ptr
  %t686 = call ptr @__olang_scope_hold(ptr %t685)
  %t687 = ptrtoint ptr %t686 to i64
  store i64 %t687, ptr %l268, !tbaa !24
  %t688 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t688, label %bb163, label %bb164
bb163:
  %t690 = load i64, ptr %l264
  %t691 = inttoptr i64 %t690 to ptr
  %t692 = call ptr @__olang_region_make_part(ptr %t691)
  %t693 = ptrtoint ptr %t692 to i64
  store i64 %t693, ptr %l268, !tbaa !24
  br label %bb164
bb164:
  %t694 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  %t695 = load { i64, ptr }, ptr %t694, !tbaa !27
  store { i64, ptr } %t695, ptr %l270, !tbaa !27
  %t696 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  store i64 %t697, ptr %l271, !tbaa !24
  %t698 = load i64, ptr %l271, !tbaa !24
  %t699 = mul i64 %t698, 80
  %t700 = load i64, ptr %l268
  %t701 = inttoptr i64 %t700 to ptr
  %t702 = call ptr @__olang_held_alloc(ptr %t701, i64 %t699)
  %t703 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  store { i64, ptr } %t704, ptr %l272, !tbaa !27
  %t705 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t708 = load ptr, ptr %t707, !tbaa !27
  %t709 = load i64, ptr %l271, !tbaa !24
  %t710 = mul i64 %t709, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t706, ptr %t708, i64 %t710, i1 false)
  %t711 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t712 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  store { i64, ptr } %t711, ptr %t712, !tbaa !27
  %t713 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t713, label %bb165, label %bb166
bb165:
  %t715 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  %t716 = load { i64, ptr }, ptr %t715, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t716, 0
  %t719 = icmp eq i64 %t717, 0
  br i1 %t719, label %bb167, label %bb168
bb166:
  %t721 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2eCell_2elocal_2e9
  br i1 %t721, label %bb169, label %bb170
bb167:
  %t723 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t723, !tbaa !27
  br label %bb168
bb168:
  %t724 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  %t725 = load i64, ptr %l268
  %t726 = inttoptr i64 %t725 to ptr
  %t727 = load { i64, ptr }, ptr %t724
  %t728 = extractvalue { i64, ptr } %t727, 1
  %t729 = call ptr @__olang_region_or(ptr %t728, ptr null)
  %t730 = icmp ne ptr %t729, null
  %t731 = select i1 %t730, ptr %t729, ptr null
  call void @__olang_region_settle_in(ptr %t726, ptr %t731)
  br label %bb166
bb169:
  %t732 = load i64, ptr %l264
  %t733 = inttoptr i64 %t732 to ptr
  %t734 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267, i32 0, i32 0
  %t735 = load { i64, ptr }, ptr %t734
  %t736 = extractvalue { i64, ptr } %t735, 1
  %t737 = call ptr @__olang_region_or(ptr %t736, ptr null)
  %t738 = call ptr @__olang_region_home(ptr %t737)
  %t739 = icmp ne ptr %t738, null
  %t740 = select i1 %t739, ptr %t738, ptr null
  call void @__olang_region_settle_in(ptr %t733, ptr %t740)
  br label %bb170
bb170:
  %t741 = load ptr, ptr %lp9
  %t742 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t741
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t742, ptr %l277
  %t743 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267
  %t744 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t743, ptr %t744
  %t745 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2eCell_2elocal_2e9
  br i1 %t745, label %bb171, label %bb172
bb171:
  %t747 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l277, i32 0, i32 0
  %t748 = load { i64, ptr }, ptr %t747
  %t749 = extractvalue { i64, ptr } %t748, 1
  %t750 = call ptr @__olang_region_or(ptr %t749, ptr null)
  %t751 = call ptr @__olang_region_home(ptr %t750)
  %t752 = icmp ne ptr %t751, null
  %t753 = select i1 %t752, ptr %t751, ptr null
  call void @__olang_region_drop(ptr %t753)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l277
  br label %bb172
bb172:
  %t754 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t754, label %bb173, label %bb174
bb173:
  %t756 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l277, i32 0, i32 0
  %t757 = load { i64, ptr }, ptr %t756
  %t758 = extractvalue { i64, ptr } %t757, 0
  %t759 = extractvalue { i64, ptr } %t757, 1
  call void @__olang_region_release_part(ptr %t759, i64 %t758)
  store { i64, ptr } zeroinitializer, ptr %t756
  br label %bb174
bb174:
  br label %bb208
bb175:
  %t760 = load ptr, ptr %lp7
  %t761 = getelementptr %"compiler/prompt:Reply", ptr %t760, i32 0, i32 0
  %t762 = load i1, ptr %t761, !tbaa !21
  br i1 %t762, label %bb176, label %bb177
bb176:
  store i1 true, ptr %l281, !tbaa !21
  br label %bb178
bb177:
  %t764 = load ptr, ptr %lp3
  %t765 = getelementptr %"compiler/prompt:cell", ptr %t764, i32 0, i32 4
  %t766 = load i1, ptr %t765, !tbaa !21
  %t768 = xor i1 %t766, true
  store i1 %t768, ptr %l281, !tbaa !21
  br label %bb178
bb178:
  %t770 = load i1, ptr %l281, !tbaa !21
  br i1 %t770, label %bb179, label %bb180
bb179:
  br label %bb209
bb180:
  br label %bb181
bb181:
  %t771 = load ptr, ptr %lp3
  %t772 = getelementptr %"compiler/prompt:cell", ptr %t771, i32 0, i32 4
  store i1 false, ptr %t772, !tbaa !21
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load ptr, ptr %lp8
  %t775 = load ptr, ptr %lp9
  %t776 = load ptr, ptr %lp3
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eattempt(ptr %t777, ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v4, ptr %t773, ptr %t774, ptr %t775, ptr %t776)
  call void @llvm.memmove.p0.p0.i64(ptr %l288, ptr %t777, i64 144, i1 false)
  br label %bb182
bb182:
  %t782 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 144, i64 8)
  store ptr %t782, ptr %lp34
  %t783 = load ptr, ptr %lp34
  call void @llvm.memmove.p0.p0.i64(ptr %t783, ptr %l288, i64 144, i1 false)
  %t784 = load ptr, ptr %lp34
  %t785 = getelementptr %"compiler/prompt:Reply", ptr %t784, i32 0, i32 0
  %t786 = load i1, ptr %t785, !tbaa !21
  br i1 %t786, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l290, !tbaa !21
  br label %bb187
bb184:
  %t788 = load ptr, ptr %lp34
  %t789 = getelementptr %"compiler/prompt:Reply", ptr %t788, i32 0, i32 1
  %t790 = load { i64, ptr }, ptr %t789, !tbaa !27
  %t792 = call i64 @compiler_2fprompt_2eerrorRows(ptr %v3, { i64, ptr } %t790)
  store i64 %t792, ptr %l292
  br label %bb185
bb185:
  %t793 = load ptr, ptr %lp7
  %t794 = getelementptr %"compiler/prompt:Reply", ptr %t793, i32 0, i32 1
  %t795 = load { i64, ptr }, ptr %t794, !tbaa !27
  %t797 = call i64 @compiler_2fprompt_2eerrorRows(ptr %v3, { i64, ptr } %t795)
  store i64 %t797, ptr %l294
  br label %bb186
bb186:
  %t798 = load i64, ptr %l292, !tbaa !24
  %t799 = load i64, ptr %l294, !tbaa !24
  %t800 = icmp slt i64 %t798, %t799
  store i1 %t800, ptr %l290, !tbaa !21
  br label %bb187
bb187:
  %t802 = load i1, ptr %l290, !tbaa !21
  br i1 %t802, label %bb188, label %bb189
bb188:
  %t803 = load ptr, ptr %lp34
  call void @llvm.memmove.p0.p0.i64(ptr %l296, ptr %t803, i64 144, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fprompt_3aReply(ptr %t804, ptr %v3, ptr %l296)
  call void @llvm.memmove.p0.p0.i64(ptr %l298, ptr %t804, i64 144, i1 false)
  br label %bb190
bb189:
  br label %bb207
bb190:
  %t806 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l299, ptr %t806, i64 144, i1 false)
  %t807 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t807, ptr %l298, i64 144, i1 false)
  %t808 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t808, label %bb191, label %bb192
bb191:
  %t810 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 1
  %t811 = load { i64, ptr }, ptr %t810
  %t812 = extractvalue { i64, ptr } %t811, 1
  call void @__olang_region_release(ptr %t812)
  store { i64, ptr } zeroinitializer, ptr %t810
  br label %bb192
bb192:
  %t813 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e3
  br i1 %t813, label %bb193, label %bb194
bb193:
  %t815 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 3
  %t816 = load { i64, ptr }, ptr %t815
  %t817 = extractvalue { i64, ptr } %t816, 1
  call void @__olang_region_release(ptr %t817)
  store { i64, ptr } zeroinitializer, ptr %t815
  br label %bb194
bb194:
  %t818 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t818, label %bb195, label %bb196
bb195:
  %t820 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 4
  %t821 = load { i64, ptr }, ptr %t820
  %t822 = extractvalue { i64, ptr } %t821, 1
  call void @__olang_region_release(ptr %t822)
  store { i64, ptr } zeroinitializer, ptr %t820
  br label %bb196
bb196:
  %t823 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e5
  br i1 %t823, label %bb197, label %bb198
bb197:
  %t825 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 5
  %t826 = load { i64, ptr }, ptr %t825
  %t827 = extractvalue { i64, ptr } %t826, 1
  call void @__olang_region_release(ptr %t827)
  store { i64, ptr } zeroinitializer, ptr %t825
  br label %bb198
bb198:
  %t828 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e6
  br i1 %t828, label %bb199, label %bb200
bb199:
  %t830 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 6
  %t831 = load { i64, ptr }, ptr %t830
  %t832 = extractvalue { i64, ptr } %t831, 1
  call void @__olang_region_release(ptr %t832)
  store { i64, ptr } zeroinitializer, ptr %t830
  br label %bb200
bb200:
  %t833 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e7
  br i1 %t833, label %bb201, label %bb202
bb201:
  %t835 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 7
  %t836 = load { i64, ptr }, ptr %t835
  %t837 = extractvalue { i64, ptr } %t836, 1
  call void @__olang_region_release(ptr %t837)
  store { i64, ptr } zeroinitializer, ptr %t835
  br label %bb202
bb202:
  %t838 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e8
  br i1 %t838, label %bb203, label %bb204
bb203:
  %t840 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 8
  %t841 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t840, i32 0, i32 0
  %t842 = load { i64, ptr }, ptr %t841
  %t843 = extractvalue { i64, ptr } %t842, 1
  %t844 = call ptr @__olang_region_or(ptr %t843, ptr null)
  %t845 = call ptr @__olang_region_home(ptr %t844)
  %t846 = icmp ne ptr %t845, null
  %t847 = select i1 %t846, ptr %t845, ptr null
  call void @__olang_region_drop(ptr %t847)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t840
  br label %bb204
bb204:
  %t848 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t848, label %bb205, label %bb206
bb205:
  %t850 = getelementptr %"compiler/prompt:Reply", ptr %l299, i32 0, i32 8
  %t851 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t850, i32 0, i32 0
  %t852 = load { i64, ptr }, ptr %t851
  %t853 = extractvalue { i64, ptr } %t852, 0
  %t854 = extractvalue { i64, ptr } %t852, 1
  call void @__olang_region_release_part(ptr %t854, i64 %t853)
  store { i64, ptr } zeroinitializer, ptr %t851
  br label %bb206
bb206:
  br label %bb207
bb207:
  br label %bb209
bb208:
  br label %bb125
bb209:
  %t855 = call ptr @__olang_scope_hold(ptr %v3)
  %t856 = ptrtoint ptr %t855 to i64
  store i64 %t856, ptr %l308, !tbaa !24
  %t857 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e5
  br i1 %t857, label %bb210, label %bb211
bb210:
  %t859 = call ptr @__olang_region_make(ptr %v3)
  %t860 = ptrtoint ptr %t859 to i64
  store i64 %t860, ptr %l308, !tbaa !24
  br label %bb211
bb211:
  %t862 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l28)
  store { i64, ptr } %t862, ptr %l311
  br label %bb212
bb212:
  %t863 = load ptr, ptr %lp7
  %t864 = getelementptr %"compiler/prompt:Reply", ptr %t863, i32 0, i32 5
  %t865 = load { i64, ptr }, ptr %t864, !tbaa !27
  %t866 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t870 = extractvalue { i64, ptr } %t865, 1
  %t871 = extractvalue { i64, ptr } %t865, 0
  %t872 = add i64 %t868, %t871
  %t873 = load i64, ptr %l308
  %t874 = inttoptr i64 %t873 to ptr
  %t875 = call ptr @__olang_held_alloc(ptr %t874, i64 %t872)
  call void @olang_textcopy(ptr %t875, ptr %t867, i64 %t868)
  %t876 = getelementptr i8, ptr %t875, i64 %t868
  call void @olang_textcopy(ptr %t876, ptr %t870, i64 %t871)
  %t877 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t875, 1
  %t880 = load ptr, ptr %lp7
  %t881 = getelementptr %"compiler/prompt:Reply", ptr %t880, i32 0, i32 5
  %t882 = load { i64, ptr }, ptr %t881, !tbaa !27
  store { i64, ptr } %t882, ptr %l315, !tbaa !27
  %t884 = load ptr, ptr %lp7
  %t885 = getelementptr %"compiler/prompt:Reply", ptr %t884, i32 0, i32 5
  store { i64, ptr } %t878, ptr %t885, !tbaa !27
  %t886 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e5
  br i1 %t886, label %bb213, label %bb214
bb213:
  %t888 = load { i64, ptr }, ptr %l315
  %t889 = extractvalue { i64, ptr } %t888, 1
  call void @__olang_region_release(ptr %t889)
  store { i64, ptr } zeroinitializer, ptr %l315
  br label %bb214
bb214:
  %t890 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l317, ptr %t890, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l317, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eTypeOf(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca %"compiler/prompt:Reply"
  %l7 = alloca %"compiler/diag:Diagnostics"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/prompt:Value"
  %l12 = alloca i64
  %l17 = alloca %"compiler/prompt:cell"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/prompt:item"
  %l29 = alloca %"compiler/prompt:item"
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l43 = alloca %"compiler/prompt:Reply"
  %l44 = alloca %"compiler/diag:Diagnostics"
  %l45 = alloca ptr
  %l52 = alloca %"compiler/prompt:program"
  %l55 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"compiler/prompt:Reply"
  %l70 = alloca i64
  %l72 = alloca i64
  %l77 = alloca %"compiler/prompt:Value"
  %l79 = alloca i1
  %l82 = alloca { i64, ptr }
  %l87 = alloca %"compiler/prompt:Reply"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t115 = alloca %"compiler/prompt:Reply", align 8
  %t116 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l12, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3acell_2e1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l12, !tbaa !24
  br label %bb2
bb2:
  %t8 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l12
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  %t26 = call %"compiler/prompt:cell" @compiler_2fprompt_3acell_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } %t23)
  store %"compiler/prompt:cell" %t26, ptr %l17
  br label %bb3
bb3:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 104, i64 8)
  store ptr %t27, ptr %lp2
  %t28 = load %"compiler/prompt:cell", ptr %l17
  %t29 = load ptr, ptr %lp2
  store %"compiler/prompt:cell" %t28, ptr %t29
  %t30 = load ptr, ptr %lp2
  %t31 = getelementptr %"compiler/prompt:cell", ptr %t30, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2epieces(ptr %v2, ptr %v2, { i64, ptr } %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l19
  br label %bb4
bb4:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  store ptr %t36, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l23
  br label %bb6
bb6:
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v2, ptr %v2, ptr %t48, i64 %t49)
  store %"compiler/prompt:item" %t52, ptr %l28
  br label %bb10
bb10:
  %t53 = load %"compiler/prompt:item", ptr %l28
  store %"compiler/prompt:item" %t53, ptr %l29
  %t54 = call ptr @__olang_scope_hold(ptr %v2)
  %t55 = ptrtoint ptr %t54 to i64
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = call ptr @__olang_region_make_part(ptr %v2)
  %t59 = ptrtoint ptr %t58 to i64
  store i64 %t59, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t60 = getelementptr %"compiler/prompt:item", ptr %l29, i32 0, i32 5
  %t61 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l32, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l33, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = mul i64 %t65, 16
  %t67 = load i64, ptr %l30
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_held_alloc(ptr %t68, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l34, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = mul i64 %t76, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = getelementptr %"compiler/prompt:item", ptr %l29, i32 0, i32 5
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t79, i32 0, i32 0
  store { i64, ptr } %t78, ptr %t80, !tbaa !27
  %t81 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t81, label %bb13, label %bb14
bb13:
  %t83 = getelementptr %"compiler/prompt:item", ptr %l29, i32 0, i32 5
  %t84 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t83, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t88 = icmp eq i64 %t86, 0
  br i1 %t88, label %bb15, label %bb16
bb14:
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store ptr %t90, ptr %lp5
  %t91 = load %"compiler/prompt:item", ptr %l29
  %t92 = load ptr, ptr %lp5
  store %"compiler/prompt:item" %t91, ptr %t92
  %t93 = load ptr, ptr %lp2
  %t94 = getelementptr %"compiler/prompt:cell", ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %lp5
  %t96 = load %"compiler/prompt:item", ptr %t95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ePush_3ccompiler_2fprompt_3aitem_3e(ptr %v2, ptr %v2, ptr %t94, %"compiler/prompt:item" %t96)
  br label %bb17
bb15:
  %t99 = getelementptr %"compiler/prompt:item", ptr %l29, i32 0, i32 5
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t99, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t100, !tbaa !27
  br label %bb16
bb16:
  %t101 = getelementptr %"compiler/prompt:item", ptr %l29, i32 0, i32 5
  %t102 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t101, i32 0, i32 0
  %t103 = load i64, ptr %l30
  %t104 = inttoptr i64 %t103 to ptr
  %t105 = load { i64, ptr }, ptr %t102
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = call ptr @__olang_region_or(ptr %t106, ptr null)
  %t108 = icmp ne ptr %t107, null
  %t109 = select i1 %t108, ptr %t107, ptr null
  call void @__olang_region_settle_in(ptr %t104, ptr %t109)
  br label %bb14
bb17:
  br label %bb18
bb18:
  %t110 = load i64, ptr %l4, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l4, !tbaa !24
  br label %bb5
bb19:
  call void @compiler_2fprompt_3aReply_2ector(ptr %t115, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t115, i64 144, i1 false)
  br label %bb20
bb20:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l43, i64 144, i1 false)
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t116, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t116, i64 704, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l44, i64 704, i1 false)
  %t117 = getelementptr %"compiler/diag:Diagnostics", ptr %l7, i32 0, i32 25
  store i1 true, ptr %t117, !tbaa !21
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l45, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/prompt:Session", ptr %t120, i32 0, i32 3
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/prompt:Session", ptr %t123, i32 0, i32 4
  %t126 = load ptr, ptr %lp2
  %t131 = call %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %s0, ptr %t119, ptr %t122, ptr %t125, ptr %t126, i1 false)
  store %"compiler/prompt:program" %t131, ptr %l52
  br label %bb22
bb22:
  %t132 = load %"compiler/prompt:program", ptr %l52
  %t133 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 128, i64 8)
  store %"compiler/prompt:program" %t132, ptr %t133
  %t134 = load ptr, ptr %l45, !tbaa !29
  %t137 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t134, ptr %t133, ptr %l7)
  store ptr %t137, ptr %l55
  br label %bb23
bb23:
  %t138 = load ptr, ptr %l55, !tbaa !29
  store ptr %t138, ptr %l8, !tbaa !29
  %t139 = load ptr, ptr %l8, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb24, label %bb25
bb24:
  %t143 = call ptr @__olang_scope_hold(ptr %v2)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l58, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t145, label %bb26, label %bb27
bb25:
  br label %bb31
bb26:
  %t147 = call ptr @__olang_region_make(ptr %v2)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l58, !tbaa !24
  br label %bb27
bb27:
  %t149 = load i64, ptr %l58
  %t150 = inttoptr i64 %t149 to ptr
  %t152 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %t150, ptr %l7)
  store { i64, ptr } %t152, ptr %l61
  br label %bb28
bb28:
  %t153 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t154 = getelementptr %"compiler/prompt:Reply", ptr %l6, i32 0, i32 1
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l63, !tbaa !27
  %t157 = getelementptr %"compiler/prompt:Reply", ptr %l6, i32 0, i32 1
  store { i64, ptr } %t153, ptr %t157, !tbaa !27
  %t158 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t158, label %bb29, label %bb30
bb29:
  %t160 = load { i64, ptr }, ptr %l63
  %t161 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release(ptr %t161)
  store { i64, ptr } zeroinitializer, ptr %l63
  br label %bb30
bb30:
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %l6, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l65, i64 144, i1 false)
  br label %ret
bb31:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l8, !tbaa !29
  %t164 = load ptr, ptr %lp2
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekeptLocals(ptr %v0, ptr %s0, ptr %v2, ptr %t162, ptr %t163, ptr %t164, i1 false)
  br label %bb32
bb32:
  %t168 = getelementptr %"compiler/prompt:Reply", ptr %l6, i32 0, i32 0
  store i1 true, ptr %t168, !tbaa !21
  %t169 = load ptr, ptr %lp2
  %t170 = getelementptr %"compiler/prompt:cell", ptr %t169, i32 0, i32 3
  store ptr %t170, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load i64, ptr %l10, !tbaa !24
  store i64 %t172, ptr %l70, !tbaa !24
  %t173 = load ptr, ptr %l9, !tbaa !29
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t173)
  store i64 %t175, ptr %l72
  br label %bb34
bb34:
  %t176 = load i64, ptr %l70, !tbaa !24
  %t177 = load i64, ptr %l72, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb36:
  br label %bb37
bb37:
  %t182 = load ptr, ptr %l9, !tbaa !29
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t182, i64 %t183)
  store %"compiler/prompt:Value" %t186, ptr %l77
  br label %bb38
bb38:
  %t187 = load %"compiler/prompt:Value", ptr %l77
  store %"compiler/prompt:Value" %t187, ptr %l11
  %t188 = getelementptr %"compiler/prompt:Value", ptr %l11, i32 0, i32 0
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t191 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s7, { i64, ptr } %t189, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t191, ptr %l79
  br label %bb39
bb39:
  %t192 = load i1, ptr %l79, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t195 = getelementptr %"compiler/prompt:Reply", ptr %l6, i32 0, i32 2
  store i1 true, ptr %t195, !tbaa !21
  %t196 = getelementptr %"compiler/prompt:Value", ptr %l11, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t198 = getelementptr %"compiler/prompt:Reply", ptr %l6, i32 0, i32 3
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t201 = getelementptr %"compiler/prompt:Reply", ptr %l6, i32 0, i32 3
  store { i64, ptr } %t197, ptr %t201, !tbaa !27
  %t202 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e3
  br i1 %t202, label %bb43, label %bb44
bb43:
  %t204 = load { i64, ptr }, ptr %l82
  %t205 = extractvalue { i64, ptr } %t204, 1
  call void @__olang_region_release(ptr %t205)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t206 = load i64, ptr %l10, !tbaa !24
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %l10, !tbaa !24
  br label %bb33
bb46:
  call void @llvm.memmove.p0.p0.i64(ptr %l87, ptr %l6, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l87, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eattempt(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/prompt:item"
  %l9 = alloca %"compiler/diag:Diagnostics"
  %l10 = alloca %"compiler/prompt:program"
  %l11 = alloca ptr
  %l12 = alloca %"compiler/diag:Diagnostics"
  %l13 = alloca %"compiler/prompt:program"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l30 = alloca %"compiler/prompt:Reply"
  %l31 = alloca %"compiler/prompt:Reply"
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/prompt:item"
  %l45 = alloca i64
  %l51 = alloca %"compiler/diag:Diagnostics"
  %l56 = alloca %"compiler/prompt:program"
  %l60 = alloca ptr
  %l63 = alloca i64
  %l65 = alloca i64
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/prompt:Reply"
  %l80 = alloca %"compiler/diag:Diagnostics"
  %l85 = alloca %"compiler/prompt:program"
  %l89 = alloca ptr
  %l92 = alloca i64
  %l94 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/prompt:Reply"
  %l110 = alloca ptr
  %l113 = alloca i64
  %l115 = alloca i64
  %l118 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca %"compiler/prompt:Reply"
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca i64
  %l135 = alloca i64
  %l140 = alloca { i64, ptr }
  %l147 = alloca i64
  %l149 = alloca %"compiler/prompt:Reply"
  %l150 = alloca i64
  %l152 = alloca i64
  %l155 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l171 = alloca %"compiler/prompt:Reply"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t21 = alloca %"compiler/prompt:Reply", align 8
  %t26 = alloca %"compiler/prompt:Reply", align 8
  %t66 = alloca %"compiler/diag:Diagnostics", align 8
  %t132 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estartWorker(ptr %v0, ptr %v5, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/prompt:Session", ptr %t10, i32 0, i32 7
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eattemptCompiled(ptr %t21, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %t17, ptr %t18, ptr %t19, ptr %t20)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t21, i64 144, i1 false)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 144, i1 false)
  br label %ret
bb8:
  call void @compiler_2fprompt_3aReply_2ector(ptr %t26, ptr %v4)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t26, i64 144, i1 false)
  br label %bb9
bb9:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 144, i64 8)
  store ptr %t27, ptr %lp4
  %t28 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %l31, i64 144, i1 false)
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/prompt:cell", ptr %t29, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eClear_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t31)
  br label %bb10
bb10:
  store i1 false, ptr %l5, !tbaa !21
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/prompt:cell", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l7, !tbaa !24
  store i64 %t37, ptr %l36, !tbaa !24
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t38)
  store i64 %t40, ptr %l38
  br label %bb12
bb12:
  %t41 = load i64, ptr %l36, !tbaa !24
  %t42 = load i64, ptr %l38, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb13, label %bb14
bb13:
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %v3, ptr %t47, i64 %t48)
  store %"compiler/prompt:item" %t51, ptr %l43
  br label %bb16
bb16:
  %t52 = load %"compiler/prompt:item", ptr %l43
  store %"compiler/prompt:item" %t52, ptr %l8
  %t53 = getelementptr %"compiler/prompt:item", ptr %l8, i32 0, i32 5
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t53)
  store i64 %t55, ptr %l45
  br label %bb17
bb17:
  %t56 = load i64, ptr %l45, !tbaa !24
  %t57 = icmp sgt i64 %t56, 0
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t59, 1
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb11
bb22:
  %t64 = load i1, ptr %l5, !tbaa !21
  br i1 %t64, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t66, ptr %s7, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr %t66, i64 704, i1 false)
  br label %bb25
bb24:
  br label %bb40
bb25:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l51, i64 704, i1 false)
  %t67 = getelementptr %"compiler/diag:Diagnostics", ptr %l9, i32 0, i32 25
  store i1 true, ptr %t67, !tbaa !21
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t76 = call %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s7, ptr %t68, ptr %t69, ptr %t70, ptr %t71, i1 false)
  store %"compiler/prompt:program" %t76, ptr %l56
  br label %bb26
bb26:
  %t77 = load %"compiler/prompt:program", ptr %l56
  store %"compiler/prompt:program" %t77, ptr %l10
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t82 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t78, ptr %l10, ptr %l9)
  store ptr %t82, ptr %l60
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l60, !tbaa !29
  store ptr %t83, ptr %l11, !tbaa !29
  %t84 = load ptr, ptr %l11, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t88 = call ptr @__olang_scope_hold(ptr %v4)
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l63, !tbaa !24
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t90, label %bb30, label %bb31
bb29:
  br label %bb38
bb30:
  %t92 = call ptr @__olang_region_make(ptr %v4)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l63, !tbaa !24
  br label %bb31
bb31:
  %t94 = call ptr @__olang_scope_hold(ptr %s8)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l65, !tbaa !24
  %t96 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t98 = call ptr @__olang_region_make(ptr %s8)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l65, !tbaa !24
  br label %bb33
bb33:
  %t100 = load i64, ptr %l65
  %t101 = inttoptr i64 %t100 to ptr
  %t103 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s7, ptr %t101, ptr %l9)
  store { i64, ptr } %t103, ptr %l68
  br label %bb34
bb34:
  %t104 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = getelementptr %"compiler/prompt:cell", ptr %t105, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l63
  %t110 = inttoptr i64 %t109 to ptr
  %t113 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s8, ptr %v3, ptr %t110, { i64, ptr } %t104, { i64, ptr } %t108)
  store { i64, ptr } %t113, ptr %l72
  br label %bb35
bb35:
  %t114 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t115 = load ptr, ptr %lp4
  %t116 = getelementptr %"compiler/prompt:Reply", ptr %t115, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l74, !tbaa !27
  %t119 = load ptr, ptr %lp4
  %t120 = getelementptr %"compiler/prompt:Reply", ptr %t119, i32 0, i32 1
  store { i64, ptr } %t114, ptr %t120, !tbaa !27
  %t121 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t121, label %bb36, label %bb37
bb36:
  %t123 = load { i64, ptr }, ptr %l74
  %t124 = extractvalue { i64, ptr } %t123, 1
  call void @__olang_region_release(ptr %t124)
  store { i64, ptr } zeroinitializer, ptr %l74
  br label %bb37
bb37:
  %t125 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t125, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l76, i64 144, i1 false)
  br label %ret
bb38:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l11, !tbaa !29
  %t128 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekeptLocals(ptr %v0, ptr %s7, ptr %v3, ptr %t126, ptr %t127, ptr %t128, i1 true)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t132, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l80, ptr %t132, i64 704, i1 false)
  br label %bb41
bb41:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l80, i64 704, i1 false)
  %t133 = getelementptr %"compiler/diag:Diagnostics", ptr %l12, i32 0, i32 25
  store i1 true, ptr %t133, !tbaa !21
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t142 = call %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t134, ptr %t135, ptr %t136, ptr %t137, i1 true)
  store %"compiler/prompt:program" %t142, ptr %l85
  br label %bb42
bb42:
  %t143 = load %"compiler/prompt:program", ptr %l85
  store %"compiler/prompt:program" %t143, ptr %l13
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t144, ptr %l13, ptr %l12)
  store ptr %t148, ptr %l89
  br label %bb43
bb43:
  %t149 = load ptr, ptr %l89, !tbaa !29
  store ptr %t149, ptr %l14, !tbaa !29
  %t150 = load ptr, ptr %l14, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t154 = call ptr @__olang_scope_hold(ptr %v4)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l92, !tbaa !24
  %t156 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t156, label %bb46, label %bb47
bb45:
  br label %bb54
bb46:
  %t158 = call ptr @__olang_region_make(ptr %v4)
  %t159 = ptrtoint ptr %t158 to i64
  store i64 %t159, ptr %l92, !tbaa !24
  br label %bb47
bb47:
  %t160 = call ptr @__olang_scope_hold(ptr %s9)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l94, !tbaa !24
  %t162 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t162, label %bb48, label %bb49
bb48:
  %t164 = call ptr @__olang_region_make(ptr %s9)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l94, !tbaa !24
  br label %bb49
bb49:
  %t166 = load i64, ptr %l94
  %t167 = inttoptr i64 %t166 to ptr
  %t169 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %t167, ptr %l12)
  store { i64, ptr } %t169, ptr %l97
  br label %bb50
bb50:
  %t170 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t173 = getelementptr %"compiler/prompt:cell", ptr %t171, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l92
  %t176 = inttoptr i64 %t175 to ptr
  %t179 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s9, ptr %v3, ptr %t176, { i64, ptr } %t170, { i64, ptr } %t174)
  store { i64, ptr } %t179, ptr %l101
  br label %bb51
bb51:
  %t180 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t181 = load ptr, ptr %lp4
  %t182 = getelementptr %"compiler/prompt:Reply", ptr %t181, i32 0, i32 1
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l103, !tbaa !27
  %t185 = load ptr, ptr %lp4
  %t186 = getelementptr %"compiler/prompt:Reply", ptr %t185, i32 0, i32 1
  store { i64, ptr } %t180, ptr %t186, !tbaa !27
  %t187 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t187, label %bb52, label %bb53
bb52:
  %t189 = load { i64, ptr }, ptr %l103
  %t190 = extractvalue { i64, ptr } %t189, 1
  call void @__olang_region_release(ptr %t190)
  store { i64, ptr } zeroinitializer, ptr %l103
  br label %bb53
bb53:
  %t191 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l105, ptr %t191, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l105, i64 144, i1 false)
  br label %ret
bb54:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l14, !tbaa !29
  %t194 = load ptr, ptr %lp4
  %t199 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2emachine(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %s0, ptr %t192, ptr %t193, ptr %l12, ptr %t194)
  store ptr %t199, ptr %l110
  br label %bb55
bb55:
  %t200 = load ptr, ptr %l110, !tbaa !29
  store ptr %t200, ptr %l15, !tbaa !29
  %t201 = load ptr, ptr %l15, !tbaa !29
  %t203 = icmp eq ptr %t201, null
  br i1 %t203, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t205 = call ptr @__olang_scope_hold(ptr %v4)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l113, !tbaa !24
  %t207 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t207, label %bb58, label %bb59
bb57:
  br label %bb66
bb58:
  %t209 = call ptr @__olang_region_make(ptr %v4)
  %t210 = ptrtoint ptr %t209 to i64
  store i64 %t210, ptr %l113, !tbaa !24
  br label %bb59
bb59:
  %t211 = call ptr @__olang_scope_hold(ptr %s10)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l115, !tbaa !24
  %t213 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t213, label %bb60, label %bb61
bb60:
  %t215 = call ptr @__olang_region_make(ptr %s10)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l115, !tbaa !24
  br label %bb61
bb61:
  %t217 = load i64, ptr %l115
  %t218 = inttoptr i64 %t217 to ptr
  %t220 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %t218, ptr %l12)
  store { i64, ptr } %t220, ptr %l118
  br label %bb62
bb62:
  %t221 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t222 = load ptr, ptr %l3, !tbaa !29
  %t224 = getelementptr %"compiler/prompt:cell", ptr %t222, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l113
  %t227 = inttoptr i64 %t226 to ptr
  %t230 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s10, ptr %v3, ptr %t227, { i64, ptr } %t221, { i64, ptr } %t225)
  store { i64, ptr } %t230, ptr %l122
  br label %bb63
bb63:
  %t231 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t232 = load ptr, ptr %lp4
  %t233 = getelementptr %"compiler/prompt:Reply", ptr %t232, i32 0, i32 1
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l124, !tbaa !27
  %t236 = load ptr, ptr %lp4
  %t237 = getelementptr %"compiler/prompt:Reply", ptr %t236, i32 0, i32 1
  store { i64, ptr } %t231, ptr %t237, !tbaa !27
  %t238 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t240 = load { i64, ptr }, ptr %l124
  %t241 = extractvalue { i64, ptr } %t240, 1
  call void @__olang_region_release(ptr %t241)
  store { i64, ptr } zeroinitializer, ptr %l124
  br label %bb65
bb65:
  %t242 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l126, ptr %t242, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l126, i64 144, i1 false)
  br label %ret
bb66:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l14, !tbaa !29
  %t245 = load ptr, ptr %l15, !tbaa !29
  %t246 = load ptr, ptr %l2, !tbaa !29
  %t251 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2emismatched(ptr %v0, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %t243, ptr %t244, ptr %t245, ptr %t246)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l131
  br label %bb67
bb67:
  %t252 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  %t253 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t252, ptr %t253
  store ptr %t253, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb68
bb68:
  %t255 = load i64, ptr %l17, !tbaa !24
  store i64 %t255, ptr %l133, !tbaa !24
  %t256 = load ptr, ptr %l16, !tbaa !29
  %t258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t256)
  store i64 %t258, ptr %l135
  br label %bb69
bb69:
  %t259 = load i64, ptr %l133, !tbaa !24
  %t260 = load i64, ptr %l135, !tbaa !24
  %t261 = icmp slt i64 %t259, %t260
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb70, label %bb71
bb70:
  br label %bb76
bb71:
  br label %bb72
bb72:
  %t265 = load ptr, ptr %l16, !tbaa !29
  %t266 = load i64, ptr %l17, !tbaa !24
  %t269 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t265, i64 %t266)
  store { i64, ptr } %t269, ptr %l140
  br label %bb73
bb73:
  %t270 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t271 = load ptr, ptr %lp4
  %t272 = getelementptr %"compiler/prompt:Reply", ptr %t271, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t272, { i64, ptr } %t270)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t276 = load i64, ptr %l17, !tbaa !24
  %t279 = add i64 %t276, 1
  store i64 %t279, ptr %l17, !tbaa !24
  br label %bb68
bb76:
  %t281 = load ptr, ptr %lp4
  %t282 = getelementptr %"compiler/prompt:Reply", ptr %t281, i32 0, i32 8
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t282)
  store i64 %t284, ptr %l147
  br label %bb77
bb77:
  %t285 = load i64, ptr %l147, !tbaa !24
  %t286 = icmp sgt i64 %t285, 0
  br i1 %t286, label %bb78, label %bb79
bb78:
  %t288 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l149, ptr %t288, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l149, i64 144, i1 false)
  br label %ret
bb79:
  br label %bb80
bb80:
  %t289 = load ptr, ptr %lp4
  %t290 = getelementptr %"compiler/prompt:Reply", ptr %t289, i32 0, i32 0
  store i1 true, ptr %t290, !tbaa !21
  %t291 = call ptr @__olang_scope_hold(ptr %v4)
  %t292 = ptrtoint ptr %t291 to i64
  store i64 %t292, ptr %l150, !tbaa !24
  %t293 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t293, label %bb81, label %bb82
bb81:
  %t295 = call ptr @__olang_region_make(ptr %v4)
  %t296 = ptrtoint ptr %t295 to i64
  store i64 %t296, ptr %l150, !tbaa !24
  br label %bb82
bb82:
  %t297 = call ptr @__olang_scope_hold(ptr %s0)
  %t298 = ptrtoint ptr %t297 to i64
  store i64 %t298, ptr %l152, !tbaa !24
  %t299 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t299, label %bb83, label %bb84
bb83:
  %t301 = call ptr @__olang_region_make(ptr %s0)
  %t302 = ptrtoint ptr %t301 to i64
  store i64 %t302, ptr %l152, !tbaa !24
  br label %bb84
bb84:
  %t303 = load i64, ptr %l152
  %t304 = inttoptr i64 %t303 to ptr
  %t306 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %s0, ptr %t304, ptr %l12)
  store { i64, ptr } %t306, ptr %l155
  br label %bb85
bb85:
  %t307 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t308 = load ptr, ptr %l3, !tbaa !29
  %t310 = getelementptr %"compiler/prompt:cell", ptr %t308, i32 0, i32 0
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  %t312 = load i64, ptr %l150
  %t313 = inttoptr i64 %t312 to ptr
  %t316 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s0, ptr %v3, ptr %t313, { i64, ptr } %t307, { i64, ptr } %t311)
  store { i64, ptr } %t316, ptr %l159
  br label %bb86
bb86:
  %t317 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t318 = load ptr, ptr %lp4
  %t319 = getelementptr %"compiler/prompt:Reply", ptr %t318, i32 0, i32 1
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  store { i64, ptr } %t320, ptr %l161, !tbaa !27
  %t322 = load ptr, ptr %lp4
  %t323 = getelementptr %"compiler/prompt:Reply", ptr %t322, i32 0, i32 1
  store { i64, ptr } %t317, ptr %t323, !tbaa !27
  %t324 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t324, label %bb87, label %bb88
bb87:
  %t326 = load { i64, ptr }, ptr %l161
  %t327 = extractvalue { i64, ptr } %t326, 1
  call void @__olang_region_release(ptr %t327)
  store { i64, ptr } zeroinitializer, ptr %l161
  br label %bb88
bb88:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l14, !tbaa !29
  %t330 = load ptr, ptr %l15, !tbaa !29
  %t331 = load ptr, ptr %l1, !tbaa !29
  %t332 = load ptr, ptr %l2, !tbaa !29
  %t333 = load ptr, ptr %l3, !tbaa !29
  %t334 = load ptr, ptr %lp4
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erun(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t328, ptr %t329, ptr %t330, ptr %l12, ptr %t331, ptr %t332, ptr %t333, ptr %t334)
  br label %bb89
bb89:
  %t343 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l171, ptr %t343, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l171, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eattemptCompiled(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/prompt:Value"
  %l9 = alloca %"compiler/diag:Diagnostics"
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/prompt:Value"
  %l15 = alloca %"compiler/prompt:Reply"
  %l20 = alloca i1
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/prompt:Value"
  %l44 = alloca %"compiler/prompt:Reply"
  %l45 = alloca %"compiler/diag:Diagnostics"
  %l46 = alloca ptr
  %l51 = alloca %"compiler/prompt:program"
  %l54 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca %"compiler/prompt:Reply"
  %l74 = alloca ptr
  %l76 = alloca i64
  %l85 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l101 = alloca i64
  %l103 = alloca i64
  %l108 = alloca %"compiler/prompt:Value"
  %l110 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l119 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i64
  %l131 = alloca i64
  %l133 = alloca %"compiler/prompt:Reply"
  %l140 = alloca %"compiler/prompt:Reply"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %t1 = alloca %"compiler/prompt:Reply", align 8
  %t64 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fprompt_3aReply_2ector(ptr %t1, ptr %v4)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t1, i64 144, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 144, i64 8)
  store ptr %t2, ptr %lp4
  %t3 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l15, i64 144, i1 false)
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/prompt:cell", ptr %t4, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eClear_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t6)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i1 @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eprobes(ptr %v0, ptr %v3, ptr %v5, ptr %t8, ptr %t9)
  store i1 %t12, ptr %l20
  br label %bb3
bb3:
  %t13 = load i1, ptr %l20, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l22
  br label %bb6
bb5:
  br label %bb17
bb6:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t17, ptr %lp5
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  %t19 = load ptr, ptr %lp5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %t19
  %t20 = load ptr, ptr %l2, !tbaa !29
  store ptr %t20, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t22 = load i64, ptr %l7, !tbaa !24
  store i64 %t22, ptr %l24, !tbaa !24
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t23)
  store i64 %t25, ptr %l26
  br label %bb8
bb8:
  %t26 = load i64, ptr %l24, !tbaa !24
  %t27 = load i64, ptr %l26, !tbaa !24
  %t28 = icmp slt i64 %t26, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t32, i64 %t33)
  store %"compiler/prompt:Value" %t36, ptr %l31
  br label %bb12
bb12:
  %t37 = load %"compiler/prompt:Value", ptr %l31
  store %"compiler/prompt:Value" %t37, ptr %l8
  %t38 = load ptr, ptr %lp5
  %t39 = getelementptr %"compiler/prompt:Value", ptr %l8, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/prompt:Value", ptr %l8, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v2, ptr %v2, ptr %t38, { i64, ptr } %t40, { i64, ptr } %t42)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l7, !tbaa !24
  br label %bb7
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t55 = load ptr, ptr %lp5
  %t56 = load ptr, ptr %lp4
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erunCompiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v0, ptr %v4, ptr %t51, ptr %t52, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  br label %bb16
bb16:
  %t63 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t63, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l44, i64 144, i1 false)
  br label %ret
bb17:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t64, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t64, i64 704, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l45, i64 704, i1 false)
  %t65 = getelementptr %"compiler/diag:Diagnostics", ptr %l9, i32 0, i32 25
  store i1 true, ptr %t65, !tbaa !21
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l46, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t75 = call %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t67, ptr %t68, ptr %t69, ptr %t70, i1 false)
  store %"compiler/prompt:program" %t75, ptr %l51
  br label %bb19
bb19:
  %t76 = load %"compiler/prompt:program", ptr %l51
  %t77 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 128, i64 8)
  store %"compiler/prompt:program" %t76, ptr %t77
  %t78 = load ptr, ptr %l46, !tbaa !29
  %t81 = call ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t78, ptr %t77, ptr %l9)
  store ptr %t81, ptr %l54
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l54, !tbaa !29
  store ptr %t82, ptr %l10, !tbaa !29
  %t83 = load ptr, ptr %l10, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = call ptr @__olang_scope_hold(ptr %v4)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l57, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t89, label %bb23, label %bb24
bb22:
  br label %bb31
bb23:
  %t91 = call ptr @__olang_region_make(ptr %v4)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l57, !tbaa !24
  br label %bb24
bb24:
  %t93 = call ptr @__olang_scope_hold(ptr %s5)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l59, !tbaa !24
  %t95 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t97 = call ptr @__olang_region_make(ptr %s5)
  %t98 = ptrtoint ptr %t97 to i64
  store i64 %t98, ptr %l59, !tbaa !24
  br label %bb26
bb26:
  %t99 = load i64, ptr %l59
  %t100 = inttoptr i64 %t99 to ptr
  %t102 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %t100, ptr %l9)
  store { i64, ptr } %t102, ptr %l62
  br label %bb27
bb27:
  %t103 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/prompt:cell", ptr %t104, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l57
  %t109 = inttoptr i64 %t108 to ptr
  %t112 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s5, ptr %v3, ptr %t109, { i64, ptr } %t103, { i64, ptr } %t107)
  store { i64, ptr } %t112, ptr %l66
  br label %bb28
bb28:
  %t113 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t114 = load ptr, ptr %lp4
  %t115 = getelementptr %"compiler/prompt:Reply", ptr %t114, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l68, !tbaa !27
  %t118 = load ptr, ptr %lp4
  %t119 = getelementptr %"compiler/prompt:Reply", ptr %t118, i32 0, i32 1
  store { i64, ptr } %t113, ptr %t119, !tbaa !27
  %t120 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t122 = load { i64, ptr }, ptr %l68
  %t123 = extractvalue { i64, ptr } %t122, 1
  call void @__olang_region_release(ptr %t123)
  store { i64, ptr } zeroinitializer, ptr %l68
  br label %bb30
bb30:
  %t124 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l70, ptr %t124, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l70, i64 144, i1 false)
  br label %ret
bb31:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l10, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekeptLocals(ptr %v0, ptr %s0, ptr %v3, ptr %t125, ptr %t126, ptr %t127, i1 true)
  br label %bb32
bb32:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l74, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @__olang_scope_or(ptr %v5, ptr %t132)
  %t135 = call ptr @__olang_scope_hold(ptr %t134)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l76, !tbaa !24
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t143, i32 0, i32 10
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/load:Loader", ptr %t152, i32 0, i32 12
  %t155 = load i64, ptr %t154, !tbaa !24
  %t158 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %s0, ptr %s0, ptr %t145, i64 %t155)
  store ptr %t158, ptr %l85
  br label %bb33
bb33:
  %t159 = load ptr, ptr %l85, !tbaa !29
  %t161 = getelementptr %"compiler/load:Module", ptr %t159, i32 0, i32 2
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = extractvalue { i64, ptr } %t162, 0
  call void @__olang_sb_put(ptr %s6, ptr %t164, i64 %t165)
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call ptr @__olang_scope_or(ptr %v5, ptr %t166)
  %t169 = call ptr @__olang_scope_hold(ptr %t168)
  %t170 = ptrtoint ptr %t169 to i64
  %t171 = load ptr, ptr %s6
  %t172 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t173 = load i64, ptr %t172
  %t175 = inttoptr i64 %t170 to ptr
  %t176 = call ptr @__olang_held_alloc(ptr %t175, i64 %t173)
  call void @olang_textcopy(ptr %t176, ptr %t171, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l90, !tbaa !27
  %t179 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t180 = load ptr, ptr %t179
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %sbgrew.182, label %sbdone.183
sbgrew.182:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.183
sbdone.183:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call ptr @__olang_scope_or(ptr %v5, ptr %t184)
  %t187 = call ptr @__olang_scope_hold(ptr %t186)
  %t188 = ptrtoint ptr %t187 to i64
  %t189 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t191 = inttoptr i64 %t188 to ptr
  %t192 = extractvalue { i64, ptr } %t189, 0
  %t193 = extractvalue { i64, ptr } %t189, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_held_alloc(ptr %t191, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load ptr, ptr %l74, !tbaa !29
  %t199 = getelementptr %"compiler/prompt:Session", ptr %t198, i32 0, i32 11
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  store { i64, ptr } %t200, ptr %l94, !tbaa !27
  %t202 = load ptr, ptr %l74, !tbaa !29
  %t203 = getelementptr %"compiler/prompt:Session", ptr %t202, i32 0, i32 11
  store { i64, ptr } %t197, ptr %t203, !tbaa !27
  %t204 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e11
  br i1 %t204, label %bb34, label %bb35
bb34:
  %t206 = load { i64, ptr }, ptr %l94
  %t207 = extractvalue { i64, ptr } %t206, 1
  call void @__olang_region_release(ptr %t207)
  store { i64, ptr } zeroinitializer, ptr %l94
  br label %bb35
bb35:
  %t208 = load ptr, ptr %l10, !tbaa !29
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t210 = load ptr, ptr %l2, !tbaa !29
  %t214 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fprompt_2elayouts(ptr %s0, ptr %v1, ptr %v2, ptr %v0, ptr %t208, ptr %t209, ptr %t210)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t214, ptr %l99
  br label %bb36
bb36:
  %t215 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t215, ptr %lp11
  %t216 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l99
  %t217 = load ptr, ptr %lp11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t216, ptr %t217
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb37
bb37:
  %t218 = load ptr, ptr %l2, !tbaa !29
  store ptr %t218, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t220 = load i64, ptr %l13, !tbaa !24
  store i64 %t220, ptr %l101, !tbaa !24
  %t221 = load ptr, ptr %l12, !tbaa !29
  %t223 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t221)
  store i64 %t223, ptr %l103
  br label %bb39
bb39:
  %t224 = load i64, ptr %l101, !tbaa !24
  %t225 = load i64, ptr %l103, !tbaa !24
  %t226 = icmp slt i64 %t224, %t225
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb41:
  br label %bb42
bb42:
  %t230 = load ptr, ptr %l12, !tbaa !29
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t230, i64 %t231)
  store %"compiler/prompt:Value" %t234, ptr %l108
  br label %bb43
bb43:
  %t235 = load %"compiler/prompt:Value", ptr %l108
  store %"compiler/prompt:Value" %t235, ptr %l14
  %t236 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 5
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s8, { i64, ptr } %t237, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t239, ptr %l110
  br label %bb44
bb44:
  %t240 = load i1, ptr %l110, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb45, label %bb46
bb45:
  %t243 = load ptr, ptr %lp11
  %t244 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 0
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t248 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v2, ptr %v0, ptr %t243, { i64, ptr } %t245)
  %t249 = extractvalue { i32, { i64, ptr } } %t248, 1
  %t250 = extractvalue { i32, { i64, ptr } } %t248, 0
  store i32 %t250, ptr %l117
  %t251 = icmp ne i32 %t250, 0
  br i1 %t251, label %bb48, label %ok.252, !prof !99
ok.252:
  store { i64, ptr } %t249, ptr %l116
  br label %bb47
bb46:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb52
bb47:
  %t253 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t253, ptr %l113, !tbaa !27
  br label %bb50
bb48:
  br label %bb49
bb49:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l113, !tbaa !27
  br label %bb50
bb50:
  %t254 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 4
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t258 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t256, { i64, ptr } %t255)
  store i1 %t258, ptr %l119
  br label %bb51
bb51:
  %t259 = load i1, ptr %l119, !tbaa !21
  %t260 = xor i1 %t259, true
  store i1 %t260, ptr %l112, !tbaa !21
  br label %bb52
bb52:
  %t262 = load i1, ptr %l112, !tbaa !21
  br i1 %t262, label %bb53, label %bb54
bb53:
  %t263 = load ptr, ptr %lp4
  %t264 = getelementptr %"compiler/prompt:Reply", ptr %t263, i32 0, i32 8
  store ptr %t264, ptr %l121, !tbaa !29
  %t265 = call ptr @__olang_scope_hold(ptr %v4)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l122, !tbaa !24
  %t267 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t267, label %bb55, label %bb56
bb54:
  br label %bb58
bb55:
  %t269 = call ptr @__olang_region_make(ptr %v4)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l122, !tbaa !24
  br label %bb56
bb56:
  %t271 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = extractvalue { i64, ptr } %t272, 0
  %t276 = load i64, ptr %l122
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = call ptr @__olang_held_alloc(ptr %t277, i64 %t275)
  call void @olang_textcopy(ptr %t278, ptr %t274, i64 %t275)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t282 = load ptr, ptr %l121, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t282, { i64, ptr } %t280)
  br label %bb57
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb59:
  %t284 = load i64, ptr %l13, !tbaa !24
  %t287 = add i64 %t284, 1
  store i64 %t287, ptr %l13, !tbaa !24
  br label %bb38
bb60:
  %t289 = load ptr, ptr %lp4
  %t290 = getelementptr %"compiler/prompt:Reply", ptr %t289, i32 0, i32 8
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t290)
  store i64 %t292, ptr %l131
  br label %bb61
bb61:
  %t293 = load i64, ptr %l131, !tbaa !24
  %t294 = icmp sgt i64 %t293, 0
  br i1 %t294, label %bb62, label %bb63
bb62:
  %t296 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l133, ptr %t296, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l133, i64 144, i1 false)
  br label %ret
bb63:
  br label %bb64
bb64:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t301 = load ptr, ptr %lp11
  %t302 = load ptr, ptr %lp4
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erunCompiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v0, ptr %v4, ptr %t297, ptr %t298, ptr %t299, ptr %t300, ptr %t301, ptr %t302)
  br label %bb65
bb65:
  %t309 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l140, ptr %t309, i64 144, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l140, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2echeck(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l17 = alloca %"compiler/cond:Consts"
  %l19 = alloca %"compiler/cond:Consts"
  %l20 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l36 = alloca %"compiler/fetch:Fetcher"
  %l38 = alloca %"compiler/source:Names"
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca %"compiler/load:Loader"
  %l50 = alloca ptr
  %l51 = alloca i64
  %l58 = alloca { i64, ptr }
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l83 = alloca { i64, ptr }
  %l87 = alloca i64
  %l91 = alloca ptr
  %l96 = alloca ptr
  %l98 = alloca i64
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/views:Kept"
  %l112 = alloca %"compiler/check:Checker"
  %l115 = alloca i64
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t20 = alloca %"compiler/cond:Consts", align 8
  %t80 = alloca %"compiler/fetch:Fetcher", align 8
  %t113 = alloca %"compiler/load:Loader", align 8
  %t257 = alloca %"compiler/views:Kept", align 8
  %t259 = alloca %"compiler/check:Checker", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t11, ptr %lp3
  %t13 = load ptr, ptr %lp3
  store { i64, ptr } %t10, ptr %t13, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/prompt:Session", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/build:Config", ptr %t17, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t19, i64 256, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcond_3aConsts(ptr %t20, ptr %v3, ptr %l17)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t20, i64 256, i1 false)
  br label %bb1
bb1:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 256, i64 8)
  store ptr %t22, ptr %lp4
  %t23 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %l19, i64 256, i1 false)
  %t24 = call ptr @__olang_scope_hold(ptr %v3)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = call ptr @__olang_region_make(ptr %v3)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l20, !tbaa !24
  br label %bb3
bb3:
  %t30 = load ptr, ptr %lp3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l20
  %t33 = inttoptr i64 %t32 to ptr
  %t35 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v3, ptr %t33, { i64, ptr } %t31)
  store { i64, ptr } %t35, ptr %l23
  br label %bb4
bb4:
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t37 = load i64, ptr %l20
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = extractvalue { i64, ptr } %t36, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_held_alloc(ptr %t38, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l25, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = call ptr @__olang_region_make(ptr %v3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t51 = load i64, ptr %l25
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %t52)
  store { i64, ptr } %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  %t55 = call ptr @__olang_scope_hold(ptr %v3)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l29, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e2
  br i1 %t57, label %bb8, label %bb9
bb8:
  %t59 = call ptr @__olang_region_make(ptr %v3)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l29, !tbaa !24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l29
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %t62)
  store { i64, ptr } %t63, ptr %l31
  br label %bb10
bb10:
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t65 = load i64, ptr %l29
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = extractvalue { i64, ptr } %t64, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_held_alloc(ptr %t66, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/prompt:Session", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 24
  %t79 = load i1, ptr %t78, !tbaa !21
  %t81 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2ffetch_3aFetcher_2ector(ptr %t80, ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t81, { i64, ptr } %t82, { i64, ptr } %t72, i1 %t79, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t80, i64 184, i1 false)
  br label %bb11
bb11:
  %t85 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %l36, i64 184, i1 false)
  store ptr %t85, ptr %l5, !tbaa !29
  %t87 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v3)
  store %"compiler/source:Names" %t87, ptr %l38
  br label %bb12
bb12:
  %t88 = load %"compiler/source:Names", ptr %l38
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 104, i64 8)
  store %"compiler/source:Names" %t88, ptr %t89
  store ptr %t89, ptr %l6, !tbaa !29
  %t91 = call ptr @__olang_scope_hold(ptr %v3)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l40, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e0
  br i1 %t93, label %bb13, label %bb14
bb13:
  %t95 = call ptr @__olang_region_make(ptr %v3)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t97 = load i64, ptr %l40
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %t98)
  store { i64, ptr } %t99, ptr %l42
  br label %bb15
bb15:
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t101 = load i64, ptr %l40
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = extractvalue { i64, ptr } %t100, 0
  %t104 = extractvalue { i64, ptr } %t100, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_held_alloc(ptr %t102, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %lp4
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t112 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t113, ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v2, ptr %v3, { i64, ptr } %t108, ptr %t109, ptr %t110, ptr %t111, ptr %t112)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t113, i64 864, i1 false)
  br label %bb16
bb16:
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 864, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %l48, i64 864, i1 false)
  store ptr %t119, ptr %l7, !tbaa !29
  %t121 = load ptr, ptr %l7, !tbaa !29
  store ptr %t121, ptr %l50, !tbaa !29
  %t122 = call ptr @__olang_scope_hold(ptr %v3)
  %t123 = ptrtoint ptr %t122 to i64
  store i64 %t123, ptr %l51, !tbaa !24
  %t124 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e20
  br i1 %t124, label %bb17, label %bb18
bb17:
  %t126 = call ptr @__olang_region_make(ptr %v3)
  %t127 = ptrtoint ptr %t126 to i64
  store i64 %t127, ptr %l51, !tbaa !24
  br label %bb18
bb18:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/prompt:Session", ptr %t128, i32 0, i32 0
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/build:Config", ptr %t131, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = extractvalue { i64, ptr } %t134, 0
  %t138 = load i64, ptr %l51
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = call ptr @__olang_held_alloc(ptr %t139, i64 %t137)
  call void @olang_textcopy(ptr %t140, ptr %t136, i64 %t137)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = load ptr, ptr %l50, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t144, i32 0, i32 20
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l58, !tbaa !27
  %t148 = load ptr, ptr %l50, !tbaa !29
  %t149 = getelementptr %"compiler/load:Loader", ptr %t148, i32 0, i32 20
  store { i64, ptr } %t142, ptr %t149, !tbaa !27
  %t150 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e20
  br i1 %t150, label %bb19, label %bb20
bb19:
  %t152 = load { i64, ptr }, ptr %l58
  %t153 = extractvalue { i64, ptr } %t152, 1
  call void @__olang_region_release(ptr %t153)
  store { i64, ptr } zeroinitializer, ptr %l58
  br label %bb20
bb20:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/prompt:program", ptr %t154, i32 0, i32 3
  store ptr %t156, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  %t158 = load i64, ptr %l9, !tbaa !24
  store i64 %t158, ptr %l62, !tbaa !24
  %t159 = load ptr, ptr %l8, !tbaa !29
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t159)
  store i64 %t161, ptr %l64
  br label %bb22
bb22:
  %t162 = load i64, ptr %l62, !tbaa !24
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t169 = load i64, ptr %l9, !tbaa !24
  %t172 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t168, i64 %t169)
  store { i64, ptr } %t172, ptr %l69
  br label %bb26
bb26:
  %t173 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t174 = load ptr, ptr %l7, !tbaa !29
  %t176 = getelementptr %"compiler/load:Loader", ptr %t174, i32 0, i32 14
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v3, ptr %v1, ptr %t176, { i64, ptr } %t173, i1 true)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t180 = load i64, ptr %l9, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l9, !tbaa !24
  br label %bb21
bb29:
  %t185 = load ptr, ptr %l7, !tbaa !29
  %t187 = getelementptr %"compiler/load:Loader", ptr %t185, i32 0, i32 13
  store ptr %t187, ptr %l77, !tbaa !29
  %t188 = load ptr, ptr %lp3
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l78, !tbaa !27
  %t190 = call ptr @__olang_scope_hold(ptr %v3)
  %t191 = ptrtoint ptr %t190 to i64
  store i64 %t191, ptr %l79, !tbaa !24
  %t192 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t192, label %bb30, label %bb31
bb30:
  %t194 = call ptr @__olang_region_make(ptr %v3)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = getelementptr %"compiler/prompt:program", ptr %t196, i32 0, i32 0
  %t199 = load i64, ptr %l79
  %t200 = inttoptr i64 %t199 to ptr
  %t202 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %t200, ptr %t198)
  store { i64, ptr } %t202, ptr %l83
  br label %bb32
bb32:
  %t203 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t204 = load ptr, ptr %l77, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v3, ptr %v3, ptr %v3, ptr %t204, { i64, ptr } %t205, { i64, ptr } %t203)
  br label %bb33
bb33:
  %t207 = load ptr, ptr %l7, !tbaa !29
  %t208 = load ptr, ptr %lp3
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t212 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v3, ptr %v3, ptr %t207, { i64, ptr } %t209)
  store i64 %t212, ptr %l87
  br label %bb34
bb34:
  %t213 = load ptr, ptr %l7, !tbaa !29
  %t215 = getelementptr %"compiler/load:Loader", ptr %t213, i32 0, i32 12
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = icmp sge i64 %t216, 0
  br i1 %t218, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l91, !tbaa !29
  %t221 = load ptr, ptr %l7, !tbaa !29
  %t223 = getelementptr %"compiler/load:Loader", ptr %t221, i32 0, i32 10
  %t224 = load ptr, ptr %l7, !tbaa !29
  %t226 = getelementptr %"compiler/load:Loader", ptr %t224, i32 0, i32 12
  %t227 = load i64, ptr %t226, !tbaa !24
  %t230 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v3, ptr %v3, ptr %t223, i64 %t227)
  store ptr %t230, ptr %l96
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t231 = load ptr, ptr %l96, !tbaa !29
  %t233 = getelementptr %"compiler/load:Module", ptr %t231, i32 0, i32 4
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l98, !tbaa !24
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/prompt:program", ptr %t235, i32 0, i32 1
  %t239 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t237)
  store { i64, ptr } %t239, ptr %l101
  br label %bb38
bb38:
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr %"compiler/prompt:program", ptr %t240, i32 0, i32 2
  %t244 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s6, ptr %t242)
  store { i64, ptr } %t244, ptr %l104
  br label %bb39
bb39:
  %t245 = load ptr, ptr %l91, !tbaa !29
  %t246 = load i64, ptr %l98, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l104, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNameLines(ptr %v2, ptr %v1, ptr %s6, ptr %t245, i64 %t246, { i64, ptr } %t247, { i64, ptr } %t248)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t251 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t249)
  store i64 %t251, ptr %l106
  br label %bb42
bb42:
  %t252 = load i64, ptr %l106, !tbaa !24
  %t253 = icmp sgt i64 %t252, 0
  br i1 %t253, label %bb43, label %bb44
bb43:
  store ptr null, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t256 = load ptr, ptr %l7, !tbaa !29
  store ptr %t256, ptr %l109, !tbaa !29
  call void @compiler_2fviews_3aKept_2ector(ptr %t257, ptr %v3)
  call void @llvm.memmove.p0.p0.i64(ptr %l110, ptr %t257, i64 296, i1 false)
  br label %bb46
bb46:
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 296, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t258, ptr %l110, i64 296, i1 false)
  %t260 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t259, ptr %v3, ptr %v3, ptr %v3, ptr %t260, i1 false, ptr %t258)
  call void @llvm.memmove.p0.p0.i64(ptr %l112, ptr %t259, i64 5960, i1 false)
  br label %bb47
bb47:
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 5960, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %l112, i64 5960, i1 false)
  store ptr %t262, ptr %l11, !tbaa !29
  %t264 = load ptr, ptr %l2, !tbaa !29
  %t266 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t264)
  store i64 %t266, ptr %l115
  br label %bb48
bb48:
  %t267 = load i64, ptr %l115, !tbaa !24
  %t268 = icmp sgt i64 %t267, 0
  br i1 %t268, label %bb49, label %bb50
bb49:
  store ptr null, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t271 = load ptr, ptr %l11, !tbaa !29
  store ptr %t271, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eendCompiled(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l44 = alloca i1
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l67 = alloca i1
  %l73 = alloca i32
  %l75 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t1, i32 0, i32 9
  call void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eEnd(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/prompt:Session", ptr %t5, i32 0, i32 10
  %t8 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 14
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb3:
  %t13 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d33, i32 0, i32 1) })
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l15
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l14
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  br label %bb9
bb5:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  store i1 %t22, ptr %l17, !tbaa !21
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l13, !tbaa !27
  br label %bb9
bb9:
  %t28 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t29, ptr %l20
  br label %bb10
bb10:
  %t30 = load i1, ptr %l20, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l12, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ecellDir(ptr %v0, ptr %s0, ptr %t34)
  store { i64, ptr } %t36, ptr %l23
  br label %bb15
bb15:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t37)
  store i32 %t39, ptr %l25
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb17, label %ok.41, !prof !99
ok.41:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  store i1 %t45, ptr %l27, !tbaa !21
  %t46 = load i32, ptr %l25, !tbaa !23
  %t47 = ashr i32 %t46, 16
  %t49 = icmp eq i32 %t47, 1
  br i1 %t49, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/prompt:Session", ptr %t51, i32 0, i32 11
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = call ptr @__olang_scope_or(ptr %v1, ptr %t56)
  %t58 = call ptr @__olang_scope_hold(ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t61, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t63, ptr %l33
  br label %bb22
bb22:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/prompt:Session", ptr %t65, i32 0, i32 11
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = call ptr @__olang_scope_or(ptr %v1, ptr %t70)
  %t72 = call ptr @__olang_scope_hold(ptr %t71)
  %t73 = ptrtoint ptr %t72 to i64
  %t75 = inttoptr i64 %t73 to ptr
  %t76 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t77 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %t75, ptr %s0, { i64, ptr } %t76)
  store { i64, ptr } %t77, ptr %l37
  br label %bb26
bb26:
  %t78 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t78, ptr %l1, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/prompt:Session", ptr %t79, i32 0, i32 10
  %t82 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t83)
  %t86 = extractvalue { i32, { i64, ptr } } %t85, 1
  %t87 = extractvalue { i32, { i64, ptr } } %t85, 0
  store i32 %t87, ptr %l42
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb28, label %ok.89, !prof !99
ok.89:
  store { i64, ptr } %t86, ptr %l41
  br label %bb27
bb27:
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t90, ptr %l38, !tbaa !27
  br label %bb32
bb28:
  %t91 = load i32, ptr %l42, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  store i1 %t94, ptr %l44, !tbaa !21
  %t95 = load i32, ptr %l42, !tbaa !23
  %t96 = ashr i32 %t95, 16
  %t98 = icmp eq i32 %t96, 1
  br i1 %t98, label %bb29, label %bb30
bb29:
  call void @__olang_errpay_pop()
  br label %bb30
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t100 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t100, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb35:
  br label %bb36
bb36:
  %t115 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t115, ptr %l54, !tbaa !27
  %t116 = load i64, ptr %l4, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t116
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !37
  store { i64, ptr } %t121, ptr %l6, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = extractvalue { i64, ptr } %t124, 0
  %t128 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t131 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t130)
  call void @olang_textcopy(ptr %t131, ptr %t126, i64 %t127)
  %t132 = getelementptr i8, ptr %t131, i64 %t127
  call void @olang_textcopy(ptr %t132, ptr %t128, i64 %t129)
  %t133 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t131, 1
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t123, { i64, ptr } %t134)
  store i1 %t138, ptr %l61
  br label %bb37
bb37:
  %t139 = load i1, ptr %l61, !tbaa !21
  br i1 %t139, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb39:
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = extractvalue { i64, ptr } %t141, 0
  %t145 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = getelementptr i8, ptr %t148, i64 %t144
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t140, { i64, ptr } %t151)
  store i1 %t155, ptr %l67
  br label %bb40
bb40:
  %t156 = load i1, ptr %l67, !tbaa !21
  store i1 %t156, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t157 = load i1, ptr %l62, !tbaa !21
  br i1 %t157, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/prompt:Session", ptr %t158, i32 0, i32 10
  %t161 = getelementptr %"compiler/build:Config", ptr %t160, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t162, 1
  %t166 = extractvalue { i64, ptr } %t162, 0
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t163, 1
  %t172 = extractvalue { i64, ptr } %t163, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t165, i64 %t166)
  %t175 = getelementptr i8, ptr %t174, i64 %t166
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t171, i64 %t172)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  %t181 = call i32 @std_2fos_2eRemove(ptr %s9, { i64, ptr } %t178)
  store i32 %t181, ptr %l73
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb45, label %ok.183, !prof !99
ok.183:
  br label %bb44
bb43:
  br label %bb50
bb44:
  br label %bb49
bb45:
  %t184 = load i32, ptr %l73, !tbaa !23
  %t185 = ashr i32 %t184, 16
  %t187 = icmp eq i32 %t185, 1
  store i1 %t187, ptr %l75, !tbaa !21
  %t188 = load i32, ptr %l73, !tbaa !23
  %t189 = ashr i32 %t188, 16
  %t191 = icmp eq i32 %t189, 1
  br i1 %t191, label %bb46, label %bb47
bb46:
  call void @__olang_errpay_pop()
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb51:
  %t193 = load i64, ptr %l4, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l4, !tbaa !24
  br label %bb33
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2einitSym(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/prompt:Session", ptr %a0, i32 0, i32 11
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t4, 1
  %t8 = extractvalue { i64, ptr } %t4, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t7, i64 %t8)
  %t20 = getelementptr i8, ptr %t19, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t9, i64 %t10)
  %t21 = getelementptr i8, ptr %t20, i64 %t10
  call void @olang_textcopy(ptr %t21, ptr %t13, i64 %t14)
  %t22 = getelementptr i8, ptr %t21, i64 %t14
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t19, 1
  %t27 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s0, ptr %v2, { i64, ptr } %t24)
  store { i64, ptr } %t27, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/prompt:Value" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l6 = alloca %"compiler/prompt:Value"
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l18 = alloca %"compiler/prompt:Value"
  %l19 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %rv = alloca %"compiler/prompt:Value"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l7, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = load i64, ptr %l7
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call ptr @__olang_held_alloc(ptr %t12, i64 %t10)
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t17 = call ptr @__olang_scope_hold(ptr %v5)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e1
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = call ptr @__olang_region_make(ptr %v5)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t25 = extractvalue { i64, ptr } %a2, 1
  %t26 = extractvalue { i64, ptr } %a2, 0
  %t27 = load i64, ptr %l12
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t34 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = call %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v5, ptr %v5, ptr %v5, { i64, ptr } %t34, { i64, ptr } %t31, i1 %a3)
  store %"compiler/prompt:Value" %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load %"compiler/prompt:Value", ptr %l18
  store %"compiler/prompt:Value" %t38, ptr %l6
  %t39 = call ptr @__olang_scope_hold(ptr %v5)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l19, !tbaa !24
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e5
  br i1 %t41, label %bb6, label %bb7
bb6:
  %t43 = call ptr @__olang_region_make(ptr %v5)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/prompt:Session", ptr %t47, i32 0, i32 1
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = load i64, ptr %l19
  %t52 = inttoptr i64 %t51 to ptr
  %t56 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estoreOf(ptr %v0, ptr %v3, ptr %t52, ptr %t45, { i64, ptr } %a4, i64 %t50)
  store { i64, ptr } %t56, ptr %l25
  br label %bb8
bb8:
  %t57 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t58 = getelementptr %"compiler/prompt:Value", ptr %l6, i32 0, i32 5
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l27, !tbaa !27
  %t61 = getelementptr %"compiler/prompt:Value", ptr %l6, i32 0, i32 5
  store { i64, ptr } %t57, ptr %t61, !tbaa !27
  %t62 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e5
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load { i64, ptr }, ptr %l27
  %t65 = extractvalue { i64, ptr } %t64, 1
  call void @__olang_region_release(ptr %t65)
  store { i64, ptr } zeroinitializer, ptr %l27
  br label %bb10
bb10:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t70 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v4, ptr %v1, ptr %v5, ptr %a5, { i64, ptr } %t67)
  %t71 = extractvalue { i32, { i64, ptr } } %t70, 1
  %t72 = extractvalue { i32, { i64, ptr } } %t70, 0
  store i32 %t72, ptr %l33
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb12, label %ok.74, !prof !99
ok.74:
  store { i64, ptr } %t71, ptr %l32
  br label %bb11
bb11:
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t75, ptr %l29, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb14
bb14:
  %t76 = getelementptr %"compiler/prompt:Value", ptr %l6, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l34, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t79 = getelementptr %"compiler/prompt:Value", ptr %l6, i32 0, i32 4
  store { i64, ptr } %t78, ptr %t79, !tbaa !27
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e4
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load { i64, ptr }, ptr %l34
  %t83 = extractvalue { i64, ptr } %t82, 1
  call void @__olang_region_release(ptr %t83)
  store { i64, ptr } zeroinitializer, ptr %l34
  br label %bb16
bb16:
  %t84 = load %"compiler/prompt:Value", ptr %l6
  store %"compiler/prompt:Value" %t84, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:Value", ptr %rv
  ret %"compiler/prompt:Value" %rr
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekeptLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/typed:Local"
  %lp9 = alloca ptr
  %l10 = alloca %"compiler/prompt:Value"
  %l12 = alloca i64
  %l18 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca %"compiler/typed:Local"
  %l36 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l52 = alloca i1
  %l57 = alloca i32
  %l61 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca i64
  %l83 = alloca { i64, ptr }
  %l87 = alloca %"compiler/prompt:Value"
  %l96 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @compiler_2fprompt_2ecellBody(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i64, ptr %l12, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 19
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v1, ptr %v1, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l18, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 12
  %t27 = load i64, ptr %t26, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v1, ptr %t17, i64 %t27)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 7
  store ptr %t32, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l7, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t35)
  store i64 %t37, ptr %l28
  br label %bb8
bb8:
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = load i64, ptr %l28, !tbaa !24
  %t40 = icmp slt i64 %t38, %t39
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb10:
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t44, i64 %t45)
  store %"compiler/typed:Local" %t48, ptr %l33
  br label %bb12
bb12:
  %t49 = load %"compiler/typed:Local", ptr %l33
  store %"compiler/typed:Local" %t49, ptr %l8
  %t50 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 3
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 4
  %t56 = load i32, ptr %t55, !range !{i32 0, i32 7}
  %t58 = trunc i64 1 to i32
  %t59 = icmp eq i32 %t56, %t58
  %t61 = xor i1 %t59, true
  store i1 %t61, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb18
bb17:
  %t64 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 0
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = icmp eq i32 %t65, 0
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb20:
  br label %bb21
bb21:
  %t70 = call ptr @__olang_scope_hold(ptr %v2)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l43, !tbaa !24
  %t72 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2ekeptLocals_2elocal_2e9
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = call ptr @__olang_region_make(ptr %v2)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l43, !tbaa !24
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load i64, ptr %l43
  %t80 = inttoptr i64 %t79 to ptr
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %t80, ptr %t76, i32 %t78)
  store { i64, ptr } %t83, ptr %l47
  br label %bb24
bb24:
  %t84 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2ekeptLocals_2elocal_2e9
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t86 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb27, label %bb28
bb26:
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t91, ptr %lp9
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t93 = load ptr, ptr %lp9
  store { i64, ptr } %t92, ptr %t93, !tbaa !27
  br i1 %a3, label %bb29, label %bb30
bb27:
  store { i64, ptr } zeroinitializer, ptr %l47, !tbaa !27
  br label %bb28
bb28:
  %t96 = load i64, ptr %l43
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l47
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  br label %bb26
bb29:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t110 = load i32, ptr %t109, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t108, i32 %t110)
  store i32 %t113, ptr %l57
  br label %bb31
bb30:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb32
bb31:
  %t114 = load i32, ptr %l57, !range !{i32 0, i32 33}
  %t116 = trunc i64 20 to i32
  %t117 = icmp eq i32 %t114, %t116
  %t119 = xor i1 %t117, true
  store i1 %t119, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t121 = load i1, ptr %l52, !tbaa !21
  br i1 %t121, label %bb33, label %bb34
bb33:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t132 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v1, ptr %t127, i32 %t129)
  store i1 %t132, ptr %l66
  br label %bb35
bb34:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb36
bb35:
  %t133 = load i1, ptr %l66, !tbaa !21
  store i1 %t133, ptr %l61, !tbaa !21
  br label %bb36
bb36:
  %t134 = load i1, ptr %l61, !tbaa !21
  br i1 %t134, label %bb37, label %bb38
bb37:
  %t135 = call ptr @__olang_scope_hold(ptr %v2)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l67, !tbaa !24
  %t137 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2ekeptLocals_2elocal_2e9
  br i1 %t137, label %bb39, label %bb40
bb38:
  br label %bb47
bb39:
  %t139 = call ptr @__olang_region_make(ptr %v2)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l67, !tbaa !24
  br label %bb40
bb40:
  %t141 = load ptr, ptr %lp9
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = load i64, ptr %l67
  %t150 = inttoptr i64 %t149 to ptr
  %t151 = call ptr @__olang_held_alloc(ptr %t150, i64 %t148)
  call void @olang_textcopy(ptr %t151, ptr %t144, i64 %t145)
  %t152 = getelementptr i8, ptr %t151, i64 %t145
  call void @olang_textcopy(ptr %t152, ptr %t146, i64 %t147)
  %t153 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  store { i64, ptr } %t154, ptr %l70, !tbaa !27
  %t155 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2ekeptLocals_2elocal_2e9
  br i1 %t155, label %bb41, label %bb42
bb41:
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb43, label %bb44
bb42:
  %t162 = load ptr, ptr %lp9
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l74, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t165 = load ptr, ptr %lp9
  store { i64, ptr } %t164, ptr %t165, !tbaa !27
  %t166 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2ekeptLocals_2elocal_2e9
  br i1 %t166, label %bb45, label %bb46
bb43:
  store { i64, ptr } zeroinitializer, ptr %l70, !tbaa !27
  br label %bb44
bb44:
  %t168 = load i64, ptr %l67
  %t169 = inttoptr i64 %t168 to ptr
  %t170 = load { i64, ptr }, ptr %l70
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = call ptr @__olang_region_or(ptr %t171, ptr null)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr null
  call void @__olang_region_settle_in(ptr %t169, ptr %t174)
  br label %bb42
bb45:
  %t175 = load { i64, ptr }, ptr %l74
  %t176 = extractvalue { i64, ptr } %t175, 1
  call void @__olang_region_release(ptr %t176)
  store { i64, ptr } zeroinitializer, ptr %l74
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t177 = call ptr @__olang_scope_hold(ptr %v2)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l76, !tbaa !24
  %t179 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e0
  br i1 %t179, label %bb48, label %bb49
bb48:
  %t181 = call ptr @__olang_region_make(ptr %v2)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l76, !tbaa !24
  br label %bb49
bb49:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/load:Loader", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t197 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s3, ptr %t192, i32 %t194)
  store { i64, ptr } %t197, ptr %l83
  br label %bb50
bb50:
  %t198 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = load i64, ptr %l76
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = call ptr @__olang_held_alloc(ptr %t202, i64 %t200)
  call void @olang_textcopy(ptr %t203, ptr %t199, i64 %t200)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t207 = load ptr, ptr %lp9
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t211 = call %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t205, { i64, ptr } %t208, i1 true)
  store %"compiler/prompt:Value" %t211, ptr %l87
  br label %bb51
bb51:
  %t212 = load %"compiler/prompt:Value", ptr %l87
  store %"compiler/prompt:Value" %t212, ptr %l10
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/load:Loader", ptr %t219, i32 0, i32 4
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load ptr, ptr %l5, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Body", ptr %t223, i32 0, i32 3
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 1
  %t228 = getelementptr %"compiler/source:Span", ptr %t227, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  %t231 = sext i32 %t229 to i64
  %t235 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v1, ptr %t222, i64 %t226, i64 %t231)
  store i64 %t235, ptr %l96
  br label %bb52
bb52:
  %t236 = load i64, ptr %l96, !tbaa !24
  %t237 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 3
  store i64 %t236, ptr %t237, !tbaa !24
  %t240 = getelementptr %"compiler/prompt:cell", ptr %a2, i32 0, i32 3
  %t241 = load %"compiler/prompt:Value", ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t240, %"compiler/prompt:Value" %t241)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb54
bb54:
  %t244 = load i64, ptr %l7, !tbaa !24
  %t247 = add i64 %t244, 1
  store i64 %t247, ptr %l7, !tbaa !24
  br label %bb7
bb55:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2emachine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/check:Gap"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/scope:Gap"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca %"compiler/check:Gap"
  %l56 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l70 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l101 = alloca i1
  %l109 = alloca %"compiler/interp:Exec"
  %l111 = alloca ptr
  %l112 = alloca i64
  %l116 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l117 = alloca i64
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l125 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l133 = alloca i64
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l142 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l150 = alloca ptr
  %l152 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca %"compiler/scope:Scoper"
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca %"compiler/scope:Gap"
  %l176 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l189 = alloca i64
  %l191 = alloca i1
  %l194 = alloca i1
  %l198 = alloca ptr
  %l200 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l202 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca %"compiler/free:Free"
  %l206 = alloca ptr
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l215 = alloca ptr
  %l217 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l219 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l222 = alloca i64
  %l226 = alloca i64
  %l229 = alloca i64
  %l248 = alloca ptr
  %l252 = alloca %"compiler/typed:Plan"
  %l254 = alloca ptr
  %l258 = alloca i1
  %l260 = alloca ptr
  %l264 = alloca i64
  %l266 = alloca ptr
  %l267 = alloca i64
  %l272 = alloca { i64, ptr }
  %l280 = alloca ptr
  %l281 = alloca i64
  %l285 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca i64
  %l288 = alloca { i64, ptr }
  %l289 = alloca i64
  %l290 = alloca { i64, ptr }
  %l295 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l299 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l301 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l303 = alloca i64
  %l305 = alloca i64
  %l310 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l312 = alloca ptr
  %l313 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca ptr
  %t190 = alloca %"compiler/interp:Exec", align 8
  %t437 = alloca %"compiler/scope:Scoper", align 8
  %t564 = alloca %"compiler/free:Free", align 8
  %t663 = alloca %"compiler/typed:Plan", align 8
  %t667 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v4)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l28
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %t3
  store ptr %t3, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t5)
  store i64 %t7, ptr %l31
  br label %bb2
bb2:
  %t8 = load i64, ptr %l31, !tbaa !24
  %t9 = icmp eq i64 %t8, 0
  store i1 %t9, ptr %l5, !tbaa !21
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i64 @compiler_2finterp_2eDecideValues(ptr %v1, ptr %t13)
  store i64 %t15, ptr %l35
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t20 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v1, ptr %v4, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l38
  br label %bb7
bb7:
  %t21 = load i1, ptr %l5, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2eBake(ptr %v1, ptr %s2, ptr %t23)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l41
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t26)
  store i64 %t28, ptr %l43
  br label %bb12
bb12:
  %t29 = load i64, ptr %l43, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 20
  store ptr %t35, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t37 = load i64, ptr %l7, !tbaa !24
  store i64 %t37, ptr %l48, !tbaa !24
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v1, ptr %t38)
  store i64 %t40, ptr %l50
  br label %bb17
bb17:
  %t41 = load i64, ptr %l48, !tbaa !24
  %t42 = load i64, ptr %l50, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = call %"compiler/check:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eAt_3ccompiler_2fcheck_3aGap_3e(ptr %v1, ptr %v1, ptr %t47, i64 %t48)
  store %"compiler/check:Gap" %t51, ptr %l55
  br label %bb21
bb21:
  %t52 = load %"compiler/check:Gap", ptr %l55
  store %"compiler/check:Gap" %t52, ptr %l8
  %t53 = load ptr, ptr %l3, !tbaa !29
  store ptr %t53, ptr %l56, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/check:Gap", ptr %l8, i32 0, i32 0
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = getelementptr %"compiler/check:Gap", ptr %l8, i32 0, i32 1
  %t58 = getelementptr %"compiler/source:Span", ptr %t57, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t65 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s5, ptr %t54, i64 %t56, i64 %t61)
  store { i64, ptr } %t65, ptr %l61
  br label %bb22
bb22:
  %t66 = getelementptr %"compiler/check:Gap", ptr %l8, i32 0, i32 2
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t75 = extractvalue { i64, ptr } %t67, 1
  %t76 = extractvalue { i64, ptr } %t67, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t69, i64 %t70)
  %t82 = getelementptr i8, ptr %t81, i64 %t70
  call void @olang_textcopy(ptr %t82, ptr %t71, i64 %t72)
  %t83 = getelementptr i8, ptr %t82, i64 %t72
  call void @olang_textcopy(ptr %t83, ptr %t75, i64 %t76)
  %t84 = getelementptr i8, ptr %t83, i64 %t76
  call void @olang_textcopy(ptr %t84, ptr %t78, i64 %t79)
  %t85 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t81, 1
  %t88 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2fprompt_2egap(ptr %v3, ptr %s5, ptr %t88, { i64, ptr } %t86)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l7, !tbaa !24
  br label %bb16
bb25:
  %t95 = load ptr, ptr %l3, !tbaa !29
  %t97 = getelementptr %"compiler/prompt:Reply", ptr %t95, i32 0, i32 4
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t98, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t100, ptr %l70
  br label %bb26
bb26:
  %t101 = load i1, ptr %l70, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s9
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v1, ptr %s9, ptr %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %l76
  br label %bb30
bb30:
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  %t115 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %t115
  store ptr %t115, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s10
  %t117 = load i64, ptr %l10, !tbaa !24
  store i64 %t117, ptr %l78, !tbaa !24
  %t118 = load ptr, ptr %l9, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s9, ptr %t118)
  store i64 %t120, ptr %l80
  br label %bb32
bb32:
  %t121 = load i64, ptr %l78, !tbaa !24
  %t122 = load i64, ptr %l80, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb44
bb34:
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s9, ptr %s9, ptr %t127, i64 %t128)
  store { i64, ptr } %t131, ptr %l85
  br label %bb36
bb36:
  %t132 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t132, ptr %l11, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t135 = call { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %s9, ptr %s10, { i64, ptr } %t133)
  store { i64, ptr } %t135, ptr %l87
  br label %bb37
bb37:
  %t136 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t136, ptr %l12, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t137, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t139, ptr %l89
  br label %bb38
bb38:
  %t140 = load i1, ptr %l89, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t146 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t149 = extractvalue { i64, ptr } %t144, 1
  %t150 = extractvalue { i64, ptr } %t144, 0
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t156 = extractvalue { i64, ptr } %t145, 1
  %t157 = extractvalue { i64, ptr } %t145, 0
  %t158 = add i64 %t154, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t146, i64 %t147)
  %t160 = getelementptr i8, ptr %t159, i64 %t147
  call void @olang_textcopy(ptr %t160, ptr %t149, i64 %t150)
  %t161 = getelementptr i8, ptr %t160, i64 %t150
  call void @olang_textcopy(ptr %t161, ptr %t152, i64 %t153)
  %t162 = getelementptr i8, ptr %t161, i64 %t153
  call void @olang_textcopy(ptr %t162, ptr %t156, i64 %t157)
  %t163 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t159, 1
  call void @compiler_2fprompt_2egap(ptr %v3, ptr %s11, ptr %t143, { i64, ptr } %t164)
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb43
bb43:
  %t168 = load i64, ptr %l10, !tbaa !24
  %t171 = add i64 %t168, 1
  store i64 %t171, ptr %l10, !tbaa !24
  br label %bb31
bb44:
  call void @__olang_scope_close(ptr %s9)
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t175 = getelementptr %"compiler/prompt:Reply", ptr %t173, i32 0, i32 4
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t176, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t178, ptr %l101
  br label %bb45
bb45:
  %t179 = load i1, ptr %l101, !tbaa !21
  %t180 = xor i1 %t179, true
  br i1 %t180, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 19
  call void @compiler_2finterp_3aExec_2ector(ptr %t190, ptr %v1, ptr %v1, ptr %v4, ptr %t186, ptr %t189, i32 1)
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t190, i64 7352, i1 false)
  br label %bb49
bb49:
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 7352, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %l109, i64 7352, i1 false)
  store ptr %t194, ptr %l13, !tbaa !29
  %t196 = load ptr, ptr %l13, !tbaa !29
  store ptr %t196, ptr %l111, !tbaa !29
  %t197 = call ptr @__olang_scope_hold(ptr %v4)
  %t198 = ptrtoint ptr %t197 to i64
  store i64 %t198, ptr %l112, !tbaa !24
  %t199 = load i1, ptr @olang_2esole_2ecompiler_2flower_3aLowerer_2e20
  br i1 %t199, label %bb50, label %bb51
bb50:
  %t201 = call ptr @__olang_region_make(ptr %v4)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l112, !tbaa !24
  br label %bb51
bb51:
  %t203 = load ptr, ptr %l4, !tbaa !29
  %t205 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t203
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t205, ptr %l116
  %t207 = load i64, ptr %l112
  %t208 = inttoptr i64 %t207 to ptr
  %t209 = call ptr @__olang_scope_hold(ptr %t208)
  %t210 = ptrtoint ptr %t209 to i64
  store i64 %t210, ptr %l117, !tbaa !24
  %t211 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e0
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t213 = load i64, ptr %l112
  %t214 = inttoptr i64 %t213 to ptr
  %t215 = call ptr @__olang_region_make_part(ptr %t214)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l117, !tbaa !24
  br label %bb53
bb53:
  %t217 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 0
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  store { i64, ptr } %t218, ptr %l119, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 0
  store i64 %t220, ptr %l120, !tbaa !24
  %t221 = load i64, ptr %l120, !tbaa !24
  %t222 = mul i64 %t221, 24
  %t223 = load i64, ptr %l117
  %t224 = inttoptr i64 %t223 to ptr
  %t225 = call ptr @__olang_held_alloc(ptr %t224, i64 %t222)
  %t226 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l121, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l120, !tbaa !24
  %t233 = mul i64 %t232, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t229, ptr %t231, i64 %t233, i1 false)
  %t234 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t235 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 0
  store { i64, ptr } %t234, ptr %t235, !tbaa !27
  %t236 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e0
  br i1 %t236, label %bb54, label %bb55
bb54:
  %t238 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 0
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t242 = icmp eq i64 %t240, 0
  br i1 %t242, label %bb56, label %bb57
bb55:
  %t244 = load i64, ptr %l112
  %t245 = inttoptr i64 %t244 to ptr
  %t246 = call ptr @__olang_scope_hold(ptr %t245)
  %t247 = ptrtoint ptr %t246 to i64
  store i64 %t247, ptr %l125, !tbaa !24
  %t248 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e1
  br i1 %t248, label %bb58, label %bb59
bb56:
  %t250 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t250, !tbaa !27
  br label %bb57
bb57:
  %t251 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 0
  %t252 = load i64, ptr %l117
  %t253 = inttoptr i64 %t252 to ptr
  %t254 = load { i64, ptr }, ptr %t251
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = icmp ne ptr %t256, null
  %t258 = select i1 %t257, ptr %t256, ptr null
  call void @__olang_region_settle_in(ptr %t253, ptr %t258)
  br label %bb55
bb58:
  %t259 = load i64, ptr %l112
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = call ptr @__olang_region_make_part(ptr %t260)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l125, !tbaa !24
  br label %bb59
bb59:
  %t263 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 1
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l127, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l128, !tbaa !24
  %t267 = load i64, ptr %l128, !tbaa !24
  %t268 = mul i64 %t267, 8
  %t269 = load i64, ptr %l125
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = call ptr @__olang_held_alloc(ptr %t270, i64 %t268)
  %t272 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l129, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = load i64, ptr %l128, !tbaa !24
  %t279 = mul i64 %t278, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t275, ptr %t277, i64 %t279, i1 false)
  %t280 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t281 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 1
  store { i64, ptr } %t280, ptr %t281, !tbaa !27
  %t282 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e1
  br i1 %t282, label %bb60, label %bb61
bb60:
  %t284 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 1
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 0
  %t288 = icmp eq i64 %t286, 0
  br i1 %t288, label %bb62, label %bb63
bb61:
  %t290 = load i64, ptr %l112
  %t291 = inttoptr i64 %t290 to ptr
  %t292 = call ptr @__olang_scope_hold(ptr %t291)
  %t293 = ptrtoint ptr %t292 to i64
  store i64 %t293, ptr %l133, !tbaa !24
  %t294 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e2
  br i1 %t294, label %bb64, label %bb65
bb62:
  %t296 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t296, !tbaa !27
  br label %bb63
bb63:
  %t297 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 1
  %t298 = load i64, ptr %l125
  %t299 = inttoptr i64 %t298 to ptr
  %t300 = load { i64, ptr }, ptr %t297
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = call ptr @__olang_region_or(ptr %t301, ptr null)
  %t303 = icmp ne ptr %t302, null
  %t304 = select i1 %t303, ptr %t302, ptr null
  call void @__olang_region_settle_in(ptr %t299, ptr %t304)
  br label %bb61
bb64:
  %t305 = load i64, ptr %l112
  %t306 = inttoptr i64 %t305 to ptr
  %t307 = call ptr @__olang_region_make_part(ptr %t306)
  %t308 = ptrtoint ptr %t307 to i64
  store i64 %t308, ptr %l133, !tbaa !24
  br label %bb65
bb65:
  %t309 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 2
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l135, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  store i64 %t312, ptr %l136, !tbaa !24
  %t313 = load i64, ptr %l136, !tbaa !24
  %t314 = mul i64 %t313, 8
  %t315 = load i64, ptr %l133
  %t316 = inttoptr i64 %t315 to ptr
  %t317 = call ptr @__olang_held_alloc(ptr %t316, i64 %t314)
  %t318 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  store { i64, ptr } %t319, ptr %l137, !tbaa !27
  %t320 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = load i64, ptr %l136, !tbaa !24
  %t325 = mul i64 %t324, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t321, ptr %t323, i64 %t325, i1 false)
  %t326 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t327 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 2
  store { i64, ptr } %t326, ptr %t327, !tbaa !27
  %t328 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e2
  br i1 %t328, label %bb66, label %bb67
bb66:
  %t330 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 2
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t331, 0
  %t334 = icmp eq i64 %t332, 0
  br i1 %t334, label %bb68, label %bb69
bb67:
  %t336 = load i1, ptr @olang_2esole_2ecompiler_2flower_3aLowerer_2e20
  br i1 %t336, label %bb70, label %bb71
bb68:
  %t338 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t338, !tbaa !27
  br label %bb69
bb69:
  %t339 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 2
  %t340 = load i64, ptr %l133
  %t341 = inttoptr i64 %t340 to ptr
  %t342 = load { i64, ptr }, ptr %t339
  %t343 = extractvalue { i64, ptr } %t342, 1
  %t344 = call ptr @__olang_region_or(ptr %t343, ptr null)
  %t345 = icmp ne ptr %t344, null
  %t346 = select i1 %t345, ptr %t344, ptr null
  call void @__olang_region_settle_in(ptr %t341, ptr %t346)
  br label %bb67
bb70:
  %t347 = load i64, ptr %l112
  %t348 = inttoptr i64 %t347 to ptr
  %t349 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 2
  %t350 = load { i64, ptr }, ptr %t349
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = call ptr @__olang_region_or(ptr %t351, ptr null)
  %t353 = call ptr @__olang_region_home(ptr %t352)
  %t354 = icmp ne ptr %t353, null
  %t355 = select i1 %t354, ptr %t353, ptr null
  %t356 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %t356
  %t358 = extractvalue { i64, ptr } %t357, 1
  %t359 = call ptr @__olang_region_or(ptr %t358, ptr null)
  %t360 = call ptr @__olang_region_home(ptr %t359)
  %t361 = icmp ne ptr %t360, null
  %t362 = select i1 %t361, ptr %t360, ptr %t355
  %t363 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116, i32 0, i32 0
  %t364 = load { i64, ptr }, ptr %t363
  %t365 = extractvalue { i64, ptr } %t364, 1
  %t366 = call ptr @__olang_region_or(ptr %t365, ptr null)
  %t367 = call ptr @__olang_region_home(ptr %t366)
  %t368 = icmp ne ptr %t367, null
  %t369 = select i1 %t368, ptr %t367, ptr %t362
  call void @__olang_region_settle_in(ptr %t348, ptr %t369)
  br label %bb71
bb71:
  %t370 = load ptr, ptr %l111, !tbaa !29
  %t371 = getelementptr %"compiler/interp:Exec", ptr %t370, i32 0, i32 3
  %t372 = getelementptr %"compiler/lower:Lowerer", ptr %t371, i32 0, i32 20
  %t373 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t372
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t373, ptr %l142
  %t374 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l116
  %t375 = load ptr, ptr %l111, !tbaa !29
  %t376 = getelementptr %"compiler/interp:Exec", ptr %t375, i32 0, i32 3
  %t377 = getelementptr %"compiler/lower:Lowerer", ptr %t376, i32 0, i32 20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t374, ptr %t377
  %t378 = load i1, ptr @olang_2esole_2ecompiler_2flower_3aLowerer_2e20
  br i1 %t378, label %bb72, label %bb73
bb72:
  %t380 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 2
  %t381 = load { i64, ptr }, ptr %t380
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = call ptr @__olang_region_or(ptr %t382, ptr null)
  %t384 = call ptr @__olang_region_home(ptr %t383)
  %t385 = icmp ne ptr %t384, null
  %t386 = select i1 %t385, ptr %t384, ptr null
  %t387 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 1
  %t388 = load { i64, ptr }, ptr %t387
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = call ptr @__olang_region_or(ptr %t389, ptr null)
  %t391 = call ptr @__olang_region_home(ptr %t390)
  %t392 = icmp ne ptr %t391, null
  %t393 = select i1 %t392, ptr %t391, ptr %t386
  %t394 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 0
  %t395 = load { i64, ptr }, ptr %t394
  %t396 = extractvalue { i64, ptr } %t395, 1
  %t397 = call ptr @__olang_region_or(ptr %t396, ptr null)
  %t398 = call ptr @__olang_region_home(ptr %t397)
  %t399 = icmp ne ptr %t398, null
  %t400 = select i1 %t399, ptr %t398, ptr %t393
  call void @__olang_region_drop(ptr %t400)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l142
  br label %bb73
bb73:
  %t401 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e0
  br i1 %t401, label %bb74, label %bb75
bb74:
  %t403 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403
  %t405 = extractvalue { i64, ptr } %t404, 0
  %t406 = extractvalue { i64, ptr } %t404, 1
  call void @__olang_region_release_part(ptr %t406, i64 %t405)
  store { i64, ptr } zeroinitializer, ptr %t403
  br label %bb75
bb75:
  %t407 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e1
  br i1 %t407, label %bb76, label %bb77
bb76:
  %t409 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 1
  %t410 = load { i64, ptr }, ptr %t409
  %t411 = extractvalue { i64, ptr } %t410, 0
  %t412 = extractvalue { i64, ptr } %t410, 1
  call void @__olang_region_release_part(ptr %t412, i64 %t411)
  store { i64, ptr } zeroinitializer, ptr %t409
  br label %bb77
bb77:
  %t413 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e2
  br i1 %t413, label %bb78, label %bb79
bb78:
  %t415 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142, i32 0, i32 2
  %t416 = load { i64, ptr }, ptr %t415
  %t417 = extractvalue { i64, ptr } %t416, 0
  %t418 = extractvalue { i64, ptr } %t416, 1
  call void @__olang_region_release_part(ptr %t418, i64 %t417)
  store { i64, ptr } zeroinitializer, ptr %t415
  br label %bb79
bb79:
  %t419 = load ptr, ptr %l13, !tbaa !29
  %t421 = getelementptr %"compiler/interp:Exec", ptr %t419, i32 0, i32 3
  %t422 = getelementptr %"compiler/lower:Lowerer", ptr %t421, i32 0, i32 17
  store i1 true, ptr %t422, !tbaa !21
  %t423 = load ptr, ptr %l13, !tbaa !29
  %t425 = getelementptr %"compiler/interp:Exec", ptr %t423, i32 0, i32 3
  %t426 = getelementptr %"compiler/lower:Lowerer", ptr %t425, i32 0, i32 15
  store i1 true, ptr %t426, !tbaa !21
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l150, !tbaa !29
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t431, i32 0, i32 19
  %t434 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t433
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t434, ptr %l152
  %t436 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v4, ptr %l152)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t436, ptr %l154
  br label %bb80
bb80:
  %t438 = load ptr, ptr %l150, !tbaa !29
  %t439 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  call void @compiler_2fscope_3aScoper_2ector(ptr %t437, ptr %v1, ptr %v4, ptr %v4, ptr %t438, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t439)
  call void @llvm.memmove.p0.p0.i64(ptr %l155, ptr %t437, i64 12080, i1 false)
  br label %bb81
bb81:
  %t440 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 12080, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t440, ptr %l155, i64 12080, i1 false)
  store ptr %t440, ptr %l14, !tbaa !29
  %t442 = load ptr, ptr %l14, !tbaa !29
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t444 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t445 = ptrtoint ptr %t444 to i64
  %t446 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 %t445, i64 8)
  %t447 = getelementptr { ptr, ptr }, ptr %t446, i32 0, i32 0
  store ptr %t443, ptr %t447, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t449 = call ptr @__olang_scope_hold(ptr %v1)
  %t450 = getelementptr { ptr, ptr }, ptr %t446, i32 0, i32 1
  store ptr %t449, ptr %t450, !tbaa !28
  %t451 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_51, 0
  %t452 = insertvalue { ptr, ptr } %t451, ptr %t446, 1
  %t456 = getelementptr %"compiler/scope:Scoper", ptr %t442, i32 0, i32 4
  store { ptr, ptr } %t452, ptr %t456
  %t457 = load ptr, ptr %l14, !tbaa !29
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t459 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t460 = ptrtoint ptr %t459 to i64
  %t461 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 %t460, i64 8)
  %t462 = getelementptr { ptr, ptr }, ptr %t461, i32 0, i32 0
  store ptr %t458, ptr %t462, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t464 = call ptr @__olang_scope_hold(ptr %v1)
  %t465 = getelementptr { ptr, ptr }, ptr %t461, i32 0, i32 1
  store ptr %t464, ptr %t465, !tbaa !28
  %t466 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_52, 0
  %t467 = insertvalue { ptr, ptr } %t466, ptr %t461, 1
  %t471 = getelementptr %"compiler/scope:Scoper", ptr %t457, i32 0, i32 5
  store { ptr, ptr } %t467, ptr %t471
  %t472 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v4, ptr %t472)
  br label %bb82
bb82:
  %t474 = load ptr, ptr %l14, !tbaa !29
  %t476 = getelementptr %"compiler/scope:Scoper", ptr %t474, i32 0, i32 3
  store ptr %t476, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s16
  %t478 = load i64, ptr %l16, !tbaa !24
  store i64 %t478, ptr %l168, !tbaa !24
  %t479 = load ptr, ptr %l15, !tbaa !29
  %t481 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v4, ptr %t479)
  store i64 %t481, ptr %l170
  br label %bb84
bb84:
  %t482 = load i64, ptr %l168, !tbaa !24
  %t483 = load i64, ptr %l170, !tbaa !24
  %t484 = icmp slt i64 %t482, %t483
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s16)
  br label %bb92
bb86:
  br label %bb87
bb87:
  %t488 = load ptr, ptr %l15, !tbaa !29
  %t489 = load i64, ptr %l16, !tbaa !24
  %t492 = call %"compiler/scope:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eAt_3ccompiler_2fscope_3aGap_3e(ptr %v4, ptr %v4, ptr %t488, i64 %t489)
  store %"compiler/scope:Gap" %t492, ptr %l175
  br label %bb88
bb88:
  %t493 = load %"compiler/scope:Gap", ptr %l175
  store %"compiler/scope:Gap" %t493, ptr %l17
  %t494 = load ptr, ptr %l3, !tbaa !29
  store ptr %t494, ptr %l176, !tbaa !29
  %t495 = load ptr, ptr %l2, !tbaa !29
  %t496 = getelementptr %"compiler/scope:Gap", ptr %l17, i32 0, i32 0
  %t497 = load i64, ptr %t496, !tbaa !24
  %t498 = getelementptr %"compiler/scope:Gap", ptr %l17, i32 0, i32 1
  %t499 = getelementptr %"compiler/source:Span", ptr %t498, i32 0, i32 0
  %t500 = load i32, ptr %t499, !tbaa !23
  %t502 = sext i32 %t500 to i64
  %t506 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s16, ptr %t495, i64 %t497, i64 %t502)
  store { i64, ptr } %t506, ptr %l181
  br label %bb89
bb89:
  %t507 = getelementptr %"compiler/scope:Gap", ptr %l17, i32 0, i32 2
  %t508 = load { i64, ptr }, ptr %t507, !tbaa !27
  %t509 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t510 = extractvalue { i64, ptr } %t509, 1
  %t511 = extractvalue { i64, ptr } %t509, 0
  %t512 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t514 = add i64 %t511, %t513
  %t516 = extractvalue { i64, ptr } %t508, 1
  %t517 = extractvalue { i64, ptr } %t508, 0
  %t518 = add i64 %t514, %t517
  %t519 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t522 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t521)
  call void @olang_textcopy(ptr %t522, ptr %t510, i64 %t511)
  %t523 = getelementptr i8, ptr %t522, i64 %t511
  call void @olang_textcopy(ptr %t523, ptr %t512, i64 %t513)
  %t524 = getelementptr i8, ptr %t523, i64 %t513
  call void @olang_textcopy(ptr %t524, ptr %t516, i64 %t517)
  %t525 = getelementptr i8, ptr %t524, i64 %t517
  call void @olang_textcopy(ptr %t525, ptr %t519, i64 %t520)
  %t526 = insertvalue { i64, ptr } undef, i64 %t521, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t522, 1
  %t529 = load ptr, ptr %l176, !tbaa !29
  call void @compiler_2fprompt_2egap(ptr %v3, ptr %s16, ptr %t529, { i64, ptr } %t527)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb91:
  %t531 = load i64, ptr %l16, !tbaa !24
  %t534 = add i64 %t531, 1
  store i64 %t534, ptr %l16, !tbaa !24
  br label %bb83
bb92:
  %t536 = load ptr, ptr %l2, !tbaa !29
  %t538 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t536)
  store i64 %t538, ptr %l189
  br label %bb93
bb93:
  %t539 = load i64, ptr %l189, !tbaa !24
  %t540 = icmp sgt i64 %t539, 0
  br i1 %t540, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb97
bb95:
  %t542 = load ptr, ptr %l3, !tbaa !29
  %t544 = getelementptr %"compiler/prompt:Reply", ptr %t542, i32 0, i32 4
  %t545 = load { i64, ptr }, ptr %t544, !tbaa !27
  %t547 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t545, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t547, ptr %l194
  br label %bb96
bb96:
  %t548 = load i1, ptr %l194, !tbaa !21
  %t549 = xor i1 %t548, true
  store i1 %t549, ptr %l191, !tbaa !21
  br label %bb97
bb97:
  %t551 = load i1, ptr %l191, !tbaa !21
  br i1 %t551, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t555 = getelementptr %"compiler/check:Checker", ptr %t553, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !29
  store ptr %t556, ptr %l198, !tbaa !29
  %t557 = load ptr, ptr %l1, !tbaa !29
  %t559 = getelementptr %"compiler/check:Checker", ptr %t557, i32 0, i32 19
  %t560 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t559
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t560, ptr %l200
  %t562 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v4, ptr %l200)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t562, ptr %l202
  br label %bb101
bb101:
  %t563 = load ptr, ptr %l14, !tbaa !29
  %t565 = load ptr, ptr %l198, !tbaa !29
  %t566 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l202
  call void @compiler_2ffree_3aFree_2ector(ptr %t564, ptr %v1, ptr %v4, ptr %v4, ptr %v4, ptr %t565, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t566, ptr %t563)
  call void @llvm.memmove.p0.p0.i64(ptr %l204, ptr %t564, i64 7600, i1 false)
  br label %bb102
bb102:
  %t568 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 7600, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t568, ptr %l204, i64 7600, i1 false)
  store ptr %t568, ptr %l18, !tbaa !29
  %t570 = load ptr, ptr %l18, !tbaa !29
  store ptr %t570, ptr %l206, !tbaa !29
  %t571 = load ptr, ptr %l14, !tbaa !29
  %t573 = getelementptr %"compiler/scope:Scoper", ptr %t571, i32 0, i32 2
  %t574 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t573
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t574, ptr %l208
  %t576 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %s0, ptr %l208)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t576, ptr %l210
  br label %bb103
bb103:
  %t577 = load ptr, ptr %l1, !tbaa !29
  %t579 = getelementptr %"compiler/check:Checker", ptr %t577, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !29
  %t582 = getelementptr %"compiler/generic:Program", ptr %t580, i32 0, i32 0
  %t583 = load ptr, ptr %t582, !tbaa !29
  %t585 = getelementptr %"compiler/load:Loader", ptr %t583, i32 0, i32 12
  %t586 = load i64, ptr %t585, !tbaa !24
  %t587 = load ptr, ptr %l206, !tbaa !29
  %t588 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l210
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v4, ptr %v4, ptr %t587, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t588, i64 %t586)
  br label %bb104
bb104:
  %t590 = load ptr, ptr %l13, !tbaa !29
  store ptr %t590, ptr %l215, !tbaa !29
  %t591 = load ptr, ptr %l18, !tbaa !29
  %t593 = getelementptr %"compiler/free:Free", ptr %t591, i32 0, i32 3
  %t594 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t593
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t594, ptr %l217
  %t596 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v4, ptr %l217)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t596, ptr %l219
  br label %bb105
bb105:
  %t597 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l219
  %t598 = load ptr, ptr %l215, !tbaa !29
  %t599 = getelementptr %"compiler/interp:Exec", ptr %t598, i32 0, i32 3
  %t600 = getelementptr %"compiler/lower:Lowerer", ptr %t599, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t597, ptr %t600
  store i64 0, ptr %l19, !tbaa !24
  %t601 = load ptr, ptr %l18, !tbaa !29
  %t603 = getelementptr %"compiler/free:Free", ptr %t601, i32 0, i32 2
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinCount(ptr %v4, ptr %t604)
  store i64 %t606, ptr %l222
  br label %bb106
bb106:
  %t607 = load i64, ptr %l222, !tbaa !24
  store i64 %t607, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t608 = load i64, ptr %l20, !tbaa !24
  %t609 = load i64, ptr %l19, !tbaa !24
  %t612 = icmp sgt i64 %t608, %t609
  br i1 %t612, label %bb107, label %bb108
bb107:
  %t614 = load i64, ptr %l21, !tbaa !24
  %t616 = icmp sgt i64 %t614, 0
  br i1 %t616, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l226, !tbaa !24
  br label %bb112
bb109:
  %t618 = load i64, ptr %l20, !tbaa !24
  %t619 = load i64, ptr %l19, !tbaa !24
  %t622 = sub i64 %t618, %t619
  %t623 = load i64, ptr %l21, !tbaa !24
  %t626 = add i64 %t622, %t623
  %t628 = sub i64 %t626, 1
  %t629 = load i64, ptr %l21, !tbaa !24
  %t632 = sdiv i64 %t628, %t629
  store i64 %t632, ptr %l229, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l229, !tbaa !24
  br label %bb111
bb111:
  %t634 = load i64, ptr %l229, !tbaa !24
  store i64 %t634, ptr %l226, !tbaa !24
  br label %bb112
bb112:
  %t635 = load i64, ptr %l226, !tbaa !24
  store i64 %t635, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb113
bb113:
  %t636 = load i64, ptr %l23, !tbaa !24
  %t637 = load i64, ptr %l22, !tbaa !24
  %t640 = icmp slt i64 %t636, %t637
  %t642 = xor i1 %t640, true
  br i1 %t642, label %bb114, label %bb115
bb114:
  br label %bb128
bb115:
  br label %bb116
bb116:
  %t644 = load i64, ptr %l19, !tbaa !24
  %t645 = load i64, ptr %l23, !tbaa !24
  %t646 = load i64, ptr %l21, !tbaa !24
  %t649 = mul i64 %t645, %t646
  %t652 = add i64 %t644, %t649
  store i64 %t652, ptr %l24, !tbaa !24
  %t654 = load ptr, ptr %l13, !tbaa !29
  %t656 = getelementptr %"compiler/interp:Exec", ptr %t654, i32 0, i32 3
  %t657 = getelementptr %"compiler/lower:Lowerer", ptr %t656, i32 0, i32 8
  store ptr %t657, ptr %l248, !tbaa !29
  %t658 = load ptr, ptr %l18, !tbaa !29
  %t660 = getelementptr %"compiler/free:Free", ptr %t658, i32 0, i32 2
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t662 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinPlan(ptr %t663, ptr %v4, ptr %v4, ptr %t661, i64 %t662)
  call void @llvm.memmove.p0.p0.i64(ptr %l252, ptr %t663, i64 584, i1 false)
  br label %bb117
bb117:
  %t666 = load ptr, ptr %l248, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t667, ptr %l252, i64 584, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ePush_3ccompiler_2ftyped_3aPlan_3e(ptr %v4, ptr %v4, ptr %t666, ptr %t667)
  br label %bb118
bb118:
  %t668 = load ptr, ptr %l13, !tbaa !29
  %t670 = getelementptr %"compiler/interp:Exec", ptr %t668, i32 0, i32 3
  %t671 = getelementptr %"compiler/lower:Lowerer", ptr %t670, i32 0, i32 9
  store ptr %t671, ptr %l254, !tbaa !29
  %t672 = load ptr, ptr %l18, !tbaa !29
  %t674 = getelementptr %"compiler/free:Free", ptr %t672, i32 0, i32 2
  %t675 = load ptr, ptr %t674, !tbaa !29
  %t676 = load i64, ptr %l24, !tbaa !24
  %t679 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinOwn(ptr %v4, ptr %t675, i64 %t676)
  store i1 %t679, ptr %l258
  br label %bb119
bb119:
  %t680 = load ptr, ptr %l254, !tbaa !29
  %t681 = load i1, ptr %l258, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v4, ptr %t680, i1 %t681)
  br label %bb120
bb120:
  %t682 = load ptr, ptr %l13, !tbaa !29
  %t684 = getelementptr %"compiler/interp:Exec", ptr %t682, i32 0, i32 3
  %t685 = getelementptr %"compiler/lower:Lowerer", ptr %t684, i32 0, i32 10
  store ptr %t685, ptr %l260, !tbaa !29
  %t686 = load ptr, ptr %l18, !tbaa !29
  %t688 = getelementptr %"compiler/free:Free", ptr %t686, i32 0, i32 2
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t690 = load i64, ptr %l24, !tbaa !24
  %t693 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinBody(ptr %v4, ptr %t689, i64 %t690)
  store i64 %t693, ptr %l264
  br label %bb121
bb121:
  %t694 = load ptr, ptr %l260, !tbaa !29
  %t695 = load i64, ptr %l264, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v4, ptr %t694, i64 %t695)
  br label %bb122
bb122:
  %t696 = load ptr, ptr %l13, !tbaa !29
  %t698 = getelementptr %"compiler/interp:Exec", ptr %t696, i32 0, i32 3
  %t699 = getelementptr %"compiler/lower:Lowerer", ptr %t698, i32 0, i32 11
  store ptr %t699, ptr %l266, !tbaa !29
  %t700 = call ptr @__olang_scope_hold(ptr %v4)
  %t701 = ptrtoint ptr %t700 to i64
  store i64 %t701, ptr %l267, !tbaa !24
  %t702 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t702, label %bb123, label %bb124
bb123:
  %t704 = call ptr @__olang_region_make(ptr %v4)
  %t705 = ptrtoint ptr %t704 to i64
  store i64 %t705, ptr %l267, !tbaa !24
  br label %bb124
bb124:
  %t706 = load ptr, ptr %l18, !tbaa !29
  %t708 = getelementptr %"compiler/free:Free", ptr %t706, i32 0, i32 2
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t710 = load i64, ptr %l24, !tbaa !24
  %t711 = load i64, ptr %l267
  %t712 = inttoptr i64 %t711 to ptr
  %t715 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinStable(ptr %v4, ptr %t712, ptr %t709, i64 %t710)
  store { i64, ptr } %t715, ptr %l272
  br label %bb125
bb125:
  %t716 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t717 = load i64, ptr %l267
  %t718 = inttoptr i64 %t717 to ptr
  %t719 = extractvalue { i64, ptr } %t716, 0
  %t720 = extractvalue { i64, ptr } %t716, 1
  %t721 = mul i64 %t719, 1
  %t722 = call ptr @__olang_held_alloc(ptr %t718, i64 %t721)
  call void @llvm.memcpy.p0.p0.i64(ptr %t722, ptr %t720, i64 %t721, i1 false)
  %t723 = insertvalue { i64, ptr } undef, i64 %t719, 0
  %t724 = insertvalue { i64, ptr } %t723, ptr %t722, 1
  %t725 = load ptr, ptr %l266, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t725, { i64, ptr } %t724)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t727 = load i64, ptr %l23, !tbaa !24
  %t730 = add i64 %t727, 1
  store i64 %t730, ptr %l23, !tbaa !24
  br label %bb113
bb128:
  %t732 = load ptr, ptr %l13, !tbaa !29
  %t733 = load ptr, ptr %l18, !tbaa !29
  %t737 = getelementptr %"compiler/interp:Exec", ptr %t732, i32 0, i32 3
  %t738 = getelementptr %"compiler/lower:Lowerer", ptr %t737, i32 0, i32 12
  store ptr %t733, ptr %t738, !tbaa !29
  %t739 = load ptr, ptr %l13, !tbaa !29
  store ptr %t739, ptr %l280, !tbaa !29
  %t740 = call ptr @__olang_scope_hold(ptr %v4)
  %t741 = ptrtoint ptr %t740 to i64
  store i64 %t741, ptr %l281, !tbaa !24
  %t742 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e5
  br i1 %t742, label %bb129, label %bb130
bb129:
  %t744 = call ptr @__olang_region_make(ptr %v4)
  %t745 = ptrtoint ptr %t744 to i64
  store i64 %t745, ptr %l281, !tbaa !24
  br label %bb130
bb130:
  %t746 = load ptr, ptr %l18, !tbaa !29
  %t748 = getelementptr %"compiler/free:Free", ptr %t746, i32 0, i32 109
  %t749 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t748
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t749, ptr %l285
  %t751 = load i64, ptr %l281
  %t752 = inttoptr i64 %t751 to ptr
  %t753 = call ptr @__olang_scope_hold(ptr %t752)
  %t754 = ptrtoint ptr %t753 to i64
  store i64 %t754, ptr %l286, !tbaa !24
  %t755 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t755, label %bb131, label %bb132
bb131:
  %t757 = load i64, ptr %l281
  %t758 = inttoptr i64 %t757 to ptr
  %t759 = call ptr @__olang_region_make_part(ptr %t758)
  %t760 = ptrtoint ptr %t759 to i64
  store i64 %t760, ptr %l286, !tbaa !24
  br label %bb132
bb132:
  %t761 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t762 = load { i64, ptr }, ptr %t761, !tbaa !27
  store { i64, ptr } %t762, ptr %l288, !tbaa !27
  %t763 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t763, 0
  store i64 %t764, ptr %l289, !tbaa !24
  %t765 = load i64, ptr %l289, !tbaa !24
  %t766 = mul i64 %t765, 1
  %t767 = load i64, ptr %l286
  %t768 = inttoptr i64 %t767 to ptr
  %t769 = call ptr @__olang_held_alloc(ptr %t768, i64 %t766)
  %t770 = insertvalue { i64, ptr } undef, i64 %t765, 0
  %t771 = insertvalue { i64, ptr } %t770, ptr %t769, 1
  store { i64, ptr } %t771, ptr %l290, !tbaa !27
  %t772 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t773 = load ptr, ptr %t772, !tbaa !27
  %t774 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = load i64, ptr %l289, !tbaa !24
  %t777 = mul i64 %t776, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t773, ptr %t775, i64 %t777, i1 false)
  %t778 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t779 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  store { i64, ptr } %t778, ptr %t779, !tbaa !27
  %t780 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t780, label %bb133, label %bb134
bb133:
  %t782 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t783 = load { i64, ptr }, ptr %t782, !tbaa !27
  %t784 = extractvalue { i64, ptr } %t783, 0
  %t786 = icmp eq i64 %t784, 0
  br i1 %t786, label %bb135, label %bb136
bb134:
  %t788 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e5
  br i1 %t788, label %bb137, label %bb138
bb135:
  %t790 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t790, !tbaa !27
  br label %bb136
bb136:
  %t791 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t792 = load i64, ptr %l286
  %t793 = inttoptr i64 %t792 to ptr
  %t794 = load { i64, ptr }, ptr %t791
  %t795 = extractvalue { i64, ptr } %t794, 1
  %t796 = call ptr @__olang_region_or(ptr %t795, ptr null)
  %t797 = icmp ne ptr %t796, null
  %t798 = select i1 %t797, ptr %t796, ptr null
  call void @__olang_region_settle_in(ptr %t793, ptr %t798)
  br label %bb134
bb137:
  %t799 = load i64, ptr %l281
  %t800 = inttoptr i64 %t799 to ptr
  %t801 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t802 = load { i64, ptr }, ptr %t801
  %t803 = extractvalue { i64, ptr } %t802, 1
  %t804 = call ptr @__olang_region_or(ptr %t803, ptr null)
  %t805 = call ptr @__olang_region_home(ptr %t804)
  %t806 = icmp ne ptr %t805, null
  %t807 = select i1 %t806, ptr %t805, ptr null
  call void @__olang_region_settle_in(ptr %t800, ptr %t807)
  br label %bb138
bb138:
  %t808 = load ptr, ptr %l280, !tbaa !29
  %t809 = getelementptr %"compiler/interp:Exec", ptr %t808, i32 0, i32 4
  %t810 = getelementptr %"compiler/eval:Machine", ptr %t809, i32 0, i32 5
  %t811 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t810
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t811, ptr %l295
  %t812 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285
  %t813 = load ptr, ptr %l280, !tbaa !29
  %t814 = getelementptr %"compiler/interp:Exec", ptr %t813, i32 0, i32 4
  %t815 = getelementptr %"compiler/eval:Machine", ptr %t814, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t812, ptr %t815
  %t816 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e5
  br i1 %t816, label %bb139, label %bb140
bb139:
  %t818 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l295, i32 0, i32 0
  %t819 = load { i64, ptr }, ptr %t818
  %t820 = extractvalue { i64, ptr } %t819, 1
  %t821 = call ptr @__olang_region_or(ptr %t820, ptr null)
  %t822 = call ptr @__olang_region_home(ptr %t821)
  %t823 = icmp ne ptr %t822, null
  %t824 = select i1 %t823, ptr %t822, ptr null
  call void @__olang_region_drop(ptr %t824)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l295
  br label %bb140
bb140:
  %t825 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t825, label %bb141, label %bb142
bb141:
  %t827 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l295, i32 0, i32 0
  %t828 = load { i64, ptr }, ptr %t827
  %t829 = extractvalue { i64, ptr } %t828, 0
  %t830 = extractvalue { i64, ptr } %t828, 1
  call void @__olang_region_release_part(ptr %t830, i64 %t829)
  store { i64, ptr } zeroinitializer, ptr %t827
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s23
  %t831 = load ptr, ptr %l18, !tbaa !29
  %t833 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eGenOkNow(ptr %v4, ptr %s23, ptr %t831)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t833, ptr %l299
  br label %bb143
bb143:
  %t835 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_H6f71158bb7f05bccd7cf814e6c677229(ptr %s23, ptr %l299)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t835, ptr %l301
  br label %bb144
bb144:
  %t836 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l301
  %t837 = call ptr @__olang_scope_alloc_a(ptr %s23, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t836, ptr %t837
  store ptr %t837, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb145
bb145:
  %t839 = load i64, ptr %l26, !tbaa !24
  store i64 %t839, ptr %l303, !tbaa !24
  %t840 = load ptr, ptr %l25, !tbaa !29
  %t842 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H39bf208114dde5103bad7bf7476536d8(ptr %s23, ptr %t840)
  store i64 %t842, ptr %l305
  br label %bb146
bb146:
  %t843 = load i64, ptr %l303, !tbaa !24
  %t844 = load i64, ptr %l305, !tbaa !24
  %t845 = icmp slt i64 %t843, %t844
  %t847 = xor i1 %t845, true
  br i1 %t847, label %bb147, label %bb148
bb147:
  br label %bb155
bb148:
  br label %bb149
bb149:
  %t849 = load ptr, ptr %l25, !tbaa !29
  %t850 = load i64, ptr %l26, !tbaa !24
  %t853 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6d56ff767ac7b72ad0cd898fedbf4594(ptr %s23, ptr %t849, i64 %t850)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t853, ptr %l310
  br label %bb150
bb150:
  %t854 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l310
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t854, ptr %l27
  %t855 = load ptr, ptr %l13, !tbaa !29
  %t857 = getelementptr %"compiler/interp:Exec", ptr %t855, i32 0, i32 4
  %t858 = getelementptr %"compiler/eval:Machine", ptr %t857, i32 0, i32 8
  store ptr %t858, ptr %l312, !tbaa !29
  %t859 = call ptr @__olang_scope_hold(ptr %v4)
  %t860 = ptrtoint ptr %t859 to i64
  store i64 %t860, ptr %l313, !tbaa !24
  %t861 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t861, label %bb151, label %bb152
bb151:
  %t863 = call ptr @__olang_region_make(ptr %v4)
  %t864 = ptrtoint ptr %t863 to i64
  store i64 %t864, ptr %l313, !tbaa !24
  br label %bb152
bb152:
  %t865 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l27, i32 0, i32 0
  %t866 = load i64, ptr %t865, !tbaa !24
  %t867 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l27, i32 0, i32 1
  %t868 = load i32, ptr %t867, !tbaa !23
  %t870 = call i64 @__olang_fmt_i64(ptr null, i64 %t866)
  %t871 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t872 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t873 = add i64 %t870, %t872
  %t875 = sext i32 %t868 to i64
  %t876 = call i64 @__olang_fmt_i64(ptr null, i64 %t875)
  %t877 = add i64 %t873, %t876
  %t878 = load i64, ptr %l313
  %t879 = inttoptr i64 %t878 to ptr
  %t880 = call ptr @__olang_held_alloc(ptr %t879, i64 %t877)
  %t881 = call i64 @__olang_fmt_i64(ptr %t880, i64 %t866)
  %t882 = getelementptr i8, ptr %t880, i64 %t870
  call void @olang_textcopy(ptr %t882, ptr %t871, i64 %t872)
  %t883 = getelementptr i8, ptr %t882, i64 %t872
  %t884 = call i64 @__olang_fmt_i64(ptr %t883, i64 %t875)
  %t885 = insertvalue { i64, ptr } undef, i64 %t877, 0
  %t886 = insertvalue { i64, ptr } %t885, ptr %t880, 1
  %t888 = load ptr, ptr %l312, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v4, ptr %v4, ptr %t888, { i64, ptr } %t886, i1 true)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t890 = load i64, ptr %l26, !tbaa !24
  %t893 = add i64 %t890, 1
  store i64 %t893, ptr %l26, !tbaa !24
  br label %bb145
bb155:
  call void @__olang_scope_close(ptr %s23)
  %t895 = load ptr, ptr %l13, !tbaa !29
  %t897 = getelementptr %"compiler/interp:Exec", ptr %t895, i32 0, i32 4
  %t898 = getelementptr %"compiler/eval:Machine", ptr %t897, i32 0, i32 83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t898, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb156
bb156:
  %t900 = load ptr, ptr %l0, !tbaa !29
  %t902 = getelementptr %"compiler/prompt:Session", ptr %t900, i32 0, i32 6
  %t903 = load { ptr, ptr }, ptr %t902
  %t905 = extractvalue { ptr, ptr } %t903, 0
  %t906 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t907 = icmp eq ptr %t905, %t906
  %t908 = extractvalue { ptr, ptr } %t903, 1
  %t909 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t910 = icmp eq ptr %t908, %t909
  %t911 = and i1 %t907, %t910
  %t913 = xor i1 %t911, true
  br i1 %t913, label %bb157, label %bb158
bb157:
  %t915 = load ptr, ptr %l13, !tbaa !29
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t918 = getelementptr %"compiler/prompt:Session", ptr %t916, i32 0, i32 6
  %t919 = load { ptr, ptr }, ptr %t918
  %t923 = getelementptr %"compiler/interp:Exec", ptr %t915, i32 0, i32 4
  %t924 = getelementptr %"compiler/eval:Machine", ptr %t923, i32 0, i32 3
  store { ptr, ptr } %t919, ptr %t924
  %t925 = load ptr, ptr %l13, !tbaa !29
  %t927 = getelementptr %"compiler/interp:Exec", ptr %t925, i32 0, i32 4
  %t928 = getelementptr %"compiler/eval:Machine", ptr %t927, i32 0, i32 2
  store i64 0, ptr %t928, !tbaa !24
  br label %bb159
bb158:
  br label %bb159
bb159:
  %t929 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t929, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2emismatched(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/prompt:Value"
  %l8 = alloca { %"compiler/eval:Ptr", i32 }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l13 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"compiler/prompt:Value"
  %l28 = alloca { %"compiler/eval:Ptr", i32 }
  %l30 = alloca ptr
  %l34 = alloca i64
  %l40 = alloca i32
  %l41 = alloca { %"compiler/eval:Ptr", i32 }
  %l42 = alloca i32
  %l44 = alloca i1
  %l49 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t10 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i64 @compiler_2fprompt_2ecellBody(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb2
bb2:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = trunc i64 %t7 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 0
  store i64 0, ptr %t11
  %t13 = insertvalue { i32 } undef, i32 %t8, 0
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  store { i32 } %t13, ptr %t14
  %t15 = load { i64, [2 x i64] }, ptr %t10
  %t16 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v2, ptr %t16, { i64, [2 x i64] } %t15)
  br label %bb3
bb3:
  store ptr %a3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l6, !tbaa !24
  store i64 %t20, ptr %l18, !tbaa !24
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t21)
  store i64 %t23, ptr %l20
  br label %bb5
bb5:
  %t24 = load i64, ptr %l18, !tbaa !24
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t30, i64 %t31)
  store %"compiler/prompt:Value" %t34, ptr %l25
  br label %bb9
bb9:
  %t35 = load %"compiler/prompt:Value", ptr %l25
  store %"compiler/prompt:Value" %t35, ptr %l7
  %t36 = getelementptr %"compiler/prompt:Value", ptr %l7, i32 0, i32 3
  %t37 = load i64, ptr %t36, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/interp:Exec", ptr %t41, i32 0, i32 4
  store ptr %t43, ptr %l30, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 12
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = getelementptr %"compiler/prompt:Value", ptr %l7, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t68 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v3, ptr %t63, { i64, ptr } %t65)
  store i32 %t68, ptr %l40
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l30, !tbaa !29
  %t70 = load i64, ptr %l34, !tbaa !24
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v2, ptr %t69, i64 %t70, i32 %t71)
  %t73 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t72, 1
  %t74 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t72, 0
  store i32 %t74, ptr %l42
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb15, label %ok.76, !prof !99
ok.76:
  store { %"compiler/eval:Ptr", i32 } %t73, ptr %l41
  br label %bb14
bb14:
  %t77 = load { %"compiler/eval:Ptr", i32 }, ptr %l41
  store { %"compiler/eval:Ptr", i32 } %t77, ptr %l28
  br label %bb17
bb15:
  %t78 = load i32, ptr %l42, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb17:
  %t82 = load { %"compiler/eval:Ptr", i32 }, ptr %l28
  store { %"compiler/eval:Ptr", i32 } %t82, ptr %l8
  %t83 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 1
  %t84 = load i32, ptr %t83, !tbaa !23
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/interp:Exec", ptr %t86, i32 0, i32 4
  %t92 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v2, ptr %s2, ptr %t88, i32 %t84)
  store { i64, ptr } %t92, ptr %l49
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t94 = getelementptr %"compiler/prompt:Value", ptr %l7, i32 0, i32 4
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %v3, { i64, ptr } %t93, { i64, ptr } %t95)
  store i1 %t98, ptr %l52
  br label %bb19
bb19:
  %t99 = load i1, ptr %l52, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb20, label %bb21
bb20:
  store ptr %l4, ptr %l54, !tbaa !29
  %t102 = call ptr @__olang_scope_hold(ptr %v4)
  %t103 = ptrtoint ptr %t102 to i64
  store i64 %t103, ptr %l55, !tbaa !24
  %t104 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t104, label %bb22, label %bb23
bb21:
  br label %bb25
bb22:
  %t106 = call ptr @__olang_region_make(ptr %v4)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t108 = getelementptr %"compiler/prompt:Value", ptr %l7, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = load i64, ptr %l55
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = call ptr @__olang_held_alloc(ptr %t114, i64 %t112)
  call void @olang_textcopy(ptr %t115, ptr %t111, i64 %t112)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t119, { i64, ptr } %t117)
  br label %bb24
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l6, !tbaa !24
  br label %bb4
bb27:
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eprobes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/prompt:item"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/prompt:item"
  %l22 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l37 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/prompt:Session", ptr %a0, i32 0, i32 11
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = call ptr @__olang_scope_or(ptr %v2, ptr %t6)
  %t8 = call ptr @__olang_scope_hold(ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t11, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb1
bb1:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/prompt:cell", ptr %t16, i32 0, i32 2
  store ptr %t18, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v1, ptr %t21)
  store i64 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v1, ptr %v1, ptr %t30, i64 %t31)
  store %"compiler/prompt:item" %t34, ptr %l20
  br label %bb10
bb10:
  %t35 = load %"compiler/prompt:item", ptr %l20
  store %"compiler/prompt:item" %t35, ptr %l4
  %t36 = getelementptr %"compiler/prompt:item", ptr %l4, i32 0, i32 5
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t36)
  store i64 %t38, ptr %l22
  br label %bb11
bb11:
  %t39 = load i64, ptr %l22, !tbaa !24
  %t40 = icmp sgt i64 %t39, 0
  br i1 %t40, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t43 = getelementptr %"compiler/prompt:item", ptr %l4, i32 0, i32 3
  %t44 = load i1, ptr %t43, !tbaa !21
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/prompt:cell", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l28, !tbaa !27
  %t52 = getelementptr %"compiler/prompt:item", ptr %l4, i32 0, i32 0
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = getelementptr %"compiler/prompt:item", ptr %l4, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l31, !tbaa !24
  %t58 = load i64, ptr %l29, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l30, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_c095982bd76c0dde_ab739287ff4badb2)
  unreachable
bb20:
  %t65 = load i64, ptr %l30, !tbaa !24
  %t66 = load i64, ptr %l31, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_c095982bd76c0dde_ab739287ff4badb2)
  unreachable
bb22:
  %t69 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l29, !tbaa !24
  %t72 = load i64, ptr %l30, !tbaa !24
  %t73 = getelementptr i8, ptr %t70, i64 %t71
  %t74 = sub i64 %t72, %t71
  %t75 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  store { i64, ptr } %t76, ptr %l5, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t78, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t80, ptr %l37
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c095982bd76c0dde_ab739287ff4badb2)
  unreachable
bb24:
  %t81 = load i1, ptr %l37, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb25, label %bb26
bb25:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t84, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t86, ptr %l41
  br label %bb27
bb26:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb28
bb27:
  %t87 = load i1, ptr %l41, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l3, !tbaa !24
  br label %bb5
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, ptr %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/prompt:Value"
  %l17 = alloca { i64, [5 x i64] }
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/prompt:Value"
  %l22 = alloca { %"compiler/eval:Ptr", i32 }
  %l23 = alloca %"compiler/eval:Ptr"
  %l24 = alloca i32
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/prompt:Value"
  %l29 = alloca { i64, ptr }
  %l30 = alloca { %"compiler/eval:Ptr", i32 }
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i64
  %l34 = alloca %"compiler/prompt:Value"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/prompt:Decl"
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca %"compiler/prompt:Value"
  %l42 = alloca { %"compiler/eval:Ptr", i32 }
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i64
  %l46 = alloca %"compiler/prompt:Value"
  %l48 = alloca i64
  %l63 = alloca %"std/prelude/text:StringBuilder"
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca %"compiler/prompt:Value"
  %l80 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i64
  %l90 = alloca i32
  %l95 = alloca { i64, [5 x i64] }
  %l99 = alloca ptr
  %l100 = alloca { i64, [2 x i64] }
  %l104 = alloca { i64, [5 x i64] }
  %l108 = alloca ptr
  %l109 = alloca i64
  %l115 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l125 = alloca i64
  %l127 = alloca i64
  %l132 = alloca %"compiler/prompt:Value"
  %l135 = alloca %"compiler/prompt:Value"
  %l143 = alloca i1
  %l146 = alloca { %"compiler/eval:Ptr", i32 }
  %l148 = alloca ptr
  %l149 = alloca i64
  %l150 = alloca ptr
  %l151 = alloca i64
  %l155 = alloca i32
  %l156 = alloca { %"compiler/eval:Ptr", i32 }
  %l157 = alloca i32
  %l159 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i64
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l175 = alloca i64
  %l179 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l186 = alloca i1
  %l188 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l197 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l199 = alloca i64
  %l201 = alloca i64
  %l206 = alloca %"compiler/prompt:Value"
  %l208 = alloca i1
  %l211 = alloca { i64, ptr }
  %l217 = alloca { %"compiler/eval:Ptr", i32 }
  %l219 = alloca ptr
  %l220 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca i64
  %l226 = alloca i32
  %l227 = alloca { %"compiler/eval:Ptr", i32 }
  %l228 = alloca i32
  %l230 = alloca i1
  %l232 = alloca i64
  %l234 = alloca ptr
  %l235 = alloca i64
  %l236 = alloca ptr
  %l237 = alloca i64
  %l241 = alloca i32
  %l244 = alloca i64
  %l245 = alloca i32
  %l247 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l254 = alloca i64
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l265 = alloca %"compiler/prompt:Value"
  %l267 = alloca i64
  %l272 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l282 = alloca i64
  %l284 = alloca i64
  %l289 = alloca %"compiler/prompt:Decl"
  %l291 = alloca i1
  %l292 = alloca i1
  %l294 = alloca i1
  %l295 = alloca i1
  %l298 = alloca { i64, ptr }
  %l299 = alloca i1
  %l301 = alloca i1
  %l304 = alloca i64
  %l306 = alloca i64
  %l311 = alloca %"compiler/prompt:Value"
  %l314 = alloca i1
  %l319 = alloca { %"compiler/eval:Ptr", i32 }
  %l321 = alloca ptr
  %l322 = alloca i64
  %l323 = alloca ptr
  %l324 = alloca i64
  %l328 = alloca i32
  %l329 = alloca { %"compiler/eval:Ptr", i32 }
  %l330 = alloca i32
  %l332 = alloca i1
  %l334 = alloca i64
  %l336 = alloca ptr
  %l337 = alloca i64
  %l338 = alloca ptr
  %l339 = alloca i64
  %l343 = alloca i32
  %l346 = alloca i64
  %l347 = alloca i32
  %l349 = alloca i1
  %l350 = alloca ptr
  %l351 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l356 = alloca i64
  %l361 = alloca %"compiler/prompt:Value"
  %l363 = alloca i64
  %l368 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l384 = alloca { i64, [5 x i64] }
  %l385 = alloca ptr
  %l386 = alloca i64
  %l390 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l391 = alloca i64
  %l393 = alloca { i64, ptr }
  %l394 = alloca i64
  %l395 = alloca { i64, ptr }
  %l400 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l403 = alloca ptr
  %l404 = alloca i64
  %l407 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l408 = alloca i64
  %l410 = alloca { i64, ptr }
  %l411 = alloca i64
  %l412 = alloca { i64, ptr }
  %l417 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l420 = alloca ptr
  %l421 = alloca i64
  %l424 = alloca { i64, ptr }
  %l426 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %t9 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a6, ptr %l6
  store ptr %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @compiler_2fprompt_2ecellBody(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l48
  br label %bb1
bb1:
  %t4 = load i64, ptr %l48, !tbaa !24
  store i64 %t4, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l8, !tbaa !24
  %t7 = trunc i64 %t5 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [2 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t12 = insertvalue { i32 } undef, i32 %t7, 0
  %t13 = getelementptr { i64, [2 x i64] }, ptr %t9, i32 0, i32 1
  store { i32 } %t12, ptr %t13
  %t14 = load { i64, [2 x i64] }, ptr %t9
  store { i64, [2 x i64] } %t14, ptr %l9
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v2, ptr %t16, { i64, [2 x i64] } %t17)
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 12
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l10, !tbaa !24
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/load:Loader", ptr %t37, i32 0, i32 3
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l11, !tbaa !29
  %t42 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t42, ptr %l63
  br label %bb3
bb3:
  %t43 = load %"std/prelude/text:StringBuilder", ptr %l63
  store %"std/prelude/text:StringBuilder" %t43, ptr %l12
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erestore(ptr %v0, ptr %v1, ptr %v2, ptr %v5, ptr %s0, ptr %t44, ptr %t45, ptr %t46, ptr %a5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l68
  br label %bb4
bb4:
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l13
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/prompt:cell", ptr %t54, i32 0, i32 3
  store ptr %t56, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l15, !tbaa !24
  store i64 %t58, ptr %l71, !tbaa !24
  %t59 = load ptr, ptr %l14, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v6, ptr %t59)
  store i64 %t61, ptr %l73
  br label %bb6
bb6:
  %t62 = load i64, ptr %l71, !tbaa !24
  %t63 = load i64, ptr %l73, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t68 = load ptr, ptr %l14, !tbaa !29
  %t69 = load i64, ptr %l15, !tbaa !24
  %t72 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v6, ptr %v6, ptr %t68, i64 %t69)
  store %"compiler/prompt:Value" %t72, ptr %l78
  br label %bb10
bb10:
  %t73 = load %"compiler/prompt:Value", ptr %l78
  store %"compiler/prompt:Value" %t73, ptr %l16
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/interp:Exec", ptr %t74, i32 0, i32 4
  store ptr %t76, ptr %l80, !tbaa !29
  %t77 = load i64, ptr %l10, !tbaa !24
  store i64 %t77, ptr %l81, !tbaa !24
  %t78 = load ptr, ptr %l11, !tbaa !29
  store ptr %t78, ptr %l82, !tbaa !29
  %t79 = call ptr @__olang_scope_hold(ptr %v1)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l83, !tbaa !24
  %t81 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t81, label %bb11, label %bb12
bb11:
  %t83 = load ptr, ptr %l82, !tbaa !29
  %t84 = call ptr @__olang_region_or(ptr %t83, ptr %v1)
  %t85 = call ptr @__olang_scope_hold(ptr %t84)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l83, !tbaa !24
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l11, !tbaa !29
  %t88 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eKeepPrefix, !tbaa !27
  %t89 = getelementptr %"compiler/prompt:Value", ptr %l16, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t88, 1
  %t93 = extractvalue { i64, ptr } %t88, 0
  %t95 = extractvalue { i64, ptr } %t90, 1
  %t96 = extractvalue { i64, ptr } %t90, 0
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t92, i64 %t93)
  %t99 = getelementptr i8, ptr %t98, i64 %t93
  call void @olang_textcopy(ptr %t99, ptr %t95, i64 %t96)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  %t103 = load i64, ptr %l83
  %t104 = inttoptr i64 %t103 to ptr
  %t107 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t104, ptr %s2, ptr %t87, { i64, ptr } %t101)
  store i32 %t107, ptr %l90
  br label %bb13
bb13:
  %t108 = load ptr, ptr %l80, !tbaa !29
  %t109 = load i64, ptr %l81, !tbaa !24
  %t110 = load i32, ptr %l90, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eMarkSet(ptr %v2, ptr %t108, i64 %t109, i32 %t110)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t111 = load i64, ptr %l15, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l15, !tbaa !24
  br label %bb5
bb16:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = call { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v2, ptr %s0, ptr %t116)
  store { i64, [5 x i64] } %t118, ptr %l95
  br label %bb17
bb17:
  %t119 = load { i64, [5 x i64] }, ptr %l95
  store { i64, [5 x i64] } %t119, ptr %l17
  %t120 = load { i64, [5 x i64] }, ptr %l17
  %t122 = extractvalue { i64, [5 x i64] } %t120, 0
  %t123 = icmp eq i64 %t122, 0
  br i1 %t123, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/interp:Exec", ptr %t125, i32 0, i32 4
  store ptr %t127, ptr %l99, !tbaa !29
  %t128 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t128, ptr %l100
  %t129 = icmp sge i64 0, 0
  br i1 %t129, label %bb20, label %bb21
bb19:
  br label %bb25
bb20:
  %t131 = icmp sle i64 0, 1152921504606846975
  br i1 %t131, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a211c8d235081e84_d100b21f1be88968)
  unreachable
bb22:
  %t133 = mul i64 0, 8
  %t134 = insertvalue { i64, ptr } undef, i64 0, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t136 = load ptr, ptr %l99, !tbaa !29
  %t137 = load { i64, [2 x i64] }, ptr %l100
  %t139 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v2, ptr %s5, ptr %s0, ptr %t136, { i64, [2 x i64] } %t137, { i64, ptr } %t135)
  store { i64, [5 x i64] } %t139, ptr %l104
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a211c8d235081e84_d100b21f1be88968)
  unreachable
bb24:
  %t140 = load { i64, [5 x i64] }, ptr %l104
  store { i64, [5 x i64] } %t140, ptr %l17
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t141 = load { i64, [5 x i64] }, ptr %l17
  %t143 = extractvalue { i64, [5 x i64] } %t141, 0
  %t144 = icmp eq i64 %t143, 0
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = load ptr, ptr %l7, !tbaa !29
  store ptr %t148, ptr %l108, !tbaa !29
  %t149 = call ptr @__olang_scope_hold(ptr %v7)
  %t150 = ptrtoint ptr %t149 to i64
  store i64 %t150, ptr %l109, !tbaa !24
  %t151 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t151, label %bb28, label %bb29
bb27:
  %t153 = load ptr, ptr %l6, !tbaa !29
  %t155 = getelementptr %"compiler/prompt:cell", ptr %t153, i32 0, i32 3
  store ptr %t155, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb34
bb28:
  %t157 = call ptr @__olang_region_make(ptr %v7)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l109, !tbaa !24
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t160 = load { i64, [5 x i64] }, ptr %l17
  %t161 = load i64, ptr %l8, !tbaa !24
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t167 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v2, ptr %s0, ptr %v3, ptr %s6, ptr %t159, { i64, [5 x i64] } %t160, i64 %t161, ptr %t162)
  store { i64, ptr } %t167, ptr %l115
  br label %bb30
bb30:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t172 = call { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v2, ptr %v3, ptr %s6, ptr %t168, ptr %t169)
  store { i64, ptr } %t172, ptr %l118
  br label %bb31
bb31:
  %t173 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = load i64, ptr %l109
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = call ptr @__olang_held_alloc(ptr %t184, i64 %t182)
  call void @olang_textcopy(ptr %t185, ptr %t174, i64 %t175)
  %t186 = getelementptr i8, ptr %t185, i64 %t175
  call void @olang_textcopy(ptr %t186, ptr %t176, i64 %t177)
  %t187 = getelementptr i8, ptr %t186, i64 %t177
  call void @olang_textcopy(ptr %t187, ptr %t180, i64 %t181)
  %t188 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t185, 1
  %t191 = load ptr, ptr %l108, !tbaa !29
  %t192 = getelementptr %"compiler/prompt:Reply", ptr %t191, i32 0, i32 4
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l121, !tbaa !27
  %t195 = load ptr, ptr %l108, !tbaa !29
  %t196 = getelementptr %"compiler/prompt:Reply", ptr %t195, i32 0, i32 4
  store { i64, ptr } %t189, ptr %t196, !tbaa !27
  %t197 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t197, label %bb32, label %bb33
bb32:
  %t199 = load { i64, ptr }, ptr %l121
  %t200 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release(ptr %t200)
  store { i64, ptr } zeroinitializer, ptr %l121
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb34:
  %t201 = load i64, ptr %l19, !tbaa !24
  store i64 %t201, ptr %l125, !tbaa !24
  %t202 = load ptr, ptr %l18, !tbaa !29
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v6, ptr %t202)
  store i64 %t204, ptr %l127
  br label %bb35
bb35:
  %t205 = load i64, ptr %l125, !tbaa !24
  %t206 = load i64, ptr %l127, !tbaa !24
  %t207 = icmp slt i64 %t205, %t206
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb36, label %bb37
bb36:
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t211 = load ptr, ptr %l18, !tbaa !29
  %t212 = load i64, ptr %l19, !tbaa !24
  %t215 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v6, ptr %v6, ptr %t211, i64 %t212)
  store %"compiler/prompt:Value" %t215, ptr %l132
  br label %bb39
bb39:
  %t216 = load %"compiler/prompt:Value", ptr %l132
  store %"compiler/prompt:Value" %t216, ptr %l20
  %t217 = getelementptr %"compiler/prompt:Value", ptr %l20, i32 0, i32 0
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t219 = getelementptr %"compiler/prompt:Value", ptr %l20, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t223 = call %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v6, ptr %v6, ptr %s0, { i64, ptr } %t218, { i64, ptr } %t220, i1 true)
  store %"compiler/prompt:Value" %t223, ptr %l135
  br label %bb40
bb40:
  %t224 = load %"compiler/prompt:Value", ptr %l135
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %s0, ptr %s0, ptr %l13, %"compiler/prompt:Value" %t224)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t228 = load i64, ptr %l19, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l19, !tbaa !24
  br label %bb34
bb43:
  br label %bb44
bb44:
  %t233 = load ptr, ptr %l6, !tbaa !29
  %t235 = getelementptr %"compiler/prompt:cell", ptr %t233, i32 0, i32 4
  %t236 = load i1, ptr %t235, !tbaa !21
  br i1 %t236, label %bb45, label %bb46
bb45:
  %t238 = load { i64, [5 x i64] }, ptr %l17
  %t240 = extractvalue { i64, [5 x i64] } %t238, 0
  %t241 = icmp eq i64 %t240, 0
  store i1 %t241, ptr %l143, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb47
bb47:
  %t243 = load i1, ptr %l143, !tbaa !21
  br i1 %t243, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s12
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr %"compiler/interp:Exec", ptr %t244, i32 0, i32 4
  store ptr %t246, ptr %l148, !tbaa !29
  %t247 = load i64, ptr %l10, !tbaa !24
  store i64 %t247, ptr %l149, !tbaa !24
  %t248 = load ptr, ptr %l11, !tbaa !29
  store ptr %t248, ptr %l150, !tbaa !29
  %t249 = call ptr @__olang_scope_hold(ptr %v1)
  %t250 = ptrtoint ptr %t249 to i64
  store i64 %t250, ptr %l151, !tbaa !24
  %t251 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t251, label %bb50, label %bb51
bb49:
  br label %bb74
bb50:
  %t253 = load ptr, ptr %l150, !tbaa !29
  %t254 = call ptr @__olang_region_or(ptr %t253, ptr %v1)
  %t255 = call ptr @__olang_scope_hold(ptr %t254)
  %t256 = ptrtoint ptr %t255 to i64
  store i64 %t256, ptr %l151, !tbaa !24
  br label %bb51
bb51:
  %t257 = load ptr, ptr %l11, !tbaa !29
  %t258 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eShownName, !tbaa !27
  %t259 = load i64, ptr %l151
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = load ptr, ptr @__olang_prog_scope
  %t264 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t260, ptr %t261, ptr %t257, { i64, ptr } %t258)
  store i32 %t264, ptr %l155
  br label %bb52
bb52:
  %t265 = load ptr, ptr %l148, !tbaa !29
  %t266 = load i64, ptr %l149, !tbaa !24
  %t267 = load i32, ptr %l155, !tbaa !23
  %t268 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v2, ptr %t265, i64 %t266, i32 %t267)
  %t269 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t268, 1
  %t270 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t268, 0
  store i32 %t270, ptr %l157
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb54, label %ok.272, !prof !99
ok.272:
  store { %"compiler/eval:Ptr", i32 } %t269, ptr %l156
  br label %bb53
bb53:
  %t273 = load { %"compiler/eval:Ptr", i32 }, ptr %l156
  store { %"compiler/eval:Ptr", i32 } %t273, ptr %l146
  br label %bb56
bb54:
  %t274 = load i32, ptr %l157, !tbaa !23
  %t275 = ashr i32 %t274, 16
  %t277 = icmp eq i32 %t275, 1
  store i1 %t277, ptr %l159, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t278 = load { %"compiler/eval:Ptr", i32 }, ptr %l146
  store { %"compiler/eval:Ptr", i32 } %t278, ptr %l22
  %t279 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l22, i32 0, i32 0
  %t280 = load %"compiler/eval:Ptr", ptr %t279
  store %"compiler/eval:Ptr" %t280, ptr %l23
  %t282 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l22, i32 0, i32 1
  %t283 = load i32, ptr %t282, !tbaa !23
  store i32 %t283, ptr %l24, !tbaa !23
  %t285 = load ptr, ptr %l7, !tbaa !29
  %t287 = getelementptr %"compiler/prompt:Reply", ptr %t285, i32 0, i32 2
  store i1 true, ptr %t287, !tbaa !21
  %t288 = load ptr, ptr %l7, !tbaa !29
  store ptr %t288, ptr %l163, !tbaa !29
  %t289 = call ptr @__olang_scope_hold(ptr %v7)
  %t290 = ptrtoint ptr %t289 to i64
  store i64 %t290, ptr %l164, !tbaa !24
  %t291 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e3
  br i1 %t291, label %bb57, label %bb58
bb57:
  %t293 = call ptr @__olang_region_make(ptr %v7)
  %t294 = ptrtoint ptr %t293 to i64
  store i64 %t294, ptr %l164, !tbaa !24
  br label %bb58
bb58:
  %t295 = load ptr, ptr %l2, !tbaa !29
  %t297 = getelementptr %"compiler/interp:Exec", ptr %t295, i32 0, i32 4
  %t298 = load %"compiler/eval:Ptr", ptr %l23
  %t299 = load i32, ptr %l24, !tbaa !23
  %t300 = load i64, ptr %l164
  %t301 = inttoptr i64 %t300 to ptr
  %t305 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v2, ptr %t301, ptr %t297, %"compiler/eval:Ptr" %t298, i32 %t299)
  store { i64, ptr } %t305, ptr %l170
  br label %bb59
bb59:
  %t306 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t307 = load ptr, ptr %l163, !tbaa !29
  %t308 = getelementptr %"compiler/prompt:Reply", ptr %t307, i32 0, i32 3
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  store { i64, ptr } %t309, ptr %l172, !tbaa !27
  %t311 = load ptr, ptr %l163, !tbaa !29
  %t312 = getelementptr %"compiler/prompt:Reply", ptr %t311, i32 0, i32 3
  store { i64, ptr } %t306, ptr %t312, !tbaa !27
  %t313 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e3
  br i1 %t313, label %bb60, label %bb61
bb60:
  %t315 = load { i64, ptr }, ptr %l172
  %t316 = extractvalue { i64, ptr } %t315, 1
  call void @__olang_region_release(ptr %t316)
  store { i64, ptr } zeroinitializer, ptr %l172
  br label %bb61
bb61:
  %t317 = load ptr, ptr %l7, !tbaa !29
  store ptr %t317, ptr %l174, !tbaa !29
  %t318 = call ptr @__olang_scope_hold(ptr %v7)
  %t319 = ptrtoint ptr %t318 to i64
  store i64 %t319, ptr %l175, !tbaa !24
  %t320 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e6
  br i1 %t320, label %bb62, label %bb63
bb62:
  %t322 = call ptr @__olang_region_make(ptr %v7)
  %t323 = ptrtoint ptr %t322 to i64
  store i64 %t323, ptr %l175, !tbaa !24
  br label %bb63
bb63:
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t326 = load i64, ptr %l175
  %t327 = inttoptr i64 %t326 to ptr
  %t330 = call { i64, ptr } @compiler_2fprompt_2eglobal(ptr %v2, ptr %v1, ptr %s12, ptr %t327, ptr %t324, ptr %t325, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store { i64, ptr } %t330, ptr %l179
  br label %bb64
bb64:
  %t331 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t332 = load i64, ptr %l175
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = extractvalue { i64, ptr } %t331, 0
  %t335 = extractvalue { i64, ptr } %t331, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_held_alloc(ptr %t333, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  %t340 = load ptr, ptr %l174, !tbaa !29
  %t341 = getelementptr %"compiler/prompt:Reply", ptr %t340, i32 0, i32 6
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  store { i64, ptr } %t342, ptr %l181, !tbaa !27
  %t344 = load ptr, ptr %l174, !tbaa !29
  %t345 = getelementptr %"compiler/prompt:Reply", ptr %t344, i32 0, i32 6
  store { i64, ptr } %t339, ptr %t345, !tbaa !27
  %t346 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e6
  br i1 %t346, label %bb65, label %bb66
bb65:
  %t348 = load { i64, ptr }, ptr %l181
  %t349 = extractvalue { i64, ptr } %t348, 1
  call void @__olang_region_release(ptr %t349)
  store { i64, ptr } zeroinitializer, ptr %l181
  br label %bb66
bb66:
  %t350 = load ptr, ptr %l7, !tbaa !29
  store ptr %t350, ptr %l183, !tbaa !29
  %t351 = load ptr, ptr %l7, !tbaa !29
  %t353 = getelementptr %"compiler/prompt:Reply", ptr %t351, i32 0, i32 6
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  %t356 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v7, ptr %s12, { i64, ptr } %t354, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t356, ptr %l186
  br label %bb67
bb67:
  %t357 = load i1, ptr %l186, !tbaa !21
  %t358 = xor i1 %t357, true
  br i1 %t358, label %bb68, label %bb69
bb68:
  %t360 = load ptr, ptr %l2, !tbaa !29
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t364 = call { i64, ptr } @compiler_2fprompt_2eglobal(ptr %v2, ptr %v1, ptr %s12, ptr %v7, ptr %t360, ptr %t361, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store { i64, ptr } %t364, ptr %l191
  br label %bb70
bb69:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l188, !tbaa !27
  br label %bb71
bb70:
  %t365 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t365, ptr %l188, !tbaa !27
  br label %bb71
bb71:
  %t367 = load ptr, ptr %l183, !tbaa !29
  %t368 = getelementptr %"compiler/prompt:Reply", ptr %t367, i32 0, i32 7
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  store { i64, ptr } %t369, ptr %l193, !tbaa !27
  %t370 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t371 = load ptr, ptr %l183, !tbaa !29
  %t372 = getelementptr %"compiler/prompt:Reply", ptr %t371, i32 0, i32 7
  store { i64, ptr } %t370, ptr %t372, !tbaa !27
  %t373 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e7
  br i1 %t373, label %bb72, label %bb73
bb72:
  %t375 = load { i64, ptr }, ptr %l193
  %t376 = extractvalue { i64, ptr } %t375, 1
  call void @__olang_region_release(ptr %t376)
  store { i64, ptr } zeroinitializer, ptr %l193
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb74
bb74:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/prompt:Session", ptr %t377, i32 0, i32 5
  call void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2eClear(ptr %v0, ptr %t379)
  br label %bb75
bb75:
  %t381 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t381, ptr %l197
  br label %bb76
bb76:
  %t382 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l197
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %l25
  store ptr %l13, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s15
  %t384 = load i64, ptr %l27, !tbaa !24
  store i64 %t384, ptr %l199, !tbaa !24
  %t385 = load ptr, ptr %l26, !tbaa !29
  %t387 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %s0, ptr %t385)
  store i64 %t387, ptr %l201
  br label %bb78
bb78:
  %t388 = load i64, ptr %l199, !tbaa !24
  %t389 = load i64, ptr %l201, !tbaa !24
  %t390 = icmp slt i64 %t388, %t389
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s15)
  br label %bb117
bb80:
  br label %bb81
bb81:
  %t394 = load ptr, ptr %l26, !tbaa !29
  %t395 = load i64, ptr %l27, !tbaa !24
  %t398 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %s0, ptr %s0, ptr %t394, i64 %t395)
  store %"compiler/prompt:Value" %t398, ptr %l206
  br label %bb82
bb82:
  %t399 = load %"compiler/prompt:Value", ptr %l206
  store %"compiler/prompt:Value" %t399, ptr %l28
  %t400 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 2
  %t401 = load i1, ptr %t400, !tbaa !21
  br i1 %t401, label %bb83, label %bb84
bb83:
  %t403 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 3
  %t404 = load i64, ptr %t403, !tbaa !24
  %t406 = icmp slt i64 %t404, 0
  store i1 %t406, ptr %l208, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb85
bb85:
  %t408 = load i1, ptr %l208, !tbaa !21
  br i1 %t408, label %bb86, label %bb87
bb86:
  %t409 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eKeepPrefix, !tbaa !27
  %t410 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 0
  %t411 = load { i64, ptr }, ptr %t410, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t409, 1
  %t414 = extractvalue { i64, ptr } %t409, 0
  %t416 = extractvalue { i64, ptr } %t411, 1
  %t417 = extractvalue { i64, ptr } %t411, 0
  %t418 = add i64 %t414, %t417
  %t419 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t418)
  call void @olang_textcopy(ptr %t419, ptr %t413, i64 %t414)
  %t420 = getelementptr i8, ptr %t419, i64 %t414
  call void @olang_textcopy(ptr %t420, ptr %t416, i64 %t417)
  %t421 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t419, 1
  store { i64, ptr } %t422, ptr %l211, !tbaa !27
  br label %bb88
bb87:
  %t424 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 1
  %t428 = extractvalue { i64, ptr } %t425, 0
  %t429 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t428)
  call void @olang_textcopy(ptr %t429, ptr %t427, i64 %t428)
  %t430 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t429, 1
  store { i64, ptr } %t431, ptr %l211, !tbaa !27
  br label %bb88
bb88:
  %t433 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t433, ptr %l29, !tbaa !27
  %t434 = load ptr, ptr %l2, !tbaa !29
  %t436 = getelementptr %"compiler/interp:Exec", ptr %t434, i32 0, i32 4
  store ptr %t436, ptr %l219, !tbaa !29
  %t437 = load i64, ptr %l10, !tbaa !24
  store i64 %t437, ptr %l220, !tbaa !24
  %t438 = load ptr, ptr %l11, !tbaa !29
  store ptr %t438, ptr %l221, !tbaa !29
  %t439 = call ptr @__olang_scope_hold(ptr %v1)
  %t440 = ptrtoint ptr %t439 to i64
  store i64 %t440, ptr %l222, !tbaa !24
  %t441 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t441, label %bb89, label %bb90
bb89:
  %t443 = load ptr, ptr %l221, !tbaa !29
  %t444 = call ptr @__olang_region_or(ptr %t443, ptr %v1)
  %t445 = call ptr @__olang_scope_hold(ptr %t444)
  %t446 = ptrtoint ptr %t445 to i64
  store i64 %t446, ptr %l222, !tbaa !24
  br label %bb90
bb90:
  %t447 = load ptr, ptr %l11, !tbaa !29
  %t448 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t449 = load i64, ptr %l222
  %t450 = inttoptr i64 %t449 to ptr
  %t453 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t450, ptr %s15, ptr %t447, { i64, ptr } %t448)
  store i32 %t453, ptr %l226
  br label %bb91
bb91:
  %t454 = load ptr, ptr %l219, !tbaa !29
  %t455 = load i64, ptr %l220, !tbaa !24
  %t456 = load i32, ptr %l226, !tbaa !23
  %t457 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v2, ptr %t454, i64 %t455, i32 %t456)
  %t458 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t457, 1
  %t459 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t457, 0
  store i32 %t459, ptr %l228
  %t460 = icmp ne i32 %t459, 0
  br i1 %t460, label %bb93, label %ok.461, !prof !99
ok.461:
  store { %"compiler/eval:Ptr", i32 } %t458, ptr %l227
  br label %bb92
bb92:
  %t462 = load { %"compiler/eval:Ptr", i32 }, ptr %l227
  store { %"compiler/eval:Ptr", i32 } %t462, ptr %l217
  br label %bb95
bb93:
  %t463 = load i32, ptr %l228, !tbaa !23
  %t464 = ashr i32 %t463, 16
  %t466 = icmp eq i32 %t464, 1
  store i1 %t466, ptr %l230, !tbaa !21
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb116
bb95:
  %t467 = load { %"compiler/eval:Ptr", i32 }, ptr %l217
  store { %"compiler/eval:Ptr", i32 } %t467, ptr %l30
  %t468 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l30, i32 0, i32 1
  %t469 = load i32, ptr %t468, !tbaa !23
  store i32 %t469, ptr %l31, !tbaa !23
  %t471 = load ptr, ptr %l2, !tbaa !29
  %t473 = getelementptr %"compiler/interp:Exec", ptr %t471, i32 0, i32 4
  store ptr %t473, ptr %l234, !tbaa !29
  %t474 = load i64, ptr %l10, !tbaa !24
  store i64 %t474, ptr %l235, !tbaa !24
  %t475 = load ptr, ptr %l11, !tbaa !29
  store ptr %t475, ptr %l236, !tbaa !29
  %t476 = call ptr @__olang_scope_hold(ptr %v1)
  %t477 = ptrtoint ptr %t476 to i64
  store i64 %t477, ptr %l237, !tbaa !24
  %t478 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t478, label %bb96, label %bb97
bb96:
  %t480 = load ptr, ptr %l236, !tbaa !29
  %t481 = call ptr @__olang_region_or(ptr %t480, ptr %v1)
  %t482 = call ptr @__olang_scope_hold(ptr %t481)
  %t483 = ptrtoint ptr %t482 to i64
  store i64 %t483, ptr %l237, !tbaa !24
  br label %bb97
bb97:
  %t484 = load ptr, ptr %l11, !tbaa !29
  %t485 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t486 = load i64, ptr %l237
  %t487 = inttoptr i64 %t486 to ptr
  %t490 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t487, ptr %s15, ptr %t484, { i64, ptr } %t485)
  store i32 %t490, ptr %l241
  br label %bb98
bb98:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/prompt:Session", ptr %t491, i32 0, i32 5
  %t494 = load ptr, ptr %l234, !tbaa !29
  %t495 = load i64, ptr %l235, !tbaa !24
  %t496 = load i32, ptr %l241, !tbaa !23
  %t498 = call { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eSave(ptr %v2, ptr %v0, ptr %t494, i64 %t495, i32 %t496, ptr %t493)
  %t499 = extractvalue { i32, i64 } %t498, 1
  %t500 = extractvalue { i32, i64 } %t498, 0
  store i32 %t500, ptr %l245
  %t501 = icmp ne i32 %t500, 0
  br i1 %t501, label %bb100, label %ok.502, !prof !99
ok.502:
  store i64 %t499, ptr %l244
  br label %bb99
bb99:
  %t503 = load i64, ptr %l244, !tbaa !24
  store i64 %t503, ptr %l232, !tbaa !24
  br label %bb104
bb100:
  %t504 = load i32, ptr %l245, !tbaa !23
  %t505 = ashr i32 %t504, 16
  %t507 = icmp eq i32 %t505, 1
  store i1 %t507, ptr %l247, !tbaa !21
  %t508 = load i32, ptr %l245, !tbaa !23
  %t509 = lshr i32 %t508, 16
  %t510 = and i32 %t508, 65535
  %t511 = icmp eq i32 %t509, 1
  %t512 = select i1 %t511, i32 1, i32 0
  %t513 = icmp eq i32 %t508, 0
  %t514 = shl i32 %t512, 16
  %t515 = or i32 %t514, %t510
  %t516 = select i1 %t513, i32 0, i32 %t515
  store i32 %t516, ptr %l32, !tbaa !23
  br label %bb101
bb101:
  store %olang.scope zeroinitializer, ptr %s19
  store ptr %l12, ptr %l248, !tbaa !29
  %t517 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 0
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l249, !tbaa !27
  %t519 = load i32, ptr %l32, !tbaa !23
  %t521 = call { i64, ptr } @compiler_2fprompt_2enotSaved(ptr %s19, i32 %t519)
  store { i64, ptr } %t521, ptr %l251
  br label %bb102
bb102:
  %t522 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 1
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t525 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t527 = add i64 %t524, %t526
  %t528 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 1
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = add i64 %t527, %t530
  %t532 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t533 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t534 = add i64 %t531, %t533
  %t535 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t534)
  call void @olang_textcopy(ptr %t535, ptr %t523, i64 %t524)
  %t536 = getelementptr i8, ptr %t535, i64 %t524
  call void @olang_textcopy(ptr %t536, ptr %t525, i64 %t526)
  %t537 = getelementptr i8, ptr %t536, i64 %t526
  call void @olang_textcopy(ptr %t537, ptr %t529, i64 %t530)
  %t538 = getelementptr i8, ptr %t537, i64 %t530
  call void @olang_textcopy(ptr %t538, ptr %t532, i64 %t533)
  %t539 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t535, 1
  %t542 = load ptr, ptr %l248, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t542, { i64, ptr } %t540)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s15)
  br label %bb116
bb104:
  %t544 = load i64, ptr %l232, !tbaa !24
  store i64 %t544, ptr %l33, !tbaa !24
  %t545 = call ptr @__olang_scope_hold(ptr %v0)
  %t546 = ptrtoint ptr %t545 to i64
  store i64 %t546, ptr %l254, !tbaa !24
  %t547 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e0
  br i1 %t547, label %bb105, label %bb106
bb105:
  %t549 = call ptr @__olang_region_make(ptr %v0)
  %t550 = ptrtoint ptr %t549 to i64
  store i64 %t550, ptr %l254, !tbaa !24
  br label %bb106
bb106:
  %t551 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 0
  %t552 = load { i64, ptr }, ptr %t551, !tbaa !27
  %t554 = extractvalue { i64, ptr } %t552, 1
  %t555 = extractvalue { i64, ptr } %t552, 0
  %t556 = load i64, ptr %l254
  %t557 = inttoptr i64 %t556 to ptr
  %t558 = call ptr @__olang_held_alloc(ptr %t557, i64 %t555)
  call void @olang_textcopy(ptr %t558, ptr %t554, i64 %t555)
  %t559 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  store { i64, ptr } %t560, ptr %l258, !tbaa !27
  %t562 = call ptr @__olang_scope_hold(ptr %v0)
  %t563 = ptrtoint ptr %t562 to i64
  store i64 %t563, ptr %l259, !tbaa !24
  %t564 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e1
  br i1 %t564, label %bb107, label %bb108
bb107:
  %t566 = call ptr @__olang_region_make(ptr %v0)
  %t567 = ptrtoint ptr %t566 to i64
  store i64 %t567, ptr %l259, !tbaa !24
  br label %bb108
bb108:
  %t568 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 1
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t569, 1
  %t572 = extractvalue { i64, ptr } %t569, 0
  %t573 = load i64, ptr %l259
  %t574 = inttoptr i64 %t573 to ptr
  %t575 = call ptr @__olang_held_alloc(ptr %t574, i64 %t572)
  call void @olang_textcopy(ptr %t575, ptr %t571, i64 %t572)
  %t576 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t575, 1
  %t579 = getelementptr %"compiler/prompt:Value", ptr %l28, i32 0, i32 2
  %t580 = load i1, ptr %t579, !tbaa !21
  %t581 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t584 = call %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t581, { i64, ptr } %t577, i1 %t580)
  store %"compiler/prompt:Value" %t584, ptr %l265
  br label %bb109
bb109:
  %t585 = load %"compiler/prompt:Value", ptr %l265
  store %"compiler/prompt:Value" %t585, ptr %l34
  %t586 = load i64, ptr %l33, !tbaa !24
  %t588 = getelementptr %"compiler/prompt:Value", ptr %l34, i32 0, i32 3
  store i64 %t586, ptr %t588, !tbaa !24
  %t589 = call ptr @__olang_scope_hold(ptr %v0)
  %t590 = ptrtoint ptr %t589 to i64
  store i64 %t590, ptr %l267, !tbaa !24
  %t591 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e4
  br i1 %t591, label %bb110, label %bb111
bb110:
  %t593 = call ptr @__olang_region_make(ptr %v0)
  %t594 = ptrtoint ptr %t593 to i64
  store i64 %t594, ptr %l267, !tbaa !24
  br label %bb111
bb111:
  %t595 = load ptr, ptr %l2, !tbaa !29
  %t597 = getelementptr %"compiler/interp:Exec", ptr %t595, i32 0, i32 4
  %t598 = load i32, ptr %l31, !tbaa !23
  %t599 = load i64, ptr %l267
  %t600 = inttoptr i64 %t599 to ptr
  %t603 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v2, ptr %t600, ptr %t597, i32 %t598)
  store { i64, ptr } %t603, ptr %l272
  br label %bb112
bb112:
  %t604 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t605 = getelementptr %"compiler/prompt:Value", ptr %l34, i32 0, i32 4
  %t606 = load { i64, ptr }, ptr %t605, !tbaa !27
  store { i64, ptr } %t606, ptr %l274, !tbaa !27
  %t608 = getelementptr %"compiler/prompt:Value", ptr %l34, i32 0, i32 4
  store { i64, ptr } %t604, ptr %t608, !tbaa !27
  %t609 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e4
  br i1 %t609, label %bb113, label %bb114
bb113:
  %t611 = load { i64, ptr }, ptr %l274
  %t612 = extractvalue { i64, ptr } %t611, 1
  call void @__olang_region_release(ptr %t612)
  store { i64, ptr } zeroinitializer, ptr %l274
  br label %bb114
bb114:
  %t613 = load %"compiler/prompt:Value", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v0, ptr %l25, %"compiler/prompt:Value" %t613)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s15)
  br label %bb116
bb116:
  %t616 = load i64, ptr %l27, !tbaa !24
  %t619 = add i64 %t616, 1
  store i64 %t619, ptr %l27, !tbaa !24
  br label %bb77
bb117:
  %t621 = load ptr, ptr %l4, !tbaa !29
  store ptr %t621, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb118
bb118:
  store %olang.scope zeroinitializer, ptr %s25
  %t623 = load i64, ptr %l36, !tbaa !24
  store i64 %t623, ptr %l282, !tbaa !24
  %t624 = load ptr, ptr %l35, !tbaa !29
  %t626 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v4, ptr %t624)
  store i64 %t626, ptr %l284
  br label %bb119
bb119:
  %t627 = load i64, ptr %l282, !tbaa !24
  %t628 = load i64, ptr %l284, !tbaa !24
  %t629 = icmp slt i64 %t627, %t628
  %t631 = xor i1 %t629, true
  br i1 %t631, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s25)
  br label %bb181
bb121:
  br label %bb122
bb122:
  %t633 = load ptr, ptr %l35, !tbaa !29
  %t634 = load i64, ptr %l36, !tbaa !24
  %t637 = call %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v4, ptr %v4, ptr %t633, i64 %t634)
  store %"compiler/prompt:Decl" %t637, ptr %l289
  br label %bb123
bb123:
  %t638 = load %"compiler/prompt:Decl", ptr %l289
  store %"compiler/prompt:Decl" %t638, ptr %l37
  %t639 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t640 = load { i64, ptr }, ptr %t639, !tbaa !27
  %t642 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s25, { i64, ptr } %t640, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t642, ptr %l291
  br label %bb124
bb124:
  %t643 = load i1, ptr %l291, !tbaa !21
  br i1 %t643, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb128
bb126:
  %t644 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t645 = load { i64, ptr }, ptr %t644, !tbaa !27
  %t647 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v4, ptr %s25, { i64, ptr } %t645, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t647, ptr %l294
  br label %bb127
bb127:
  %t648 = load i1, ptr %l294, !tbaa !21
  store i1 %t648, ptr %l292, !tbaa !21
  br label %bb128
bb128:
  %t649 = load i1, ptr %l292, !tbaa !21
  br i1 %t649, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb132
bb130:
  %t650 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t651 = load { i64, ptr }, ptr %t650, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l298, !tbaa !27
  %t654 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t655 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v4, ptr %s25, { i64, ptr } %t651, { i64, ptr } %t654)
  store i1 %t655, ptr %l299
  br label %bb131
bb131:
  %t656 = load i1, ptr %l299, !tbaa !21
  store i1 %t656, ptr %l295, !tbaa !21
  br label %bb132
bb132:
  %t657 = load i1, ptr %l295, !tbaa !21
  br i1 %t657, label %bb133, label %bb134
bb133:
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb134:
  br label %bb135
bb135:
  %t659 = call i1 @compiler_2fprompt_2eisGlobal(ptr %s25, ptr %l37)
  store i1 %t659, ptr %l301
  br label %bb136
bb136:
  %t660 = load i1, ptr %l301, !tbaa !21
  %t661 = xor i1 %t660, true
  br i1 %t661, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb138:
  br label %bb139
bb139:
  store i1 false, ptr %l38, !tbaa !21
  store ptr %l25, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb140
bb140:
  %t664 = load i64, ptr %l40, !tbaa !24
  store i64 %t664, ptr %l304, !tbaa !24
  %t665 = load ptr, ptr %l39, !tbaa !29
  %t667 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %t665)
  store i64 %t667, ptr %l306
  br label %bb141
bb141:
  %t668 = load i64, ptr %l304, !tbaa !24
  %t669 = load i64, ptr %l306, !tbaa !24
  %t670 = icmp slt i64 %t668, %t669
  %t672 = xor i1 %t670, true
  br i1 %t672, label %bb142, label %bb143
bb142:
  br label %bb151
bb143:
  br label %bb144
bb144:
  %t674 = load ptr, ptr %l39, !tbaa !29
  %t675 = load i64, ptr %l40, !tbaa !24
  %t678 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v0, ptr %t674, i64 %t675)
  store %"compiler/prompt:Value" %t678, ptr %l311
  br label %bb145
bb145:
  %t679 = load %"compiler/prompt:Value", ptr %l311
  store %"compiler/prompt:Value" %t679, ptr %l41
  %t680 = getelementptr %"compiler/prompt:Value", ptr %l41, i32 0, i32 0
  %t681 = load { i64, ptr }, ptr %t680, !tbaa !27
  %t682 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t683 = load { i64, ptr }, ptr %t682, !tbaa !27
  %t686 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v4, { i64, ptr } %t681, { i64, ptr } %t683)
  store i1 %t686, ptr %l314
  br label %bb146
bb146:
  %t687 = load i1, ptr %l314, !tbaa !21
  br i1 %t687, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb149
bb148:
  br label %bb149
bb149:
  br label %bb150
bb150:
  %t688 = load i64, ptr %l40, !tbaa !24
  %t691 = add i64 %t688, 1
  store i64 %t691, ptr %l40, !tbaa !24
  br label %bb140
bb151:
  %t693 = load i1, ptr %l38, !tbaa !21
  br i1 %t693, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb153:
  br label %bb154
bb154:
  %t695 = load ptr, ptr %l2, !tbaa !29
  %t697 = getelementptr %"compiler/interp:Exec", ptr %t695, i32 0, i32 4
  store ptr %t697, ptr %l321, !tbaa !29
  %t698 = load i64, ptr %l10, !tbaa !24
  store i64 %t698, ptr %l322, !tbaa !24
  %t699 = load ptr, ptr %l11, !tbaa !29
  store ptr %t699, ptr %l323, !tbaa !29
  %t700 = call ptr @__olang_scope_hold(ptr %v1)
  %t701 = ptrtoint ptr %t700 to i64
  store i64 %t701, ptr %l324, !tbaa !24
  %t702 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t702, label %bb155, label %bb156
bb155:
  %t704 = load ptr, ptr %l323, !tbaa !29
  %t705 = call ptr @__olang_region_or(ptr %t704, ptr %v1)
  %t706 = call ptr @__olang_scope_hold(ptr %t705)
  %t707 = ptrtoint ptr %t706 to i64
  store i64 %t707, ptr %l324, !tbaa !24
  br label %bb156
bb156:
  %t708 = load ptr, ptr %l11, !tbaa !29
  %t709 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t710 = load { i64, ptr }, ptr %t709, !tbaa !27
  %t711 = load i64, ptr %l324
  %t712 = inttoptr i64 %t711 to ptr
  %t715 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t712, ptr %v4, ptr %t708, { i64, ptr } %t710)
  store i32 %t715, ptr %l328
  br label %bb157
bb157:
  %t716 = load ptr, ptr %l321, !tbaa !29
  %t717 = load i64, ptr %l322, !tbaa !24
  %t718 = load i32, ptr %l328, !tbaa !23
  %t719 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v2, ptr %t716, i64 %t717, i32 %t718)
  %t720 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t719, 1
  %t721 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t719, 0
  store i32 %t721, ptr %l330
  %t722 = icmp ne i32 %t721, 0
  br i1 %t722, label %bb159, label %ok.723, !prof !99
ok.723:
  store { %"compiler/eval:Ptr", i32 } %t720, ptr %l329
  br label %bb158
bb158:
  %t724 = load { %"compiler/eval:Ptr", i32 }, ptr %l329
  store { %"compiler/eval:Ptr", i32 } %t724, ptr %l319
  br label %bb161
bb159:
  %t725 = load i32, ptr %l330, !tbaa !23
  %t726 = ashr i32 %t725, 16
  %t728 = icmp eq i32 %t726, 1
  store i1 %t728, ptr %l332, !tbaa !21
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb161:
  %t729 = load { %"compiler/eval:Ptr", i32 }, ptr %l319
  store { %"compiler/eval:Ptr", i32 } %t729, ptr %l42
  %t730 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l42, i32 0, i32 1
  %t731 = load i32, ptr %t730, !tbaa !23
  store i32 %t731, ptr %l43, !tbaa !23
  %t733 = load ptr, ptr %l2, !tbaa !29
  %t735 = getelementptr %"compiler/interp:Exec", ptr %t733, i32 0, i32 4
  store ptr %t735, ptr %l336, !tbaa !29
  %t736 = load i64, ptr %l10, !tbaa !24
  store i64 %t736, ptr %l337, !tbaa !24
  %t737 = load ptr, ptr %l11, !tbaa !29
  store ptr %t737, ptr %l338, !tbaa !29
  %t738 = call ptr @__olang_scope_hold(ptr %v1)
  %t739 = ptrtoint ptr %t738 to i64
  store i64 %t739, ptr %l339, !tbaa !24
  %t740 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t740, label %bb162, label %bb163
bb162:
  %t742 = load ptr, ptr %l338, !tbaa !29
  %t743 = call ptr @__olang_region_or(ptr %t742, ptr %v1)
  %t744 = call ptr @__olang_scope_hold(ptr %t743)
  %t745 = ptrtoint ptr %t744 to i64
  store i64 %t745, ptr %l339, !tbaa !24
  br label %bb163
bb163:
  %t746 = load ptr, ptr %l11, !tbaa !29
  %t747 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t748 = load { i64, ptr }, ptr %t747, !tbaa !27
  %t749 = load i64, ptr %l339
  %t750 = inttoptr i64 %t749 to ptr
  %t753 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t750, ptr %v4, ptr %t746, { i64, ptr } %t748)
  store i32 %t753, ptr %l343
  br label %bb164
bb164:
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t756 = getelementptr %"compiler/prompt:Session", ptr %t754, i32 0, i32 5
  %t757 = load ptr, ptr %l336, !tbaa !29
  %t758 = load i64, ptr %l337, !tbaa !24
  %t759 = load i32, ptr %l343, !tbaa !23
  %t761 = call { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eSave(ptr %v2, ptr %v0, ptr %t757, i64 %t758, i32 %t759, ptr %t756)
  %t762 = extractvalue { i32, i64 } %t761, 1
  %t763 = extractvalue { i32, i64 } %t761, 0
  store i32 %t763, ptr %l347
  %t764 = icmp ne i32 %t763, 0
  br i1 %t764, label %bb166, label %ok.765, !prof !99
ok.765:
  store i64 %t762, ptr %l346
  br label %bb165
bb165:
  %t766 = load i64, ptr %l346, !tbaa !24
  store i64 %t766, ptr %l334, !tbaa !24
  br label %bb170
bb166:
  %t767 = load i32, ptr %l347, !tbaa !23
  %t768 = ashr i32 %t767, 16
  %t770 = icmp eq i32 %t768, 1
  store i1 %t770, ptr %l349, !tbaa !21
  %t771 = load i32, ptr %l347, !tbaa !23
  %t772 = lshr i32 %t771, 16
  %t773 = and i32 %t771, 65535
  %t774 = icmp eq i32 %t772, 1
  %t775 = select i1 %t774, i32 1, i32 0
  %t776 = icmp eq i32 %t771, 0
  %t777 = shl i32 %t775, 16
  %t778 = or i32 %t777, %t773
  %t779 = select i1 %t776, i32 0, i32 %t778
  store i32 %t779, ptr %l44, !tbaa !23
  br label %bb167
bb167:
  store %olang.scope zeroinitializer, ptr %s34
  store ptr %l12, ptr %l350, !tbaa !29
  %t780 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t781 = load { i64, ptr }, ptr %t780, !tbaa !27
  store { i64, ptr } %t781, ptr %l351, !tbaa !27
  %t782 = load i32, ptr %l44, !tbaa !23
  %t784 = call { i64, ptr } @compiler_2fprompt_2enotSaved(ptr %s34, i32 %t782)
  store { i64, ptr } %t784, ptr %l353
  br label %bb168
bb168:
  %t785 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t785, 1
  %t787 = extractvalue { i64, ptr } %t785, 0
  %t788 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t790 = add i64 %t787, %t789
  %t791 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = add i64 %t790, %t793
  %t795 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t796 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t797 = add i64 %t794, %t796
  %t798 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t797)
  call void @olang_textcopy(ptr %t798, ptr %t786, i64 %t787)
  %t799 = getelementptr i8, ptr %t798, i64 %t787
  call void @olang_textcopy(ptr %t799, ptr %t788, i64 %t789)
  %t800 = getelementptr i8, ptr %t799, i64 %t789
  call void @olang_textcopy(ptr %t800, ptr %t792, i64 %t793)
  %t801 = getelementptr i8, ptr %t800, i64 %t793
  call void @olang_textcopy(ptr %t801, ptr %t795, i64 %t796)
  %t802 = insertvalue { i64, ptr } undef, i64 %t797, 0
  %t803 = insertvalue { i64, ptr } %t802, ptr %t798, 1
  %t805 = load ptr, ptr %l350, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s34, ptr %t805, { i64, ptr } %t803)
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb170:
  %t807 = load i64, ptr %l334, !tbaa !24
  store i64 %t807, ptr %l45, !tbaa !24
  %t808 = call ptr @__olang_scope_hold(ptr %v0)
  %t809 = ptrtoint ptr %t808 to i64
  store i64 %t809, ptr %l356, !tbaa !24
  %t810 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e0
  br i1 %t810, label %bb171, label %bb172
bb171:
  %t812 = call ptr @__olang_region_make(ptr %v0)
  %t813 = ptrtoint ptr %t812 to i64
  store i64 %t813, ptr %l356, !tbaa !24
  br label %bb172
bb172:
  %t814 = getelementptr %"compiler/prompt:Decl", ptr %l37, i32 0, i32 0
  %t815 = load { i64, ptr }, ptr %t814, !tbaa !27
  %t817 = extractvalue { i64, ptr } %t815, 1
  %t818 = extractvalue { i64, ptr } %t815, 0
  %t819 = load i64, ptr %l356
  %t820 = inttoptr i64 %t819 to ptr
  %t821 = call ptr @__olang_held_alloc(ptr %t820, i64 %t818)
  call void @olang_textcopy(ptr %t821, ptr %t817, i64 %t818)
  %t822 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  %t826 = call %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t823, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, i1 false)
  store %"compiler/prompt:Value" %t826, ptr %l361
  br label %bb173
bb173:
  %t827 = load %"compiler/prompt:Value", ptr %l361
  store %"compiler/prompt:Value" %t827, ptr %l46
  %t828 = load i64, ptr %l45, !tbaa !24
  %t830 = getelementptr %"compiler/prompt:Value", ptr %l46, i32 0, i32 3
  store i64 %t828, ptr %t830, !tbaa !24
  %t831 = call ptr @__olang_scope_hold(ptr %v0)
  %t832 = ptrtoint ptr %t831 to i64
  store i64 %t832, ptr %l363, !tbaa !24
  %t833 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e4
  br i1 %t833, label %bb174, label %bb175
bb174:
  %t835 = call ptr @__olang_region_make(ptr %v0)
  %t836 = ptrtoint ptr %t835 to i64
  store i64 %t836, ptr %l363, !tbaa !24
  br label %bb175
bb175:
  %t837 = load ptr, ptr %l2, !tbaa !29
  %t839 = getelementptr %"compiler/interp:Exec", ptr %t837, i32 0, i32 4
  %t840 = load i32, ptr %l43, !tbaa !23
  %t841 = load i64, ptr %l363
  %t842 = inttoptr i64 %t841 to ptr
  %t845 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v2, ptr %t842, ptr %t839, i32 %t840)
  store { i64, ptr } %t845, ptr %l368
  br label %bb176
bb176:
  %t846 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t847 = getelementptr %"compiler/prompt:Value", ptr %l46, i32 0, i32 4
  %t848 = load { i64, ptr }, ptr %t847, !tbaa !27
  store { i64, ptr } %t848, ptr %l370, !tbaa !27
  %t850 = getelementptr %"compiler/prompt:Value", ptr %l46, i32 0, i32 4
  store { i64, ptr } %t846, ptr %t850, !tbaa !27
  %t851 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aValue_2e4
  br i1 %t851, label %bb177, label %bb178
bb177:
  %t853 = load { i64, ptr }, ptr %l370
  %t854 = extractvalue { i64, ptr } %t853, 1
  call void @__olang_region_release(ptr %t854)
  store { i64, ptr } zeroinitializer, ptr %l370
  br label %bb178
bb178:
  %t855 = load %"compiler/prompt:Value", ptr %l46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v0, ptr %l25, %"compiler/prompt:Value" %t855)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s25)
  br label %bb180
bb180:
  %t858 = load i64, ptr %l36, !tbaa !24
  %t861 = add i64 %t858, 1
  store i64 %t861, ptr %l36, !tbaa !24
  br label %bb118
bb181:
  %t863 = load ptr, ptr %l2, !tbaa !29
  %t865 = getelementptr %"compiler/interp:Exec", ptr %t863, i32 0, i32 4
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t868 = getelementptr %"compiler/prompt:Session", ptr %t866, i32 0, i32 5
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eSaveRegs(ptr %v2, ptr %v0, ptr %t865, ptr %t868)
  br label %bb182
bb182:
  %t871 = load ptr, ptr %l2, !tbaa !29
  %t873 = getelementptr %"compiler/interp:Exec", ptr %t871, i32 0, i32 4
  %t874 = load { i64, [2 x i64] }, ptr %l9
  %t877 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEndProgram(ptr %v2, ptr %s0, ptr %t873, { i64, [2 x i64] } %t874)
  store { i64, [5 x i64] } %t877, ptr %l384
  br label %bb183
bb183:
  %t878 = load ptr, ptr %l0, !tbaa !29
  store ptr %t878, ptr %l385, !tbaa !29
  %t879 = call ptr @__olang_scope_hold(ptr %v0)
  %t880 = ptrtoint ptr %t879 to i64
  store i64 %t880, ptr %l386, !tbaa !24
  %t881 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t881, label %bb184, label %bb185
bb184:
  %t883 = call ptr @__olang_region_make(ptr %v0)
  %t884 = ptrtoint ptr %t883 to i64
  store i64 %t884, ptr %l386, !tbaa !24
  br label %bb185
bb185:
  %t885 = load ptr, ptr %l4, !tbaa !29
  %t887 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t885
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t887, ptr %l390
  %t889 = load i64, ptr %l386
  %t890 = inttoptr i64 %t889 to ptr
  %t891 = call ptr @__olang_scope_hold(ptr %t890)
  %t892 = ptrtoint ptr %t891 to i64
  store i64 %t892, ptr %l391, !tbaa !24
  %t893 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0
  br i1 %t893, label %bb186, label %bb187
bb186:
  %t895 = load i64, ptr %l386
  %t896 = inttoptr i64 %t895 to ptr
  %t897 = call ptr @__olang_region_make_part(ptr %t896)
  %t898 = ptrtoint ptr %t897 to i64
  store i64 %t898, ptr %l391, !tbaa !24
  br label %bb187
bb187:
  %t899 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390, i32 0, i32 0
  %t900 = load { i64, ptr }, ptr %t899, !tbaa !27
  store { i64, ptr } %t900, ptr %l393, !tbaa !27
  %t901 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t902 = extractvalue { i64, ptr } %t901, 0
  store i64 %t902, ptr %l394, !tbaa !24
  %t903 = load i64, ptr %l394, !tbaa !24
  %t904 = mul i64 %t903, 56
  %t905 = load i64, ptr %l391
  %t906 = inttoptr i64 %t905 to ptr
  %t907 = call ptr @__olang_held_alloc(ptr %t906, i64 %t904)
  %t908 = insertvalue { i64, ptr } undef, i64 %t903, 0
  %t909 = insertvalue { i64, ptr } %t908, ptr %t907, 1
  store { i64, ptr } %t909, ptr %l395, !tbaa !27
  %t910 = getelementptr { i64, ptr }, ptr %l395, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = getelementptr { i64, ptr }, ptr %l393, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = load i64, ptr %l394, !tbaa !24
  %t915 = mul i64 %t914, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t911, ptr %t913, i64 %t915, i1 false)
  %t916 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t917 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390, i32 0, i32 0
  store { i64, ptr } %t916, ptr %t917, !tbaa !27
  %t918 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0
  br i1 %t918, label %bb188, label %bb189
bb188:
  %t920 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390, i32 0, i32 0
  %t921 = load { i64, ptr }, ptr %t920, !tbaa !27
  %t922 = extractvalue { i64, ptr } %t921, 0
  %t924 = icmp eq i64 %t922, 0
  br i1 %t924, label %bb190, label %bb191
bb189:
  %t926 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t926, label %bb192, label %bb193
bb190:
  %t928 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t928, !tbaa !27
  br label %bb191
bb191:
  %t929 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390, i32 0, i32 0
  %t930 = load i64, ptr %l391
  %t931 = inttoptr i64 %t930 to ptr
  %t932 = load { i64, ptr }, ptr %t929
  %t933 = extractvalue { i64, ptr } %t932, 1
  %t934 = call ptr @__olang_region_or(ptr %t933, ptr null)
  %t935 = icmp ne ptr %t934, null
  %t936 = select i1 %t935, ptr %t934, ptr null
  call void @__olang_region_settle_in(ptr %t931, ptr %t936)
  br label %bb189
bb192:
  %t937 = load i64, ptr %l386
  %t938 = inttoptr i64 %t937 to ptr
  %t939 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390, i32 0, i32 0
  %t940 = load { i64, ptr }, ptr %t939
  %t941 = extractvalue { i64, ptr } %t940, 1
  %t942 = call ptr @__olang_region_or(ptr %t941, ptr null)
  %t943 = call ptr @__olang_region_home(ptr %t942)
  %t944 = icmp ne ptr %t943, null
  %t945 = select i1 %t944, ptr %t943, ptr null
  call void @__olang_region_settle_in(ptr %t938, ptr %t945)
  br label %bb193
bb193:
  %t946 = load ptr, ptr %l385, !tbaa !29
  %t947 = getelementptr %"compiler/prompt:Session", ptr %t946, i32 0, i32 3
  %t948 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t947
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t948, ptr %l400
  %t949 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l390
  %t950 = load ptr, ptr %l385, !tbaa !29
  %t951 = getelementptr %"compiler/prompt:Session", ptr %t950, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t949, ptr %t951
  %t952 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t952, label %bb194, label %bb195
bb194:
  %t954 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l400, i32 0, i32 0
  %t955 = load { i64, ptr }, ptr %t954
  %t956 = extractvalue { i64, ptr } %t955, 1
  %t957 = call ptr @__olang_region_or(ptr %t956, ptr null)
  %t958 = call ptr @__olang_region_home(ptr %t957)
  %t959 = icmp ne ptr %t958, null
  %t960 = select i1 %t959, ptr %t958, ptr null
  call void @__olang_region_drop(ptr %t960)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l400
  br label %bb195
bb195:
  %t961 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0
  br i1 %t961, label %bb196, label %bb197
bb196:
  %t963 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l400, i32 0, i32 0
  %t964 = load { i64, ptr }, ptr %t963
  %t965 = extractvalue { i64, ptr } %t964, 0
  %t966 = extractvalue { i64, ptr } %t964, 1
  call void @__olang_region_release_part(ptr %t966, i64 %t965)
  store { i64, ptr } zeroinitializer, ptr %t963
  br label %bb197
bb197:
  %t967 = load ptr, ptr %l0, !tbaa !29
  store ptr %t967, ptr %l403, !tbaa !29
  %t968 = call ptr @__olang_scope_hold(ptr %v0)
  %t969 = ptrtoint ptr %t968 to i64
  store i64 %t969, ptr %l404, !tbaa !24
  %t970 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t970, label %bb198, label %bb199
bb198:
  %t972 = call ptr @__olang_region_make(ptr %v0)
  %t973 = ptrtoint ptr %t972 to i64
  store i64 %t973, ptr %l404, !tbaa !24
  br label %bb199
bb199:
  %t974 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t974, ptr %l407
  %t976 = load i64, ptr %l404
  %t977 = inttoptr i64 %t976 to ptr
  %t978 = call ptr @__olang_scope_hold(ptr %t977)
  %t979 = ptrtoint ptr %t978 to i64
  store i64 %t979, ptr %l408, !tbaa !24
  %t980 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t980, label %bb200, label %bb201
bb200:
  %t982 = load i64, ptr %l404
  %t983 = inttoptr i64 %t982 to ptr
  %t984 = call ptr @__olang_region_make_part(ptr %t983)
  %t985 = ptrtoint ptr %t984 to i64
  store i64 %t985, ptr %l408, !tbaa !24
  br label %bb201
bb201:
  %t986 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407, i32 0, i32 0
  %t987 = load { i64, ptr }, ptr %t986, !tbaa !27
  store { i64, ptr } %t987, ptr %l410, !tbaa !27
  %t988 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t989 = extractvalue { i64, ptr } %t988, 0
  store i64 %t989, ptr %l411, !tbaa !24
  %t990 = load i64, ptr %l411, !tbaa !24
  %t991 = mul i64 %t990, 80
  %t992 = load i64, ptr %l408
  %t993 = inttoptr i64 %t992 to ptr
  %t994 = call ptr @__olang_held_alloc(ptr %t993, i64 %t991)
  %t995 = insertvalue { i64, ptr } undef, i64 %t990, 0
  %t996 = insertvalue { i64, ptr } %t995, ptr %t994, 1
  store { i64, ptr } %t996, ptr %l412, !tbaa !27
  %t997 = getelementptr { i64, ptr }, ptr %l412, i32 0, i32 1
  %t998 = load ptr, ptr %t997, !tbaa !27
  %t999 = getelementptr { i64, ptr }, ptr %l410, i32 0, i32 1
  %t1000 = load ptr, ptr %t999, !tbaa !27
  %t1001 = load i64, ptr %l411, !tbaa !24
  %t1002 = mul i64 %t1001, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t998, ptr %t1000, i64 %t1002, i1 false)
  %t1003 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t1004 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407, i32 0, i32 0
  store { i64, ptr } %t1003, ptr %t1004, !tbaa !27
  %t1005 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t1005, label %bb202, label %bb203
bb202:
  %t1007 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407, i32 0, i32 0
  %t1008 = load { i64, ptr }, ptr %t1007, !tbaa !27
  %t1009 = extractvalue { i64, ptr } %t1008, 0
  %t1011 = icmp eq i64 %t1009, 0
  br i1 %t1011, label %bb204, label %bb205
bb203:
  %t1013 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t1013, label %bb206, label %bb207
bb204:
  %t1015 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1015, !tbaa !27
  br label %bb205
bb205:
  %t1016 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407, i32 0, i32 0
  %t1017 = load i64, ptr %l408
  %t1018 = inttoptr i64 %t1017 to ptr
  %t1019 = load { i64, ptr }, ptr %t1016
  %t1020 = extractvalue { i64, ptr } %t1019, 1
  %t1021 = call ptr @__olang_region_or(ptr %t1020, ptr null)
  %t1022 = icmp ne ptr %t1021, null
  %t1023 = select i1 %t1022, ptr %t1021, ptr null
  call void @__olang_region_settle_in(ptr %t1018, ptr %t1023)
  br label %bb203
bb206:
  %t1024 = load i64, ptr %l404
  %t1025 = inttoptr i64 %t1024 to ptr
  %t1026 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407, i32 0, i32 0
  %t1027 = load { i64, ptr }, ptr %t1026
  %t1028 = extractvalue { i64, ptr } %t1027, 1
  %t1029 = call ptr @__olang_region_or(ptr %t1028, ptr null)
  %t1030 = call ptr @__olang_region_home(ptr %t1029)
  %t1031 = icmp ne ptr %t1030, null
  %t1032 = select i1 %t1031, ptr %t1030, ptr null
  call void @__olang_region_settle_in(ptr %t1025, ptr %t1032)
  br label %bb207
bb207:
  %t1033 = load ptr, ptr %l403, !tbaa !29
  %t1034 = getelementptr %"compiler/prompt:Session", ptr %t1033, i32 0, i32 4
  %t1035 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1034
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1035, ptr %l417
  %t1036 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l407
  %t1037 = load ptr, ptr %l403, !tbaa !29
  %t1038 = getelementptr %"compiler/prompt:Session", ptr %t1037, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1036, ptr %t1038
  %t1039 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t1039, label %bb208, label %bb209
bb208:
  %t1041 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l417, i32 0, i32 0
  %t1042 = load { i64, ptr }, ptr %t1041
  %t1043 = extractvalue { i64, ptr } %t1042, 1
  %t1044 = call ptr @__olang_region_or(ptr %t1043, ptr null)
  %t1045 = call ptr @__olang_region_home(ptr %t1044)
  %t1046 = icmp ne ptr %t1045, null
  %t1047 = select i1 %t1046, ptr %t1045, ptr null
  call void @__olang_region_drop(ptr %t1047)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l417
  br label %bb209
bb209:
  %t1048 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t1048, label %bb210, label %bb211
bb210:
  %t1050 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l417, i32 0, i32 0
  %t1051 = load { i64, ptr }, ptr %t1050
  %t1052 = extractvalue { i64, ptr } %t1051, 0
  %t1053 = extractvalue { i64, ptr } %t1051, 1
  call void @__olang_region_release_part(ptr %t1053, i64 %t1052)
  store { i64, ptr } zeroinitializer, ptr %t1050
  br label %bb211
bb211:
  %t1054 = load ptr, ptr %l7, !tbaa !29
  store ptr %t1054, ptr %l420, !tbaa !29
  %t1055 = call ptr @__olang_scope_hold(ptr %v7)
  %t1056 = ptrtoint ptr %t1055 to i64
  store i64 %t1056, ptr %l421, !tbaa !24
  %t1057 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e5
  br i1 %t1057, label %bb212, label %bb213
bb212:
  %t1059 = call ptr @__olang_region_make(ptr %v7)
  %t1060 = ptrtoint ptr %t1059 to i64
  store i64 %t1060, ptr %l421, !tbaa !24
  br label %bb213
bb213:
  %t1061 = load i64, ptr %l421
  %t1062 = inttoptr i64 %t1061 to ptr
  %t1064 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t1062, ptr %l12)
  store { i64, ptr } %t1064, ptr %l424
  br label %bb214
bb214:
  %t1065 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t1066 = load ptr, ptr %l420, !tbaa !29
  %t1067 = getelementptr %"compiler/prompt:Reply", ptr %t1066, i32 0, i32 5
  %t1068 = load { i64, ptr }, ptr %t1067, !tbaa !27
  store { i64, ptr } %t1068, ptr %l426, !tbaa !27
  %t1070 = load ptr, ptr %l420, !tbaa !29
  %t1071 = getelementptr %"compiler/prompt:Reply", ptr %t1070, i32 0, i32 5
  store { i64, ptr } %t1065, ptr %t1071, !tbaa !27
  %t1072 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e5
  br i1 %t1072, label %bb215, label %bb216
bb215:
  %t1074 = load { i64, ptr }, ptr %l426
  %t1075 = extractvalue { i64, ptr } %t1074, 1
  call void @__olang_region_release(ptr %t1075)
  store { i64, ptr } zeroinitializer, ptr %l426
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erunCompiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/cells:Plan"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/prompt:Value"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/prompt:Value"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %lp19 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/cells:Outcome"
  %lp24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca %"compiler/prompt:Value"
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca %"compiler/cells:Plan"
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca %"compiler/prompt:Value"
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i64
  %l68 = alloca { i64, ptr }
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca %"compiler/prompt:Value"
  %l86 = alloca ptr
  %l87 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l98 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca i64
  %l105 = alloca { i64, ptr }
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l134 = alloca { i64, ptr }
  %l143 = alloca %"compiler/prompt:program"
  %l144 = alloca %"compiler/diag:Diagnostics"
  %l146 = alloca { i64, ptr }
  %l148 = alloca i32
  %l150 = alloca i1
  %l157 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca i32
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i64
  %l178 = alloca i64
  %l181 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l191 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca i64
  %l199 = alloca i64
  %l202 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l215 = alloca %"compiler/cells:Outcome"
  %l216 = alloca ptr
  %l217 = alloca i64
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l222 = alloca i64
  %l224 = alloca { i64, ptr }
  %l225 = alloca i64
  %l226 = alloca { i64, ptr }
  %l231 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l234 = alloca i64
  %l236 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l238 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l242 = alloca i64
  %l245 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l246 = alloca i64
  %l248 = alloca { i64, ptr }
  %l249 = alloca i64
  %l250 = alloca { i64, ptr }
  %l255 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l259 = alloca i64
  %l261 = alloca i64
  %l266 = alloca %"compiler/prompt:Value"
  %l273 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i64
  %l279 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l284 = alloca i64
  %l287 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l288 = alloca i64
  %l290 = alloca { i64, ptr }
  %l291 = alloca i64
  %l292 = alloca { i64, ptr }
  %l297 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l300 = alloca ptr
  %l301 = alloca i64
  %l307 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l312 = alloca i1
  %l315 = alloca i64
  %l317 = alloca i64
  %l322 = alloca %"compiler/prompt:Value"
  %l323 = alloca ptr
  %l332 = alloca %"compiler/prompt:Value"
  %l337 = alloca i64
  %l339 = alloca i64
  %l344 = alloca { i64, ptr }
  %l345 = alloca ptr
  %l350 = alloca %"compiler/prompt:Value"
  %l356 = alloca ptr
  %l358 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l362 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l366 = alloca { i64, ptr }
  %l368 = alloca ptr
  %l370 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %t6 = alloca %"compiler/cells:Plan", align 8
  %t257 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  call void @compiler_2fcells_3aPlan_2ector(ptr %t6, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t6, i64 216, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l36, i64 216, i1 false)
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %l38, !tbaa !24
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t10)
  store i64 %t12, ptr %l40
  br label %bb3
bb3:
  %t13 = load i64, ptr %l38, !tbaa !24
  %t14 = load i64, ptr %l40, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load i64, ptr %l9, !tbaa !24
  %t23 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t19, i64 %t20)
  store %"compiler/prompt:Value" %t23, ptr %l45
  br label %bb7
bb7:
  %t24 = load %"compiler/prompt:Value", ptr %l45
  store %"compiler/prompt:Value" %t24, ptr %l10
  %t25 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 5
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t28, ptr %l47
  br label %bb8
bb8:
  %t29 = load i1, ptr %l47, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t30 = getelementptr %"compiler/cells:Plan", ptr %l7, i32 0, i32 0
  store ptr %t30, ptr %l48, !tbaa !29
  %t31 = call ptr @__olang_scope_hold(ptr %s0)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l49, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t35 = call ptr @__olang_region_make(ptr %s0)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l49, !tbaa !24
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l49
  %t41 = inttoptr i64 %t40 to ptr
  %t44 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %v2, ptr %t41, ptr %t37, { i64, ptr } %t39)
  store { i64, ptr } %t44, ptr %l53
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t46 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %v2, ptr %t48, { i64, ptr } %t45, { i64, ptr } %t47)
  br label %bb15
bb15:
  %t51 = getelementptr %"compiler/cells:Plan", ptr %l7, i32 0, i32 1
  store ptr %t51, ptr %l56, !tbaa !29
  %t52 = call ptr @__olang_scope_hold(ptr %s0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l57, !tbaa !24
  %t54 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = call ptr @__olang_region_make(ptr %s0)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l57, !tbaa !24
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l57
  %t62 = inttoptr i64 %t61 to ptr
  %t65 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %v2, ptr %t62, ptr %t58, { i64, ptr } %t60)
  store { i64, ptr } %t65, ptr %l61
  br label %bb18
bb18:
  %t66 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t67 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %t67, { i64, ptr } %t66, i1 true)
  br label %bb19
bb19:
  %t69 = getelementptr %"compiler/cells:Plan", ptr %l7, i32 0, i32 2
  store ptr %t69, ptr %l63, !tbaa !29
  %t70 = call ptr @__olang_scope_hold(ptr %s0)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l64, !tbaa !24
  %t72 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = call ptr @__olang_region_make(ptr %s0)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l64, !tbaa !24
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/prompt:Value", ptr %l10, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l64
  %t80 = inttoptr i64 %t79 to ptr
  %t83 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2einitSym(ptr %v0, ptr %v2, ptr %t80, ptr %t76, { i64, ptr } %t78)
  store { i64, ptr } %t83, ptr %l68
  br label %bb22
bb22:
  %t84 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t85 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %t85, { i64, ptr } %t84, i1 true)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = add i64 %t87, 1
  store i64 %t90, ptr %l9, !tbaa !24
  br label %bb2
bb25:
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t94 = getelementptr %"compiler/prompt:cell", ptr %t92, i32 0, i32 3
  store ptr %t94, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load i64, ptr %l12, !tbaa !24
  store i64 %t96, ptr %l75, !tbaa !24
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t97)
  store i64 %t99, ptr %l77
  br label %bb27
bb27:
  %t100 = load i64, ptr %l75, !tbaa !24
  %t101 = load i64, ptr %l77, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb29:
  br label %bb30
bb30:
  %t106 = load ptr, ptr %l11, !tbaa !29
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t106, i64 %t107)
  store %"compiler/prompt:Value" %t110, ptr %l82
  br label %bb31
bb31:
  %t111 = load %"compiler/prompt:Value", ptr %l82
  store %"compiler/prompt:Value" %t111, ptr %l13
  %t112 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eKeepPrefix, !tbaa !27
  %t113 = getelementptr %"compiler/prompt:Value", ptr %l13, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t112, 1
  %t117 = extractvalue { i64, ptr } %t112, 0
  %t119 = extractvalue { i64, ptr } %t114, 1
  %t120 = extractvalue { i64, ptr } %t114, 0
  %t121 = add i64 %t117, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t116, i64 %t117)
  %t123 = getelementptr i8, ptr %t122, i64 %t117
  call void @olang_textcopy(ptr %t123, ptr %t119, i64 %t120)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  store { i64, ptr } %t125, ptr %l14, !tbaa !27
  %t127 = getelementptr %"compiler/cells:Plan", ptr %l7, i32 0, i32 0
  store ptr %t127, ptr %l86, !tbaa !29
  %t128 = call ptr @__olang_scope_hold(ptr %s0)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l87, !tbaa !24
  %t130 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t132 = call ptr @__olang_region_make(ptr %s0)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l87, !tbaa !24
  br label %bb33
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t136 = load i64, ptr %l87
  %t137 = inttoptr i64 %t136 to ptr
  %t140 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %s6, ptr %t137, ptr %t134, { i64, ptr } %t135)
  store { i64, ptr } %t140, ptr %l91
  br label %bb34
bb34:
  %t141 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t141, ptr %l92, !tbaa !27
  %t142 = call ptr @__olang_scope_hold(ptr %s0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l93, !tbaa !24
  %t144 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t146 = call ptr @__olang_region_make(ptr %s0)
  %t147 = ptrtoint ptr %t146 to i64
  store i64 %t147, ptr %l93, !tbaa !24
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t150 = load i64, ptr %l6, !tbaa !24
  %t151 = load i64, ptr %l93
  %t152 = inttoptr i64 %t151 to ptr
  %t156 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estoreOf(ptr %v0, ptr %s6, ptr %t152, ptr %t148, { i64, ptr } %t149, i64 %t150)
  store { i64, ptr } %t156, ptr %l98
  br label %bb37
bb37:
  %t157 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t158 = load ptr, ptr %l86, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l92, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %s0, ptr %t158, { i64, ptr } %t159, { i64, ptr } %t157)
  br label %bb38
bb38:
  %t161 = getelementptr %"compiler/cells:Plan", ptr %l7, i32 0, i32 2
  store ptr %t161, ptr %l100, !tbaa !29
  %t162 = call ptr @__olang_scope_hold(ptr %s0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l101, !tbaa !24
  %t164 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t164, label %bb39, label %bb40
bb39:
  %t166 = call ptr @__olang_region_make(ptr %s0)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l101, !tbaa !24
  br label %bb40
bb40:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t170 = load i64, ptr %l101
  %t171 = inttoptr i64 %t170 to ptr
  %t174 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2einitSym(ptr %v0, ptr %s6, ptr %t171, ptr %t168, { i64, ptr } %t169)
  store { i64, ptr } %t174, ptr %l105
  br label %bb41
bb41:
  %t175 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t176 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %t176, { i64, ptr } %t175, i1 true)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  %t178 = load i64, ptr %l12, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l12, !tbaa !24
  br label %bb26
bb44:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t187 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2efreshGlobals(ptr %v1, ptr %v2, ptr %s0, ptr %t183, ptr %t184)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187, ptr %l112
  br label %bb45
bb45:
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb46
bb46:
  %t190 = load i64, ptr %l17, !tbaa !24
  store i64 %t190, ptr %l114, !tbaa !24
  %t191 = load ptr, ptr %l16, !tbaa !29
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t191)
  store i64 %t193, ptr %l116
  br label %bb47
bb47:
  %t194 = load i64, ptr %l114, !tbaa !24
  %t195 = load i64, ptr %l116, !tbaa !24
  %t196 = icmp slt i64 %t194, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb48, label %bb49
bb48:
  br label %bb60
bb49:
  br label %bb50
bb50:
  %t200 = load ptr, ptr %l16, !tbaa !29
  %t201 = load i64, ptr %l17, !tbaa !24
  %t204 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t200, i64 %t201)
  store { i64, ptr } %t204, ptr %l121
  br label %bb51
bb51:
  %t205 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t205, ptr %l18, !tbaa !27
  %t206 = getelementptr %"compiler/cells:Plan", ptr %l7, i32 0, i32 0
  store ptr %t206, ptr %l122, !tbaa !29
  %t207 = call ptr @__olang_scope_hold(ptr %s0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l123, !tbaa !24
  %t209 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t209, label %bb52, label %bb53
bb52:
  %t211 = call ptr @__olang_region_make(ptr %s0)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l123, !tbaa !24
  br label %bb53
bb53:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t215 = load i64, ptr %l123
  %t216 = inttoptr i64 %t215 to ptr
  %t219 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %s0, ptr %t216, ptr %t213, { i64, ptr } %t214)
  store { i64, ptr } %t219, ptr %l127
  br label %bb54
bb54:
  %t220 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t220, ptr %l128, !tbaa !27
  %t221 = call ptr @__olang_scope_hold(ptr %s0)
  %t222 = ptrtoint ptr %t221 to i64
  store i64 %t222, ptr %l129, !tbaa !24
  %t223 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t223, label %bb55, label %bb56
bb55:
  %t225 = call ptr @__olang_region_make(ptr %s0)
  %t226 = ptrtoint ptr %t225 to i64
  store i64 %t226, ptr %l129, !tbaa !24
  br label %bb56
bb56:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t229 = load i64, ptr %l6, !tbaa !24
  %t230 = load i64, ptr %l129
  %t231 = inttoptr i64 %t230 to ptr
  %t235 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estoreOf(ptr %v0, ptr %s0, ptr %t231, ptr %t227, { i64, ptr } %t228, i64 %t229)
  store { i64, ptr } %t235, ptr %l134
  br label %bb57
bb57:
  %t236 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t237 = load ptr, ptr %l122, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l128, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %s0, ptr %t237, { i64, ptr } %t238, { i64, ptr } %t236)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t240 = load i64, ptr %l17, !tbaa !24
  %t243 = add i64 %t240, 1
  store i64 %t243, ptr %l17, !tbaa !24
  br label %bb46
bb60:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t247 = load ptr, ptr %l2, !tbaa !29
  %t248 = load ptr, ptr %l3, !tbaa !29
  %t253 = call %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v0, ptr %t245, ptr %t246, ptr %t247, ptr %t248, i1 true)
  store %"compiler/prompt:program" %t253, ptr %l143
  br label %bb61
bb61:
  %t254 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 128, i64 8)
  store ptr %t254, ptr %lp19
  %t255 = load %"compiler/prompt:program", ptr %l143
  %t256 = load ptr, ptr %lp19
  store %"compiler/prompt:program" %t255, ptr %t256
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t257, ptr %v0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l144, ptr %t257, i64 704, i1 false)
  br label %bb62
bb62:
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 704, i64 8)
  store ptr %t258, ptr %lp20
  %t259 = load ptr, ptr %lp20
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %l144, i64 704, i1 false)
  %t260 = load ptr, ptr %lp20
  %t261 = getelementptr %"compiler/diag:Diagnostics", ptr %t260, i32 0, i32 25
  store i1 true, ptr %t261, !tbaa !21
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ecellDir(ptr %v0, ptr %s0, ptr %t262)
  store { i64, ptr } %t264, ptr %l146
  br label %bb63
bb63:
  %t265 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t265, ptr %l21, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t268 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t266)
  store i32 %t268, ptr %l148
  %t269 = icmp ne i32 %t268, 0
  br i1 %t269, label %bb65, label %ok.270, !prof !99
ok.270:
  br label %bb64
bb64:
  br label %bb69
bb65:
  %t271 = load i32, ptr %l148, !tbaa !23
  %t272 = ashr i32 %t271, 16
  %t274 = icmp eq i32 %t272, 1
  store i1 %t274, ptr %l150, !tbaa !21
  %t275 = load i32, ptr %l148, !tbaa !23
  %t276 = ashr i32 %t275, 16
  %t278 = icmp eq i32 %t276, 1
  br i1 %t278, label %bb66, label %bb67
bb66:
  call void @__olang_errpay_pop()
  br label %bb67
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t280 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t281 = load i64, ptr %l6, !tbaa !24
  %t283 = extractvalue { i64, ptr } %t280, 1
  %t284 = extractvalue { i64, ptr } %t280, 0
  %t285 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t287 = add i64 %t284, %t286
  %t289 = call i64 @__olang_fmt_i64(ptr null, i64 %t281)
  %t290 = add i64 %t287, %t289
  %t291 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t293)
  call void @olang_textcopy(ptr %t294, ptr %t283, i64 %t284)
  %t295 = getelementptr i8, ptr %t294, i64 %t284
  call void @olang_textcopy(ptr %t295, ptr %t285, i64 %t286)
  %t296 = getelementptr i8, ptr %t295, i64 %t286
  %t297 = call i64 @__olang_fmt_i64(ptr %t296, i64 %t281)
  %t298 = getelementptr i8, ptr %t296, i64 %t289
  call void @olang_textcopy(ptr %t298, ptr %t291, i64 %t292)
  %t299 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t294, 1
  store { i64, ptr } %t300, ptr %l22, !tbaa !27
  call void @compiler_2fspin_2eBegin(ptr %s0, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb70
bb70:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/prompt:Session", ptr %t302, i32 0, i32 10
  store ptr %t304, ptr %l157, !tbaa !29
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/prompt:Session", ptr %t305, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l159, !tbaa !27
  %t309 = load ptr, ptr %lp19
  %t310 = getelementptr %"compiler/prompt:program", ptr %t309, i32 0, i32 0
  %t312 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v0, ptr %t310)
  store { i64, ptr } %t312, ptr %l161
  br label %bb71
bb71:
  %t313 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t313, ptr %l162, !tbaa !27
  %t314 = load ptr, ptr %lp19
  %t315 = getelementptr %"compiler/prompt:program", ptr %t314, i32 0, i32 3
  %t317 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t315)
  store { i64, ptr } %t317, ptr %l164
  br label %bb72
bb72:
  %t318 = load ptr, ptr %lp19
  %t319 = getelementptr %"compiler/prompt:program", ptr %t318, i32 0, i32 1
  %t321 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t319)
  store { i64, ptr } %t321, ptr %l166
  br label %bb73
bb73:
  %t322 = load ptr, ptr %lp19
  %t323 = getelementptr %"compiler/prompt:program", ptr %t322, i32 0, i32 2
  %t325 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v0, ptr %t323)
  store { i64, ptr } %t325, ptr %l168
  br label %bb74
bb74:
  %t326 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t327 = load ptr, ptr %lp20
  %t328 = load ptr, ptr %l157, !tbaa !29
  %t329 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t332 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t337 = call i32 @compiler_2fcells_2eBuild(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %v0, ptr %t328, { i64, ptr } %t329, { i64, ptr } %t330, { i64, ptr } %t331, { i64, ptr } %t332, { i64, ptr } %t333, ptr %l7, { i64, ptr } %t326, ptr %t327)
  store i32 %t337, ptr %l172
  %t338 = icmp ne i32 %t337, 0
  br i1 %t338, label %bb76, label %ok.339, !prof !99
ok.339:
  br label %bb75
bb75:
  br label %bb93
bb76:
  %t340 = load i32, ptr %l172, !tbaa !23
  %t341 = ashr i32 %t340, 16
  %t343 = icmp eq i32 %t341, 1
  store i1 %t343, ptr %l174, !tbaa !21
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  call void @compiler_2fspin_2eEnd()
  br label %bb78
bb78:
  %t344 = load ptr, ptr %l5, !tbaa !29
  store ptr %t344, ptr %l175, !tbaa !29
  %t345 = call ptr @__olang_scope_hold(ptr %v5)
  %t346 = ptrtoint ptr %t345 to i64
  store i64 %t346, ptr %l176, !tbaa !24
  %t347 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t347, label %bb79, label %bb80
bb79:
  %t349 = call ptr @__olang_region_make(ptr %v5)
  %t350 = ptrtoint ptr %t349 to i64
  store i64 %t350, ptr %l176, !tbaa !24
  br label %bb80
bb80:
  %t351 = call ptr @__olang_scope_hold(ptr %s14)
  %t352 = ptrtoint ptr %t351 to i64
  store i64 %t352, ptr %l178, !tbaa !24
  %t353 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t353, label %bb81, label %bb82
bb81:
  %t355 = call ptr @__olang_region_make(ptr %s14)
  %t356 = ptrtoint ptr %t355 to i64
  store i64 %t356, ptr %l178, !tbaa !24
  br label %bb82
bb82:
  %t357 = load ptr, ptr %lp20
  %t358 = load i64, ptr %l178
  %t359 = inttoptr i64 %t358 to ptr
  %t361 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %t359, ptr %t357)
  store { i64, ptr } %t361, ptr %l181
  br label %bb83
bb83:
  %t362 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t363 = load ptr, ptr %l3, !tbaa !29
  %t365 = getelementptr %"compiler/prompt:cell", ptr %t363, i32 0, i32 0
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  %t367 = load i64, ptr %l176
  %t368 = inttoptr i64 %t367 to ptr
  %t371 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s14, ptr %v3, ptr %t368, { i64, ptr } %t362, { i64, ptr } %t366)
  store { i64, ptr } %t371, ptr %l185
  br label %bb84
bb84:
  %t372 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t373 = load ptr, ptr %l175, !tbaa !29
  %t374 = getelementptr %"compiler/prompt:Reply", ptr %t373, i32 0, i32 1
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  store { i64, ptr } %t375, ptr %l187, !tbaa !27
  %t377 = load ptr, ptr %l175, !tbaa !29
  %t378 = getelementptr %"compiler/prompt:Reply", ptr %t377, i32 0, i32 1
  store { i64, ptr } %t372, ptr %t378, !tbaa !27
  %t379 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t379, label %bb85, label %bb86
bb85:
  %t381 = load { i64, ptr }, ptr %l187
  %t382 = extractvalue { i64, ptr } %t381, 1
  call void @__olang_region_release(ptr %t382)
  store { i64, ptr } zeroinitializer, ptr %l187
  br label %bb86
bb86:
  %t383 = load ptr, ptr %l5, !tbaa !29
  %t385 = getelementptr %"compiler/prompt:Reply", ptr %t383, i32 0, i32 1
  %t386 = load { i64, ptr }, ptr %t385, !tbaa !27
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s14, { i64, ptr } %t386, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t388, ptr %l191
  br label %bb87
bb87:
  %t389 = load i1, ptr %l191, !tbaa !21
  br i1 %t389, label %bb88, label %bb89
bb88:
  %t390 = load ptr, ptr %l5, !tbaa !29
  store ptr %t390, ptr %l192, !tbaa !29
  %t391 = load ptr, ptr %l192, !tbaa !29
  %t392 = getelementptr %"compiler/prompt:Reply", ptr %t391, i32 0, i32 1
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  store { i64, ptr } %t393, ptr %l193, !tbaa !27
  %t394 = load ptr, ptr %l192, !tbaa !29
  %t395 = getelementptr %"compiler/prompt:Reply", ptr %t394, i32 0, i32 1
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %t395, !tbaa !27
  %t396 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t396, label %bb90, label %bb91
bb89:
  br label %bb92
bb90:
  %t398 = load { i64, ptr }, ptr %l193
  %t399 = extractvalue { i64, ptr } %t398, 1
  call void @__olang_region_release(ptr %t399)
  store { i64, ptr } zeroinitializer, ptr %l193
  br label %bb91
bb91:
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb93:
  %t400 = load ptr, ptr %l5, !tbaa !29
  %t402 = getelementptr %"compiler/prompt:Reply", ptr %t400, i32 0, i32 0
  store i1 true, ptr %t402, !tbaa !21
  %t403 = load ptr, ptr %l5, !tbaa !29
  store ptr %t403, ptr %l196, !tbaa !29
  %t404 = call ptr @__olang_scope_hold(ptr %v5)
  %t405 = ptrtoint ptr %t404 to i64
  store i64 %t405, ptr %l197, !tbaa !24
  %t406 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t406, label %bb94, label %bb95
bb94:
  %t408 = call ptr @__olang_region_make(ptr %v5)
  %t409 = ptrtoint ptr %t408 to i64
  store i64 %t409, ptr %l197, !tbaa !24
  br label %bb95
bb95:
  %t410 = call ptr @__olang_scope_hold(ptr %s0)
  %t411 = ptrtoint ptr %t410 to i64
  store i64 %t411, ptr %l199, !tbaa !24
  %t412 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t412, label %bb96, label %bb97
bb96:
  %t414 = call ptr @__olang_region_make(ptr %s0)
  %t415 = ptrtoint ptr %t414 to i64
  store i64 %t415, ptr %l199, !tbaa !24
  br label %bb97
bb97:
  %t416 = load ptr, ptr %lp20
  %t417 = load i64, ptr %l199
  %t418 = inttoptr i64 %t417 to ptr
  %t420 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v0, ptr %t418, ptr %t416)
  store { i64, ptr } %t420, ptr %l202
  br label %bb98
bb98:
  %t421 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t422 = load ptr, ptr %l3, !tbaa !29
  %t424 = getelementptr %"compiler/prompt:cell", ptr %t422, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  %t426 = load i64, ptr %l197
  %t427 = inttoptr i64 %t426 to ptr
  %t430 = call { i64, ptr } @compiler_2fprompt_2ecellRows(ptr %s0, ptr %v3, ptr %t427, { i64, ptr } %t421, { i64, ptr } %t425)
  store { i64, ptr } %t430, ptr %l206
  br label %bb99
bb99:
  %t431 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t432 = load ptr, ptr %l196, !tbaa !29
  %t433 = getelementptr %"compiler/prompt:Reply", ptr %t432, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l208, !tbaa !27
  %t436 = load ptr, ptr %l196, !tbaa !29
  %t437 = getelementptr %"compiler/prompt:Reply", ptr %t436, i32 0, i32 1
  store { i64, ptr } %t431, ptr %t437, !tbaa !27
  %t438 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e1
  br i1 %t438, label %bb100, label %bb101
bb100:
  %t440 = load { i64, ptr }, ptr %l208
  %t441 = extractvalue { i64, ptr } %t440, 1
  call void @__olang_region_release(ptr %t441)
  store { i64, ptr } zeroinitializer, ptr %l208
  br label %bb101
bb101:
  call void @compiler_2fspin_2eRetitle(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb102
bb102:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/prompt:Session", ptr %t442, i32 0, i32 9
  %t445 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/prompt:Session", ptr %t446, i32 0, i32 6
  %t449 = load { ptr, ptr }, ptr %t448
  %t453 = extractvalue { ptr, ptr } %t449, 0
  %t454 = extractvalue { ptr, ptr } %t449, 1
  %t455 = call %"compiler/cells:Outcome" @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRun(ptr %v0, ptr %s0, ptr %v0, ptr %v5, ptr %t444, { i64, ptr } %t445, ptr %t453, ptr %t454)
  store %"compiler/cells:Outcome" %t455, ptr %l215
  br label %bb103
bb103:
  %t456 = load %"compiler/cells:Outcome", ptr %l215
  store %"compiler/cells:Outcome" %t456, ptr %l23
  call void @compiler_2fspin_2eEnd()
  br label %bb104
bb104:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb105
bb105:
  %t457 = load ptr, ptr %l0, !tbaa !29
  store ptr %t457, ptr %l216, !tbaa !29
  %t458 = call ptr @__olang_scope_hold(ptr %v0)
  %t459 = ptrtoint ptr %t458 to i64
  store i64 %t459, ptr %l217, !tbaa !24
  %t460 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t460, label %bb106, label %bb107
bb106:
  %t462 = call ptr @__olang_region_make(ptr %v0)
  %t463 = ptrtoint ptr %t462 to i64
  store i64 %t463, ptr %l217, !tbaa !24
  br label %bb107
bb107:
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t466 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t464
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t466, ptr %l221
  %t468 = load i64, ptr %l217
  %t469 = inttoptr i64 %t468 to ptr
  %t470 = call ptr @__olang_scope_hold(ptr %t469)
  %t471 = ptrtoint ptr %t470 to i64
  store i64 %t471, ptr %l222, !tbaa !24
  %t472 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0
  br i1 %t472, label %bb108, label %bb109
bb108:
  %t474 = load i64, ptr %l217
  %t475 = inttoptr i64 %t474 to ptr
  %t476 = call ptr @__olang_region_make_part(ptr %t475)
  %t477 = ptrtoint ptr %t476 to i64
  store i64 %t477, ptr %l222, !tbaa !24
  br label %bb109
bb109:
  %t478 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221, i32 0, i32 0
  %t479 = load { i64, ptr }, ptr %t478, !tbaa !27
  store { i64, ptr } %t479, ptr %l224, !tbaa !27
  %t480 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 0
  store i64 %t481, ptr %l225, !tbaa !24
  %t482 = load i64, ptr %l225, !tbaa !24
  %t483 = mul i64 %t482, 56
  %t484 = load i64, ptr %l222
  %t485 = inttoptr i64 %t484 to ptr
  %t486 = call ptr @__olang_held_alloc(ptr %t485, i64 %t483)
  %t487 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  store { i64, ptr } %t488, ptr %l226, !tbaa !27
  %t489 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = load i64, ptr %l225, !tbaa !24
  %t494 = mul i64 %t493, 56
  call void @llvm.memmove.p0.p0.i64(ptr %t490, ptr %t492, i64 %t494, i1 false)
  %t495 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t496 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221, i32 0, i32 0
  store { i64, ptr } %t495, ptr %t496, !tbaa !27
  %t497 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0
  br i1 %t497, label %bb110, label %bb111
bb110:
  %t499 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221, i32 0, i32 0
  %t500 = load { i64, ptr }, ptr %t499, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t500, 0
  %t503 = icmp eq i64 %t501, 0
  br i1 %t503, label %bb112, label %bb113
bb111:
  %t505 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t505, label %bb114, label %bb115
bb112:
  %t507 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t507, !tbaa !27
  br label %bb113
bb113:
  %t508 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221, i32 0, i32 0
  %t509 = load i64, ptr %l222
  %t510 = inttoptr i64 %t509 to ptr
  %t511 = load { i64, ptr }, ptr %t508
  %t512 = extractvalue { i64, ptr } %t511, 1
  %t513 = call ptr @__olang_region_or(ptr %t512, ptr null)
  %t514 = icmp ne ptr %t513, null
  %t515 = select i1 %t514, ptr %t513, ptr null
  call void @__olang_region_settle_in(ptr %t510, ptr %t515)
  br label %bb111
bb114:
  %t516 = load i64, ptr %l217
  %t517 = inttoptr i64 %t516 to ptr
  %t518 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221, i32 0, i32 0
  %t519 = load { i64, ptr }, ptr %t518
  %t520 = extractvalue { i64, ptr } %t519, 1
  %t521 = call ptr @__olang_region_or(ptr %t520, ptr null)
  %t522 = call ptr @__olang_region_home(ptr %t521)
  %t523 = icmp ne ptr %t522, null
  %t524 = select i1 %t523, ptr %t522, ptr null
  call void @__olang_region_settle_in(ptr %t517, ptr %t524)
  br label %bb115
bb115:
  %t525 = load ptr, ptr %l216, !tbaa !29
  %t526 = getelementptr %"compiler/prompt:Session", ptr %t525, i32 0, i32 3
  %t527 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t526
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t527, ptr %l231
  %t528 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221
  %t529 = load ptr, ptr %l216, !tbaa !29
  %t530 = getelementptr %"compiler/prompt:Session", ptr %t529, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t528, ptr %t530
  %t531 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t531, label %bb116, label %bb117
bb116:
  %t533 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l231, i32 0, i32 0
  %t534 = load { i64, ptr }, ptr %t533
  %t535 = extractvalue { i64, ptr } %t534, 1
  %t536 = call ptr @__olang_region_or(ptr %t535, ptr null)
  %t537 = call ptr @__olang_region_home(ptr %t536)
  %t538 = icmp ne ptr %t537, null
  %t539 = select i1 %t538, ptr %t537, ptr null
  call void @__olang_region_drop(ptr %t539)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l231
  br label %bb117
bb117:
  %t540 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0
  br i1 %t540, label %bb118, label %bb119
bb118:
  %t542 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l231, i32 0, i32 0
  %t543 = load { i64, ptr }, ptr %t542
  %t544 = extractvalue { i64, ptr } %t543, 0
  %t545 = extractvalue { i64, ptr } %t543, 1
  call void @__olang_region_release_part(ptr %t545, i64 %t544)
  store { i64, ptr } zeroinitializer, ptr %t542
  br label %bb119
bb119:
  %t546 = call ptr @__olang_scope_hold(ptr %v0)
  %t547 = ptrtoint ptr %t546 to i64
  store i64 %t547, ptr %l234, !tbaa !24
  %t548 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t548, label %bb120, label %bb121
bb120:
  %t550 = call ptr @__olang_region_make(ptr %v0)
  %t551 = ptrtoint ptr %t550 to i64
  store i64 %t551, ptr %l234, !tbaa !24
  br label %bb121
bb121:
  %t552 = load i64, ptr %l234
  %t553 = inttoptr i64 %t552 to ptr
  %t554 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %t553, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t554, ptr %l236
  br label %bb122
bb122:
  %t555 = load i64, ptr %l234
  %t556 = inttoptr i64 %t555 to ptr
  %t557 = call ptr @__olang_scope_alloc_a(ptr %t556, i64 32, i64 8)
  store ptr %t557, ptr %lp24
  %t558 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l236
  %t559 = load ptr, ptr %lp24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t558, ptr %t559
  %t560 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 6
  %t561 = load i1, ptr %t560, !tbaa !21
  br i1 %t561, label %bb123, label %bb124
bb123:
  %t563 = load ptr, ptr %l5, !tbaa !29
  store ptr %t563, ptr %l238, !tbaa !29
  %t564 = load ptr, ptr %l238, !tbaa !29
  %t565 = getelementptr %"compiler/prompt:Reply", ptr %t564, i32 0, i32 4
  %t566 = load { i64, ptr }, ptr %t565, !tbaa !27
  store { i64, ptr } %t566, ptr %l239, !tbaa !27
  %t567 = load ptr, ptr %l238, !tbaa !29
  %t568 = getelementptr %"compiler/prompt:Reply", ptr %t567, i32 0, i32 4
  store { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %t568, !tbaa !27
  %t569 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t569, label %bb125, label %bb126
bb124:
  br label %bb141
bb125:
  %t571 = load { i64, ptr }, ptr %l239
  %t572 = extractvalue { i64, ptr } %t571, 1
  call void @__olang_region_release(ptr %t572)
  store { i64, ptr } zeroinitializer, ptr %l239
  br label %bb126
bb126:
  %t573 = load ptr, ptr %l0, !tbaa !29
  store ptr %t573, ptr %l241, !tbaa !29
  %t574 = call ptr @__olang_scope_hold(ptr %v0)
  %t575 = ptrtoint ptr %t574 to i64
  store i64 %t575, ptr %l242, !tbaa !24
  %t576 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t576, label %bb127, label %bb128
bb127:
  %t578 = call ptr @__olang_region_make(ptr %v0)
  %t579 = ptrtoint ptr %t578 to i64
  store i64 %t579, ptr %l242, !tbaa !24
  br label %bb128
bb128:
  %t580 = load ptr, ptr %lp24
  %t581 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t580
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t581, ptr %l245
  %t583 = load i64, ptr %l242
  %t584 = inttoptr i64 %t583 to ptr
  %t585 = call ptr @__olang_scope_hold(ptr %t584)
  %t586 = ptrtoint ptr %t585 to i64
  store i64 %t586, ptr %l246, !tbaa !24
  %t587 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t587, label %bb129, label %bb130
bb129:
  %t589 = load i64, ptr %l242
  %t590 = inttoptr i64 %t589 to ptr
  %t591 = call ptr @__olang_region_make_part(ptr %t590)
  %t592 = ptrtoint ptr %t591 to i64
  store i64 %t592, ptr %l246, !tbaa !24
  br label %bb130
bb130:
  %t593 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245, i32 0, i32 0
  %t594 = load { i64, ptr }, ptr %t593, !tbaa !27
  store { i64, ptr } %t594, ptr %l248, !tbaa !27
  %t595 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t596 = extractvalue { i64, ptr } %t595, 0
  store i64 %t596, ptr %l249, !tbaa !24
  %t597 = load i64, ptr %l249, !tbaa !24
  %t598 = mul i64 %t597, 80
  %t599 = load i64, ptr %l246
  %t600 = inttoptr i64 %t599 to ptr
  %t601 = call ptr @__olang_held_alloc(ptr %t600, i64 %t598)
  %t602 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t603 = insertvalue { i64, ptr } %t602, ptr %t601, 1
  store { i64, ptr } %t603, ptr %l250, !tbaa !27
  %t604 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !27
  %t606 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !27
  %t608 = load i64, ptr %l249, !tbaa !24
  %t609 = mul i64 %t608, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t605, ptr %t607, i64 %t609, i1 false)
  %t610 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t611 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245, i32 0, i32 0
  store { i64, ptr } %t610, ptr %t611, !tbaa !27
  %t612 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t612, label %bb131, label %bb132
bb131:
  %t614 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245, i32 0, i32 0
  %t615 = load { i64, ptr }, ptr %t614, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 0
  %t618 = icmp eq i64 %t616, 0
  br i1 %t618, label %bb133, label %bb134
bb132:
  %t620 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t620, label %bb135, label %bb136
bb133:
  %t622 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t622, !tbaa !27
  br label %bb134
bb134:
  %t623 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245, i32 0, i32 0
  %t624 = load i64, ptr %l246
  %t625 = inttoptr i64 %t624 to ptr
  %t626 = load { i64, ptr }, ptr %t623
  %t627 = extractvalue { i64, ptr } %t626, 1
  %t628 = call ptr @__olang_region_or(ptr %t627, ptr null)
  %t629 = icmp ne ptr %t628, null
  %t630 = select i1 %t629, ptr %t628, ptr null
  call void @__olang_region_settle_in(ptr %t625, ptr %t630)
  br label %bb132
bb135:
  %t631 = load i64, ptr %l242
  %t632 = inttoptr i64 %t631 to ptr
  %t633 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245, i32 0, i32 0
  %t634 = load { i64, ptr }, ptr %t633
  %t635 = extractvalue { i64, ptr } %t634, 1
  %t636 = call ptr @__olang_region_or(ptr %t635, ptr null)
  %t637 = call ptr @__olang_region_home(ptr %t636)
  %t638 = icmp ne ptr %t637, null
  %t639 = select i1 %t638, ptr %t637, ptr null
  call void @__olang_region_settle_in(ptr %t632, ptr %t639)
  br label %bb136
bb136:
  %t640 = load ptr, ptr %l241, !tbaa !29
  %t641 = getelementptr %"compiler/prompt:Session", ptr %t640, i32 0, i32 4
  %t642 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t641
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t642, ptr %l255
  %t643 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245
  %t644 = load ptr, ptr %l241, !tbaa !29
  %t645 = getelementptr %"compiler/prompt:Session", ptr %t644, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t643, ptr %t645
  %t646 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t646, label %bb137, label %bb138
bb137:
  %t648 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l255, i32 0, i32 0
  %t649 = load { i64, ptr }, ptr %t648
  %t650 = extractvalue { i64, ptr } %t649, 1
  %t651 = call ptr @__olang_region_or(ptr %t650, ptr null)
  %t652 = call ptr @__olang_region_home(ptr %t651)
  %t653 = icmp ne ptr %t652, null
  %t654 = select i1 %t653, ptr %t652, ptr null
  call void @__olang_region_drop(ptr %t654)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l255
  br label %bb138
bb138:
  %t655 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t655, label %bb139, label %bb140
bb139:
  %t657 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l255, i32 0, i32 0
  %t658 = load { i64, ptr }, ptr %t657
  %t659 = extractvalue { i64, ptr } %t658, 0
  %t660 = extractvalue { i64, ptr } %t658, 1
  call void @__olang_region_release_part(ptr %t660, i64 %t659)
  store { i64, ptr } zeroinitializer, ptr %t657
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb141:
  %t661 = load ptr, ptr %l2, !tbaa !29
  store ptr %t661, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  br label %bb142
bb142:
  %t663 = load i64, ptr %l26, !tbaa !24
  store i64 %t663, ptr %l259, !tbaa !24
  %t664 = load ptr, ptr %l25, !tbaa !29
  %t666 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t664)
  store i64 %t666, ptr %l261
  br label %bb143
bb143:
  %t667 = load i64, ptr %l259, !tbaa !24
  %t668 = load i64, ptr %l261, !tbaa !24
  %t669 = icmp slt i64 %t667, %t668
  %t671 = xor i1 %t669, true
  br i1 %t671, label %bb144, label %bb145
bb144:
  br label %bb150
bb145:
  br label %bb146
bb146:
  %t673 = load ptr, ptr %l25, !tbaa !29
  %t674 = load i64, ptr %l26, !tbaa !24
  %t677 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t673, i64 %t674)
  store %"compiler/prompt:Value" %t677, ptr %l266
  br label %bb147
bb147:
  %t678 = load %"compiler/prompt:Value", ptr %l266
  %t679 = load ptr, ptr %lp24
  %t681 = load i64, ptr %l234
  %t682 = inttoptr i64 %t681 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %t682, ptr %v2, ptr %t679, %"compiler/prompt:Value" %t678)
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t685 = load i64, ptr %l26, !tbaa !24
  %t688 = add i64 %t685, 1
  store i64 %t688, ptr %l26, !tbaa !24
  br label %bb142
bb150:
  %t690 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 5
  %t691 = load { i64, ptr }, ptr %t690, !tbaa !27
  %t693 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t691, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t693, ptr %l273
  br label %bb151
bb151:
  %t694 = load i1, ptr %l273, !tbaa !21
  %t695 = xor i1 %t694, true
  br i1 %t695, label %bb152, label %bb153
bb152:
  %t697 = load ptr, ptr %l5, !tbaa !29
  store ptr %t697, ptr %l275, !tbaa !29
  %t698 = call ptr @__olang_scope_hold(ptr %v5)
  %t699 = ptrtoint ptr %t698 to i64
  store i64 %t699, ptr %l276, !tbaa !24
  %t700 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t700, label %bb154, label %bb155
bb153:
  br label %bb173
bb154:
  %t702 = call ptr @__olang_region_make(ptr %v5)
  %t703 = ptrtoint ptr %t702 to i64
  store i64 %t703, ptr %l276, !tbaa !24
  br label %bb155
bb155:
  %t704 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 5
  %t705 = load { i64, ptr }, ptr %t704, !tbaa !27
  %t706 = load i64, ptr %l276
  %t707 = inttoptr i64 %t706 to ptr
  %t709 = call { i64, ptr } @compiler_2fprompt_2estopped(ptr %v5, ptr %t707, { i64, ptr } %t705)
  store { i64, ptr } %t709, ptr %l279
  br label %bb156
bb156:
  %t710 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t711 = load ptr, ptr %l275, !tbaa !29
  %t712 = getelementptr %"compiler/prompt:Reply", ptr %t711, i32 0, i32 4
  %t713 = load { i64, ptr }, ptr %t712, !tbaa !27
  store { i64, ptr } %t713, ptr %l281, !tbaa !27
  %t715 = load ptr, ptr %l275, !tbaa !29
  %t716 = getelementptr %"compiler/prompt:Reply", ptr %t715, i32 0, i32 4
  store { i64, ptr } %t710, ptr %t716, !tbaa !27
  %t717 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t717, label %bb157, label %bb158
bb157:
  %t719 = load { i64, ptr }, ptr %l281
  %t720 = extractvalue { i64, ptr } %t719, 1
  call void @__olang_region_release(ptr %t720)
  store { i64, ptr } zeroinitializer, ptr %l281
  br label %bb158
bb158:
  %t721 = load ptr, ptr %l0, !tbaa !29
  store ptr %t721, ptr %l283, !tbaa !29
  %t722 = call ptr @__olang_scope_hold(ptr %v0)
  %t723 = ptrtoint ptr %t722 to i64
  store i64 %t723, ptr %l284, !tbaa !24
  %t724 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t724, label %bb159, label %bb160
bb159:
  %t726 = call ptr @__olang_region_make(ptr %v0)
  %t727 = ptrtoint ptr %t726 to i64
  store i64 %t727, ptr %l284, !tbaa !24
  br label %bb160
bb160:
  %t728 = load ptr, ptr %lp24
  %t729 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t728
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t729, ptr %l287
  %t731 = load i64, ptr %l284
  %t732 = inttoptr i64 %t731 to ptr
  %t733 = call ptr @__olang_scope_hold(ptr %t732)
  %t734 = ptrtoint ptr %t733 to i64
  store i64 %t734, ptr %l288, !tbaa !24
  %t735 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t735, label %bb161, label %bb162
bb161:
  %t737 = load i64, ptr %l284
  %t738 = inttoptr i64 %t737 to ptr
  %t739 = call ptr @__olang_region_make_part(ptr %t738)
  %t740 = ptrtoint ptr %t739 to i64
  store i64 %t740, ptr %l288, !tbaa !24
  br label %bb162
bb162:
  %t741 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287, i32 0, i32 0
  %t742 = load { i64, ptr }, ptr %t741, !tbaa !27
  store { i64, ptr } %t742, ptr %l290, !tbaa !27
  %t743 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t743, 0
  store i64 %t744, ptr %l291, !tbaa !24
  %t745 = load i64, ptr %l291, !tbaa !24
  %t746 = mul i64 %t745, 80
  %t747 = load i64, ptr %l288
  %t748 = inttoptr i64 %t747 to ptr
  %t749 = call ptr @__olang_held_alloc(ptr %t748, i64 %t746)
  %t750 = insertvalue { i64, ptr } undef, i64 %t745, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t749, 1
  store { i64, ptr } %t751, ptr %l292, !tbaa !27
  %t752 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !27
  %t754 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = load i64, ptr %l291, !tbaa !24
  %t757 = mul i64 %t756, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t753, ptr %t755, i64 %t757, i1 false)
  %t758 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t759 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287, i32 0, i32 0
  store { i64, ptr } %t758, ptr %t759, !tbaa !27
  %t760 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t760, label %bb163, label %bb164
bb163:
  %t762 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287, i32 0, i32 0
  %t763 = load { i64, ptr }, ptr %t762, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t763, 0
  %t766 = icmp eq i64 %t764, 0
  br i1 %t766, label %bb165, label %bb166
bb164:
  %t768 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t768, label %bb167, label %bb168
bb165:
  %t770 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t770, !tbaa !27
  br label %bb166
bb166:
  %t771 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287, i32 0, i32 0
  %t772 = load i64, ptr %l288
  %t773 = inttoptr i64 %t772 to ptr
  %t774 = load { i64, ptr }, ptr %t771
  %t775 = extractvalue { i64, ptr } %t774, 1
  %t776 = call ptr @__olang_region_or(ptr %t775, ptr null)
  %t777 = icmp ne ptr %t776, null
  %t778 = select i1 %t777, ptr %t776, ptr null
  call void @__olang_region_settle_in(ptr %t773, ptr %t778)
  br label %bb164
bb167:
  %t779 = load i64, ptr %l284
  %t780 = inttoptr i64 %t779 to ptr
  %t781 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287, i32 0, i32 0
  %t782 = load { i64, ptr }, ptr %t781
  %t783 = extractvalue { i64, ptr } %t782, 1
  %t784 = call ptr @__olang_region_or(ptr %t783, ptr null)
  %t785 = call ptr @__olang_region_home(ptr %t784)
  %t786 = icmp ne ptr %t785, null
  %t787 = select i1 %t786, ptr %t785, ptr null
  call void @__olang_region_settle_in(ptr %t780, ptr %t787)
  br label %bb168
bb168:
  %t788 = load ptr, ptr %l283, !tbaa !29
  %t789 = getelementptr %"compiler/prompt:Session", ptr %t788, i32 0, i32 4
  %t790 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t789
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t790, ptr %l297
  %t791 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287
  %t792 = load ptr, ptr %l283, !tbaa !29
  %t793 = getelementptr %"compiler/prompt:Session", ptr %t792, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t791, ptr %t793
  %t794 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t794, label %bb169, label %bb170
bb169:
  %t796 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l297, i32 0, i32 0
  %t797 = load { i64, ptr }, ptr %t796
  %t798 = extractvalue { i64, ptr } %t797, 1
  %t799 = call ptr @__olang_region_or(ptr %t798, ptr null)
  %t800 = call ptr @__olang_region_home(ptr %t799)
  %t801 = icmp ne ptr %t800, null
  %t802 = select i1 %t801, ptr %t800, ptr null
  call void @__olang_region_drop(ptr %t802)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l297
  br label %bb170
bb170:
  %t803 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t803, label %bb171, label %bb172
bb171:
  %t805 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l297, i32 0, i32 0
  %t806 = load { i64, ptr }, ptr %t805
  %t807 = extractvalue { i64, ptr } %t806, 0
  %t808 = extractvalue { i64, ptr } %t806, 1
  call void @__olang_region_release_part(ptr %t808, i64 %t807)
  store { i64, ptr } zeroinitializer, ptr %t805
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb173:
  %t809 = load ptr, ptr %l5, !tbaa !29
  store ptr %t809, ptr %l300, !tbaa !29
  %t810 = call ptr @__olang_scope_hold(ptr %v5)
  %t811 = ptrtoint ptr %t810 to i64
  store i64 %t811, ptr %l301, !tbaa !24
  %t812 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t812, label %bb174, label %bb175
bb174:
  %t814 = call ptr @__olang_region_make(ptr %v5)
  %t815 = ptrtoint ptr %t814 to i64
  store i64 %t815, ptr %l301, !tbaa !24
  br label %bb175
bb175:
  %t816 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 4
  %t817 = load { i64, ptr }, ptr %t816, !tbaa !27
  %t818 = load ptr, ptr %lp19
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t821 = getelementptr %"compiler/prompt:Session", ptr %t819, i32 0, i32 2
  %t822 = load { i64, ptr }, ptr %t821, !tbaa !27
  %t823 = load i64, ptr %l301
  %t824 = inttoptr i64 %t823 to ptr
  %t828 = call { i64, ptr } @compiler_2fprompt_2eplaces(ptr %v5, ptr %v0, ptr %v0, ptr %t824, { i64, ptr } %t817, ptr %t818, { i64, ptr } %t822)
  store { i64, ptr } %t828, ptr %l307
  br label %bb176
bb176:
  %t829 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t830 = load i64, ptr %l301
  %t831 = inttoptr i64 %t830 to ptr
  %t832 = extractvalue { i64, ptr } %t829, 0
  %t833 = extractvalue { i64, ptr } %t829, 1
  %t834 = mul i64 %t832, 1
  %t835 = call ptr @__olang_held_alloc(ptr %t831, i64 %t834)
  call void @llvm.memcpy.p0.p0.i64(ptr %t835, ptr %t833, i64 %t834, i1 false)
  %t836 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t835, 1
  %t838 = load ptr, ptr %l300, !tbaa !29
  %t839 = getelementptr %"compiler/prompt:Reply", ptr %t838, i32 0, i32 4
  %t840 = load { i64, ptr }, ptr %t839, !tbaa !27
  store { i64, ptr } %t840, ptr %l309, !tbaa !27
  %t842 = load ptr, ptr %l300, !tbaa !29
  %t843 = getelementptr %"compiler/prompt:Reply", ptr %t842, i32 0, i32 4
  store { i64, ptr } %t837, ptr %t843, !tbaa !27
  %t844 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t844, label %bb177, label %bb178
bb177:
  %t846 = load { i64, ptr }, ptr %l309
  %t847 = extractvalue { i64, ptr } %t846, 1
  call void @__olang_region_release(ptr %t847)
  store { i64, ptr } zeroinitializer, ptr %l309
  br label %bb178
bb178:
  %t848 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 4
  %t849 = load { i64, ptr }, ptr %t848, !tbaa !27
  %t851 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t849, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t851, ptr %l312
  br label %bb179
bb179:
  %t852 = load i1, ptr %l312, !tbaa !21
  br i1 %t852, label %bb180, label %bb181
bb180:
  %t853 = load ptr, ptr %l3, !tbaa !29
  %t855 = getelementptr %"compiler/prompt:cell", ptr %t853, i32 0, i32 3
  store ptr %t855, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb182
bb181:
  br label %bb208
bb182:
  store %olang.scope zeroinitializer, ptr %s23
  %t857 = load i64, ptr %l29, !tbaa !24
  store i64 %t857, ptr %l315, !tbaa !24
  %t858 = load ptr, ptr %l28, !tbaa !29
  %t860 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t858)
  store i64 %t860, ptr %l317
  br label %bb183
bb183:
  %t861 = load i64, ptr %l315, !tbaa !24
  %t862 = load i64, ptr %l317, !tbaa !24
  %t863 = icmp slt i64 %t861, %t862
  %t865 = xor i1 %t863, true
  br i1 %t865, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s23)
  br label %bb191
bb185:
  br label %bb186
bb186:
  %t867 = load ptr, ptr %l28, !tbaa !29
  %t868 = load i64, ptr %l29, !tbaa !24
  %t871 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t867, i64 %t868)
  store %"compiler/prompt:Value" %t871, ptr %l322
  br label %bb187
bb187:
  %t872 = load %"compiler/prompt:Value", ptr %l322
  store %"compiler/prompt:Value" %t872, ptr %l30
  %t873 = load ptr, ptr %lp24
  store ptr %t873, ptr %l323, !tbaa !29
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = getelementptr %"compiler/prompt:Value", ptr %l30, i32 0, i32 0
  %t876 = load { i64, ptr }, ptr %t875, !tbaa !27
  %t877 = getelementptr %"compiler/prompt:Value", ptr %l30, i32 0, i32 1
  %t878 = load { i64, ptr }, ptr %t877, !tbaa !27
  %t879 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eKeepPrefix, !tbaa !27
  %t880 = getelementptr %"compiler/prompt:Value", ptr %l30, i32 0, i32 0
  %t881 = load { i64, ptr }, ptr %t880, !tbaa !27
  %t883 = extractvalue { i64, ptr } %t879, 1
  %t884 = extractvalue { i64, ptr } %t879, 0
  %t886 = extractvalue { i64, ptr } %t881, 1
  %t887 = extractvalue { i64, ptr } %t881, 0
  %t888 = add i64 %t884, %t887
  %t889 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t888)
  call void @olang_textcopy(ptr %t889, ptr %t883, i64 %t884)
  %t890 = getelementptr i8, ptr %t889, i64 %t884
  call void @olang_textcopy(ptr %t890, ptr %t886, i64 %t887)
  %t891 = insertvalue { i64, ptr } undef, i64 %t888, 0
  %t892 = insertvalue { i64, ptr } %t891, ptr %t889, 1
  %t894 = load ptr, ptr %l4, !tbaa !29
  %t900 = call %"compiler/prompt:Value" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekept(ptr %v0, ptr %v3, ptr %v3, ptr %s23, ptr %v4, ptr %v4, ptr %t874, { i64, ptr } %t876, { i64, ptr } %t878, i1 true, { i64, ptr } %t892, ptr %t894)
  store %"compiler/prompt:Value" %t900, ptr %l332
  br label %bb188
bb188:
  %t901 = load i64, ptr %l234
  %t902 = inttoptr i64 %t901 to ptr
  %t903 = load ptr, ptr %l323, !tbaa !29
  %t904 = load %"compiler/prompt:Value", ptr %l332
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %t902, ptr %v4, ptr %t903, %"compiler/prompt:Value" %t904)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s23)
  br label %bb190
bb190:
  %t905 = load i64, ptr %l29, !tbaa !24
  %t908 = add i64 %t905, 1
  store i64 %t908, ptr %l29, !tbaa !24
  br label %bb182
bb191:
  store ptr %l15, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s27
  %t911 = load i64, ptr %l32, !tbaa !24
  store i64 %t911, ptr %l337, !tbaa !24
  %t912 = load ptr, ptr %l31, !tbaa !29
  %t914 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t912)
  store i64 %t914, ptr %l339
  br label %bb193
bb193:
  %t915 = load i64, ptr %l337, !tbaa !24
  %t916 = load i64, ptr %l339, !tbaa !24
  %t917 = icmp slt i64 %t915, %t916
  %t919 = xor i1 %t917, true
  br i1 %t919, label %bb194, label %bb195
bb194:
  call void @__olang_scope_close(ptr %s27)
  br label %bb201
bb195:
  br label %bb196
bb196:
  %t921 = load ptr, ptr %l31, !tbaa !29
  %t922 = load i64, ptr %l32, !tbaa !24
  %t925 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t921, i64 %t922)
  store { i64, ptr } %t925, ptr %l344
  br label %bb197
bb197:
  %t926 = load { i64, ptr }, ptr %l344, !tbaa !27
  store { i64, ptr } %t926, ptr %l33, !tbaa !27
  %t927 = load ptr, ptr %lp24
  store ptr %t927, ptr %l345, !tbaa !29
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t929 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t930 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t931 = load ptr, ptr %l4, !tbaa !29
  %t936 = call %"compiler/prompt:Value" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ekept(ptr %v0, ptr %s0, ptr %s27, ptr %s0, ptr %v4, ptr %v4, ptr %t928, { i64, ptr } %t929, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, i1 false, { i64, ptr } %t930, ptr %t931)
  store %"compiler/prompt:Value" %t936, ptr %l350
  br label %bb198
bb198:
  %t937 = load i64, ptr %l234
  %t938 = inttoptr i64 %t937 to ptr
  %t939 = load ptr, ptr %l345, !tbaa !29
  %t940 = load %"compiler/prompt:Value", ptr %l350
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %t938, ptr %v4, ptr %t939, %"compiler/prompt:Value" %t940)
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s27)
  br label %bb200
bb200:
  %t941 = load i64, ptr %l32, !tbaa !24
  %t944 = add i64 %t941, 1
  store i64 %t944, ptr %l32, !tbaa !24
  br label %bb192
bb201:
  %t946 = load ptr, ptr %l5, !tbaa !29
  %t947 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 0
  %t948 = load i1, ptr %t947, !tbaa !21
  %t951 = getelementptr %"compiler/prompt:Reply", ptr %t946, i32 0, i32 2
  store i1 %t948, ptr %t951, !tbaa !21
  %t952 = load ptr, ptr %l5, !tbaa !29
  store ptr %t952, ptr %l356, !tbaa !29
  %t953 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 1
  %t954 = load { i64, ptr }, ptr %t953, !tbaa !27
  %t955 = load ptr, ptr %l356, !tbaa !29
  %t956 = getelementptr %"compiler/prompt:Reply", ptr %t955, i32 0, i32 3
  %t957 = load { i64, ptr }, ptr %t956, !tbaa !27
  store { i64, ptr } %t957, ptr %l358, !tbaa !27
  %t959 = load ptr, ptr %l356, !tbaa !29
  %t960 = getelementptr %"compiler/prompt:Reply", ptr %t959, i32 0, i32 3
  store { i64, ptr } %t954, ptr %t960, !tbaa !27
  %t961 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e3
  br i1 %t961, label %bb202, label %bb203
bb202:
  %t963 = load { i64, ptr }, ptr %l358
  %t964 = extractvalue { i64, ptr } %t963, 1
  call void @__olang_region_release(ptr %t964)
  store { i64, ptr } zeroinitializer, ptr %l358
  br label %bb203
bb203:
  %t965 = load ptr, ptr %l5, !tbaa !29
  store ptr %t965, ptr %l360, !tbaa !29
  %t966 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 2
  %t967 = load { i64, ptr }, ptr %t966, !tbaa !27
  %t968 = load ptr, ptr %l360, !tbaa !29
  %t969 = getelementptr %"compiler/prompt:Reply", ptr %t968, i32 0, i32 6
  %t970 = load { i64, ptr }, ptr %t969, !tbaa !27
  store { i64, ptr } %t970, ptr %l362, !tbaa !27
  %t972 = load ptr, ptr %l360, !tbaa !29
  %t973 = getelementptr %"compiler/prompt:Reply", ptr %t972, i32 0, i32 6
  store { i64, ptr } %t967, ptr %t973, !tbaa !27
  %t974 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e6
  br i1 %t974, label %bb204, label %bb205
bb204:
  %t976 = load { i64, ptr }, ptr %l362
  %t977 = extractvalue { i64, ptr } %t976, 1
  call void @__olang_region_release(ptr %t977)
  store { i64, ptr } zeroinitializer, ptr %l362
  br label %bb205
bb205:
  %t978 = load ptr, ptr %l5, !tbaa !29
  store ptr %t978, ptr %l364, !tbaa !29
  %t979 = getelementptr %"compiler/cells:Outcome", ptr %l23, i32 0, i32 3
  %t980 = load { i64, ptr }, ptr %t979, !tbaa !27
  %t981 = load ptr, ptr %l364, !tbaa !29
  %t982 = getelementptr %"compiler/prompt:Reply", ptr %t981, i32 0, i32 7
  %t983 = load { i64, ptr }, ptr %t982, !tbaa !27
  store { i64, ptr } %t983, ptr %l366, !tbaa !27
  %t985 = load ptr, ptr %l364, !tbaa !29
  %t986 = getelementptr %"compiler/prompt:Reply", ptr %t985, i32 0, i32 7
  store { i64, ptr } %t980, ptr %t986, !tbaa !27
  %t987 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e7
  br i1 %t987, label %bb206, label %bb207
bb206:
  %t989 = load { i64, ptr }, ptr %l366
  %t990 = extractvalue { i64, ptr } %t989, 1
  call void @__olang_region_release(ptr %t990)
  store { i64, ptr } zeroinitializer, ptr %l366
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t991 = load ptr, ptr %l0, !tbaa !29
  store ptr %t991, ptr %l368, !tbaa !29
  %t992 = load ptr, ptr %lp24
  %t993 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t992
  %t994 = load ptr, ptr %l368, !tbaa !29
  %t995 = getelementptr %"compiler/prompt:Session", ptr %t994, i32 0, i32 4
  %t996 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t995
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t996, ptr %l370
  %t998 = load ptr, ptr %l368, !tbaa !29
  %t999 = getelementptr %"compiler/prompt:Session", ptr %t998, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t993, ptr %t999
  %t1000 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t1000, label %bb209, label %bb210
bb209:
  %t1002 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l370, i32 0, i32 0
  %t1003 = load { i64, ptr }, ptr %t1002
  %t1004 = extractvalue { i64, ptr } %t1003, 1
  %t1005 = call ptr @__olang_region_or(ptr %t1004, ptr null)
  %t1006 = call ptr @__olang_region_home(ptr %t1005)
  %t1007 = icmp ne ptr %t1006, null
  %t1008 = select i1 %t1007, ptr %t1006, ptr null
  call void @__olang_region_drop(ptr %t1008)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l370
  br label %bb210
bb210:
  %t1009 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0
  br i1 %t1009, label %bb211, label %bb212
bb211:
  %t1011 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l370, i32 0, i32 0
  %t1012 = load { i64, ptr }, ptr %t1011
  %t1013 = extractvalue { i64, ptr } %t1012, 0
  %t1014 = extractvalue { i64, ptr } %t1012, 1
  call void @__olang_region_release_part(ptr %t1014, i64 %t1013)
  store { i64, ptr } zeroinitializer, ptr %t1011
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estartWorker(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l51 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l55 = alloca ptr
  %l57 = alloca %"compiler/build:Config"
  %l58 = alloca %"compiler/build:Config"
  %l94 = alloca ptr
  %l95 = alloca i64
  %l99 = alloca %"compiler/cells:Worker"
  %l101 = alloca %"compiler/cells:Worker"
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l113 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t158 = alloca %"compiler/build:Config", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:Session", ptr %t1, i32 0, i32 9
  %t5 = call i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRunning(ptr %v0, ptr %t3)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t9 = load { ptr, ptr }, ptr @G_2ecompiler_2fcells_2eBuilder
  %t11 = extractvalue { ptr, ptr } %t9, 0
  %t12 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t13 = icmp eq ptr %t11, %t12
  %t14 = extractvalue { ptr, ptr } %t9, 1
  %t15 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t16 = icmp eq ptr %t14, %t15
  %t17 = and i1 %t13, %t16
  br i1 %t17, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l11, !tbaa !27
  store { i64, ptr } %t19, ptr %l1, !tbaa !27
  %t22 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2estartWorker_2elocal_2e1
  br i1 %t22, label %bb7, label %bb8
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/prompt:Session", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_scope_or(ptr %v1, ptr %t32)
  %t34 = call ptr @__olang_scope_hold(ptr %t33)
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = inttoptr i64 %t35 to ptr
  %t38 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t37, ptr %s3, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t39, ptr %l17
  br label %bb9
bb7:
  %t40 = load { i64, ptr }, ptr %l11
  %t41 = extractvalue { i64, ptr } %t40, 1
  call void @__olang_region_release(ptr %t41)
  store { i64, ptr } zeroinitializer, ptr %l11
  br label %bb8
bb8:
  br label %bb20
bb9:
  %t42 = load i1, ptr %l17, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l20, !tbaa !27
  store { i64, ptr } %t43, ptr %l1, !tbaa !27
  %t46 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2estartWorker_2elocal_2e1
  br i1 %t46, label %bb12, label %bb13
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/prompt:Session", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t51, i32 0, i32 2
  %t54 = getelementptr %"compiler/target:Target", ptr %t53, i32 0, i32 9
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb12:
  %t57 = load { i64, ptr }, ptr %l20
  %t58 = extractvalue { i64, ptr } %t57, 1
  call void @__olang_region_release(ptr %t58)
  store { i64, ptr } zeroinitializer, ptr %l20
  br label %bb13
bb13:
  br label %bb19
bb14:
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l27, !tbaa !27
  store { i64, ptr } %t59, ptr %l1, !tbaa !27
  %t62 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2estartWorker_2elocal_2e1
  br i1 %t62, label %bb16, label %bb17
bb15:
  br label %bb18
bb16:
  %t64 = load { i64, ptr }, ptr %l27
  %t65 = extractvalue { i64, ptr } %t64, 1
  call void @__olang_region_release(ptr %t65)
  store { i64, ptr } zeroinitializer, ptr %l27
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t68, ptr %l30
  br label %bb21
bb21:
  %t69 = load i1, ptr %l30, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/prompt:Session", ptr %t70, i32 0, i32 10
  %t73 = getelementptr %"compiler/build:Config", ptr %t72, i32 0, i32 14
  %t74 = load i1, ptr %t73, !tbaa !21
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb24, label %bb25
bb23:
  br label %bb127
bb24:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l34, !tbaa !29
  %t79 = call ptr @__olang_scope_hold(ptr %v0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l35, !tbaa !24
  %t81 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e2
  br i1 %t81, label %bb26, label %bb27
bb25:
  br label %bb37
bb26:
  %t83 = call ptr @__olang_region_make(ptr %v0)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l35, !tbaa !24
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/prompt:Session", ptr %t85, i32 0, i32 2
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l38, !tbaa !27
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/prompt:Session", ptr %t89, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t96 = sub i64 %t94, 6
  store i64 %t96, ptr %l42, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l43, !tbaa !24
  %t99 = icmp sge i64 0, 0
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load i64, ptr %l42, !tbaa !24
  %t102 = icmp sle i64 0, %t101
  br i1 %t102, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4b18163218a04cd9_3c47abda6897b34d)
  unreachable
bb30:
  %t104 = load i64, ptr %l42, !tbaa !24
  %t105 = load i64, ptr %l43, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4b18163218a04cd9_3c47abda6897b34d)
  unreachable
bb32:
  %t108 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l42, !tbaa !24
  %t111 = getelementptr i8, ptr %t109, i64 0
  %t112 = sub i64 %t110, 0
  %t113 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  store { i64, ptr } %t114, ptr %l47, !tbaa !27
  %t115 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t115, ptr %l48
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_4b18163218a04cd9_3c47abda6897b34d)
  unreachable
bb34:
  %t116 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = load i32, ptr %l48, !tbaa !23
  %t123 = sext i32 %t122 to i64
  %t124 = call i64 @__olang_fmt_i64(ptr null, i64 %t123)
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = load i64, ptr %l35
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = call ptr @__olang_held_alloc(ptr %t130, i64 %t128)
  call void @olang_textcopy(ptr %t131, ptr %t117, i64 %t118)
  %t132 = getelementptr i8, ptr %t131, i64 %t118
  call void @olang_textcopy(ptr %t132, ptr %t119, i64 %t120)
  %t133 = getelementptr i8, ptr %t132, i64 %t120
  %t134 = call i64 @__olang_fmt_i64(ptr %t133, i64 %t123)
  %t135 = getelementptr i8, ptr %t133, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t131, 1
  %t139 = load ptr, ptr %l34, !tbaa !29
  %t140 = getelementptr %"compiler/prompt:Session", ptr %t139, i32 0, i32 2
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l51, !tbaa !27
  %t143 = load ptr, ptr %l34, !tbaa !29
  %t144 = getelementptr %"compiler/prompt:Session", ptr %t143, i32 0, i32 2
  store { i64, ptr } %t137, ptr %t144, !tbaa !27
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e2
  br i1 %t145, label %bb35, label %bb36
bb35:
  %t147 = load { i64, ptr }, ptr %l51
  %t148 = extractvalue { i64, ptr } %t147, 1
  call void @__olang_region_release(ptr %t148)
  store { i64, ptr } zeroinitializer, ptr %l51
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l53, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/prompt:Session", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  store ptr %t153, ptr %l55, !tbaa !29
  %t154 = load ptr, ptr %l55, !tbaa !29
  %t155 = call ptr @__olang_scope_or(ptr %v1, ptr %t154)
  %t156 = call ptr @__olang_scope_hold(ptr %t155)
  %t157 = ptrtoint ptr %t156 to i64
  %t160 = inttoptr i64 %t157 to ptr
  %t161 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fcells_2eConfig(ptr %t158, ptr %t160, ptr %v0, ptr %t161)
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t158, i64 720, i1 false)
  br label %bb38
bb38:
  %t162 = load ptr, ptr %l53, !tbaa !29
  %t163 = getelementptr %"compiler/prompt:Session", ptr %t162, i32 0, i32 10
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t163, i64 720, i1 false)
  %t164 = load ptr, ptr %l53, !tbaa !29
  %t165 = getelementptr %"compiler/prompt:Session", ptr %t164, i32 0, i32 10
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %l57, i64 720, i1 false)
  %t166 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e0
  br i1 %t166, label %bb39, label %bb40
bb39:
  %t168 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 0
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  call void @__olang_region_release(ptr %t170)
  store { i64, ptr } zeroinitializer, ptr %t168
  br label %bb40
bb40:
  %t171 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e1
  br i1 %t171, label %bb41, label %bb42
bb41:
  %t173 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 1
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  call void @__olang_region_release(ptr %t175)
  store { i64, ptr } zeroinitializer, ptr %t173
  br label %bb42
bb42:
  %t176 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e0
  br i1 %t176, label %bb43, label %bb44
bb43:
  %t178 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t179 = getelementptr %"compiler/target:Target", ptr %t178, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179
  %t181 = extractvalue { i64, ptr } %t180, 1
  call void @__olang_region_release(ptr %t181)
  store { i64, ptr } zeroinitializer, ptr %t179
  br label %bb44
bb44:
  %t182 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e1
  br i1 %t182, label %bb45, label %bb46
bb45:
  %t184 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t185 = getelementptr %"compiler/target:Target", ptr %t184, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185
  %t187 = extractvalue { i64, ptr } %t186, 1
  call void @__olang_region_release(ptr %t187)
  store { i64, ptr } zeroinitializer, ptr %t185
  br label %bb46
bb46:
  %t188 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e2
  br i1 %t188, label %bb47, label %bb48
bb47:
  %t190 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t191 = getelementptr %"compiler/target:Target", ptr %t190, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191
  %t193 = extractvalue { i64, ptr } %t192, 1
  call void @__olang_region_release(ptr %t193)
  store { i64, ptr } zeroinitializer, ptr %t191
  br label %bb48
bb48:
  %t194 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e3
  br i1 %t194, label %bb49, label %bb50
bb49:
  %t196 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t197 = getelementptr %"compiler/target:Target", ptr %t196, i32 0, i32 3
  %t198 = load { i64, ptr }, ptr %t197
  %t199 = extractvalue { i64, ptr } %t198, 1
  call void @__olang_region_release(ptr %t199)
  store { i64, ptr } zeroinitializer, ptr %t197
  br label %bb50
bb50:
  %t200 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e4
  br i1 %t200, label %bb51, label %bb52
bb51:
  %t202 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t203 = getelementptr %"compiler/target:Target", ptr %t202, i32 0, i32 4
  %t204 = load { i64, ptr }, ptr %t203
  %t205 = extractvalue { i64, ptr } %t204, 1
  call void @__olang_region_release(ptr %t205)
  store { i64, ptr } zeroinitializer, ptr %t203
  br label %bb52
bb52:
  %t206 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e5
  br i1 %t206, label %bb53, label %bb54
bb53:
  %t208 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t209 = getelementptr %"compiler/target:Target", ptr %t208, i32 0, i32 5
  %t210 = load { i64, ptr }, ptr %t209
  %t211 = extractvalue { i64, ptr } %t210, 1
  call void @__olang_region_release(ptr %t211)
  store { i64, ptr } zeroinitializer, ptr %t209
  br label %bb54
bb54:
  %t212 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e6
  br i1 %t212, label %bb55, label %bb56
bb55:
  %t214 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t215 = getelementptr %"compiler/target:Target", ptr %t214, i32 0, i32 6
  %t216 = load { i64, ptr }, ptr %t215
  %t217 = extractvalue { i64, ptr } %t216, 1
  call void @__olang_region_release(ptr %t217)
  store { i64, ptr } zeroinitializer, ptr %t215
  br label %bb56
bb56:
  %t218 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e13
  br i1 %t218, label %bb57, label %bb58
bb57:
  %t220 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 2
  %t221 = getelementptr %"compiler/target:Target", ptr %t220, i32 0, i32 13
  %t222 = load { i64, ptr }, ptr %t221
  %t223 = extractvalue { i64, ptr } %t222, 1
  call void @__olang_region_release(ptr %t223)
  store { i64, ptr } zeroinitializer, ptr %t221
  br label %bb58
bb58:
  %t224 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e0
  br i1 %t224, label %bb59, label %bb60
bb59:
  %t226 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t227 = getelementptr %"compiler/cond:Consts", ptr %t226, i32 0, i32 0
  %t228 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t227, i32 0, i32 0
  %t229 = load { i64, ptr }, ptr %t228
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = call ptr @__olang_region_or(ptr %t230, ptr null)
  %t232 = call ptr @__olang_region_home(ptr %t231)
  %t233 = icmp ne ptr %t232, null
  %t234 = select i1 %t233, ptr %t232, ptr null
  call void @__olang_region_drop(ptr %t234)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t227
  br label %bb60
bb60:
  %t235 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t235, label %bb61, label %bb62
bb61:
  %t237 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t238 = getelementptr %"compiler/cond:Consts", ptr %t237, i32 0, i32 0
  %t239 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t238, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239
  %t241 = extractvalue { i64, ptr } %t240, 0
  %t242 = extractvalue { i64, ptr } %t240, 1
  call void @__olang_region_release_part(ptr %t242, i64 %t241)
  store { i64, ptr } zeroinitializer, ptr %t239
  br label %bb62
bb62:
  %t243 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e2
  br i1 %t243, label %bb63, label %bb64
bb63:
  %t245 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t246 = getelementptr %"compiler/cond:Consts", ptr %t245, i32 0, i32 2
  %t247 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t246, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = call ptr @__olang_region_or(ptr %t249, ptr null)
  %t251 = call ptr @__olang_region_home(ptr %t250)
  %t252 = icmp ne ptr %t251, null
  %t253 = select i1 %t252, ptr %t251, ptr null
  call void @__olang_region_drop(ptr %t253)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t246
  br label %bb64
bb64:
  %t254 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t254, label %bb65, label %bb66
bb65:
  %t256 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t257 = getelementptr %"compiler/cond:Consts", ptr %t256, i32 0, i32 2
  %t258 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t257, i32 0, i32 0
  %t259 = load { i64, ptr }, ptr %t258
  %t260 = extractvalue { i64, ptr } %t259, 0
  %t261 = extractvalue { i64, ptr } %t259, 1
  call void @__olang_region_release_part(ptr %t261, i64 %t260)
  store { i64, ptr } zeroinitializer, ptr %t258
  br label %bb66
bb66:
  %t262 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e3
  br i1 %t262, label %bb67, label %bb68
bb67:
  %t264 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t265 = getelementptr %"compiler/cond:Consts", ptr %t264, i32 0, i32 3
  %t266 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t265, i32 0, i32 0
  %t267 = load { i64, ptr }, ptr %t266
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = call ptr @__olang_region_or(ptr %t268, ptr null)
  %t270 = call ptr @__olang_region_home(ptr %t269)
  %t271 = icmp ne ptr %t270, null
  %t272 = select i1 %t271, ptr %t270, ptr null
  call void @__olang_region_drop(ptr %t272)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t265
  br label %bb68
bb68:
  %t273 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t275 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t276 = getelementptr %"compiler/cond:Consts", ptr %t275, i32 0, i32 3
  %t277 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t276, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  call void @__olang_region_release_part(ptr %t280, i64 %t279)
  store { i64, ptr } zeroinitializer, ptr %t277
  br label %bb70
bb70:
  %t281 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e4
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t283 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t284 = getelementptr %"compiler/cond:Consts", ptr %t283, i32 0, i32 4
  %t285 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t284, i32 0, i32 0
  %t286 = load { i64, ptr }, ptr %t285
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = call ptr @__olang_region_or(ptr %t287, ptr null)
  %t289 = call ptr @__olang_region_home(ptr %t288)
  %t290 = icmp ne ptr %t289, null
  %t291 = select i1 %t290, ptr %t289, ptr null
  call void @__olang_region_drop(ptr %t291)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t284
  br label %bb72
bb72:
  %t292 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t292, label %bb73, label %bb74
bb73:
  %t294 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t295 = getelementptr %"compiler/cond:Consts", ptr %t294, i32 0, i32 4
  %t296 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t295, i32 0, i32 0
  %t297 = load { i64, ptr }, ptr %t296
  %t298 = extractvalue { i64, ptr } %t297, 0
  %t299 = extractvalue { i64, ptr } %t297, 1
  call void @__olang_region_release_part(ptr %t299, i64 %t298)
  store { i64, ptr } zeroinitializer, ptr %t296
  br label %bb74
bb74:
  %t300 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e5
  br i1 %t300, label %bb75, label %bb76
bb75:
  %t302 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t303 = getelementptr %"compiler/cond:Consts", ptr %t302, i32 0, i32 5
  %t304 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t303, i32 0, i32 0
  %t305 = load { i64, ptr }, ptr %t304
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = call ptr @__olang_region_or(ptr %t306, ptr null)
  %t308 = call ptr @__olang_region_home(ptr %t307)
  %t309 = icmp ne ptr %t308, null
  %t310 = select i1 %t309, ptr %t308, ptr null
  call void @__olang_region_drop(ptr %t310)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t303
  br label %bb76
bb76:
  %t311 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t311, label %bb77, label %bb78
bb77:
  %t313 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t314 = getelementptr %"compiler/cond:Consts", ptr %t313, i32 0, i32 5
  %t315 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t314, i32 0, i32 0
  %t316 = load { i64, ptr }, ptr %t315
  %t317 = extractvalue { i64, ptr } %t316, 0
  %t318 = extractvalue { i64, ptr } %t316, 1
  call void @__olang_region_release_part(ptr %t318, i64 %t317)
  store { i64, ptr } zeroinitializer, ptr %t315
  br label %bb78
bb78:
  %t319 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e6
  br i1 %t319, label %bb79, label %bb80
bb79:
  %t321 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t322 = getelementptr %"compiler/cond:Consts", ptr %t321, i32 0, i32 6
  %t323 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t322, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = call ptr @__olang_region_or(ptr %t325, ptr null)
  %t327 = call ptr @__olang_region_home(ptr %t326)
  %t328 = icmp ne ptr %t327, null
  %t329 = select i1 %t328, ptr %t327, ptr null
  call void @__olang_region_drop(ptr %t329)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t322
  br label %bb80
bb80:
  %t330 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t330, label %bb81, label %bb82
bb81:
  %t332 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t333 = getelementptr %"compiler/cond:Consts", ptr %t332, i32 0, i32 6
  %t334 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t333, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  call void @__olang_region_release_part(ptr %t337, i64 %t336)
  store { i64, ptr } zeroinitializer, ptr %t334
  br label %bb82
bb82:
  %t338 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aConsts_2e7
  br i1 %t338, label %bb83, label %bb84
bb83:
  %t340 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t341 = getelementptr %"compiler/cond:Consts", ptr %t340, i32 0, i32 7
  %t342 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t341, i32 0, i32 0
  %t343 = load { i64, ptr }, ptr %t342
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = call ptr @__olang_region_or(ptr %t344, ptr null)
  %t346 = call ptr @__olang_region_home(ptr %t345)
  %t347 = icmp ne ptr %t346, null
  %t348 = select i1 %t347, ptr %t346, ptr null
  call void @__olang_region_drop(ptr %t348)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t341
  br label %bb84
bb84:
  %t349 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t349, label %bb85, label %bb86
bb85:
  %t351 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 3
  %t352 = getelementptr %"compiler/cond:Consts", ptr %t351, i32 0, i32 7
  %t353 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t352, i32 0, i32 0
  %t354 = load { i64, ptr }, ptr %t353
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = extractvalue { i64, ptr } %t354, 1
  call void @__olang_region_release_part(ptr %t356, i64 %t355)
  store { i64, ptr } zeroinitializer, ptr %t353
  br label %bb86
bb86:
  %t357 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e12
  br i1 %t357, label %bb87, label %bb88
bb87:
  %t359 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 12
  %t360 = load { i64, ptr }, ptr %t359
  %t361 = extractvalue { i64, ptr } %t360, 1
  call void @__olang_region_release(ptr %t361)
  store { i64, ptr } zeroinitializer, ptr %t359
  br label %bb88
bb88:
  %t362 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e16
  br i1 %t362, label %bb89, label %bb90
bb89:
  %t364 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 16
  %t365 = load { i64, ptr }, ptr %t364
  %t366 = extractvalue { i64, ptr } %t365, 1
  call void @__olang_region_release(ptr %t366)
  store { i64, ptr } zeroinitializer, ptr %t364
  br label %bb90
bb90:
  %t367 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e23
  br i1 %t367, label %bb91, label %bb92
bb91:
  %t369 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 23
  %t370 = load { i64, ptr }, ptr %t369
  %t371 = extractvalue { i64, ptr } %t370, 1
  call void @__olang_region_release(ptr %t371)
  store { i64, ptr } zeroinitializer, ptr %t369
  br label %bb92
bb92:
  %t372 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e28
  br i1 %t372, label %bb93, label %bb94
bb93:
  %t374 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 28
  %t375 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t374, i32 0, i32 0
  %t376 = load { i64, ptr }, ptr %t375
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = call ptr @__olang_region_or(ptr %t377, ptr null)
  %t379 = call ptr @__olang_region_home(ptr %t378)
  %t380 = icmp ne ptr %t379, null
  %t381 = select i1 %t380, ptr %t379, ptr null
  call void @__olang_region_drop(ptr %t381)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t374
  br label %bb94
bb94:
  %t382 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t382, label %bb95, label %bb96
bb95:
  %t384 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 28
  %t385 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t384, i32 0, i32 0
  %t386 = load { i64, ptr }, ptr %t385
  %t387 = extractvalue { i64, ptr } %t386, 0
  %t388 = extractvalue { i64, ptr } %t386, 1
  call void @__olang_region_release_part(ptr %t388, i64 %t387)
  store { i64, ptr } zeroinitializer, ptr %t385
  br label %bb96
bb96:
  %t389 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e30
  br i1 %t389, label %bb97, label %bb98
bb97:
  %t391 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 30
  %t392 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t391, i32 0, i32 0
  %t393 = load { i64, ptr }, ptr %t392
  %t394 = extractvalue { i64, ptr } %t393, 1
  %t395 = call ptr @__olang_region_or(ptr %t394, ptr null)
  %t396 = call ptr @__olang_region_home(ptr %t395)
  %t397 = icmp ne ptr %t396, null
  %t398 = select i1 %t397, ptr %t396, ptr null
  call void @__olang_region_drop(ptr %t398)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t391
  br label %bb98
bb98:
  %t399 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t399, label %bb99, label %bb100
bb99:
  %t401 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 30
  %t402 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t401, i32 0, i32 0
  %t403 = load { i64, ptr }, ptr %t402
  %t404 = extractvalue { i64, ptr } %t403, 0
  %t405 = extractvalue { i64, ptr } %t403, 1
  call void @__olang_region_release_part(ptr %t405, i64 %t404)
  store { i64, ptr } zeroinitializer, ptr %t402
  br label %bb100
bb100:
  %t406 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e34
  br i1 %t406, label %bb101, label %bb102
bb101:
  %t408 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 34
  %t409 = load { i64, ptr }, ptr %t408
  %t410 = extractvalue { i64, ptr } %t409, 1
  call void @__olang_region_release(ptr %t410)
  store { i64, ptr } zeroinitializer, ptr %t408
  br label %bb102
bb102:
  %t411 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e35
  br i1 %t411, label %bb103, label %bb104
bb103:
  %t413 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 35
  %t414 = load { i64, ptr }, ptr %t413
  %t415 = extractvalue { i64, ptr } %t414, 1
  call void @__olang_region_release(ptr %t415)
  store { i64, ptr } zeroinitializer, ptr %t413
  br label %bb104
bb104:
  %t416 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e40
  br i1 %t416, label %bb105, label %bb106
bb105:
  %t418 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 40
  %t419 = load { i64, ptr }, ptr %t418
  %t420 = extractvalue { i64, ptr } %t419, 1
  call void @__olang_region_release(ptr %t420)
  store { i64, ptr } zeroinitializer, ptr %t418
  br label %bb106
bb106:
  %t421 = load i1, ptr @olang_2esole_2ecompiler_2fbuild_3aConfig_2e41
  br i1 %t421, label %bb107, label %bb108
bb107:
  %t423 = getelementptr %"compiler/build:Config", ptr %l58, i32 0, i32 41
  %t424 = load { i64, ptr }, ptr %t423
  %t425 = extractvalue { i64, ptr } %t424, 1
  call void @__olang_region_release(ptr %t425)
  store { i64, ptr } zeroinitializer, ptr %t423
  br label %bb108
bb108:
  %t426 = load ptr, ptr %l0, !tbaa !29
  store ptr %t426, ptr %l94, !tbaa !29
  %t427 = call ptr @__olang_scope_hold(ptr %v0)
  %t428 = ptrtoint ptr %t427 to i64
  store i64 %t428, ptr %l95, !tbaa !24
  %t429 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e9
  br i1 %t429, label %bb109, label %bb110
bb109:
  %t431 = call ptr @__olang_region_make(ptr %v0)
  %t432 = ptrtoint ptr %t431 to i64
  store i64 %t432, ptr %l95, !tbaa !24
  br label %bb110
bb110:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/prompt:Session", ptr %t433, i32 0, i32 8
  %t436 = load i1, ptr %t435, !tbaa !21
  %t437 = load i64, ptr %l95
  %t438 = inttoptr i64 %t437 to ptr
  %t440 = call %"compiler/cells:Worker" @compiler_2fcells_3aWorker_2ector(ptr %t438, i1 %t436)
  store %"compiler/cells:Worker" %t440, ptr %l99
  br label %bb111
bb111:
  %t441 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e9
  br i1 %t441, label %bb112, label %bb113
bb112:
  %t443 = load i64, ptr %l95
  %t444 = inttoptr i64 %t443 to ptr
  %t445 = getelementptr %"compiler/cells:Worker", ptr %l99, i32 0, i32 8
  %t446 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t445, i32 0, i32 0
  %t447 = load { i64, ptr }, ptr %t446
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = call ptr @__olang_region_or(ptr %t448, ptr null)
  %t450 = call ptr @__olang_region_home(ptr %t449)
  %t451 = icmp ne ptr %t450, null
  %t452 = select i1 %t451, ptr %t450, ptr null
  call void @__olang_region_settle_in(ptr %t444, ptr %t452)
  br label %bb113
bb113:
  %t453 = load ptr, ptr %l94, !tbaa !29
  %t454 = getelementptr %"compiler/prompt:Session", ptr %t453, i32 0, i32 9
  %t455 = load %"compiler/cells:Worker", ptr %t454
  store %"compiler/cells:Worker" %t455, ptr %l101
  %t456 = load %"compiler/cells:Worker", ptr %l99
  %t457 = load ptr, ptr %l94, !tbaa !29
  %t458 = getelementptr %"compiler/prompt:Session", ptr %t457, i32 0, i32 9
  store %"compiler/cells:Worker" %t456, ptr %t458
  %t459 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e9
  br i1 %t459, label %bb114, label %bb115
bb114:
  %t461 = getelementptr %"compiler/cells:Worker", ptr %l101, i32 0, i32 8
  %t462 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t461, i32 0, i32 0
  %t463 = load { i64, ptr }, ptr %t462
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = call ptr @__olang_region_or(ptr %t464, ptr null)
  %t466 = call ptr @__olang_region_home(ptr %t465)
  %t467 = icmp ne ptr %t466, null
  %t468 = select i1 %t467, ptr %t466, ptr null
  call void @__olang_region_drop(ptr %t468)
  store %"compiler/cells:Worker" zeroinitializer, ptr %l101
  br label %bb115
bb115:
  %t469 = load i1, ptr @olang_2esole_2ecompiler_2fcells_3aWorker_2e8
  br i1 %t469, label %bb116, label %bb117
bb116:
  %t471 = getelementptr %"compiler/cells:Worker", ptr %l101, i32 0, i32 8
  %t472 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t471, i32 0, i32 0
  %t473 = load { i64, ptr }, ptr %t472
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = call ptr @__olang_region_or(ptr %t474, ptr null)
  %t476 = call ptr @__olang_region_home(ptr %t475)
  %t477 = icmp ne ptr %t476, null
  %t478 = select i1 %t477, ptr %t476, ptr null
  call void @__olang_region_drop(ptr %t478)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t471
  br label %bb117
bb117:
  %t479 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2e0
  br i1 %t479, label %bb118, label %bb119
bb118:
  %t481 = getelementptr %"compiler/cells:Worker", ptr %l101, i32 0, i32 8
  %t482 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t481, i32 0, i32 0
  %t483 = load { i64, ptr }, ptr %t482
  %t484 = extractvalue { i64, ptr } %t483, 0
  %t485 = extractvalue { i64, ptr } %t483, 1
  call void @__olang_region_release_part(ptr %t485, i64 %t484)
  store { i64, ptr } zeroinitializer, ptr %t482
  br label %bb119
bb119:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/prompt:Session", ptr %t486, i32 0, i32 9
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/prompt:Session", ptr %t489, i32 0, i32 10
  %t494 = call { i64, ptr } @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eStart(ptr %v0, ptr %v0, ptr %s0, ptr %t488, ptr %t491)
  store { i64, ptr } %t494, ptr %l109
  br label %bb120
bb120:
  %t495 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t495, ptr %l110, !tbaa !27
  %t496 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t496, ptr %l1, !tbaa !27
  %t497 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2estartWorker_2elocal_2e1
  br i1 %t497, label %bb121, label %bb122
bb121:
  %t499 = load { i64, ptr }, ptr %l110
  %t500 = extractvalue { i64, ptr } %t499, 1
  call void @__olang_region_release(ptr %t500)
  store { i64, ptr } zeroinitializer, ptr %l110
  br label %bb122
bb122:
  %t501 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t503 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t501, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t503, ptr %l113
  br label %bb123
bb123:
  %t504 = load i1, ptr %l113, !tbaa !21
  br i1 %t504, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s7)
  br label %bb127
bb127:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/prompt:Session", ptr %t505, i32 0, i32 7
  store i1 true, ptr %t507, !tbaa !21
  %t508 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t509 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t510 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t512 = extractvalue { i64, ptr } %t508, 1
  %t513 = extractvalue { i64, ptr } %t508, 0
  %t514 = add i64 %t510, %t513
  %t515 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t517 = add i64 %t514, %t516
  %t518 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t517)
  call void @olang_textcopy(ptr %t518, ptr %t509, i64 %t510)
  %t519 = getelementptr i8, ptr %t518, i64 %t510
  call void @olang_textcopy(ptr %t519, ptr %t512, i64 %t513)
  %t520 = getelementptr i8, ptr %t519, i64 %t513
  call void @olang_textcopy(ptr %t520, ptr %t515, i64 %t516)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t518, 1
  call void @compiler_2fprompt_2esayErr(ptr %s0, { i64, ptr } %t522)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/prompt:program" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/prompt:Decl"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/prompt:Decl"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/prompt:Value"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/prompt:Value"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/prompt:item"
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/prompt:Value"
  %l27 = alloca %"compiler/prompt:program"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/prompt:Decl"
  %l38 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca %"compiler/prompt:Decl"
  %l56 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i64
  %l73 = alloca %"compiler/prompt:Value"
  %l90 = alloca i64
  %l92 = alloca i64
  %l97 = alloca %"compiler/prompt:Value"
  %l131 = alloca i64
  %l135 = alloca i64
  %l137 = alloca i64
  %l143 = alloca %"compiler/prompt:item"
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l156 = alloca i1
  %l169 = alloca i1
  %l185 = alloca i64
  %l187 = alloca i64
  %l192 = alloca %"compiler/prompt:Value"
  %l193 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca i1
  %l198 = alloca { i64, ptr }
  %l210 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca %"compiler/prompt:program"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/prompt:program" @compiler_2fprompt_3aprogram_2ector(ptr %v4)
  store %"compiler/prompt:program" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 128, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"compiler/prompt:program", ptr %l27
  %t4 = load ptr, ptr %lp5
  store %"compiler/prompt:program" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l7, !tbaa !24
  store i64 %t7, ptr %l29, !tbaa !24
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l31
  br label %bb3
bb3:
  %t11 = load i64, ptr %l29, !tbaa !24
  %t12 = load i64, ptr %l31, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = call %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  store %"compiler/prompt:Decl" %t21, ptr %l36
  br label %bb7
bb7:
  %t22 = load %"compiler/prompt:Decl", ptr %l36
  store %"compiler/prompt:Decl" %t22, ptr %l8
  %t23 = getelementptr %"compiler/prompt:Decl", ptr %l8, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s2, { i64, ptr } %t24, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t26, ptr %l38
  br label %bb8
bb8:
  %t27 = load i1, ptr %l38, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %lp5
  %t29 = getelementptr %"compiler/prompt:Decl", ptr %l8, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/prompt:Decl", ptr %l8, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/prompt:Decl", ptr %l8, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %v1, ptr %v1, ptr %t28, { i64, ptr } %t30, { i64, ptr } %t32, i64 %t34)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb2
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t46 = load i64, ptr %l10, !tbaa !24
  store i64 %t46, ptr %l47, !tbaa !24
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v1, ptr %t47)
  store i64 %t49, ptr %l49
  br label %bb16
bb16:
  %t50 = load i64, ptr %l47, !tbaa !24
  %t51 = load i64, ptr %l49, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l9, !tbaa !29
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = call %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v1, ptr %v1, ptr %t56, i64 %t57)
  store %"compiler/prompt:Decl" %t60, ptr %l54
  br label %bb20
bb20:
  %t61 = load %"compiler/prompt:Decl", ptr %l54
  store %"compiler/prompt:Decl" %t61, ptr %l11
  %t62 = getelementptr %"compiler/prompt:Decl", ptr %l11, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s6, { i64, ptr } %t63, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t65, ptr %l56
  br label %bb21
bb21:
  %t66 = load i1, ptr %l56, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %lp5
  %t70 = getelementptr %"compiler/prompt:Decl", ptr %l11, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t72 = getelementptr %"compiler/prompt:Decl", ptr %l11, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/prompt:Decl", ptr %l11, i32 0, i32 3
  %t75 = load i64, ptr %t74, !tbaa !24
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %v1, ptr %v1, ptr %t69, { i64, ptr } %t71, { i64, ptr } %t73, i64 %t75)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb26
bb26:
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l10, !tbaa !24
  br label %bb15
bb27:
  store ptr %a2, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s10
  %t87 = load i64, ptr %l13, !tbaa !24
  store i64 %t87, ptr %l66, !tbaa !24
  %t88 = load ptr, ptr %l12, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t88)
  store i64 %t90, ptr %l68
  br label %bb29
bb29:
  %t91 = load i64, ptr %l66, !tbaa !24
  %t92 = load i64, ptr %l68, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s10)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l12, !tbaa !29
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t97, i64 %t98)
  store %"compiler/prompt:Value" %t101, ptr %l73
  br label %bb33
bb33:
  %t102 = load %"compiler/prompt:Value", ptr %l73
  store %"compiler/prompt:Value" %t102, ptr %l14
  %t103 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 2
  %t104 = load i1, ptr %t103, !tbaa !21
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s10)
  br label %bb39
bb35:
  br label %bb36
bb36:
  %t108 = load ptr, ptr %lp5
  %t109 = getelementptr %"compiler/prompt:program", ptr %t108, i32 0, i32 3
  %t110 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v2, ptr %t109, { i64, ptr } %t111)
  br label %bb37
bb37:
  %t114 = load ptr, ptr %lp5
  %t115 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = getelementptr %"compiler/prompt:Value", ptr %l14, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t122 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t126 = extractvalue { i64, ptr } %t118, 1
  %t127 = extractvalue { i64, ptr } %t118, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t120, i64 %t121)
  %t133 = getelementptr i8, ptr %t132, i64 %t121
  call void @olang_textcopy(ptr %t133, ptr %t122, i64 %t123)
  %t134 = getelementptr i8, ptr %t133, i64 %t123
  call void @olang_textcopy(ptr %t134, ptr %t126, i64 %t127)
  %t135 = getelementptr i8, ptr %t134, i64 %t127
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t132, 1
  %t139 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t140 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s10, ptr %t140, ptr %t114, { i64, ptr } %t137, { i64, ptr } %t139, i64 0)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb39
bb39:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = add i64 %t144, 1
  store i64 %t147, ptr %l13, !tbaa !24
  br label %bb28
bb40:
  %t149 = load i1, ptr %l4, !tbaa !21
  br i1 %t149, label %bb41, label %bb42
bb41:
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t153 = getelementptr %"compiler/prompt:cell", ptr %t151, i32 0, i32 3
  store ptr %t153, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb42:
  br label %bb52
bb43:
  store %olang.scope zeroinitializer, ptr %s16
  %t155 = load i64, ptr %l16, !tbaa !24
  store i64 %t155, ptr %l90, !tbaa !24
  %t156 = load ptr, ptr %l15, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t156)
  store i64 %t158, ptr %l92
  br label %bb44
bb44:
  %t159 = load i64, ptr %l90, !tbaa !24
  %t160 = load i64, ptr %l92, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s16)
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t165 = load ptr, ptr %l15, !tbaa !29
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t165, i64 %t166)
  store %"compiler/prompt:Value" %t169, ptr %l97
  br label %bb48
bb48:
  %t170 = load %"compiler/prompt:Value", ptr %l97
  store %"compiler/prompt:Value" %t170, ptr %l17
  %t171 = load ptr, ptr %lp5
  %t172 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eKeepPrefix, !tbaa !27
  %t173 = getelementptr %"compiler/prompt:Value", ptr %l17, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t175 = getelementptr %"compiler/prompt:Value", ptr %l17, i32 0, i32 1
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t172, 1
  %t179 = extractvalue { i64, ptr } %t172, 0
  %t181 = extractvalue { i64, ptr } %t174, 1
  %t182 = extractvalue { i64, ptr } %t174, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t188 = extractvalue { i64, ptr } %t176, 1
  %t189 = extractvalue { i64, ptr } %t176, 0
  %t190 = add i64 %t186, %t189
  %t191 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t193 = add i64 %t190, %t192
  %t194 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t178, i64 %t179)
  %t195 = getelementptr i8, ptr %t194, i64 %t179
  call void @olang_textcopy(ptr %t195, ptr %t181, i64 %t182)
  %t196 = getelementptr i8, ptr %t195, i64 %t182
  call void @olang_textcopy(ptr %t196, ptr %t184, i64 %t185)
  %t197 = getelementptr i8, ptr %t196, i64 %t185
  call void @olang_textcopy(ptr %t197, ptr %t188, i64 %t189)
  %t198 = getelementptr i8, ptr %t197, i64 %t189
  call void @olang_textcopy(ptr %t198, ptr %t191, i64 %t192)
  %t199 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t194, 1
  %t202 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t203 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s16, ptr %t203, ptr %t171, { i64, ptr } %t200, { i64, ptr } %t202, i64 0)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s16)
  br label %bb50
bb50:
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l16, !tbaa !24
  br label %bb43
bb51:
  br label %bb52
bb52:
  %t212 = load ptr, ptr %l3, !tbaa !29
  %t214 = getelementptr %"compiler/prompt:cell", ptr %t212, i32 0, i32 4
  %t215 = load i1, ptr %t214, !tbaa !21
  br i1 %t215, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s19
  %t217 = load ptr, ptr %lp5
  %t218 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eShownName, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 1
  %t221 = extractvalue { i64, ptr } %t218, 0
  %t222 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t220, i64 %t221)
  %t226 = getelementptr i8, ptr %t225, i64 %t221
  call void @olang_textcopy(ptr %t226, ptr %t222, i64 %t223)
  %t227 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t225, 1
  %t230 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t231 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s19, ptr %t231, ptr %t217, { i64, ptr } %t228, { i64, ptr } %t230, i64 0)
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t235 = load ptr, ptr %lp5
  %t236 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eRichDecls, !tbaa !27
  %t237 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t238 = load ptr, ptr @__olang_prog_scope
  %t239 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %t238, ptr %t239, ptr %t235, { i64, ptr } %t236, { i64, ptr } %t237, i64 0)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s19)
  br label %bb57
bb57:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/prompt:Session", ptr %t243, i32 0, i32 7
  %t246 = load i1, ptr %t245, !tbaa !21
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb58, label %bb59
bb58:
  %t250 = load ptr, ptr %lp5
  %t251 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSayDecl, !tbaa !27
  %t252 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t253 = load ptr, ptr @__olang_prog_scope
  %t254 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %t253, ptr %t254, ptr %t250, { i64, ptr } %t251, { i64, ptr } %t252, i64 0)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  %t258 = load ptr, ptr %lp5
  %t259 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eCellName, !tbaa !27
  %t260 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t263 = extractvalue { i64, ptr } %t259, 1
  %t264 = extractvalue { i64, ptr } %t259, 0
  %t265 = add i64 %t261, %t264
  %t266 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t268 = add i64 %t265, %t267
  %t269 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t260, i64 %t261)
  %t270 = getelementptr i8, ptr %t269, i64 %t261
  call void @olang_textcopy(ptr %t270, ptr %t263, i64 %t264)
  %t271 = getelementptr i8, ptr %t270, i64 %t264
  call void @olang_textcopy(ptr %t271, ptr %t266, i64 %t267)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t269, 1
  %t275 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t276 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s0, ptr %t276, ptr %t258, { i64, ptr } %t273, { i64, ptr } %t275, i64 0)
  br label %bb62
bb62:
  %t280 = load ptr, ptr %l3, !tbaa !29
  %t282 = getelementptr %"compiler/prompt:cell", ptr %t280, i32 0, i32 2
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t282)
  store i64 %t284, ptr %l131
  br label %bb63
bb63:
  %t285 = load i64, ptr %l131, !tbaa !24
  %t286 = sub i64 %t285, 1
  store i64 %t286, ptr %l18, !tbaa !24
  %t288 = load ptr, ptr %l3, !tbaa !29
  %t290 = getelementptr %"compiler/prompt:cell", ptr %t288, i32 0, i32 2
  store ptr %t290, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb64:
  %t292 = load i64, ptr %l20, !tbaa !24
  store i64 %t292, ptr %l135, !tbaa !24
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %t293)
  store i64 %t295, ptr %l137
  br label %bb65
bb65:
  %t296 = load i64, ptr %l135, !tbaa !24
  %t297 = load i64, ptr %l137, !tbaa !24
  %t298 = icmp slt i64 %t296, %t297
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb66, label %bb67
bb66:
  br label %bb95
bb67:
  br label %bb68
bb68:
  %t302 = load i64, ptr %l20, !tbaa !24
  store i64 %t302, ptr %l21, !tbaa !24
  %t304 = load ptr, ptr %l19, !tbaa !29
  %t305 = load i64, ptr %l20, !tbaa !24
  %t308 = call %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v3, ptr %v3, ptr %t304, i64 %t305)
  store %"compiler/prompt:item" %t308, ptr %l143
  br label %bb69
bb69:
  %t309 = load %"compiler/prompt:item", ptr %l143
  store %"compiler/prompt:item" %t309, ptr %l22
  %t310 = getelementptr %"compiler/prompt:item", ptr %l22, i32 0, i32 3
  %t311 = load i1, ptr %t310, !tbaa !21
  br i1 %t311, label %bb70, label %bb71
bb70:
  br label %bb94
bb71:
  br label %bb72
bb72:
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t315 = getelementptr %"compiler/prompt:cell", ptr %t313, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l146, !tbaa !27
  %t317 = getelementptr %"compiler/prompt:item", ptr %l22, i32 0, i32 0
  %t318 = load i64, ptr %t317, !tbaa !24
  store i64 %t318, ptr %l147, !tbaa !24
  %t319 = getelementptr %"compiler/prompt:item", ptr %l22, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l148, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  store i64 %t322, ptr %l149, !tbaa !24
  %t323 = load i64, ptr %l147, !tbaa !24
  %t324 = icmp sge i64 %t323, 0
  br i1 %t324, label %bb73, label %bb74
bb73:
  %t326 = load i64, ptr %l147, !tbaa !24
  %t327 = load i64, ptr %l148, !tbaa !24
  %t328 = icmp sle i64 %t326, %t327
  br i1 %t328, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_10924d50905b82ca_4ba1203e047902e)
  unreachable
bb75:
  %t330 = load i64, ptr %l148, !tbaa !24
  %t331 = load i64, ptr %l149, !tbaa !24
  %t332 = icmp sle i64 %t330, %t331
  br i1 %t332, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_10924d50905b82ca_4ba1203e047902e)
  unreachable
bb77:
  %t334 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = load i64, ptr %l147, !tbaa !24
  %t337 = load i64, ptr %l148, !tbaa !24
  %t338 = getelementptr i8, ptr %t335, i64 %t336
  %t339 = sub i64 %t337, %t336
  %t340 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t338, 1
  store { i64, ptr } %t341, ptr %l23, !tbaa !27
  %t343 = load ptr, ptr %l3, !tbaa !29
  %t345 = getelementptr %"compiler/prompt:cell", ptr %t343, i32 0, i32 4
  %t346 = load i1, ptr %t345, !tbaa !21
  br i1 %t346, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_10924d50905b82ca_4ba1203e047902e)
  unreachable
bb79:
  %t348 = load i64, ptr %l21, !tbaa !24
  %t349 = load i64, ptr %l18, !tbaa !24
  %t352 = icmp eq i64 %t348, %t349
  store i1 %t352, ptr %l156, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb81
bb81:
  %t354 = load i1, ptr %l156, !tbaa !21
  br i1 %t354, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s26
  %t355 = load ptr, ptr %lp5
  %t356 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t357 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s26, ptr %t357, ptr %t355, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } %t356, i64 0)
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_scope_close(ptr %s26)
  br label %bb85
bb85:
  %t360 = load ptr, ptr %lp5
  %t361 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t362 = load ptr, ptr %l3, !tbaa !29
  %t364 = getelementptr %"compiler/prompt:cell", ptr %t362, i32 0, i32 0
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  %t366 = getelementptr %"compiler/prompt:item", ptr %l22, i32 0, i32 2
  %t367 = load i64, ptr %t366, !tbaa !24
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %v3, ptr %v3, ptr %t360, { i64, ptr } %t361, { i64, ptr } %t365, i64 %t367)
  br label %bb86
bb86:
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t374 = getelementptr %"compiler/prompt:cell", ptr %t372, i32 0, i32 4
  %t375 = load i1, ptr %t374, !tbaa !21
  br i1 %t375, label %bb87, label %bb88
bb87:
  %t377 = load i64, ptr %l21, !tbaa !24
  %t378 = load i64, ptr %l18, !tbaa !24
  %t381 = icmp eq i64 %t377, %t378
  store i1 %t381, ptr %l169, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb89
bb89:
  %t383 = load i1, ptr %l169, !tbaa !21
  br i1 %t383, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s27
  %t384 = load ptr, ptr %lp5
  %t385 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eShownName, !tbaa !27
  %t386 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eRichName, !tbaa !27
  %t387 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t390 = extractvalue { i64, ptr } %t385, 1
  %t391 = extractvalue { i64, ptr } %t385, 0
  %t392 = add i64 %t388, %t391
  %t393 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t395 = add i64 %t392, %t394
  %t397 = extractvalue { i64, ptr } %t386, 1
  %t398 = extractvalue { i64, ptr } %t386, 0
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t402 = add i64 %t399, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t387, i64 %t388)
  %t404 = getelementptr i8, ptr %t403, i64 %t388
  call void @olang_textcopy(ptr %t404, ptr %t390, i64 %t391)
  %t405 = getelementptr i8, ptr %t404, i64 %t391
  call void @olang_textcopy(ptr %t405, ptr %t393, i64 %t394)
  %t406 = getelementptr i8, ptr %t405, i64 %t394
  call void @olang_textcopy(ptr %t406, ptr %t397, i64 %t398)
  %t407 = getelementptr i8, ptr %t406, i64 %t398
  call void @olang_textcopy(ptr %t407, ptr %t400, i64 %t401)
  %t408 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t403, 1
  %t411 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t412 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s27, ptr %t412, ptr %t384, { i64, ptr } %t409, { i64, ptr } %t411, i64 0)
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s27)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t416 = load i64, ptr %l20, !tbaa !24
  %t419 = add i64 %t416, 1
  store i64 %t419, ptr %l20, !tbaa !24
  br label %bb64
bb95:
  %t421 = load i1, ptr %l4, !tbaa !21
  br i1 %t421, label %bb96, label %bb97
bb96:
  %t423 = load ptr, ptr %l3, !tbaa !29
  %t425 = getelementptr %"compiler/prompt:cell", ptr %t423, i32 0, i32 3
  store ptr %t425, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb98
bb97:
  br label %bb111
bb98:
  store %olang.scope zeroinitializer, ptr %s32
  %t427 = load i64, ptr %l25, !tbaa !24
  store i64 %t427, ptr %l185, !tbaa !24
  %t428 = load ptr, ptr %l24, !tbaa !29
  %t430 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %t428)
  store i64 %t430, ptr %l187
  br label %bb99
bb99:
  %t431 = load i64, ptr %l185, !tbaa !24
  %t432 = load i64, ptr %l187, !tbaa !24
  %t433 = icmp slt i64 %t431, %t432
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s32)
  br label %bb110
bb101:
  br label %bb102
bb102:
  %t437 = load ptr, ptr %l24, !tbaa !29
  %t438 = load i64, ptr %l25, !tbaa !24
  %t441 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v3, ptr %v3, ptr %t437, i64 %t438)
  store %"compiler/prompt:Value" %t441, ptr %l192
  br label %bb103
bb103:
  %t442 = load %"compiler/prompt:Value", ptr %l192
  store %"compiler/prompt:Value" %t442, ptr %l26
  %t443 = load ptr, ptr %lp5
  store ptr %t443, ptr %l193, !tbaa !29
  %t444 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eKeepPrefix, !tbaa !27
  store { i64, ptr } %t444, ptr %l194, !tbaa !27
  %t445 = getelementptr %"compiler/prompt:Value", ptr %l26, i32 0, i32 0
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  store { i64, ptr } %t446, ptr %l195, !tbaa !27
  %t447 = getelementptr %"compiler/prompt:Value", ptr %l26, i32 0, i32 1
  %t448 = load { i64, ptr }, ptr %t447, !tbaa !27
  %t450 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v3, ptr %s32, { i64, ptr } %t448, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i1 %t450, ptr %l197
  br label %bb104
bb104:
  %t451 = load i1, ptr %l197, !tbaa !21
  br i1 %t451, label %bb105, label %bb106
bb105:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, ptr %l198, !tbaa !27
  br label %bb107
bb106:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l198, !tbaa !27
  br label %bb107
bb107:
  %t452 = getelementptr %"compiler/prompt:Value", ptr %l26, i32 0, i32 0
  %t453 = load { i64, ptr }, ptr %t452, !tbaa !27
  %t454 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 1
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t460 = add i64 %t456, %t459
  %t461 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = add i64 %t460, %t463
  %t466 = extractvalue { i64, ptr } %t453, 1
  %t467 = extractvalue { i64, ptr } %t453, 0
  %t468 = add i64 %t464, %t467
  %t469 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t468)
  call void @olang_textcopy(ptr %t469, ptr %t455, i64 %t456)
  %t470 = getelementptr i8, ptr %t469, i64 %t456
  call void @olang_textcopy(ptr %t470, ptr %t458, i64 %t459)
  %t471 = getelementptr i8, ptr %t470, i64 %t459
  call void @olang_textcopy(ptr %t471, ptr %t462, i64 %t463)
  %t472 = getelementptr i8, ptr %t471, i64 %t463
  call void @olang_textcopy(ptr %t472, ptr %t466, i64 %t467)
  %t473 = insertvalue { i64, ptr } undef, i64 %t468, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t469, 1
  %t476 = load ptr, ptr %l3, !tbaa !29
  %t478 = getelementptr %"compiler/prompt:cell", ptr %t476, i32 0, i32 0
  %t479 = load { i64, ptr }, ptr %t478, !tbaa !27
  %t480 = getelementptr %"compiler/prompt:Value", ptr %l26, i32 0, i32 3
  %t481 = load i64, ptr %t480, !tbaa !24
  %t482 = load ptr, ptr %l193, !tbaa !29
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s32, ptr %v3, ptr %t482, { i64, ptr } %t474, { i64, ptr } %t479, i64 %t481)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s32)
  br label %bb109
bb109:
  %t486 = load i64, ptr %l25, !tbaa !24
  %t489 = add i64 %t486, 1
  store i64 %t489, ptr %l25, !tbaa !24
  br label %bb98
bb110:
  br label %bb111
bb111:
  %t491 = load ptr, ptr %l3, !tbaa !29
  %t493 = getelementptr %"compiler/prompt:cell", ptr %t491, i32 0, i32 4
  %t494 = load i1, ptr %t493, !tbaa !21
  br i1 %t494, label %bb112, label %bb113
bb112:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/prompt:Session", ptr %t496, i32 0, i32 7
  %t499 = load i1, ptr %t498, !tbaa !21
  %t501 = xor i1 %t499, true
  store i1 %t501, ptr %l210, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb114
bb114:
  %t503 = load i1, ptr %l210, !tbaa !21
  br i1 %t503, label %bb115, label %bb116
bb115:
  %t504 = load ptr, ptr %lp5
  %t505 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSayShown, !tbaa !27
  %t506 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t507 = load ptr, ptr @__olang_prog_scope
  %t508 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %t507, ptr %t508, ptr %t504, { i64, ptr } %t505, { i64, ptr } %t506, i64 0)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t512 = load ptr, ptr %lp5
  %t513 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t514 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %s0, ptr %t514, ptr %t512, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, { i64, ptr } %t513, i64 0)
  br label %bb119
bb119:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t519 = getelementptr %"compiler/prompt:Session", ptr %t517, i32 0, i32 7
  %t520 = load i1, ptr %t519, !tbaa !21
  %t522 = xor i1 %t520, true
  br i1 %t522, label %bb120, label %bb121
bb120:
  %t524 = load ptr, ptr %lp5
  %t525 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eCellEntry, !tbaa !27
  %t526 = load { i64, ptr }, ptr @G_2ecompiler_2fprompt_2eSynthetic, !tbaa !27
  %t527 = load ptr, ptr @__olang_prog_scope
  %t528 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v4, ptr %t527, ptr %t528, ptr %t524, { i64, ptr } %t525, { i64, ptr } %t526, i64 0)
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb123
bb123:
  %t532 = load ptr, ptr %lp5
  %t533 = load %"compiler/prompt:program", ptr %t532
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/prompt:program" %t533, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:program", ptr %rv
  ret %"compiler/prompt:program" %rr
}

define dso_local void @compiler_2fprompt_2ecompiler_2fprompt_3aprogram_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i1
  %l31 = alloca { i64, ptr }
  %l47 = alloca i64
  %l50 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/prompt:program", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/prompt:program", ptr %t7, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t9, i8 10)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l23, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp slt i64 %t19, 2147483648
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  %t25 = and i1 %t20, %t22
  store i1 %t25, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb4, label %bb5
bb4:
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t34, ptr %l31, !tbaa !27
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t44 = icmp eq i8 %t40, 10
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l6, !tbaa !24
  br label %bb3
bb11:
  store i64 0, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb12, label %bb13
bb12:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb17
bb14:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l50, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb16
bb16:
  %t86 = load i64, ptr %l50, !tbaa !24
  store i64 %t86, ptr %l47, !tbaa !24
  br label %bb17
bb17:
  %t87 = load i64, ptr %l47, !tbaa !24
  store i64 %t87, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  br label %bb25
bb20:
  br label %bb21
bb21:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l14, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/prompt:program", ptr %t106, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v2, ptr %t108, { i64, ptr } %a2)
  br label %bb22
bb22:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/prompt:program", ptr %t112, i32 0, i32 2
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = add i64 %a3, %t116
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t114, i64 %t119)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l13, !tbaa !24
  br label %bb18
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprompt_2edeclKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i1
  %l57 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l89 = alloca i1
  %l94 = alloca i1
  %l95 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load i64, ptr %l4, !tbaa !24
  %t6 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/token:Token", ptr %t7, i64 %t4
  %t9 = getelementptr %"compiler/token:Token", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 116}
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/token:Token", ptr %t20, i64 %t17
  %t22 = load %"compiler/token:Token", ptr %t21
  %t25 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %s0, { i64, ptr } %t15, %"compiler/token:Token" %t22)
  store { i64, ptr } %t25, ptr %l16
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d114, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb4
bb4:
  %t29 = load i1, ptr %l18, !tbaa !21
  store i1 %t29, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t30 = load i1, ptr %l11, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l27, !tbaa !24
  %t45 = load i64, ptr %l27, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l27, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t56, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l29, !tbaa !27
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/token:Token", ptr %t62, i64 %t59
  %t64 = getelementptr %"compiler/token:Token", ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 116}
  store i32 %t65, ptr %l5
  %t67 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t69 = trunc i64 33 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = add i64 %t72, 1
  %t75 = load i64, ptr %l3, !tbaa !24
  %t78 = icmp sle i64 %t74, %t75
  store i1 %t78, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t80 = load i1, ptr %l34, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t82, ptr %l40, !tbaa !27
  %t83 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t83, 1
  %t87 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr %"compiler/token:Token", ptr %t88, i64 %t85
  %t90 = load %"compiler/token:Token", ptr %t89
  %t93 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %v2, { i64, ptr } %t81, %"compiler/token:Token" %t90)
  store { i64, ptr } %t93, ptr %l44
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t94, ptr %rv
  br label %ret
bb18:
  %t95 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t97 = trunc i64 37 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb19, label %bb20
bb19:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = add i64 %t100, 1
  %t103 = load i64, ptr %l3, !tbaa !24
  %t106 = icmp sle i64 %t102, %t103
  store i1 %t106, ptr %l47, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t108 = load i1, ptr %l47, !tbaa !21
  br i1 %t108, label %bb22, label %bb23
bb22:
  %t109 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = add i64 %t111, 1
  %t114 = load i64, ptr %l3, !tbaa !24
  %t119 = call { i64, ptr } @compiler_2fprompt_2efnKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t109, { i64, ptr } %t110, i64 %t113, i64 %t114)
  store { i64, ptr } %t119, ptr %l57
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
bb25:
  %t121 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t123 = trunc i64 40 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t126 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t128 = load i64, ptr %l4, !tbaa !24
  %t130 = add i64 %t128, 1
  %t131 = load i64, ptr %l3, !tbaa !24
  %t136 = call { i64, ptr } @compiler_2fprompt_2eimportName(ptr %v0, ptr %v1, ptr %s5, { i64, ptr } %t126, { i64, ptr } %t127, i64 %t130, i64 %t131)
  store { i64, ptr } %t136, ptr %l65
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t137 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t139 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t137, i64 %t138)
  %t144 = getelementptr i8, ptr %t143, i64 %t138
  call void @olang_textcopy(ptr %t144, ptr %t140, i64 %t141)
  %t145 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t143, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t146, ptr %rv
  br label %ret
bb29:
  %t148 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t150 = trunc i64 43 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb32
bb31:
  %t153 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t155 = trunc i64 41 to i32
  %t156 = icmp eq i32 %t153, %t155
  store i1 %t156, ptr %l69, !tbaa !21
  br label %bb32
bb32:
  %t158 = load i1, ptr %l69, !tbaa !21
  br i1 %t158, label %bb33, label %bb34
bb33:
  %t159 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t159, ptr %l72, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t160, ptr %l73, !tbaa !27
  %t161 = load i64, ptr %l2, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr %"compiler/token:Token", ptr %t164, i64 %t161
  %t166 = getelementptr %"compiler/token:Token", ptr %t165, i32 0, i32 2
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  store i64 %t169, ptr %l76, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t170, ptr %l77, !tbaa !27
  %t171 = load i64, ptr %l3, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr %"compiler/token:Token", ptr %t174, i64 %t171
  %t176 = getelementptr %"compiler/token:Token", ptr %t175, i32 0, i32 3
  %t177 = load i32, ptr %t176, !tbaa !23
  %t179 = sext i32 %t177 to i64
  store i64 %t179, ptr %l80, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l81, !tbaa !24
  %t182 = load i64, ptr %l76, !tbaa !24
  %t183 = icmp sge i64 %t182, 0
  br i1 %t183, label %bb35, label %bb36
bb34:
  br label %bb41
bb35:
  %t185 = load i64, ptr %l76, !tbaa !24
  %t186 = load i64, ptr %l80, !tbaa !24
  %t187 = icmp sle i64 %t185, %t186
  br i1 %t187, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d7f38a87e2333c97_c2add44d049df38b)
  unreachable
bb37:
  %t189 = load i64, ptr %l80, !tbaa !24
  %t190 = load i64, ptr %l81, !tbaa !24
  %t191 = icmp sle i64 %t189, %t190
  br i1 %t191, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d7f38a87e2333c97_c2add44d049df38b)
  unreachable
bb39:
  %t193 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = load i64, ptr %l76, !tbaa !24
  %t196 = load i64, ptr %l80, !tbaa !24
  %t197 = getelementptr i8, ptr %t194, i64 %t195
  %t198 = sub i64 %t196, %t195
  %t199 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  %t201 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t204 = extractvalue { i64, ptr } %t200, 1
  %t205 = extractvalue { i64, ptr } %t200, 0
  %t206 = add i64 %t202, %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t201, i64 %t202)
  %t208 = getelementptr i8, ptr %t207, i64 %t202
  call void @olang_textcopy(ptr %t208, ptr %t204, i64 %t205)
  %t209 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t207, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_d7f38a87e2333c97_c2add44d049df38b)
  unreachable
bb41:
  %t212 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t214 = trunc i64 1 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb42, label %bb43
bb42:
  %t217 = load i64, ptr %l4, !tbaa !24
  %t219 = add i64 %t217, 1
  %t220 = load i64, ptr %l3, !tbaa !24
  %t223 = icmp sle i64 %t219, %t220
  store i1 %t223, ptr %l89, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb44
bb44:
  %t225 = load i1, ptr %l89, !tbaa !21
  br i1 %t225, label %bb45, label %bb46
bb45:
  %t226 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t226, ptr %l95, !tbaa !27
  %t227 = load i64, ptr %l4, !tbaa !24
  %t229 = add i64 %t227, 1
  %t231 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr %"compiler/token:Token", ptr %t232, i64 %t229
  %t234 = getelementptr %"compiler/token:Token", ptr %t233, i32 0, i32 0
  %t235 = load i32, ptr %t234, !range !{i32 0, i32 116}
  %t237 = trunc i64 39 to i32
  %t238 = icmp eq i32 %t235, %t237
  store i1 %t238, ptr %l94, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb47
bb47:
  %t240 = load i1, ptr %l94, !tbaa !21
  br i1 %t240, label %bb48, label %bb49
bb48:
  %t241 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t242, ptr %l101, !tbaa !27
  %t243 = load i64, ptr %l4, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr %"compiler/token:Token", ptr %t246, i64 %t243
  %t248 = load %"compiler/token:Token", ptr %t247
  %t251 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %v2, { i64, ptr } %t241, %"compiler/token:Token" %t248)
  store { i64, ptr } %t251, ptr %l104
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t252 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t252, ptr %rv
  br label %ret
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t253, ptr %l106, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l107, !tbaa !24
  %t256 = load i64, ptr %l107, !tbaa !24
  %t257 = mul i64 %t256, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t257)
  %t259 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l108, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l107, !tbaa !24
  %t266 = mul i64 %t265, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %t264, i64 %t266, i1 false)
  %t267 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t267, ptr %l106, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t268 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t268, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fprompt_2eerrorRows(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l5
  store %"std/prelude/text:LineIter" %t4, ptr %l2
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l2)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l9
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l8
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l9, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb6:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t19, ptr %l13
  br label %bb7
bb7:
  %t20 = load i1, ptr %l13, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t27 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } %t26)
  store i1 %t27, ptr %l19
  br label %bb10
bb9:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  %t28 = load i1, ptr %l19, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %l1, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb2
bb16:
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fprompt_2eflushRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i1
  %s0 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v3, ptr %v1, ptr %t7, { i64, ptr } %t5)
  store i1 %t11, ptr %l12
  br label %bb4
bb4:
  %t12 = load i1, ptr %l12, !tbaa !21
  store i1 %t12, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v3, ptr %v1, ptr %t14, { i64, ptr } %t15, i1 true)
  br label %bb9
bb9:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t19, i8 10)
  %t23 = extractvalue { i32, i64 } %t22, 1
  %t24 = extractvalue { i32, i64 } %t22, 0
  store i32 %t24, ptr %l20
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb11, label %ok.26, !prof !99
ok.26:
  store i64 %t23, ptr %l19
  br label %bb10
bb10:
  %t27 = load i64, ptr %l19, !tbaa !24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l16, !tbaa !24
  br label %bb13
bb13:
  %t32 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t36 = load i64, ptr %l16, !tbaa !24
  %t37 = icmp sle i64 0, %t36
  br i1 %t37, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7f01f42c2e703e66_b0b354f2667b155a)
  unreachable
bb16:
  %t39 = load i64, ptr %l16, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t41 = icmp sle i64 %t39, %t40
  br i1 %t41, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7f01f42c2e703e66_b0b354f2667b155a)
  unreachable
bb18:
  %t43 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l16, !tbaa !24
  %t46 = getelementptr i8, ptr %t44, i64 0
  %t47 = sub i64 %t45, 0
  %t48 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d122, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t55 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t51, { i64, ptr } %t54)
  store i1 %t55, ptr %l31
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7f01f42c2e703e66_b0b354f2667b155a)
  unreachable
bb20:
  %t56 = load i1, ptr %l31, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb21:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t60 = extractvalue { i64, ptr } %a2, 1
  %t61 = extractvalue { i64, ptr } %a2, 0
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = getelementptr i8, ptr %t65, i64 %t61
  call void @olang_textcopy(ptr %t66, ptr %t62, i64 %t63)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t57, { i64, ptr } %t68)
  store i1 %t72, ptr %l37
  br label %bb23
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb28
bb23:
  %t73 = load i1, ptr %l37, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb27
bb25:
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d124, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t80 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t76, { i64, ptr } %t79)
  store i1 %t80, ptr %l43
  br label %bb26
bb26:
  %t81 = load i1, ptr %l43, !tbaa !21
  store i1 %t81, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l39, !tbaa !21
  store i1 %t82, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t83 = load i1, ptr %l32, !tbaa !21
  br i1 %t83, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  br label %bb31
bb31:
  %t85 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t85)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprompt_2efnKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l49 = alloca i64
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l79 = alloca i1
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr %"compiler/token:Token", ptr %t5, i64 %t2
  %t7 = getelementptr %"compiler/token:Token", ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 116}
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = add i64 %t13, 2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sle i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr %"compiler/token:Token", ptr %t27, i64 %t24
  %t29 = getelementptr %"compiler/token:Token", ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 116}
  %t32 = trunc i64 76 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t35 = load i1, ptr %l14, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/token:Token", ptr %t41, i64 %t38
  %t43 = load %"compiler/token:Token", ptr %t42
  %t46 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %s2, { i64, ptr } %t36, %"compiler/token:Token" %t43)
  store { i64, ptr } %t46, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t49, 2
  %t53 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/token:Token", ptr %t54, i64 %t51
  %t56 = load %"compiler/token:Token", ptr %t55
  %t59 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %s2, { i64, ptr } %t47, %"compiler/token:Token" %t56)
  store { i64, ptr } %t59, ptr %l30
  br label %bb9
bb9:
  %t60 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t61, i64 %t62)
  %t71 = getelementptr i8, ptr %t70, i64 %t62
  call void @olang_textcopy(ptr %t71, ptr %t63, i64 %t64)
  %t72 = getelementptr i8, ptr %t71, i64 %t64
  call void @olang_textcopy(ptr %t72, ptr %t67, i64 %t68)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t70, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb10:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t77, ptr %l33, !tbaa !27
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"compiler/token:Token", ptr %t81, i64 %t78
  %t83 = load %"compiler/token:Token", ptr %t82
  %t86 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %v2, { i64, ptr } %t76, %"compiler/token:Token" %t83)
  store { i64, ptr } %t86, ptr %l36
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t87, ptr %rv
  br label %ret
bb12:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = load i64, ptr %l2, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr %"compiler/token:Token", ptr %t92, i64 %t89
  %t94 = getelementptr %"compiler/token:Token", ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94, !range !{i32 0, i32 116}
  %t97 = trunc i64 110 to i32
  %t98 = icmp eq i32 %t95, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t102, ptr %l43, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l44, !tbaa !24
  %t105 = load i64, ptr %l44, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l45, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l44, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t116, ptr %l43, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t119 = load i64, ptr %l2, !tbaa !24
  %t120 = load i64, ptr %l3, !tbaa !24
  %t124 = call i64 @compiler_2fprompt_2ematching(ptr %v1, { i64, ptr } %t118, i64 %t119, i64 %t120)
  store i64 %t124, ptr %l49
  br label %bb16
bb16:
  %t125 = load i64, ptr %l49, !tbaa !24
  store i64 %t125, ptr %l4, !tbaa !24
  %t126 = load i64, ptr %l2, !tbaa !24
  %t128 = add i64 %t126, 2
  store i64 %t128, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l5, !tbaa !24
  %t131 = load i64, ptr %l3, !tbaa !24
  %t134 = icmp sle i64 %t130, %t131
  br i1 %t134, label %bb17, label %bb18
bb17:
  %t136 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t136, ptr %l56, !tbaa !27
  %t137 = load i64, ptr %l5, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr %"compiler/token:Token", ptr %t140, i64 %t137
  %t142 = getelementptr %"compiler/token:Token", ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142, !range !{i32 0, i32 116}
  %t145 = trunc i64 39 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l55, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb19
bb19:
  %t148 = load i1, ptr %l55, !tbaa !21
  br i1 %t148, label %bb20, label %bb21
bb20:
  %t149 = load i64, ptr %l5, !tbaa !24
  %t152 = add i64 %t149, 1
  store i64 %t152, ptr %l5, !tbaa !24
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t154 = load i64, ptr %l5, !tbaa !24
  %t156 = add i64 %t154, 2
  %t157 = load i64, ptr %l3, !tbaa !24
  %t160 = icmp sle i64 %t156, %t157
  br i1 %t160, label %bb23, label %bb24
bb23:
  %t162 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t162, ptr %l68, !tbaa !27
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t163, 1
  %t167 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr %"compiler/token:Token", ptr %t168, i64 %t165
  %t170 = getelementptr %"compiler/token:Token", ptr %t169, i32 0, i32 0
  %t171 = load i32, ptr %t170, !range !{i32 0, i32 116}
  %t173 = trunc i64 76 to i32
  %t174 = icmp eq i32 %t171, %t173
  store i1 %t174, ptr %l67, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb25
bb25:
  %t176 = load i1, ptr %l67, !tbaa !21
  br i1 %t176, label %bb26, label %bb27
bb26:
  %t177 = load i64, ptr %l5, !tbaa !24
  %t180 = add i64 %t177, 2
  store i64 %t180, ptr %l5, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t182 = load i64, ptr %l5, !tbaa !24
  %t183 = load i64, ptr %l3, !tbaa !24
  %t186 = icmp sgt i64 %t182, %t183
  br i1 %t186, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb30:
  %t188 = load i64, ptr %l4, !tbaa !24
  %t190 = add i64 %t188, 1
  %t191 = load i64, ptr %l3, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  store i1 %t194, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t196 = load i1, ptr %l79, !tbaa !21
  br i1 %t196, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l84, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t197, ptr %l85, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l86, !tbaa !24
  %t200 = load i64, ptr %l86, !tbaa !24
  %t201 = mul i64 %t200, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t201)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l87, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l86, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t211, ptr %l85, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t212 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t213 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t214, ptr %l89, !tbaa !27
  %t215 = load i64, ptr %l5, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr %"compiler/token:Token", ptr %t218, i64 %t215
  %t220 = load %"compiler/token:Token", ptr %t219
  %t223 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %s0, { i64, ptr } %t213, %"compiler/token:Token" %t220)
  store { i64, ptr } %t223, ptr %l92
  br label %bb35
bb35:
  %t224 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t225, ptr %l94, !tbaa !27
  %t226 = load i64, ptr %l4, !tbaa !24
  %t228 = add i64 %t226, 1
  %t230 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr %"compiler/token:Token", ptr %t231, i64 %t228
  %t233 = load %"compiler/token:Token", ptr %t232
  %t236 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %s0, { i64, ptr } %t224, %"compiler/token:Token" %t233)
  store { i64, ptr } %t236, ptr %l98
  br label %bb36
bb36:
  %t237 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t242 = add i64 %t239, %t241
  %t243 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = add i64 %t242, %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t238, i64 %t239)
  %t248 = getelementptr i8, ptr %t247, i64 %t239
  call void @olang_textcopy(ptr %t248, ptr %t240, i64 %t241)
  %t249 = getelementptr i8, ptr %t248, i64 %t241
  call void @olang_textcopy(ptr %t249, ptr %t244, i64 %t245)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t247, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t251, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2efreshGlobals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/prompt:Value"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/prompt:Decl"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/prompt:Value"
  %l22 = alloca i1
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/prompt:Decl"
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load i64, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/prompt:Value" %t19, ptr %l20
  br label %bb7
bb7:
  %t20 = load %"compiler/prompt:Value", ptr %l20
  store %"compiler/prompt:Value" %t20, ptr %l5
  %t21 = getelementptr %"compiler/prompt:Value", ptr %l5, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t24, ptr %l22
  br label %bb8
bb8:
  %t25 = load i1, ptr %l22, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = getelementptr %"compiler/prompt:Value", ptr %l5, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %v1, ptr %l2, { i64, ptr } %t29, i1 true)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l29
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l6
  store ptr %a0, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t41 = load i64, ptr %l8, !tbaa !24
  store i64 %t41, ptr %l31, !tbaa !24
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l33
  br label %bb17
bb17:
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l33, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = call %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/prompt:Decl" %t55, ptr %l38
  br label %bb21
bb21:
  %t56 = load %"compiler/prompt:Decl", ptr %l38
  store %"compiler/prompt:Decl" %t56, ptr %l9
  %t58 = call i1 @compiler_2fprompt_2eisGlobal(ptr %s6, ptr %l9)
  store i1 %t58, ptr %l40
  br label %bb22
bb22:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = getelementptr %"compiler/prompt:Decl", ptr %l9, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t66 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t61)
  store i1 %t66, ptr %l45
  br label %bb25
bb24:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb26
bb25:
  %t67 = load i1, ptr %l45, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l41, !tbaa !21
  br label %bb26
bb26:
  %t70 = load i1, ptr %l41, !tbaa !21
  br i1 %t70, label %bb27, label %bb28
bb27:
  %t71 = getelementptr %"compiler/prompt:Decl", ptr %l9, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v0, ptr %l6, { i64, ptr } %t72)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb16
bb32:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fprompt_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l10 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = call ptr @__olang_scope_hold(ptr %v0)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call ptr @__olang_region_make(ptr %v0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/prompt:Reply", ptr %t8, i32 0, i32 4
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a1, 1
  %t21 = extractvalue { i64, ptr } %a1, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = load i64, ptr %l3
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_held_alloc(ptr %t27, i64 %t25)
  call void @olang_textcopy(ptr %t28, ptr %t14, i64 %t15)
  %t29 = getelementptr i8, ptr %t28, i64 %t15
  call void @olang_textcopy(ptr %t29, ptr %t16, i64 %t17)
  %t30 = getelementptr i8, ptr %t29, i64 %t17
  call void @olang_textcopy(ptr %t30, ptr %t20, i64 %t21)
  %t31 = getelementptr i8, ptr %t30, i64 %t21
  call void @olang_textcopy(ptr %t31, ptr %t23, i64 %t24)
  %t32 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t28, 1
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/prompt:Reply", ptr %t35, i32 0, i32 4
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l10, !tbaa !27
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/prompt:Reply", ptr %t39, i32 0, i32 4
  store { i64, ptr } %t33, ptr %t40, !tbaa !27
  %t41 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aReply_2e4
  br i1 %t41, label %bb3, label %bb4
bb3:
  %t43 = load { i64, ptr }, ptr %l10
  %t44 = extractvalue { i64, ptr } %t43, 1
  call void @__olang_region_release(ptr %t44)
  store { i64, ptr } zeroinitializer, ptr %l10
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprompt_2eglobal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { %"compiler/eval:Ptr", i32 }
  %l6 = alloca { %"compiler/eval:Ptr", i32 }
  %l8 = alloca ptr
  %l12 = alloca i64
  %l18 = alloca i32
  %l19 = alloca { %"compiler/eval:Ptr", i32 }
  %l20 = alloca i32
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/interp:Exec", ptr %t1, i32 0, i32 4
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 12
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Loader", ptr %t20, i32 0, i32 3
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t27 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %t23, { i64, ptr } %a2)
  store i32 %t27, ptr %l18
  br label %bb1
bb1:
  %t28 = load ptr, ptr %l8, !tbaa !29
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i32, ptr %l18, !tbaa !23
  %t31 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %t28, i64 %t29, i32 %t30)
  %t32 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t31, 1
  %t33 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t31, 0
  store i32 %t33, ptr %l20
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb3, label %ok.35, !prof !99
ok.35:
  store { %"compiler/eval:Ptr", i32 } %t32, ptr %l19
  br label %bb2
bb2:
  %t36 = load { %"compiler/eval:Ptr", i32 }, ptr %l19
  store { %"compiler/eval:Ptr", i32 } %t36, ptr %l6
  br label %bb5
bb3:
  %t37 = load i32, ptr %l20, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  store i1 %t40, ptr %l22, !tbaa !21
  br label %bb4
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t55, ptr %l24, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb5:
  %t57 = load { %"compiler/eval:Ptr", i32 }, ptr %l6
  store { %"compiler/eval:Ptr", i32 } %t57, ptr %l3
  %t58 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l3, i32 0, i32 0
  %t59 = load %"compiler/eval:Ptr", ptr %t58
  %t61 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l3, i32 0, i32 1
  %t62 = load i32, ptr %t61, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/interp:Exec", ptr %t64, i32 0, i32 4
  %t72 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v3, ptr %t66, %"compiler/eval:Ptr" %t59, i32 %t62)
  store { i64, ptr } %t72, ptr %l33
  br label %bb6
bb6:
  %t73 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2eimportName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l63 = alloca i64
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i32
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %a3
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t7, ptr %l11, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l12, !tbaa !24
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l14, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr %"compiler/token:Token", ptr %t27, i64 %t24
  %t29 = getelementptr %"compiler/token:Token", ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 116}
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l19, !tbaa !27
  %t37 = load i64, ptr %l2, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/token:Token", ptr %t40, i64 %t37
  %t42 = load %"compiler/token:Token", ptr %t41
  %t45 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %v2, { i64, ptr } %t35, %"compiler/token:Token" %t42)
  store { i64, ptr } %t45, ptr %l22
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb7:
  %t47 = call ptr @__olang_scope_hold(ptr %v2)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l23, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t51 = call ptr @__olang_region_make(ptr %v2)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t54, ptr %l26, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/token:Token", ptr %t58, i64 %t55
  %t60 = load %"compiler/token:Token", ptr %t59
  %t61 = load i64, ptr %l23
  %t62 = inttoptr i64 %t61 to ptr
  %t65 = call { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %t62, { i64, ptr } %t53, %"compiler/token:Token" %t60)
  store { i64, ptr } %t65, ptr %l29
  br label %bb10
bb10:
  %t66 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb13, label %bb14
bb12:
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t73, ptr %lp4
  %t74 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t75 = load ptr, ptr %lp4
  store { i64, ptr } %t74, ptr %t75, !tbaa !27
  %t76 = call ptr @__olang_scope_hold(ptr %v2)
  %t77 = ptrtoint ptr %t76 to i64
  store i64 %t77, ptr %l33, !tbaa !24
  %t78 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t78, label %bb15, label %bb16
bb13:
  store { i64, ptr } zeroinitializer, ptr %l29, !tbaa !27
  br label %bb14
bb14:
  %t80 = load i64, ptr %l23
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = load { i64, ptr }, ptr %l29
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = call ptr @__olang_region_or(ptr %t83, ptr null)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr null
  call void @__olang_region_settle_in(ptr %t81, ptr %t86)
  br label %bb12
bb15:
  %t87 = call ptr @__olang_region_make(ptr %v2)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t89 = load ptr, ptr %lp4
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t94 = icmp sge i64 %t92, 2
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = call ptr @__olang_scope_hold(ptr %v2)
  %t97 = ptrtoint ptr %t96 to i64
  store i64 %t97, ptr %l39, !tbaa !24
  %t98 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t98, label %bb19, label %bb20
bb18:
  %t100 = load ptr, ptr %lp4
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l38, !tbaa !27
  br label %bb31
bb19:
  %t103 = call ptr @__olang_region_make(ptr %v2)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l39, !tbaa !24
  br label %bb20
bb20:
  %t105 = load ptr, ptr %lp4
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t110 = sub i64 %t108, 1
  store i64 %t110, ptr %l43, !tbaa !24
  %t111 = load ptr, ptr %lp4
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l44, !tbaa !24
  %t114 = icmp sge i64 1, 0
  br i1 %t114, label %bb21, label %bb22
bb21:
  %t116 = load i64, ptr %l43, !tbaa !24
  %t117 = icmp sle i64 1, %t116
  br i1 %t117, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a2264893ec9e865a_32f4c01046e050a6)
  unreachable
bb23:
  %t119 = load i64, ptr %l43, !tbaa !24
  %t120 = load i64, ptr %l44, !tbaa !24
  %t121 = icmp sle i64 %t119, %t120
  br i1 %t121, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a2264893ec9e865a_32f4c01046e050a6)
  unreachable
bb25:
  %t123 = load ptr, ptr %lp4
  %t124 = getelementptr { i64, ptr }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l43, !tbaa !24
  %t127 = getelementptr i8, ptr %t125, i64 1
  %t128 = sub i64 %t126, 1
  %t129 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = extractvalue { i64, ptr } %t130, 0
  %t134 = load i64, ptr %l39
  %t135 = inttoptr i64 %t134 to ptr
  %t136 = call ptr @__olang_held_alloc(ptr %t135, i64 %t133)
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l49, !tbaa !27
  %t139 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t139, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_a2264893ec9e865a_32f4c01046e050a6)
  unreachable
bb27:
  %t141 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t144 = icmp eq i64 %t142, 0
  br i1 %t144, label %bb29, label %bb30
bb28:
  %t146 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t146, ptr %l38, !tbaa !27
  br label %bb31
bb29:
  store { i64, ptr } zeroinitializer, ptr %l49, !tbaa !27
  br label %bb30
bb30:
  %t147 = load i64, ptr %l39
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l49
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  br label %bb28
bb31:
  %t154 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l54, !tbaa !24
  %t156 = load i64, ptr %l54, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = load i64, ptr %l33
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call ptr @__olang_held_alloc(ptr %t159, i64 %t157)
  %t161 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l55, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = load i64, ptr %l54, !tbaa !24
  %t168 = mul i64 %t167, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t164, ptr %t166, i64 %t168, i1 false)
  %t169 = load ptr, ptr %lp4
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l56, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t172 = load ptr, ptr %lp4
  store { i64, ptr } %t171, ptr %t172, !tbaa !27
  %t173 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t173, label %bb32, label %bb33
bb32:
  %t175 = load { i64, ptr }, ptr %l56
  %t176 = extractvalue { i64, ptr } %t175, 1
  call void @__olang_region_release(ptr %t176)
  store { i64, ptr } zeroinitializer, ptr %l56
  br label %bb33
bb33:
  %t177 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t177, label %bb34, label %bb35
bb34:
  %t179 = load ptr, ptr %lp4
  %t180 = load i64, ptr %l33
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = load { i64, ptr }, ptr %t179
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = call ptr @__olang_region_or(ptr %t183, ptr null)
  %t185 = icmp ne ptr %t184, null
  %t186 = select i1 %t185, ptr %t184, ptr null
  call void @__olang_region_settle_in(ptr %t181, ptr %t186)
  br label %bb35
bb35:
  %t187 = load ptr, ptr %lp4
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t190 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v2, ptr %s0, { i64, ptr } %t188, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) })
  %t191 = extractvalue { i32, i64 } %t190, 1
  %t192 = extractvalue { i32, i64 } %t190, 0
  store i32 %t192, ptr %l62
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb37, label %ok.194, !prof !99
ok.194:
  store i64 %t191, ptr %l61
  br label %bb36
bb36:
  %t195 = load i64, ptr %l61, !tbaa !24
  store i64 %t195, ptr %l59, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  store i64 -1, ptr %l59, !tbaa !24
  br label %bb39
bb39:
  %t196 = load i64, ptr %l59, !tbaa !24
  store i64 %t196, ptr %l5, !tbaa !24
  %t197 = call ptr @__olang_scope_hold(ptr %v2)
  %t198 = ptrtoint ptr %t197 to i64
  store i64 %t198, ptr %l63, !tbaa !24
  %t199 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t199, label %bb40, label %bb41
bb40:
  %t201 = call ptr @__olang_region_make(ptr %v2)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l63, !tbaa !24
  br label %bb41
bb41:
  %t203 = load i64, ptr %l5, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l66, !tbaa !24
  %t206 = load ptr, ptr %lp4
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  store i64 %t209, ptr %l68, !tbaa !24
  %t210 = load ptr, ptr %lp4
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  store i64 %t212, ptr %l69, !tbaa !24
  %t213 = load i64, ptr %l66, !tbaa !24
  %t214 = icmp sge i64 %t213, 0
  br i1 %t214, label %bb42, label %bb43
bb42:
  %t216 = load i64, ptr %l66, !tbaa !24
  %t217 = load i64, ptr %l68, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  br i1 %t218, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_e14f50e721aea7b7_1df1d94fb9afe903)
  unreachable
bb44:
  %t220 = load i64, ptr %l68, !tbaa !24
  %t221 = load i64, ptr %l69, !tbaa !24
  %t222 = icmp sle i64 %t220, %t221
  br i1 %t222, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_e14f50e721aea7b7_1df1d94fb9afe903)
  unreachable
bb46:
  %t224 = load ptr, ptr %lp4
  %t225 = getelementptr { i64, ptr }, ptr %t224, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l66, !tbaa !24
  %t228 = load i64, ptr %l68, !tbaa !24
  %t229 = getelementptr i8, ptr %t226, i64 %t227
  %t230 = sub i64 %t228, %t227
  %t231 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = load i64, ptr %l63
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = call ptr @__olang_held_alloc(ptr %t237, i64 %t235)
  call void @olang_textcopy(ptr %t238, ptr %t234, i64 %t235)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  store { i64, ptr } %t240, ptr %l74, !tbaa !27
  %t241 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t241, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_e14f50e721aea7b7_1df1d94fb9afe903)
  unreachable
bb48:
  %t243 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 0
  %t246 = icmp eq i64 %t244, 0
  br i1 %t246, label %bb50, label %bb51
bb49:
  %t248 = load ptr, ptr %lp4
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l78, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t251 = load ptr, ptr %lp4
  store { i64, ptr } %t250, ptr %t251, !tbaa !27
  %t252 = load i1, ptr @olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4
  br i1 %t252, label %bb52, label %bb53
bb50:
  store { i64, ptr } zeroinitializer, ptr %l74, !tbaa !27
  br label %bb51
bb51:
  %t254 = load i64, ptr %l63
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = load { i64, ptr }, ptr %l74
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = call ptr @__olang_region_or(ptr %t257, ptr null)
  %t259 = icmp ne ptr %t258, null
  %t260 = select i1 %t259, ptr %t258, ptr null
  call void @__olang_region_settle_in(ptr %t255, ptr %t260)
  br label %bb49
bb52:
  %t261 = load { i64, ptr }, ptr %l78
  %t262 = extractvalue { i64, ptr } %t261, 1
  call void @__olang_region_release(ptr %t262)
  store { i64, ptr } zeroinitializer, ptr %l78
  br label %bb53
bb53:
  %t263 = load ptr, ptr %lp4
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  %t266 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v2, ptr %s0, { i64, ptr } %t264, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) })
  %t267 = extractvalue { i32, i64 } %t266, 1
  %t268 = extractvalue { i32, i64 } %t266, 0
  store i32 %t268, ptr %l83
  %t269 = icmp ne i32 %t268, 0
  br i1 %t269, label %bb55, label %ok.270, !prof !99
ok.270:
  store i64 %t267, ptr %l82
  br label %bb54
bb54:
  %t271 = load i64, ptr %l82, !tbaa !24
  store i64 %t271, ptr %l80, !tbaa !24
  br label %bb57
bb55:
  br label %bb56
bb56:
  store i64 -1, ptr %l80, !tbaa !24
  br label %bb57
bb57:
  %t272 = load i64, ptr %l80, !tbaa !24
  store i64 %t272, ptr %l6, !tbaa !24
  %t273 = load i64, ptr %l6, !tbaa !24
  %t275 = icmp sgt i64 %t273, 0
  br i1 %t275, label %bb58, label %bb59
bb58:
  %t277 = load i64, ptr %l6, !tbaa !24
  store i64 %t277, ptr %l87, !tbaa !24
  %t278 = load ptr, ptr %lp4
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  store i64 %t280, ptr %l88, !tbaa !24
  %t281 = icmp sge i64 0, 0
  br i1 %t281, label %bb60, label %bb61
bb59:
  %t283 = load ptr, ptr %lp4
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  store { i64, ptr } %t284, ptr %l86, !tbaa !27
  br label %bb66
bb60:
  %t286 = load i64, ptr %l87, !tbaa !24
  %t287 = icmp sle i64 0, %t286
  br i1 %t287, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_7f83270da91fdacc_101e1b43d440f4e8)
  unreachable
bb62:
  %t289 = load i64, ptr %l87, !tbaa !24
  %t290 = load i64, ptr %l88, !tbaa !24
  %t291 = icmp sle i64 %t289, %t290
  br i1 %t291, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_7f83270da91fdacc_101e1b43d440f4e8)
  unreachable
bb64:
  %t293 = load ptr, ptr %lp4
  %t294 = getelementptr { i64, ptr }, ptr %t293, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = load i64, ptr %l87, !tbaa !24
  %t297 = getelementptr i8, ptr %t295, i64 0
  %t298 = sub i64 %t296, 0
  %t299 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t297, 1
  %t302 = extractvalue { i64, ptr } %t300, 1
  %t303 = extractvalue { i64, ptr } %t300, 0
  %t304 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t302, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l86, !tbaa !27
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_7f83270da91fdacc_101e1b43d440f4e8)
  unreachable
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t308 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t308, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fprompt_2eisWord(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp uge i8 %t11, 97
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = icmp ule i8 %t20, 122
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l8, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2elayoutKey(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l17 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i32
  %l41 = alloca i32
  %l45 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v1, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l17, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l23, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v1, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l28
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i32, ptr %l28, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v1, ptr %t48, i32 %t49, i32 0)
  store i32 %t50, ptr %l29
  br label %bb9
bb9:
  %t51 = load i1, ptr %l3, !tbaa !21
  %t52 = load ptr, ptr %l19, !tbaa !29
  %t53 = load ptr, ptr %l20, !tbaa !29
  %t54 = load i32, ptr %l29, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fprompt_2elayoutKey(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t53, i32 %t54, i1 %t51)
  store { i64, ptr } %t56, ptr %l31
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb11:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v1, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l36
  br label %bb12
bb12:
  %t68 = load i32, ptr %l36, !tbaa !23
  store i32 %t68, ptr %l4, !tbaa !23
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l4, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb13
bb13:
  %t79 = load i32, ptr %l41, !range !{i32 0, i32 33}
  %t81 = trunc i64 20 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/interp:Exec", ptr %t84, i32 0, i32 4
  store ptr %t86, ptr %l45, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l4, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l50
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load i32, ptr %l50, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v0, ptr %s2, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l51
  br label %bb17
bb17:
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = add i64 %t101, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t100, i64 %t101)
  %t107 = getelementptr i8, ptr %t106, i64 %t101
  call void @olang_textcopy(ptr %t107, ptr %t103, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t109, ptr %rv
  br label %ret
bb18:
  %t111 = load i1, ptr %l3, !tbaa !21
  br i1 %t111, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l54, !tbaa !27
  br label %bb21
bb21:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/interp:Exec", ptr %t113, i32 0, i32 4
  %t116 = load i32, ptr %l2, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v0, ptr %s0, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l58
  br label %bb22
bb22:
  %t120 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t121, i64 %t122)
  %t128 = getelementptr i8, ptr %t127, i64 %t122
  call void @olang_textcopy(ptr %t128, ptr %t124, i64 %t125)
  %t129 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2fprompt_2elayouts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/prompt:Value"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/prompt:Decl"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { %"compiler/eval:Ptr", i32 }
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca i64
  %l35 = alloca %"compiler/interp:Exec"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l54 = alloca i64
  %l59 = alloca %"compiler/prompt:Value"
  %l66 = alloca i64
  %l68 = alloca i64
  %l73 = alloca %"compiler/prompt:Decl"
  %l75 = alloca i1
  %l82 = alloca i64
  %l84 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca { %"compiler/eval:Ptr", i32 }
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca i64
  %l99 = alloca i32
  %l100 = alloca { %"compiler/eval:Ptr", i32 }
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l116 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l127 = alloca i64
  %l129 = alloca i64
  %l134 = alloca %"compiler/typed:Local"
  %l137 = alloca i1
  %l141 = alloca i1
  %l148 = alloca i32
  %l152 = alloca i1
  %l157 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i64
  %l163 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l172 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %t23 = alloca %"compiler/interp:Exec", align 8
  %t34 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l24
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 72, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2fprompt_2ecellBody(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l26
  br label %bb2
bb2:
  %t8 = load i64, ptr %l26, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %lp3
  %t14 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t13
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t14, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 19
  call void @compiler_2finterp_3aExec_2ector(ptr %t23, ptr %v0, ptr %v0, ptr %v0, ptr %t19, ptr %t22, i32 1)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t23, i64 7352, i1 false)
  br label %bb6
bb6:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 7352, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %l35, i64 7352, i1 false)
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = trunc i64 %t30 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { i32 } undef, i32 %t32, 0
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  store { i32 } %t37, ptr %t38
  %t39 = load { i64, [2 x i64] }, ptr %t34
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %t29, { i64, [2 x i64] } %t39)
  br label %bb7
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 12
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l50
  br label %bb8
bb8:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l8
  store ptr %a2, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t68 = load i64, ptr %l10, !tbaa !24
  store i64 %t68, ptr %l52, !tbaa !24
  %t69 = load ptr, ptr %l9, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %t69)
  store i64 %t71, ptr %l54
  br label %bb10
bb10:
  %t72 = load i64, ptr %l52, !tbaa !24
  %t73 = load i64, ptr %l54, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = call %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v2, ptr %v2, ptr %t78, i64 %t79)
  store %"compiler/prompt:Value" %t82, ptr %l59
  br label %bb14
bb14:
  %t83 = load %"compiler/prompt:Value", ptr %l59
  store %"compiler/prompt:Value" %t83, ptr %l11
  %t84 = getelementptr %"compiler/prompt:Value", ptr %l11, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l8, { i64, ptr } %t85)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l10, !tbaa !24
  br label %bb9
bb17:
  store ptr %a1, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load i64, ptr %l13, !tbaa !24
  store i64 %t95, ptr %l66, !tbaa !24
  %t96 = load ptr, ptr %l12, !tbaa !29
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v1, ptr %t96)
  store i64 %t98, ptr %l68
  br label %bb19
bb19:
  %t99 = load i64, ptr %l66, !tbaa !24
  %t100 = load i64, ptr %l68, !tbaa !24
  %t101 = icmp slt i64 %t99, %t100
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb21:
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l12, !tbaa !29
  %t106 = load i64, ptr %l13, !tbaa !24
  %t109 = call %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v1, ptr %v1, ptr %t105, i64 %t106)
  store %"compiler/prompt:Decl" %t109, ptr %l73
  br label %bb23
bb23:
  %t110 = load %"compiler/prompt:Decl", ptr %l73
  store %"compiler/prompt:Decl" %t110, ptr %l14
  %t112 = call i1 @compiler_2fprompt_2eisGlobal(ptr %s6, ptr %l14)
  store i1 %t112, ptr %l75
  br label %bb24
bb24:
  %t113 = load i1, ptr %l75, !tbaa !21
  br i1 %t113, label %bb25, label %bb26
bb25:
  %t114 = getelementptr %"compiler/prompt:Decl", ptr %l14, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l8, { i64, ptr } %t115)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l13, !tbaa !24
  br label %bb18
bb30:
  store ptr %l8, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  %t124 = load i64, ptr %l16, !tbaa !24
  store i64 %t124, ptr %l82, !tbaa !24
  %t125 = load ptr, ptr %l15, !tbaa !29
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t125)
  store i64 %t127, ptr %l84
  br label %bb32
bb32:
  %t128 = load i64, ptr %l82, !tbaa !24
  %t129 = load i64, ptr %l84, !tbaa !24
  %t130 = icmp slt i64 %t128, %t129
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb33, label %bb34
bb33:
  br label %bb51
bb34:
  br label %bb35
bb35:
  %t134 = load ptr, ptr %l15, !tbaa !29
  %t135 = load i64, ptr %l16, !tbaa !24
  %t138 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t134, i64 %t135)
  store { i64, ptr } %t138, ptr %l89
  br label %bb36
bb36:
  %t139 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t139, ptr %l17, !tbaa !27
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = getelementptr %"compiler/interp:Exec", ptr %t140, i32 0, i32 4
  store ptr %t142, ptr %l92, !tbaa !29
  %t143 = load i64, ptr %l6, !tbaa !24
  store i64 %t143, ptr %l93, !tbaa !24
  %t144 = load ptr, ptr %l7, !tbaa !29
  store ptr %t144, ptr %l94, !tbaa !29
  %t145 = call ptr @__olang_scope_hold(ptr %v0)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l95, !tbaa !24
  %t147 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t147, label %bb37, label %bb38
bb37:
  %t149 = load ptr, ptr %l94, !tbaa !29
  %t150 = call ptr @__olang_region_or(ptr %t149, ptr %v0)
  %t151 = call ptr @__olang_scope_hold(ptr %t150)
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l95, !tbaa !24
  br label %bb38
bb38:
  %t153 = load ptr, ptr %l7, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t155 = load i64, ptr %l95
  %t156 = inttoptr i64 %t155 to ptr
  %t159 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t156, ptr %s0, ptr %t153, { i64, ptr } %t154)
  store i32 %t159, ptr %l99
  br label %bb39
bb39:
  %t160 = load ptr, ptr %l92, !tbaa !29
  %t161 = load i64, ptr %l93, !tbaa !24
  %t162 = load i32, ptr %l99, !tbaa !23
  %t163 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %t160, i64 %t161, i32 %t162)
  %t164 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t163, 1
  %t165 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t163, 0
  store i32 %t165, ptr %l101
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb41, label %ok.167, !prof !99
ok.167:
  store { %"compiler/eval:Ptr", i32 } %t164, ptr %l100
  br label %bb40
bb40:
  %t168 = load { %"compiler/eval:Ptr", i32 }, ptr %l100
  store { %"compiler/eval:Ptr", i32 } %t168, ptr %l90
  br label %bb43
bb41:
  %t169 = load i32, ptr %l101, !tbaa !23
  %t170 = ashr i32 %t169, 16
  %t172 = icmp eq i32 %t170, 1
  store i1 %t172, ptr %l103, !tbaa !21
  br label %bb42
bb42:
  br label %bb50
bb43:
  %t173 = load { %"compiler/eval:Ptr", i32 }, ptr %l90
  store { %"compiler/eval:Ptr", i32 } %t173, ptr %l18
  %t174 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l18, i32 0, i32 1
  %t175 = load i32, ptr %t174, !tbaa !23
  store i32 %t175, ptr %l19, !tbaa !23
  %t177 = load ptr, ptr %lp3
  store ptr %t177, ptr %l105, !tbaa !29
  %t178 = call ptr @__olang_scope_hold(ptr %v3)
  %t179 = ptrtoint ptr %t178 to i64
  store i64 %t179, ptr %l106, !tbaa !24
  %t180 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t180, label %bb44, label %bb45
bb44:
  %t182 = call ptr @__olang_region_make(ptr %v3)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l106, !tbaa !24
  br label %bb45
bb45:
  %t184 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = extractvalue { i64, ptr } %t184, 0
  %t188 = load i64, ptr %l106
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = call ptr @__olang_held_alloc(ptr %t189, i64 %t187)
  call void @olang_textcopy(ptr %t190, ptr %t186, i64 %t187)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l110, !tbaa !27
  %t194 = call ptr @__olang_scope_hold(ptr %v3)
  %t195 = ptrtoint ptr %t194 to i64
  store i64 %t195, ptr %l111, !tbaa !24
  %t196 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = call ptr @__olang_region_make(ptr %v3)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l111, !tbaa !24
  br label %bb47
bb47:
  %t200 = load ptr, ptr %l5, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l19, !tbaa !23
  %t203 = load i64, ptr %l111
  %t204 = inttoptr i64 %t203 to ptr
  %t208 = call { i64, ptr } @compiler_2fprompt_2elayoutKey(ptr %v0, ptr %v0, ptr %t204, ptr %t200, ptr %t201, i32 %t202, i1 false)
  store { i64, ptr } %t208, ptr %l116
  br label %bb48
bb48:
  %t209 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t210 = load i64, ptr %l111
  %t211 = inttoptr i64 %t210 to ptr
  %t212 = extractvalue { i64, ptr } %t209, 0
  %t213 = extractvalue { i64, ptr } %t209, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_held_alloc(ptr %t211, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load ptr, ptr %l105, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v3, ptr %v3, ptr %v3, ptr %t218, { i64, ptr } %t219, { i64, ptr } %t217)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t221 = load i64, ptr %l16, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l16, !tbaa !24
  br label %bb31
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 19
  %t229 = load i64, ptr %l4, !tbaa !24
  %t232 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t228, i64 %t229)
  store ptr %t232, ptr %l124
  br label %bb52
bb52:
  %t233 = load ptr, ptr %l124, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Body", ptr %t233, i32 0, i32 7
  store ptr %t235, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s15
  %t237 = load i64, ptr %l21, !tbaa !24
  store i64 %t237, ptr %l127, !tbaa !24
  %t238 = load ptr, ptr %l20, !tbaa !29
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t238)
  store i64 %t240, ptr %l129
  br label %bb54
bb54:
  %t241 = load i64, ptr %l127, !tbaa !24
  %t242 = load i64, ptr %l129, !tbaa !24
  %t243 = icmp slt i64 %t241, %t242
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s15)
  br label %bb81
bb56:
  br label %bb57
bb57:
  %t247 = load ptr, ptr %l20, !tbaa !29
  %t248 = load i64, ptr %l21, !tbaa !24
  %t251 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t247, i64 %t248)
  store %"compiler/typed:Local" %t251, ptr %l134
  br label %bb58
bb58:
  %t252 = load %"compiler/typed:Local", ptr %l134
  store %"compiler/typed:Local" %t252, ptr %l22
  %t253 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 3
  %t254 = load i32, ptr %t253, !tbaa !23
  %t256 = icmp ne i32 %t254, 0
  br i1 %t256, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb61
bb60:
  %t258 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 4
  %t259 = load i32, ptr %t258, !range !{i32 0, i32 7}
  %t261 = trunc i64 1 to i32
  %t262 = icmp eq i32 %t259, %t261
  %t264 = xor i1 %t262, true
  store i1 %t264, ptr %l137, !tbaa !21
  br label %bb61
bb61:
  %t266 = load i1, ptr %l137, !tbaa !21
  br i1 %t266, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb64
bb63:
  %t267 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 0
  %t268 = load i32, ptr %t267, !tbaa !23
  %t270 = icmp eq i32 %t268, 0
  store i1 %t270, ptr %l141, !tbaa !21
  br label %bb64
bb64:
  %t272 = load i1, ptr %l141, !tbaa !21
  br i1 %t272, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s15)
  br label %bb80
bb66:
  br label %bb67
bb67:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 2
  %t280 = load i32, ptr %t279, !tbaa !23
  %t283 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t278, i32 %t280)
  store i32 %t283, ptr %l148
  br label %bb68
bb68:
  %t284 = load i32, ptr %l148, !range !{i32 0, i32 33}
  %t286 = trunc i64 20 to i32
  %t287 = icmp eq i32 %t284, %t286
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb69, label %bb70
bb69:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  %t297 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 2
  %t298 = load i32, ptr %t297, !tbaa !23
  %t301 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t296, i32 %t298)
  store i1 %t301, ptr %l157
  br label %bb71
bb70:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb72
bb71:
  %t302 = load i1, ptr %l157, !tbaa !21
  store i1 %t302, ptr %l152, !tbaa !21
  br label %bb72
bb72:
  %t303 = load i1, ptr %l152, !tbaa !21
  store i1 %t303, ptr %l23, !tbaa !21
  %t304 = load ptr, ptr %lp3
  store ptr %t304, ptr %l158, !tbaa !29
  %t305 = call ptr @__olang_scope_hold(ptr %v3)
  %t306 = ptrtoint ptr %t305 to i64
  store i64 %t306, ptr %l159, !tbaa !24
  %t307 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t307, label %bb73, label %bb74
bb73:
  %t309 = call ptr @__olang_region_make(ptr %v3)
  %t310 = ptrtoint ptr %t309 to i64
  store i64 %t310, ptr %l159, !tbaa !24
  br label %bb74
bb74:
  %t311 = load ptr, ptr %l7, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 0
  %t313 = load i32, ptr %t312, !tbaa !23
  %t316 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s15, ptr %t311, i32 %t313)
  store { i64, ptr } %t316, ptr %l163
  br label %bb75
bb75:
  %t317 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = load i64, ptr %l159
  %t321 = inttoptr i64 %t320 to ptr
  %t322 = call ptr @__olang_held_alloc(ptr %t321, i64 %t319)
  call void @olang_textcopy(ptr %t322, ptr %t318, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l165, !tbaa !27
  %t326 = call ptr @__olang_scope_hold(ptr %v3)
  %t327 = ptrtoint ptr %t326 to i64
  store i64 %t327, ptr %l166, !tbaa !24
  %t328 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t328, label %bb76, label %bb77
bb76:
  %t330 = call ptr @__olang_region_make(ptr %v3)
  %t331 = ptrtoint ptr %t330 to i64
  store i64 %t331, ptr %l166, !tbaa !24
  br label %bb77
bb77:
  %t332 = load ptr, ptr %l5, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 2
  %t335 = load i32, ptr %t334, !tbaa !23
  %t336 = load i1, ptr %l23, !tbaa !21
  %t337 = load i64, ptr %l166
  %t338 = inttoptr i64 %t337 to ptr
  %t343 = call { i64, ptr } @compiler_2fprompt_2elayoutKey(ptr %v0, ptr %v0, ptr %t338, ptr %t332, ptr %t333, i32 %t335, i1 %t336)
  store { i64, ptr } %t343, ptr %l172
  br label %bb78
bb78:
  %t344 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t345 = load i64, ptr %l166
  %t346 = inttoptr i64 %t345 to ptr
  %t347 = extractvalue { i64, ptr } %t344, 0
  %t348 = extractvalue { i64, ptr } %t344, 1
  %t349 = mul i64 %t347, 1
  %t350 = call ptr @__olang_held_alloc(ptr %t346, i64 %t349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t350, ptr %t348, i64 %t349, i1 false)
  %t351 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t350, 1
  %t353 = load ptr, ptr %l158, !tbaa !29
  %t354 = load { i64, ptr }, ptr %l165, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v3, ptr %v3, ptr %v3, ptr %t353, { i64, ptr } %t354, { i64, ptr } %t352)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s15)
  br label %bb80
bb80:
  %t356 = load i64, ptr %l21, !tbaa !24
  %t359 = add i64 %t356, 1
  store i64 %t359, ptr %l21, !tbaa !24
  br label %bb53
bb81:
  %t361 = load ptr, ptr %lp3
  %t362 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t361
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t362, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local i64 @compiler_2fprompt_2ematching(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca { i64, ptr }
  %l47 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = add i64 %t3, 1
  store i64 %t5, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb23
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load i64, ptr %l9, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr %"compiler/token:Token", ptr %t57, i64 %t54
  %t59 = getelementptr %"compiler/token:Token", ptr %t58, i32 0, i32 0
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 116}
  %t62 = call i1 @compiler_2fprompt_2eopens(i32 %t60)
  store i1 %t62, ptr %l40
  br label %bb11
bb11:
  %t63 = load i1, ptr %l40, !tbaa !21
  br i1 %t63, label %bb12, label %bb13
bb12:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/token:Token", ptr %t73, i64 %t70
  %t75 = getelementptr %"compiler/token:Token", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !range !{i32 0, i32 116}
  %t78 = call i1 @compiler_2fprompt_2ecloses(i32 %t76)
  store i1 %t78, ptr %l47
  br label %bb15
bb15:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = sub i64 %t80, 1
  store i64 %t83, ptr %l3, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l9, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb7
bb23:
  %t96 = load i64, ptr %l2, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fprompt_2enextEntry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t9 = call { i32, { i64, ptr } } @compiler_2fprompt_2ereadEntry(ptr %v1, ptr %v2, ptr %a1, i1 %a3)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l9
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t15 = load i32, ptr %l10, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t27 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t26, 1
  store { i32, { i64, ptr } } %t27, ptr %rv
  br label %ret
bb6:
  %t29 = insertvalue { ptr, ptr } undef, ptr @compiler_2fprompt_2eOpen_fv_fn_28std_2fprelude_2ftext_3aString_26_29_20Bool, 0
  %t30 = insertvalue { ptr, ptr } %t29, ptr null, 1
  %t31 = load ptr, ptr @__olang_prog_scope
  %t34 = extractvalue { ptr, ptr } %t30, 0
  %t35 = extractvalue { ptr, ptr } %t30, 1
  %t36 = call { i32, { i64, ptr } } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eRead(ptr %v0, ptr %t31, ptr %s0, ptr %a0, ptr %t34, ptr %t35)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l16
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb8, label %ok.40, !prof !99
ok.40:
  store { i64, ptr } %t37, ptr %l15
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t41, ptr %l12, !tbaa !27
  br label %bb10
bb8:
  %t42 = load i32, ptr %l16, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
bb10:
  %t48 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t49, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  call void @__olang_scope_close(ptr %s0)
  %t55 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t53, 1
  store { i32, { i64, ptr } } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2enotSaved(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 65536
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d139, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  br label %bb9
bb2:
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = lshr i32 %t7, 16
  %t10 = and i32 %t7, 65535
  %t11 = icmp eq i32 %t9, 1
  %t12 = select i1 %t11, i32 1, i32 0
  %t13 = icmp eq i32 %t7, 0
  %t14 = shl i32 %t12, 16
  %t15 = or i32 %t14, %t10
  %t16 = select i1 %t13, i32 0, i32 %t15
  %t20 = icmp eq i32 %t16, 65537
  br i1 %t20, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  br label %bb8
bb4:
  %t24 = load i32, ptr %l0, !tbaa !23
  %t26 = lshr i32 %t24, 16
  %t27 = and i32 %t24, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t24, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  %t37 = icmp eq i32 %t33, 65538
  br i1 %t37, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t39, ptr %l19, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t41, ptr %l19, !tbaa !27
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t43, ptr %l12, !tbaa !27
  br label %bb8
bb8:
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t44, ptr %l5, !tbaa !27
  br label %bb9
bb9:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l24, !tbaa !24
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l24, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2eplaces(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l59 = alloca i1
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i32
  %l75 = alloca i64
  %l76 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i64
  %l84 = alloca i64
  %l89 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l97 = alloca i64
  %l101 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l113 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i1, ptr %l11, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t5, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l14, !tbaa !24
  %t8 = load i64, ptr %l14, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l15, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t22, ptr %l3
  %t25 = extractvalue { i64, ptr } %a2, 1
  %t26 = extractvalue { i64, ptr } %a2, 0
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t25, i64 %t26)
  %t31 = getelementptr i8, ptr %t30, i64 %t26
  call void @olang_textcopy(ptr %t31, ptr %t27, i64 %t28)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l21, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t37, 0
  store i64 %t40, ptr %l24, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b14cd07759368a94_615e274dad3004e0)
  unreachable
bb9:
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = icmp sle i64 %t50, %t51
  br i1 %t52, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b14cd07759368a94_615e274dad3004e0)
  unreachable
bb11:
  %t54 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l21, !tbaa !24
  %t57 = load i64, ptr %l24, !tbaa !24
  %t58 = getelementptr i8, ptr %t55, i64 %t56
  %t59 = sub i64 %t57, %t56
  %t60 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t65 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t61, { i64, ptr } %t62)
  %t66 = extractvalue { i32, i64 } %t65, 1
  %t67 = extractvalue { i32, i64 } %t65, 0
  store i32 %t67, ptr %l32
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb14, label %ok.69, !prof !99
ok.69:
  store i64 %t66, ptr %l31
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b14cd07759368a94_615e274dad3004e0)
  unreachable
bb13:
  %t70 = load i64, ptr %l31, !tbaa !24
  store i64 %t70, ptr %l19, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb58
bb16:
  %t71 = load i64, ptr %l19, !tbaa !24
  store i64 %t71, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l33, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l34, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  store i64 %t73, ptr %l35, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t74, %t75
  store i64 %t78, ptr %l38, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l39, !tbaa !24
  %t81 = load i64, ptr %l35, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb17, label %bb18
bb17:
  %t84 = load i64, ptr %l35, !tbaa !24
  %t85 = load i64, ptr %l38, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_da36ef8b95c68801_28fd7452ffcab23d)
  unreachable
bb19:
  %t88 = load i64, ptr %l38, !tbaa !24
  %t89 = load i64, ptr %l39, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_da36ef8b95c68801_28fd7452ffcab23d)
  unreachable
bb21:
  %t92 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l35, !tbaa !24
  %t95 = load i64, ptr %l38, !tbaa !24
  %t96 = getelementptr i8, ptr %t93, i64 %t94
  %t97 = sub i64 %t95, %t94
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t100 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t100, { i64, ptr } %t99)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_da36ef8b95c68801_28fd7452ffcab23d)
  unreachable
bb23:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t112 = add i64 %t106, %t109
  store i64 %t112, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  store i64 %t114, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t122 = icmp slt i64 %t116, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t124 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t124, ptr %l56, !tbaa !27
  %t125 = load i64, ptr %l8, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i8, ptr %t128, i64 %t125
  %t130 = load i8, ptr %t129, !tbaa !32
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t130)
  store i1 %t132, ptr %l59
  br label %bb27
bb26:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb28
bb27:
  %t133 = load i1, ptr %l59, !tbaa !21
  store i1 %t133, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t134 = load i1, ptr %l55, !tbaa !21
  %t135 = xor i1 %t134, true
  br i1 %t135, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t137, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  br label %bb24
bb33:
  %t142 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t142, ptr %l65, !tbaa !27
  %t143 = load i64, ptr %l7, !tbaa !24
  store i64 %t143, ptr %l66, !tbaa !24
  %t144 = load i64, ptr %l8, !tbaa !24
  store i64 %t144, ptr %l67, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l68, !tbaa !24
  %t147 = load i64, ptr %l66, !tbaa !24
  %t148 = icmp sge i64 %t147, 0
  br i1 %t148, label %bb34, label %bb35
bb34:
  %t150 = load i64, ptr %l66, !tbaa !24
  %t151 = load i64, ptr %l67, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_2b63874b1fcbb202_7b98d930a28c0ade)
  unreachable
bb36:
  %t154 = load i64, ptr %l67, !tbaa !24
  %t155 = load i64, ptr %l68, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_2b63874b1fcbb202_7b98d930a28c0ade)
  unreachable
bb38:
  %t158 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l66, !tbaa !24
  %t161 = load i64, ptr %l67, !tbaa !24
  %t162 = getelementptr i8, ptr %t159, i64 %t160
  %t163 = sub i64 %t161, %t160
  %t164 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  store { i64, ptr } %t165, ptr %l72, !tbaa !27
  %t166 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 10)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l74
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb41, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l73
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_2b63874b1fcbb202_7b98d930a28c0ade)
  unreachable
bb40:
  %t171 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t172 = load i64, ptr %l73, !tbaa !24
  %t173 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t171, i64 %t172)
  %t174 = extractvalue { i32, i64 } %t173, 1
  %t175 = extractvalue { i32, i64 } %t173, 0
  store i32 %t175, ptr %l76
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb44, label %ok.177, !prof !99
ok.177:
  store i64 %t174, ptr %l75
  br label %bb43
bb41:
  br label %bb42
bb42:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb45
bb43:
  %t178 = load i64, ptr %l75, !tbaa !24
  store i64 %t178, ptr %l64, !tbaa !24
  br label %bb45
bb44:
  br label %bb42
bb45:
  %t179 = load i64, ptr %l64, !tbaa !24
  %t180 = sub i64 %t179, 1
  store i64 %t180, ptr %l9, !tbaa !24
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = icmp slt i64 %t182, 0
  br i1 %t184, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb49
bb47:
  %t186 = load i64, ptr %l9, !tbaa !24
  store i64 %t186, ptr %l81, !tbaa !24
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/prompt:program", ptr %t187, i32 0, i32 1
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t189)
  store i64 %t191, ptr %l84
  br label %bb48
bb48:
  %t192 = load i64, ptr %l81, !tbaa !24
  %t193 = load i64, ptr %l84, !tbaa !24
  %t194 = icmp sge i64 %t192, %t193
  store i1 %t194, ptr %l80, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l80, !tbaa !21
  br i1 %t196, label %bb50, label %bb51
bb50:
  %t197 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t197)
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t200 = load i64, ptr %l7, !tbaa !24
  store i64 %t200, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb53:
  store ptr %l3, ptr %l89, !tbaa !29
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr %"compiler/prompt:program", ptr %t202, i32 0, i32 1
  %t205 = load i64, ptr %l9, !tbaa !24
  %t208 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s3, ptr %t204, i64 %t205)
  store { i64, ptr } %t208, ptr %l93
  br label %bb54
bb54:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr %"compiler/prompt:program", ptr %t209, i32 0, i32 2
  %t212 = load i64, ptr %l9, !tbaa !24
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t211, i64 %t212)
  store i64 %t215, ptr %l97
  br label %bb55
bb55:
  %t216 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = load i64, ptr %l97, !tbaa !24
  %t223 = call i64 @__olang_fmt_i64(ptr null, i64 %t222)
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t217, i64 %t218)
  %t226 = getelementptr i8, ptr %t225, i64 %t218
  call void @olang_textcopy(ptr %t226, ptr %t219, i64 %t220)
  %t227 = getelementptr i8, ptr %t226, i64 %t220
  %t228 = call i64 @__olang_fmt_i64(ptr %t227, i64 %t222)
  %t229 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t225, 1
  %t232 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t232, { i64, ptr } %t230)
  br label %bb56
bb56:
  %t234 = load i64, ptr %l8, !tbaa !24
  store i64 %t234, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb57:
  br label %bb6
bb58:
  store ptr %l3, ptr %l101, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t236, ptr %l102, !tbaa !27
  %t237 = load i64, ptr %l5, !tbaa !24
  store i64 %t237, ptr %l103, !tbaa !24
  %t238 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t238, 0
  store i64 %t241, ptr %l106, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l107, !tbaa !24
  %t244 = load i64, ptr %l103, !tbaa !24
  %t245 = icmp sge i64 %t244, 0
  br i1 %t245, label %bb59, label %bb60
bb59:
  %t247 = load i64, ptr %l103, !tbaa !24
  %t248 = load i64, ptr %l106, !tbaa !24
  %t249 = icmp sle i64 %t247, %t248
  br i1 %t249, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_77d28f78d720beff_d78a7ce3569603db)
  unreachable
bb61:
  %t251 = load i64, ptr %l106, !tbaa !24
  %t252 = load i64, ptr %l107, !tbaa !24
  %t253 = icmp sle i64 %t251, %t252
  br i1 %t253, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_77d28f78d720beff_d78a7ce3569603db)
  unreachable
bb63:
  %t255 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = load i64, ptr %l103, !tbaa !24
  %t258 = load i64, ptr %l106, !tbaa !24
  %t259 = getelementptr i8, ptr %t256, i64 %t257
  %t260 = sub i64 %t258, %t257
  %t261 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t259, 1
  %t263 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t263, { i64, ptr } %t262)
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_77d28f78d720beff_d78a7ce3569603db)
  unreachable
bb65:
  %t266 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t266, ptr %l113
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t267 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t267, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fprompt_2ereadEntry(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i1
  %l9 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i1 true, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  br i1 %a1, label %bb3, label %bb4
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i1 @compiler_2fprompt_2ewaiting(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l9
  br label %bb5
bb4:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t8 = load i1, ptr %l9, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i1, ptr %l3, !tbaa !21
  br i1 %t12, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d147, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb11
bb11:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2fprompt_2esay(ptr %s2, { i64, ptr } %t14)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %v0, ptr %s1, ptr %t15)
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l16
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb15, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l15
  br label %bb14
bb14:
  %t22 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  br label %bb22
bb15:
  %t23 = load i32, ptr %l16, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t28 = load i1, ptr %l3, !tbaa !21
  br i1 %t28, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb36
bb22:
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  %t33 = load i1, ptr %l3, !tbaa !21
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb23, label %bb24
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } %t38)
  br label %bb27
bb27:
  store i1 false, ptr %l3, !tbaa !21
  %t41 = call ptr @__olang_scope_hold(ptr %s1)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l26, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fscan_3ascanner_2e0
  br i1 %t43, label %bb28, label %bb29
bb28:
  %t45 = call ptr @__olang_region_make(ptr %s1)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l26, !tbaa !24
  br label %bb29
bb29:
  %t47 = load i64, ptr %l26
  %t48 = inttoptr i64 %t47 to ptr
  %t50 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t48, ptr %l2)
  store { i64, ptr } %t50, ptr %l29
  br label %bb30
bb30:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t53 = call i1 @compiler_2fprompt_2eOpen(ptr %s1, { i64, ptr } %t51)
  store i1 %t53, ptr %l31
  br label %bb31
bb31:
  %t54 = load i1, ptr %l31, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb36
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  br label %bb35
bb35:
  br label %bb2
bb36:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t58, ptr %l34
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t59, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fprompt_2eshows(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i64
  %l74 = alloca { i64, ptr }
  %l78 = alloca i1
  %l83 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l12, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr %"compiler/token:Token", ptr %t5, i64 %t2
  %t7 = getelementptr %"compiler/token:Token", ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 116}
  store i32 %t8, ptr %l3
  %t10 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t12 = trunc i64 114 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb25
bb2:
  %t15 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t17 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t15)
  store { i64, ptr } %t17, ptr %l19
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store i1 %t19, ptr %l20
  br label %bb4
bb4:
  %t20 = load i1, ptr %l20, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t25 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t23)
  store { i64, ptr } %t25, ptr %l24
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb9
bb7:
  %t26 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t27 = call i1 @compiler_2fprompt_2eisWord(ptr %s0, { i64, ptr } %t26)
  store i1 %t27, ptr %l25
  br label %bb8
bb8:
  %t28 = load i1, ptr %l25, !tbaa !21
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t32 = trunc i64 11 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l26, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t37 = load i1, ptr %l26, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t38 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t40 = trunc i64 48 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t45 = load i1, ptr %l30, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  %t46 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t48 = trunc i64 51 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t54 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t56 = trunc i64 6 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l38, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l38, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t64 = trunc i64 7 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l42, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t69 = load i1, ptr %l42, !tbaa !21
  store i1 %t69, ptr %l17, !tbaa !21
  br label %bb25
bb25:
  %t70 = load i1, ptr %l17, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  store i64 0, ptr %l4, !tbaa !24
  %t72 = load i64, ptr %l1, !tbaa !24
  store i64 %t72, ptr %l5, !tbaa !24
  %t76 = add i64 %a2, 1
  store i64 %t76, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb34
bb31:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l56, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb33
bb33:
  %t104 = load i64, ptr %l56, !tbaa !24
  store i64 %t104, ptr %l53, !tbaa !24
  br label %bb34
bb34:
  %t105 = load i64, ptr %l53, !tbaa !24
  store i64 %t105, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb35
bb35:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb36, label %bb37
bb36:
  br label %bb55
bb37:
  br label %bb38
bb38:
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  %t124 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t124, ptr %l74, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr %"compiler/token:Token", ptr %t128, i64 %t122
  %t130 = getelementptr %"compiler/token:Token", ptr %t129, i32 0, i32 0
  %t131 = load i32, ptr %t130, !range !{i32 0, i32 116}
  store i32 %t131, ptr %l11
  %t133 = load i32, ptr %l11, !range !{i32 0, i32 116}
  %t135 = call i1 @compiler_2fprompt_2eopens(i32 %t133)
  store i1 %t135, ptr %l78
  br label %bb39
bb39:
  %t136 = load i1, ptr %l78, !tbaa !21
  br i1 %t136, label %bb40, label %bb41
bb40:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t140 = add i64 %t137, 1
  store i64 %t140, ptr %l4, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t142 = load i32, ptr %l11, !range !{i32 0, i32 116}
  %t144 = call i1 @compiler_2fprompt_2ecloses(i32 %t142)
  store i1 %t144, ptr %l83
  br label %bb43
bb43:
  %t145 = load i1, ptr %l83, !tbaa !21
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t146 = load i64, ptr %l4, !tbaa !24
  %t149 = sub i64 %t146, 1
  store i64 %t149, ptr %l4, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t151 = load i64, ptr %l4, !tbaa !24
  %t153 = icmp eq i64 %t151, 0
  br i1 %t153, label %bb47, label %bb48
bb47:
  %t155 = load i32, ptr %l11, !range !{i32 0, i32 116}
  %t157 = call i1 @compiler_2fprompt_2eassigns(i32 %t155)
  store i1 %t157, ptr %l91
  br label %bb49
bb48:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb50
bb49:
  %t158 = load i1, ptr %l91, !tbaa !21
  store i1 %t158, ptr %l89, !tbaa !21
  br label %bb50
bb50:
  %t159 = load i1, ptr %l89, !tbaa !21
  br i1 %t159, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t164 = add i64 %t161, 1
  store i64 %t164, ptr %l9, !tbaa !24
  br label %bb35
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fprompt_2estopped(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d150, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb36
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb9
bb9:
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb10, label %bb11
bb10:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t10, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l11, !tbaa !24
  %t16 = icmp sge i64 7, 0
  br i1 %t16, label %bb12, label %bb13
bb11:
  br label %bb18
bb12:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sle i64 7, %t18
  br i1 %t19, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_b2828226e705177d_4f9f00f8ce972671)
  unreachable
bb14:
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = load i64, ptr %l11, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b2828226e705177d_4f9f00f8ce972671)
  unreachable
bb16:
  %t25 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l10, !tbaa !24
  %t28 = getelementptr i8, ptr %t26, i64 7
  %t29 = sub i64 %t27, 7
  %t30 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t32 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t32, i64 %t33)
  %t39 = getelementptr i8, ptr %t38, i64 %t33
  call void @olang_textcopy(ptr %t39, ptr %t35, i64 %t36)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l2, !tbaa !27
  br label %bb36
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b2828226e705177d_4f9f00f8ce972671)
  unreachable
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb31
bb21:
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t46, ptr %l19
  br label %bb22
bb22:
  %t47 = load i1, ptr %l19, !tbaa !21
  br i1 %t47, label %bb23, label %bb24
bb23:
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t48, ptr %l20, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t49, 0
  store i64 %t52, ptr %l23, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l24, !tbaa !24
  %t55 = icmp sge i64 7, 0
  br i1 %t55, label %bb25, label %bb26
bb24:
  br label %bb31
bb25:
  %t57 = load i64, ptr %l23, !tbaa !24
  %t58 = icmp sle i64 7, %t57
  br i1 %t58, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ad688bb7ba0b3d20_99d8bf61b60a8404)
  unreachable
bb27:
  %t60 = load i64, ptr %l23, !tbaa !24
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ad688bb7ba0b3d20_99d8bf61b60a8404)
  unreachable
bb29:
  %t64 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l23, !tbaa !24
  %t67 = getelementptr i8, ptr %t65, i64 7
  %t68 = sub i64 %t66, 7
  %t69 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t74 = extractvalue { i64, ptr } %t70, 1
  %t75 = extractvalue { i64, ptr } %t70, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t74, i64 %t75)
  %t82 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  store { i64, ptr } %t84, ptr %l2, !tbaa !27
  br label %bb36
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ad688bb7ba0b3d20_99d8bf61b60a8404)
  unreachable
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t87 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = extractvalue { i64, ptr } %t87, 0
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t89, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l2, !tbaa !27
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_84114044f9b61514_f9c7bee38045a068)
  unreachable
bb36:
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = extractvalue { i64, ptr } %t96, 0
  %t101 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t99, i64 %t100)
  %t105 = getelementptr i8, ptr %t104, i64 %t100
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprompt_2etell(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fpaint_2eWanted(i32 2)
  store i1 %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load i1, ptr %l2, !tbaa !21
  store i1 %t2, ptr %l1, !tbaa !21
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/prompt:Reply", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d158, i32 0, i32 1) })
  store i1 %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load i1, ptr %l1, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb4:
  br label %bb10
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/prompt:Reply", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2fpaint_2eDiagnostics(ptr %v0, ptr %s1, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l11
  br label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/prompt:Reply", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  br label %bb8
bb7:
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t32, ptr %l8, !tbaa !27
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fprompt_2esayErr(ptr %s1, { i64, ptr } %t34)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/prompt:Reply", ptr %t35, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t40, ptr %l19
  br label %bb11
bb11:
  %t41 = load i1, ptr %l19, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i1, ptr %l1, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/prompt:Reply", ptr %t46, i32 0, i32 4
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2fpaint_2eDiagnostics(ptr %v0, ptr %s3, { i64, ptr } %t49)
  store { i64, ptr } %t51, ptr %l25
  br label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/prompt:Reply", ptr %t52, i32 0, i32 4
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l22, !tbaa !27
  br label %bb17
bb16:
  %t64 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t64, ptr %l22, !tbaa !27
  br label %bb17
bb17:
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2fprompt_2esayErr(ptr %s3, { i64, ptr } %t66)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/prompt:Reply", ptr %t67, i32 0, i32 5
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d160, i32 0, i32 1) })
  store i1 %t72, ptr %l33
  br label %bb20
bb20:
  %t73 = load i1, ptr %l33, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/prompt:Reply", ptr %t76, i32 0, i32 5
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @compiler_2fprompt_2esayErr(ptr %v0, { i64, ptr } %t79)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/prompt:Reply", ptr %t81, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = call i1 @compiler_2fpaint_2eWanted(i32 1)
  store i1 %t86, ptr %l39
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t87 = load i1, ptr %l39, !tbaa !21
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/prompt:Reply", ptr %t88, i32 0, i32 3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call { i64, ptr } @compiler_2fpaint_2eSource(ptr %v0, ptr %s6, { i64, ptr } %t91)
  store { i64, ptr } %t93, ptr %l43
  br label %bb30
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/prompt:Reply", ptr %t94, i32 0, i32 3
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t99, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l40, !tbaa !27
  br label %bb31
bb30:
  %t105 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t105, ptr %l40, !tbaa !27
  br label %bb31
bb31:
  %t106 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t107, i64 %t108)
  %t113 = getelementptr i8, ptr %t112, i64 %t108
  call void @olang_textcopy(ptr %t113, ptr %t109, i64 %t110)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  call void @compiler_2fprompt_2esay(ptr %s6, { i64, ptr } %t115)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fprompt_2ewaiting(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca [1 x %"<poll.h>:pollfd"]
  %l3 = alloca i1
  %l5 = alloca %"<poll.h>:pollfd"
  %l7 = alloca %"<poll.h>:pollfd"
  %l12 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @std_2fio_2estd_2fio_3aLines_2eBuffered(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %"<poll.h>:pollfd" zeroinitializer, ptr %l5
  %t6 = icmp sgt i64 1, 0
  br i1 %t6, label %bb5, label %bb6
bb5:
  %t8 = call %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd()
  store %"<poll.h>:pollfd" %t8, ptr %l7
  br label %bb7
bb6:
  %t9 = load %"<poll.h>:pollfd", ptr %l5
  %t10 = insertvalue [1 x %"<poll.h>:pollfd"] undef, %"<poll.h>:pollfd" %t9, 0
  store [1 x %"<poll.h>:pollfd"] %t10, ptr %l1
  %t12 = getelementptr [1 x %"<poll.h>:pollfd"], ptr %l1, i64 0, i64 0
  %t13 = getelementptr %"<poll.h>:pollfd", ptr %t12, i32 0, i32 0
  store i32 0, ptr %t13, !tbaa !23
  %t14 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t16 = trunc i32 %t14 to i16
  %t18 = getelementptr [1 x %"<poll.h>:pollfd"], ptr %l1, i64 0, i64 0
  %t19 = getelementptr %"<poll.h>:pollfd", ptr %t18, i32 0, i32 1
  store i16 %t16, ptr %t19, !tbaa !62
  %t21 = call i32 @poll(ptr %l1, i64 1, i32 0)
  store i32 %t21, ptr %l12
  br label %bb8
bb7:
  %t22 = load %"<poll.h>:pollfd", ptr %l7
  store %"<poll.h>:pollfd" %t22, ptr %l5
  br label %bb6
bb8:
  %t23 = load i32, ptr %l12, !tbaa !23
  %t24 = icmp sgt i32 %t23, 0
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/prompt:Decl" @compiler_2fprompt_3aDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/prompt:Decl"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/prompt:Decl" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/prompt:Decl" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/prompt:Decl" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/prompt:Decl" %t14, i64 %a3, 3
  store %"compiler/prompt:Decl" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:Decl", ptr %rv
  ret %"compiler/prompt:Decl" %rr
}

define dso_local void @compiler_2fprompt_3aSession_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"compiler/eval:Snapshot"
  %l7 = alloca { ptr, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca %"compiler/cells:Worker"
  %l11 = alloca %"compiler/build:Config"
  %l12 = alloca { i64, ptr }
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca %"compiler/eval:Snapshot"
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i64
  %l45 = alloca %"compiler/cells:Worker"
  %l47 = alloca %"compiler/build:Config"
  %l48 = alloca %"compiler/prompt:Session"
  %t82 = alloca %"compiler/eval:Snapshot", align 8
  %t193 = alloca %"compiler/build:Config", align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l14, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l14, !tbaa !24
  br label %bb2
bb2:
  %t9 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v1)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l18
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l17
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t14, ptr %l16, !tbaa !27
  br label %bb8
bb4:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_errpay_pop()
  br label %bb6
bb6:
  br label %bb7
bb7:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb8
bb8:
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = load i64, ptr %l14
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call ptr @__olang_held_alloc(ptr %t27, i64 %t25)
  call void @olang_textcopy(ptr %t28, ptr %t21, i64 %t22)
  %t29 = getelementptr i8, ptr %t28, i64 %t22
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  %t34 = call ptr @__olang_scope_hold(ptr %v1)
  %t35 = ptrtoint ptr %t34 to i64
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = call ptr @__olang_region_make(ptr %v1)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l23
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2ector(ptr %t41, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l25
  br label %bb11
bb11:
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e3
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load i64, ptr %l23
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = call ptr @__olang_region_or(ptr %t49, ptr null)
  %t51 = call ptr @__olang_region_home(ptr %t50)
  %t52 = icmp ne ptr %t51, null
  %t53 = select i1 %t52, ptr %t51, ptr null
  call void @__olang_region_settle_in(ptr %t46, ptr %t53)
  br label %bb13
bb13:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l4
  %t55 = call ptr @__olang_scope_hold(ptr %v1)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l27, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = call ptr @__olang_region_make(ptr %v1)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l27, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l27
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %t62, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l29
  br label %bb16
bb16:
  %t64 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e4
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load i64, ptr %l27
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = call ptr @__olang_region_or(ptr %t70, ptr null)
  %t72 = call ptr @__olang_region_home(ptr %t71)
  %t73 = icmp ne ptr %t72, null
  %t74 = select i1 %t73, ptr %t72, ptr null
  call void @__olang_region_settle_in(ptr %t67, ptr %t74)
  br label %bb18
bb18:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l5
  %t76 = call ptr @__olang_scope_hold(ptr %v1)
  %t77 = ptrtoint ptr %t76 to i64
  store i64 %t77, ptr %l31, !tbaa !24
  %t78 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e5
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t80 = call ptr @__olang_region_make(ptr %v1)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l31, !tbaa !24
  br label %bb20
bb20:
  %t83 = load i64, ptr %l31
  %t84 = inttoptr i64 %t83 to ptr
  call void @compiler_2feval_3aSnapshot_2ector(ptr %t82, ptr %t84)
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %t82, i64 232, i1 false)
  br label %bb21
bb21:
  %t85 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e5
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t87 = load i64, ptr %l31
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 5
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = call ptr @__olang_region_or(ptr %t92, ptr null)
  %t94 = call ptr @__olang_region_home(ptr %t93)
  %t95 = icmp ne ptr %t94, null
  %t96 = select i1 %t95, ptr %t94, ptr null
  %t97 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 5
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t97, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t96
  %t105 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 5
  %t106 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t105, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = call ptr @__olang_region_or(ptr %t108, ptr null)
  %t110 = call ptr @__olang_region_home(ptr %t109)
  %t111 = icmp ne ptr %t110, null
  %t112 = select i1 %t111, ptr %t110, ptr %t104
  %t113 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 4
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t113, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = call ptr @__olang_region_home(ptr %t117)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr %t112
  %t121 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 3
  %t122 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = call ptr @__olang_region_or(ptr %t124, ptr null)
  %t126 = call ptr @__olang_region_home(ptr %t125)
  %t127 = icmp ne ptr %t126, null
  %t128 = select i1 %t127, ptr %t126, ptr %t120
  %t129 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 2
  %t130 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t129, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = call ptr @__olang_region_home(ptr %t133)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, ptr %t134, ptr %t128
  %t137 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 1
  %t138 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t137, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = call ptr @__olang_region_or(ptr %t140, ptr null)
  %t142 = call ptr @__olang_region_home(ptr %t141)
  %t143 = icmp ne ptr %t142, null
  %t144 = select i1 %t143, ptr %t142, ptr %t136
  %t145 = getelementptr %"compiler/eval:Snapshot", ptr %l33, i32 0, i32 0
  %t146 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t145, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = call ptr @__olang_region_home(ptr %t149)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr %t144
  call void @__olang_region_settle_in(ptr %t88, ptr %t152)
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l33, i64 232, i1 false)
  store { ptr, ptr } zeroinitializer, ptr %l7
  %t153 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v1, ptr %v1, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d164, i32 0, i32 1) })
  %t154 = extractvalue { i32, { i64, ptr } } %t153, 1
  %t155 = extractvalue { i32, { i64, ptr } } %t153, 0
  store i32 %t155, ptr %l37
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb25, label %ok.157, !prof !99
ok.157:
  store { i64, ptr } %t154, ptr %l36
  br label %bb24
bb24:
  %t158 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t158, ptr %l35, !tbaa !27
  br label %bb29
bb25:
  %t159 = load i32, ptr %l37, !tbaa !23
  %t160 = ashr i32 %t159, 16
  %t162 = icmp eq i32 %t160, 1
  store i1 %t162, ptr %l39, !tbaa !21
  %t163 = load i32, ptr %l37, !tbaa !23
  %t164 = ashr i32 %t163, 16
  %t166 = icmp eq i32 %t164, 1
  br i1 %t166, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb29
bb29:
  %t168 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v1, { i64, ptr } %t168, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d166, i32 0, i32 1) })
  store i1 %t169, ptr %l42
  br label %bb30
bb30:
  %t170 = load i1, ptr %l42, !tbaa !21
  store i1 %t170, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  %t171 = call ptr @__olang_scope_hold(ptr %v1)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l43, !tbaa !24
  %t173 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e9
  br i1 %t173, label %bb31, label %bb32
bb31:
  %t175 = call ptr @__olang_region_make(ptr %v1)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l43, !tbaa !24
  br label %bb32
bb32:
  %t177 = load i64, ptr %l43
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = call %"compiler/cells:Worker" @compiler_2fcells_3aWorker_2ector(ptr %t178, i1 false)
  store %"compiler/cells:Worker" %t179, ptr %l45
  br label %bb33
bb33:
  %t180 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aSession_2e9
  br i1 %t180, label %bb34, label %bb35
bb34:
  %t182 = load i64, ptr %l43
  %t183 = inttoptr i64 %t182 to ptr
  %t184 = getelementptr %"compiler/cells:Worker", ptr %l45, i32 0, i32 8
  %t185 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t184, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = call ptr @__olang_region_home(ptr %t188)
  %t190 = icmp ne ptr %t189, null
  %t191 = select i1 %t190, ptr %t189, ptr null
  call void @__olang_region_settle_in(ptr %t183, ptr %t191)
  br label %bb35
bb35:
  %t192 = load %"compiler/cells:Worker", ptr %l45
  store %"compiler/cells:Worker" %t192, ptr %l10
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t193, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t193, i64 720, i1 false)
  br label %bb36
bb36:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l47, i64 720, i1 false)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d167, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t194 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 0
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %t194, !tbaa !29
  %t196 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 1
  %t197 = load i64, ptr %l2, !tbaa !24
  store i64 %t197, ptr %t196, !tbaa !24
  %t198 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 2
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t199, ptr %t198, !tbaa !27
  %t200 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 3
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %t200
  %t202 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 4
  %t203 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %t202
  %t204 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 5
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %l6, i64 232, i1 false)
  %t205 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 6
  %t206 = load { ptr, ptr }, ptr %l7
  store { ptr, ptr } %t206, ptr %t205
  %t207 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 7
  %t208 = load i1, ptr %l8, !tbaa !21
  store i1 %t208, ptr %t207, !tbaa !21
  %t209 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 8
  %t210 = load i1, ptr %l9, !tbaa !21
  store i1 %t210, ptr %t209, !tbaa !21
  %t211 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 9
  %t212 = load %"compiler/cells:Worker", ptr %l10
  store %"compiler/cells:Worker" %t212, ptr %t211
  %t213 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 10
  call void @llvm.memmove.p0.p0.i64(ptr %t213, ptr %l11, i64 720, i1 false)
  %t214 = getelementptr %"compiler/prompt:Session", ptr %l48, i32 0, i32 11
  %t215 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t215, ptr %t214, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 1152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/prompt:program" @compiler_2fprompt_3aprogram_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/prompt:program"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t8)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l6
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l4
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/text:StringBuilder", ptr %l6, i32 0, i32 0
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = call ptr @__olang_region_or(ptr %t17, ptr null)
  %t19 = call ptr @__olang_region_home(ptr %t18)
  %t20 = icmp ne ptr %t19, null
  %t21 = select i1 %t20, ptr %t19, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t21)
  br label %bb5
bb5:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t22, ptr %l0
  %t23 = call ptr @__olang_scope_hold(ptr %v0)
  %t24 = ptrtoint ptr %t23 to i64
  store i64 %t24, ptr %l8, !tbaa !24
  %t25 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e1
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = call ptr @__olang_region_make(ptr %v0)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l8
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t30, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l10
  br label %bb8
bb8:
  %t32 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e1
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l8
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = call ptr @__olang_region_or(ptr %t38, ptr null)
  %t40 = call ptr @__olang_region_home(ptr %t39)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t35, ptr %t42)
  br label %bb10
bb10:
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l1
  %t44 = call ptr @__olang_scope_hold(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l12, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e2
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = call ptr @__olang_region_make(ptr %v0)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l12, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l12
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t51, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l14
  br label %bb13
bb13:
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e2
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load i64, ptr %l12
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = call ptr @__olang_region_or(ptr %t59, ptr null)
  %t61 = call ptr @__olang_region_home(ptr %t60)
  %t62 = icmp ne ptr %t61, null
  %t63 = select i1 %t62, ptr %t61, ptr null
  call void @__olang_region_settle_in(ptr %t56, ptr %t63)
  br label %bb15
bb15:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l2
  %t65 = call ptr @__olang_scope_hold(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l16, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e3
  br i1 %t67, label %bb16, label %bb17
bb16:
  %t69 = call ptr @__olang_region_make(ptr %v0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  %t71 = load i64, ptr %l16
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t72, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l18
  br label %bb18
bb18:
  %t74 = load i1, ptr @olang_2esole_2ecompiler_2fprompt_3aprogram_2e3
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load i64, ptr %l16
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18, i32 0, i32 0
  %t79 = load { i64, ptr }, ptr %t78
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = call ptr @__olang_region_or(ptr %t80, ptr null)
  %t82 = call ptr @__olang_region_home(ptr %t81)
  %t83 = icmp ne ptr %t82, null
  %t84 = select i1 %t83, ptr %t82, ptr null
  call void @__olang_region_settle_in(ptr %t77, ptr %t84)
  br label %bb20
bb20:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t86 = load %"std/prelude/text:StringBuilder", ptr %l0
  %t87 = insertvalue %"compiler/prompt:program" undef, %"std/prelude/text:StringBuilder" %t86, 0
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  %t89 = insertvalue %"compiler/prompt:program" %t87, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, 1
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t91 = insertvalue %"compiler/prompt:program" %t89, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, 2
  %t93 = insertvalue %"compiler/prompt:program" %t91, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, 3
  store %"compiler/prompt:program" %t93, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/prompt:program", ptr %rv
  ret %"compiler/prompt:program" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"olang - :help for help, :quit to leave\0A" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e8 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2etable_2eI32_7cstd_2fio_3aDescriptor = linkonce_odr constant [4 x ptr] [ptr @olang_2etypeid_2eI32, ptr @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor, ptr @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0]
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c":quit" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":q" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler__2fprompt__2ecellRows_2elocal_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c": error" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": warning" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2ftext_3aStringBuilder_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c":set vi" }>, align 8
@.d12 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c":set emacs" }>, align 8
@.d13 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c":set vi" }>, align 8
declare void @__olang_errpay_pop()
@.d14 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"cannot remember the keys chosen\0A" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c":help" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c":type " }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c":load " }>, align 8
@.d19 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cannot read " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d21 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unknown command " }>, align 8
@.d22 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" - :help lists them\0A" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3acell_2e0 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"cell" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
@olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2eCell_2elocal_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aDecl_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aDecl_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aDecl_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aReply_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2fprompt_3aReply_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aReply_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aReply_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aReply_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aReply_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aReply_2e8 = weak hidden constant i1 false
@.d25 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c" is let go: its type is not laid out as it was\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2e0 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fprompt_3aReply(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/prompt:Reply"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 144, i1 false)
  %t2 = getelementptr %"compiler/prompt:Reply", ptr %l1, i32 0, i32 8
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/prompt:Reply", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

@olang_2esole_2ecompiler_2fprompt_3acell_2e1 = weak hidden constant i1 false
@.d26 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olangType := (" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d29 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"olangType" }>, align 8
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @__olang_scope_or(ptr, ptr)
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2fprompt_3aSession_2e11 = weak hidden constant i1 false
@.d30 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"cell probe" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcond_3aConsts(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/cond:Consts"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 256, i1 false)
  %t2 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 0
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 1
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 2
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 3
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 4
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 5
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 6
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 7
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/cond:Consts", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e20 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03 = weak hidden constant i1 false
@.d33 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"OLANG_CELLS_KEEP" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"__" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aValue_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aValue_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aValue_2e5 = weak hidden constant i1 false
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aValue_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2ekeptLocals_2elocal_2e9 = weak hidden constant i1 false
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d44 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": it does not check " }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"the library '" }>, align 8
@.d49 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"' cannot be loaded: " }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flower_3aLowerer_2e20 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2e2 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_51(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_52(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d53 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": it does not judge " }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler_2feval_3aMachine_2e5 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_H6f71158bb7f05bccd7cf814e6c677229(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"olang" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d60 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"export fn " }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
@__olang_empty_array = external constant [16 x i64]
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d62 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olangShownMime" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olangShownData" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" is let go: " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d68 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d71 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" is let go: " }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aSession_2e3 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aSession_2e4 = weak hidden constant i1 false
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670 = weak hidden constant i1 false
@.d75 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/cell" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d77 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"compiling" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"olang: the cell cannot be built\0A" }>, align 8
@.d80 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"running" }>, align 8
@.d81 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"cell run" }>, align 8
@.d82 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"olang: the session's worker ended, and the values it kept with it\0A" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"this compiler builds no cells" }>, align 8
@olang_2esole_2ecompiler__2fprompt__2ecompiler__2fprompt__3aSession__2estartWorker_2elocal_2e1 = weak hidden constant i1 false
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"there is no clang to build them with" }>, align 8
@.d90 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"they are built for another machine" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aSession_2e2 = weak hidden constant i1 false
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d93 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aConsts_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e28 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e30 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e34 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e35 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e40 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbuild_3aConfig_2e41 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aSession_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcells_3aWorker_2e8 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2e0 = weak hidden constant i1 false
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang: the cells are interpreted: " }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d97 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d98 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d99 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d100 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" = unreachable \22a value the session keeps\22" }>, align 8
@.d101 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d102 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" = unreachable \22a value the cell keeps\22" }>, align 8
@.d103 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" mut String = \22\22" }>, align 8
@.d104 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d105 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"() ? {" }>, align 8
@.d106 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\0AolangShownValue := (" }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d108 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" = $olangShownValue\0A" }>, align 8
@.d109 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"(olangShownValue)\0A}" }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d111 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ~ " }>, align 8
@.d112 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d114 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"export" }>, align 8
@.d115 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d116 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d117 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d118 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d120 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c": error" }>, align 8
@.d121 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d122 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": warning" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d124 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"warning[M5a]" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d129 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d130 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"olang: the prompt cannot run this: " }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fprompt__2eimportName_2elocal_2e4 = weak hidden constant i1 false
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @compiler_2fprompt_2eOpen_fv_fn_28std_2fprelude_2ftext_3aString_26_29_20Bool(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %r = call i1 @compiler_2fprompt_2eOpen(ptr %v0, { i64, ptr } %a0)
  ret i1 %r
}

@.d139 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"it holds a function value or an 'any', whose code went with its cell - a function declared with 'fn' is kept" }>, align 8
@.d140 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"it holds a generational instance" }>, align 8
@.d141 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"it holds a reference to a global's storage" }>, align 8
@.d142 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"its storage is gone" }>, align 8
@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d144 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d146 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d147 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c">>> " }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"... " }>, align 8
@olang_2esole_2ecompiler_2fscan_3ascanner_2e0 = weak hidden constant i1 false
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"interrupted" }>, align 8
@.d151 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"interrupted" }>, align 8
@.d152 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"exited " }>, align 8
@.d153 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"the cell ended the program with status " }>, align 8
@.d154 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"signal " }>, align 8
@.d155 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"the cell's run crashed (signal " }>, align 8
@.d156 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d157 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c" - the session's values are as they were before the cell\0A" }>, align 8
@.d158 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd() #0 {
entry:
  %l0 = alloca %"<poll.h>:pollfd"
  %rv = alloca %"<poll.h>:pollfd"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %t1)
  store %"<poll.h>:pollfd" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<poll.h>:pollfd", ptr %l0
  store %"<poll.h>:pollfd" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<poll.h>:pollfd", ptr %rv
  ret %"<poll.h>:pollfd" %rr
}

declare i32 @poll(ptr, i64, i32)
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d163 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"/olang-prompt.olang" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aSession_2e5 = weak hidden constant i1 false
@.d164 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_CELLS" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"interpret" }>, align 8
@.d167 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fprompt_3aprogram_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aprogram_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aprogram_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprompt_3aprogram_2e3 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@olang_2etypeid_2eI32 = linkonce_odr constant i8 0
define linkonce_odr void @olang_2eanyrender_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t6 = call i64 @__olang_fmt_i64(ptr %t5, i64 %t4)
  call void @__olang_sb_add(ptr %v0, i64 %t6)
  br label %ret
ret:
  ret void
}

define linkonce_odr void @olang_2eanyrender_2etop_2eI32_7cstd_2fio_3aDescriptor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !tbaa !23
  %t3 = sext i32 %t2 to i64
  %t4 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t5 = call i64 @__olang_fmt_i64(ptr %t4, i64 %t3)
  call void @__olang_sb_add(ptr %v0, i64 %t5)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 48
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/typed:Plan", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 584
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/typed:Plan", ptr %t14, i64 %t12
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 584, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 584, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 584, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 12
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %t27)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t31 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  %t32 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 23
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 584, i1 false)
  br label %ret
ret:
  ret void
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
declare ptr @__olang_scope_mine_slow(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i1 @std_2fos_2eIsTerminal(i32 %a0)
declare void @compiler_2fprompt_2esay(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2flineedit_2eViChosen()
declare i1 @compiler_2fpaint_2eWanted(i32 %a0)
declare void @compiler_2flineedit_3aEditor_2ector(ptr %out, ptr %v0, i1 %a0, i1 %a1, i64 %a2)
declare { i64, ptr } @compiler_2flineedit_2eHistoryPath(ptr %v0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2estd_2fio_2eStdin = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"std/io:Lines" @std_2fio_3aLines_2ector(ptr %v0, ptr %v1, { ptr, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3b31a6a49e369ce3_e623b02dcf14b57 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2flineedit_2eChoose(i1 %a0)
declare void @compiler_2fprompt_2esayErr(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fprompt_2eHelpText = external constant <{ [8 x i8], ptr }>
@olang_loc_2254b4c3038ee739_37193e0925765975 = external constant [0 x i8]
@olang_loc_33ed6a85eb60430c_36f1732cc3964218 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/prompt:cell" @compiler_2fprompt_3acell_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2epieces(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eLen_3ccompiler_2fprompt_3aitem_3e(ptr %v0, ptr %a0)
declare %"compiler/prompt:item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2eAt_3ccompiler_2fprompt_3aitem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aitem_3e_2ePush_3ccompiler_2fprompt_3aitem_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/prompt:item" %a1)
declare void @compiler_2fprompt_3aReply_2ector(ptr %out, ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eLen_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %a0)
declare %"compiler/prompt:Decl" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eAt_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2ePush_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/prompt:Decl" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eLen_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %a0)
declare %"compiler/prompt:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eAt_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2ePush_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/prompt:Value" %a1)
@olang_loc_e8da02ec0656f58f_3ce6a8f236b380bb = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eClear_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNameLines(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare void @compiler_2fviews_3aKept_2ector(ptr %out, ptr %v0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, ptr %a2)
declare void @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eEnd(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2ecellDir(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/prompt:Value" @compiler_2fprompt_3aValue_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2estoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @compiler_2fprompt_2ecellBody(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare %"compiler/check:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eAt_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eAt_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_3aFree_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinCount(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinPlan(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ePush_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinOwn(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinBody(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eTwinStable(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eGenOkNow(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H39bf208114dde5103bad7bf7476536d8(ptr %v0, ptr %a0)
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H6d56ff767ac7b72ad0cd898fedbf4594(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2finterp_2ecompiler_2finterp_3aExec_2eNeed(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eLayout(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c095982bd76c0dde_ab739287ff4badb2 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2erestore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2fprompt_2eKeepPrefix = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eMarkSet(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, [5 x i64] } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eInitGlobals(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a211c8d235081e84_d100b21f1be88968 = external constant [0 x i8]
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eStopText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [5 x i64] } %a1, i64 %a2, ptr %a3)
declare { i64, ptr } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eTraceText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fprompt_2eShownName = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2eClear(ptr %v0, ptr %a0)
declare { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eSave(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3)
declare i1 @compiler_2fprompt_2eisGlobal(ptr %v0, ptr %a0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eSaveRegs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEndProgram(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2fcells_3aPlan_2ector(ptr %out, ptr %v0)
declare { i64, ptr } @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eglobalSym(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fspin_2eBegin(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcells_2eBuild(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, ptr %v8, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %a6, { i64, ptr } %a7, ptr %a8)
declare void @compiler_2fspin_2eEnd()
declare void @compiler_2fspin_2eRetitle(ptr %v0, { i64, ptr } %a0)
declare %"compiler/cells:Outcome" @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2c, ptr %a2e)
declare i1 @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eRunning(ptr %v0, ptr %a0)
@G_2ecompiler_2fcells_2eBuilder = external global { ptr, ptr }
@olang_loc_4b18163218a04cd9_3c47abda6897b34d = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ePid()
declare void @compiler_2fcells_2eConfig(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/cells:Worker" @compiler_2fcells_3aWorker_2ector(ptr %v0, i1 %a0)
declare { i64, ptr } @compiler_2fcells_2ecompiler_2fcells_3aWorker_2eStart(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fprompt_2eSynthetic = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fprompt_2eRichDecls = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fprompt_2eSayDecl = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fprompt_2eCellName = external constant <{ [8 x i8], ptr }>
@olang_loc_10924d50905b82ca_4ba1203e047902e = external constant [0 x i8]
@G_2ecompiler_2fprompt_2eRichName = external constant <{ [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2fprompt_2eSayShown = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fprompt_2eCellEntry = external constant <{ [8 x i8], ptr }>
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2fprompt_2eword(ptr %v0, ptr %v1, { i64, ptr } %a0, %"compiler/token:Token" %a1)
@olang_loc_d7f38a87e2333c97_c2add44d049df38b = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_7f01f42c2e703e66_b0b354f2667b155a = external constant [0 x i8]
@olang_loc_a2264893ec9e865a_32f4c01046e050a6 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_e14f50e721aea7b7_1df1d94fb9afe903 = external constant [0 x i8]
@olang_loc_7f83270da91fdacc_101e1b43d440f4e8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fprompt_2eopens(i32 %a0)
declare i1 @compiler_2fprompt_2ecloses(i32 %a0)
declare { i32, { i64, ptr } } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1c, ptr %a1e)
@olang_loc_b14cd07759368a94_615e274dad3004e0 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_da36ef8b95c68801_28fd7452ffcab23d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_2b63874b1fcbb202_7b98d930a28c0ade = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_77d28f78d720beff_d78a7ce3569603db = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aLines_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fprompt_2eOpen(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_b2828226e705177d_4f9f00f8ce972671 = external constant [0 x i8]
@olang_loc_ad688bb7ba0b3d20_99d8bf61b60a8404 = external constant [0 x i8]
@olang_loc_84114044f9b61514_f9c7bee38045a068 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fpaint_2eDiagnostics(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fpaint_2eSource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fio_2estd_2fio_3aLines_2eBuffered(ptr %v0, ptr %a0)
@G_2e_3cpoll_2eh_3e_2ePOLLIN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare void @compiler_2feval_3aSnapshot_2ector(ptr %out, ptr %v0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
