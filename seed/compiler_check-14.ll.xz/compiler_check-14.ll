; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:altsCovered" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" = type { %"compiler/generic:Origin", i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i64, i1, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, { i64, ptr }, i64, i1, i64 }
%"compiler/check:errNarrow" = type { { i64, ptr }, i32, i64, i64, i1, i64 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:loopUse" = type { %"compiler/source:Span", i64, { i64, ptr } }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:heldCand" = type { i64, i64, i64 }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/check:UnrollAsk" = type { { i64, ptr }, { i64, ptr }, i64, i32 }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l35 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca { i64, [3 x i64] }
  %l43 = alloca %"compiler/diagmsg:Msg"
  %l44 = alloca i64
  %l48 = alloca ptr
  %l52 = alloca i32
  %l57 = alloca i1
  %l63 = alloca i1
  %l69 = alloca i1
  %l73 = alloca i1
  %l78 = alloca i32
  %l84 = alloca ptr
  %l86 = alloca { i64, [3 x i64] }
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %s0 = alloca %olang.scope
  %t87 = alloca { i64, [3 x i64] }, align 8
  %t187 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 12
  %t10 = load i64, ptr %t9, !tbaa !24
  store i64 %t10, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l15
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t44, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t46, ptr %l25
  br label %bb2
bb2:
  %t47 = load ptr, ptr %l19, !tbaa !29
  %t48 = load i64, ptr %l20, !tbaa !24
  %t49 = load i32, ptr %l25, !tbaa !23
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t47, i64 %t48, i32 %t49)
  store i64 %t50, ptr %l26
  br label %bb3
bb3:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb4, label %bb5
bb4:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 115
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBefore(ptr %v0, ptr %t65, i64 %t69)
  store i1 %t72, ptr %l35
  br label %bb6
bb5:
  br label %bb12
bb6:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb7, label %bb8
bb7:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 4
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l40, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t90 = insertvalue { i64 } undef, i64 %t86, 0
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  store { i64 } %t90, ptr %t91
  %t92 = load { i64, [3 x i64] }, ptr %t87
  store { i64, [3 x i64] } %t92, ptr %l42
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoMain(ptr %v0)
  store %"compiler/diagmsg:Msg" %t93, ptr %l43
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t94 = load ptr, ptr %l40, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l42
  %t96 = load %"compiler/diagmsg:Msg", ptr %l43
  %t97 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t94, { i64, [3 x i64] } %t95, %"compiler/diagmsg:Msg" %t96)
  store i64 %t97, ptr %l44
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i64, ptr %l3, !tbaa !24
  %t105 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store ptr %t105, ptr %l48
  br label %bb13
bb13:
  %t106 = load ptr, ptr %l48, !tbaa !29
  store ptr %t106, ptr %l4, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t111 = load i64, ptr %l3, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l52
  br label %bb14
bb14:
  %t115 = load i32, ptr %l52, !tbaa !23
  store i32 %t115, ptr %l5, !tbaa !23
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Func", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb17
bb16:
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Func", ptr %t125, i32 0, i32 3
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Sig", ptr %t128, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = icmp sgt i64 %t133, 0
  store i1 %t135, ptr %l57, !tbaa !21
  br label %bb17
bb17:
  %t137 = load i1, ptr %l57, !tbaa !21
  br i1 %t137, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb20
bb19:
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Func", ptr %t138, i32 0, i32 3
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Sig", ptr %t141, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t148 = icmp sgt i64 %t146, 0
  store i1 %t148, ptr %l63, !tbaa !21
  br label %bb20
bb20:
  %t150 = load i1, ptr %l63, !tbaa !21
  br i1 %t150, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb23
bb22:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Func", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Sig", ptr %t154, i32 0, i32 4
  %t157 = load i1, ptr %t156, !tbaa !21
  store i1 %t157, ptr %l69, !tbaa !21
  br label %bb23
bb23:
  %t159 = load i1, ptr %l69, !tbaa !21
  br i1 %t159, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb27
bb25:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l5, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l78
  br label %bb26
bb26:
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t171 = load i32, ptr %l78, !tbaa !23
  %t173 = icmp ne i32 %t171, %t170
  store i1 %t173, ptr %l73, !tbaa !21
  br label %bb27
bb27:
  %t175 = load i1, ptr %l73, !tbaa !21
  br i1 %t175, label %bb28, label %bb29
bb28:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/load:Loader", ptr %t182, i32 0, i32 4
  %t185 = load ptr, ptr %t184, !tbaa !29
  store ptr %t185, ptr %l84, !tbaa !29
  %t186 = load i64, ptr %l2, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 0
  store i64 1, ptr %t188
  %t190 = insertvalue { i64 } undef, i64 %t186, 0
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 1
  store { i64 } %t190, ptr %t191
  %t192 = load { i64, [3 x i64] }, ptr %t187
  store { i64, [3 x i64] } %t192, ptr %l86
  %t193 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMainSignature(ptr %v0)
  store %"compiler/diagmsg:Msg" %t193, ptr %l87
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t194 = load ptr, ptr %l84, !tbaa !29
  %t195 = load { i64, [3 x i64] }, ptr %l86
  %t196 = load %"compiler/diagmsg:Msg", ptr %l87
  %t197 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t194, { i64, [3 x i64] } %t195, %"compiler/diagmsg:Msg" %t196)
  store i64 %t197, ptr %l88
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l23 = alloca i32
  %l26 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l54 = alloca i1
  %l65 = alloca i32
  %l81 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l96 = alloca ptr
  %rv = alloca ptr
  %t75 = alloca { i64, [5 x i64] }, align 8
  %t128 = alloca { i64, [4 x i64] }, align 8
  %t140 = alloca { i64, [4 x i64] }, align 8
  %t153 = alloca { i64, [5 x i64] }, align 8
  %t192 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i32, ptr %l16, !tbaa !23
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t13, ptr %l17
  br label %bb2
bb2:
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t15 = load i64, ptr %l17, !tbaa !24
  %t17 = and i64 %t15, %t14
  store i64 %t17, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l23
  br label %bb3
bb3:
  %t27 = load i32, ptr %l23, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 44
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l26
  br label %bb4
bb4:
  %t33 = load i64, ptr %l26, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 44
  %t37 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 44
  store ptr %t42, ptr %l31, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  %t45 = load i32, ptr %l3, !tbaa !23
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t43, %"compiler/source:Span" %t44, i32 %t45, i64 0)
  store ptr %t49, ptr %l35
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t50, ptr %t51)
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = load i64, ptr %l5, !tbaa !24
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t57, i32 %t58, i64 %t59)
  store i32 %t63, ptr %l41
  br label %bb8
bb8:
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l42
  store i32 %t64, ptr %l43, !tbaa !23
  store i32 43, ptr %l44
  store i32 %a4, ptr %l45
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 44
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t70, i64 %t71)
  store { i64, ptr } %t74, ptr %l49
  br label %bb9
bb9:
  store { i64, [5 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 0
  store i64 9, ptr %t76
  %t77 = load %"compiler/source:Span", ptr %l42
  %t78 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t77, 0
  %t79 = load i32, ptr %l43, !tbaa !23
  %t80 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t78, i32 %t79, 1
  %t81 = load i32, ptr %l44, !range !{i32 0, i32 52}
  %t82 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t80, i32 %t81, 2
  %t83 = load i32, ptr %l45, !range !{i32 0, i32 4}
  %t84 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t82, i32 %t83, 3
  %t85 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t86 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t84, { i64, ptr } %t85, 4
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t86, ptr %t87
  %t88 = load { i64, [5 x i64] }, ptr %t75
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t88, ptr %t90
  store ptr %t90, ptr %l9, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t96, ptr %l54
  br label %bb10
bb10:
  %t97 = load i1, ptr %l54, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb11, label %bb12
bb11:
  %t100 = load ptr, ptr %l9, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t102 = load i32, ptr %l6, !tbaa !23
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  br i1 %t106, label %bb14, label %bb15
bb14:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l3, !tbaa !23
  %t115 = load i64, ptr %l5, !tbaa !24
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t113, i32 %t114, i64 %t115)
  store i32 %t119, ptr %l65
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t120 = load i32, ptr %l65, !tbaa !23
  %t121 = load %"compiler/source:Span", ptr %l1
  %t123 = load %"compiler/source:Span", ptr %l1
  %t124 = load i32, ptr %l3, !tbaa !23
  %t125 = load %"compiler/source:Span", ptr %l1
  %t126 = load i32, ptr %l6, !tbaa !23
  %t127 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 0
  store i64 2, ptr %t129
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t125, 0
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t126, 1
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t127, 2
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [4 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t137, ptr %t139
  store { i64, [4 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t123, 0
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t143, i32 %t124, 1
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t145, ptr %t139, 2
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t147, i64 0, 3
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t148, ptr %t149
  %t150 = load { i64, [4 x i64] }, ptr %t140
  %t152 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t150, ptr %t152
  store { i64, [5 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 0
  store i64 3, ptr %t154
  %t156 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t121, 0
  %t158 = insertvalue { %"compiler/source:Span", i32, ptr } %t156, i32 %t120, 1
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } %t158, ptr %t152, 2
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t160, ptr %t161
  %t162 = load { i64, [5 x i64] }, ptr %t153
  %t164 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t162, ptr %t164
  store ptr %t164, ptr %rv
  br label %ret
bb17:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l81, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l3, !tbaa !23
  %t176 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l84
  br label %bb18
bb18:
  %t177 = load ptr, ptr %l81, !tbaa !29
  %t178 = load i32, ptr %l84, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t179, ptr %l85
  br label %bb19
bb19:
  %t180 = load i32, ptr %l85, !range !{i32 0, i32 33}
  %t182 = trunc i64 19 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb20, label %bb21
bb20:
  %t185 = load ptr, ptr %l9, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  %t189 = load %"compiler/source:Span", ptr %l1
  %t190 = load i32, ptr %l3, !tbaa !23
  %t191 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 0
  store i64 2, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t189, 0
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, i32 %t190, 1
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } %t197, ptr %t191, 2
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t199, ptr %t200
  %t201 = load { i64, [4 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t201, ptr %t203
  %t207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t187, %"compiler/source:Span" %t188, ptr %t203)
  store ptr %t207, ptr %l96
  br label %bb23
bb23:
  %t208 = load ptr, ptr %l96, !tbaa !29
  store ptr %t208, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l83 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb10, label %bb11
bb10:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb12, label %bb13
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb15
bb15:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb16:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Promote", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t62, ptr %l35
  br label %bb22
bb22:
  %t63 = load i1, ptr %l35, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 0
  %t77 = load %"compiler/source:Span", ptr %t76
  store %"compiler/source:Span" %t77, ptr %l4
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Call", ptr %t85, i32 0, i32 1
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Call", ptr %t94, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l52
  br label %bb31
bb30:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb33
bb31:
  %t104 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t104, ptr %l54
  %t107 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l52, ptr %l54)
  store i1 %t107, ptr %l56
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l48, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l48, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb34:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t111 = load ptr, ptr %l57, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 18}
  %t117 = icmp eq i64 %t115, 14
  store i1 %t117, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l58, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Try", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l6, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Try", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t142 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i1 %t142, ptr %l72
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb42:
  %t143 = load i1, ptr %l72, !tbaa !21
  store i1 %t143, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t144 = load i1, ptr %l67, !tbaa !21
  store i1 %t144, ptr %rv
  br label %ret
bb44:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t146 = load ptr, ptr %l73, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t149 = load ptr, ptr %l73, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 11
  store i1 %t152, ptr %l74, !tbaa !21
  br label %bb46
bb46:
  %t153 = load i1, ptr %l74, !tbaa !21
  br i1 %t153, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  %t154 = load ptr, ptr %l1, !tbaa !29
  store ptr %t154, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t155 = load ptr, ptr %l77, !tbaa !29
  %t156 = icmp ne ptr %t155, null
  br i1 %t156, label %bb49, label %bb50
bb49:
  %t158 = load ptr, ptr %l77, !tbaa !29
  %t159 = load i64, ptr %t158, !range !{i64 0, i64 18}
  %t161 = icmp eq i64 %t159, 13
  store i1 %t161, ptr %l78, !tbaa !21
  br label %bb50
bb50:
  %t162 = load i1, ptr %l78, !tbaa !21
  br i1 %t162, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i1 %t167, ptr %l83
  br label %bb54
bb54:
  %t168 = load i1, ptr %l83, !tbaa !21
  store i1 %t168, ptr %rv
  br label %ret
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  call void @__olang_check_failed(ptr @olang_loc_2fb1f9f5dda04b10_a3bd6c7ca1760a54)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/load:Import"
  %l9 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/load:Import"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 10
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l22
  br label %bb8
bb8:
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/load:Import" %t42, ptr %l27
  br label %bb12
bb12:
  %t43 = load %"compiler/load:Import", ptr %l27
  store %"compiler/load:Import" %t43, ptr %l6
  %t44 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %t49, i64 %t51, ptr %t52, ptr %t53)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb7
bb18:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t62, i64 %t63)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %l28 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 172
  store ptr %t5, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l8, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Heda0e3070e2f5ab051ad1f451edd65eb(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H62ca4e6c77402fbaa86eb0d94ae649ee(ptr %v0, ptr %t17, i64 %t18)
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t21, ptr %l15
  br label %bb7
bb7:
  %t22 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t22, ptr %l4
  store ptr %l1, ptr %l16, !tbaa !29
  %t23 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l4, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l17, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t25)
  store ptr %t27, ptr %l20
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t28, i32 0, i32 4
  %t31 = getelementptr %"compiler/generic:Context", ptr %t30, i32 0, i32 2
  %t32 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l4, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t36 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t31, i32 %t33)
  %t37 = extractvalue { i32, i32 } %t36, 1
  %t38 = extractvalue { i32, i32 } %t36, 0
  store i32 %t38, ptr %l25
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb10, label %ok.40, !prof !99
ok.40:
  store i32 %t37, ptr %l24
  br label %bb9
bb9:
  %t41 = load i32, ptr %l24, !tbaa !23
  store i32 %t41, ptr %l18, !tbaa !23
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i32 -1, ptr %l18, !tbaa !23
  br label %bb12
bb12:
  %t42 = load i32, ptr %l17, !tbaa !23
  %t43 = load i32, ptr %l18, !tbaa !23
  %t44 = call %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %s2, i32 %t42, i32 %t43)
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t44, ptr %l26
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l16, !tbaa !29
  %t46 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v1, ptr %t45, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t46)
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t47)
  store ptr %t49, ptr %l28
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 4
  %t53 = getelementptr %"compiler/generic:Context", ptr %t52, i32 0, i32 2
  %t54 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l4, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l4, i32 0, i32 1
  %t57 = load i32, ptr %t56, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t53, i32 %t55, i32 %t57)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb2
bb18:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l8, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp eq i64 %t25, %t24
  br i1 %t27, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 10
  %t33 = load i32, ptr %t32, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t29, i32 %t33)
  store { i64, ptr } %t36, ptr %l22
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t38 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t37)
  store i1 %t38, ptr %l23
  br label %bb7
bb7:
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l18, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 10
  store ptr %t49, ptr %l27, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t53, i64 %t54)
  store i64 %t57, ptr %l31
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l27, !tbaa !29
  %t59 = load i64, ptr %l31, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t58, i64 %t59)
  store ptr %t60, ptr %l32
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 3
  %t64 = load i1, ptr %t63, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 10
  store ptr %t74, ptr %l39, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l41
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb18
bb16:
  %t78 = load ptr, ptr %l41, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load ptr, ptr %l39, !tbaa !29
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t82, i64 %t81)
  store ptr %t84, ptr %l44
  br label %bb17
bb17:
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t87 = getelementptr %"compiler/load:Module", ptr %t85, i32 0, i32 3
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l35, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l48
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t93, i32 %a3)
  store { i64, ptr } %t97, ptr %l51
  br label %bb22
bb22:
  %t98 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l52, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Func", ptr %t106, i32 0, i32 10
  %t109 = load i32, ptr %t108, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t105, i32 %t109)
  store { i64, ptr } %t112, ptr %l56
  br label %bb23
bb23:
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t120 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t122 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderPrivate(ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t120, { i64, ptr } %t119)
  store %"compiler/diagmsg:Msg" %t122, ptr %l58
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l47, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l48
  %t125 = load %"compiler/diagmsg:Msg", ptr %l58
  %t126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t123, %"compiler/source:Span" %t124, %"compiler/diagmsg:Msg" %t125)
  store i64 %t126, ptr %l59
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/source:Span" %a3, i32 %a4, { i64, ptr } %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/generic:Desc"
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/source:Span"
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l51 = alloca ptr
  %l56 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l102 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l106 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca { i64, ptr }
  %l138 = alloca %"compiler/diagmsg:Msg"
  %l139 = alloca i64
  %l144 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca %"compiler/source:Span"
  %l151 = alloca { i64, ptr }
  %l154 = alloca %"compiler/diagmsg:Msg"
  %l155 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l163 = alloca %"compiler/diagmsg:Msg"
  %l164 = alloca i64
  %l167 = alloca ptr
  %l172 = alloca i32
  %l180 = alloca ptr
  %l183 = alloca i1
  %l187 = alloca %"compiler/generic:Desc"
  %l191 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l193 = alloca %"compiler/source:Span"
  %l197 = alloca %"compiler/generic:Desc"
  %l199 = alloca ptr
  %l202 = alloca i1
  %l206 = alloca %"compiler/generic:Desc"
  %l213 = alloca %"compiler/generic:Desc"
  %l217 = alloca i32
  %l220 = alloca i1
  %l226 = alloca ptr
  %l231 = alloca i32
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca %"compiler/source:Span"
  %l243 = alloca i32
  %l248 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l251 = alloca i32
  %l252 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l259 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/source:Span"
  %l269 = alloca ptr
  %l271 = alloca ptr
  %l276 = alloca i32
  %l279 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i1
  %l290 = alloca i1
  %l291 = alloca i1
  %l299 = alloca ptr
  %l302 = alloca i1
  %l305 = alloca i1
  %l311 = alloca ptr
  %l314 = alloca i1
  %l319 = alloca i32
  %l323 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l327 = alloca { i64, ptr }
  %l329 = alloca %"compiler/diagmsg:Msg"
  %l330 = alloca i64
  %l335 = alloca ptr
  %l340 = alloca ptr
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l18, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t8)
  store ptr %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l20, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l24
  br label %bb2
bb2:
  %t21 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t21, ptr %l7
  %t22 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 9}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t30, ptr %l29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load i32, ptr %l4, !tbaa !23
  %t41 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t34, i64 %t36, i32 %t37)
  store i64 %t41, ptr %l34
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l35, !tbaa !27
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t45 = icmp sle i64 0, 1152921504606846975
  br i1 %t45, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6af63211fe08a219_4bcf48e786826ca5)
  unreachable
bb8:
  %t47 = mul i64 0, 8
  %t48 = insertvalue { i64, ptr } undef, i64 0, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t49, ptr %l38, !tbaa !27
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6af63211fe08a219_4bcf48e786826ca5)
  unreachable
bb10:
  %t52 = icmp sle i64 0, 2305843009213693951
  br i1 %t52, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_31ceea79ef23e30c_3748df63b5867238)
  unreachable
bb12:
  %t54 = mul i64 0, 4
  %t55 = insertvalue { i64, ptr } undef, i64 0, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l28
  %t59 = load %"compiler/source:Span", ptr %l29
  %t60 = load i64, ptr %l34, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t57, %"compiler/source:Span" %t58, %"compiler/source:Span" %t59, i64 %t60, ptr null, { i64, ptr } %t61, { i64, ptr } %t62, { i64, ptr } %t56)
  store ptr %t64, ptr %l42
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_31ceea79ef23e30c_3748df63b5867238)
  unreachable
bb14:
  %t65 = load ptr, ptr %l42, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb15:
  %t66 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 9}
  %t69 = trunc i64 7 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l45, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t73, ptr %l46
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l4, !tbaa !23
  %t78 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l49
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l46
  %t82 = load i32, ptr %l49, !tbaa !23
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v2, ptr %v3, ptr %t80, %"compiler/source:Span" %t81, i32 %t82, { i64, ptr } %t79)
  store ptr %t84, ptr %l51
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l51, !tbaa !29
  store ptr %t85, ptr %rv
  br label %ret
bb20:
  %t86 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t87 = load i32, ptr %t86, !range !{i32 0, i32 9}
  %t89 = trunc i64 4 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i32 %t96, ptr %l56
  br label %bb23
bb22:
  br label %bb37
bb23:
  %t97 = load i32, ptr %l56, !tbaa !23
  store i32 %t97, ptr %l8, !tbaa !23
  %t98 = load i32, ptr %l8, !tbaa !23
  %t100 = icmp slt i32 %t98, 0
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t102 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  store i1 %t105, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t107 = load i1, ptr %l59, !tbaa !21
  br i1 %t107, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l62, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t109, ptr %l63
  %t110 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t110, ptr %l64
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t118 = load i64, ptr %t117, !tbaa !24
  %t122 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t114, i64 %t116, i64 %t118)
  store i32 %t122, ptr %l69
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = load ptr, ptr %l62, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l63
  %t127 = load %"compiler/source:Span", ptr %l64
  %t128 = load i32, ptr %l69, !tbaa !23
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferredCtor(ptr %v0, ptr %v2, ptr %v3, ptr %t125, %"compiler/source:Span" %t126, %"compiler/source:Span" %t127, i32 %t128, { i64, ptr } %t123, i32 %a6)
  store ptr %t131, ptr %l72
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l72, !tbaa !29
  store ptr %t132, ptr %rv
  br label %ret
bb31:
  %t133 = load i32, ptr %l8, !tbaa !23
  %t135 = icmp slt i32 %t133, 0
  br i1 %t135, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t137, %"compiler/source:Span" %t138)
  store ptr %t141, ptr %l77
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t142 = load ptr, ptr %l77, !tbaa !29
  store ptr %t142, ptr %rv
  br label %ret
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l1
  %t145 = load %"compiler/source:Span", ptr %l3
  %t146 = load i32, ptr %l8, !tbaa !23
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v2, ptr %v3, ptr %t143, %"compiler/source:Span" %t144, %"compiler/source:Span" %t145, i32 %t146, { i64, ptr } %t147)
  store ptr %t153, ptr %l83
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l83, !tbaa !29
  store ptr %t154, ptr %rv
  br label %ret
bb37:
  %t155 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t156 = load i32, ptr %t155, !range !{i32 0, i32 9}
  %t158 = trunc i64 0 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 155
  store ptr %t163, ptr %l87, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l4, !tbaa !23
  %t168 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t164, i32 %t165)
  store { i64, ptr } %t168, ptr %l90
  br label %bb40
bb39:
  br label %bb78
bb40:
  %t169 = load ptr, ptr %l87, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t169, { i64, ptr } %t170)
  br label %bb41
bb41:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  %t173 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodMeant(ptr %v0, ptr %v2, ptr %s6, ptr %t171, i32 %t172, { i64, ptr } %t173)
  store { i64, ptr } %t177, ptr %l94
  br label %bb42
bb42:
  %t178 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t178, ptr %l9, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t179, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t181, ptr %l96
  br label %bb43
bb43:
  %t182 = load i1, ptr %l96, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l98, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t186, ptr %l99
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l4, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l102
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t192 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  %t199 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMethod(ptr %s7, ptr %s6, ptr %v0, { i64, ptr } %t198, { i64, ptr } %t199)
  store %"compiler/diagmsg:Msg" %t202, ptr %l105
  br label %bb47
bb47:
  %t203 = load ptr, ptr %l98, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l99
  %t205 = load %"compiler/diagmsg:Msg", ptr %l105
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, %"compiler/diagmsg:Msg" %t205)
  store i64 %t206, ptr %l106
  br label %bb48
bb48:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t207, %"compiler/source:Span" %t208)
  store ptr %t211, ptr %l109
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  %t212 = load ptr, ptr %l109, !tbaa !29
  store ptr %t212, ptr %rv
  br label %ret
bb50:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l110, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l4, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t214, i32 %t215)
  store { i64, ptr } %t218, ptr %l113
  br label %bb51
bb51:
  %t219 = load ptr, ptr %l110, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v0, ptr %s6, ptr %t219, { i64, ptr } %t220)
  store { i64, ptr } %t221, ptr %l114
  br label %bb52
bb52:
  %t222 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t222, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t225, ptr %l116
  br label %bb53
bb53:
  %t226 = load i1, ptr %l116, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb54, label %bb55
bb54:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l3
  %t231 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t229, %"compiler/source:Span" %t230, i32 %t231, i1 false)
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t235, %"compiler/source:Span" %t236)
  store ptr %t239, ptr %l123
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  %t240 = load ptr, ptr %l123, !tbaa !29
  store ptr %t240, ptr %rv
  br label %ret
bb58:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l124, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l4, !tbaa !23
  %t246 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t242, i32 %t243)
  store { i64, ptr } %t246, ptr %l127
  br label %bb59
bb59:
  %t247 = load ptr, ptr %l124, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v0, ptr %s6, ptr %t247, { i64, ptr } %t248, i1 true)
  store { i64, ptr } %t249, ptr %l128
  br label %bb60
bb60:
  %t250 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t250, ptr %l11, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t255 = icmp eq i64 %t253, 0
  br i1 %t255, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l132, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t258, ptr %l133
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l4, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t259, i32 %t260)
  store { i64, ptr } %t263, ptr %l136
  br label %bb63
bb62:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t269, { i64, ptr } %t270)
  store i32 %t273, ptr %l144
  br label %bb66
bb63:
  %t274 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t276 = extractvalue { i64, ptr } %t274, 1
  %t277 = mul i64 %t275, 1
  %t278 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t277)
  call void @llvm.memcpy.p0.p0.i64(ptr %t278, ptr %t276, i64 %t277, i1 false)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t282 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %s9, ptr %v0, { i64, ptr } %t280)
  store %"compiler/diagmsg:Msg" %t282, ptr %l138
  br label %bb64
bb64:
  %t283 = load ptr, ptr %l132, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l133
  %t285 = load %"compiler/diagmsg:Msg", ptr %l138
  %t286 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t283, %"compiler/source:Span" %t284, %"compiler/diagmsg:Msg" %t285)
  store i64 %t286, ptr %l139
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb66:
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t288 = load i32, ptr %l144, !tbaa !23
  %t290 = icmp ne i32 %t288, %t287
  br i1 %t290, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l147, !tbaa !29
  %t293 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t293, ptr %l148
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l4, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t294, i32 %t295)
  store { i64, ptr } %t298, ptr %l151
  br label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l156, !tbaa !29
  %t300 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t300, ptr %l157
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l4, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t301, i32 %t302)
  store { i64, ptr } %t305, ptr %l160
  br label %bb72
bb69:
  %t306 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  %t308 = extractvalue { i64, ptr } %t306, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  %t313 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t316 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %s11, ptr %s6, ptr %v0, { i64, ptr } %t312, { i64, ptr } %t313)
  store %"compiler/diagmsg:Msg" %t316, ptr %l154
  br label %bb70
bb70:
  %t317 = load ptr, ptr %l147, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l148
  %t319 = load %"compiler/diagmsg:Msg", ptr %l154
  %t320 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t317, %"compiler/source:Span" %t318, %"compiler/diagmsg:Msg" %t319)
  store i64 %t320, ptr %l155
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb75
bb72:
  %t321 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  %t323 = extractvalue { i64, ptr } %t321, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  %t328 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t331 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %s12, ptr %s6, ptr %v0, { i64, ptr } %t327, { i64, ptr } %t328)
  store %"compiler/diagmsg:Msg" %t331, ptr %l163
  br label %bb73
bb73:
  %t332 = load ptr, ptr %l156, !tbaa !29
  %t333 = load %"compiler/source:Span", ptr %l157
  %t334 = load %"compiler/diagmsg:Msg", ptr %l163
  %t335 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t332, %"compiler/source:Span" %t333, %"compiler/diagmsg:Msg" %t334)
  store i64 %t335, ptr %l164
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s12)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  %t340 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t336, %"compiler/source:Span" %t337)
  store ptr %t340, ptr %l167
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s6)
  %t341 = load ptr, ptr %l167, !tbaa !29
  store ptr %t341, ptr %rv
  br label %ret
bb78:
  %t342 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t343 = load i32, ptr %t342, !range !{i32 0, i32 9}
  %t345 = trunc i64 1 to i32
  %t346 = icmp eq i32 %t343, %t345
  br i1 %t346, label %bb79, label %bb80
bb79:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l2, !tbaa !29
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store i32 %t352, ptr %l172
  br label %bb81
bb80:
  br label %bb121
bb81:
  %t353 = load i32, ptr %l172, !tbaa !23
  store i32 %t353, ptr %l12, !tbaa !23
  %t354 = load i32, ptr %l12, !tbaa !23
  %t355 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t358 = icmp eq i32 %t354, %t355
  br i1 %t358, label %bb82, label %bb83
bb82:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t360, { i64, ptr } %t361)
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l1
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t364, %"compiler/source:Span" %t365)
  store ptr %t368, ptr %l180
  br label %bb85
bb85:
  %t369 = load ptr, ptr %l180, !tbaa !29
  store ptr %t369, ptr %rv
  br label %ret
bb86:
  %t370 = load i32, ptr %l12, !tbaa !23
  %t372 = icmp sge i32 %t370, 0
  br i1 %t372, label %bb87, label %bb88
bb87:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/check:Checker", ptr %t374, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t378 = load i32, ptr %l12, !tbaa !23
  %t381 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t377, i32 %t378)
  store %"compiler/generic:Desc" %t381, ptr %l187
  br label %bb89
bb88:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb90
bb89:
  %t382 = getelementptr %"compiler/generic:Desc", ptr %l187, i32 0, i32 0
  %t383 = load i64, ptr %t382, !tbaa !24
  %t384 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t387 = icmp eq i64 %t383, %t384
  store i1 %t387, ptr %l183, !tbaa !21
  br label %bb90
bb90:
  %t389 = load i1, ptr %l183, !tbaa !21
  br i1 %t389, label %bb91, label %bb92
bb91:
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l191, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t391, ptr %l192
  %t392 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t392, ptr %l193
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/check:Checker", ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t397 = load i32, ptr %l12, !tbaa !23
  %t400 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t396, i32 %t397)
  store %"compiler/generic:Desc" %t400, ptr %l197
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t401 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t402 = load ptr, ptr %l191, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l192
  %t404 = load %"compiler/source:Span", ptr %l193
  %t405 = load %"compiler/generic:Desc", ptr %l197
  %t407 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFnCall(ptr %v0, ptr %v2, ptr %v3, ptr %t402, %"compiler/source:Span" %t403, %"compiler/source:Span" %t404, %"compiler/generic:Desc" %t405, { i64, ptr } %t401)
  store ptr %t407, ptr %l199
  br label %bb94
bb94:
  %t408 = load ptr, ptr %l199, !tbaa !29
  store ptr %t408, ptr %rv
  br label %ret
bb95:
  %t409 = load i32, ptr %l12, !tbaa !23
  %t411 = icmp sge i32 %t409, 0
  br i1 %t411, label %bb96, label %bb97
bb96:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/check:Checker", ptr %t413, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t417 = load i32, ptr %l12, !tbaa !23
  %t420 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t416, i32 %t417)
  store %"compiler/generic:Desc" %t420, ptr %l206
  br label %bb98
bb97:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb99
bb98:
  %t421 = getelementptr %"compiler/generic:Desc", ptr %l206, i32 0, i32 0
  %t422 = load i64, ptr %t421, !tbaa !24
  %t423 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t426 = icmp eq i64 %t422, %t423
  store i1 %t426, ptr %l202, !tbaa !21
  br label %bb99
bb99:
  %t428 = load i1, ptr %l202, !tbaa !21
  br i1 %t428, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s16
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/check:Checker", ptr %t429, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t433 = load i32, ptr %l12, !tbaa !23
  %t436 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t432, i32 %t433)
  store %"compiler/generic:Desc" %t436, ptr %l213
  br label %bb102
bb101:
  br label %bb120
bb102:
  %t437 = load %"compiler/generic:Desc", ptr %l213
  store %"compiler/generic:Desc" %t437, ptr %l13
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/check:Checker", ptr %t438, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t442 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 1
  %t443 = load i32, ptr %t442, !tbaa !23
  %t446 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t441, i32 %t443)
  store i32 %t446, ptr %l217
  br label %bb103
bb103:
  %t447 = load i32, ptr %l217, !tbaa !23
  store i32 %t447, ptr %l14, !tbaa !23
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l14, !tbaa !23
  %t452 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t452, ptr %l220
  br label %bb104
bb104:
  %t453 = load i1, ptr %l220, !tbaa !21
  br i1 %t453, label %bb105, label %bb106
bb105:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l1
  %t456 = load %"compiler/source:Span", ptr %l3
  %t457 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 1
  %t458 = load i32, ptr %t457, !tbaa !23
  %t459 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t465 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v2, ptr %v3, ptr %t454, %"compiler/source:Span" %t455, %"compiler/source:Span" %t456, i32 %t458, { i64, ptr } %t459)
  store ptr %t465, ptr %l226
  br label %bb107
bb106:
  br label %bb108
bb107:
  call void @__olang_scope_close(ptr %s16)
  %t466 = load ptr, ptr %l226, !tbaa !29
  store ptr %t466, ptr %rv
  br label %ret
bb108:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = getelementptr %"compiler/generic:Program", ptr %t470, i32 0, i32 2
  %t473 = load i32, ptr %l14, !tbaa !23
  %t476 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t472, i32 %t473)
  store i32 %t476, ptr %l231
  br label %bb109
bb109:
  %t477 = load i32, ptr %l231, !range !{i32 0, i32 33}
  %t479 = trunc i64 32 to i32
  %t480 = icmp eq i32 %t477, %t479
  br i1 %t480, label %bb110, label %bb111
bb110:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load %"compiler/source:Span", ptr %l1
  %t484 = load i32, ptr %l14, !tbaa !23
  %t485 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 2
  %t486 = load i64, ptr %t485, !tbaa !24
  %t487 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t493 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordCalled(ptr %v0, ptr %v2, ptr %v3, ptr %t482, %"compiler/source:Span" %t483, i32 %t484, i64 %t486, { i64, ptr } %t487)
  store ptr %t493, ptr %l239
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_scope_close(ptr %s16)
  %t494 = load ptr, ptr %l239, !tbaa !29
  store ptr %t494, ptr %rv
  br label %ret
bb113:
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l240, !tbaa !29
  %t496 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t496, ptr %l241
  %t497 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t497, ptr %l242
  %t498 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 1
  %t499 = load i32, ptr %t498, !tbaa !23
  store i32 %t499, ptr %l243, !tbaa !23
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/check:Checker", ptr %t500, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !29
  %t505 = getelementptr %"compiler/generic:Program", ptr %t503, i32 0, i32 2
  %t506 = load i32, ptr %l14, !tbaa !23
  %t509 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s16, ptr %t505, i32 %t506)
  store { i64, ptr } %t509, ptr %l248
  br label %bb114
bb114:
  %t510 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t510, ptr %l249, !tbaa !27
  %t511 = getelementptr %"compiler/generic:Desc", ptr %l13, i32 0, i32 2
  %t512 = load i64, ptr %t511, !tbaa !24
  %t514 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !27
  %t516 = getelementptr i32, ptr %t515, i64 %t512
  %t517 = load i32, ptr %t516, !tbaa !33
  store i32 %t517, ptr %l251, !tbaa !23
  %t518 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t518, ptr %l252, !tbaa !27
  %t519 = icmp sge i64 0, 0
  br i1 %t519, label %bb115, label %bb116
bb115:
  %t521 = icmp sle i64 0, 1152921504606846975
  br i1 %t521, label %bb117, label %bb118
bb116:
  call void @__olang_check_failed(ptr @olang_loc_b1d60606349c196f_148fe1dbe07e141b)
  unreachable
bb117:
  %t523 = mul i64 0, 8
  %t524 = insertvalue { i64, ptr } undef, i64 0, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t526 = load ptr, ptr %l240, !tbaa !29
  %t527 = load %"compiler/source:Span", ptr %l241
  %t528 = load %"compiler/source:Span", ptr %l242
  %t529 = load i32, ptr %l243, !tbaa !23
  %t530 = load i32, ptr %l251, !tbaa !23
  %t531 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t533 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %t526, %"compiler/source:Span" %t527, %"compiler/source:Span" %t528, i32 %t529, i32 %t530, { i64, ptr } %t531, { i64, ptr } %t525)
  store ptr %t533, ptr %l256
  br label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_b1d60606349c196f_148fe1dbe07e141b)
  unreachable
bb119:
  call void @__olang_scope_close(ptr %s16)
  %t534 = load ptr, ptr %l256, !tbaa !29
  store ptr %t534, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  %t535 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t536 = load i32, ptr %t535, !range !{i32 0, i32 9}
  %t538 = trunc i64 1 to i32
  %t539 = icmp eq i32 %t536, %t538
  br i1 %t539, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l259, !tbaa !21
  br label %bb124
bb123:
  %t541 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t542 = load i32, ptr %t541, !range !{i32 0, i32 9}
  %t544 = trunc i64 2 to i32
  %t545 = icmp eq i32 %t542, %t544
  store i1 %t545, ptr %l259, !tbaa !21
  br label %bb124
bb124:
  %t547 = load i1, ptr %l259, !tbaa !21
  br i1 %t547, label %bb125, label %bb126
bb125:
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l262, !tbaa !29
  %t549 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t549, ptr %l263
  %t550 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t550, ptr %l264
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t558 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t551, ptr %t552, i32 %t554)
  store ptr %t558, ptr %l269
  br label %bb127
bb126:
  br label %bb129
bb127:
  %t559 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t560 = load ptr, ptr %l262, !tbaa !29
  %t561 = load %"compiler/source:Span", ptr %l263
  %t562 = load %"compiler/source:Span", ptr %l264
  %t563 = load ptr, ptr %l269, !tbaa !29
  %t565 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t560, %"compiler/source:Span" %t561, %"compiler/source:Span" %t562, ptr %t563, { i64, ptr } %t559)
  store ptr %t565, ptr %l271
  br label %bb128
bb128:
  %t566 = load ptr, ptr %l271, !tbaa !29
  store ptr %t566, ptr %rv
  br label %ret
bb129:
  %t567 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t568 = load i32, ptr %t567, !range !{i32 0, i32 9}
  %t570 = trunc i64 8 to i32
  %t571 = icmp eq i32 %t568, %t570
  br i1 %t571, label %bb130, label %bb131
bb130:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load ptr, ptr %l2, !tbaa !29
  %t577 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t573, ptr %t574)
  store i32 %t577, ptr %l276
  br label %bb132
bb131:
  br label %bb168
bb132:
  %t578 = load i32, ptr %l276, !tbaa !23
  store i32 %t578, ptr %l15, !tbaa !23
  %t579 = load i32, ptr %l15, !tbaa !23
  %t581 = icmp sge i32 %t579, 0
  br i1 %t581, label %bb133, label %bb134
bb133:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/check:Checker", ptr %t583, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !29
  %t588 = getelementptr %"compiler/generic:Program", ptr %t586, i32 0, i32 2
  %t589 = load i32, ptr %l15, !tbaa !23
  %t592 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t588, i32 %t589)
  store i1 %t592, ptr %l284
  br label %bb135
bb134:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb143
bb135:
  %t593 = load i1, ptr %l284, !tbaa !21
  br i1 %t593, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb139
bb137:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/check:Checker", ptr %t594, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !29
  %t599 = getelementptr %"compiler/generic:Program", ptr %t597, i32 0, i32 2
  %t600 = load i32, ptr %l15, !tbaa !23
  %t603 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t599, i32 %t600)
  store i1 %t603, ptr %l290
  br label %bb138
bb138:
  %t604 = load i1, ptr %l290, !tbaa !21
  store i1 %t604, ptr %l285, !tbaa !21
  br label %bb139
bb139:
  %t605 = load i1, ptr %l285, !tbaa !21
  br i1 %t605, label %bb140, label %bb141
bb140:
  store i1 true, ptr %l291, !tbaa !21
  br label %bb142
bb141:
  %t606 = load i32, ptr %l15, !tbaa !23
  %t607 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t610 = icmp eq i32 %t606, %t607
  store i1 %t610, ptr %l291, !tbaa !21
  br label %bb142
bb142:
  %t612 = load i1, ptr %l291, !tbaa !21
  store i1 %t612, ptr %l279, !tbaa !21
  br label %bb143
bb143:
  %t613 = load i1, ptr %l279, !tbaa !21
  br i1 %t613, label %bb144, label %bb145
bb144:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load %"compiler/source:Span", ptr %l1
  %t616 = load i32, ptr %l15, !tbaa !23
  %t617 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t622 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v2, ptr %v3, ptr %t614, %"compiler/source:Span" %t615, i32 %t616, { i64, ptr } %t617)
  store ptr %t622, ptr %l299
  br label %bb146
bb145:
  br label %bb147
bb146:
  %t623 = load ptr, ptr %l299, !tbaa !29
  store ptr %t623, ptr %rv
  br label %ret
bb147:
  %t624 = load i32, ptr %l15, !tbaa !23
  %t626 = icmp sge i32 %t624, 0
  br i1 %t626, label %bb148, label %bb149
bb148:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load i32, ptr %l15, !tbaa !23
  %t632 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t628, i32 %t629)
  store i1 %t632, ptr %l305
  br label %bb150
bb149:
  store i1 false, ptr %l302, !tbaa !21
  br label %bb151
bb150:
  %t633 = load i1, ptr %l305, !tbaa !21
  store i1 %t633, ptr %l302, !tbaa !21
  br label %bb151
bb151:
  %t634 = load i1, ptr %l302, !tbaa !21
  br i1 %t634, label %bb152, label %bb153
bb152:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load %"compiler/source:Span", ptr %l1
  %t637 = load %"compiler/source:Span", ptr %l3
  %t638 = load i32, ptr %l15, !tbaa !23
  %t639 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t645 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v2, ptr %v3, ptr %t635, %"compiler/source:Span" %t636, %"compiler/source:Span" %t637, i32 %t638, { i64, ptr } %t639)
  store ptr %t645, ptr %l311
  br label %bb154
bb153:
  br label %bb155
bb154:
  %t646 = load ptr, ptr %l311, !tbaa !29
  store ptr %t646, ptr %rv
  br label %ret
bb155:
  %t647 = load i32, ptr %l15, !tbaa !23
  %t649 = icmp sge i32 %t647, 0
  br i1 %t649, label %bb156, label %bb157
bb156:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/check:Checker", ptr %t651, i32 0, i32 1
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t656 = getelementptr %"compiler/generic:Program", ptr %t654, i32 0, i32 2
  %t657 = load i32, ptr %l15, !tbaa !23
  %t660 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t656, i32 %t657)
  store i32 %t660, ptr %l319
  br label %bb158
bb157:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb159
bb158:
  %t661 = load i32, ptr %l319, !range !{i32 0, i32 33}
  %t663 = trunc i64 25 to i32
  %t664 = icmp eq i32 %t661, %t663
  %t666 = xor i1 %t664, true
  store i1 %t666, ptr %l314, !tbaa !21
  br label %bb159
bb159:
  %t668 = load i1, ptr %l314, !tbaa !21
  br i1 %t668, label %bb160, label %bb161
bb160:
  store %olang.scope zeroinitializer, ptr %s23
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l323, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t670, ptr %l324
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load i32, ptr %l15, !tbaa !23
  %t675 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s23, ptr %t671, i32 %t672)
  store { i64, ptr } %t675, ptr %l327
  br label %bb162
bb161:
  br label %bb167
bb162:
  %t676 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t677 = extractvalue { i64, ptr } %t676, 0
  %t678 = extractvalue { i64, ptr } %t676, 1
  %t679 = mul i64 %t677, 1
  %t680 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t679)
  call void @llvm.memcpy.p0.p0.i64(ptr %t680, ptr %t678, i64 %t679, i1 false)
  %t681 = insertvalue { i64, ptr } undef, i64 %t677, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t680, 1
  %t684 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotCallable(ptr %s23, ptr %v0, { i64, ptr } %t682)
  store %"compiler/diagmsg:Msg" %t684, ptr %l329
  br label %bb163
bb163:
  %t685 = load ptr, ptr %l323, !tbaa !29
  %t686 = load %"compiler/source:Span", ptr %l324
  %t687 = load %"compiler/diagmsg:Msg", ptr %l329
  %t688 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t685, %"compiler/source:Span" %t686, %"compiler/diagmsg:Msg" %t687)
  store i64 %t688, ptr %l330
  br label %bb164
bb164:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t689, { i64, ptr } %t690)
  br label %bb165
bb165:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load %"compiler/source:Span", ptr %l1
  %t697 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t693, %"compiler/source:Span" %t694)
  store ptr %t697, ptr %l335
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s23)
  %t698 = load ptr, ptr %l335, !tbaa !29
  store ptr %t698, ptr %rv
  br label %ret
bb167:
  br label %bb168
bb168:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t699, %"compiler/source:Span" %t700, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb169
bb169:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load %"compiler/source:Span", ptr %l1
  %t707 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t703, %"compiler/source:Span" %t704)
  store ptr %t707, ptr %l340
  br label %bb170
bb170:
  %t708 = load ptr, ptr %l340, !tbaa !29
  store ptr %t708, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca ptr
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 18
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t18, i64 %t21)
  store ptr %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 1
  %t28 = load { i64, [2 x i64] }, ptr %t27
  store { i64, [2 x i64] } %t28, ptr %l3
  %t30 = load { i64, [2 x i64] }, ptr %l3
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l24
  br label %bb10
bb10:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7fe1bea66cf2144e_3863a3a9e6f6a662)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b79520aaecc0f88f_d487c78520878463)
  unreachable
bb22:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i32
  %l61 = alloca i32
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l20
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l6
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 28
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l9, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l11, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l12, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 28
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l52
  br label %bb14
bb14:
  %t68 = load i32, ptr %l52, !tbaa !23
  store i32 %t68, ptr %l13, !tbaa !23
  %t69 = load i64, ptr %l12, !tbaa !24
  %t73 = icmp sge i64 %t69, %a2
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l13, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l6, i32 %t75)
  br label %bb17
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l13, !tbaa !23
  %t84 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %t78, i32 %t79, ptr %a3)
  store i32 %t84, ptr %l61
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t85 = load i32, ptr %l61, !tbaa !23
  store i32 %t85, ptr %l14, !tbaa !23
  %t86 = load i32, ptr %l14, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp ne i32 %t86, %t87
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l6, i32 %t92)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l11, !tbaa !24
  br label %bb10
bb25:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 28
  %t106 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t105, i64 %t106)
  br label %bb26
bb26:
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  %t110 = load i64, ptr %l16, !tbaa !24
  store i64 %t110, ptr %l75, !tbaa !24
  %t111 = load ptr, ptr %l15, !tbaa !29
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t111)
  store i64 %t113, ptr %l77
  br label %bb28
bb28:
  %t114 = load i64, ptr %l75, !tbaa !24
  %t115 = load i64, ptr %l77, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l15, !tbaa !29
  %t121 = load i64, ptr %l16, !tbaa !24
  %t124 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t120, i64 %t121)
  store i32 %t124, ptr %l82
  br label %bb32
bb32:
  %t125 = load i32, ptr %l82, !tbaa !23
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t128, i32 %t125)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t132 = load i64, ptr %l16, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l16, !tbaa !24
  br label %bb27
bb35:
  %t136 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:altsCovered" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtAlts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/check:payloadItem"
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"compiler/check:altsCovered"
  %l24 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l46 = alloca i64
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l69 = alloca i1
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/diagmsg:Msg"
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i1
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i32
  %l90 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l103 = alloca i1
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l112 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca %"compiler/diagmsg:Msg"
  %l125 = alloca i64
  %l126 = alloca i64
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca i64
  %l142 = alloca i64
  %l147 = alloca %"compiler/check:payloadItem"
  %l149 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i1
  %l154 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l174 = alloca i32
  %l176 = alloca i1
  %l177 = alloca ptr
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca %"compiler/diagmsg:Msg"
  %l181 = alloca i64
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca i64
  %l189 = alloca ptr
  %l191 = alloca %"compiler/source:Span"
  %l192 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l201 = alloca %"compiler/diagmsg:Msg"
  %l202 = alloca i64
  %l203 = alloca i64
  %l209 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l211 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l213 = alloca ptr
  %l215 = alloca %"compiler/source:Span"
  %l216 = alloca %"compiler/diagmsg:Msg"
  %l217 = alloca i64
  %l220 = alloca i64
  %l222 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l224 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l228 = alloca %"compiler/check:altsCovered"
  %l230 = alloca %"compiler/check:altsCovered"
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"compiler/check:altsCovered"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = ptrtoint ptr %v4 to i64
  store i64 %t1, ptr %l24, !tbaa !24
  %t2 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = call ptr @__olang_region_make(ptr %v4)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l24, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l24
  %t7 = inttoptr i64 %t6 to ptr
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l26
  br label %bb3
bb3:
  %t9 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l24
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = call ptr @__olang_region_or(ptr %t15, ptr null)
  %t17 = call ptr @__olang_region_home(ptr %t16)
  %t18 = icmp ne ptr %t17, null
  %t19 = select i1 %t18, ptr %t17, ptr null
  %t20 = icmp eq ptr %t19, %t12
  call void @__olang_region_settle(ptr %t12, i1 %t20)
  br label %bb5
bb5:
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t21, ptr %lp6
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  %t23 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t23
  store i1 false, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i1 true, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Case", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l12, !tbaa !24
  %t34 = load i64, ptr %l13, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb7, label %bb8
bb7:
  br label %bb139
bb8:
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t41, ptr %l36, !tbaa !27
  %t42 = load i64, ptr %l12, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr ptr, ptr %t45, i64 %t42
  %t47 = load ptr, ptr %t46, !tbaa !39
  store ptr %t47, ptr %l14, !tbaa !29
  %t49 = load ptr, ptr %l14, !tbaa !29
  store ptr %t49, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l39, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 9}
  %t56 = icmp eq i64 %t54, 0
  store i1 %t56, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t57 = load i1, ptr %l40, !tbaa !21
  br i1 %t57, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb25
bb14:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Case", ptr %t58, i32 0, i32 3
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i1 true, ptr %l7, !tbaa !21
  %t65 = ptrtoint ptr %v4 to i64
  store i64 %t65, ptr %l46, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = call ptr @__olang_region_make(ptr %v4)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l46, !tbaa !24
  br label %bb19
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %lp6
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t71
  %t74 = load i64, ptr %l46
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call ptr @__olang_scope_alloc_a(ptr %t75, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t76
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t78 = load i64, ptr %l46
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = load i64, ptr %l46
  %t81 = inttoptr i64 %t80 to ptr
  %t85 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %t79, ptr %v3, ptr %t81, ptr %t70, ptr %t76, ptr %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l52
  br label %bb20
bb20:
  %t86 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l46
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = call ptr @__olang_region_or(ptr %t92, ptr null)
  %t94 = call ptr @__olang_region_home(ptr %t93)
  %t95 = icmp ne ptr %t94, null
  %t96 = select i1 %t95, ptr %t94, ptr null
  %t97 = icmp eq ptr %t96, %t89
  call void @__olang_region_settle(ptr %t89, i1 %t97)
  br label %bb22
bb22:
  %t98 = load ptr, ptr %lp6
  %t99 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l54
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  %t101 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  %t102 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t104 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = call ptr @__olang_region_or(ptr %t106, ptr null)
  %t108 = call ptr @__olang_region_home(ptr %t107)
  %t109 = icmp ne ptr %t108, null
  %t110 = select i1 %t109, ptr %t108, ptr null
  call void @__olang_region_drop(ptr %t110)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l54
  br label %bb24
bb24:
  br label %bb137
bb25:
  %t111 = load ptr, ptr %l14, !tbaa !29
  store ptr %t111, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t112 = load ptr, ptr %l56, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t115 = load ptr, ptr %l56, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 9}
  %t118 = icmp eq i64 %t116, 1
  store i1 %t118, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t119 = load i1, ptr %l57, !tbaa !21
  br i1 %t119, label %bb28, label %bb29
bb28:
  %t120 = load ptr, ptr %l14, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", ptr }, ptr %t122, i32 0, i32 1
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l15, !tbaa !29
  br label %bb34
bb29:
  %t126 = load ptr, ptr %l14, !tbaa !29
  store ptr %t126, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t127 = load ptr, ptr %l62, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb30, label %bb31
bb30:
  %t130 = load ptr, ptr %l62, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 9}
  %t133 = icmp eq i64 %t131, 4
  store i1 %t133, ptr %l63, !tbaa !21
  br label %bb31
bb31:
  %t134 = load i1, ptr %l63, !tbaa !21
  br i1 %t134, label %bb32, label %bb33
bb32:
  %t135 = load ptr, ptr %l14, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", ptr }, ptr %t137, i32 0, i32 1
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l15, !tbaa !29
  br label %bb34
bb33:
  br label %bb44
bb34:
  %t141 = load ptr, ptr %l15, !tbaa !29
  %t143 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t141)
  store i1 %t143, ptr %l69
  br label %bb35
bb35:
  %t144 = load i1, ptr %l69, !tbaa !21
  br i1 %t144, label %bb36, label %bb37
bb36:
  %t147 = xor i1 %a4, true
  br i1 %t147, label %bb38, label %bb39
bb37:
  br label %bb44
bb38:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l72, !tbaa !29
  %t150 = load ptr, ptr %l14, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l74
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t155 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v2, ptr %v0, { i64, ptr } %t153)
  store %"compiler/diagmsg:Msg" %t155, ptr %l76
  br label %bb41
bb41:
  %t156 = load ptr, ptr %l72, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l74
  %t158 = load %"compiler/diagmsg:Msg", ptr %l76
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t156, %"compiler/source:Span" %t157, %"compiler/diagmsg:Msg" %t158)
  store i64 %t159, ptr %l77
  br label %bb42
bb42:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb43
bb43:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb137
bb44:
  %t160 = load ptr, ptr %l14, !tbaa !29
  store ptr %t160, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t161 = load ptr, ptr %l78, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb45, label %bb46
bb45:
  %t164 = load ptr, ptr %l78, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 9}
  %t167 = icmp eq i64 %t165, 2
  store i1 %t167, ptr %l79, !tbaa !21
  br label %bb46
bb46:
  %t168 = load i1, ptr %l79, !tbaa !21
  br i1 %t168, label %bb47, label %bb48
bb47:
  %t169 = load ptr, ptr %l14, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t171, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l16, !tbaa !29
  br label %bb49
bb48:
  br label %bb95
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l16, !tbaa !29
  %t179 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s7, ptr %t175, ptr %t176)
  %t180 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t179, 1
  %t181 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t179, 0
  store i32 %t181, ptr %l88
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb51, label %ok.183, !prof !99
ok.183:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l87
  br label %bb50
bb50:
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l84
  br label %bb56
bb51:
  %t185 = load i32, ptr %l88, !tbaa !23
  %t186 = ashr i32 %t185, 16
  %t188 = icmp eq i32 %t186, 1
  store i1 %t188, ptr %l90, !tbaa !21
  br label %bb52
bb52:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l91, !tbaa !29
  %t190 = load ptr, ptr %l14, !tbaa !29
  %t192 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t190)
  store %"compiler/source:Span" %t192, ptr %l93
  br label %bb53
bb53:
  %t193 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t193, ptr %l94
  br label %bb54
bb54:
  %t194 = load ptr, ptr %l91, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l93
  %t196 = load %"compiler/diagmsg:Msg", ptr %l94
  %t197 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t194, %"compiler/source:Span" %t195, %"compiler/diagmsg:Msg" %t196)
  store i64 %t197, ptr %l95
  br label %bb55
bb55:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb138
bb56:
  %t198 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l17
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l14, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Case", ptr %t203, i32 0, i32 1
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t214 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %t199, ptr %t200, { i64, ptr } %t201, i1 %a5, i64 %t208)
  store i1 %t214, ptr %l103
  br label %bb57
bb57:
  %t215 = load i1, ptr %l103, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb58, label %bb59
bb58:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb139
bb59:
  br label %bb60
bb60:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l3, !tbaa !29
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v3, ptr %s7, ptr %s7, ptr %t218, ptr %t219, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l108
  br label %bb61
bb61:
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %l108)
  store i64 %t225, ptr %l110
  br label %bb62
bb62:
  %t226 = load i64, ptr %l110, !tbaa !24
  %t227 = icmp eq i64 %t226, 0
  br i1 %t227, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l112, !tbaa !29
  %t230 = load ptr, ptr %l14, !tbaa !29
  %t232 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t230)
  store %"compiler/source:Span" %t232, ptr %l114
  br label %bb65
bb64:
  br label %bb70
bb65:
  %t233 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t233, ptr %l115, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s7, ptr %s10, ptr %t234, ptr %l17)
  store { i64, ptr } %t237, ptr %l118
  br label %bb66
bb66:
  %t238 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  %t240 = extractvalue { i64, ptr } %t238, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  store { i64, ptr } %t244, ptr %l119, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l3, !tbaa !29
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v3, ptr %s10, ptr %t245, ptr %t246)
  store { i64, ptr } %t249, ptr %l122
  br label %bb67
bb67:
  %t250 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t260 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v2, ptr %s10, ptr %s10, ptr %v0, { i64, ptr } %t257, { i64, ptr } %t258, { i64, ptr } %t256)
  store %"compiler/diagmsg:Msg" %t260, ptr %l124
  br label %bb68
bb68:
  %t261 = load ptr, ptr %l112, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l114
  %t263 = load %"compiler/diagmsg:Msg", ptr %l124
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t261, %"compiler/source:Span" %t262, %"compiler/diagmsg:Msg" %t263)
  store i64 %t264, ptr %l125
  br label %bb69
bb69:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  br label %bb138
bb70:
  %t265 = ptrtoint ptr %v4 to i64
  store i64 %t265, ptr %l126, !tbaa !24
  %t266 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t266, label %bb71, label %bb72
bb71:
  %t268 = call ptr @__olang_region_make(ptr %v4)
  %t269 = ptrtoint ptr %t268 to i64
  store i64 %t269, ptr %l126, !tbaa !24
  br label %bb72
bb72:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %lp6
  %t272 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t271
  %t274 = load i64, ptr %l126
  %t275 = inttoptr i64 %t274 to ptr
  %t276 = call ptr @__olang_scope_alloc_a(ptr %t275, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, ptr %t276
  %t277 = load i64, ptr %l126
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = load i64, ptr %l126
  %t280 = inttoptr i64 %t279 to ptr
  %t284 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %t278, ptr %s7, ptr %t280, ptr %t270, ptr %t276, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t284, ptr %l132
  br label %bb73
bb73:
  %t285 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t285, label %bb74, label %bb75
bb74:
  %t287 = load i64, ptr %l126
  %t288 = inttoptr i64 %t287 to ptr
  %t289 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132, i32 0, i32 0
  %t290 = load { i64, ptr }, ptr %t289
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = call ptr @__olang_region_or(ptr %t291, ptr null)
  %t293 = call ptr @__olang_region_home(ptr %t292)
  %t294 = icmp ne ptr %t293, null
  %t295 = select i1 %t294, ptr %t293, ptr null
  %t296 = icmp eq ptr %t295, %t288
  call void @__olang_region_settle(ptr %t288, i1 %t296)
  br label %bb75
bb75:
  %t297 = load ptr, ptr %lp6
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t297
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %l134
  %t299 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132
  %t300 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t299, ptr %t300
  %t301 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t301, label %bb76, label %bb77
bb76:
  %t303 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134, i32 0, i32 0
  %t304 = load { i64, ptr }, ptr %t303
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = call ptr @__olang_region_or(ptr %t305, ptr null)
  %t307 = call ptr @__olang_region_home(ptr %t306)
  %t308 = icmp ne ptr %t307, null
  %t309 = select i1 %t308, ptr %t307, ptr null
  call void @__olang_region_drop(ptr %t309)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l134
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s11
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l14, !tbaa !29
  %t314 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %s11, ptr %t310, ptr %t311)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, ptr %l138
  br label %bb78
bb78:
  %t315 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  %t316 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t315, ptr %t316
  store ptr %t316, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb79
bb79:
  %t318 = load i64, ptr %l19, !tbaa !24
  store i64 %t318, ptr %l140, !tbaa !24
  %t319 = load ptr, ptr %l18, !tbaa !29
  %t321 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %s11, ptr %t319)
  store i64 %t321, ptr %l142
  br label %bb80
bb80:
  %t322 = load i64, ptr %l140, !tbaa !24
  %t323 = load i64, ptr %l142, !tbaa !24
  %t324 = icmp slt i64 %t322, %t323
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb81, label %bb82
bb81:
  br label %bb94
bb82:
  br label %bb83
bb83:
  %t328 = load ptr, ptr %l18, !tbaa !29
  %t329 = load i64, ptr %l19, !tbaa !24
  %t332 = call %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %s11, ptr %s11, ptr %t328, i64 %t329)
  store %"compiler/check:payloadItem" %t332, ptr %l147
  br label %bb84
bb84:
  %t333 = load %"compiler/check:payloadItem", ptr %l147
  store %"compiler/check:payloadItem" %t333, ptr %l20
  %t334 = load i1, ptr %l10, !tbaa !21
  br i1 %t334, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb92
bb86:
  %t336 = getelementptr %"compiler/check:payloadItem", ptr %l20, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = call i1 @compiler_2fcheck_2eisWild(ptr %s11, ptr %t337)
  store i1 %t339, ptr %l151
  br label %bb87
bb87:
  %t340 = load i1, ptr %l151, !tbaa !21
  br i1 %t340, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb91
bb89:
  %t341 = getelementptr %"compiler/check:payloadItem", ptr %l20, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = call i1 @compiler_2fcheck_2eisBind(ptr %s11, ptr %t342)
  store i1 %t344, ptr %l154
  br label %bb90
bb90:
  %t345 = load i1, ptr %l154, !tbaa !21
  store i1 %t345, ptr %l152, !tbaa !21
  br label %bb91
bb91:
  %t346 = load i1, ptr %l152, !tbaa !21
  %t347 = xor i1 %t346, true
  store i1 %t347, ptr %l149, !tbaa !21
  br label %bb92
bb92:
  %t349 = load i1, ptr %l149, !tbaa !21
  store i1 %t349, ptr %l10, !tbaa !21
  br label %bb93
bb93:
  %t350 = load i64, ptr %l19, !tbaa !24
  %t352 = add i64 %t350, 1
  store i64 %t352, ptr %l19, !tbaa !24
  br label %bb79
bb94:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  br label %bb137
bb95:
  %t354 = load ptr, ptr %l14, !tbaa !29
  store ptr %t354, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t355 = load ptr, ptr %l158, !tbaa !29
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %bb96, label %bb97
bb96:
  %t358 = load ptr, ptr %l158, !tbaa !29
  %t359 = load i64, ptr %t358, !range !{i64 0, i64 9}
  %t361 = icmp eq i64 %t359, 1
  store i1 %t361, ptr %l159, !tbaa !21
  br label %bb97
bb97:
  %t362 = load i1, ptr %l159, !tbaa !21
  br i1 %t362, label %bb98, label %bb99
bb98:
  %t363 = load ptr, ptr %l14, !tbaa !29
  %t365 = getelementptr { i64, [4 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", ptr }, ptr %t365, i32 0, i32 1
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l21, !tbaa !29
  br label %bb104
bb99:
  %t369 = load ptr, ptr %l14, !tbaa !29
  store ptr %t369, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t370 = load ptr, ptr %l164, !tbaa !29
  %t371 = icmp ne ptr %t370, null
  br i1 %t371, label %bb100, label %bb101
bb100:
  %t373 = load ptr, ptr %l164, !tbaa !29
  %t374 = load i64, ptr %t373, !range !{i64 0, i64 9}
  %t376 = icmp eq i64 %t374, 4
  store i1 %t376, ptr %l165, !tbaa !21
  br label %bb101
bb101:
  %t377 = load i1, ptr %l165, !tbaa !21
  br i1 %t377, label %bb102, label %bb103
bb102:
  %t378 = load ptr, ptr %l14, !tbaa !29
  %t380 = getelementptr { i64, [4 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr }, ptr %t380, i32 0, i32 1
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l21, !tbaa !29
  br label %bb104
bb103:
  br label %bb129
bb104:
  store %olang.scope zeroinitializer, ptr %s14
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l21, !tbaa !29
  %t388 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s14, ptr %t384, ptr %t385)
  %t389 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t388, 1
  %t390 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t388, 0
  store i32 %t390, ptr %l174
  %t391 = icmp ne i32 %t390, 0
  br i1 %t391, label %bb106, label %ok.392, !prof !99
ok.392:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t389, ptr %l173
  br label %bb105
bb105:
  %t393 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t393, ptr %l170
  br label %bb111
bb106:
  %t394 = load i32, ptr %l174, !tbaa !23
  %t395 = ashr i32 %t394, 16
  %t397 = icmp eq i32 %t395, 1
  store i1 %t397, ptr %l176, !tbaa !21
  br label %bb107
bb107:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l177, !tbaa !29
  %t399 = load ptr, ptr %l14, !tbaa !29
  %t401 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t399)
  store %"compiler/source:Span" %t401, ptr %l179
  br label %bb108
bb108:
  %t402 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t402, ptr %l180
  br label %bb109
bb109:
  %t403 = load ptr, ptr %l177, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l179
  %t405 = load %"compiler/diagmsg:Msg", ptr %l180
  %t406 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t403, %"compiler/source:Span" %t404, %"compiler/diagmsg:Msg" %t405)
  store i64 %t406, ptr %l181
  br label %bb110
bb110:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  br label %bb138
bb111:
  %t407 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t407, ptr %l22
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load ptr, ptr %l3, !tbaa !29
  %t413 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v3, ptr %s14, ptr %s14, ptr %t408, ptr %t409, ptr %l22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t413, ptr %l185
  br label %bb112
bb112:
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14, ptr %l185)
  store i64 %t415, ptr %l187
  br label %bb113
bb113:
  %t416 = load i64, ptr %l187, !tbaa !24
  %t417 = icmp eq i64 %t416, 0
  br i1 %t417, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s16
  %t419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t419, ptr %l189, !tbaa !29
  %t420 = load ptr, ptr %l14, !tbaa !29
  %t422 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t420)
  store %"compiler/source:Span" %t422, ptr %l191
  br label %bb116
bb115:
  %t423 = ptrtoint ptr %v4 to i64
  store i64 %t423, ptr %l203, !tbaa !24
  %t424 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t424, label %bb121, label %bb122
bb116:
  %t426 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t426, ptr %l192, !tbaa !27
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t430 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s14, ptr %s16, ptr %t427, ptr %l22)
  store { i64, ptr } %t430, ptr %l195
  br label %bb117
bb117:
  %t431 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  %t433 = extractvalue { i64, ptr } %t431, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l196, !tbaa !27
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l3, !tbaa !29
  %t442 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v3, ptr %s16, ptr %t438, ptr %t439)
  store { i64, ptr } %t442, ptr %l199
  br label %bb118
bb118:
  %t443 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 0
  %t445 = extractvalue { i64, ptr } %t443, 1
  %t446 = mul i64 %t444, 1
  %t447 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t446)
  call void @llvm.memcpy.p0.p0.i64(ptr %t447, ptr %t445, i64 %t446, i1 false)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t450 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t451 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t453 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v2, ptr %s16, ptr %s16, ptr %v0, { i64, ptr } %t450, { i64, ptr } %t451, { i64, ptr } %t449)
  store %"compiler/diagmsg:Msg" %t453, ptr %l201
  br label %bb119
bb119:
  %t454 = load ptr, ptr %l189, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l191
  %t456 = load %"compiler/diagmsg:Msg", ptr %l201
  %t457 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t454, %"compiler/source:Span" %t455, %"compiler/diagmsg:Msg" %t456)
  store i64 %t457, ptr %l202
  br label %bb120
bb120:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb128
bb121:
  %t458 = call ptr @__olang_region_make(ptr %v4)
  %t459 = ptrtoint ptr %t458 to i64
  store i64 %t459, ptr %l203, !tbaa !24
  br label %bb122
bb122:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load ptr, ptr %lp6
  %t462 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t461
  %t464 = load i64, ptr %l203
  %t465 = inttoptr i64 %t464 to ptr
  %t466 = call ptr @__olang_scope_alloc_a(ptr %t465, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t462, ptr %t466
  %t467 = load i64, ptr %l203
  %t468 = inttoptr i64 %t467 to ptr
  %t469 = load i64, ptr %l203
  %t470 = inttoptr i64 %t469 to ptr
  %t474 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %t468, ptr %s14, ptr %t470, ptr %t460, ptr %t466, ptr %l22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %l209
  br label %bb123
bb123:
  %t475 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t475, label %bb124, label %bb125
bb124:
  %t477 = load i64, ptr %l203
  %t478 = inttoptr i64 %t477 to ptr
  %t479 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l209, i32 0, i32 0
  %t480 = load { i64, ptr }, ptr %t479
  %t481 = extractvalue { i64, ptr } %t480, 1
  %t482 = call ptr @__olang_region_or(ptr %t481, ptr null)
  %t483 = call ptr @__olang_region_home(ptr %t482)
  %t484 = icmp ne ptr %t483, null
  %t485 = select i1 %t484, ptr %t483, ptr null
  %t486 = icmp eq ptr %t485, %t478
  call void @__olang_region_settle(ptr %t478, i1 %t486)
  br label %bb125
bb125:
  %t487 = load ptr, ptr %lp6
  %t488 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t487
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t488, ptr %l211
  %t489 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l209
  %t490 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t489, ptr %t490
  %t491 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6
  br i1 %t491, label %bb126, label %bb127
bb126:
  %t493 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l211, i32 0, i32 0
  %t494 = load { i64, ptr }, ptr %t493
  %t495 = extractvalue { i64, ptr } %t494, 1
  %t496 = call ptr @__olang_region_or(ptr %t495, ptr null)
  %t497 = call ptr @__olang_region_home(ptr %t496)
  %t498 = icmp ne ptr %t497, null
  %t499 = select i1 %t498, ptr %t497, ptr null
  call void @__olang_region_drop(ptr %t499)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l211
  br label %bb127
bb127:
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s14)
  br label %bb137
bb129:
  br i1 true, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb136
bb132:
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l213, !tbaa !29
  %t501 = load ptr, ptr %l14, !tbaa !29
  %t503 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t501)
  store %"compiler/source:Span" %t503, ptr %l215
  br label %bb133
bb133:
  %t504 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t504, ptr %l216
  br label %bb134
bb134:
  %t505 = load ptr, ptr %l213, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l215
  %t507 = load %"compiler/diagmsg:Msg", ptr %l216
  %t508 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t505, %"compiler/source:Span" %t506, %"compiler/diagmsg:Msg" %t507)
  store i64 %t508, ptr %l217
  br label %bb135
bb135:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_7f447623c50cbf0b_d88fa4c796e8075f)
  unreachable
bb137:
  br label %bb138
bb138:
  %t509 = load i64, ptr %l12, !tbaa !24
  %t511 = add i64 %t509, 1
  store i64 %t511, ptr %l12, !tbaa !24
  br label %bb6
bb139:
  %t513 = ptrtoint ptr %v4 to i64
  store i64 %t513, ptr %l220, !tbaa !24
  %t514 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aaltsCovered_2e0
  br i1 %t514, label %bb140, label %bb141
bb140:
  %t516 = call ptr @__olang_region_make(ptr %v4)
  %t517 = ptrtoint ptr %t516 to i64
  store i64 %t517, ptr %l220, !tbaa !24
  br label %bb141
bb141:
  %t518 = load ptr, ptr %lp6
  %t519 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t518
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t519, ptr %l222
  %t520 = load i64, ptr %l220
  %t521 = inttoptr i64 %t520 to ptr
  %t523 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %t521, ptr %l222)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t523, ptr %l224
  br label %bb142
bb142:
  %t524 = load i1, ptr %l7, !tbaa !21
  %t525 = load i1, ptr %l8, !tbaa !21
  %t526 = load i1, ptr %l9, !tbaa !21
  %t527 = load i64, ptr %l220
  %t528 = inttoptr i64 %t527 to ptr
  %t529 = load i64, ptr %l220
  %t530 = inttoptr i64 %t529 to ptr
  %t531 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l224
  %t535 = call %"compiler/check:altsCovered" @compiler_2fcheck_3aaltsCovered_2ector(ptr %t528, ptr %t530, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t531, i1 %t524, i1 %t525, i1 %t526)
  store %"compiler/check:altsCovered" %t535, ptr %l228
  br label %bb143
bb143:
  %t536 = load i64, ptr %l220
  %t537 = inttoptr i64 %t536 to ptr
  %t539 = call %"compiler/check:altsCovered" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aaltsCovered(ptr %t537, ptr %l228)
  store %"compiler/check:altsCovered" %t539, ptr %l230
  br label %bb144
bb144:
  %t540 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aaltsCovered_2e0
  br i1 %t540, label %bb145, label %bb146
bb145:
  %t542 = load i64, ptr %l220
  %t543 = inttoptr i64 %t542 to ptr
  %t544 = getelementptr %"compiler/check:altsCovered", ptr %l230, i32 0, i32 0
  %t545 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t544, i32 0, i32 0
  %t546 = load { i64, ptr }, ptr %t545
  %t547 = extractvalue { i64, ptr } %t546, 1
  %t548 = call ptr @__olang_region_or(ptr %t547, ptr null)
  %t549 = call ptr @__olang_region_home(ptr %t548)
  %t550 = icmp ne ptr %t549, null
  %t551 = select i1 %t550, ptr %t549, ptr null
  %t552 = icmp eq ptr %t551, %t543
  call void @__olang_region_settle(ptr %t543, i1 %t552)
  br label %bb146
bb146:
  %t553 = load %"compiler/check:altsCovered", ptr %l230
  store %"compiler/check:altsCovered" %t553, ptr %l23
  %t554 = load i1, ptr %l10, !tbaa !21
  %t556 = getelementptr %"compiler/check:altsCovered", ptr %l23, i32 0, i32 4
  store i1 %t554, ptr %t556, !tbaa !21
  %t557 = load %"compiler/check:altsCovered", ptr %l23
  store %"compiler/check:altsCovered" %t557, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:altsCovered", ptr %rv
  ret %"compiler/check:altsCovered" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, i64, i64 }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/check:errBind"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i1
  %l51 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i64
  %l77 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i64
  %l86 = alloca i64
  %l90 = alloca i1
  %l93 = alloca i32
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l114 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l128 = alloca i64
  %l130 = alloca ptr
  %l135 = alloca %"compiler/check:errBind"
  %l140 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l149 = alloca %"compiler/typed:Local"
  %l151 = alloca i1
  %l154 = alloca i1
  %l158 = alloca { i64, ptr }
  %l167 = alloca i1
  %l172 = alloca i1
  %l175 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l180 = alloca i1
  %l186 = alloca i1
  %l188 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca { i64, ptr }
  %l195 = alloca %"compiler/diagmsg:Msg"
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %l199 = alloca i64
  %l200 = alloca i64
  %l207 = alloca i64
  %l212 = alloca { i64, i64, i64 }
  %l228 = alloca ptr
  %l232 = alloca i64
  %l234 = alloca i1
  %l239 = alloca i1
  %l244 = alloca i32
  %l247 = alloca i1
  %l250 = alloca i64
  %l253 = alloca ptr
  %l258 = alloca i32
  %l259 = alloca { i64, ptr }
  %l266 = alloca i1
  %l269 = alloca i1
  %l271 = alloca i1
  %l282 = alloca i64
  %l285 = alloca i64
  %l308 = alloca i32
  %l311 = alloca i1
  %l318 = alloca ptr
  %l323 = alloca i32
  %l324 = alloca { i64, ptr }
  %l329 = alloca { i64, ptr }
  %l333 = alloca ptr
  %l336 = alloca { i64, ptr }
  %l340 = alloca ptr
  %l346 = alloca { i64, ptr }
  %l352 = alloca %"compiler/check:errBind"
  %l356 = alloca i1
  %l358 = alloca ptr
  %l359 = alloca %"compiler/source:Span"
  %l362 = alloca %"compiler/diagmsg:Msg"
  %l365 = alloca { i64, ptr }
  %l367 = alloca %"compiler/diagmsg:Msg"
  %l370 = alloca { i64, ptr }
  %l371 = alloca { i64, ptr }
  %l373 = alloca ptr
  %l375 = alloca ptr
  %l377 = alloca i64
  %l380 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l383 = alloca %"compiler/diagmsg:Msg"
  %l384 = alloca i64
  %l394 = alloca %"compiler/source:Span"
  %l395 = alloca i64
  %l398 = alloca { i64, ptr }
  %l404 = alloca %"compiler/typed:Clause"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t179 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l43
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l6
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  store i1 %t7, ptr %l46
  br label %bb2
bb2:
  %t8 = load i1, ptr %l46, !tbaa !21
  store i1 %t8, ptr %l7, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Catch", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i1, ptr %l7, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l51, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l51, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Catch", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l10, !tbaa !24
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = load i64, ptr %l10, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t40, ptr %l62, !tbaa !27
  %t41 = load i64, ptr %l9, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  store ptr %t46, ptr %l11, !tbaa !29
  %t48 = load ptr, ptr %l11, !tbaa !29
  store ptr %t48, ptr %l65, !tbaa !29
  %t49 = ptrtoint ptr %v1 to i64
  store i64 %t49, ptr %l66, !tbaa !24
  %t50 = load i1, ptr @olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l65, !tbaa !29
  %t53 = call ptr @__olang_region_or(ptr %t52, ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l66, !tbaa !24
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l11, !tbaa !29
  %t57 = load i64, ptr %l66
  %t58 = inttoptr i64 %t57 to ptr
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %t58, ptr %s0, ptr %t55, ptr %t56, ptr %l6)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l9, !tbaa !24
  br label %bb8
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Catch", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb20
bb19:
  %t75 = load i1, ptr %l7, !tbaa !21
  store i1 %t75, ptr %l77, !tbaa !21
  br label %bb20
bb20:
  %t77 = load i1, ptr %l77, !tbaa !21
  store i1 %t77, ptr %l12, !tbaa !21
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l80
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l80, !tbaa !29
  store ptr %t81, ptr %l13, !tbaa !29
  store i64 -1, ptr %l14, !tbaa !24
  store i32 0, ptr %l15, !tbaa !23
  %t82 = load ptr, ptr %l13, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 60
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l83
  br label %bb22
bb22:
  %t87 = load i64, ptr %l83, !tbaa !24
  store i64 %t87, ptr %l16, !tbaa !24
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 9
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l86
  br label %bb23
bb23:
  %t93 = load i64, ptr %l86, !tbaa !24
  store i64 %t93, ptr %l17, !tbaa !24
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/ast:Catch", ptr %t94, i32 0, i32 5
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = icmp ne i32 %t97, 0
  br i1 %t99, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb26
bb25:
  %t101 = load i1, ptr %l7, !tbaa !21
  store i1 %t101, ptr %l90, !tbaa !21
  br label %bb26
bb26:
  %t103 = load i1, ptr %l90, !tbaa !21
  br i1 %t103, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load i1, ptr %l7, !tbaa !21
  br i1 %t104, label %bb29, label %bb30
bb28:
  br label %bb42
bb29:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Catch", ptr %t106, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l95, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr ptr, ptr %t111, i64 0
  %t113 = load ptr, ptr %t112, !tbaa !39
  %t115 = getelementptr %"compiler/ast:Path", ptr %t113, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l97, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i32, ptr %t118, i64 0
  %t120 = load i32, ptr %t119, !tbaa !33
  store i32 %t120, ptr %l93, !tbaa !23
  br label %bb31
bb30:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Catch", ptr %t122, i32 0, i32 5
  %t125 = load i32, ptr %t124, !tbaa !23
  store i32 %t125, ptr %l93, !tbaa !23
  br label %bb31
bb31:
  %t127 = load i32, ptr %l93, !tbaa !23
  store i32 %t127, ptr %l18, !tbaa !23
  %t128 = load i1, ptr %l7, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/ast:Catch", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l104, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 0
  %t137 = load ptr, ptr %t136, !tbaa !39
  %t139 = getelementptr %"compiler/ast:Path", ptr %t137, i32 0, i32 0
  %t140 = load %"compiler/source:Span", ptr %t139
  store %"compiler/source:Span" %t140, ptr %l102
  br label %bb34
bb33:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Catch", ptr %t142, i32 0, i32 6
  %t145 = load %"compiler/source:Span", ptr %t144
  store %"compiler/source:Span" %t145, ptr %l102
  br label %bb34
bb34:
  %t147 = load %"compiler/source:Span", ptr %l102
  store %"compiler/source:Span" %t147, ptr %l19
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i1, ptr %l12, !tbaa !21
  %t157 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etakenSet(ptr %v0, ptr %v2, ptr %s0, ptr %v3, ptr %t148, { i64, ptr } %a4, ptr %l6, i1 %t150, ptr %a5)
  store i32 %t157, ptr %l114
  br label %bb35
bb35:
  %t158 = load i32, ptr %l114, !tbaa !23
  store i32 %t158, ptr %l15, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l115, !tbaa !29
  %t160 = load i32, ptr %l18, !tbaa !23
  store i32 %t160, ptr %l116, !tbaa !23
  %t161 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t161, ptr %l117
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  store ptr %t165, ptr %l119, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l15, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t171, i32 %t172)
  store { i64, ptr } %t175, ptr %l124
  br label %bb36
bb36:
  %t176 = load ptr, ptr %l119, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t178 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v0, ptr %t176, { i64, ptr } %t177)
  store i32 %t178, ptr %l125
  br label %bb37
bb37:
  store { i64, [1 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [1 x i64] }, ptr %t179, i32 0, i32 0
  store i64 0, ptr %t180
  %t181 = load { i64, [1 x i64] }, ptr %t179
  %t182 = load ptr, ptr %l115, !tbaa !29
  %t183 = load i32, ptr %l116, !tbaa !23
  %t184 = load %"compiler/source:Span", ptr %l117
  %t185 = load i32, ptr %l125, !tbaa !23
  %t188 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t182, i32 %t183, %"compiler/source:Span" %t184, i32 %t185, i32 1, { i64, [1 x i64] } %t181)
  store i64 %t188, ptr %l128
  br label %bb38
bb38:
  %t189 = load i64, ptr %l128, !tbaa !24
  store i64 %t189, ptr %l14, !tbaa !24
  %t190 = load ptr, ptr %l13, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 60
  store ptr %t192, ptr %l130, !tbaa !29
  %t193 = load i32, ptr %l18, !tbaa !23
  %t194 = load i64, ptr %l14, !tbaa !24
  %t195 = load i32, ptr %l15, !tbaa !23
  %t196 = load %"compiler/source:Span", ptr %l19
  %t201 = call %"compiler/check:errBind" @compiler_2fcheck_3aerrBind_2ector(ptr %s5, i32 %t193, i64 %t194, i32 %t195, %"compiler/source:Span" %t196)
  store %"compiler/check:errBind" %t201, ptr %l135
  br label %bb39
bb39:
  %t202 = load ptr, ptr %l130, !tbaa !29
  %t203 = load %"compiler/check:errBind", ptr %l135
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2ePush_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t202, %"compiler/check:errBind" %t203)
  br label %bb40
bb40:
  %t204 = load ptr, ptr %l13, !tbaa !29
  %t206 = getelementptr %"compiler/check:frame", ptr %t204, i32 0, i32 61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t206, i1 false)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  store ptr null, ptr %l20, !tbaa !29
  %t208 = load i64, ptr %l14, !tbaa !24
  %t210 = icmp sge i64 %t208, 0
  br i1 %t210, label %bb43, label %bb44
bb43:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  store ptr %t217, ptr %l143, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t218)
  store ptr %t220, ptr %l145
  br label %bb45
bb44:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb48
bb45:
  %t221 = load ptr, ptr %l145, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Body", ptr %t221, i32 0, i32 7
  %t224 = load i64, ptr %l14, !tbaa !24
  %t227 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t223, i64 %t224)
  store %"compiler/typed:Local" %t227, ptr %l149
  br label %bb46
bb46:
  %t228 = getelementptr %"compiler/typed:Local", ptr %l149, i32 0, i32 2
  %t229 = load i32, ptr %t228, !tbaa !23
  %t230 = load ptr, ptr %l143, !tbaa !29
  %t232 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %t230, i32 %t229)
  store i1 %t232, ptr %l151
  br label %bb47
bb47:
  %t233 = load i1, ptr %l151, !tbaa !21
  store i1 %t233, ptr %l140, !tbaa !21
  br label %bb48
bb48:
  %t234 = load i1, ptr %l140, !tbaa !21
  store i1 %t234, ptr %l21, !tbaa !21
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Catch", ptr %t235, i32 0, i32 4
  %t238 = load i1, ptr %t237, !tbaa !21
  br i1 %t238, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb51
bb50:
  %t240 = load i1, ptr %l21, !tbaa !21
  store i1 %t240, ptr %l154, !tbaa !21
  br label %bb51
bb51:
  %t242 = load i1, ptr %l154, !tbaa !21
  br i1 %t242, label %bb52, label %bb53
bb52:
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr %"compiler/ast:Catch", ptr %t243, i32 0, i32 4
  %t246 = load i1, ptr %t245, !tbaa !21
  br i1 %t246, label %bb54, label %bb55
bb53:
  br label %bb103
bb54:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr %"compiler/ast:Catch", ptr %t248, i32 0, i32 2
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  store { i64, ptr } %t251, ptr %l158, !tbaa !27
  br label %bb60
bb55:
  %t253 = icmp sge i64 0, 0
  br i1 %t253, label %bb56, label %bb57
bb56:
  %t255 = icmp sle i64 0, 1152921504606846975
  br i1 %t255, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e0002d39d824213_e3bfdf913f3455ef)
  unreachable
bb58:
  %t257 = mul i64 0, 8
  %t258 = insertvalue { i64, ptr } undef, i64 0, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t259, ptr %l158, !tbaa !27
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_e0002d39d824213_e3bfdf913f3455ef)
  unreachable
bb60:
  %t261 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t261, ptr %l22, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l23, !tbaa !24
  %t266 = load i1, ptr %l3, !tbaa !21
  br i1 %t266, label %bb61, label %bb62
bb61:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr %"compiler/ast:Catch", ptr %t268, i32 0, i32 3
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t275 = icmp eq i64 %t273, 0
  store i1 %t275, ptr %l167, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb63
bb63:
  %t277 = load i1, ptr %l167, !tbaa !21
  br i1 %t277, label %bb64, label %bb65
bb64:
  %t278 = load i64, ptr %l23, !tbaa !24
  %t280 = icmp sgt i64 %t278, 0
  store i1 %t280, ptr %l172, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb66
bb66:
  %t282 = load i1, ptr %l172, !tbaa !21
  br i1 %t282, label %bb67, label %bb68
bb67:
  %t283 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t283, ptr %l175, !tbaa !27
  %t284 = load i64, ptr %l23, !tbaa !24
  %t286 = sub i64 %t284, 1
  %t288 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 %t286
  %t291 = load ptr, ptr %t290, !tbaa !39
  store ptr %t291, ptr %l24, !tbaa !29
  %t293 = load ptr, ptr %l24, !tbaa !29
  store ptr %t293, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t294 = load ptr, ptr %l179, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb69, label %bb70
bb68:
  br label %bb94
bb69:
  %t297 = load ptr, ptr %l179, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 22}
  %t300 = icmp eq i64 %t298, 0
  store i1 %t300, ptr %l180, !tbaa !21
  br label %bb70
bb70:
  %t301 = load i1, ptr %l180, !tbaa !21
  br i1 %t301, label %bb71, label %bb72
bb71:
  %t302 = load ptr, ptr %l24, !tbaa !29
  %t304 = getelementptr { i64, [4 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", ptr }, ptr %t304, i32 0, i32 1
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l25, !tbaa !29
  br label %bb73
bb72:
  br label %bb88
bb73:
  %t308 = load ptr, ptr %l25, !tbaa !29
  %t310 = call i1 @compiler_2fcheck_2estmtLike(ptr %v1, ptr %t308)
  store i1 %t310, ptr %l186
  br label %bb74
bb74:
  %t311 = load i1, ptr %l186, !tbaa !21
  %t312 = xor i1 %t311, true
  br i1 %t312, label %bb75, label %bb76
bb75:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l188, !tbaa !29
  %t315 = load ptr, ptr %l25, !tbaa !29
  %t317 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t315)
  store %"compiler/source:Span" %t317, ptr %l190
  br label %bb77
bb76:
  br label %bb88
bb77:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l191, !tbaa !29
  %t319 = load ptr, ptr %l25, !tbaa !29
  %t321 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t319)
  store %"compiler/source:Span" %t321, ptr %l193
  br label %bb78
bb78:
  %t322 = load ptr, ptr %l191, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l193
  %t324 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t322, %"compiler/source:Span" %t323)
  store { i64, ptr } %t324, ptr %l194
  br label %bb79
bb79:
  %t325 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t326 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %v0, { i64, ptr } %t325)
  store %"compiler/diagmsg:Msg" %t326, ptr %l195
  br label %bb80
bb80:
  %t327 = load ptr, ptr %l188, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l190
  %t329 = load %"compiler/diagmsg:Msg", ptr %l195
  %t330 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t327, %"compiler/source:Span" %t328, %"compiler/diagmsg:Msg" %t329)
  store i64 %t330, ptr %l196
  br label %bb81
bb81:
  %t331 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t331, ptr %l197, !tbaa !27
  %t332 = load i64, ptr %l23, !tbaa !24
  %t334 = sub i64 %t332, 1
  store i64 %t334, ptr %l199, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  store i64 %t336, ptr %l200, !tbaa !24
  %t337 = icmp sge i64 0, 0
  br i1 %t337, label %bb82, label %bb83
bb82:
  %t339 = load i64, ptr %l199, !tbaa !24
  %t340 = icmp sle i64 0, %t339
  br i1 %t340, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_f25f445d5459b9fe_e155a29b0e6cdb52)
  unreachable
bb84:
  %t342 = load i64, ptr %l199, !tbaa !24
  %t343 = load i64, ptr %l200, !tbaa !24
  %t344 = icmp sle i64 %t342, %t343
  br i1 %t344, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_f25f445d5459b9fe_e155a29b0e6cdb52)
  unreachable
bb86:
  %t346 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = load i64, ptr %l199, !tbaa !24
  %t349 = getelementptr ptr, ptr %t347, i64 0
  %t350 = sub i64 %t348, 0
  %t351 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t349, 1
  store { i64, ptr } %t352, ptr %l22, !tbaa !27
  br label %bb93
bb87:
  call void @__olang_check_failed(ptr @olang_loc_f25f445d5459b9fe_e155a29b0e6cdb52)
  unreachable
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_7a5b0973d8f0076e_d42fa20e68e1cea2)
  unreachable
bb93:
  br label %bb94
bb94:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/check:Checker", ptr %t354, i32 0, i32 45
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t356)
  store i64 %t358, ptr %l207
  br label %bb95
bb95:
  %t359 = load i64, ptr %l207, !tbaa !24
  store i64 %t359, ptr %l26, !tbaa !24
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr %"compiler/ast:Catch", ptr %t361, i32 0, i32 0
  %t364 = load %"compiler/source:Span", ptr %t363
  %t368 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t360, i32 4, %"compiler/source:Span" %t364)
  store { i64, i64, i64 } %t368, ptr %l212
  br label %bb96
bb96:
  %t369 = load { i64, i64, i64 }, ptr %l212
  store { i64, i64, i64 } %t369, ptr %l27
  %t370 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 0
  %t371 = load i64, ptr %t370, !tbaa !24
  store i64 %t371, ptr %l28, !tbaa !24
  %t373 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 1
  %t374 = load i64, ptr %t373, !tbaa !24
  store i64 %t374, ptr %l29, !tbaa !24
  %t376 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 2
  %t377 = load i64, ptr %t376, !tbaa !24
  store i64 %t377, ptr %l30, !tbaa !24
  %t379 = load i1, ptr %l21, !tbaa !21
  br i1 %t379, label %bb97, label %bb98
bb97:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr %"compiler/ast:Catch", ptr %t382, i32 0, i32 0
  %t385 = load %"compiler/source:Span", ptr %t384
  %t386 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtPayload(ptr %v0, ptr %t381, %"compiler/source:Span" %t385, i64 %t386)
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb100
bb100:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t390, { i64, ptr } %t391)
  br label %bb101
bb101:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i64, ptr %l28, !tbaa !24
  %t396 = load i64, ptr %l29, !tbaa !24
  %t397 = load i64, ptr %l30, !tbaa !24
  %t398 = load i64, ptr %l26, !tbaa !24
  %t404 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v4, ptr %t394, i64 %t395, i64 %t396, i64 %t397, i64 %t398)
  store ptr %t404, ptr %l228
  br label %bb102
bb102:
  %t405 = load ptr, ptr %l228, !tbaa !29
  store ptr %t405, ptr %l20, !tbaa !29
  br label %bb103
bb103:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 44
  %t411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t409)
  store i64 %t411, ptr %l232
  br label %bb104
bb104:
  %t412 = load i64, ptr %l232, !tbaa !24
  store i64 %t412, ptr %l31, !tbaa !24
  %t413 = load i1, ptr %l3, !tbaa !21
  br i1 %t413, label %bb105, label %bb106
bb105:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/ast:Catch", ptr %t415, i32 0, i32 3
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t418, 0
  %t422 = icmp sgt i64 %t420, 0
  store i1 %t422, ptr %l234, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb107
bb107:
  %t424 = load i1, ptr %l234, !tbaa !21
  br i1 %t424, label %bb108, label %bb109
bb108:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/check:Checker", ptr %t425, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = getelementptr %"compiler/generic:Program", ptr %t428, i32 0, i32 2
  %t431 = load i32, ptr %l2, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l244
  br label %bb110
bb109:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb111
bb110:
  %t435 = load i32, ptr %l244, !range !{i32 0, i32 33}
  %t437 = trunc i64 22 to i32
  %t438 = icmp eq i32 %t435, %t437
  store i1 %t438, ptr %l239, !tbaa !21
  br label %bb111
bb111:
  %t440 = load i1, ptr %l239, !tbaa !21
  br i1 %t440, label %bb112, label %bb113
bb112:
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr %"compiler/ast:Catch", ptr %t441, i32 0, i32 3
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t444, 0
  store i64 %t446, ptr %l250, !tbaa !24
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  store ptr %t452, ptr %l253, !tbaa !29
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/check:Checker", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l2, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l258
  br label %bb114
bb113:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb116
bb114:
  %t463 = load ptr, ptr %l253, !tbaa !29
  %t464 = load i32, ptr %l258, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t463, i32 %t464)
  store { i64, ptr } %t465, ptr %l259
  br label %bb115
bb115:
  %t466 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = load i64, ptr %l250, !tbaa !24
  %t470 = icmp ne i64 %t468, %t467
  store i1 %t470, ptr %l247, !tbaa !21
  br label %bb116
bb116:
  %t472 = load i1, ptr %l247, !tbaa !21
  store i1 %t472, ptr %l32, !tbaa !21
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr %"compiler/ast:Catch", ptr %t473, i32 0, i32 3
  %t476 = load { i64, ptr }, ptr %t475, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t480 = icmp sgt i64 %t478, 0
  br i1 %t480, label %bb117, label %bb118
bb117:
  %t482 = load i1, ptr %l32, !tbaa !21
  %t484 = xor i1 %t482, true
  store i1 %t484, ptr %l266, !tbaa !21
  br label %bb119
bb118:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb119
bb119:
  %t486 = load i1, ptr %l266, !tbaa !21
  br i1 %t486, label %bb120, label %bb121
bb120:
  %t487 = load i1, ptr %l3, !tbaa !21
  br i1 %t487, label %bb122, label %bb123
bb121:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb125
bb122:
  %t489 = load i32, ptr %l2, !tbaa !23
  %t490 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t493 = icmp eq i32 %t489, %t490
  store i1 %t493, ptr %l271, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb124
bb124:
  %t495 = load i1, ptr %l271, !tbaa !21
  %t496 = xor i1 %t495, true
  store i1 %t496, ptr %l269, !tbaa !21
  br label %bb125
bb125:
  %t498 = load i1, ptr %l269, !tbaa !21
  br i1 %t498, label %bb126, label %bb127
bb126:
  store i64 0, ptr %l33, !tbaa !24
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr %"compiler/ast:Catch", ptr %t499, i32 0, i32 3
  %t502 = load { i64, ptr }, ptr %t501, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t502, 0
  store i64 %t504, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t506 = load i64, ptr %l34, !tbaa !24
  %t507 = load i64, ptr %l33, !tbaa !24
  %t510 = icmp sgt i64 %t506, %t507
  br i1 %t510, label %bb128, label %bb129
bb127:
  br label %bb154
bb128:
  %t512 = load i64, ptr %l35, !tbaa !24
  %t514 = icmp sgt i64 %t512, 0
  br i1 %t514, label %bb130, label %bb131
bb129:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb133
bb130:
  %t516 = load i64, ptr %l34, !tbaa !24
  %t517 = load i64, ptr %l33, !tbaa !24
  %t520 = sub i64 %t516, %t517
  %t521 = load i64, ptr %l35, !tbaa !24
  %t524 = add i64 %t520, %t521
  %t526 = sub i64 %t524, 1
  %t527 = load i64, ptr %l35, !tbaa !24
  %t530 = sdiv i64 %t526, %t527
  store i64 %t530, ptr %l285, !tbaa !24
  br label %bb132
bb131:
  store i64 0, ptr %l285, !tbaa !24
  br label %bb132
bb132:
  %t532 = load i64, ptr %l285, !tbaa !24
  store i64 %t532, ptr %l282, !tbaa !24
  br label %bb133
bb133:
  %t533 = load i64, ptr %l282, !tbaa !24
  store i64 %t533, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb134
bb134:
  %t534 = load i64, ptr %l37, !tbaa !24
  %t535 = load i64, ptr %l36, !tbaa !24
  %t538 = icmp slt i64 %t534, %t535
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb135, label %bb136
bb135:
  br label %bb153
bb136:
  br label %bb137
bb137:
  %t542 = load i64, ptr %l33, !tbaa !24
  %t543 = load i64, ptr %l37, !tbaa !24
  %t544 = load i64, ptr %l35, !tbaa !24
  %t547 = mul i64 %t543, %t544
  %t550 = add i64 %t542, %t547
  store i64 %t550, ptr %l38, !tbaa !24
  %t552 = load i32, ptr %l2, !tbaa !23
  store i32 %t552, ptr %l39, !tbaa !23
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t556 = getelementptr %"compiler/check:Checker", ptr %t554, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !29
  %t559 = getelementptr %"compiler/generic:Program", ptr %t557, i32 0, i32 2
  %t560 = load i32, ptr %l2, !tbaa !23
  %t563 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t559, i32 %t560)
  store i32 %t563, ptr %l308
  br label %bb138
bb138:
  %t564 = load i32, ptr %l308, !range !{i32 0, i32 33}
  %t566 = trunc i64 22 to i32
  %t567 = icmp eq i32 %t564, %t566
  br i1 %t567, label %bb139, label %bb140
bb139:
  %t569 = load ptr, ptr %l1, !tbaa !29
  %t571 = getelementptr %"compiler/ast:Catch", ptr %t569, i32 0, i32 3
  %t572 = load { i64, ptr }, ptr %t571, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t576 = icmp sgt i64 %t574, 1
  store i1 %t576, ptr %l311, !tbaa !21
  br label %bb141
bb140:
  store i1 false, ptr %l311, !tbaa !21
  br label %bb141
bb141:
  %t578 = load i1, ptr %l311, !tbaa !21
  br i1 %t578, label %bb142, label %bb143
bb142:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = getelementptr %"compiler/check:Checker", ptr %t579, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t584 = getelementptr %"compiler/generic:Program", ptr %t582, i32 0, i32 2
  store ptr %t584, ptr %l318, !tbaa !29
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/check:Checker", ptr %t585, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t588, i32 0, i32 2
  %t591 = load i32, ptr %l2, !tbaa !23
  %t594 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t590, i32 %t591)
  store i32 %t594, ptr %l323
  br label %bb144
bb143:
  br label %bb149
bb144:
  %t595 = load ptr, ptr %l318, !tbaa !29
  %t596 = load i32, ptr %l323, !tbaa !23
  %t597 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t595, i32 %t596)
  store { i64, ptr } %t597, ptr %l324
  br label %bb145
bb145:
  %t598 = load { i64, ptr }, ptr %l324, !tbaa !27
  store { i64, ptr } %t598, ptr %l40, !tbaa !27
  %t599 = load i64, ptr %l38, !tbaa !24
  %t600 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t605 = icmp slt i64 %t599, %t602
  br i1 %t605, label %bb146, label %bb147
bb146:
  %t607 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t607, ptr %l329, !tbaa !27
  %t608 = load i64, ptr %l38, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l329, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr i32, ptr %t611, i64 %t608
  %t613 = load i32, ptr %t612, !tbaa !33
  store i32 %t613, ptr %l39, !tbaa !23
  br label %bb148
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/check:Checker", ptr %t615, i32 0, i32 44
  store ptr %t617, ptr %l333, !tbaa !29
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr %"compiler/ast:Catch", ptr %t619, i32 0, i32 3
  %t622 = load { i64, ptr }, ptr %t621, !tbaa !27
  store { i64, ptr } %t622, ptr %l336, !tbaa !27
  %t623 = load i64, ptr %l38, !tbaa !24
  %t625 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t626 = load ptr, ptr %t625, !tbaa !27
  %t627 = getelementptr ptr, ptr %t626, i64 %t623
  %t628 = load ptr, ptr %t627, !tbaa !39
  %t629 = load i32, ptr %l39, !tbaa !23
  %t633 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t618, ptr %t628, i32 %t629)
  store ptr %t633, ptr %l340
  br label %bb150
bb150:
  %t634 = load ptr, ptr %l333, !tbaa !29
  %t635 = load ptr, ptr %l340, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t634, ptr %t635)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t636 = load i64, ptr %l37, !tbaa !24
  %t638 = add i64 %t636, 1
  store i64 %t638, ptr %l37, !tbaa !24
  br label %bb134
bb153:
  br label %bb154
bb154:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/check:Checker", ptr %t640, i32 0, i32 44
  %t643 = load i64, ptr %l31, !tbaa !24
  %t646 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t642, i64 %t643)
  store { i64, ptr } %t646, ptr %l346
  br label %bb155
bb155:
  %t647 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t647, ptr %l41, !tbaa !27
  %t648 = load i64, ptr %l14, !tbaa !24
  %t650 = icmp sge i64 %t648, 0
  br i1 %t650, label %bb156, label %bb157
bb156:
  %t652 = load ptr, ptr %l13, !tbaa !29
  %t654 = getelementptr %"compiler/check:frame", ptr %t652, i32 0, i32 60
  %t655 = load i64, ptr %l16, !tbaa !24
  %t658 = call %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t654, i64 %t655)
  store %"compiler/check:errBind" %t658, ptr %l352
  br label %bb158
bb157:
  br label %bb177
bb158:
  %t659 = load %"compiler/check:errBind", ptr %l352
  store %"compiler/check:errBind" %t659, ptr %l42
  %t660 = load ptr, ptr %l13, !tbaa !29
  %t662 = getelementptr %"compiler/check:frame", ptr %t660, i32 0, i32 61
  %t663 = load i64, ptr %l16, !tbaa !24
  %t666 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t662, i64 %t663)
  store i1 %t666, ptr %l356
  br label %bb159
bb159:
  %t667 = load i1, ptr %l356, !tbaa !21
  %t668 = xor i1 %t667, true
  br i1 %t668, label %bb160, label %bb161
bb160:
  store %olang.scope zeroinitializer, ptr %s18
  %t670 = load ptr, ptr %l0, !tbaa !29
  store ptr %t670, ptr %l358, !tbaa !29
  %t671 = getelementptr %"compiler/check:errBind", ptr %l42, i32 0, i32 3
  %t672 = load %"compiler/source:Span", ptr %t671
  store %"compiler/source:Span" %t672, ptr %l359
  %t673 = load i1, ptr %l7, !tbaa !21
  %t675 = xor i1 %t673, true
  br i1 %t675, label %bb162, label %bb163
bb161:
  br label %bb173
bb162:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = getelementptr %"compiler/check:errBind", ptr %l42, i32 0, i32 0
  %t679 = load i32, ptr %t678, !tbaa !23
  %t682 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t677, i32 %t679)
  store { i64, ptr } %t682, ptr %l365
  br label %bb164
bb163:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t684 = getelementptr %"compiler/check:errBind", ptr %l42, i32 0, i32 0
  %t685 = load i32, ptr %t684, !tbaa !23
  %t688 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t683, i32 %t685)
  store { i64, ptr } %t688, ptr %l370
  br label %bb166
bb164:
  %t689 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t690 = extractvalue { i64, ptr } %t689, 0
  %t691 = extractvalue { i64, ptr } %t689, 1
  %t692 = mul i64 %t690, 1
  %t693 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t692)
  call void @llvm.memcpy.p0.p0.i64(ptr %t693, ptr %t691, i64 %t692, i1 false)
  %t694 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t695 = insertvalue { i64, ptr } %t694, ptr %t693, 1
  %t697 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameUnused(ptr %s18, ptr %v0, { i64, ptr } %t695)
  store %"compiler/diagmsg:Msg" %t697, ptr %l367
  br label %bb165
bb165:
  %t698 = load %"compiler/diagmsg:Msg", ptr %l367
  store %"compiler/diagmsg:Msg" %t698, ptr %l362
  br label %bb171
bb166:
  %t699 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 0
  %t701 = extractvalue { i64, ptr } %t699, 1
  %t702 = mul i64 %t700, 1
  %t703 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t702)
  call void @llvm.memcpy.p0.p0.i64(ptr %t703, ptr %t701, i64 %t702, i1 false)
  %t704 = insertvalue { i64, ptr } undef, i64 %t700, 0
  %t705 = insertvalue { i64, ptr } %t704, ptr %t703, 1
  store { i64, ptr } %t705, ptr %l371, !tbaa !27
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  store ptr %t709, ptr %l373, !tbaa !29
  %t710 = load ptr, ptr %l0, !tbaa !29
  %t712 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t710)
  store ptr %t712, ptr %l375
  br label %bb167
bb167:
  %t713 = load ptr, ptr %l375, !tbaa !29
  %t715 = getelementptr %"compiler/check:frame", ptr %t713, i32 0, i32 1
  %t716 = load i64, ptr %t715, !tbaa !24
  store i64 %t716, ptr %l377, !tbaa !24
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t718 = getelementptr %"compiler/check:errBind", ptr %l42, i32 0, i32 0
  %t719 = load i32, ptr %t718, !tbaa !23
  %t722 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t717, i32 %t719)
  store { i64, ptr } %t722, ptr %l380
  br label %bb168
bb168:
  %t723 = load ptr, ptr %l373, !tbaa !29
  %t724 = load i64, ptr %l377, !tbaa !24
  %t725 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t726 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorTypeHint(ptr %v0, ptr %v0, ptr %s18, ptr %t723, i64 %t724, { i64, ptr } %t725)
  store { i64, ptr } %t726, ptr %l381
  br label %bb169
bb169:
  %t727 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t728 = extractvalue { i64, ptr } %t727, 0
  %t729 = extractvalue { i64, ptr } %t727, 1
  %t730 = mul i64 %t728, 1
  %t731 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t730)
  call void @llvm.memcpy.p0.p0.i64(ptr %t731, ptr %t729, i64 %t730, i1 false)
  %t732 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t733 = insertvalue { i64, ptr } %t732, ptr %t731, 1
  %t734 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t736 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchLoneUnused(ptr %s18, ptr %s18, ptr %v0, { i64, ptr } %t734, { i64, ptr } %t733)
  store %"compiler/diagmsg:Msg" %t736, ptr %l383
  br label %bb170
bb170:
  %t737 = load %"compiler/diagmsg:Msg", ptr %l383
  store %"compiler/diagmsg:Msg" %t737, ptr %l362
  br label %bb171
bb171:
  %t738 = load ptr, ptr %l358, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l359
  %t740 = load %"compiler/diagmsg:Msg", ptr %l362
  %t741 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t738, %"compiler/source:Span" %t739, %"compiler/diagmsg:Msg" %t740)
  store i64 %t741, ptr %l384
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s18)
  br label %bb173
bb173:
  %t742 = load ptr, ptr %l13, !tbaa !29
  %t744 = getelementptr %"compiler/check:frame", ptr %t742, i32 0, i32 60
  %t745 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eTrunca_H5bf147fe04fb910fd8a08f646d33c634(ptr %v0, ptr %t744, i64 %t745)
  br label %bb174
bb174:
  %t748 = load ptr, ptr %l13, !tbaa !29
  %t750 = getelementptr %"compiler/check:frame", ptr %t748, i32 0, i32 61
  %t751 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %t750, i64 %t751)
  br label %bb175
bb175:
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t755 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %t754, i64 %t755)
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t758 = load ptr, ptr %l1, !tbaa !29
  %t760 = getelementptr %"compiler/ast:Catch", ptr %t758, i32 0, i32 0
  %t761 = load %"compiler/source:Span", ptr %t760
  store %"compiler/source:Span" %t761, ptr %l394
  %t762 = ptrtoint ptr %v4 to i64
  store i64 %t762, ptr %l395, !tbaa !24
  %t763 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aClause_2e1
  br i1 %t763, label %bb178, label %bb179
bb178:
  %t765 = call ptr @__olang_region_make(ptr %v4)
  %t766 = ptrtoint ptr %t765 to i64
  store i64 %t766, ptr %l395, !tbaa !24
  br label %bb179
bb179:
  %t767 = load i64, ptr %l395
  %t768 = inttoptr i64 %t767 to ptr
  %t770 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s0, ptr %t768, ptr %l6)
  store { i64, ptr } %t770, ptr %l398
  br label %bb180
bb180:
  %t771 = load i1, ptr %l12, !tbaa !21
  %t772 = load ptr, ptr %l20, !tbaa !29
  %t773 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t774 = load i64, ptr %l14, !tbaa !24
  %t775 = load i32, ptr %l15, !tbaa !23
  %t776 = load %"compiler/source:Span", ptr %l394
  %t777 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t783 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, %"compiler/source:Span" %t776, { i64, ptr } %t777, i1 %t771, ptr %t772, { i64, ptr } %t773, i64 %t774, i32 %t775)
  store %"compiler/typed:Clause" %t783, ptr %l404
  br label %bb181
bb181:
  %t784 = load %"compiler/typed:Clause", ptr %l404
  %t785 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 72, i64 8)
  store %"compiler/typed:Clause" %t784, ptr %t785
  call void @__olang_scope_close(ptr %s0)
  store ptr %t785, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %lp26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i64
  %l86 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca %"compiler/generic:Context"
  %l102 = alloca %"compiler/generic:Context"
  %l104 = alloca %"compiler/generic:Context"
  %l110 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l124 = alloca i64
  %l134 = alloca { i64, ptr }
  %l145 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l166 = alloca i32
  %l169 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l196 = alloca %"compiler/diagmsg:Msg"
  %l197 = alloca i64
  %l200 = alloca i64
  %l206 = alloca i64
  %l209 = alloca i64
  %l228 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca i32
  %l253 = alloca %"compiler/typed:Make"
  %l262 = alloca { i64, ptr }
  %l263 = alloca %"compiler/typed:Block"
  %l265 = alloca ptr
  %l270 = alloca i1
  %l273 = alloca i1
  %l275 = alloca ptr
  %l279 = alloca i1
  %l281 = alloca i1
  %l283 = alloca ptr
  %l285 = alloca %"compiler/source:Span"
  %l286 = alloca %"compiler/diagmsg:Msg"
  %l287 = alloca i64
  %l289 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l298 = alloca %"compiler/source:Span"
  %l299 = alloca i32
  %l302 = alloca i32
  %l303 = alloca { i64, ptr }
  %l308 = alloca i32
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t149 = alloca %"compiler/generic:Context", align 8
  %t387 = alloca { i64, [3 x i64] }, align 8
  %t579 = alloca { i64, [5 x i64] }, align 8
  %t591 = alloca { i64, [3 x i64] }, align 8
  %t696 = alloca { i64, [4 x i64] }, align 8
  %t708 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l30, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Catch", ptr %t16, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i1, ptr %l5, !tbaa !21
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l41, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l44, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l44, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i1, ptr %l5, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l49, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store %"compiler/source:Span" %t52, ptr %l55
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t53 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
  store %"compiler/diagmsg:Msg" %t53, ptr %l56
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l52, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l55
  %t56 = load %"compiler/diagmsg:Msg", ptr %l56
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t54, %"compiler/source:Span" %t55, %"compiler/diagmsg:Msg" %t56)
  store i64 %t57, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l61, !tbaa !23
  br label %bb24
bb23:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t65, ptr %l61, !tbaa !23
  br label %bb24
bb24:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l6, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 0, i32 %t74, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t77, ptr %l68
  br label %bb25
bb25:
  %t78 = load i32, ptr %l68, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l70
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l70, !tbaa !29
  store ptr %t82, ptr %l8, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 20
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l73
  br label %bb27
bb27:
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t105 = load i32, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Catch", ptr %t110, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t91, { i64, [2 x i64] } %t104, i32 %t105, i64 %t109, %"compiler/source:Span" %t113)
  store i64 %t119, ptr %l86
  br label %bb28
bb28:
  %t120 = load i64, ptr %l86, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 23
  %t124 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t123, i64 %t124, i64 1)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/check:frame", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i32, ptr %l6, !tbaa !23
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t127, i64 %t128, i64 %t132, i32 %t133, i32 0)
  store ptr %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load ptr, ptr %l95, !tbaa !29
  store ptr %t139, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l11, !tbaa !29
  store ptr %t140, ptr %l96, !tbaa !29
  %t141 = ptrtoint ptr %v0 to i64
  store i64 %t141, ptr %l97, !tbaa !24
  %t142 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t142, label %bb31, label %bb32
bb31:
  %t144 = call ptr @__olang_region_make(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l97, !tbaa !24
  br label %bb32
bb32:
  %t146 = load ptr, ptr %l8, !tbaa !29
  %t148 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t148, i64 160, i1 false)
  %t150 = load i64, ptr %l97
  %t151 = inttoptr i64 %t150 to ptr
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t149, ptr %t151, ptr %l100)
  call void @llvm.memmove.p0.p0.i64(ptr %l102, ptr %t149, i64 160, i1 false)
  br label %bb33
bb33:
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t153, label %bb34, label %bb35
bb34:
  %t155 = load i64, ptr %l97
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = getelementptr %"compiler/generic:Context", ptr %l102, i32 0, i32 3
  %t158 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t157, i32 0, i32 2
  %t159 = load { i64, ptr }, ptr %t158
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = call ptr @__olang_region_or(ptr %t160, ptr null)
  %t162 = call ptr @__olang_region_home(ptr %t161)
  %t163 = icmp ne ptr %t162, null
  %t164 = select i1 %t163, ptr %t162, ptr null
  %t165 = getelementptr %"compiler/generic:Context", ptr %l102, i32 0, i32 3
  %t166 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t165, i32 0, i32 1
  %t167 = load { i64, ptr }, ptr %t166
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = call ptr @__olang_region_or(ptr %t168, ptr null)
  %t170 = call ptr @__olang_region_home(ptr %t169)
  %t171 = icmp ne ptr %t170, null
  %t172 = select i1 %t171, ptr %t170, ptr %t164
  %t173 = getelementptr %"compiler/generic:Context", ptr %l102, i32 0, i32 3
  %t174 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t173, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = call ptr @__olang_region_or(ptr %t176, ptr null)
  %t178 = call ptr @__olang_region_home(ptr %t177)
  %t179 = icmp ne ptr %t178, null
  %t180 = select i1 %t179, ptr %t178, ptr %t172
  %t181 = getelementptr %"compiler/generic:Context", ptr %l102, i32 0, i32 2
  %t182 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t181, i32 0, i32 2
  %t183 = load { i64, ptr }, ptr %t182
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = call ptr @__olang_region_or(ptr %t184, ptr null)
  %t186 = call ptr @__olang_region_home(ptr %t185)
  %t187 = icmp ne ptr %t186, null
  %t188 = select i1 %t187, ptr %t186, ptr %t180
  %t189 = getelementptr %"compiler/generic:Context", ptr %l102, i32 0, i32 2
  %t190 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t189, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = call ptr @__olang_region_or(ptr %t192, ptr null)
  %t194 = call ptr @__olang_region_home(ptr %t193)
  %t195 = icmp ne ptr %t194, null
  %t196 = select i1 %t195, ptr %t194, ptr %t188
  %t197 = getelementptr %"compiler/generic:Context", ptr %l102, i32 0, i32 2
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = call ptr @__olang_region_or(ptr %t200, ptr null)
  %t202 = call ptr @__olang_region_home(ptr %t201)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr %t196
  %t205 = icmp eq ptr %t204, %t156
  call void @__olang_region_settle(ptr %t156, i1 %t205)
  br label %bb35
bb35:
  %t206 = load ptr, ptr %l96, !tbaa !29
  %t207 = getelementptr %"compiler/check:frame", ptr %t206, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l104, ptr %t207, i64 160, i1 false)
  %t208 = load ptr, ptr %l96, !tbaa !29
  %t209 = getelementptr %"compiler/check:frame", ptr %t208, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t209, ptr %l102, i64 160, i1 false)
  %t210 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t210, label %bb36, label %bb37
bb36:
  %t212 = getelementptr %"compiler/generic:Context", ptr %l104, i32 0, i32 3
  %t213 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t212, i32 0, i32 2
  %t214 = load { i64, ptr }, ptr %t213
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = call ptr @__olang_region_or(ptr %t215, ptr null)
  %t217 = call ptr @__olang_region_home(ptr %t216)
  %t218 = icmp ne ptr %t217, null
  %t219 = select i1 %t218, ptr %t217, ptr null
  %t220 = getelementptr %"compiler/generic:Context", ptr %l104, i32 0, i32 3
  %t221 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t220, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = call ptr @__olang_region_or(ptr %t223, ptr null)
  %t225 = call ptr @__olang_region_home(ptr %t224)
  %t226 = icmp ne ptr %t225, null
  %t227 = select i1 %t226, ptr %t225, ptr %t219
  %t228 = getelementptr %"compiler/generic:Context", ptr %l104, i32 0, i32 3
  %t229 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t228, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = call ptr @__olang_region_or(ptr %t231, ptr null)
  %t233 = call ptr @__olang_region_home(ptr %t232)
  %t234 = icmp ne ptr %t233, null
  %t235 = select i1 %t234, ptr %t233, ptr %t227
  %t236 = getelementptr %"compiler/generic:Context", ptr %l104, i32 0, i32 2
  %t237 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t236, i32 0, i32 2
  %t238 = load { i64, ptr }, ptr %t237
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = call ptr @__olang_region_or(ptr %t239, ptr null)
  %t241 = call ptr @__olang_region_home(ptr %t240)
  %t242 = icmp ne ptr %t241, null
  %t243 = select i1 %t242, ptr %t241, ptr %t235
  %t244 = getelementptr %"compiler/generic:Context", ptr %l104, i32 0, i32 2
  %t245 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t244, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245
  %t247 = extractvalue { i64, ptr } %t246, 1
  %t248 = call ptr @__olang_region_or(ptr %t247, ptr null)
  %t249 = call ptr @__olang_region_home(ptr %t248)
  %t250 = icmp ne ptr %t249, null
  %t251 = select i1 %t250, ptr %t249, ptr %t243
  %t252 = getelementptr %"compiler/generic:Context", ptr %l104, i32 0, i32 2
  %t253 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t252, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = call ptr @__olang_region_home(ptr %t256)
  %t258 = icmp ne ptr %t257, null
  %t259 = select i1 %t258, ptr %t257, ptr %t251
  call void @__olang_region_drop(ptr %t259)
  store %"compiler/generic:Context" zeroinitializer, ptr %l104
  br label %bb37
bb37:
  %t260 = load ptr, ptr %l11, !tbaa !29
  %t261 = load i64, ptr %l9, !tbaa !24
  %t264 = getelementptr %"compiler/check:frame", ptr %t260, i32 0, i32 19
  store i64 %t261, ptr %t264, !tbaa !24
  %t265 = load ptr, ptr %l11, !tbaa !29
  %t267 = getelementptr %"compiler/check:frame", ptr %t265, i32 0, i32 32
  store i1 true, ptr %t267, !tbaa !21
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t268)
  store ptr %t270, ptr %l110
  br label %bb38
bb38:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr %"compiler/ast:Catch", ptr %t271, i32 0, i32 0
  %t274 = load %"compiler/source:Span", ptr %t273
  %t275 = load ptr, ptr %l110, !tbaa !29
  %t278 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t275, i32 -1, i32 0, %"compiler/source:Span" %t274)
  store i32 %t278, ptr %l114
  br label %bb39
bb39:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t279)
  store ptr %t281, ptr %l116
  br label %bb40
bb40:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t286 = load i32, ptr %l7, !tbaa !23
  %t289 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t285, i32 %t286)
  store { i64, ptr } %t289, ptr %l120
  br label %bb41
bb41:
  %t290 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = mul i64 %t291, 8
  %t294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  %t297 = load ptr, ptr %l116, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t297, { i64, ptr } %t296)
  br label %bb42
bb42:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 45
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t301)
  store i64 %t303, ptr %l124
  br label %bb43
bb43:
  %t304 = load i64, ptr %l124, !tbaa !24
  store i64 %t304, ptr %l12, !tbaa !24
  %t305 = load i1, ptr %l4, !tbaa !21
  br i1 %t305, label %bb44, label %bb45
bb44:
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr %"compiler/ast:Catch", ptr %t307, i32 0, i32 2
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t312 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  store i64 %t314, ptr %l15, !tbaa !24
  br label %bb46
bb45:
  br label %bb53
bb46:
  %t316 = load i64, ptr %l14, !tbaa !24
  %t317 = load i64, ptr %l15, !tbaa !24
  %t320 = icmp slt i64 %t316, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb47, label %bb48
bb47:
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t324 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t324, ptr %l134, !tbaa !27
  %t325 = load i64, ptr %l14, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr ptr, ptr %t328, i64 %t325
  %t330 = load ptr, ptr %t329, !tbaa !39
  %t332 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t332, ptr %t330)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t337 = load i64, ptr %l14, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l14, !tbaa !24
  br label %bb46
bb52:
  br label %bb53
bb53:
  %t341 = load i1, ptr %l5, !tbaa !21
  br i1 %t341, label %bb54, label %bb55
bb54:
  %t343 = load i64, ptr %l3, !tbaa !24
  %t345 = icmp eq i64 %t343, 1
  br i1 %t345, label %bb56, label %bb57
bb55:
  br label %bb97
bb56:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb58
bb57:
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t349 = getelementptr %"compiler/ast:Catch", ptr %t347, i32 0, i32 3
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t354 = icmp eq i64 %t352, 1
  store i1 %t354, ptr %l145, !tbaa !21
  br label %bb58
bb58:
  %t356 = load i1, ptr %l145, !tbaa !21
  br i1 %t356, label %bb59, label %bb60
bb59:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l150, !tbaa !29
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr %"compiler/ast:Catch", ptr %t358, i32 0, i32 0
  %t361 = load %"compiler/source:Span", ptr %t360
  store %"compiler/source:Span" %t361, ptr %l152
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr %"compiler/ast:Catch", ptr %t363, i32 0, i32 3
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  store { i64, ptr } %t366, ptr %l155, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr ptr, ptr %t368, i64 0
  %t370 = load ptr, ptr %t369, !tbaa !39
  %t371 = load i32, ptr %l2, !tbaa !23
  %t375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t362, ptr %t370, i32 %t371)
  store ptr %t375, ptr %l158
  br label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/check:Checker", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t381 = getelementptr %"compiler/generic:Program", ptr %t379, i32 0, i32 2
  %t382 = load i32, ptr %l2, !tbaa !23
  %t385 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t381, i32 %t382)
  store i32 %t385, ptr %l166
  br label %bb63
bb61:
  %t386 = load ptr, ptr %l158, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t387
  %t388 = getelementptr { i64, [3 x i64] }, ptr %t387, i32 0, i32 0
  store i64 6, ptr %t388
  %t389 = load %"compiler/source:Span", ptr %l152
  %t390 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t389, 0
  %t392 = insertvalue { %"compiler/source:Span", ptr } %t390, ptr %t386, 1
  %t393 = getelementptr { i64, [3 x i64] }, ptr %t387, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t392, ptr %t393
  %t394 = load { i64, [3 x i64] }, ptr %t387
  %t396 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t394, ptr %t396
  %t397 = load ptr, ptr %l150, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t397, ptr %t396)
  br label %bb62
bb62:
  br label %bb96
bb63:
  %t399 = load i32, ptr %l166, !range !{i32 0, i32 33}
  %t401 = trunc i64 22 to i32
  %t402 = icmp eq i32 %t399, %t401
  br i1 %t402, label %bb64, label %bb65
bb64:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/check:Checker", ptr %t404, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !29
  %t409 = getelementptr %"compiler/generic:Program", ptr %t407, i32 0, i32 2
  store ptr %t409, ptr %l172, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/check:Checker", ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = getelementptr %"compiler/generic:Program", ptr %t413, i32 0, i32 2
  %t416 = load i32, ptr %l2, !tbaa !23
  %t419 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t415, i32 %t416)
  store i32 %t419, ptr %l177
  br label %bb66
bb65:
  %t420 = icmp sge i64 0, 0
  br i1 %t420, label %bb68, label %bb69
bb66:
  %t422 = load ptr, ptr %l172, !tbaa !29
  %t423 = load i32, ptr %l177, !tbaa !23
  %t424 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s9, ptr %t422, i32 %t423)
  store { i64, ptr } %t424, ptr %l178
  br label %bb67
bb67:
  %t425 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t425, ptr %l169, !tbaa !27
  br label %bb72
bb68:
  %t426 = icmp sle i64 0, 2305843009213693951
  br i1 %t426, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb70:
  %t428 = mul i64 0, 4
  %t429 = insertvalue { i64, ptr } undef, i64 0, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t430, ptr %l169, !tbaa !27
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb72:
  %t432 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t432, ptr %l17, !tbaa !27
  %t433 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr %"compiler/ast:Catch", ptr %t436, i32 0, i32 3
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t444 = icmp ne i64 %t435, %t441
  br i1 %t444, label %bb73, label %bb74
bb73:
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l188, !tbaa !29
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr %"compiler/ast:Catch", ptr %t447, i32 0, i32 0
  %t450 = load %"compiler/source:Span", ptr %t449
  store %"compiler/source:Span" %t450, ptr %l190
  %t451 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = getelementptr %"compiler/ast:Catch", ptr %t454, i32 0, i32 3
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t462 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %t453, i64 %t459)
  store %"compiler/diagmsg:Msg" %t462, ptr %l196
  br label %bb75
bb74:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/check:Checker", ptr %t463, i32 0, i32 44
  %t467 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t465)
  store i64 %t467, ptr %l200
  br label %bb77
bb75:
  %t468 = load ptr, ptr %l188, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l190
  %t470 = load %"compiler/diagmsg:Msg", ptr %l196
  %t471 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t468, %"compiler/source:Span" %t469, %"compiler/diagmsg:Msg" %t470)
  store i64 %t471, ptr %l197
  br label %bb76
bb76:
  br label %bb95
bb77:
  %t472 = load i64, ptr %l200, !tbaa !24
  store i64 %t472, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t473 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 0
  store i64 %t475, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t477 = load i64, ptr %l20, !tbaa !24
  %t478 = load i64, ptr %l19, !tbaa !24
  %t481 = icmp sgt i64 %t477, %t478
  br i1 %t481, label %bb78, label %bb79
bb78:
  %t483 = load i64, ptr %l21, !tbaa !24
  %t485 = icmp sgt i64 %t483, 0
  br i1 %t485, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l206, !tbaa !24
  br label %bb83
bb80:
  %t487 = load i64, ptr %l20, !tbaa !24
  %t488 = load i64, ptr %l19, !tbaa !24
  %t491 = sub i64 %t487, %t488
  %t492 = load i64, ptr %l21, !tbaa !24
  %t495 = add i64 %t491, %t492
  %t497 = sub i64 %t495, 1
  %t498 = load i64, ptr %l21, !tbaa !24
  %t501 = sdiv i64 %t497, %t498
  store i64 %t501, ptr %l209, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l209, !tbaa !24
  br label %bb82
bb82:
  %t503 = load i64, ptr %l209, !tbaa !24
  store i64 %t503, ptr %l206, !tbaa !24
  br label %bb83
bb83:
  %t504 = load i64, ptr %l206, !tbaa !24
  store i64 %t504, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb84
bb84:
  %t505 = load i64, ptr %l23, !tbaa !24
  %t506 = load i64, ptr %l22, !tbaa !24
  %t509 = icmp slt i64 %t505, %t506
  %t511 = xor i1 %t509, true
  br i1 %t511, label %bb85, label %bb86
bb85:
  br label %bb91
bb86:
  br label %bb87
bb87:
  %t513 = load i64, ptr %l19, !tbaa !24
  %t514 = load i64, ptr %l23, !tbaa !24
  %t515 = load i64, ptr %l21, !tbaa !24
  %t518 = mul i64 %t514, %t515
  %t521 = add i64 %t513, %t518
  store i64 %t521, ptr %l24, !tbaa !24
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t525 = getelementptr %"compiler/check:Checker", ptr %t523, i32 0, i32 44
  store ptr %t525, ptr %l228, !tbaa !29
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr %"compiler/ast:Catch", ptr %t527, i32 0, i32 3
  %t530 = load { i64, ptr }, ptr %t529, !tbaa !27
  store { i64, ptr } %t530, ptr %l231, !tbaa !27
  %t531 = load i64, ptr %l24, !tbaa !24
  %t533 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = getelementptr ptr, ptr %t534, i64 %t531
  %t536 = load ptr, ptr %t535, !tbaa !39
  %t537 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t537, ptr %l234, !tbaa !27
  %t538 = load i64, ptr %l24, !tbaa !24
  %t540 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr i32, ptr %t541, i64 %t538
  %t543 = load i32, ptr %t542, !tbaa !33
  %t547 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t526, ptr %t536, i32 %t543)
  store ptr %t547, ptr %l237
  br label %bb88
bb88:
  %t548 = load ptr, ptr %l228, !tbaa !29
  %t549 = load ptr, ptr %l237, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t548, ptr %t549)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t550 = load i64, ptr %l23, !tbaa !24
  %t552 = add i64 %t550, 1
  store i64 %t552, ptr %l23, !tbaa !24
  br label %bb84
bb91:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t556 = getelementptr %"compiler/check:Checker", ptr %t554, i32 0, i32 44
  %t557 = load i64, ptr %l18, !tbaa !24
  %t560 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t556, i64 %t557)
  store { i64, ptr } %t560, ptr %l243
  br label %bb92
bb92:
  %t561 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l244, !tbaa !29
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr %"compiler/ast:Catch", ptr %t563, i32 0, i32 0
  %t566 = load %"compiler/source:Span", ptr %t565
  store %"compiler/source:Span" %t566, ptr %l246
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr %"compiler/ast:Catch", ptr %t567, i32 0, i32 0
  %t570 = load %"compiler/source:Span", ptr %t569
  store %"compiler/source:Span" %t570, ptr %l248
  %t571 = load i32, ptr %l2, !tbaa !23
  store i32 %t571, ptr %l249, !tbaa !23
  %t576 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t561, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t576, ptr %l253
  br label %bb93
bb93:
  %t577 = load %"compiler/typed:Make", ptr %l253
  %t578 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t577, ptr %t578
  store { i64, [5 x i64] } zeroinitializer, ptr %t579
  %t580 = getelementptr { i64, [5 x i64] }, ptr %t579, i32 0, i32 0
  store i64 7, ptr %t580
  %t581 = load %"compiler/source:Span", ptr %l248
  %t582 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t581, 0
  %t583 = load i32, ptr %l249, !tbaa !23
  %t584 = insertvalue { %"compiler/source:Span", i32, ptr } %t582, i32 %t583, 1
  %t586 = insertvalue { %"compiler/source:Span", i32, ptr } %t584, ptr %t578, 2
  %t587 = getelementptr { i64, [5 x i64] }, ptr %t579, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t586, ptr %t587
  %t588 = load { i64, [5 x i64] }, ptr %t579
  %t590 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t588, ptr %t590
  store { i64, [3 x i64] } zeroinitializer, ptr %t591
  %t592 = getelementptr { i64, [3 x i64] }, ptr %t591, i32 0, i32 0
  store i64 6, ptr %t592
  %t593 = load %"compiler/source:Span", ptr %l246
  %t594 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t593, 0
  %t596 = insertvalue { %"compiler/source:Span", ptr } %t594, ptr %t590, 1
  %t597 = getelementptr { i64, [3 x i64] }, ptr %t591, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t596, ptr %t597
  %t598 = load { i64, [3 x i64] }, ptr %t591
  %t600 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t598, ptr %t600
  %t601 = load ptr, ptr %l244, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t601, ptr %t600)
  br label %bb94
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s9)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/check:Checker", ptr %t603, i32 0, i32 45
  %t606 = load i64, ptr %l12, !tbaa !24
  %t609 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t605, i64 %t606)
  store { i64, ptr } %t609, ptr %l262
  br label %bb98
bb98:
  %t610 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t611 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t610)
  store %"compiler/typed:Block" %t611, ptr %l263
  br label %bb99
bb99:
  %t612 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t612, ptr %lp26
  %t613 = load %"compiler/typed:Block", ptr %l263
  %t614 = load ptr, ptr %lp26
  store %"compiler/typed:Block" %t613, ptr %t614
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t615)
  store ptr %t617, ptr %l265
  br label %bb100
bb100:
  %t618 = load ptr, ptr %l265, !tbaa !29
  %t619 = load ptr, ptr %lp26
  %t622 = getelementptr %"compiler/typed:Body", ptr %t618, i32 0, i32 11
  store ptr %t619, ptr %t622, !tbaa !29
  %t623 = load i64, ptr %l3, !tbaa !24
  %t625 = icmp sgt i64 %t623, 0
  br i1 %t625, label %bb101, label %bb102
bb101:
  %t627 = load i1, ptr %l5, !tbaa !21
  %t629 = xor i1 %t627, true
  store i1 %t629, ptr %l270, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb103
bb103:
  %t631 = load i1, ptr %l270, !tbaa !21
  br i1 %t631, label %bb104, label %bb105
bb104:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t634 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t632)
  store ptr %t634, ptr %l275
  br label %bb106
bb105:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb107
bb106:
  %t635 = load ptr, ptr %l275, !tbaa !29
  %t637 = getelementptr %"compiler/check:frame", ptr %t635, i32 0, i32 18
  %t638 = load i1, ptr %t637, !tbaa !21
  %t640 = xor i1 %t638, true
  store i1 %t640, ptr %l273, !tbaa !21
  br label %bb107
bb107:
  %t642 = load i1, ptr %l273, !tbaa !21
  br i1 %t642, label %bb108, label %bb109
bb108:
  %t643 = load ptr, ptr %lp26
  %t645 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t643)
  store i1 %t645, ptr %l281
  br label %bb110
bb109:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb111
bb110:
  %t646 = load i1, ptr %l281, !tbaa !21
  %t647 = xor i1 %t646, true
  store i1 %t647, ptr %l279, !tbaa !21
  br label %bb111
bb111:
  %t649 = load i1, ptr %l279, !tbaa !21
  br i1 %t649, label %bb112, label %bb113
bb112:
  %t650 = load ptr, ptr %l0, !tbaa !29
  store ptr %t650, ptr %l283, !tbaa !29
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t653 = getelementptr %"compiler/ast:Catch", ptr %t651, i32 0, i32 0
  %t654 = load %"compiler/source:Span", ptr %t653
  store %"compiler/source:Span" %t654, ptr %l285
  %t655 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
  store %"compiler/diagmsg:Msg" %t655, ptr %l286
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t656 = load ptr, ptr %l283, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l285
  %t658 = load %"compiler/diagmsg:Msg", ptr %l286
  %t659 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t656, %"compiler/source:Span" %t657, %"compiler/diagmsg:Msg" %t658)
  store i64 %t659, ptr %l287
  br label %bb115
bb115:
  br label %bb116
bb116:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t662 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t660)
  store ptr %t662, ptr %l289
  br label %bb117
bb117:
  %t663 = load ptr, ptr %l289, !tbaa !29
  %t665 = getelementptr %"compiler/check:frame", ptr %t663, i32 0, i32 30
  %t667 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v2, ptr %t665)
  store { i64, ptr } %t667, ptr %l292
  br label %bb118
bb118:
  %t668 = load { i64, ptr }, ptr %l292, !tbaa !27
  store { i64, ptr } %t668, ptr %l27, !tbaa !27
  %t669 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t669)
  br label %bb119
bb119:
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t673 = getelementptr %"compiler/check:Checker", ptr %t671, i32 0, i32 23
  %t674 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t673, i64 %t674, i64 2)
  br label %bb120
bb120:
  %t677 = load ptr, ptr %l1, !tbaa !29
  %t679 = getelementptr %"compiler/ast:Catch", ptr %t677, i32 0, i32 0
  %t680 = load %"compiler/source:Span", ptr %t679
  store %"compiler/source:Span" %t680, ptr %l298
  %t681 = load i32, ptr %l7, !tbaa !23
  store i32 %t681, ptr %l299, !tbaa !23
  %t682 = load i64, ptr %l10, !tbaa !24
  %t684 = trunc i64 %t682 to i32
  store i32 %t684, ptr %l302, !tbaa !23
  %t686 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t686, ptr %l303, !tbaa !27
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load ptr, ptr %l1, !tbaa !29
  %t690 = getelementptr %"compiler/ast:Catch", ptr %t688, i32 0, i32 0
  %t691 = load %"compiler/source:Span", ptr %t690
  %t695 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t687, i32 5, %"compiler/source:Span" %t691)
  store i32 %t695, ptr %l308
  br label %bb121
bb121:
  store { i64, [4 x i64] } zeroinitializer, ptr %t696
  %t697 = getelementptr { i64, [4 x i64] }, ptr %t696, i32 0, i32 0
  store i64 1, ptr %t697
  %t698 = load i32, ptr %l302, !tbaa !23
  %t699 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t698, 0
  %t700 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t701 = insertvalue { i32, { i64, ptr }, i32 } %t699, { i64, ptr } %t700, 1
  %t702 = load i32, ptr %l308, !tbaa !23
  %t703 = insertvalue { i32, { i64, ptr }, i32 } %t701, i32 %t702, 2
  %t704 = getelementptr { i64, [4 x i64] }, ptr %t696, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t703, ptr %t704
  %t705 = load { i64, [4 x i64] }, ptr %t696
  %t707 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t705, ptr %t707
  store { i64, [5 x i64] } zeroinitializer, ptr %t708
  %t709 = getelementptr { i64, [5 x i64] }, ptr %t708, i32 0, i32 0
  store i64 15, ptr %t709
  %t710 = load %"compiler/source:Span", ptr %l298
  %t711 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t710, 0
  %t712 = load i32, ptr %l299, !tbaa !23
  %t713 = insertvalue { %"compiler/source:Span", i32, ptr } %t711, i32 %t712, 1
  %t715 = insertvalue { %"compiler/source:Span", i32, ptr } %t713, ptr %t707, 2
  %t716 = getelementptr { i64, [5 x i64] }, ptr %t708, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t715, ptr %t716
  %t717 = load { i64, [5 x i64] }, ptr %t708
  %t719 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t717, ptr %t719
  call void @__olang_scope_close(ptr %s0)
  store ptr %t719, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnSlice(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 10
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [5 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l2
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  %t34 = getelementptr %"compiler/typed:Slice", ptr %t29, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l5, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l23, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 8}
  %t44 = icmp eq i64 %t42, 3
  store i1 %t44, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l6, !tbaa !29
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l30, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l31, !tbaa !29
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l33
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = load i32, ptr %l33, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t62, ptr %l34
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l30, !tbaa !29
  %t64 = load i32, ptr %l34, !tbaa !23
  %t65 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t65, ptr %l35
  br label %bb13
bb13:
  %t66 = load i1, ptr %l35, !tbaa !21
  store i1 %t66, ptr %l22, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8c10df0be32d8eb1_d395e5eefe4361bd)
  unreachable
bb19:
  %t67 = load i1, ptr %l22, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l83 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i32 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 0, i64 8)
  store ptr %t17, ptr %lp6
  %t19 = load ptr, ptr %lp6
  store [0 x i32] zeroinitializer, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t45, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i32 %t47, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = mul i64 2, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 2, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  store i32 %t53, ptr %t56, !tbaa !33
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 1
  store i32 %t48, ptr %t60, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l36
  br label %bb13
bb13:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l41
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l46
  br label %bb17
bb17:
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l46, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t97 = load i32, ptr %l4, !tbaa !23
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = icmp ne i32 %t97, %t98
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load i32, ptr %l5, !tbaa !23
  %t105 = mul i64 1, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 1, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l54, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 0
  store i32 %t104, ptr %t112, !tbaa !33
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  br label %bb23
bb22:
  %t114 = load ptr, ptr %lp6
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l4, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l61
  br label %bb25
bb25:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l66
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sle i64 %t141, 16
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i32, ptr %l5, !tbaa !23
  %t145 = mul i64 1, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 1, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t144, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  br label %bb31
bb30:
  %t154 = load ptr, ptr %lp6
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i32 %t169, ptr %l77
  br label %bb33
bb33:
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load i32, ptr %l77, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %lp6
  %t177 = insertvalue { i64, ptr } undef, i64 0, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t180 = load i32, ptr %l5, !tbaa !23
  %t181 = mul i64 1, 4
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 1, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i32, ptr %t187, i64 0
  store i32 %t180, ptr %t188, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyShape(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, ptr }
  %l37 = alloca i32
  %l42 = alloca i32
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/diagmsg:Msg"
  %l54 = alloca i64
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/diagmsg:Msg"
  %l67 = alloca i64
  %l70 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %l90 = alloca { i64, ptr }
  %l92 = alloca i1
  %l94 = alloca i1
  %l96 = alloca { i64, ptr }
  %l98 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i1
  %l106 = alloca ptr
  %l111 = alloca i32
  %l116 = alloca i32
  %l117 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l125 = alloca %"compiler/diagmsg:Msg"
  %l126 = alloca i64
  %l130 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l137 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l152 = alloca %"compiler/diagmsg:Msg"
  %l153 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i32, ptr %l11, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l14, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l19
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i32, ptr %l19, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l20
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l4, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp ne i64 %t32, 1
  br i1 %t34, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l28
  br label %bb7
bb7:
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i64, ptr %l28, !tbaa !24
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t46, i64 -1, i64 %t47, i32 %t45, i32 0)
  store ptr %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t54 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  store %"compiler/source:Span" %t54, ptr %l33
  br label %bb9
bb9:
  %t55 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t55, ptr %l5
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 0
  %t61 = load i32, ptr %t60, !tbaa !33
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t56, i32 %t61)
  store i32 %t64, ptr %l37
  br label %bb10
bb10:
  %t65 = load i32, ptr %l37, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l42
  br label %bb11
bb11:
  %t76 = load i32, ptr %l42, !tbaa !23
  store i32 %t76, ptr %l7, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l6, !tbaa !23
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l46
  br label %bb12
bb12:
  %t85 = load i1, ptr %l46, !tbaa !21
  br i1 %t85, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t87, ptr %l48
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l6, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l51
  br label %bb15
bb14:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l6, !tbaa !23
  %t102 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l59
  br label %bb18
bb15:
  %t103 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t111 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImmutCopy(ptr %s2, ptr %v0, { i64, ptr } %t109)
  store %"compiler/diagmsg:Msg" %t111, ptr %l53
  br label %bb16
bb16:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l48
  %t114 = load %"compiler/diagmsg:Msg", ptr %l53
  %t115 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t112, %"compiler/source:Span" %t113, %"compiler/diagmsg:Msg" %t114)
  store i64 %t115, ptr %l54
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb18:
  %t116 = load i1, ptr %l59, !tbaa !21
  br i1 %t116, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l60, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t118, ptr %l61
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l6, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l64
  br label %bb21
bb20:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l6, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l70
  br label %bb24
bb21:
  %t129 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t137 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueCopy(ptr %s4, ptr %v0, { i64, ptr } %t135)
  store %"compiler/diagmsg:Msg" %t137, ptr %l66
  br label %bb22
bb22:
  %t138 = load ptr, ptr %l60, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l61
  %t140 = load %"compiler/diagmsg:Msg", ptr %l66
  %t141 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t138, %"compiler/source:Span" %t139, %"compiler/diagmsg:Msg" %t140)
  store i64 %t141, ptr %l67
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb75
bb24:
  %t142 = load i1, ptr %l70, !tbaa !21
  %t143 = xor i1 %t142, true
  br i1 %t143, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb32
bb26:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l6, !tbaa !23
  %t149 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l75
  br label %bb27
bb27:
  %t150 = load i1, ptr %l75, !tbaa !21
  br i1 %t150, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb31
bb29:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l6, !tbaa !23
  %t155 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l79
  br label %bb30
bb30:
  %t156 = load i1, ptr %l79, !tbaa !21
  store i1 %t156, ptr %l76, !tbaa !21
  br label %bb31
bb31:
  %t157 = load i1, ptr %l76, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t160 = load i1, ptr %l72, !tbaa !21
  br i1 %t160, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l81, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t162, ptr %l82
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l6, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l85
  br label %bb35
bb34:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t169, ptr %l90, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i32, ptr %t171, i64 0
  %t173 = load i32, ptr %t172, !tbaa !33
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t168, i32 %t173)
  store i1 %t176, ptr %l92
  br label %bb38
bb35:
  %t177 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t185 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCopyOnWhat(ptr %s6, ptr %v0, { i64, ptr } %t183)
  store %"compiler/diagmsg:Msg" %t185, ptr %l87
  br label %bb36
bb36:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l82
  %t188 = load %"compiler/diagmsg:Msg", ptr %l87
  %t189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t186, %"compiler/source:Span" %t187, %"compiler/diagmsg:Msg" %t188)
  store i64 %t189, ptr %l88
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb74
bb38:
  %t190 = load i1, ptr %l92, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb42
bb40:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t194, ptr %l96, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 0
  %t198 = load i32, ptr %t197, !tbaa !33
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t193, i32 %t198)
  store i1 %t201, ptr %l98
  br label %bb41
bb41:
  %t202 = load i1, ptr %l98, !tbaa !21
  store i1 %t202, ptr %l94, !tbaa !21
  br label %bb42
bb42:
  %t203 = load i1, ptr %l94, !tbaa !21
  br i1 %t203, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb46
bb44:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i32, ptr %l7, !tbaa !23
  %t208 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t204, i32 %t205)
  store i1 %t208, ptr %l102
  br label %bb45
bb45:
  %t209 = load i1, ptr %l102, !tbaa !21
  store i1 %t209, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t210 = load i1, ptr %l99, !tbaa !21
  br i1 %t210, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb52
bb48:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  store ptr %t216, ptr %l106, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 2
  %t223 = load i32, ptr %l7, !tbaa !23
  %t226 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t222, i32 %t223)
  store i32 %t226, ptr %l111
  br label %bb49
bb49:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  %t233 = load i32, ptr %l6, !tbaa !23
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l116
  br label %bb50
bb50:
  %t237 = load ptr, ptr %l106, !tbaa !29
  %t238 = load i32, ptr %l111, !tbaa !23
  %t239 = load i32, ptr %l116, !tbaa !23
  %t240 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t237, i32 %t238, i32 %t239)
  store i1 %t240, ptr %l117
  br label %bb51
bb51:
  %t241 = load i1, ptr %l117, !tbaa !21
  %t242 = xor i1 %t241, true
  store i1 %t242, ptr %l103, !tbaa !21
  br label %bb52
bb52:
  %t244 = load i1, ptr %l103, !tbaa !21
  br i1 %t244, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l119, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t246, ptr %l120
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l6, !tbaa !23
  %t251 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t247, i32 %t248)
  store { i64, ptr } %t251, ptr %l123
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t254 = getelementptr %"compiler/ast:Func", ptr %t252, i32 0, i32 3
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = getelementptr %"compiler/ast:Sig", ptr %t255, i32 0, i32 4
  %t258 = load i1, ptr %t257, !tbaa !21
  br i1 %t258, label %bb58, label %bb59
bb55:
  %t260 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  %t262 = extractvalue { i64, ptr } %t260, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t268 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCopyShape(ptr %s8, ptr %v0, { i64, ptr } %t266)
  store %"compiler/diagmsg:Msg" %t268, ptr %l125
  br label %bb56
bb56:
  %t269 = load ptr, ptr %l119, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l120
  %t271 = load %"compiler/diagmsg:Msg", ptr %l125
  %t272 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t269, %"compiler/source:Span" %t270, %"compiler/diagmsg:Msg" %t271)
  store i64 %t272, ptr %l126
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb73
bb58:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb61
bb59:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l3, !tbaa !23
  %t277 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t273, i32 %t274)
  store i1 %t277, ptr %l133
  br label %bb60
bb60:
  %t278 = load i1, ptr %l133, !tbaa !21
  store i1 %t278, ptr %l130, !tbaa !21
  br label %bb61
bb61:
  %t279 = load i1, ptr %l130, !tbaa !21
  br i1 %t279, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb66
bb63:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/generic:Program", ptr %t283, i32 0, i32 2
  store ptr %t285, ptr %l137, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = getelementptr %"compiler/generic:Program", ptr %t289, i32 0, i32 2
  %t292 = load i32, ptr %l3, !tbaa !23
  %t295 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t291, i32 %t292)
  store i32 %t295, ptr %l142
  br label %bb64
bb64:
  %t296 = load ptr, ptr %l137, !tbaa !29
  %t297 = load i32, ptr %l142, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s9, ptr %t296, i32 %t297)
  store { i64, ptr } %t298, ptr %l143
  br label %bb65
bb65:
  %t299 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t302 = icmp sgt i64 %t300, 0
  store i1 %t302, ptr %l134, !tbaa !21
  br label %bb66
bb66:
  %t304 = load i1, ptr %l134, !tbaa !21
  br i1 %t304, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l146, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t306, ptr %l147
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l6, !tbaa !23
  %t311 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t307, i32 %t308)
  store { i64, ptr } %t311, ptr %l150
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t312 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t312, 0
  %t314 = extractvalue { i64, ptr } %t312, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  %t320 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCopyShape(ptr %s10, ptr %v0, { i64, ptr } %t318)
  store %"compiler/diagmsg:Msg" %t320, ptr %l152
  br label %bb70
bb70:
  %t321 = load ptr, ptr %l146, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l147
  %t323 = load %"compiler/diagmsg:Msg", ptr %l152
  %t324 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t321, %"compiler/source:Span" %t322, %"compiler/diagmsg:Msg" %t323)
  store i64 %t324, ptr %l153
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s10)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s9)
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t325 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t325)
  br label %bb77
bb77:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l18 = alloca { i64, i64, i64 }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l38 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 45
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb4
bb4:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t12, i32 3, %"compiler/source:Span" %t13)
  store { i64, i64, i64 } %t17, ptr %l18
  br label %bb5
bb5:
  %t18 = load { i64, i64, i64 }, ptr %l18
  store { i64, i64, i64 } %t18, ptr %l5
  %t19 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  %t22 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l7, !tbaa !24
  %t25 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l8, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l23, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l24
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l26, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l27
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l29
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l27
  %t40 = load i32, ptr %l29, !tbaa !23
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t38, %"compiler/source:Span" %t39, i32 %t40, i64 %a3)
  store ptr %t42, ptr %l31
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l24
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t43, %"compiler/source:Span" %t44, i64 %t45, ptr %t46)
  store ptr %t47, ptr %l32
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l22, !tbaa !29
  %t49 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t48, ptr %t49)
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %t50, i64 %t51, i64 %t52, i64 %t53, i64 %t54)
  store ptr %t60, ptr %l38
  br label %bb10
bb10:
  %t61 = load ptr, ptr %l38, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store ptr %t16, ptr %l13
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l13, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TypeDecl", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 3
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb11, label %bb12
bb10:
  br label %bb25
bb11:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 5}
  %t46 = icmp eq i64 %t44, 0
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr { i64, [6 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { ptr }, ptr %t50, i32 0, i32 0
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:StructBody", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l39
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = load i32, ptr %l39, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l40
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l30, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t77)
  store { i64, ptr } %t78, ptr %l41
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7f8223142f689eb4_f934e4a817092f38)
  unreachable
bb24:
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l7, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Sig", ptr %t17, i32 0, i32 4
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb22
bb6:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t24, ptr %l15
  br label %bb7
bb7:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 7
  %t29 = load i1, ptr %t28, !tbaa !21
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb22
bb11:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t33, ptr %l19
  br label %bb12
bb12:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l23
  br label %bb16
bb16:
  %t43 = load i1, ptr %l23, !tbaa !21
  store i1 %t43, ptr %l8, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Sig", ptr %t47, i32 0, i32 5
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l8, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bdeebae2e62e4381_d7e2b33750a898f5)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l8, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropRegistered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/typed:Local"
  %l19 = alloca { i64, ptr }
  %l23 = alloca %"compiler/source:Span"
  %l34 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"compiler/diagmsg:Msg"
  %l44 = alloca ptr
  %l48 = alloca %"compiler/typed:Local"
  %l50 = alloca { i64, ptr }
  %l53 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %t41 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 7
  store ptr %t4, ptr %l12, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:DropHolding", ptr %t5, i32 0, i32 5
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = load i64, ptr %l16, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t12, i64 %t13)
  store %"compiler/typed:Local" %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t17, i32 %t16)
  store { i64, ptr } %t19, ptr %l19
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:DropHolding", ptr %t21, i32 0, i32 4
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v2, ptr %t23, i64 %t24)
  store %"compiler/source:Span" %t27, ptr %l23
  br label %bb4
bb4:
  %t28 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t28, ptr %l5
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t37 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t38 = load i32, ptr %t37, !tbaa !23
  %t40 = sext i32 %t38 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 0
  store i64 3, ptr %t42
  %t44 = insertvalue { i64, i64, i64 } undef, i64 %t32, 0
  %t46 = insertvalue { i64, i64, i64 } %t44, i64 %t36, 1
  %t48 = insertvalue { i64, i64, i64 } %t46, i64 %t40, 2
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 1
  store { i64, i64, i64 } %t48, ptr %t49
  %t50 = load { i64, [3 x i64] }, ptr %t41
  store { i64, [3 x i64] } %t50, ptr %l6
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/typed:DropHolding", ptr %t52, i32 0, i32 3
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l34
  br label %bb5
bb5:
  %t59 = load i64, ptr %l34, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l35, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:DropHolding", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l39
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t68, i32 %t69)
  store { i64, ptr } %t70, ptr %l40
  br label %bb7
bb7:
  %t71 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t71, ptr %l8, !tbaa !27
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  br i1 %t74, label %bb8, label %bb9
bb8:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l44, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 7
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t79, i64 %t80)
  store %"compiler/typed:Local" %t83, ptr %l48
  br label %bb10
bb9:
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t88 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDropTempRegistered(ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t84, { i64, ptr } %t85)
  store %"compiler/diagmsg:Msg" %t88, ptr %l56
  br label %bb13
bb10:
  %t89 = getelementptr %"compiler/typed:Local", ptr %l48, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t91, i32 %t90)
  store { i64, ptr } %t93, ptr %l50
  br label %bb11
bb11:
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t99 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDropRegistered(ptr %v0, ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t96, { i64, ptr } %t94, { i64, ptr } %t95)
  store %"compiler/diagmsg:Msg" %t99, ptr %l53
  br label %bb12
bb12:
  %t100 = load %"compiler/diagmsg:Msg", ptr %l53
  store %"compiler/diagmsg:Msg" %t100, ptr %l43
  br label %bb14
bb13:
  %t101 = load %"compiler/diagmsg:Msg", ptr %l56
  store %"compiler/diagmsg:Msg" %t101, ptr %l43
  br label %bb14
bb14:
  %t102 = load %"compiler/diagmsg:Msg", ptr %l43
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load { i64, [3 x i64] }, ptr %l6
  %t118 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t112, { i64, [3 x i64] } %t113, %"compiler/diagmsg:Msg" %t102)
  store i64 %t118, ptr %l63
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l15 = alloca i64
  %l16 = alloca { { i64, ptr }, { i64, ptr } }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i1
  %l45 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"std/prelude/text:StringBuilder"
  %l62 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l81 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/diagmsg:Msg"
  %l105 = alloca i64
  %l107 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i64
  %l116 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca %"compiler/diagmsg:Msg"
  %l120 = alloca i64
  %l123 = alloca ptr
  %l128 = alloca %"compiler/check:EmbedAsk"
  %l136 = alloca { { i64, ptr }, { i64, ptr } }
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l142 = alloca i1
  %l144 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l151 = alloca %"compiler/diagmsg:Msg"
  %l152 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t36 = alloca { i64, [2 x i64] }, align 8
  %t44 = alloca { i64, [5 x i64] }, align 8
  %t343 = alloca { i64, [2 x i64] }, align 8
  %t351 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  store ptr %t10, ptr %l23, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t16, i32 7, i32 0)
  store i32 %t18, ptr %l27
  br label %bb2
bb2:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t20 = load ptr, ptr %l23, !tbaa !29
  %t21 = load i32, ptr %l27, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t20, i32 %t21, i64 %t19)
  store i32 %t23, ptr %l29
  br label %bb3
bb3:
  %t24 = load i32, ptr %l29, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l30
  %t26 = load i32, ptr %l4, !tbaa !23
  store i32 %t26, ptr %l31, !tbaa !23
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 2
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l33, !tbaa !24
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = mul i64 0, 1
  %t34 = insertvalue { i64, ptr } undef, i64 0, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t39 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t35, 0
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 1
  store { { i64, ptr } } %t39, ptr %t40
  %t41 = load { i64, [2 x i64] }, ptr %t36
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t41, ptr %t43
  store { i64, [5 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 0
  store i64 1, ptr %t45
  %t46 = load %"compiler/source:Span", ptr %l30
  %t47 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t46, 0
  %t48 = load i32, ptr %l31, !tbaa !23
  %t49 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t47, i32 %t48, 1
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t49, i64 %t50, 2
  %t53 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t51, ptr %t43, 3
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t53, ptr %t54
  %t55 = load { i64, [5 x i64] }, ptr %t44
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t56, ptr %lp5
  %t58 = load ptr, ptr %lp5
  store { i64, [5 x i64] } %t55, ptr %t58
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t59, ptr %l6, !tbaa !27
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t62 = load ptr, ptr %l41, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2d16f3aa36d067c5_95008946090581a1)
  unreachable
bb6:
  %t65 = load ptr, ptr %l41, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 28}
  %t68 = icmp eq i64 %t66, 1
  store i1 %t68, ptr %l42, !tbaa !21
  br label %bb7
bb7:
  %t69 = load i1, ptr %l42, !tbaa !21
  br i1 %t69, label %bb8, label %bb9
bb8:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32 }, ptr %t72, i32 0, i32 1
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 113}
  %t76 = trunc i64 5 to i32
  %t77 = icmp eq i32 %t74, %t76
  store i1 %t77, ptr %l45, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb10
bb10:
  %t79 = load i1, ptr %l45, !tbaa !21
  br i1 %t79, label %bb11, label %bb12
bb11:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32 }, ptr %t82, i32 0, i32 0
  %t84 = load %"compiler/source:Span", ptr %t83
  store %"compiler/source:Span" %t84, ptr %l7
  br label %bb13
bb12:
  br label %bb30
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l7
  %t90 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %s1, ptr %t86, %"compiler/source:Span" %t87)
  store { i64, ptr } %t90, ptr %l53
  br label %bb14
bb14:
  %t91 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  %t92 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s1)
  store %"std/prelude/text:StringBuilder" %t92, ptr %l54
  br label %bb15
bb15:
  %t93 = load %"std/prelude/text:StringBuilder", ptr %l54
  store %"std/prelude/text:StringBuilder" %t93, ptr %l9
  %t94 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t94, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l12, !tbaa !24
  br label %bb16
bb16:
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t108 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t108, ptr %l62, !tbaa !27
  %t109 = load i64, ptr %l11, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s1, ptr %l9, i8 %t114)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l11, !tbaa !24
  br label %bb16
bb22:
  %t124 = ptrtoint ptr %s0 to i64
  store i64 %t124, ptr %l70, !tbaa !24
  %t125 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eembed_2elocal_2e6
  br i1 %t125, label %bb23, label %bb24
bb23:
  %t127 = call ptr @__olang_region_make(ptr %s0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l70, !tbaa !24
  br label %bb24
bb24:
  %t129 = load i64, ptr %l70
  %t130 = inttoptr i64 %t129 to ptr
  %t132 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s1, ptr %t130, ptr %l9)
  store { i64, ptr } %t132, ptr %l73
  br label %bb25
bb25:
  %t133 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eembed_2elocal_2e6
  br i1 %t133, label %bb26, label %bb27
bb26:
  %t135 = load i64, ptr %l70
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = load { i64, ptr }, ptr %l73
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = call ptr @__olang_region_or(ptr %t138, ptr null)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr null
  %t142 = icmp eq ptr %t141, %t136
  call void @__olang_region_settle(ptr %t136, i1 %t142)
  br label %bb27
bb27:
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t143, ptr %l75, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t144, ptr %l6, !tbaa !27
  %t145 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eembed_2elocal_2e6
  br i1 %t145, label %bb28, label %bb29
bb28:
  %t147 = load { i64, ptr }, ptr %l75
  %t148 = extractvalue { i64, ptr } %t147, 1
  call void @__olang_region_release(ptr %t148)
  store { i64, ptr } zeroinitializer, ptr %l75
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s1)
  br label %bb63
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb62
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 2
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  %t159 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t152, i64 %t156)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t159, ptr %l81
  br label %bb34
bb34:
  %t160 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l81
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t160, ptr %l14
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 56
  %t167 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  %t170 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v0, ptr %t166, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167)
  store i1 %t170, ptr %l86
  br label %bb35
bb35:
  %t171 = load i1, ptr %l86, !tbaa !21
  br i1 %t171, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 56
  %t178 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  %t181 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H031c7c147cc8ce0b988dd3fed8d142ad(ptr %v0, ptr %s6, ptr %t177, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t178)
  %t182 = extractvalue { i32, { i64, ptr } } %t181, 1
  %t183 = extractvalue { i32, { i64, ptr } } %t181, 0
  store i32 %t183, ptr %l93
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb39, label %ok.185, !prof !99
ok.185:
  store { i64, ptr } %t182, ptr %l92
  br label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l107, !tbaa !29
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr %"compiler/check:frame", ptr %t187, i32 0, i32 1
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l109, !tbaa !24
  %t191 = load ptr, ptr %l2, !tbaa !29
  store ptr %t191, ptr %l110, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t192)
  store i32 %t194, ptr %l112
  br label %bb51
bb38:
  %t195 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t195, ptr %l87, !tbaa !27
  br label %bb41
bb39:
  br label %bb40
bb40:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb41
bb41:
  %t196 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t196, ptr %l94, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t197, ptr %l95, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l96, !tbaa !24
  %t200 = load i64, ptr %l96, !tbaa !24
  %t201 = mul i64 %t200, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t201)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l97, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l96, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  %t211 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t211, ptr %l6, !tbaa !27
  %t212 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eembed_2elocal_2e6
  br i1 %t212, label %bb42, label %bb43
bb42:
  %t214 = load { i64, ptr }, ptr %l95
  %t215 = extractvalue { i64, ptr } %t214, 1
  call void @__olang_region_release(ptr %t215)
  store { i64, ptr } zeroinitializer, ptr %l95
  br label %bb43
bb43:
  %t216 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s6, { i64, ptr } %t216, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t218, ptr %l100
  br label %bb44
bb44:
  %t219 = load i1, ptr %l100, !tbaa !21
  br i1 %t219, label %bb45, label %bb46
bb45:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l101, !tbaa !29
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t221)
  store %"compiler/source:Span" %t223, ptr %l103
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t224 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEmbedPathUndecided(ptr %v0)
  store %"compiler/diagmsg:Msg" %t224, ptr %l104
  br label %bb48
bb48:
  %t225 = load ptr, ptr %l101, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l103
  %t227 = load %"compiler/diagmsg:Msg", ptr %l104
  %t228 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, %"compiler/diagmsg:Msg" %t227)
  store i64 %t228, ptr %l105
  br label %bb49
bb49:
  %t229 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t229, ptr %rv
  br label %ret
bb50:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb51:
  %t231 = load ptr, ptr %l107, !tbaa !29
  %t232 = load i64, ptr %l109, !tbaa !24
  %t233 = load ptr, ptr %l110, !tbaa !29
  %t234 = load i32, ptr %l112, !tbaa !23
  %t235 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %t231, i64 %t232, ptr %t233, i32 %t234)
  store i64 %t235, ptr %l113
  br label %bb52
bb52:
  %t236 = load i64, ptr %l113, !tbaa !24
  store i64 %t236, ptr %l15, !tbaa !24
  %t237 = load i64, ptr %l15, !tbaa !24
  %t239 = icmp slt i64 %t237, 0
  br i1 %t239, label %bb53, label %bb54
bb53:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l116, !tbaa !29
  %t242 = load ptr, ptr %l2, !tbaa !29
  %t244 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t242)
  store %"compiler/source:Span" %t244, ptr %l118
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t245 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEmbedPathUnknown(ptr %v0)
  store %"compiler/diagmsg:Msg" %t245, ptr %l119
  br label %bb56
bb56:
  %t246 = load ptr, ptr %l116, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l118
  %t248 = load %"compiler/diagmsg:Msg", ptr %l119
  %t249 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t246, %"compiler/source:Span" %t247, %"compiler/diagmsg:Msg" %t248)
  store i64 %t249, ptr %l120
  br label %bb57
bb57:
  %t250 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t250, ptr %rv
  br label %ret
bb58:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 118
  store ptr %t254, ptr %l123, !tbaa !29
  %t255 = load i64, ptr %l15, !tbaa !24
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t258 = getelementptr %"compiler/check:frame", ptr %t256, i32 0, i32 2
  %t259 = load i64, ptr %t258, !tbaa !24
  %t260 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t261 = load i32, ptr %t260, !tbaa !23
  %t265 = call %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %s8, i64 %t255, i64 %t259, i32 %t261)
  store %"compiler/check:EmbedAsk" %t265, ptr %l128
  br label %bb59
bb59:
  %t266 = load ptr, ptr %l123, !tbaa !29
  %t267 = load %"compiler/check:EmbedAsk", ptr %l128
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2ePush_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %t266, %"compiler/check:EmbedAsk" %t267)
  br label %bb60
bb60:
  %t268 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t268, ptr %rv
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_1d0e70c978300aa7_2a4aae738133c57b)
  unreachable
bb63:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 0
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t277 = load ptr, ptr %l3, !tbaa !29
  %t279 = getelementptr %"compiler/check:frame", ptr %t277, i32 0, i32 1
  %t280 = load i64, ptr %t279, !tbaa !24
  %t281 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t285 = call { { i64, ptr }, { i64, ptr } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbed(ptr %v0, ptr %s0, ptr %v0, ptr %t276, i64 %t280, { i64, ptr } %t281)
  store { { i64, ptr }, { i64, ptr } } %t285, ptr %l136
  br label %bb64
bb64:
  %t286 = load { { i64, ptr }, { i64, ptr } }, ptr %l136
  store { { i64, ptr }, { i64, ptr } } %t286, ptr %l16
  %t287 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l17, !tbaa !27
  %t290 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  store { i64, ptr } %t291, ptr %l138, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l139, !tbaa !24
  %t294 = load i64, ptr %l139, !tbaa !24
  %t295 = mul i64 %t294, 1
  %t296 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l140, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l139, !tbaa !24
  %t304 = mul i64 %t303, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t300, ptr %t302, i64 %t304, i1 false)
  %t305 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t305, ptr %l18, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t308 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t306, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t308, ptr %l142
  br label %bb65
bb65:
  %t309 = load i1, ptr %l142, !tbaa !21
  %t310 = xor i1 %t309, true
  br i1 %t310, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s10
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l144, !tbaa !29
  %t313 = load ptr, ptr %l2, !tbaa !29
  %t315 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t313)
  store %"compiler/source:Span" %t315, ptr %l146
  br label %bb68
bb67:
  br label %bb72
bb68:
  %t316 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t318 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s10, { i64, ptr } %t316)
  store { i64, ptr } %t318, ptr %l148
  br label %bb69
bb69:
  %t319 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  %t321 = extractvalue { i64, ptr } %t319, 1
  %t322 = mul i64 %t320, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t323, ptr %t321, i64 %t322, i1 false)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  %t326 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t329 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEmbedNotRead(ptr %s10, ptr %s0, ptr %v0, { i64, ptr } %t325, { i64, ptr } %t326)
  store %"compiler/diagmsg:Msg" %t329, ptr %l151
  br label %bb70
bb70:
  %t330 = load ptr, ptr %l144, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l146
  %t332 = load %"compiler/diagmsg:Msg", ptr %l151
  %t333 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t330, %"compiler/source:Span" %t331, %"compiler/diagmsg:Msg" %t332)
  store i64 %t333, ptr %l152
  br label %bb71
bb71:
  %t334 = load ptr, ptr %lp5
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t334, ptr %rv
  br label %ret
bb72:
  %t336 = load %"compiler/source:Span", ptr %l1
  %t337 = load i32, ptr %l4, !tbaa !23
  %t338 = load ptr, ptr %l3, !tbaa !29
  %t340 = getelementptr %"compiler/check:frame", ptr %t338, i32 0, i32 2
  %t341 = load i64, ptr %t340, !tbaa !24
  %t342 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t343
  %t344 = getelementptr { i64, [2 x i64] }, ptr %t343, i32 0, i32 0
  store i64 1, ptr %t344
  %t346 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t342, 0
  %t347 = getelementptr { i64, [2 x i64] }, ptr %t343, i32 0, i32 1
  store { { i64, ptr } } %t346, ptr %t347
  %t348 = load { i64, [2 x i64] }, ptr %t343
  %t350 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t348, ptr %t350
  store { i64, [5 x i64] } zeroinitializer, ptr %t351
  %t352 = getelementptr { i64, [5 x i64] }, ptr %t351, i32 0, i32 0
  store i64 1, ptr %t352
  %t354 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t336, 0
  %t356 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t354, i32 %t337, 1
  %t358 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t356, i64 %t341, 2
  %t360 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t358, ptr %t350, 3
  %t361 = getelementptr { i64, [5 x i64] }, ptr %t351, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t360, ptr %t361
  %t362 = load { i64, [5 x i64] }, ptr %t351
  %t364 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t362, ptr %t364
  call void @__olang_scope_close(ptr %s0)
  store ptr %t364, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 45
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrSubjectOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 65
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 64
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l13
  %t21 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l10, ptr %l13)
  store i1 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load i1, ptr %l15, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l18
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t28, i32 0, i32 65
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l18
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t32, %"compiler/source:Span" %t33, i64 %t31)
  store ptr %t35, ptr %l21
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l21, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t38, i32 %t40)
  store ptr %t44, ptr %l26
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l26, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"compiler/names:Ref"
  %l31 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca %"compiler/names:Ref"
  %l46 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l64 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l100 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l11, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  br label %bb8
bb7:
  br label %bb34
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t34)
  store ptr %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t46 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t43, i64 %t40, i32 %t42)
  store %"compiler/names:Ref" %t46, ptr %l27
  br label %bb10
bb10:
  %t47 = load %"compiler/names:Ref", ptr %l27
  store %"compiler/names:Ref" %t47, ptr %l4
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp sgt i64 %t50, 1
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t55 = load i32, ptr %t54, !range !{i32 0, i32 9}
  %t57 = trunc i64 0 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t68)
  store ptr %t70, ptr %l38
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 2
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load ptr, ptr %l36, !tbaa !29
  %t80 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t77, i64 %t74, i32 %t76)
  store %"compiler/names:Ref" %t80, ptr %l42
  br label %bb17
bb17:
  %t81 = load %"compiler/names:Ref", ptr %l42
  store %"compiler/names:Ref" %t81, ptr %l4
  br label %bb18
bb18:
  %t82 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t83 = load i32, ptr %t82, !range !{i32 0, i32 9}
  %t85 = trunc i64 4 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb21
bb20:
  %t90 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l52, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t110 = load i64, ptr %t109, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t106, i64 %t108, i64 %t110)
  store i32 %t114, ptr %l57
  br label %bb25
bb25:
  %t115 = load ptr, ptr %l52, !tbaa !29
  %t116 = load i32, ptr %l57, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l58
  br label %bb26
bb26:
  %t118 = load i32, ptr %l58, !range !{i32 0, i32 6}
  %t120 = trunc i64 2 to i32
  %t121 = icmp eq i32 %t118, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %l64, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = sub i64 %t130, 1
  %t134 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i32, ptr %t135, i64 %t132
  %t137 = load i32, ptr %t136, !tbaa !33
  %t140 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t126, i32 %t137)
  store { i64, ptr } %t140, ptr %l69
  br label %bb30
bb30:
  %t141 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t141, ptr %l5, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l70, !tbaa !29
  %t143 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t149 = trunc i64 %t147 to i32
  %t152 = sub i32 %t144, %t149
  %t153 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  %t157 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t152, i32 %t154)
  store %"compiler/source:Span" %t157, ptr %l77
  br label %bb31
bb31:
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t160 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorAsResult(ptr %v0, ptr %v0, { i64, ptr } %t158)
  store %"compiler/diagmsg:Msg" %t160, ptr %l79
  br label %bb32
bb32:
  %t161 = load ptr, ptr %l70, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l77
  %t163 = load %"compiler/diagmsg:Msg", ptr %l79
  %t164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t161, %"compiler/source:Span" %t162, %"compiler/diagmsg:Msg" %t163)
  store i64 %t164, ptr %l80
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  %t166 = load ptr, ptr %l1, !tbaa !29
  store ptr %t166, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t167 = load ptr, ptr %l82, !tbaa !29
  %t168 = icmp ne ptr %t167, null
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t171 = load i64, ptr %t170, !range !{i64 0, i64 8}
  %t173 = icmp eq i64 %t171, 3
  store i1 %t173, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t174 = load i1, ptr %l83, !tbaa !21
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t177, i32 0, i32 1
  %t179 = load ptr, ptr %t178
  store ptr %t179, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l6, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorResult(ptr %v0, ptr %v1, ptr %t181, ptr %t182)
  store i1 %t186, ptr %l91
  br label %bb40
bb40:
  %t187 = load i1, ptr %l91, !tbaa !21
  store i1 %t187, ptr %rv
  br label %ret
bb41:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t189 = load ptr, ptr %l92, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb42, label %bb43
bb42:
  %t192 = load ptr, ptr %l92, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 8}
  %t195 = icmp eq i64 %t193, 4
  store i1 %t195, ptr %l93, !tbaa !21
  br label %bb43
bb43:
  %t196 = load i1, ptr %l93, !tbaa !21
  br i1 %t196, label %bb44, label %bb45
bb44:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t199, i32 0, i32 1
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t207 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorResult(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  store i1 %t207, ptr %l100
  br label %bb47
bb47:
  %t208 = load i1, ptr %l100, !tbaa !21
  store i1 %t208, ptr %rv
  br label %ret
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  call void @__olang_check_failed(ptr @olang_loc_8058995779d73e9c_6a6c2092014b34b0)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"compiler/check:factsMark"
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca %"compiler/check:factsMark"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t67 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %t1)
  store %"compiler/check:factsMark" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"compiler/check:factsMark", ptr %l10
  store %"compiler/check:factsMark" %t4, ptr %l5
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 45
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i64, ptr %l13, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  store ptr %a1, ptr %l15, !tbaa !29
  store i1 %a2, ptr %l16, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l18
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 7
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load i1, ptr %l16, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i1 %t23, i64 %t20)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 45
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l23
  br label %bb5
bb5:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l23, !tbaa !24
  %t33 = icmp sgt i64 %t31, %t30
  store i1 %t33, ptr %l7, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t35, ptr %t36, i32 %a4)
  store ptr %t42, ptr %l30
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l30, !tbaa !29
  store ptr %t43, ptr %l8, !tbaa !29
  %t44 = load i1, ptr %l7, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l33
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t49 = load ptr, ptr %l8, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t49)
  store i32 %t52, ptr %l36
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 45
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store { i64, ptr } %t59, ptr %l40
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t62, ptr %t60, i1 false)
  store %"compiler/typed:Seq" %t64, ptr %l43
  br label %bb12
bb12:
  %t65 = load %"compiler/typed:Seq", ptr %l43
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t65, ptr %t66
  store { i64, [5 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 0
  store i64 12, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l33
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t69, 0
  %t71 = load i32, ptr %l36, !tbaa !23
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr } %t70, i32 %t71, 1
  %t74 = insertvalue { %"compiler/source:Span", i32, ptr } %t72, ptr %t66, 2
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t74, ptr %t75
  %t76 = load { i64, [5 x i64] }, ptr %t67
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t76, ptr %t78
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb13
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/check:factsMark", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %t80, %"compiler/check:factsMark" %t81)
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l8, !tbaa !29
  store ptr %t84, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/check:factsMark"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:factsMark"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 50
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 46
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l9
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 62
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = call %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %s0, i64 %t20, i64 %t21, i64 %t22)
  store %"compiler/check:factsMark" %t23, ptr %l13
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load %"compiler/check:factsMark", ptr %l13
  store %"compiler/check:factsMark" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsMark", ptr %rv
  ret %"compiler/check:factsMark" %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldDeclAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l17 = alloca i32
  %l20 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i32
  %l35 = alloca i1
  %l44 = alloca { i64, ptr }
  %l55 = alloca { i64, [3 x i64] }
  %s2 = alloca %olang.scope
  %wh2 = alloca ptr
  %wc2 = alloca ptr
  %ws2 = alloca i32
  %rv = alloca { i64, [3 x i64] }
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t104 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store ptr %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l20, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb3, label %bb4
bb3:
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t22
  store { i64, [3 x i64] } %t24, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb6
bb6:
  %t34 = load i64, ptr %l27, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %s2, ptr %t35)
  %t38 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t37, 0, 1
  %t39 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t37, 0, 0
  store ptr %t38, ptr %wh2
  store ptr %t39, ptr %wc2
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t37, ptr %l29
  br label %bb7
bb7:
  %t40 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l29
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t40, ptr %l7
  br label %bb8
bb8:
  %t42 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s2, ptr %l7)
  %t43 = extractvalue { i32, ptr } %t42, 1
  %t44 = extractvalue { i32, ptr } %t42, 0
  store i32 %t44, ptr %l33
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46, !prof !99
ok.46:
  store ptr %t43, ptr %l32
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l32, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  br label %bb12
bb10:
  %t48 = load i32, ptr %l33, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb11
bb11:
  br label %bb24
bb12:
  %t52 = load ptr, ptr %l30, !tbaa !29
  store ptr %t52, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t55 = getelementptr %"compiler/ast:VarDecl", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l11, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t70, ptr %l44, !tbaa !27
  %t71 = load i64, ptr %l10, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i32, ptr %t74, i64 %t71
  %t76 = load i32, ptr %t75, !tbaa !33
  store i32 %t76, ptr %l12, !tbaa !23
  %t78 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp eq i64 %t78, %a2
  br i1 %t82, label %bb17, label %bb18
bb17:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t88 = load i32, ptr %l12, !tbaa !23
  %t94 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeWritten(ptr %v0, ptr %v0, ptr %v0, ptr %t84, i64 %t85, ptr %t86, ptr %t87, i32 %t88)
  store { i64, [3 x i64] } %t94, ptr %l55
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 0, ptr %ws2
  br label %wend2
wend2.c0:
  call void @__olang_scope_close(ptr %s2)
  %t95 = load { i64, [3 x i64] }, ptr %l55
  store { i64, [3 x i64] } %t95, ptr %rv
  br label %ret
bb20:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l10, !tbaa !24
  br label %bb13
bb22:
  br label %bb23
bb23:
  br label %bb8
bb24:
  store i32 1, ptr %ws2
  br label %wend2
wend2.c1:
  call void @__olang_scope_close(ptr %s2)
  store { i64, [3 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t106 = load { i64, [3 x i64] }, ptr %t104
  store { i64, [3 x i64] } %t106, ptr %rv
  br label %ret
wend2:
  %t108 = load ptr, ptr %wh2
  %t109 = load ptr, ptr %wc2
  %t110 = call ptr @llvm.coro.promise(ptr %t108, i32 8, i1 false)
  %t111 = getelementptr { { i32, ptr }, i32 }, ptr %t110, i32 0, i32 1
  store i32 2, ptr %t111
  %t112 = call { i32, ptr } %t109(ptr %t108, ptr null)
  %t113 = load i32, ptr %ws2
  switch i32 %t113, label %wend2.c0 [ i32 1, label %wend2.c1 ]
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i64
  %l31 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l74 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca i32
  %l86 = alloca i32
  %l90 = alloca { i64, ptr }
  %l94 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca i1
  %l115 = alloca i1
  %l118 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca %"compiler/names:Ref"
  %l133 = alloca { i64, ptr }
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i64
  %l147 = alloca i1
  %l149 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca { i64, ptr }
  %l164 = alloca %"compiler/diagmsg:Msg"
  %l165 = alloca i64
  %l174 = alloca { i64, ptr }
  %l180 = alloca i1
  %l182 = alloca ptr
  %l184 = alloca %"compiler/source:Span"
  %l185 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca { i64, ptr }
  %l189 = alloca %"compiler/diagmsg:Msg"
  %l190 = alloca i64
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l23
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l23, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l27
  br label %bb2
bb2:
  %t18 = load i64, ptr %l27, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t19, i64 -1, i64 %t20, i32 %t21, i32 0)
  store ptr %t25, ptr %l31
  br label %bb3
bb3:
  store i1 false, ptr %l4, !tbaa !21
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 5
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb5, label %bb6
bb5:
  br label %bb21
bb6:
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l40, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  store ptr %t49, ptr %l8, !tbaa !29
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TypeParam", ptr %t51, i32 0, i32 4
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t56 = load ptr, ptr %l8, !tbaa !29
  %t58 = getelementptr %"compiler/ast:TypeParam", ptr %t56, i32 0, i32 5
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb19
bb12:
  %t65 = load i1, ptr %l4, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s6
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l50, !tbaa !29
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr %"compiler/ast:TypeParam", ptr %t68, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l52
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l8, !tbaa !29
  %t75 = getelementptr %"compiler/ast:TypeParam", ptr %t73, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t72, i32 %t76)
  store { i64, ptr } %t79, ptr %l56
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t80 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeDefaultNotTrailing(ptr %s6, ptr %v0, { i64, ptr } %t86)
  store %"compiler/diagmsg:Msg" %t88, ptr %l58
  br label %bb16
bb16:
  %t89 = load ptr, ptr %l50, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l52
  %t91 = load %"compiler/diagmsg:Msg", ptr %l58
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t89, %"compiler/source:Span" %t90, %"compiler/diagmsg:Msg" %t91)
  store i64 %t92, ptr %l59
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb4
bb21:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 5
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Func", ptr %t106, i32 0, i32 5
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l11, !tbaa !24
  br label %bb24
bb23:
  br label %bb94
bb24:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb25, label %bb26
bb25:
  br label %bb93
bb26:
  br label %bb27
bb27:
  %t123 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t123, ptr %l74, !tbaa !27
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l12, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l3, !tbaa !24
  %t133 = load ptr, ptr %l12, !tbaa !29
  %t135 = getelementptr %"compiler/ast:TypeParam", ptr %t133, i32 0, i32 1
  %t136 = load i32, ptr %t135, !tbaa !23
  %t140 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %t131, i64 %t132, i32 %t136)
  store i1 %t140, ptr %l81
  br label %bb28
bb28:
  %t141 = load i1, ptr %l81, !tbaa !21
  br i1 %t141, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s11
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l82, !tbaa !29
  %t143 = load ptr, ptr %l12, !tbaa !29
  %t145 = getelementptr %"compiler/ast:TypeParam", ptr %t143, i32 0, i32 0
  %t146 = getelementptr %"compiler/source:Span", ptr %t145, i32 0, i32 0
  %t147 = load i32, ptr %t146, !tbaa !23
  store i32 %t147, ptr %l84, !tbaa !23
  %t148 = load ptr, ptr %l12, !tbaa !29
  %t150 = getelementptr %"compiler/ast:TypeParam", ptr %t148, i32 0, i32 0
  %t151 = getelementptr %"compiler/source:Span", ptr %t150, i32 0, i32 0
  %t152 = load i32, ptr %t151, !tbaa !23
  store i32 %t152, ptr %l86, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l12, !tbaa !29
  %t156 = getelementptr %"compiler/ast:TypeParam", ptr %t154, i32 0, i32 1
  %t157 = load i32, ptr %t156, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s11, ptr %t153, i32 %t157)
  store { i64, ptr } %t160, ptr %l90
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t161 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t164 = trunc i64 %t162 to i32
  %t165 = load i32, ptr %l86, !tbaa !23
  %t167 = add i32 %t165, %t164
  %t168 = load i32, ptr %l84, !tbaa !23
  %t170 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t168, i32 %t167)
  store %"compiler/source:Span" %t170, ptr %l94
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l12, !tbaa !29
  %t174 = getelementptr %"compiler/ast:TypeParam", ptr %t172, i32 0, i32 1
  %t175 = load i32, ptr %t174, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t171, i32 %t175)
  store { i64, ptr } %t178, ptr %l98
  br label %bb33
bb33:
  %t179 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  %t181 = extractvalue { i64, ptr } %t179, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t187 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %s11, ptr %v0, { i64, ptr } %t185)
  store %"compiler/diagmsg:Msg" %t187, ptr %l100
  br label %bb34
bb34:
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l94
  %t190 = load %"compiler/diagmsg:Msg", ptr %l100
  %t191 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t188, %"compiler/source:Span" %t189, %"compiler/diagmsg:Msg" %t190)
  store i64 %t191, ptr %l101
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s11)
  br label %bb36
bb36:
  %t192 = load ptr, ptr %l12, !tbaa !29
  %t194 = getelementptr %"compiler/ast:TypeParam", ptr %t192, i32 0, i32 2
  %t195 = load ptr, ptr %t194, !tbaa !29
  store ptr %t195, ptr %l13, !tbaa !29
  %t197 = load ptr, ptr %l13, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t198 = load ptr, ptr %l104, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb37, label %bb38
bb37:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 8}
  %t204 = icmp eq i64 %t202, 0
  store i1 %t204, ptr %l105, !tbaa !21
  br label %bb38
bb38:
  %t205 = load i1, ptr %l105, !tbaa !21
  br i1 %t205, label %bb39, label %bb40
bb39:
  %t206 = load ptr, ptr %l13, !tbaa !29
  %t208 = getelementptr { i64, [5 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t208, i32 0, i32 0
  %t210 = load %"compiler/source:Span", ptr %t209
  store %"compiler/source:Span" %t210, ptr %l14
  %t212 = load ptr, ptr %l13, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t214, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l15, !tbaa !27
  br label %bb41
bb40:
  br label %bb50
bb41:
  %t218 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t222 = icmp eq i64 %t220, 1
  br i1 %t222, label %bb42, label %bb43
bb42:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  store ptr %t230, ptr %l118, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 0
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/load:Loader", ptr %t237, i32 0, i32 10
  %t240 = load i64, ptr %l3, !tbaa !24
  %t243 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t239, i64 %t240)
  store ptr %t243, ptr %l124
  br label %bb44
bb43:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb46
bb44:
  %t244 = load ptr, ptr %l124, !tbaa !29
  %t246 = getelementptr %"compiler/load:Module", ptr %t244, i32 0, i32 4
  %t247 = load i64, ptr %t246, !tbaa !24
  %t248 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t249 = load i32, ptr %t248, !tbaa !23
  %t250 = load ptr, ptr %l118, !tbaa !29
  %t253 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t250, i64 %t247, i32 %t249)
  store %"compiler/names:Ref" %t253, ptr %l128
  br label %bb45
bb45:
  %t254 = getelementptr %"compiler/names:Ref", ptr %l128, i32 0, i32 0
  %t255 = load i32, ptr %t254, !range !{i32 0, i32 9}
  %t257 = trunc i64 0 to i32
  %t258 = icmp eq i32 %t255, %t257
  store i1 %t258, ptr %l115, !tbaa !21
  br label %bb46
bb46:
  %t260 = load i1, ptr %l115, !tbaa !21
  br i1 %t260, label %bb47, label %bb48
bb47:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l14
  %t263 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t263, ptr %l133, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i32, ptr %t265, i64 0
  %t267 = load i32, ptr %t266, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t261, %"compiler/source:Span" %t262, i32 %t267, i1 true)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb92
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_e4171899205744bd_2a3775717c01c5d1)
  unreachable
bb55:
  %t271 = load ptr, ptr %l12, !tbaa !29
  %t273 = getelementptr %"compiler/ast:TypeParam", ptr %t271, i32 0, i32 2
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = icmp eq ptr %t274, null
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb56, label %bb57
bb56:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l140, !tbaa !29
  %t281 = load i64, ptr %l3, !tbaa !24
  store i64 %t281, ptr %l141, !tbaa !24
  %t282 = load ptr, ptr %l12, !tbaa !29
  %t284 = getelementptr %"compiler/ast:TypeParam", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb58, label %bb59
bb57:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb62
bb58:
  call void @__olang_check_failed(ptr @olang_loc_f9f7abe6f4095c55_11136f6e879bf089)
  unreachable
bb59:
  br label %bb60
bb60:
  %t289 = load ptr, ptr %l12, !tbaa !29
  %t291 = getelementptr %"compiler/ast:TypeParam", ptr %t289, i32 0, i32 2
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t293 = load ptr, ptr %l140, !tbaa !29
  %t294 = load i64, ptr %l141, !tbaa !24
  %t296 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v0, ptr %t293, i64 %t294, ptr %t292)
  store i1 %t296, ptr %l147
  br label %bb61
bb61:
  %t297 = load i1, ptr %l147, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l139, !tbaa !21
  br label %bb62
bb62:
  %t300 = load i1, ptr %l139, !tbaa !21
  br i1 %t300, label %bb63, label %bb64
bb63:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l149, !tbaa !29
  %t302 = load ptr, ptr %l12, !tbaa !29
  %t304 = getelementptr %"compiler/ast:TypeParam", ptr %t302, i32 0, i32 2
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = icmp eq ptr %t305, null
  br i1 %t307, label %bb65, label %bb66
bb64:
  br label %bb76
bb65:
  call void @__olang_check_failed(ptr @olang_loc_f9f7abe6f4095c55_11136f6e879bf089)
  unreachable
bb66:
  br label %bb67
bb67:
  %t309 = load ptr, ptr %l12, !tbaa !29
  %t311 = getelementptr %"compiler/ast:TypeParam", ptr %t309, i32 0, i32 2
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t312)
  store %"compiler/source:Span" %t314, ptr %l155
  br label %bb68
bb68:
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l156, !tbaa !29
  %t316 = load ptr, ptr %l12, !tbaa !29
  %t318 = getelementptr %"compiler/ast:TypeParam", ptr %t316, i32 0, i32 2
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = icmp eq ptr %t319, null
  br i1 %t321, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_f9f7abe6f4095c55_11136f6e879bf089)
  unreachable
bb70:
  br label %bb71
bb71:
  %t323 = load ptr, ptr %l12, !tbaa !29
  %t325 = getelementptr %"compiler/ast:TypeParam", ptr %t323, i32 0, i32 2
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t326)
  store %"compiler/source:Span" %t328, ptr %l162
  br label %bb72
bb72:
  %t329 = load ptr, ptr %l156, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l162
  %t331 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t329, %"compiler/source:Span" %t330)
  store { i64, ptr } %t331, ptr %l163
  br label %bb73
bb73:
  %t332 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t333 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v0, { i64, ptr } %t332)
  store %"compiler/diagmsg:Msg" %t333, ptr %l164
  br label %bb74
bb74:
  %t334 = load ptr, ptr %l149, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l155
  %t336 = load %"compiler/diagmsg:Msg", ptr %l164
  %t337 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t334, %"compiler/source:Span" %t335, %"compiler/diagmsg:Msg" %t336)
  store i64 %t337, ptr %l165
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t338 = load ptr, ptr %l12, !tbaa !29
  %t340 = getelementptr %"compiler/ast:TypeParam", ptr %t338, i32 0, i32 3
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !27
  store { i64, ptr } %t341, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t343 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t343, 0
  store i64 %t345, ptr %l18, !tbaa !24
  br label %bb77
bb77:
  %t347 = load i64, ptr %l17, !tbaa !24
  %t348 = load i64, ptr %l18, !tbaa !24
  %t351 = icmp slt i64 %t347, %t348
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb78, label %bb79
bb78:
  br label %bb91
bb79:
  br label %bb80
bb80:
  %t355 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t355, ptr %l174, !tbaa !27
  %t356 = load i64, ptr %l17, !tbaa !24
  %t358 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = getelementptr ptr, ptr %t359, i64 %t356
  %t361 = load ptr, ptr %t360, !tbaa !39
  store ptr %t361, ptr %l19, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i64, ptr %l3, !tbaa !24
  %t365 = load ptr, ptr %l19, !tbaa !29
  %t369 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v0, ptr %t363, i64 %t364, ptr %t365)
  store i1 %t369, ptr %l180
  br label %bb81
bb81:
  %t370 = load i1, ptr %l180, !tbaa !21
  %t371 = xor i1 %t370, true
  br i1 %t371, label %bb82, label %bb83
bb82:
  %t373 = load ptr, ptr %l0, !tbaa !29
  store ptr %t373, ptr %l182, !tbaa !29
  %t374 = load ptr, ptr %l19, !tbaa !29
  %t376 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t374)
  store %"compiler/source:Span" %t376, ptr %l184
  br label %bb84
bb83:
  br label %bb89
bb84:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l185, !tbaa !29
  %t378 = load ptr, ptr %l19, !tbaa !29
  %t380 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t378)
  store %"compiler/source:Span" %t380, ptr %l187
  br label %bb85
bb85:
  %t381 = load ptr, ptr %l185, !tbaa !29
  %t382 = load %"compiler/source:Span", ptr %l187
  %t383 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t381, %"compiler/source:Span" %t382)
  store { i64, ptr } %t383, ptr %l188
  br label %bb86
bb86:
  %t384 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t385 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v0, { i64, ptr } %t384)
  store %"compiler/diagmsg:Msg" %t385, ptr %l189
  br label %bb87
bb87:
  %t386 = load ptr, ptr %l182, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l184
  %t388 = load %"compiler/diagmsg:Msg", ptr %l189
  %t389 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t386, %"compiler/source:Span" %t387, %"compiler/diagmsg:Msg" %t388)
  store i64 %t389, ptr %l190
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t390 = load i64, ptr %l17, !tbaa !24
  %t392 = add i64 %t390, 1
  store i64 %t392, ptr %l17, !tbaa !24
  br label %bb77
bb91:
  br label %bb92
bb92:
  %t394 = load i64, ptr %l10, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l10, !tbaa !24
  br label %bb24
bb93:
  br label %bb94
bb94:
  %t398 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t398)
  br label %bb95
bb95:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/generic:Origin"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l41 = alloca ptr
  %l46 = alloca i64
  %l51 = alloca i1
  %l55 = alloca i64
  %l59 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca i1
  %l80 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l89 = alloca { i64, ptr }
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l94 = alloca ptr
  %l96 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l127 = alloca { i64, ptr }
  %l135 = alloca i64
  %l138 = alloca i1
  %l143 = alloca i64
  %l146 = alloca i32
  %l151 = alloca i32
  %l156 = alloca i1
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca i64
  %l164 = alloca i32
  %l167 = alloca { i64, [3 x i64] }
  %l168 = alloca i1
  %l171 = alloca ptr
  %l174 = alloca i1
  %l178 = alloca i1
  %l183 = alloca ptr
  %l187 = alloca i32
  %l192 = alloca ptr
  %l195 = alloca %"compiler/generic:Origin"
  %l200 = alloca i64
  %l206 = alloca i1
  %l207 = alloca ptr
  %l211 = alloca i32
  %l213 = alloca i1
  %l217 = alloca ptr
  %l220 = alloca i64
  %l224 = alloca i32
  %l227 = alloca i1
  %l230 = alloca ptr
  %l235 = alloca i32
  %l240 = alloca i32
  %l243 = alloca i32
  %l248 = alloca i32
  %l249 = alloca i32
  %l251 = alloca ptr
  %l252 = alloca i64
  %l255 = alloca { i64, [3 x i64] }
  %l256 = alloca i64
  %l258 = alloca ptr
  %l262 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l268 = alloca %"compiler/check:roFn"
  %l272 = alloca ptr
  %l276 = alloca i1
  %l280 = alloca i64
  %l283 = alloca ptr
  %l288 = alloca i32
  %l289 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca i32
  %l300 = alloca i64
  %l301 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t633 = alloca { i64, [4 x i64] }, align 8
  %t641 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l4, !tbaa !23
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l27
  br label %bb3
bb2:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l27, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l23, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t21)
  store i64 %t23, ptr %l33
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load i64, ptr %l33, !tbaa !24
  %t26 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t26, ptr %l34
  br label %bb8
bb8:
  %t27 = load i64, ptr %l34, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  store i1 %t28, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l29, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t31)
  store i64 %t33, ptr %l37
  br label %bb12
bb11:
  br label %bb77
bb12:
  %t34 = load i64, ptr %l37, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store ptr %t42, ptr %l41
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l41, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 5
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l46, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l46, !tbaa !24
  store i64 %t60, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l51
  br label %bb17
bb17:
  %t64 = load i1, ptr %l51, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l55
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t73 = load i64, ptr %l55, !tbaa !24
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l5, !tbaa !24
  %t81 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l59
  br label %bb22
bb22:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l59, !tbaa !24
  %t85 = icmp sgt i64 %t83, %t82
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l62, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t88, ptr %l63
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Func", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t89, i32 %t93)
  store { i64, ptr } %t96, ptr %l67
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t97 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t98 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %v0, { i64, ptr } %t97)
  store %"compiler/diagmsg:Msg" %t98, ptr %l68
  br label %bb26
bb26:
  %t99 = load ptr, ptr %l62, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l63
  %t101 = load %"compiler/diagmsg:Msg", ptr %l68
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t99, %"compiler/source:Span" %t100, %"compiler/diagmsg:Msg" %t101)
  store i64 %t102, ptr %l69
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t103, %"compiler/source:Span" %t104)
  store ptr %t107, ptr %l72
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load ptr, ptr %l72, !tbaa !29
  store ptr %t108, ptr %rv
  br label %ret
bb29:
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t113 = icmp eq i64 %t111, 0
  br i1 %t113, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb33
bb31:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i64, ptr %l5, !tbaa !24
  %t122 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t118, i64 %t119)
  store i64 %t122, ptr %l80
  br label %bb32
bb32:
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = load i64, ptr %l80, !tbaa !24
  %t128 = icmp ne i64 %t126, %t125
  store i1 %t128, ptr %l76, !tbaa !21
  br label %bb33
bb33:
  %t130 = load i1, ptr %l76, !tbaa !21
  br i1 %t130, label %bb34, label %bb35
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l84, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l85
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l6, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Func", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  %t140 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t133, i32 %t137)
  store { i64, ptr } %t140, ptr %l89
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t141 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t142 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v0, { i64, ptr } %t141)
  store %"compiler/diagmsg:Msg" %t142, ptr %l90
  br label %bb37
bb37:
  %t143 = load ptr, ptr %l84, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l85
  %t145 = load %"compiler/diagmsg:Msg", ptr %l90
  %t146 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t143, %"compiler/source:Span" %t144, %"compiler/diagmsg:Msg" %t145)
  store i64 %t146, ptr %l91
  br label %bb38
bb38:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t147, %"compiler/source:Span" %t148)
  store ptr %t151, ptr %l94
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t152 = load ptr, ptr %l94, !tbaa !29
  store ptr %t152, ptr %rv
  br label %ret
bb40:
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l96, !tbaa !24
  %t156 = load i64, ptr %l96, !tbaa !24
  %t157 = icmp sge i64 %t156, 0
  br i1 %t157, label %bb41, label %bb42
bb41:
  %t159 = load i64, ptr %l96, !tbaa !24
  %t160 = icmp sle i64 %t159, 2305843009213693951
  br i1 %t160, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_de04a3fa462e2701_a46741d0a252ba9d)
  unreachable
bb43:
  %t162 = load i64, ptr %l96, !tbaa !24
  %t163 = mul i64 %t162, 4
  %t164 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t172 = load i64, ptr %l10, !tbaa !24
  %t173 = load i64, ptr %l9, !tbaa !24
  %t176 = icmp sgt i64 %t172, %t173
  br i1 %t176, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_de04a3fa462e2701_a46741d0a252ba9d)
  unreachable
bb45:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t180 = icmp sgt i64 %t178, 0
  br i1 %t180, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb50
bb47:
  %t182 = load i64, ptr %l10, !tbaa !24
  %t183 = load i64, ptr %l9, !tbaa !24
  %t186 = sub i64 %t182, %t183
  %t187 = load i64, ptr %l11, !tbaa !24
  %t190 = add i64 %t186, %t187
  %t192 = sub i64 %t190, 1
  %t193 = load i64, ptr %l11, !tbaa !24
  %t196 = sdiv i64 %t192, %t193
  store i64 %t196, ptr %l108, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb49
bb49:
  %t198 = load i64, ptr %l108, !tbaa !24
  store i64 %t198, ptr %l105, !tbaa !24
  br label %bb50
bb50:
  %t199 = load i64, ptr %l105, !tbaa !24
  store i64 %t199, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb51
bb51:
  %t200 = load i64, ptr %l13, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb52, label %bb53
bb52:
  br label %bb56
bb53:
  br label %bb54
bb54:
  %t208 = load i64, ptr %l9, !tbaa !24
  %t209 = load i64, ptr %l13, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = mul i64 %t209, %t210
  %t216 = add i64 %t208, %t213
  store i64 %t216, ptr %l14, !tbaa !24
  %t218 = load i64, ptr %l14, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t219, ptr %l127, !tbaa !27
  %t220 = load i64, ptr %l14, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i32, ptr %t223, i64 %t220
  %t225 = load i32, ptr %t224, !tbaa !33
  %t228 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i32, ptr %t229, i64 %t218
  store i32 %t225, ptr %t230, !tbaa !33
  br label %bb55
bb55:
  %t231 = load i64, ptr %l13, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l13, !tbaa !24
  br label %bb51
bb56:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t239 = load i64, ptr %l2, !tbaa !24
  %t242 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l135
  br label %bb57
bb57:
  %t243 = load i64, ptr %l135, !tbaa !24
  store i64 %t243, ptr %l15, !tbaa !24
  %t244 = load i64, ptr %l15, !tbaa !24
  %t246 = icmp sge i64 %t244, 0
  br i1 %t246, label %bb58, label %bb59
bb58:
  %t248 = load i64, ptr %l15, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i32, ptr %t251, i64 %t248
  %t253 = load i32, ptr %t252, !tbaa !33
  %t254 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t257 = icmp eq i32 %t253, %t254
  store i1 %t257, ptr %l138, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb60
bb60:
  %t259 = load i1, ptr %l138, !tbaa !21
  br i1 %t259, label %bb61, label %bb62
bb61:
  %t260 = load i64, ptr %l15, !tbaa !24
  store i64 %t260, ptr %l143, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t264, i32 0)
  store i32 %t266, ptr %l146
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t267 = load i32, ptr %l146, !tbaa !23
  %t268 = load i64, ptr %l143, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i32, ptr %t270, i64 %t268
  store i32 %t267, ptr %t271, !tbaa !33
  br label %bb64
bb64:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Program", ptr %t275, i32 0, i32 2
  %t278 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t281 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s1, ptr %t277, { i64, ptr } %t278)
  store i32 %t281, ptr %l151
  br label %bb65
bb65:
  %t282 = load i32, ptr %l151, !tbaa !23
  store i32 %t282, ptr %l4, !tbaa !23
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i64, ptr %l5, !tbaa !24
  %t285 = load i32, ptr %l4, !tbaa !23
  %t286 = load %"compiler/source:Span", ptr %l1
  %t291 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %t283, i64 %t284, i32 %t285, %"compiler/source:Span" %t286)
  store i1 %t291, ptr %l156
  br label %bb66
bb66:
  %t292 = load i1, ptr %l156, !tbaa !21
  %t293 = xor i1 %t292, true
  br i1 %t293, label %bb67, label %bb68
bb67:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t295, %"compiler/source:Span" %t296)
  store ptr %t299, ptr %l160
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t300 = load ptr, ptr %l160, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb70:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  store ptr %t304, ptr %l162, !tbaa !29
  %t305 = load i64, ptr %l2, !tbaa !24
  store i64 %t305, ptr %l163, !tbaa !24
  %t306 = load i32, ptr %l4, !tbaa !23
  store i32 %t306, ptr %l164, !tbaa !23
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i64, ptr %l2, !tbaa !24
  %t311 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %t307, i64 %t308)
  store { i64, [3 x i64] } %t311, ptr %l167
  br label %bb71
bb71:
  %t312 = load ptr, ptr %l162, !tbaa !29
  %t313 = load i64, ptr %l163, !tbaa !24
  %t314 = load i32, ptr %l164, !tbaa !23
  %t315 = load { i64, [3 x i64] }, ptr %l167
  %t316 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnTooDeep(ptr %v0, ptr %t312, i64 %t313, i32 %t314, { i64, [3 x i64] } %t315)
  store i1 %t316, ptr %l168
  br label %bb72
bb72:
  %t317 = load i1, ptr %l168, !tbaa !21
  br i1 %t317, label %bb73, label %bb74
bb73:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l1
  %t322 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t318, %"compiler/source:Span" %t319)
  store ptr %t322, ptr %l171
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t323 = load ptr, ptr %l171, !tbaa !29
  store ptr %t323, ptr %rv
  br label %ret
bb76:
  call void @__olang_scope_close(ptr %s1)
  br label %bb77
bb77:
  %t324 = load i64, ptr %l2, !tbaa !24
  %t326 = icmp slt i64 %t324, 0
  br i1 %t326, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb81
bb79:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t332 = load i64, ptr %l2, !tbaa !24
  %t335 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t331, i64 %t332)
  store i1 %t335, ptr %l178
  br label %bb80
bb80:
  %t336 = load i1, ptr %l178, !tbaa !21
  store i1 %t336, ptr %l174, !tbaa !21
  br label %bb81
bb81:
  %t337 = load i1, ptr %l174, !tbaa !21
  br i1 %t337, label %bb82, label %bb83
bb82:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t338, %"compiler/source:Span" %t339, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l1
  %t346 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t342, %"compiler/source:Span" %t343)
  store ptr %t346, ptr %l183
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t347 = load ptr, ptr %l183, !tbaa !29
  store ptr %t347, ptr %rv
  br label %ret
bb86:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/check:Checker", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t352 = load i64, ptr %l2, !tbaa !24
  %t355 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t351, i64 %t352)
  store i32 %t355, ptr %l187
  br label %bb87
bb87:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = getelementptr %"compiler/generic:Program", ptr %t359, i32 0, i32 51
  %t362 = load %"compiler/generic:Origin", ptr %t361
  store %"compiler/generic:Origin" %t362, ptr %l16
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/check:Checker", ptr %t364, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !29
  store ptr %t367, ptr %l192, !tbaa !29
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l1
  %t372 = call %"compiler/generic:Origin" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorigin(ptr %v0, ptr %t368, %"compiler/source:Span" %t369)
  store %"compiler/generic:Origin" %t372, ptr %l195
  br label %bb88
bb88:
  %t373 = load %"compiler/generic:Origin", ptr %l195
  %t374 = load ptr, ptr %l192, !tbaa !29
  %t375 = getelementptr %"compiler/generic:Program", ptr %t374, i32 0, i32 51
  store %"compiler/generic:Origin" %t373, ptr %t375
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/check:Checker", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t380 = load i64, ptr %l2, !tbaa !24
  %t381 = load i32, ptr %l4, !tbaa !23
  %t385 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t379, i64 %t380, i32 %t381)
  store i64 %t385, ptr %l200
  br label %bb89
bb89:
  %t386 = load i64, ptr %l200, !tbaa !24
  store i64 %t386, ptr %l17, !tbaa !24
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t391 = load %"compiler/generic:Origin", ptr %l16
  %t394 = getelementptr %"compiler/generic:Program", ptr %t390, i32 0, i32 51
  store %"compiler/generic:Origin" %t391, ptr %t394
  %t395 = load i32, ptr %l4, !tbaa !23
  %t397 = icmp ne i32 %t395, 0
  br i1 %t397, label %bb90, label %bb91
bb90:
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l207, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t404 = load i64, ptr %l17, !tbaa !24
  %t407 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t403, i64 %t404)
  store i32 %t407, ptr %l211
  br label %bb92
bb91:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb94
bb92:
  %t408 = load %"compiler/source:Span", ptr %l1
  %t409 = load ptr, ptr %l207, !tbaa !29
  %t410 = load i32, ptr %l211, !tbaa !23
  %t412 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t409, i32 %t410, %"compiler/source:Span" %t408)
  store i1 %t412, ptr %l213
  br label %bb93
bb93:
  %t413 = load i1, ptr %l213, !tbaa !21
  %t414 = xor i1 %t413, true
  store i1 %t414, ptr %l206, !tbaa !21
  br label %bb94
bb94:
  %t416 = load i1, ptr %l206, !tbaa !21
  br i1 %t416, label %bb95, label %bb96
bb95:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t417, %"compiler/source:Span" %t418)
  store ptr %t421, ptr %l217
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_scope_close(ptr %s0)
  %t422 = load ptr, ptr %l217, !tbaa !29
  store ptr %t422, ptr %rv
  br label %ret
bb98:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i64, ptr %l17, !tbaa !24
  %t427 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t423, i64 %t424)
  store i64 %t427, ptr %l220
  br label %bb99
bb99:
  %t428 = load i64, ptr %l220, !tbaa !24
  store i64 %t428, ptr %l18, !tbaa !24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/check:Checker", ptr %t429, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t433 = load i64, ptr %l17, !tbaa !24
  %t436 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t432, i64 %t433)
  store i32 %t436, ptr %l224
  br label %bb100
bb100:
  %t437 = load i32, ptr %l224, !tbaa !23
  store i32 %t437, ptr %l19, !tbaa !23
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load i32, ptr %l19, !tbaa !23
  %t442 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t438, i32 %t439)
  store i1 %t442, ptr %l227
  br label %bb101
bb101:
  %t443 = load i1, ptr %l227, !tbaa !21
  br i1 %t443, label %bb102, label %bb103
bb102:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/check:Checker", ptr %t444, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t449 = getelementptr %"compiler/generic:Program", ptr %t447, i32 0, i32 2
  store ptr %t449, ptr %l230, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/check:Checker", ptr %t450, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/generic:Program", ptr %t453, i32 0, i32 2
  %t456 = load i32, ptr %l19, !tbaa !23
  %t459 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t455, i32 %t456)
  store i32 %t459, ptr %l235
  br label %bb104
bb103:
  br label %bb109
bb104:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/check:Checker", ptr %t460, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = getelementptr %"compiler/generic:Program", ptr %t463, i32 0, i32 2
  %t466 = load i32, ptr %l19, !tbaa !23
  %t469 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t465, i32 %t466)
  store i32 %t469, ptr %l240
  br label %bb105
bb105:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i64, ptr %l18, !tbaa !24
  %t474 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t470, i64 %t471)
  store i32 %t474, ptr %l243
  br label %bb106
bb106:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 2
  %t481 = load i32, ptr %l19, !tbaa !23
  %t484 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l248
  br label %bb107
bb107:
  %t485 = load ptr, ptr %l230, !tbaa !29
  %t486 = load i32, ptr %l235, !tbaa !23
  %t487 = load i32, ptr %l240, !tbaa !23
  %t488 = load i32, ptr %l243, !tbaa !23
  %t489 = load i32, ptr %l248, !tbaa !23
  %t490 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t485, i32 %t486, i32 %t487, i32 %t488, i32 %t489, i64 0, i1 false, i32 0, i64 0)
  store i32 %t490, ptr %l249
  br label %bb108
bb108:
  %t491 = load i32, ptr %l249, !tbaa !23
  store i32 %t491, ptr %l19, !tbaa !23
  br label %bb109
bb109:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/check:Checker", ptr %t492, i32 0, i32 97
  store ptr %t494, ptr %l251, !tbaa !29
  %t495 = load i64, ptr %l18, !tbaa !24
  store i64 %t495, ptr %l252, !tbaa !24
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l1
  %t500 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t496, %"compiler/source:Span" %t497)
  store { i64, [3 x i64] } %t500, ptr %l255
  br label %bb110
bb110:
  %t501 = ptrtoint ptr %v0 to i64
  store i64 %t501, ptr %l256, !tbaa !24
  %t502 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aroFn_2e3
  br i1 %t502, label %bb111, label %bb112
bb111:
  %t504 = call ptr @__olang_region_make(ptr %v0)
  %t505 = ptrtoint ptr %t504 to i64
  store i64 %t505, ptr %l256, !tbaa !24
  br label %bb112
bb112:
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l258, !tbaa !29
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/check:Checker", ptr %t507, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t511 = load i64, ptr %l2, !tbaa !24
  %t514 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t510, i64 %t511)
  store ptr %t514, ptr %l262
  br label %bb113
bb113:
  %t515 = load ptr, ptr %l262, !tbaa !29
  %t517 = getelementptr %"compiler/ast:Func", ptr %t515, i32 0, i32 2
  %t518 = load i32, ptr %t517, !tbaa !23
  %t519 = load ptr, ptr %l258, !tbaa !29
  %t521 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t519, i32 %t518)
  store { i64, ptr } %t521, ptr %l265
  br label %bb114
bb114:
  %t522 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t524 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = extractvalue { i64, ptr } %t524, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t530 = add i64 %t527, %t529
  %t531 = load i64, ptr %l256
  %t532 = inttoptr i64 %t531 to ptr
  %t533 = call ptr @__olang_held_alloc(ptr %t532, i64 %t530)
  call void @olang_textcopy(ptr %t533, ptr %t522, i64 %t523)
  %t534 = getelementptr i8, ptr %t533, i64 %t523
  call void @olang_textcopy(ptr %t534, ptr %t525, i64 %t526)
  %t535 = getelementptr i8, ptr %t534, i64 %t526
  call void @olang_textcopy(ptr %t535, ptr %t528, i64 %t529)
  %t536 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t533, 1
  %t539 = load i64, ptr %l256
  %t540 = inttoptr i64 %t539 to ptr
  %t541 = extractvalue { i64, ptr } %t537, 0
  %t542 = extractvalue { i64, ptr } %t537, 1
  %t543 = mul i64 %t541, 1
  %t544 = call ptr @__olang_held_alloc(ptr %t540, i64 %t543)
  call void @llvm.memcpy.p0.p0.i64(ptr %t544, ptr %t542, i64 %t543, i1 false)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  %t547 = load i64, ptr %l252, !tbaa !24
  %t548 = load { i64, [3 x i64] }, ptr %l255
  %t550 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t547, i64 0, { i64, [3 x i64] } %t548, { i64, ptr } %t546)
  store %"compiler/check:roFn" %t550, ptr %l268
  br label %bb115
bb115:
  %t551 = load ptr, ptr %l251, !tbaa !29
  %t552 = load %"compiler/check:roFn", ptr %l268
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t551, %"compiler/check:roFn" %t552)
  br label %bb116
bb116:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/check:Checker", ptr %t553, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !29
  %t557 = load i64, ptr %l2, !tbaa !24
  %t560 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t556, i64 %t557)
  store ptr %t560, ptr %l272
  br label %bb117
bb117:
  %t561 = load ptr, ptr %l272, !tbaa !29
  store ptr %t561, ptr %l20, !tbaa !29
  %t562 = load ptr, ptr %l20, !tbaa !29
  %t564 = getelementptr %"compiler/ast:Func", ptr %t562, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !29
  %t567 = icmp eq ptr %t565, null
  br i1 %t567, label %bb118, label %bb119
bb118:
  %t569 = load ptr, ptr %l20, !tbaa !29
  %t571 = getelementptr %"compiler/ast:Func", ptr %t569, i32 0, i32 3
  %t572 = load ptr, ptr %t571, !tbaa !29
  %t574 = getelementptr %"compiler/ast:Sig", ptr %t572, i32 0, i32 0
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t575, 0
  store i64 %t577, ptr %l280, !tbaa !24
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = getelementptr %"compiler/check:Checker", ptr %t578, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !29
  %t583 = getelementptr %"compiler/generic:Program", ptr %t581, i32 0, i32 2
  store ptr %t583, ptr %l283, !tbaa !29
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/check:Checker", ptr %t584, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !29
  %t589 = getelementptr %"compiler/generic:Program", ptr %t587, i32 0, i32 2
  %t590 = load i32, ptr %l19, !tbaa !23
  %t593 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t589, i32 %t590)
  store i32 %t593, ptr %l288
  br label %bb120
bb119:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb122
bb120:
  %t594 = load ptr, ptr %l283, !tbaa !29
  %t595 = load i32, ptr %l288, !tbaa !23
  %t596 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t594, i32 %t595)
  store { i64, ptr } %t596, ptr %l289
  br label %bb121
bb121:
  %t597 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t598 = extractvalue { i64, ptr } %t597, 0
  %t599 = load i64, ptr %l280, !tbaa !24
  %t601 = icmp eq i64 %t599, %t598
  store i1 %t601, ptr %l276, !tbaa !21
  br label %bb122
bb122:
  %t603 = load i1, ptr %l276, !tbaa !21
  br i1 %t603, label %bb123, label %bb124
bb123:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 2
  store ptr %t609, ptr %l294, !tbaa !29
  %t610 = load i32, ptr %l19, !tbaa !23
  store i32 %t610, ptr %l295, !tbaa !23
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/check:Checker", ptr %t611, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !29
  %t615 = load ptr, ptr %l20, !tbaa !29
  %t617 = getelementptr %"compiler/ast:Func", ptr %t615, i32 0, i32 3
  %t618 = load ptr, ptr %t617, !tbaa !29
  %t621 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v0, ptr %t614, ptr %t618)
  store i64 %t621, ptr %l300
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t622 = load ptr, ptr %l294, !tbaa !29
  %t623 = load i32, ptr %l295, !tbaa !23
  %t624 = load i64, ptr %l300, !tbaa !24
  %t625 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t622, i32 %t623, i64 %t624)
  store i32 %t625, ptr %l301
  br label %bb126
bb126:
  %t626 = load i32, ptr %l301, !tbaa !23
  store i32 %t626, ptr %l19, !tbaa !23
  br label %bb127
bb127:
  %t627 = load %"compiler/source:Span", ptr %l1
  %t628 = load i32, ptr %l19, !tbaa !23
  %t629 = load i64, ptr %l18, !tbaa !24
  %t631 = trunc i64 %t629 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t633
  %t634 = getelementptr { i64, [4 x i64] }, ptr %t633, i32 0, i32 0
  store i64 0, ptr %t634
  %t636 = insertvalue { i32 } undef, i32 %t631, 0
  %t637 = getelementptr { i64, [4 x i64] }, ptr %t633, i32 0, i32 1
  store { i32 } %t636, ptr %t637
  %t638 = load { i64, [4 x i64] }, ptr %t633
  %t640 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t638, ptr %t640
  store { i64, [5 x i64] } zeroinitializer, ptr %t641
  %t642 = getelementptr { i64, [5 x i64] }, ptr %t641, i32 0, i32 0
  store i64 15, ptr %t642
  %t644 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t627, 0
  %t646 = insertvalue { %"compiler/source:Span", i32, ptr } %t644, i32 %t628, 1
  %t648 = insertvalue { %"compiler/source:Span", i32, ptr } %t646, ptr %t640, 2
  %t649 = getelementptr { i64, [5 x i64] }, ptr %t641, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t648, ptr %t649
  %t650 = load { i64, [5 x i64] }, ptr %t641
  %t652 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t650, ptr %t652
  call void @__olang_scope_close(ptr %s0)
  store ptr %t652, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca %"compiler/check:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 20
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 18
  store i1 true, ptr %t22, !tbaa !21
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 19
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t32 = call %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v1, ptr %v0, i64 %t26, %"compiler/source:Span" %a1, { i64, ptr } %a2)
  store %"compiler/check:Gap" %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"compiler/check:Gap", ptr %l20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t33, %"compiler/check:Gap" %t34)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenByValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, [3 x i64] }
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, [3 x i64] }
  %l29 = alloca i32
  %l34 = alloca i64
  %l36 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, [3 x i64] }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l47 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l55 = alloca { i64, [3 x i64] }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i64
  %t47 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l9
  %t7 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t5, %"compiler/source:Span" %t6)
  store { i64, ptr } %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 109
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l16, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l20
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t30, ptr %t27, ptr %t28)
  store i32 %t33, ptr %l25
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb5
bb5:
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = sext i32 %t37 to i64
  %t39 = load ptr, ptr %l13, !tbaa !29
  %t41 = call { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %t39, i64 %t38)
  %t42 = extractvalue { i32, { i64, [3 x i64] } } %t41, 1
  %t43 = extractvalue { i32, { i64, [3 x i64] } } %t41, 0
  store i32 %t43, ptr %l29
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb7, label %ok.45, !prof !99
ok.45:
  store { i64, [3 x i64] } %t42, ptr %l28
  br label %bb6
bb6:
  %t46 = load { i64, [3 x i64] }, ptr %l28
  store { i64, [3 x i64] } %t46, ptr %l11
  br label %bb9
bb7:
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t49 = load { i64, [3 x i64] }, ptr %t47
  store { i64, [3 x i64] } %t49, ptr %l11
  br label %bb9
bb9:
  %t51 = load { i64, [3 x i64] }, ptr %l11
  store { i64, [3 x i64] } %t51, ptr %l4
  %t52 = load { i64, [3 x i64] }, ptr %l4
  %t54 = extractvalue { i64, [3 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 3
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t57 = getelementptr { i64, [3 x i64] }, ptr %l4, i32 0, i32 1
  %t58 = getelementptr { i64, i64, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load i64, ptr %t58
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l34, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t62)
  store ptr %t64, ptr %l36
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l34, !tbaa !24
  %t71 = icmp ne i64 %t69, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/load:Loader", ptr %t79, i32 0, i32 4
  %t82 = load ptr, ptr %t81, !tbaa !29
  store ptr %t82, ptr %l43, !tbaa !29
  %t83 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t83, ptr %l44
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValueAway(ptr %v0, ptr %v0, { i64, ptr } %t84)
  store %"compiler/diagmsg:Msg" %t86, ptr %l46
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t87 = load ptr, ptr %l43, !tbaa !29
  %t88 = load { i64, [3 x i64] }, ptr %l44
  %t89 = load %"compiler/diagmsg:Msg", ptr %l46
  %t90 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t87, { i64, [3 x i64] } %t88, %"compiler/diagmsg:Msg" %t89)
  store i64 %t90, ptr %l47
  br label %bb17
bb17:
  %t91 = load i64, ptr %l47, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 4
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l51, !tbaa !29
  store i64 %t91, ptr %l52, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l2
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l55
  br label %bb18
bb18:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenSlot(ptr %v0, ptr %v0, { i64, ptr } %t108)
  store %"compiler/diagmsg:Msg" %t110, ptr %l57
  br label %bb19
bb19:
  %t111 = load ptr, ptr %l51, !tbaa !29
  %t112 = load i64, ptr %l52, !tbaa !24
  %t113 = load { i64, [3 x i64] }, ptr %l55
  %t114 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t111, i64 %t112, { i64, [3 x i64] } %t113, %"compiler/diagmsg:Msg" %t114)
  br label %bb20
bb20:
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_15eb6f7c806fc73b_bac9f6515206ea7f)
  unreachable
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l58, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t116, ptr %l59
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t119 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValue(ptr %v0, ptr %v0, { i64, ptr } %t117)
  store %"compiler/diagmsg:Msg" %t119, ptr %l61
  br label %bb27
bb27:
  %t120 = load ptr, ptr %l58, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l59
  %t122 = load %"compiler/diagmsg:Msg", ptr %l61
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t120, %"compiler/source:Span" %t121, %"compiler/diagmsg:Msg" %t122)
  store i64 %t123, ptr %l62
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenTypeDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/generic:Context"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i64
  %l42 = alloca i32
  %l46 = alloca %"compiler/generic:Context"
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l57 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca i1
  %l71 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i1
  %l103 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l120 = alloca ptr
  %l124 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %wh4 = alloca ptr
  %wc4 = alloca ptr
  %ws4 = alloca i32
  %t47 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l26, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t16, i64 %t17, i32 %t21)
  store i64 %t25, ptr %l35
  br label %bb7
bb7:
  %t26 = load i64, ptr %l35, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t34, i64 %t35, i64 %t36)
  store i32 %t40, ptr %l42
  br label %bb11
bb11:
  %t41 = load i32, ptr %l42, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t47, ptr %v0, ptr %s0, ptr %t45, i32 %t46)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t47, i64 160, i1 false)
  br label %bb12
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l46, i64 160, i1 false)
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TypeDecl", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  store ptr %t55, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t56 = load ptr, ptr %l49, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l49, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 5}
  %t62 = icmp eq i64 %t60, 0
  store i1 %t62, ptr %l50, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l50, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr { i64, [6 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { ptr }, ptr %t66, i32 0, i32 0
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l7, !tbaa !29
  br label %bb17
bb16:
  br label %bb34
bb17:
  store i64 0, ptr %l8, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t72 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v1, ptr %s4, ptr %t70)
  %t73 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t72, 0, 1
  %t74 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t72, 0, 0
  store ptr %t73, ptr %wh4
  store ptr %t74, ptr %wc4
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t72, ptr %l56
  br label %bb18
bb18:
  %t75 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l56
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t75, ptr %l9
  br label %bb19
bb19:
  %t77 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s4, ptr %l9)
  %t78 = extractvalue { i32, ptr } %t77, 1
  %t79 = extractvalue { i32, ptr } %t77, 0
  store i32 %t79, ptr %l60
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb21, label %ok.81, !prof !99
ok.81:
  store ptr %t78, ptr %l59
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l59, !tbaa !29
  store ptr %t82, ptr %l57, !tbaa !29
  br label %bb23
bb21:
  %t83 = load i32, ptr %l60, !tbaa !23
  %t84 = ashr i32 %t83, 16
  %t86 = icmp eq i32 %t84, 1
  store i1 %t86, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  br label %bb33
bb23:
  %t87 = load ptr, ptr %l57, !tbaa !29
  store ptr %t87, ptr %l10, !tbaa !29
  %t88 = load ptr, ptr %l10, !tbaa !29
  %t90 = getelementptr %"compiler/ast:VarDecl", ptr %t88, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t105 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t105, ptr %l71, !tbaa !27
  %t106 = load i64, ptr %l12, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l74, !tbaa !29
  store ptr %l5, ptr %l75, !tbaa !29
  %t114 = load ptr, ptr %l10, !tbaa !29
  %t116 = getelementptr %"compiler/ast:VarDecl", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l77, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s7, ptr %t118, i32 %t111)
  store { i64, ptr } %t122, ptr %l80
  br label %bb28
bb28:
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t125 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = getelementptr i8, ptr %t133, i64 %t127
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } %t136, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load i32, ptr %l4, !tbaa !23
  %t146 = sext i32 %t144 to i64
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load ptr, ptr %l74, !tbaa !29
  %t149 = load ptr, ptr %l75, !tbaa !29
  %t150 = load ptr, ptr %l77, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenMarks(ptr %v0, ptr %s0, ptr %v1, ptr %s7, ptr %t148, ptr %t149, ptr %t150, { i64, ptr } %t143, i64 %t146, i64 %t147, i1 true)
  br label %bb29
bb29:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l12, !tbaa !24
  br label %bb24
bb31:
  br label %bb32
bb32:
  br label %bb19
bb33:
  store i32 0, ptr %ws4
  br label %wend4
wend4.c0:
  call void @__olang_scope_close(ptr %s4)
  br label %bb59
bb34:
  %t162 = load ptr, ptr %l6, !tbaa !29
  store ptr %t162, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t163 = load ptr, ptr %l90, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb35, label %bb36
bb35:
  %t166 = load ptr, ptr %l90, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 5}
  %t169 = icmp eq i64 %t167, 1
  store i1 %t169, ptr %l91, !tbaa !21
  br label %bb36
bb36:
  %t170 = load i1, ptr %l91, !tbaa !21
  br i1 %t170, label %bb37, label %bb38
bb37:
  %t171 = load ptr, ptr %l6, !tbaa !29
  %t173 = getelementptr { i64, [6 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { { i64, ptr }, ptr }, ptr %t173, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174
  store { i64, ptr } %t175, ptr %l15, !tbaa !27
  br label %bb39
bb38:
  br label %bb54
bb39:
  %t177 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t177, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  store i64 %t181, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  %t183 = load i64, ptr %l17, !tbaa !24
  %t184 = load i64, ptr %l18, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb41, label %bb42
bb41:
  br label %bb53
bb42:
  br label %bb43
bb43:
  %t191 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t191, ptr %l103, !tbaa !27
  %t192 = load i64, ptr %l17, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr ptr, ptr %t195, i64 %t192
  %t197 = load ptr, ptr %t196, !tbaa !39
  %t201 = getelementptr %"compiler/ast:CaseDecl", ptr %t197, i32 0, i32 2
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t204 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l22, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s14
  %t208 = load i64, ptr %l21, !tbaa !24
  %t209 = load i64, ptr %l22, !tbaa !24
  %t212 = icmp slt i64 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s14)
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t216 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t216, ptr %l114, !tbaa !27
  %t217 = load i64, ptr %l21, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr ptr, ptr %t220, i64 %t217
  %t222 = load ptr, ptr %t221, !tbaa !39
  store ptr %t222, ptr %l23, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l117, !tbaa !29
  store ptr %l5, ptr %l118, !tbaa !29
  %t225 = load ptr, ptr %l23, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Param", ptr %t225, i32 0, i32 2
  %t228 = load ptr, ptr %t227, !tbaa !29
  store ptr %t228, ptr %l120, !tbaa !29
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l23, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Param", ptr %t230, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s14, ptr %t229, i32 %t233)
  store { i64, ptr } %t236, ptr %l124
  br label %bb48
bb48:
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t239 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t237, i64 %t238)
  %t247 = getelementptr i8, ptr %t246, i64 %t238
  call void @olang_textcopy(ptr %t247, ptr %t240, i64 %t241)
  %t248 = getelementptr i8, ptr %t247, i64 %t241
  call void @olang_textcopy(ptr %t248, ptr %t243, i64 %t244)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t246, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = extractvalue { i64, ptr } %t250, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load ptr, ptr %l117, !tbaa !29
  %t259 = load ptr, ptr %l118, !tbaa !29
  %t260 = load ptr, ptr %l120, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenMarks(ptr %v0, ptr %s0, ptr %v1, ptr %s14, ptr %t258, ptr %t259, ptr %t260, { i64, ptr } %t257, i64 -1, i64 -1, i1 true)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s14)
  br label %bb50
bb50:
  %t262 = load i64, ptr %l21, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l21, !tbaa !24
  br label %bb44
bb51:
  br label %bb52
bb52:
  %t266 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t266, 1
  store i64 %t268, ptr %l17, !tbaa !24
  br label %bb40
bb53:
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_e919a481eb9c0c53_bf698ad9ae031297)
  unreachable
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
wend4:
  %t270 = load ptr, ptr %wh4
  %t271 = load ptr, ptr %wc4
  %t272 = call ptr @llvm.coro.promise(ptr %t270, i32 8, i1 false)
  %t273 = getelementptr { { i32, ptr }, i32 }, ptr %t272, i32 0, i32 1
  store i32 2, ptr %t273
  %t274 = call { i32, ptr } %t271(ptr %t270, ptr null)
  %t275 = load i32, ptr %ws4
  switch i32 %t275, label %wend4.c0 [ ]
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %v0, ptr %t1, %"compiler/source:Span" %a1, ptr %t3)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t9, ptr %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:If", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:If", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb23
bb13:
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = getelementptr %"compiler/typed:If", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %t48)
  store i1 %t51, ptr %l28
  br label %bb14
bb14:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/ast:If", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb17, label %bb18
bb16:
  br label %bb22
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bb0c9585cb5cd0e5_782fa8d07097a5f1)
  unreachable
bb18:
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:If", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t65)
  store ptr %t67, ptr %l36
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t70 = getelementptr %"compiler/check:frame", ptr %t68, i32 0, i32 7
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l29, !tbaa !29
  %t73 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i1 false, i64 %t71)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_78bdf75b8d9b61cd_a447015cda228549)
  unreachable
bb28:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb28
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 8}
  %t28 = icmp eq i64 %t26, 5
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 8}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ce96f1d737413f70_b94e71a15147345c)
  unreachable
bb23:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l22, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l23, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l25, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t49)
  store ptr %t51, ptr %l27
  br label %bb24
bb24:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = load ptr, ptr %l25, !tbaa !29
  %t60 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t57, ptr %t54, ptr %t55)
  store i32 %t60, ptr %l32
  br label %bb25
bb25:
  %t61 = load ptr, ptr %l23, !tbaa !29
  %t62 = load i32, ptr %l32, !tbaa !23
  %t63 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t63, ptr %l33
  br label %bb26
bb26:
  %t64 = load ptr, ptr %l22, !tbaa !29
  %t65 = load i32, ptr %l33, !tbaa !23
  %t66 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t66, ptr %l34
  br label %bb27
bb27:
  %t67 = load i1, ptr %l34, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_cca9af72e1ece301_506f5d82865fcd8d)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l127 = alloca i32
  %l129 = alloca i32
  %l131 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca i1
  %l144 = alloca ptr
  %l151 = alloca ptr
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i32
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l169 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %t21 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [4 x i64] }, align 8
  %t298 = alloca { i64, [3 x i64] }, align 8
  %t347 = alloca { i64, [5 x i64] }, align 8
  %t359 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 25
  store i1 false, ptr %t7, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 5
  store i32 %t15, ptr %t18, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t24 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t20, 0
  %t25 = insertvalue { %"compiler/source:Span", ptr } %t24, ptr null, 1
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t25, ptr %t26
  %t27 = load { i64, [3 x i64] }, ptr %t21
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t27, ptr %t29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t19, ptr %t29)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 44
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l30
  br label %bb6
bb6:
  %t37 = load i64, ptr %l30, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = icmp sle i64 %t44, 2305843009213693951
  br i1 %t45, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb9:
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t47, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb11:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb16
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l44, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb16
bb16:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb18, label %bb19
bb18:
  br label %bb42
bb19:
  br label %bb20
bb20:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l11, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l64, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t104, ptr %t111, i32 %t113)
  store ptr %t117, ptr %l69
  br label %bb21
bb21:
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t118, ptr %l70, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l73
  br label %bb22
bb22:
  %t127 = load ptr, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l69, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l73
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t127, ptr %t128, %"compiler/source:Span" %t129)
  store ptr %t130, ptr %l74
  br label %bb23
bb23:
  %t131 = load ptr, ptr %l74, !tbaa !29
  store ptr %t131, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t135 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t132)
  store i32 %t135, ptr %l77
  br label %bb24
bb24:
  %t136 = load i32, ptr %l77, !tbaa !23
  store i32 %t136, ptr %l13, !tbaa !23
  %t137 = load i32, ptr %l13, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t141 = icmp eq i32 %t137, %t138
  br i1 %t141, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb27
bb26:
  %t143 = load i32, ptr %l13, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  store i1 %t147, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t149 = load i1, ptr %l81, !tbaa !21
  br i1 %t149, label %bb28, label %bb29
bb28:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l85, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t151, ptr %l86, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr ptr, ptr %t155, i64 %t152
  %t157 = load ptr, ptr %t156, !tbaa !39
  %t159 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t157)
  store %"compiler/source:Span" %t159, ptr %l89
  br label %bb30
bb29:
  %t160 = load i32, ptr %l13, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp ne i32 %t160, %t161
  br i1 %t164, label %bb33, label %bb34
bb30:
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t166, ptr %l90
  br label %bb31
bb31:
  %t167 = load ptr, ptr %l85, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l89
  %t169 = load %"compiler/diagmsg:Msg", ptr %l90
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t167, %"compiler/source:Span" %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l91
  br label %bb32
bb32:
  %t171 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t171, ptr %l13, !tbaa !23
  br label %bb37
bb33:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t174, ptr %l97, !tbaa !27
  %t175 = load i64, ptr %l11, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t173, ptr %t180, ptr %t181, i1 false)
  store i32 %t185, ptr %l101
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t186 = load i32, ptr %l101, !tbaa !23
  store i32 %t186, ptr %l13, !tbaa !23
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i32, ptr %l13, !tbaa !23
  %t191 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t187
  store i32 %t188, ptr %t193, !tbaa !33
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 44
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l106, !tbaa !29
  %t198 = load ptr, ptr %l12, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  %t199 = load i32, ptr %l13, !tbaa !23
  store i32 %t199, ptr %l108, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t200, ptr %l109, !tbaa !27
  %t201 = load i64, ptr %l11, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l112
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l106, !tbaa !29
  %t210 = load ptr, ptr %l107, !tbaa !29
  %t211 = load i32, ptr %l108, !tbaa !23
  %t212 = load %"compiler/source:Span", ptr %l112
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t209, ptr %t210, i32 %t211, %"compiler/source:Span" %t212)
  store ptr %t213, ptr %l113
  br label %bb39
bb39:
  %t214 = load ptr, ptr %l105, !tbaa !29
  %t215 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t214, ptr %t215)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t216 = load i64, ptr %l10, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l10, !tbaa !24
  br label %bb17
bb42:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 44
  %t223 = load i64, ptr %l4, !tbaa !24
  %t226 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t222, i64 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb43
bb43:
  %t227 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t227, ptr %l14, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t232 = icmp eq i64 %t230, 1
  br i1 %t232, label %bb44, label %bb45
bb44:
  %t234 = load ptr, ptr %l3, !tbaa !29
  %t235 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i32, ptr %t236, i64 0
  %t238 = load i32, ptr %t237, !tbaa !33
  %t241 = getelementptr %"compiler/check:frame", ptr %t234, i32 0, i32 5
  store i32 %t238, ptr %t241, !tbaa !23
  %t242 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t242, ptr %l125, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 0
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l15, !tbaa !29
  %t248 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 0
  %t251 = load i32, ptr %t250, !tbaa !33
  store i32 %t251, ptr %l127, !tbaa !23
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t252)
  store i32 %t254, ptr %l129
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t255 = load i32, ptr %l127, !tbaa !23
  %t256 = load i32, ptr %l129, !tbaa !23
  %t257 = icmp eq i32 %t255, %t256
  br i1 %t257, label %bb47, label %bb48
bb47:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l132, !tbaa !29
  %t260 = load ptr, ptr %l15, !tbaa !29
  %t263 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t260)
  store i32 %t263, ptr %l135
  br label %bb49
bb48:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb51
bb49:
  %t264 = load ptr, ptr %l132, !tbaa !29
  %t265 = load i32, ptr %l135, !tbaa !23
  %t266 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t266, ptr %l136
  br label %bb50
bb50:
  %t267 = load i1, ptr %l136, !tbaa !21
  store i1 %t267, ptr %l131, !tbaa !21
  br label %bb51
bb51:
  %t268 = load i1, ptr %l131, !tbaa !21
  br i1 %t268, label %bb52, label %bb53
bb52:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 0
  %t275 = load i32, ptr %t274, !tbaa !33
  %t276 = load ptr, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 0
  store i64 2, ptr %t278
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t271, 0
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t275, 1
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t276, 2
  %t285 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [4 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t286, ptr %t288
  %t292 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t269, %"compiler/source:Span" %t270, ptr %t288)
  store ptr %t292, ptr %l144
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t293 = load ptr, ptr %l144, !tbaa !29
  store ptr %t293, ptr %l15, !tbaa !29
  br label %bb55
bb55:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  %t296 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 0
  store i64 6, ptr %t299
  %t301 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t295, 0
  %t303 = insertvalue { %"compiler/source:Span", ptr } %t301, ptr %t296, 1
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t303, ptr %t304
  %t305 = load { i64, [3 x i64] }, ptr %t298
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t305, ptr %t307
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t294, ptr %t307)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb57:
  %t310 = load ptr, ptr %l3, !tbaa !29
  store ptr %t310, ptr %l151, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  store ptr %t316, ptr %l154, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  %t323 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t326 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t322, { i64, ptr } %t323)
  store i32 %t326, ptr %l159
  br label %bb58
bb58:
  %t327 = load ptr, ptr %l154, !tbaa !29
  %t328 = load i32, ptr %l159, !tbaa !23
  %t329 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t327, i32 %t328)
  store i32 %t329, ptr %l160
  br label %bb59
bb59:
  %t330 = load i32, ptr %l160, !tbaa !23
  %t331 = load ptr, ptr %l151, !tbaa !29
  %t332 = getelementptr %"compiler/check:frame", ptr %t331, i32 0, i32 5
  store i32 %t330, ptr %t332, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l161, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l162
  %t335 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t335, ptr %l163
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/check:frame", ptr %t336, i32 0, i32 5
  %t339 = load i32, ptr %t338, !tbaa !23
  store i32 %t339, ptr %l165, !tbaa !23
  %t340 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t344 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t340, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t344, ptr %l169
  br label %bb60
bb60:
  %t345 = load %"compiler/typed:Make", ptr %l169
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t345, ptr %t346
  store { i64, [5 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 0
  store i64 7, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l163
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t349, 0
  %t351 = load i32, ptr %l165, !tbaa !23
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, i32 %t351, 1
  %t354 = insertvalue { %"compiler/source:Span", i32, ptr } %t352, ptr %t346, 2
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t354, ptr %t355
  %t356 = load { i64, [5 x i64] }, ptr %t347
  %t358 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t356, ptr %t358
  store { i64, [3 x i64] } zeroinitializer, ptr %t359
  %t360 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 0
  store i64 6, ptr %t360
  %t361 = load %"compiler/source:Span", ptr %l162
  %t362 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t361, 0
  %t364 = insertvalue { %"compiler/source:Span", ptr } %t362, ptr %t358, 1
  %t365 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t364, ptr %t365
  %t366 = load { i64, [3 x i64] }, ptr %t359
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t366, ptr %t368
  %t369 = load ptr, ptr %l161, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t369, ptr %t368)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstContexts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:Origin"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l57 = alloca %"compiler/generic:Origin"
  %l60 = alloca ptr
  %l63 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca ptr
  %l97 = alloca i64
  %l101 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l105 = alloca ptr
  %l111 = alloca { i64, [3 x i64] }
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l121 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  %t192 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l26, !tbaa !24
  store i64 %t31, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l23, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  store ptr %t56, ptr %l46, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t60, i64 %t61)
  store i32 %t64, ptr %l50
  br label %bb12
bb12:
  %t65 = load ptr, ptr %l46, !tbaa !29
  %t66 = load i32, ptr %l50, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t65, i32 %t66)
  store { i64, ptr } %t67, ptr %l51
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t80 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/generic:Origin" %t80, ptr %l57
  br label %bb17
bb17:
  %t81 = load %"compiler/generic:Origin", ptr %l57
  store %"compiler/generic:Origin" %t81, ptr %l10
  %t82 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp slt i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb19:
  br label %bb20
bb20:
  store ptr %l2, ptr %l60, !tbaa !29
  %t87 = load %"compiler/generic:Origin", ptr %l10
  %t88 = load i64, ptr %l3, !tbaa !24
  %t91 = call %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %s2, %"compiler/generic:Origin" %t87, i64 %t88)
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t91, ptr %l63
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l60, !tbaa !29
  %t93 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb1726e9607ca4add8166541fc83d3bee(ptr %s0, ptr %t92, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t93)
  br label %bb22
bb22:
  %t94 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t99 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb8
bb27:
  store i64 0, ptr %l11, !tbaa !24
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %s0, ptr %l2)
  store i64 %t107, ptr %l70
  br label %bb28
bb28:
  %t108 = load i64, ptr %l70, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb29, label %bb30
bb29:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb34
bb31:
  %t119 = load i64, ptr %l12, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l13, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l77, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb33
bb33:
  %t135 = load i64, ptr %l77, !tbaa !24
  store i64 %t135, ptr %l74, !tbaa !24
  br label %bb34
bb34:
  %t136 = load i64, ptr %l74, !tbaa !24
  store i64 %t136, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb35
bb35:
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb36, label %bb37
bb36:
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t145 = load i64, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l15, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  store i64 %t153, ptr %l16, !tbaa !24
  store ptr %l2, ptr %l95, !tbaa !29
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %s0, ptr %l2)
  store i64 %t156, ptr %l97
  br label %bb39
bb39:
  %t157 = load i64, ptr %l97, !tbaa !24
  %t158 = sub i64 %t157, 1
  %t159 = load i64, ptr %l16, !tbaa !24
  %t162 = sub i64 %t158, %t159
  %t163 = load ptr, ptr %l95, !tbaa !29
  %t165 = call %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb10eca62c04bf212a25728cfc6f83c9c(ptr %s0, ptr %t163, i64 %t162)
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t165, ptr %l101
  br label %bb40
bb40:
  %t166 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l101
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t166, ptr %l17
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 4
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l105, !tbaa !29
  %t177 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t178 = getelementptr %"compiler/generic:Origin", ptr %t177, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t181 = getelementptr %"compiler/generic:Origin", ptr %t180, i32 0, i32 1
  %t182 = getelementptr %"compiler/source:Span", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  %t186 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t187 = getelementptr %"compiler/generic:Origin", ptr %t186, i32 0, i32 1
  %t188 = getelementptr %"compiler/source:Span", ptr %t187, i32 0, i32 1
  %t189 = load i32, ptr %t188, !tbaa !23
  %t191 = sext i32 %t189 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t197 = insertvalue { i64, i64, i64 } %t195, i64 %t185, 1
  %t199 = insertvalue { i64, i64, i64 } %t197, i64 %t191, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { i64, i64, i64 } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  store { i64, [3 x i64] } %t201, ptr %l111
  %t202 = ptrtoint ptr %v0 to i64
  store i64 %t202, ptr %l112, !tbaa !24
  %t203 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3acontext_2e1
  br i1 %t203, label %bb41, label %bb42
bb41:
  %t205 = call ptr @__olang_region_make(ptr %v0)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l112, !tbaa !24
  br label %bb42
bb42:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 1
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i64, ptr %l112
  %t211 = inttoptr i64 %t210 to ptr
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %t211, ptr %t207, i64 %t209)
  store { i64, ptr } %t214, ptr %l116
  br label %bb43
bb43:
  %t215 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t216 = load i64, ptr %l112
  %t217 = inttoptr i64 %t216 to ptr
  %t218 = extractvalue { i64, ptr } %t215, 0
  %t219 = extractvalue { i64, ptr } %t215, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_held_alloc(ptr %t217, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t224 = load ptr, ptr %l105, !tbaa !29
  %t225 = load { i64, [3 x i64] }, ptr %l111
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v0, ptr %t224, { i64, [3 x i64] } %t225, { i64, ptr } %t223)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l15, !tbaa !24
  br label %bb35
bb46:
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %s0, ptr %l2)
  store i64 %t232, ptr %l121
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t233 = load i64, ptr %l121, !tbaa !24
  store i64 %t233, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %s0, ptr %a0, i32 %a1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigned(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsMark" %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca %"compiler/check:factsMark"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca %"compiler/check:nullNarrow"
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l65 = alloca %"compiler/check:nullNarrow"
  %l67 = alloca %"compiler/check:nullNarrow"
  %l73 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l98 = alloca { i64, ptr }
  %l102 = alloca %"compiler/check:narrowed"
  %l104 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i64
  %l111 = alloca %"compiler/check:narrowed"
  %l113 = alloca %"compiler/check:narrowed"
  %l119 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i64
  %l144 = alloca { i64, ptr }
  %l148 = alloca %"compiler/check:errNarrow"
  %l150 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l157 = alloca %"compiler/check:errNarrow"
  %l159 = alloca %"compiler/check:errNarrow"
  store %"compiler/check:factsMark" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/check:factsMark", ptr %l1, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 50
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l27
  br label %bb2
bb2:
  %t13 = load i64, ptr %l27, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l34, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb22
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t60, ptr %l52, !tbaa !27
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 50
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store %"compiler/check:nullNarrow" %t67, ptr %l56
  br label %bb13
bb13:
  %t68 = getelementptr %"compiler/check:nullNarrow", ptr %l56, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t72 = call i1 @compiler_2fcheck_2eassignsName(ptr %v1, ptr %v0, { i64, ptr } %t70, { i64, ptr } %t69)
  store i1 %t72, ptr %l58
  br label %bb14
bb14:
  %t73 = load i1, ptr %l58, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:frame", ptr %t74, i32 0, i32 50
  store ptr %t76, ptr %l60, !tbaa !29
  %t77 = load i64, ptr %l9, !tbaa !24
  store i64 %t77, ptr %l61, !tbaa !24
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 50
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store %"compiler/check:nullNarrow" %t84, ptr %l65
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t85 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyAssigned, !tbaa !24
  %t86 = load %"compiler/check:nullNarrow", ptr %l65
  %t88 = call %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:nullNarrow" %t86, i64 %t85)
  store %"compiler/check:nullNarrow" %t88, ptr %l67
  br label %bb18
bb18:
  %t89 = load ptr, ptr %l60, !tbaa !29
  %t90 = load i64, ptr %l61, !tbaa !24
  %t91 = load %"compiler/check:nullNarrow", ptr %l67
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t89, i64 %t90, %"compiler/check:nullNarrow" %t91)
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb9
bb22:
  %t96 = getelementptr %"compiler/check:factsMark", ptr %l1, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 46
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l73
  br label %bb23
bb23:
  %t104 = load i64, ptr %l73, !tbaa !24
  store i64 %t104, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb24, label %bb25
bb24:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb29
bb26:
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l10, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l80, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l80, !tbaa !24
  store i64 %t131, ptr %l77, !tbaa !24
  br label %bb29
bb29:
  %t132 = load i64, ptr %l77, !tbaa !24
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb30
bb30:
  %t133 = load i64, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb31, label %bb32
bb31:
  br label %bb43
bb32:
  br label %bb33
bb33:
  %t141 = load i64, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  store i64 %t149, ptr %l15, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t151, ptr %l98, !tbaa !27
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 46
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t154, i64 %t155)
  store %"compiler/check:narrowed" %t158, ptr %l102
  br label %bb34
bb34:
  %t159 = getelementptr %"compiler/check:narrowed", ptr %l102, i32 0, i32 5
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t163 = call i1 @compiler_2fcheck_2eassignsName(ptr %v1, ptr %v0, { i64, ptr } %t161, { i64, ptr } %t160)
  store i1 %t163, ptr %l104
  br label %bb35
bb35:
  %t164 = load i1, ptr %l104, !tbaa !21
  br i1 %t164, label %bb36, label %bb37
bb36:
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/check:frame", ptr %t165, i32 0, i32 46
  store ptr %t167, ptr %l106, !tbaa !29
  %t168 = load i64, ptr %l15, !tbaa !24
  store i64 %t168, ptr %l107, !tbaa !24
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 46
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store %"compiler/check:narrowed" %t175, ptr %l111
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t176 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyAssigned, !tbaa !24
  %t177 = load %"compiler/check:narrowed", ptr %l111
  %t179 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v0, %"compiler/check:narrowed" %t177, i64 %t176)
  store %"compiler/check:narrowed" %t179, ptr %l113
  br label %bb39
bb39:
  %t180 = load ptr, ptr %l106, !tbaa !29
  %t181 = load i64, ptr %l107, !tbaa !24
  %t182 = load %"compiler/check:narrowed", ptr %l113
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v0, ptr %t180, i64 %t181, %"compiler/check:narrowed" %t182)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t183 = load i64, ptr %l14, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l14, !tbaa !24
  br label %bb30
bb43:
  %t187 = getelementptr %"compiler/check:factsMark", ptr %l1, i32 0, i32 2
  %t188 = load i64, ptr %t187, !tbaa !24
  store i64 %t188, ptr %l16, !tbaa !24
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 62
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l119
  br label %bb44
bb44:
  %t195 = load i64, ptr %l119, !tbaa !24
  store i64 %t195, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t197 = load i64, ptr %l16, !tbaa !24
  %t200 = icmp sgt i64 %t196, %t197
  br i1 %t200, label %bb45, label %bb46
bb45:
  %t202 = load i64, ptr %l18, !tbaa !24
  %t204 = icmp sgt i64 %t202, 0
  br i1 %t204, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb50
bb47:
  %t206 = load i64, ptr %l17, !tbaa !24
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = sub i64 %t206, %t207
  %t211 = load i64, ptr %l18, !tbaa !24
  %t214 = add i64 %t210, %t211
  %t216 = sub i64 %t214, 1
  %t217 = load i64, ptr %l18, !tbaa !24
  %t220 = sdiv i64 %t216, %t217
  store i64 %t220, ptr %l126, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb49
bb49:
  %t222 = load i64, ptr %l126, !tbaa !24
  store i64 %t222, ptr %l123, !tbaa !24
  br label %bb50
bb50:
  %t223 = load i64, ptr %l123, !tbaa !24
  store i64 %t223, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb51
bb51:
  %t224 = load i64, ptr %l20, !tbaa !24
  %t225 = load i64, ptr %l19, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb52, label %bb53
bb52:
  br label %bb64
bb53:
  br label %bb54
bb54:
  %t232 = load i64, ptr %l16, !tbaa !24
  %t233 = load i64, ptr %l20, !tbaa !24
  %t234 = load i64, ptr %l18, !tbaa !24
  %t237 = mul i64 %t233, %t234
  %t240 = add i64 %t232, %t237
  store i64 %t240, ptr %l21, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t242, ptr %l144, !tbaa !27
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t245 = getelementptr %"compiler/check:frame", ptr %t243, i32 0, i32 62
  %t246 = load i64, ptr %l21, !tbaa !24
  %t249 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v0, ptr %t245, i64 %t246)
  store %"compiler/check:errNarrow" %t249, ptr %l148
  br label %bb55
bb55:
  %t250 = getelementptr %"compiler/check:errNarrow", ptr %l148, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t254 = call i1 @compiler_2fcheck_2eassignsName(ptr %v1, ptr %v0, { i64, ptr } %t252, { i64, ptr } %t251)
  store i1 %t254, ptr %l150
  br label %bb56
bb56:
  %t255 = load i1, ptr %l150, !tbaa !21
  br i1 %t255, label %bb57, label %bb58
bb57:
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t258 = getelementptr %"compiler/check:frame", ptr %t256, i32 0, i32 62
  store ptr %t258, ptr %l152, !tbaa !29
  %t259 = load i64, ptr %l21, !tbaa !24
  store i64 %t259, ptr %l153, !tbaa !24
  %t260 = load ptr, ptr %l3, !tbaa !29
  %t262 = getelementptr %"compiler/check:frame", ptr %t260, i32 0, i32 62
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v0, ptr %t262, i64 %t263)
  store %"compiler/check:errNarrow" %t266, ptr %l157
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t267 = load i64, ptr @G_2ecompiler_2fcheck_2eWhyAssigned, !tbaa !24
  %t268 = load %"compiler/check:errNarrow", ptr %l157
  %t270 = call %"compiler/check:errNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3aerrNarrow_2eKilled(ptr %v0, ptr %v0, %"compiler/check:errNarrow" %t268, i64 %t267)
  store %"compiler/check:errNarrow" %t270, ptr %l159
  br label %bb60
bb60:
  %t271 = load ptr, ptr %l152, !tbaa !29
  %t272 = load i64, ptr %l153, !tbaa !24
  %t273 = load %"compiler/check:errNarrow", ptr %l159
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %v0, ptr %t271, i64 %t272, %"compiler/check:errNarrow" %t273)
  br label %bb61
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t274 = load i64, ptr %l20, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l20, !tbaa !24
  br label %bb51
bb64:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca [1 x i64]
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca %"compiler/check:laneNode"
  %l17 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca %"compiler/check:laneNode"
  %l33 = alloca i64
  %l38 = alloca i32
  %l39 = alloca %"compiler/check:laneNode"
  %l40 = alloca i64
  %l41 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %t1, ptr %a3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load i32, ptr %l2, !range !{i32 0, i32 113}
  store i32 %t8, ptr %l11
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 47
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t12)
  store %"compiler/check:laneNode" %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l11, !range !{i32 0, i32 113}
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %t18, i32 %t19, i32 %t17)
  store i32 %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = insertvalue [1 x i64] undef, i64 %t23, 0
  store [1 x i64] %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 113}
  store i32 %t31, ptr %l24
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l25
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l26
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 47
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t38, i64 %t39)
  store %"compiler/check:laneNode" %t42, ptr %l32
  br label %bb4
bb4:
  %t43 = getelementptr %"compiler/check:laneNode", ptr %l32, i32 0, i32 9
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l33, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %l6, 1
  %t49 = load i32, ptr %l5, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t45, { i64, ptr } %t48, i32 %t49)
  store i32 %t53, ptr %l38
  br label %bb5
bb5:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = load i32, ptr %l24, !range !{i32 0, i32 113}
  %t56 = load %"compiler/source:Span", ptr %l25
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = load i32, ptr %l28, !tbaa !23
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t54, i32 %t55, %"compiler/source:Span" %t56, %"compiler/source:Span" %t57, i64 %t58, i64 -1, i64 -1, ptr null, i32 %t59, i64 %t60, i32 %t61)
  store %"compiler/check:laneNode" %t62, ptr %l39
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l22, !tbaa !29
  %t64 = load %"compiler/check:laneNode", ptr %l39
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t63, %"compiler/check:laneNode" %t64)
  store i64 %t65, ptr %l40
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l20, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l21
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v2, ptr %t66, %"compiler/source:Span" %t67, i64 %t68)
  store ptr %t69, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l41, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t13 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store %"compiler/check:litv" %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t14, ptr %l3
  %t15 = getelementptr %"compiler/check:litv", ptr %l3, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/check:litv", ptr %l3
  %t20 = load i32, ptr %l2, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t18, %"compiler/check:litv" %t19, i32 %t20)
  store i1 %t24, ptr %l19
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 28}
  %t33 = icmp eq i64 %t31, 2
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t41, ptr %t42, i32 %t43)
  store i1 %t47, ptr %l29
  br label %bb14
bb14:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 28}
  %t56 = icmp eq i64 %t54, 8
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 3
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t70, ptr %t71, i32 %t72)
  store i1 %t76, ptr %l41
  br label %bb21
bb21:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t78, ptr %t79, i32 %t80)
  store i1 %t84, ptr %l46
  br label %bb24
bb23:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i1, ptr %l46, !tbaa !21
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l42, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 false, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_4be822f0c0d0de23_1d47e77fc9d2ed77)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteral(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca i64
  %l39 = alloca ptr
  %l44 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l77 = alloca ptr
  %l82 = alloca ptr
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t3 = trunc i64 6 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t7, ptr %l7
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t8, ptr %l8, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t9, %"compiler/source:Span" %t10)
  store { i64, ptr } %t13, ptr %l11
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t14 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t15, ptr %l12
  br label %bb4
bb4:
  %t16 = load i1, ptr %l12, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l13, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l7
  %t19 = load i32, ptr %l8, !tbaa !23
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t17, %"compiler/source:Span" %t18, i32 %t19, i64 %t20)
  store ptr %t21, ptr %l14
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t22 = load ptr, ptr %l14, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
bb9:
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t25 = trunc i64 7 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l21
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load i32, ptr %l3, !tbaa !23
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %t39, %"compiler/source:Span" %t40, i32 %t41)
  store ptr %t45, ptr %l25
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t46 = load ptr, ptr %l25, !tbaa !29
  store ptr %t46, ptr %rv
  br label %ret
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t47, %"compiler/source:Span" %t48, i32 %t49, i64 0)
  store ptr %t53, ptr %l29
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l29, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb18:
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t57 = trunc i64 4 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l33
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t62)
  store i32 %t64, ptr %l35
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t65, %"compiler/source:Span" %t66)
  store i64 %t69, ptr %l38
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l33
  %t72 = load i32, ptr %l35, !tbaa !23
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t70, %"compiler/source:Span" %t71, i32 %t72, i64 %t73)
  store ptr %t74, ptr %l39
  br label %bb23
bb23:
  %t75 = load ptr, ptr %l39, !tbaa !29
  store ptr %t75, ptr %rv
  br label %ret
bb24:
  %t76 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t78 = trunc i64 5 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l1
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %v1, ptr %t81, %"compiler/source:Span" %t82)
  store ptr %t85, ptr %l44
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t86 = load ptr, ptr %l44, !tbaa !29
  store ptr %t86, ptr %rv
  br label %ret
bb28:
  %t87 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t89 = trunc i64 2 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l1
  %t96 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t92, %"compiler/source:Span" %t93)
  store { i64, ptr } %t96, ptr %l49
  br label %bb31
bb30:
  br label %bb41
bb31:
  %t97 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t98 = call i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %t97)
  store i1 %t98, ptr %l50
  br label %bb32
bb32:
  %t99 = load i1, ptr %l50, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l52, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t103, ptr %l53
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t104, %"compiler/source:Span" %t105)
  store { i64, ptr } %t108, ptr %l56
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t109 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s7, { i64, ptr } %t109)
  store { i64, ptr } %t110, ptr %l57
  br label %bb36
bb36:
  %t111 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %s7, ptr %v0, { i64, ptr } %t117)
  store %"compiler/diagmsg:Msg" %t119, ptr %l59
  br label %bb37
bb37:
  %t120 = load ptr, ptr %l52, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l53
  %t122 = load %"compiler/diagmsg:Msg", ptr %l59
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t120, %"compiler/source:Span" %t121, %"compiler/diagmsg:Msg" %t122)
  store i64 %t123, ptr %l60
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb39:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l1
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t124, %"compiler/source:Span" %t125)
  store ptr %t128, ptr %l63
  br label %bb40
bb40:
  %t129 = load ptr, ptr %l63, !tbaa !29
  store ptr %t129, ptr %rv
  br label %ret
bb41:
  %t130 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t132 = trunc i64 3 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l66, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t136, ptr %l67
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t137, %"compiler/source:Span" %t138)
  store { i64, ptr } %t141, ptr %l70
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t142 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t143 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s8, { i64, ptr } %t142)
  store { i64, ptr } %t143, ptr %l71
  br label %bb45
bb45:
  %t144 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t152 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %s8, ptr %v0, { i64, ptr } %t150)
  store %"compiler/diagmsg:Msg" %t152, ptr %l73
  br label %bb46
bb46:
  %t153 = load ptr, ptr %l66, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l67
  %t155 = load %"compiler/diagmsg:Msg", ptr %l73
  %t156 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t153, %"compiler/source:Span" %t154, %"compiler/diagmsg:Msg" %t155)
  store i64 %t156, ptr %l74
  br label %bb47
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t157, %"compiler/source:Span" %t158)
  store ptr %t161, ptr %l77
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  %t162 = load ptr, ptr %l77, !tbaa !29
  store ptr %t162, ptr %rv
  br label %ret
bb49:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t163, %"compiler/source:Span" %t164, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb50
bb50:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l82
  br label %bb51
bb51:
  %t172 = load ptr, ptr %l82, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopLeave(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:loopUse"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l25 = alloca i64
  %l30 = alloca %"compiler/check:loopUse"
  %l32 = alloca %"compiler/check:loopUse"
  %l43 = alloca ptr
  %l44 = alloca %"compiler/check:loopUse"
  %l46 = alloca %"compiler/check:loopUse"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/diagmsg:Msg"
  %l51 = alloca i64
  %l54 = alloca ptr
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 54
  %t9 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t7)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l10, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  br label %ret
bb5:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 54
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = ptrtoint ptr %v0 to i64
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e55
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = call ptr @__olang_region_make(ptr %v0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t27 = load i64, ptr %l18
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2ector(ptr %t28, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load i64, ptr %l18
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_scope_alloc_a(ptr %t31, i64 32, i64 8)
  store ptr %t32, ptr %lp4
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  %t34 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %t34
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 55
  store ptr %t37, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l6, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2eLen_3ccompiler_2fcheck_3aloopUse_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l25
  br label %bb11
bb11:
  %t43 = load i64, ptr %l23, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = call %"compiler/check:loopUse" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2eAt_3ccompiler_2fcheck_3aloopUse_3e(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store %"compiler/check:loopUse" %t53, ptr %l30
  br label %bb15
bb15:
  %t55 = call %"compiler/check:loopUse" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aloopUse(ptr %s3, ptr %l30)
  store %"compiler/check:loopUse" %t55, ptr %l32
  br label %bb16
bb16:
  %t56 = load %"compiler/check:loopUse", ptr %l32
  store %"compiler/check:loopUse" %t56, ptr %l7
  %t57 = getelementptr %"compiler/check:loopUse", ptr %l7, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 51
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp eq i64 %t67, %t68
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t73 = getelementptr %"compiler/check:loopUse", ptr %l7, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr %l3, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  br i1 %t78, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t80 = load ptr, ptr %lp4
  store ptr %t80, ptr %l43, !tbaa !29
  %t81 = load %"compiler/check:loopUse", ptr %l7
  store %"compiler/check:loopUse" %t81, ptr %l44
  %t83 = call %"compiler/check:loopUse" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aloopUse(ptr %s6, ptr %l44)
  store %"compiler/check:loopUse" %t83, ptr %l46
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t84 = load i64, ptr %l18
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = load %"compiler/check:loopUse", ptr %l46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2ePush_3ccompiler_2fcheck_3aloopUse_3e(ptr %t85, ptr %s6, ptr %t86, %"compiler/check:loopUse" %t87)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l47, !tbaa !29
  %t89 = getelementptr %"compiler/check:loopUse", ptr %l7, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  store %"compiler/source:Span" %t90, ptr %l48
  %t91 = getelementptr %"compiler/check:loopUse", ptr %l7, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowedAcrossLoop(ptr %s3, ptr %v0, { i64, ptr } %t92)
  store %"compiler/diagmsg:Msg" %t94, ptr %l50
  br label %bb28
bb28:
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l48
  %t97 = load %"compiler/diagmsg:Msg", ptr %l50
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t95, %"compiler/source:Span" %t96, %"compiler/diagmsg:Msg" %t97)
  store i64 %t98, ptr %l51
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l6, !tbaa !24
  br label %bb10
bb31:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l54, !tbaa !29
  %t104 = load ptr, ptr %lp4
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t104
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 55
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l56
  %t110 = load ptr, ptr %l54, !tbaa !29
  %t111 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %t111
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e55
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = call ptr @__olang_region_home(ptr %t117)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_drop(ptr %t120)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l56
  br label %bb33
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l52 = alloca i32
  %l60 = alloca i1
  %l61 = alloca i1
  %l66 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i32
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i32
  %l108 = alloca i32
  %l109 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t19, i32 %t20, i32 %t21)
  store i1 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l10, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t31 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t29, i32 %t30, i32 %t31)
  store i1 %t35, ptr %l21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t43, ptr %l26
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l30
  br label %bb19
bb19:
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l34
  br label %bb22
bb21:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb23
bb22:
  %t58 = load i1, ptr %l34, !tbaa !21
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb24, label %bb25
bb24:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load i32, ptr %l2, !tbaa !23
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t63, i32 %t64, i32 %t65)
  store i32 %t69, ptr %l39
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t70 = load i32, ptr %l39, !tbaa !23
  %t71 = icmp sge i32 %t70, 0
  store i1 %t71, ptr %rv
  br label %ret
bb27:
  %t73 = load i32, ptr %l1, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l46
  br label %bb30
bb29:
  br label %bb35
bb30:
  %t84 = load i1, ptr %l46, !tbaa !21
  br i1 %t84, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb34
bb32:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l52
  br label %bb33
bb33:
  %t95 = load i32, ptr %l52, !range !{i32 0, i32 33}
  %t97 = trunc i64 21 to i32
  %t98 = icmp eq i32 %t95, %t97
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb34
bb34:
  %t100 = load i1, ptr %l47, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
bb35:
  %t101 = load i32, ptr %l2, !tbaa !23
  %t102 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t105 = icmp eq i32 %t101, %t102
  br i1 %t105, label %bb36, label %bb37
bb36:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l60
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t112 = load i1, ptr %l60, !tbaa !21
  br i1 %t112, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb42
bb40:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l1, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l66
  br label %bb41
bb41:
  %t123 = load i32, ptr %l66, !range !{i32 0, i32 33}
  %t125 = trunc i64 21 to i32
  %t126 = icmp eq i32 %t123, %t125
  store i1 %t126, ptr %l61, !tbaa !21
  br label %bb42
bb42:
  %t128 = load i1, ptr %l61, !tbaa !21
  store i1 %t128, ptr %rv
  br label %ret
bb43:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l1, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l71
  br label %bb44
bb44:
  %t134 = load i1, ptr %l71, !tbaa !21
  br i1 %t134, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb48
bb46:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t135, i32 %t136)
  store i1 %t139, ptr %l75
  br label %bb47
bb47:
  %t140 = load i1, ptr %l75, !tbaa !21
  store i1 %t140, ptr %l72, !tbaa !21
  br label %bb48
bb48:
  %t141 = load i1, ptr %l72, !tbaa !21
  br i1 %t141, label %bb49, label %bb50
bb49:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l76, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l1, !tbaa !23
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l79
  br label %bb51
bb50:
  br label %bb71
bb51:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t152 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l82
  br label %bb52
bb52:
  %t153 = load ptr, ptr %l76, !tbaa !29
  %t154 = load i32, ptr %l79, !tbaa !23
  %t155 = load i32, ptr %l82, !tbaa !23
  %t156 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t153, i32 %t154, i32 %t155)
  store i1 %t156, ptr %l83
  br label %bb53
bb53:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb54, label %bb55
bb54:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t158, i32 %t159)
  store i1 %t162, ptr %l87
  br label %bb56
bb55:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb70
bb56:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t167, ptr %l90
  br label %bb57
bb57:
  %t168 = load i1, ptr %l87, !tbaa !21
  %t169 = load i1, ptr %l90, !tbaa !21
  %t170 = icmp eq i1 %t168, %t169
  br i1 %t170, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb63
bb59:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l93, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l96
  br label %bb60
bb60:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l2, !tbaa !23
  %t182 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l99
  br label %bb61
bb61:
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = load i32, ptr %l96, !tbaa !23
  %t185 = load i32, ptr %l99, !tbaa !23
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t183, i32 %t184, i32 %t185)
  store i1 %t186, ptr %l100
  br label %bb62
bb62:
  %t187 = load i1, ptr %l100, !tbaa !21
  store i1 %t187, ptr %l92, !tbaa !21
  br label %bb63
bb63:
  %t188 = load i1, ptr %l92, !tbaa !21
  br i1 %t188, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb69
bb65:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l102, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l2, !tbaa !23
  %t194 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l105
  br label %bb66
bb66:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l108
  br label %bb67
bb67:
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i32, ptr %l105, !tbaa !23
  %t202 = load i32, ptr %l108, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t200, i32 %t201, i32 %t202)
  store i1 %t203, ptr %l109
  br label %bb68
bb68:
  %t204 = load i1, ptr %l109, !tbaa !21
  store i1 %t204, ptr %l101, !tbaa !21
  br label %bb69
bb69:
  %t205 = load i1, ptr %l101, !tbaa !21
  store i1 %t205, ptr %l84, !tbaa !21
  br label %bb70
bb70:
  %t206 = load i1, ptr %l84, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb71:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i64
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i32, ptr %t26, i64 %t23
  %t28 = load i32, ptr %t27, !tbaa !33
  store i32 %t28, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l5, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb9
bb9:
  %t47 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t49 = trunc i64 18 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l38
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb12:
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = load i32, ptr %l38, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t70, ptr %l39
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l5, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l47
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i32, ptr %l47, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l48
  br label %bb15
bb15:
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = load i64, ptr %l39, !tbaa !24
  %t94 = icmp ne i64 %t92, %t91
  store i1 %t94, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb2
bb21:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i32
  %l30 = alloca i1
  %l38 = alloca i32
  %l40 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l83 = alloca i32
  %l86 = alloca i1
  %l95 = alloca i64
  %l98 = alloca i64
  %l100 = alloca i64
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i64
  %l114 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i64
  %l123 = alloca i32
  %l130 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l19, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l21
  br label %bb3
bb3:
  %t9 = load i64, ptr %l19, !tbaa !24
  %t10 = load i64, ptr %l21, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb58
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t15, i64 %t16)
  store i32 %t19, ptr %l26
  br label %bb7
bb7:
  %t20 = load i32, ptr %l26, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load i32, ptr %l5, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t25 = icmp eq i32 %t21, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i32, ptr %l5, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l30, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  br label %bb57
bb12:
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l5, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l38
  br label %bb14
bb14:
  %t44 = load i32, ptr %l38, !tbaa !23
  store i32 %t44, ptr %l6, !tbaa !23
  store i64 -1, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l2)
  store i64 %t46, ptr %l40
  br label %bb15
bb15:
  %t47 = load i64, ptr %l40, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load i64, ptr %l10, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb21
bb18:
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l47, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb20
bb20:
  %t74 = load i64, ptr %l47, !tbaa !24
  store i64 %t74, ptr %l44, !tbaa !24
  br label %bb21
bb21:
  %t75 = load i64, ptr %l44, !tbaa !24
  store i64 %t75, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb22
bb22:
  %t76 = load i64, ptr %l12, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb23, label %bb24
bb23:
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l13, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l67, !tbaa !29
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l2, i64 %t100)
  store i32 %t103, ptr %l70
  br label %bb26
bb26:
  %t104 = load ptr, ptr %l67, !tbaa !29
  %t105 = load i32, ptr %l70, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t106, ptr %l71
  br label %bb27
bb27:
  %t107 = load i32, ptr %l6, !tbaa !23
  %t108 = load i32, ptr %l71, !tbaa !23
  %t110 = icmp eq i32 %t108, %t107
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t112 = load i64, ptr %l13, !tbaa !24
  store i64 %t112, ptr %l7, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t114 = load i64, ptr %l12, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l12, !tbaa !24
  br label %bb22
bb32:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = icmp slt i64 %t118, 0
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t122 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l2, i32 %t122)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb57
bb36:
  %t125 = load i64, ptr %l7, !tbaa !24
  %t128 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l2, i64 %t125)
  store i32 %t128, ptr %l83
  br label %bb37
bb37:
  %t129 = load i32, ptr %l6, !tbaa !23
  %t130 = load i32, ptr %l83, !tbaa !23
  %t132 = icmp eq i32 %t130, %t129
  br i1 %t132, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb40
bb39:
  %t134 = load i32, ptr %l5, !tbaa !23
  %t135 = load i32, ptr %l6, !tbaa !23
  %t138 = icmp eq i32 %t134, %t135
  store i1 %t138, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t140 = load i1, ptr %l86, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t141 = load i64, ptr %l7, !tbaa !24
  %t142 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l2, i64 %t141, i32 %t142)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb57
bb44:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l6, !tbaa !23
  %t150 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t146, i32 %t147)
  store i64 %t150, ptr %l95
  br label %bb45
bb45:
  %t151 = load i64, ptr %l95, !tbaa !24
  store i64 %t151, ptr %l14, !tbaa !24
  %t152 = load i64, ptr %l14, !tbaa !24
  %t154 = icmp sge i64 %t152, 64
  br i1 %t154, label %bb46, label %bb47
bb46:
  %t156 = sub i64 0, 1
  store i64 %t156, ptr %l98, !tbaa !65
  br label %bb48
bb47:
  %t158 = load i64, ptr %l14, !tbaa !24
  store i64 %t158, ptr %l100, !tbaa !24
  %t159 = load i64, ptr %l100, !tbaa !24
  %t160 = load i64, ptr %l100, !tbaa !24
  %t161 = shl i64 1, %t160
  %t163 = sub i64 %t161, 1
  store i64 %t163, ptr %l98, !tbaa !65
  br label %bb48
bb48:
  %t165 = load i64, ptr %l98, !tbaa !65
  store i64 %t165, ptr %l15, !tbaa !65
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l105, !tbaa !29
  %t172 = load i64, ptr %l7, !tbaa !24
  %t175 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l2, i64 %t172)
  store i32 %t175, ptr %l108
  br label %bb49
bb49:
  %t176 = load ptr, ptr %l105, !tbaa !29
  %t177 = load i32, ptr %l108, !tbaa !23
  %t178 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t176, i32 %t177)
  store i64 %t178, ptr %l109
  br label %bb50
bb50:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l5, !tbaa !23
  %t188 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t184, i32 %t185)
  store i64 %t188, ptr %l114
  br label %bb51
bb51:
  %t189 = load i64, ptr %l109, !tbaa !65
  %t190 = load i64, ptr %l114, !tbaa !65
  %t191 = or i64 %t189, %t190
  %t192 = load i64, ptr %l15, !tbaa !65
  %t195 = and i64 %t191, %t192
  store i64 %t195, ptr %l16, !tbaa !65
  store ptr %l2, ptr %l118, !tbaa !29
  %t197 = load i64, ptr %l7, !tbaa !24
  store i64 %t197, ptr %l119, !tbaa !24
  %t198 = load i64, ptr %l16, !tbaa !65
  %t199 = load i64, ptr %l15, !tbaa !65
  %t202 = icmp eq i64 %t198, %t199
  br i1 %t202, label %bb52, label %bb53
bb52:
  %t204 = load i32, ptr %l6, !tbaa !23
  store i32 %t204, ptr %l123, !tbaa !23
  br label %bb55
bb53:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %l6, !tbaa !23
  %t213 = load i64, ptr %l16, !tbaa !65
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t211, i32 %t212, i64 %t213)
  store i32 %t217, ptr %l130
  br label %bb54
bb54:
  %t218 = load i32, ptr %l130, !tbaa !23
  store i32 %t218, ptr %l123, !tbaa !23
  br label %bb55
bb55:
  %t219 = load ptr, ptr %l118, !tbaa !29
  %t220 = load i64, ptr %l119, !tbaa !24
  %t221 = load i32, ptr %l123, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t219, i64 %t220, i32 %t221)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t222 = load i64, ptr %l4, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l4, !tbaa !24
  br label %bb2
bb58:
  %t226 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emixedLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca %"compiler/diagmsg:Msg"
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %a1)
  store %"compiler/source:Span" %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l10
  %t11 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t9, %"compiler/source:Span" %t10)
  store { i64, ptr } %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l13, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l17, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l18, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l20
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l20
  %t43 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t41, %"compiler/source:Span" %t42)
  store { i64, ptr } %t43, ptr %l21
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t45, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l23, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t57, i32 %a4)
  store { i64, ptr } %t61, ptr %l26
  br label %bb7
bb7:
  %t62 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l27, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l30
  br label %bb8
bb8:
  %t74 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t100 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralMixed(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t95, { i64, ptr } %t96, { i64, ptr } %t97, { i64, ptr } %t98, { i64, ptr } %t94)
  store %"compiler/diagmsg:Msg" %t100, ptr %l33
  br label %bb9
bb9:
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l7
  %t103 = load %"compiler/diagmsg:Msg", ptr %l33
  %t104 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t101, %"compiler/source:Span" %t102, %"compiler/diagmsg:Msg" %t103)
  store i64 %t104, ptr %l34
  br label %bb10
bb10:
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutGlobalsValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/load:Import"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca i1
  %l84 = alloca i64
  %l87 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l107 = alloca %"compiler/load:Import"
  %l114 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca i64
  %l121 = alloca i64
  %l126 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca i64
  %l134 = alloca { i64, ptr }
  %l140 = alloca %"std/prelude/text:StringBuilder"
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l147 = alloca i64
  %l151 = alloca i64
  %l154 = alloca i64
  %l174 = alloca ptr
  %l178 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l184 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l206 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l29
  br label %bb1
bb1:
  %t4 = load i64, ptr %l29, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t7, ptr %l32, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l33, !tbaa !24
  %t10 = load i64, ptr %l33, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l34, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l33, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t21, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 10
  store ptr %t31, ptr %l2, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l40
  br label %bb5
bb5:
  %t36 = load i64, ptr %l40, !tbaa !24
  %t37 = icmp sge i64 %t36, 0
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load i64, ptr %l40, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l3, !tbaa !27
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l43
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d0f72ce45fbcaa4b_31766cde14dc3f8f)
  unreachable
bb8:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l45
  br label %bb9
bb9:
  %t50 = load i64, ptr %l45, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb15
bb12:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l52, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb14
bb14:
  %t77 = load i64, ptr %l52, !tbaa !24
  store i64 %t77, ptr %l49, !tbaa !24
  br label %bb15
bb15:
  %t78 = load i64, ptr %l49, !tbaa !24
  store i64 %t78, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb17, label %bb18
bb17:
  br label %bb27
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l10, !tbaa !24
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t97, i64 %t99)
  store ptr %t102, ptr %l73
  br label %bb20
bb20:
  %t103 = load ptr, ptr %l73, !tbaa !29
  %t105 = getelementptr %"compiler/load:Module", ptr %t103, i32 0, i32 4
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t112 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t108, i64 %t106)
  store i1 %t112, ptr %l78
  br label %bb21
bb21:
  %t113 = load i1, ptr %l78, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t114)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l9, !tbaa !24
  br label %bb16
bb27:
  br label %bb28
bb28:
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t122, ptr %l84
  br label %bb29
bb29:
  %t123 = load i64, ptr %l84, !tbaa !24
  %t124 = icmp sgt i64 %t123, 0
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb30, label %bb31
bb30:
  br label %bb54
bb31:
  br label %bb32
bb32:
  %t129 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l4)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l90
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb34, label %ok.133, !prof !99
ok.133:
  store i64 %t130, ptr %l89
  br label %bb33
bb33:
  %t134 = load i64, ptr %l89, !tbaa !24
  store i64 %t134, ptr %l87, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  br label %bb54
bb36:
  %t135 = load i64, ptr %l87, !tbaa !24
  store i64 %t135, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i1, ptr %t139, i64 %t136
  %t141 = load i1, ptr %t140, !tbaa !31
  br i1 %t141, label %bb37, label %bb38
bb37:
  br label %bb53
bb38:
  br label %bb39
bb39:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i1, ptr %t146, i64 %t143
  store i1 true, ptr %t147, !tbaa !31
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t148, i64 %t150)
  store ptr %t153, ptr %l97
  br label %bb40
bb40:
  %t154 = load ptr, ptr %l97, !tbaa !29
  %t156 = getelementptr %"compiler/load:Module", ptr %t154, i32 0, i32 11
  store ptr %t156, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  %t158 = load i64, ptr %l14, !tbaa !24
  store i64 %t158, ptr %l100, !tbaa !24
  %t159 = load ptr, ptr %l13, !tbaa !29
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l102
  br label %bb42
bb42:
  %t162 = load i64, ptr %l100, !tbaa !24
  %t163 = load i64, ptr %l102, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb43, label %bb44
bb43:
  br label %bb52
bb44:
  br label %bb45
bb45:
  %t168 = load ptr, ptr %l13, !tbaa !29
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t168, i64 %t169)
  store %"compiler/load:Import" %t172, ptr %l107
  br label %bb46
bb46:
  %t173 = load %"compiler/load:Import", ptr %l107
  store %"compiler/load:Import" %t173, ptr %l15
  %t174 = getelementptr %"compiler/load:Import", ptr %l15, i32 0, i32 5
  %t175 = load i64, ptr %t174, !tbaa !24
  %t177 = icmp sge i64 %t175, 0
  br i1 %t177, label %bb47, label %bb48
bb47:
  %t179 = getelementptr %"compiler/load:Import", ptr %l15, i32 0, i32 5
  %t180 = load i64, ptr %t179, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t180)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t183 = load i64, ptr %l14, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l14, !tbaa !24
  br label %bb41
bb52:
  br label %bb53
bb53:
  br label %bb28
bb54:
  %t187 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187, ptr %l114
  br label %bb55
bb55:
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l114
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l16
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/load:Loader", ptr %t195, i32 0, i32 9
  store ptr %t197, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb56
bb56:
  %t199 = load i64, ptr %l18, !tbaa !24
  store i64 %t199, ptr %l119, !tbaa !24
  %t200 = load ptr, ptr %l17, !tbaa !29
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t200)
  store i64 %t202, ptr %l121
  br label %bb57
bb57:
  %t203 = load i64, ptr %l119, !tbaa !24
  %t204 = load i64, ptr %l121, !tbaa !24
  %t205 = icmp slt i64 %t203, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb58, label %bb59
bb58:
  br label %bb67
bb59:
  br label %bb60
bb60:
  %t209 = load ptr, ptr %l17, !tbaa !29
  %t210 = load i64, ptr %l18, !tbaa !24
  %t213 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t209, i64 %t210)
  store i64 %t213, ptr %l126
  br label %bb61
bb61:
  %t214 = load i64, ptr %l126, !tbaa !24
  store i64 %t214, ptr %l19, !tbaa !24
  store ptr %l16, ptr %l127, !tbaa !29
  %t215 = ptrtoint ptr %s0 to i64
  store i64 %t215, ptr %l128, !tbaa !24
  %t216 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t216, label %bb62, label %bb63
bb62:
  %t218 = call ptr @__olang_region_make(ptr %s0)
  %t219 = ptrtoint ptr %t218 to i64
  store i64 %t219, ptr %l128, !tbaa !24
  br label %bb63
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i64, ptr %l19, !tbaa !24
  %t223 = trunc i64 %t221 to i32
  %t225 = load i64, ptr %l128
  %t226 = inttoptr i64 %t225 to ptr
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %t226, ptr %t220, i32 %t223)
  store { i64, ptr } %t229, ptr %l134
  br label %bb64
bb64:
  %t230 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t231 = load i64, ptr %l128
  %t232 = inttoptr i64 %t231 to ptr
  %t233 = extractvalue { i64, ptr } %t230, 0
  %t234 = extractvalue { i64, ptr } %t230, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_held_alloc(ptr %t232, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l127, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t238)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t241 = load i64, ptr %l18, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l18, !tbaa !24
  br label %bb56
bb67:
  %t245 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_27, 0
  %t246 = insertvalue { ptr, ptr } %t245, ptr null, 1
  %t249 = extractvalue { ptr, ptr } %t246, 0
  %t250 = extractvalue { ptr, ptr } %t246, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l16, ptr %t249, ptr %t250)
  br label %bb68
bb68:
  %t251 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t251, ptr %l140
  br label %bb69
bb69:
  %t252 = load %"std/prelude/text:StringBuilder", ptr %l140
  store %"std/prelude/text:StringBuilder" %t252, ptr %l20
  store ptr %l20, ptr %l141, !tbaa !29
  %t254 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l16, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store { i64, ptr } %t254, ptr %l143
  br label %bb70
bb70:
  %t255 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t260 = add i64 %t257, %t259
  %t261 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t260)
  call void @olang_textcopy(ptr %t261, ptr %t256, i64 %t257)
  %t262 = getelementptr i8, ptr %t261, i64 %t257
  call void @olang_textcopy(ptr %t262, ptr %t258, i64 %t259)
  %t263 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t261, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = extractvalue { i64, ptr } %t264, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  %t272 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t272, { i64, ptr } %t271)
  br label %bb71
bb71:
  store i64 0, ptr %l21, !tbaa !24
  %t274 = load ptr, ptr %l2, !tbaa !29
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l147
  br label %bb72
bb72:
  %t277 = load i64, ptr %l147, !tbaa !24
  store i64 %t277, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t278 = load i64, ptr %l22, !tbaa !24
  %t279 = load i64, ptr %l21, !tbaa !24
  %t282 = icmp sgt i64 %t278, %t279
  br i1 %t282, label %bb73, label %bb74
bb73:
  %t284 = load i64, ptr %l23, !tbaa !24
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb78
bb75:
  %t288 = load i64, ptr %l22, !tbaa !24
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = sub i64 %t288, %t289
  %t293 = load i64, ptr %l23, !tbaa !24
  %t296 = add i64 %t292, %t293
  %t298 = sub i64 %t296, 1
  %t299 = load i64, ptr %l23, !tbaa !24
  %t302 = sdiv i64 %t298, %t299
  store i64 %t302, ptr %l154, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb77
bb77:
  %t304 = load i64, ptr %l154, !tbaa !24
  store i64 %t304, ptr %l151, !tbaa !24
  br label %bb78
bb78:
  %t305 = load i64, ptr %l151, !tbaa !24
  store i64 %t305, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb79
bb79:
  %t306 = load i64, ptr %l25, !tbaa !24
  %t307 = load i64, ptr %l24, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb80, label %bb81
bb80:
  br label %bb97
bb81:
  br label %bb82
bb82:
  %t314 = load i64, ptr %l21, !tbaa !24
  %t315 = load i64, ptr %l25, !tbaa !24
  %t316 = load i64, ptr %l23, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l26, !tbaa !24
  %t324 = load i64, ptr %l26, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i1, ptr %t327, i64 %t324
  %t329 = load i1, ptr %t328, !tbaa !31
  br i1 %t329, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s19
  store ptr %l20, ptr %l174, !tbaa !29
  %t331 = load ptr, ptr %l2, !tbaa !29
  %t333 = load i64, ptr %l26, !tbaa !24
  %t336 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t331, i64 %t333)
  store ptr %t336, ptr %l178
  br label %bb85
bb84:
  br label %bb95
bb85:
  %t337 = load ptr, ptr %l178, !tbaa !29
  %t339 = getelementptr %"compiler/load:Module", ptr %t337, i32 0, i32 2
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l180, !tbaa !27
  %t341 = load ptr, ptr %l2, !tbaa !29
  %t343 = load i64, ptr %l26, !tbaa !24
  %t346 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t341, i64 %t343)
  store ptr %t346, ptr %l184
  br label %bb86
bb86:
  %t347 = load ptr, ptr %l184, !tbaa !29
  %t349 = getelementptr %"compiler/load:Module", ptr %t347, i32 0, i32 6
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t352 = icmp eq ptr %t350, null
  %t354 = xor i1 %t352, true
  br i1 %t354, label %bb87, label %bb88
bb87:
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = load i64, ptr %l26, !tbaa !24
  %t361 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t356, i64 %t358)
  store ptr %t361, ptr %l193
  br label %bb89
bb88:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l189, !tbaa !27
  br label %bb93
bb89:
  %t362 = load ptr, ptr %l193, !tbaa !29
  %t364 = getelementptr %"compiler/load:Module", ptr %t362, i32 0, i32 6
  %t365 = load ptr, ptr %t364, !tbaa !29
  store ptr %t365, ptr %l27, !tbaa !29
  %t367 = load ptr, ptr %l27, !tbaa !29
  %t369 = icmp eq ptr %t367, null
  br i1 %t369, label %bb90, label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_108bcd44a7d76d1e_c10b21813ea4a0da)
  unreachable
bb91:
  br label %bb92
bb92:
  %t371 = load ptr, ptr %l27, !tbaa !29
  %t374 = getelementptr %"compiler/source:Source", ptr %t371, i32 0, i32 1
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  store { i64, ptr } %t375, ptr %l189, !tbaa !27
  br label %bb93
bb93:
  %t377 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 1
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t378, i64 %t379)
  %t391 = getelementptr i8, ptr %t390, i64 %t379
  call void @olang_textcopy(ptr %t391, ptr %t380, i64 %t381)
  %t392 = getelementptr i8, ptr %t391, i64 %t381
  call void @olang_textcopy(ptr %t392, ptr %t384, i64 %t385)
  %t393 = getelementptr i8, ptr %t392, i64 %t385
  call void @olang_textcopy(ptr %t393, ptr %t387, i64 %t388)
  %t394 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t390, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  %t403 = load ptr, ptr %l174, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t403, { i64, ptr } %t402)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s19)
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t405 = load i64, ptr %l25, !tbaa !24
  %t407 = add i64 %t405, 1
  store i64 %t407, ptr %l25, !tbaa !24
  br label %bb79
bb97:
  %t410 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l20)
  store { i64, ptr } %t410, ptr %l206
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t411 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t411, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca %"compiler/typed:Local"
  %l26 = alloca i32
  %t11 = alloca { i64, [4 x i64] }, align 8
  %t53 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l6
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i64, ptr %l2, !tbaa !24
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t2, i64 %t3)
  store i32 %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = trunc i64 %t7 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load %"compiler/source:Span", ptr %l6
  %t14 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t13, 0
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = insertvalue { %"compiler/source:Span", i32, i32 } %t14, i32 %t15, 1
  %t18 = insertvalue { %"compiler/source:Span", i32, i32 } %t16, i32 %t9, 2
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t18, ptr %t19
  %t20 = load { i64, [4 x i64] }, ptr %t11
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t20, ptr %t22
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l16
  store ptr %t22, ptr %l17, !tbaa !29
  %t27 = ptrtoint ptr %v0 to i64
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3anarrowed_2e5
  br i1 %t28, label %bb2, label %bb3
bb2:
  %t30 = call ptr @__olang_region_make(ptr %v0)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l21
  br label %bb4
bb4:
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 7
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/typed:Local" %t41, ptr %l25
  br label %bb5
bb5:
  %t42 = getelementptr %"compiler/typed:Local", ptr %l25, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  %t44 = icmp sge i64 1, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = icmp sle i64 1, 2305843009213693951
  br i1 %t46, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_da08e6a1bfd31b51_4c78ede106fe65fd)
  unreachable
bb8:
  %t48 = mul i64 1, 4
  %t49 = load i64, ptr %l18
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  %t52 = load i32, ptr %l26, !tbaa !23
  store i64 0, ptr %t53
  br label %fill.54
fill.54:
  %t57 = load i64, ptr %t53
  %t58 = icmp slt i64 %t57, 1
  br i1 %t58, label %fillb.55, label %filld.56
fillb.55:
  %t59 = getelementptr i32, ptr %t51, i64 %t57
  store i32 %t52, ptr %t59
  %t60 = add i64 %t57, 1
  store i64 %t60, ptr %t53
  br label %fill.54
filld.56:
  %t61 = insertvalue { i64, ptr } undef, i64 1, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t51, 1
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = load ptr, ptr %l15, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l16
  %t68 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowAt(ptr %v0, ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67, ptr %t68, { i64, ptr } %t62, i64 %t63, i64 %a3, i64 %a4)
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_da08e6a1bfd31b51_4c78ede106fe65fd)
  unreachable
bb10:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i64
  %l15 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/diagmsg:Msg"
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/diagmsg:Msg"
  %l31 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/diagmsg:Msg"
  %l72 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l89 = alloca i32
  %l92 = alloca i64
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i32
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t187 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l15, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb15
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t21, ptr %l23
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %s2, ptr %v0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, i64 1, i64 %t24)
  store %"compiler/diagmsg:Msg" %t26, ptr %l26
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l28, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l29
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %s3, ptr %v0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t29, ptr %l30
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l23
  %t32 = load %"compiler/diagmsg:Msg", ptr %l26
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store i64 %t33, ptr %l27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l29
  %t36 = load %"compiler/diagmsg:Msg", ptr %l30
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t34, %"compiler/source:Span" %t35, %"compiler/diagmsg:Msg" %t36)
  store i64 %t37, ptr %l31
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t42, %"compiler/source:Span" %t43)
  store ptr %t46, ptr %l36
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load ptr, ptr %l36, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t49, ptr %l38, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t57 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v2, ptr %t48, ptr %t53)
  store i32 %t57, ptr %l41
  br label %bb16
bb16:
  %t58 = load i32, ptr %l41, !tbaa !23
  store i32 %t58, ptr %l6, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v4, ptr %t59, ptr %a3, %"compiler/source:Span" %t61)
  store ptr %t65, ptr %l45
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l45, !tbaa !29
  store ptr %t66, ptr %l7, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t70 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t67)
  store i32 %t70, ptr %l48
  br label %bb18
bb18:
  %t71 = load i32, ptr %l48, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  %t72 = load i32, ptr %l6, !tbaa !23
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t76 = icmp eq i32 %t72, %t73
  br i1 %t76, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb21
bb20:
  %t78 = load i32, ptr %l8, !tbaa !23
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = icmp eq i32 %t78, %t79
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t85, %"compiler/source:Span" %t86)
  store ptr %t89, ptr %l58
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load ptr, ptr %l58, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l6, !tbaa !23
  %t95 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t95, ptr %l61
  br label %bb26
bb26:
  %t96 = load i1, ptr %l61, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l63, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l64, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 0
  %t104 = load ptr, ptr %t103, !tbaa !39
  %t106 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t104)
  store %"compiler/source:Span" %t106, ptr %l66
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l69
  br label %bb30
bb30:
  %t112 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t120 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %s5, ptr %v0, { i64, ptr } %t118)
  store %"compiler/diagmsg:Msg" %t120, ptr %l71
  br label %bb31
bb31:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l66
  %t123 = load %"compiler/diagmsg:Msg", ptr %l71
  %t124 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t121, %"compiler/source:Span" %t122, %"compiler/diagmsg:Msg" %t123)
  store i64 %t124, ptr %l72
  br label %bb32
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t125, %"compiler/source:Span" %t126)
  store ptr %t129, ptr %l75
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load ptr, ptr %l75, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l8, !tbaa !23
  %t133 = load i32, ptr %l6, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t131, i32 %t132, i32 %t133)
  store { i64, ptr } %t137, ptr %l79
  br label %bb35
bb35:
  %t138 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t143 = icmp eq i64 %t141, 0
  br i1 %t143, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %t145, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i32 %t147, ptr %l84
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t148 = mul i64 1, 4
  %t149 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 1, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t152 = load i32, ptr %l84, !tbaa !23
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 0
  store i32 %t152, ptr %t155, !tbaa !33
  %t156 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = load %"compiler/source:Span", ptr %l2
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t158, %"compiler/source:Span" %t159, i1 false)
  store i32 %t163, ptr %l89
  br label %bb40
bb40:
  %t164 = load i32, ptr %l89, !range !{i32 0, i32 4}
  store i32 %t164, ptr %l10
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 44
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t167)
  store i64 %t169, ptr %l92
  br label %bb41
bb41:
  %t170 = load i64, ptr %l92, !tbaa !24
  store i64 %t170, ptr %l11, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 44
  %t174 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t173, ptr %t174)
  br label %bb42
bb42:
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l96
  %t178 = load i32, ptr %l6, !tbaa !23
  store i32 %t178, ptr %l97, !tbaa !23
  store i32 20, ptr %l98
  %t179 = load i32, ptr %l10, !range !{i32 0, i32 4}
  store i32 %t179, ptr %l99
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 44
  %t183 = load i64, ptr %l11, !tbaa !24
  %t186 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l103
  br label %bb43
bb43:
  store { i64, [5 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 0
  store i64 9, ptr %t188
  %t189 = load %"compiler/source:Span", ptr %l96
  %t190 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t189, 0
  %t191 = load i32, ptr %l97, !tbaa !23
  %t192 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t190, i32 %t191, 1
  %t193 = load i32, ptr %l98, !range !{i32 0, i32 52}
  %t194 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t192, i32 %t193, 2
  %t195 = load i32, ptr %l99, !range !{i32 0, i32 4}
  %t196 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t194, i32 %t195, 3
  %t197 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t198 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t196, { i64, ptr } %t197, 4
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t198, ptr %t199
  %t200 = load { i64, [5 x i64] }, ptr %t187
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t200, ptr %t202
  call void @__olang_scope_close(ptr %s0)
  store ptr %t202, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedWrite(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/check:narrowed"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/check:narrowed"
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l45 = alloca %"compiler/diagmsg:Msg"
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 46
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %t7, i64 %a2)
  store i64 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store %"compiler/check:narrowed" %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load %"compiler/check:narrowed", ptr %l14
  store %"compiler/check:narrowed" %t15, ptr %l3
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i32, ptr %l21, !tbaa !23
  %t33 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t31, i32 %t32)
  store ptr %t33, ptr %l22
  br label %bb5
bb5:
  %t34 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t36, i64 %t35)
  store ptr %t38, ptr %l24
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l24, !tbaa !29
  store ptr %t39, ptr %l4, !tbaa !29
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/ast:CaseDecl", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t46, i32 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb10
bb9:
  %t54 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t56, i32 %t58)
  store { i64, ptr } %t61, ptr %l35
  br label %bb11
bb11:
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t70 = extractvalue { i64, ptr } %t62, 1
  %t71 = extractvalue { i64, ptr } %t62, 0
  %t72 = add i64 %t68, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t66, i64 %t67)
  %t75 = getelementptr i8, ptr %t74, i64 %t67
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 5
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t86 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathText(ptr %v0, ptr %v0, ptr %s0, ptr %t81, { i64, ptr } %t83)
  store { i64, ptr } %t86, ptr %l42
  br label %bb12
bb12:
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t93, { i64, ptr } %t94)
  store %"compiler/diagmsg:Msg" %t97, ptr %l45
  br label %bb13
bb13:
  %t98 = load ptr, ptr %l38, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l39
  %t100 = load %"compiler/diagmsg:Msg", ptr %l45
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t98, %"compiler/source:Span" %t99, %"compiler/diagmsg:Msg" %t100)
  store i64 %t101, ptr %l46
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca %"compiler/typed:Body"
  %rv = alloca i64
  %t34 = alloca %"compiler/typed:Body", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 18
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 18
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load i64, ptr %l5, !tbaa !24
  %t12 = trunc i64 %t10 to i32
  store i32 %t12, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l14
  store i32 %a2, ptr %l15, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 10
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t24, i64 %a3)
  store ptr %t28, ptr %l21
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = load i32, ptr %l13, !tbaa !23
  %t36 = load { i64, [2 x i64] }, ptr %l14
  %t37 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2ftyped_3aBody_2ector(ptr %t34, ptr %v0, i32 %t35, { i64, [2 x i64] } %t36, i32 %t37, i64 %t32, %"compiler/source:Span" %a4)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t34, i64 440, i1 false)
  br label %bb3
bb3:
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 440, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %l25, i64 440, i1 false)
  %t41 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Hb4635a51dd989c2102029bfb32ae3a2f(ptr %v0, ptr %v0, ptr %t41, ptr %t40)
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t45, i64 0)
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 21
  %t50 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  br label %bb6
bb6:
  %t53 = load i64, ptr %l5, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l41 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l69 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca ptr
  %t188 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l19
  br label %bb2
bb2:
  %t18 = load i64, ptr %l19, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l25
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f66b04275832bdf5_49261566e6ebbc09)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_959932aa8b846e4e_2c1999e37dfb1a2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = sext i32 %t88 to i64
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l54, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  store i64 %t94, ptr %l55, !tbaa !24
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sge i64 %t104, 0
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l58, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb16:
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = load i64, ptr %l59, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb18:
  %t115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = getelementptr i8, ptr %t116, i64 %t117
  %t120 = sub i64 %t118, %t117
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t126 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t122, { i64, ptr } %t123)
  %t127 = extractvalue { i32, i64 } %t126, 1
  %t128 = extractvalue { i32, i64 } %t126, 0
  store i32 %t128, ptr %l66
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb21, label %ok.130, !prof !99
ok.130:
  store i64 %t127, ptr %l65
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb20:
  %t131 = load i64, ptr %l65, !tbaa !24
  store i64 %t131, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t132 = load i64, ptr %l53, !tbaa !24
  store i64 %t132, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t133, 0
  br i1 %t135, label %bb24, label %bb25
bb24:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Func", ptr %t137, i32 0, i32 0
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb26
bb25:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l69, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 4
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  store i64 %a1, ptr %l80, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 10
  %t172 = load i64, ptr %l5, !tbaa !24
  %t175 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store ptr %t175, ptr %l86
  br label %bb27
bb27:
  %t176 = load ptr, ptr %l86, !tbaa !29
  %t178 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 4
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t187 = add i64 %t181, %t184
  store { i64, [3 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 0
  store i64 3, ptr %t189
  %t191 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t193 = insertvalue { i64, i64, i64 } %t191, i64 %t180, 1
  %t195 = insertvalue { i64, i64, i64 } %t193, i64 %t187, 2
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  store { i64, i64, i64 } %t195, ptr %t196
  %t197 = load { i64, [3 x i64] }, ptr %t188
  %t199 = load ptr, ptr %l79, !tbaa !29
  %t200 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %t199, i64 %t200, { i64, [3 x i64] } %t197, %"compiler/diagmsg:Msg" %a3)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonce(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l37 = alloca i64
  %l49 = alloca ptr
  %rv = alloca ptr
  %t78 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb6:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 2
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  store %"compiler/source:Span" %t40, ptr %l3
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l4, !tbaa !23
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t50, i32 0, i32 2
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l5, !tbaa !23
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9e3e60c51c241998_753bf57c496fa07c)
  unreachable
bb22:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l31
  br label %bb23
bb23:
  %t59 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t59, ptr %l6
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t61, ptr %l33
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t65 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t62)
  store i32 %t65, ptr %l36
  br label %bb24
bb24:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l33
  %t68 = load i32, ptr %l36, !tbaa !23
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store i64 %t69, ptr %l37
  br label %bb25
bb25:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l6
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  %t77 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t81 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } %t81, i32 %t75, 1
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, ptr %t77, 2
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t78
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t87, ptr %t89
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t71, ptr %t89)
  br label %bb26
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l6
  %t94 = load i64, ptr %l7, !tbaa !24
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t92, %"compiler/source:Span" %t93, i64 %t94)
  store ptr %t98, ptr %l49
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l49, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/generic:Origin" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorigin(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca %"compiler/generic:Origin"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Origin"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l6
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load %"compiler/source:Span", ptr %l6
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = call %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %s0, i64 %t15, %"compiler/source:Span" %t16, i64 %t17, i32 %t18)
  store %"compiler/generic:Origin" %t19, ptr %l11
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/generic:Origin", ptr %l11
  store %"compiler/generic:Origin" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Origin", ptr %rv
  ret %"compiler/generic:Origin" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/check:litv"
  %l7 = alloca %"compiler/check:litv"
  %l8 = alloca { ptr, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l34 = alloca %"compiler/check:litv"
  %l38 = alloca %"compiler/check:litv"
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l17, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 28}
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 113}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t51 = trunc i64 71 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t60 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store %"compiler/check:litv" %t60, ptr %l34
  br label %bb16
bb16:
  %t61 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t61, ptr %l6
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t67 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store %"compiler/check:litv" %t67, ptr %l38
  br label %bb17
bb17:
  %t68 = load %"compiler/check:litv", ptr %l38
  store %"compiler/check:litv" %t68, ptr %l7
  %t69 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_39, 0
  %t70 = insertvalue { ptr, ptr } %t69, ptr null, 1
  store { ptr, ptr } %t70, ptr %l8
  %t72 = load { ptr, ptr }, ptr %l8
  %t73 = load %"compiler/check:litv", ptr %l6
  %t75 = extractvalue { ptr, ptr } %t72, 0
  %t76 = extractvalue { ptr, ptr } %t72, 1
  %t78 = call i1 %t75(ptr %t76, %"compiler/check:litv" %t73)
  store i1 %t78, ptr %l42
  br label %bb18
bb18:
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t80 = load { ptr, ptr }, ptr %l8
  %t81 = load %"compiler/check:litv", ptr %l7
  %t83 = extractvalue { ptr, ptr } %t80, 0
  %t84 = extractvalue { ptr, ptr } %t80, 1
  %t86 = call i1 %t83(ptr %t84, %"compiler/check:litv" %t81)
  store i1 %t86, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i1, ptr %l43, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_2c067c0920238e9c_6231d620e5a2e328)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l5 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l16 = alloca i64
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i32
  %l34 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t57 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t10)
  store i32 %t13, ptr %l11
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t14, i32 %t15, i64 0)
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t16)
  store %"compiler/source:Span" %t18, ptr %l13
  br label %bb7
bb7:
  %t19 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t19, ptr %l2
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 44
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 44
  %t29 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  br label %bb9
bb9:
  %t32 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t32, ptr %l20
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t33)
  store i32 %t36, ptr %l23
  br label %bb10
bb10:
  store i32 4, ptr %l24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 44
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store { i64, ptr } %t43, ptr %l28
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l2
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t44, i32 1, %"compiler/source:Span" %t45)
  store i32 %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = load i32, ptr %l24, !range !{i32 0, i32 5}
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = load i32, ptr %l32, !tbaa !23
  %t54 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v2, ptr %v2, i32 %t50, i64 0, { i64, ptr } %t51, ptr null, i32 %t52, i32 0, i1 false)
  store %"compiler/typed:Make" %t54, ptr %l34
  br label %bb13
bb13:
  %t55 = load %"compiler/typed:Make", ptr %l34
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t55, ptr %t56
  store { i64, [5 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 0
  store i64 7, ptr %t58
  %t59 = load %"compiler/source:Span", ptr %l20
  %t60 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t59, 0
  %t61 = load i32, ptr %l23, !tbaa !23
  %t62 = insertvalue { %"compiler/source:Span", i32, ptr } %t60, i32 %t61, 1
  %t64 = insertvalue { %"compiler/source:Span", i32, ptr } %t62, ptr %t56, 2
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t64, ptr %t65
  %t66 = load { i64, [5 x i64] }, ptr %t57
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t66, ptr %t68
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplacement(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca i1
  %l47 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %l69 = alloca i32
  %l75 = alloca i32
  %l79 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i32
  %l95 = alloca i64
  %l100 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l119 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l140 = alloca i32
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca %"compiler/diagmsg:Msg"
  %l151 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %t10, i32 0, i32 7
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Func", ptr %t15, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Sig", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp ne i64 %t23, 1
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb8
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load i1, ptr %l28, !tbaa !21
  store i1 %t36, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l32
  br label %bb12
bb12:
  %t46 = load i64, ptr %l32, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t56, ptr %l37
  br label %bb14
bb14:
  %t57 = load i1, ptr %l37, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 12
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = icmp eq i64 %t58, %t68
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t73 = load i1, ptr %l38, !tbaa !21
  br i1 %t73, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = call %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %t77)
  store %"compiler/source:Span" %t79, ptr %l47
  br label %bb21
bb21:
  %t80 = getelementptr %"compiler/source:Span", ptr %l47, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = icmp sge i32 %t81, 0
  br i1 %t83, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t92 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t88, i64 %t89)
  store i32 %t92, ptr %l53
  br label %bb25
bb25:
  %t93 = load i32, ptr %l53, !tbaa !23
  store i32 %t93, ptr %l4, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l56, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l57, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l4, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l62
  br label %bb26
bb26:
  %t111 = load ptr, ptr %l57, !tbaa !29
  %t112 = load i32, ptr %l62, !tbaa !23
  %t113 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t113, ptr %l63
  br label %bb27
bb27:
  %t114 = load ptr, ptr %l56, !tbaa !29
  %t115 = load i32, ptr %l63, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l64
  br label %bb28
bb28:
  %t117 = load i32, ptr %l64, !tbaa !23
  store i32 %t117, ptr %l5, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %l5, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l69
  br label %bb29
bb29:
  %t128 = load i32, ptr %l69, !range !{i32 0, i32 33}
  %t130 = trunc i64 18 to i32
  %t131 = icmp eq i32 %t128, %t130
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l5, !tbaa !23
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l75
  br label %bb33
bb33:
  %t140 = load i32, ptr %l75, !range !{i32 0, i32 6}
  store i32 %t140, ptr %l6
  %t141 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t143 = trunc i64 0 to i32
  %t144 = icmp eq i32 %t141, %t143
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb34, label %bb35
bb34:
  %t148 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t150 = trunc i64 1 to i32
  %t151 = icmp eq i32 %t148, %t150
  %t153 = xor i1 %t151, true
  store i1 %t153, ptr %l79, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb36
bb36:
  %t155 = load i1, ptr %l79, !tbaa !21
  br i1 %t155, label %bb37, label %bb38
bb37:
  %t156 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t158 = trunc i64 4 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l83, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb39
bb39:
  %t163 = load i1, ptr %l83, !tbaa !21
  br i1 %t163, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  br label %bb42
bb42:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t169, i32 %t170)
  store i32 %t173, ptr %l91
  br label %bb43
bb43:
  %t174 = load i32, ptr %l91, !tbaa !23
  store i32 %t174, ptr %l7, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i32, ptr %l7, !tbaa !23
  %t182 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t178, i32 %t179)
  store i64 %t182, ptr %l95
  br label %bb44
bb44:
  %t183 = load i64, ptr %l3, !tbaa !24
  %t184 = load i64, ptr %l95, !tbaa !24
  %t186 = icmp ne i64 %t184, %t183
  br i1 %t186, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  br label %bb47
bb47:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  store ptr %t193, ptr %l100, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t200 = load i32, ptr %l4, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t203, ptr %l105
  br label %bb48
bb48:
  %t204 = load ptr, ptr %l100, !tbaa !29
  %t205 = load i32, ptr %l105, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t204, i32 %t205)
  store { i64, ptr } %t206, ptr %l106
  br label %bb49
bb49:
  %t207 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t207, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  store i64 %t210, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  %t212 = load i64, ptr %l9, !tbaa !24
  %t213 = load i64, ptr %l10, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t220 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t220, ptr %l113, !tbaa !27
  %t221 = load i64, ptr %l9, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i32, ptr %t224, i64 %t221
  %t226 = load i32, ptr %t225, !tbaa !33
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l5, !tbaa !23
  %t234 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t228, i32 %t226, i32 %t230, i64 0)
  store i1 %t234, ptr %l119
  br label %bb54
bb54:
  %t235 = load i1, ptr %l119, !tbaa !21
  br i1 %t235, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t236 = load i64, ptr %l9, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l9, !tbaa !24
  br label %bb50
bb59:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i64, ptr %l3, !tbaa !24
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t240, i64 -1, i64 %t241, i32 %t242, i32 0)
  store ptr %t246, ptr %l125
  br label %bb60
bb60:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l126, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t252 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t248, ptr %t249)
  store %"compiler/source:Span" %t252, ptr %l129
  br label %bb61
bb61:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l2, !tbaa !29
  %t256 = getelementptr %"compiler/ast:Func", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %t256, !tbaa !23
  %t260 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t253, i32 %t257)
  store { i64, ptr } %t260, ptr %l133
  br label %bb62
bb62:
  %t261 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  store { i64, ptr } %t267, ptr %l134, !tbaa !27
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l135, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  %t275 = load i32, ptr %l7, !tbaa !23
  %t278 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t274, i32 %t275)
  store i32 %t278, ptr %l140
  br label %bb63
bb63:
  %t279 = load ptr, ptr %l135, !tbaa !29
  %t280 = load i32, ptr %l140, !tbaa !23
  %t281 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t279, i32 %t280)
  store { i64, ptr } %t281, ptr %l141
  br label %bb64
bb64:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l5, !tbaa !23
  %t286 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t282, i32 %t283)
  store { i64, ptr } %t286, ptr %l144
  br label %bb65
bb65:
  %t287 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  %t289 = extractvalue { i64, ptr } %t287, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  store { i64, ptr } %t293, ptr %l145, !tbaa !27
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l2, !tbaa !29
  %t297 = getelementptr %"compiler/ast:Func", ptr %t295, i32 0, i32 2
  %t298 = load i32, ptr %t297, !tbaa !23
  %t301 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t294, i32 %t298)
  store { i64, ptr } %t301, ptr %l149
  br label %bb66
bb66:
  %t302 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t305 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t306 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderExpected(ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t302, { i64, ptr } %t303, { i64, ptr } %t304, { i64, ptr } %t305)
  store %"compiler/diagmsg:Msg" %t306, ptr %l150
  br label %bb67
bb67:
  %t307 = load ptr, ptr %l126, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l129
  %t309 = load %"compiler/diagmsg:Msg", ptr %l150
  %t310 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t307, %"compiler/source:Span" %t308, %"compiler/diagmsg:Msg" %t309)
  store i64 %t310, ptr %l151
  br label %bb68
bb68:
  %t311 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t311)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l8 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsLength(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i32 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i32 %t12, ptr %l8
  br label %bb5
bb5:
  %t13 = load i32, ptr %l8, !tbaa !23
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflRendered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"compiler/check:reflVal"
  %l5 = alloca %"compiler/check:reflVal"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  store %"compiler/check:reflVal" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/check:reflVal", ptr %l5
  store %"compiler/check:reflVal" %t6, ptr %l2
  %t7 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t19 = icmp eq i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t38, 1
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t51 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t50)
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t48)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @__olang_scope_close(ptr %s0)
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t54, 1
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t57 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t62 = icmp eq i64 %t58, %t59
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp eq i64 %t65, 1
  br i1 %t67, label %bb13, label %bb14
bb12:
  br label %bb16
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t69, ptr %l26, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l26, !tbaa !27
  br label %bb15
bb15:
  %t73 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l31, !tbaa !24
  %t75 = load i64, ptr %l31, !tbaa !24
  %t76 = mul i64 %t75, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l32, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l31, !tbaa !24
  %t85 = mul i64 %t84, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t81, ptr %t83, i64 %t85, i1 false)
  %t86 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t86, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t88 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t87, 1
  store { i32, { i64, ptr } } %t88, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t90 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t5, i32 %t6)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i1, ptr %l9, !tbaa !21
  store i1 %t12, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t14 = load i32, ptr %l2, !tbaa !23
  %t16 = icmp sge i32 %t14, 0
  br i1 %t16, label %bb9, label %bb10
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l13
  br label %bb11
bb10:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l19
  br label %bb13
bb11:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 4
  %t27 = getelementptr %"compiler/generic:Context", ptr %t26, i32 0, i32 3
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t27, i32 %t28, i32 %t29)
  br label %bb12
bb12:
  br label %bb15
bb13:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 4
  %t36 = getelementptr %"compiler/generic:Context", ptr %t35, i32 0, i32 3
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H2c4b9eb360b9a0ada2008890a467b28d(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l23
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/check:Ask"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/check:AssertAsk"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca %"compiler/check:Ask"
  %l50 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l94 = alloca %"compiler/check:AssertAsk"
  %l98 = alloca i1
  %l103 = alloca %"compiler/check:AssertAsk"
  %t154 = alloca %"compiler/check:AssertAsk", align 8
  %t175 = alloca %"compiler/check:AssertAsk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 117
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 117
  %t59 = call %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t51)
  store %"compiler/check:Ask" %t59, ptr %l46
  br label %bb12
bb12:
  %t60 = load %"compiler/check:Ask", ptr %l46
  store %"compiler/check:Ask" %t60, ptr %l8
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 4
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 5
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t61, i64 %t63, { i64, ptr } %t65)
  store i1 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i1, ptr %l50, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v0, ptr %t71, ptr %t73)
  br label %bb16
bb15:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 117
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load %"compiler/check:Ask", ptr %l8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79, %"compiler/check:Ask" %t80)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l1, !tbaa !24
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb8
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 117
  %t95 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t94, i64 %t95)
  br label %bb21
bb21:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 119
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l66
  br label %bb22
bb22:
  %t103 = load i64, ptr %l66, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t110 = load i64, ptr %l11, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb28
bb25:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l73, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t130 = load i64, ptr %l73, !tbaa !24
  store i64 %t130, ptr %l70, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l70, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 119
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %t154, ptr %v0, ptr %v0, ptr %t152, i64 %t148)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t154, i64 184, i1 false)
  br label %bb33
bb33:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l94, i64 184, i1 false)
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 0
  %t159 = load i64, ptr %t158, !tbaa !24
  %t160 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 10
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t157, i64 %t159, { i64, ptr } %t161)
  store i1 %t165, ptr %l98
  br label %bb34
bb34:
  %t166 = load i1, ptr %l98, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 119
  %t172 = load i64, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l103, ptr %l15, i64 184, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %l103, i64 184, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eSetA_H2f2d9e3b51ec05f25dc2320ca6b31566(ptr %v0, ptr %v0, ptr %t171, i64 %t172, ptr %t175)
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t176 = load i64, ptr %l1, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l1, !tbaa !24
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 119
  %t187 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eTrun_Heefffe1e944651b1941f34d83e014b00(ptr %v0, ptr %t186, i64 %t187)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etakenSet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/typed:Item"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca i32
  %l47 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i64
  %l56 = alloca %"compiler/typed:Item"
  %l66 = alloca i1
  %l71 = alloca i64
  %l72 = alloca i64
  %l76 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb46
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t17, ptr %l23, !tbaa !27
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  store i32 %t23, ptr %l9, !tbaa !23
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i32, ptr %l9, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l29, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb45
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l9, !tbaa !23
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v3, ptr %t38, i32 %t39, ptr %a4)
  store i32 %t44, ptr %l36
  br label %bb12
bb12:
  %t45 = load i32, ptr %l36, !tbaa !23
  store i32 %t45, ptr %l10, !tbaa !23
  %t46 = load i32, ptr %l10, !tbaa !23
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t50 = icmp eq i32 %t46, %t47
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb45
bb14:
  br label %bb15
bb15:
  br i1 %a3, label %bb16, label %bb17
bb16:
  %t54 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t54)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb45
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l10, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l47
  br label %bb20
bb20:
  %t67 = load i32, ptr %l47, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  store ptr %a2, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t70 = load i64, ptr %l13, !tbaa !24
  store i64 %t70, ptr %l49, !tbaa !24
  %t71 = load ptr, ptr %l12, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t71)
  store i64 %t73, ptr %l51
  br label %bb22
bb22:
  %t74 = load i64, ptr %l49, !tbaa !24
  %t75 = load i64, ptr %l51, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb23, label %bb24
bb23:
  br label %bb44
bb24:
  br label %bb25
bb25:
  %t80 = load ptr, ptr %l12, !tbaa !29
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t80, i64 %t81)
  store %"compiler/typed:Item" %t84, ptr %l56
  br label %bb26
bb26:
  %t85 = load %"compiler/typed:Item", ptr %l56
  store %"compiler/typed:Item" %t85, ptr %l14
  %t86 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = load i32, ptr %l11, !tbaa !23
  %t91 = icmp ne i32 %t87, %t88
  br i1 %t91, label %bb27, label %bb28
bb27:
  br label %bb43
bb28:
  br label %bb29
bb29:
  %t93 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t98 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t98)
  br label %bb32
bb31:
  %t101 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = icmp slt i64 %t102, 64
  br i1 %t104, label %bb33, label %bb34
bb32:
  br label %bb42
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l10, !tbaa !23
  %t115 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t111, i32 %t112)
  store i64 %t115, ptr %l71
  br label %bb35
bb34:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t116 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  store i64 %t117, ptr %l72, !tbaa !24
  %t118 = load i64, ptr %l72, !tbaa !24
  %t119 = load i64, ptr %l72, !tbaa !24
  %t120 = shl i64 1, %t119
  %t121 = load i64, ptr %l71, !tbaa !65
  %t123 = and i64 %t121, %t120
  %t125 = icmp ne i64 %t123, 0
  store i1 %t125, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t127 = load i1, ptr %l66, !tbaa !21
  br i1 %t127, label %bb37, label %bb38
bb37:
  store ptr %l5, ptr %l76, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l11, !tbaa !23
  %t135 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l81, !tbaa !24
  %t138 = load i64, ptr %l81, !tbaa !24
  %t139 = shl i64 1, %t138
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t133, i32 %t134, i64 %t139)
  store i32 %t143, ptr %l83
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t145 = load i32, ptr %l83, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t144, i32 %t145)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l13, !tbaa !24
  br label %bb21
bb44:
  br label %bb45
bb45:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l7, !tbaa !24
  br label %bb2
bb46:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l88, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l89, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t159 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %s0, ptr %t156, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l92
  br label %bb47
bb47:
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t161 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %t161
  %t162 = load ptr, ptr %l89, !tbaa !29
  %t164 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %s0, ptr %s0, ptr %t162, ptr %t161)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l94
  br label %bb48
bb48:
  %t165 = load ptr, ptr %l88, !tbaa !29
  %t167 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t165, ptr %l94)
  store i32 %t167, ptr %l96
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t168 = load i32, ptr %l96, !tbaa !23
  store i32 %t168, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etargetHoldsRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l14
  br label %bb6
bb6:
  %t26 = load i1, ptr %l14, !tbaa !21
  store i1 %t26, ptr %l3, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5f447d0cb8af3524_fdbf87197f7ceb70)
  unreachable
bb12:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOperand(ptr %v0, ptr %v1, ptr %v2, ptr %v5, ptr %t5, ptr %a2, ptr %a3, ptr %t8)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOperand(ptr %v0, ptr %v3, ptr %v4, ptr %v5, ptr %t13, ptr %a4, ptr %a5, ptr %t16)
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOf(ptr %v0, ptr %v5, ptr %v5, ptr %t21, %"compiler/source:Span" %a1, ptr %t23)
  store ptr %t27, ptr %l20
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l20, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etotalsReport(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l2 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l5 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l8 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l9 = alloca i32
  %l11 = alloca i1
  %l13 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l17 = alloca i32
  %l19 = alloca i1
  %s2 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 51
  %t5 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_Ha2532e1d68e811abb948a2d41b0a02a3(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l5
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_2c_2_H2299030e35d289e69d6656a10d43050e(ptr %v0, ptr %s2, ptr %l1)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t9, ptr %l8
  br label %bb3
bb3:
  %t14 = call %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext__Hfb2c811c78810c6f5b3ad7447b9f8624(ptr %s2, ptr %l8)
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t14, ptr %l13
  br label %bb6
bb4:
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb6:
  %t19 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l13
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t19, ptr %l6
  br label %bb7
bb7:
  %t20 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l6
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t20, ptr %l2
  %t21 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l2, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l2, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t28 = extractvalue { i64, ptr } %t22, 1
  %t29 = extractvalue { i64, ptr } %t22, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %t24, 1
  %t36 = extractvalue { i64, ptr } %t24, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t25, i64 %t26)
  %t39 = getelementptr i8, ptr %t38, i64 %t26
  call void @olang_textcopy(ptr %t39, ptr %t28, i64 %t29)
  %t40 = getelementptr i8, ptr %t39, i64 %t29
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t38, 1
  %t45 = call i32 @std_2fio_2ePutErrLn_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t43)
  store i32 %t45, ptr %l17
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb9, label %ok.47, !prof !99
ok.47:
  br label %bb8
bb8:
  br label %bb13
bb9:
  %t48 = load i32, ptr %l17, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  store i1 %t51, ptr %l19, !tbaa !21
  %t52 = load i32, ptr %l17, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca %"compiler/generic:Context"
  %l49 = alloca %"compiler/generic:Context"
  %l58 = alloca { i64, ptr }
  %l64 = alloca i1
  %l70 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i32
  %l78 = alloca { i64, ptr }
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca %"compiler/diagmsg:Msg"
  %l84 = alloca i64
  %l87 = alloca i1
  %l95 = alloca i1
  %s6 = alloca %olang.scope
  %t79 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l13, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t19 = load ptr, ptr %l19, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l19, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb49
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t33, i64 -1, i64 %t34, i32 %t35, i32 0)
  store ptr %t39, ptr %l28
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l28, !tbaa !29
  store ptr %t40, ptr %l5, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 0
  %t49 = load i32, ptr %t48, !tbaa !23
  %t53 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t44, i64 %t45, i32 %t49)
  store i64 %t53, ptr %l34
  br label %bb13
bb13:
  %t54 = load i64, ptr %l34, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l5, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = ptrtoint ptr %v0 to i64
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t61, label %bb16, label %bb17
bb15:
  br label %bb24
bb16:
  %t63 = call ptr @__olang_region_make(ptr %v0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l41, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t78 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t72, i64 %t73, i64 %t74)
  store i32 %t78, ptr %l46
  br label %bb18
bb18:
  %t80 = load i64, ptr %l38
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i32, ptr %l46, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t79, ptr %v0, ptr %t81, ptr %t82, i32 %t83)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t79, i64 160, i1 false)
  br label %bb19
bb19:
  %t84 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l38
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 3
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 2
  %t90 = load { i64, ptr }, ptr %t89
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = call ptr @__olang_region_or(ptr %t91, ptr null)
  %t93 = call ptr @__olang_region_home(ptr %t92)
  %t94 = icmp ne ptr %t93, null
  %t95 = select i1 %t94, ptr %t93, ptr null
  %t96 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 3
  %t97 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t96, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = call ptr @__olang_region_home(ptr %t100)
  %t102 = icmp ne ptr %t101, null
  %t103 = select i1 %t102, ptr %t101, ptr %t95
  %t104 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 3
  %t105 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t104, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = call ptr @__olang_region_or(ptr %t107, ptr null)
  %t109 = call ptr @__olang_region_home(ptr %t108)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr %t103
  %t112 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 2
  %t113 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 2
  %t114 = load { i64, ptr }, ptr %t113
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = call ptr @__olang_region_or(ptr %t115, ptr null)
  %t117 = call ptr @__olang_region_home(ptr %t116)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr %t111
  %t120 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 2
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t120, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr %t119
  %t128 = getelementptr %"compiler/generic:Context", ptr %l47, i32 0, i32 2
  %t129 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t128, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = call ptr @__olang_region_or(ptr %t131, ptr null)
  %t133 = call ptr @__olang_region_home(ptr %t132)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr %t127
  %t136 = icmp eq ptr %t135, %t87
  call void @__olang_region_settle(ptr %t87, i1 %t136)
  br label %bb21
bb21:
  %t137 = load ptr, ptr %l37, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t138, i64 160, i1 false)
  %t139 = load ptr, ptr %l37, !tbaa !29
  %t140 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %l47, i64 160, i1 false)
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t141, label %bb22, label %bb23
bb22:
  %t143 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t144 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_region_or(ptr %t146, ptr null)
  %t148 = call ptr @__olang_region_home(ptr %t147)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  %t151 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t152 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t151, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = call ptr @__olang_region_or(ptr %t154, ptr null)
  %t156 = call ptr @__olang_region_home(ptr %t155)
  %t157 = icmp ne ptr %t156, null
  %t158 = select i1 %t157, ptr %t156, ptr %t150
  %t159 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 3
  %t160 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t159, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = call ptr @__olang_region_or(ptr %t162, ptr null)
  %t164 = call ptr @__olang_region_home(ptr %t163)
  %t165 = icmp ne ptr %t164, null
  %t166 = select i1 %t165, ptr %t164, ptr %t158
  %t167 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = call ptr @__olang_region_home(ptr %t171)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr %t166
  %t175 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t176 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t175, i32 0, i32 1
  %t177 = load { i64, ptr }, ptr %t176
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = call ptr @__olang_region_or(ptr %t178, ptr null)
  %t180 = call ptr @__olang_region_home(ptr %t179)
  %t181 = icmp ne ptr %t180, null
  %t182 = select i1 %t181, ptr %t180, ptr %t174
  %t183 = getelementptr %"compiler/generic:Context", ptr %l49, i32 0, i32 2
  %t184 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t183, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = call ptr @__olang_region_or(ptr %t186, ptr null)
  %t188 = call ptr @__olang_region_home(ptr %t187)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr %t182
  call void @__olang_region_drop(ptr %t190)
  store %"compiler/generic:Context" zeroinitializer, ptr %l49
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t191 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t191, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  %t197 = load i64, ptr %l8, !tbaa !24
  %t198 = load i64, ptr %l9, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb26, label %bb27
bb26:
  br label %bb47
bb27:
  br label %bb28
bb28:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l58, !tbaa !27
  %t206 = load i64, ptr %l8, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  store ptr %t211, ptr %l10, !tbaa !29
  %t213 = load ptr, ptr %l10, !tbaa !29
  %t215 = getelementptr %"compiler/ast:Func", ptr %t213, i32 0, i32 3
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/ast:Sig", ptr %t216, i32 0, i32 2
  %t219 = load i1, ptr %t218, !tbaa !21
  br i1 %t219, label %bb29, label %bb30
bb29:
  %t221 = load ptr, ptr %l10, !tbaa !29
  %t223 = getelementptr %"compiler/ast:Func", ptr %t221, i32 0, i32 3
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/ast:Sig", ptr %t224, i32 0, i32 3
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t231 = icmp eq i64 %t229, 0
  store i1 %t231, ptr %l64, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb31
bb31:
  %t233 = load i1, ptr %l64, !tbaa !21
  br i1 %t233, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l70, !tbaa !29
  %t235 = load ptr, ptr %l10, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Func", ptr %t235, i32 0, i32 0
  %t238 = getelementptr %"compiler/source:Span", ptr %t237, i32 0, i32 0
  %t239 = load i32, ptr %t238, !tbaa !23
  store i32 %t239, ptr %l72, !tbaa !23
  %t240 = load ptr, ptr %l10, !tbaa !29
  %t242 = getelementptr %"compiler/ast:Func", ptr %t240, i32 0, i32 0
  %t243 = getelementptr %"compiler/source:Span", ptr %t242, i32 0, i32 0
  %t244 = load i32, ptr %t243, !tbaa !23
  store i32 %t244, ptr %l74, !tbaa !23
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l10, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Func", ptr %t246, i32 0, i32 2
  %t249 = load i32, ptr %t248, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t245, i32 %t249)
  store { i64, ptr } %t252, ptr %l78
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t253 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t256 = trunc i64 %t254 to i32
  %t257 = load i32, ptr %l74, !tbaa !23
  %t259 = add i32 %t257, %t256
  %t260 = load i32, ptr %l72, !tbaa !23
  %t262 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t260, i32 %t259)
  store %"compiler/source:Span" %t262, ptr %l82
  br label %bb35
bb35:
  %t263 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
  store %"compiler/diagmsg:Msg" %t263, ptr %l83
  br label %bb36
bb36:
  %t264 = load ptr, ptr %l70, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l82
  %t266 = load %"compiler/diagmsg:Msg", ptr %l83
  %t267 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t264, %"compiler/source:Span" %t265, %"compiler/diagmsg:Msg" %t266)
  store i64 %t267, ptr %l84
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t268 = load i64, ptr %l6, !tbaa !24
  %t270 = icmp sge i64 %t268, 0
  br i1 %t270, label %bb39, label %bb40
bb39:
  %t272 = load ptr, ptr %l10, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Func", ptr %t272, i32 0, i32 5
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t279 = icmp eq i64 %t277, 0
  store i1 %t279, ptr %l87, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb41
bb41:
  %t281 = load i1, ptr %l87, !tbaa !21
  br i1 %t281, label %bb42, label %bb43
bb42:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load ptr, ptr %l10, !tbaa !29
  %t285 = getelementptr %"compiler/ast:Func", ptr %t283, i32 0, i32 3
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t289 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigWritten(ptr %v0, ptr %v1, ptr %t282, ptr %t286)
  store i1 %t289, ptr %l95
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t290 = load i64, ptr %l8, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l8, !tbaa !24
  br label %bb25
bb47:
  %t294 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t294)
  br label %bb48
bb48:
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_cc3b7a6e318210b6_464c855cb4a991aa)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/generic:Context"
  %l6 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l8 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l9 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:typeCase"
  %l27 = alloca %"compiler/check:typeCase"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l46 = alloca %"compiler/generic:Context"
  %l49 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l50 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l52 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l53 = alloca i32
  %l55 = alloca i1
  %l61 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l62 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l64 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l65 = alloca i32
  %l67 = alloca i1
  %l72 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca i32
  %l107 = alloca i32
  %l115 = alloca i32
  %l121 = alloca i32
  %l124 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i64
  %l140 = alloca i64
  %l143 = alloca i64
  %l161 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca i64
  %l171 = alloca i32
  %l175 = alloca ptr
  %l176 = alloca i32
  %l181 = alloca i32
  %l182 = alloca i32
  %l185 = alloca i1
  %l186 = alloca i32
  %l188 = alloca i64
  %l191 = alloca %"compiler/check:typeCase"
  %l200 = alloca i32
  %l202 = alloca %"compiler/check:typeCase"
  %l205 = alloca i1
  %l206 = alloca i32
  %l208 = alloca i64
  %l209 = alloca %"compiler/check:typeCase"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca %"compiler/check:typeCase"
  %t37 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l28
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4, ptr %l2, i1 false)
  br label %bb2
bb2:
  %t9 = shl i64 1, 40
  %t11 = sub i64 0, %t9
  store i64 %t11, ptr %l34, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l36
  br label %bb3
bb3:
  %t15 = getelementptr %"compiler/source:Span", ptr %l36, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = load i64, ptr %l34, !tbaa !24
  %t21 = sub i64 %t19, %t18
  store i64 %t21, ptr %l3, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l41
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l41, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 4
  %t30 = getelementptr %"compiler/generic:Context", ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 4
  %t35 = getelementptr %"compiler/generic:Context", ptr %t34, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t37, ptr %s0, i64 %t31, i64 %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t37, i64 160, i1 false)
  br label %bb5
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l46, i64 160, i1 false)
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 4
  %t43 = getelementptr %"compiler/generic:Context", ptr %t42, i32 0, i32 2
  %t45 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t43)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t45, ptr %l49
  br label %bb6
bb6:
  %t46 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l49
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t46, ptr %l6
  br label %bb7
bb7:
  %t48 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l6)
  %t49 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t48, 1
  %t50 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t48, 0
  store i32 %t50, ptr %l53
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb9, label %ok.52, !prof !99
ok.52:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t49, ptr %l52
  br label %bb8
bb8:
  %t53 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l52
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t53, ptr %l50
  br label %bb11
bb9:
  %t54 = load i32, ptr %l53, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l55, !tbaa !21
  br label %bb10
bb10:
  br label %bb14
bb11:
  %t58 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l50
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t58, ptr %l7
  %t59 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  %t60 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t59, i32 %t61, i32 %t63)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb7
bb14:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 4
  %t70 = getelementptr %"compiler/generic:Context", ptr %t69, i32 0, i32 3
  %t72 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t70)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t72, ptr %l61
  br label %bb15
bb15:
  %t73 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l61
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t73, ptr %l8
  br label %bb16
bb16:
  %t75 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l8)
  %t76 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 1
  %t77 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t75, 0
  store i32 %t77, ptr %l65
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb18, label %ok.79, !prof !99
ok.79:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t76, ptr %l64
  br label %bb17
bb17:
  %t80 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l64
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t80, ptr %l62
  br label %bb20
bb18:
  %t81 = load i32, ptr %l65, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l67, !tbaa !21
  br label %bb19
bb19:
  br label %bb23
bb20:
  %t85 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l62
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t85, ptr %l9
  %t86 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 3
  %t87 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t86, i32 %t88, i32 %t90)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb16
bb23:
  store i64 0, ptr %l10, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t95, ptr %l72
  br label %bb24
bb24:
  %t96 = load i64, ptr %l72, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb30
bb27:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l79, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb29
bb29:
  %t123 = load i64, ptr %l79, !tbaa !24
  store i64 %t123, ptr %l76, !tbaa !24
  br label %bb30
bb30:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb32, label %bb33
bb32:
  br label %bb39
bb33:
  br label %bb34
bb34:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l15, !tbaa !24
  %t143 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  store ptr %t143, ptr %l97, !tbaa !29
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2, i64 %t144)
  store i32 %t147, ptr %l100
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i64, ptr %l3, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t153, i64 %t154, i64 %t155, i64 %t156)
  store i32 %t161, ptr %l107
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l97, !tbaa !29
  %t163 = load i32, ptr %l100, !tbaa !23
  %t164 = load i32, ptr %l107, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t162, i32 %t163, i32 %t164)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l14, !tbaa !24
  br label %bb31
bb39:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t178 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v1, ptr %t172, ptr %l5, ptr %t173)
  store i32 %t178, ptr %l115
  br label %bb40
bb40:
  %t179 = load i32, ptr %l115, !tbaa !23
  store i32 %t179, ptr %l16, !tbaa !23
  %t180 = load i32, ptr %l16, !tbaa !23
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t184 = icmp eq i32 %t180, %t181
  br i1 %t184, label %bb41, label %bb42
bb41:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t190 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebareDecl(ptr %v0, ptr %v1, ptr %t186, ptr %t187)
  store i32 %t190, ptr %l121
  br label %bb43
bb42:
  br label %bb74
bb43:
  %t191 = load i32, ptr %l121, !tbaa !23
  store i32 %t191, ptr %l17, !tbaa !23
  %t192 = load i32, ptr %l17, !tbaa !23
  %t194 = icmp sge i32 %t192, 0
  br i1 %t194, label %bb44, label %bb45
bb44:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l17, !tbaa !23
  %t205 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t201, i32 %t202)
  store i64 %t205, ptr %l129
  br label %bb46
bb45:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb47
bb46:
  %t206 = load i64, ptr %l129, !tbaa !24
  store i64 %t206, ptr %l124, !tbaa !24
  br label %bb47
bb47:
  %t207 = load i64, ptr %l124, !tbaa !24
  store i64 %t207, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l18, !tbaa !24
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t212 = load i64, ptr %l18, !tbaa !24
  store i64 %t212, ptr %l132, !tbaa !24
  %t213 = load i64, ptr %l132, !tbaa !24
  %t214 = icmp sge i64 %t213, 0
  br i1 %t214, label %bb50, label %bb51
bb49:
  br label %bb73
bb50:
  %t216 = load i64, ptr %l132, !tbaa !24
  %t217 = icmp sle i64 %t216, 2305843009213693951
  br i1 %t217, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb52:
  %t219 = load i64, ptr %l132, !tbaa !24
  %t220 = mul i64 %t219, 4
  %t221 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t225 = load i64, ptr %l18, !tbaa !24
  store i64 %t225, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t227 = load i64, ptr %l21, !tbaa !24
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb54:
  %t233 = load i64, ptr %l22, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb59
bb56:
  %t237 = load i64, ptr %l21, !tbaa !24
  %t238 = load i64, ptr %l20, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l22, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l22, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l143, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb58
bb58:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l140, !tbaa !24
  br label %bb59
bb59:
  %t254 = load i64, ptr %l140, !tbaa !24
  store i64 %t254, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  %t255 = load i64, ptr %l24, !tbaa !24
  %t256 = load i64, ptr %l23, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  br label %bb63
bb63:
  %t263 = load i64, ptr %l20, !tbaa !24
  %t264 = load i64, ptr %l24, !tbaa !24
  %t265 = load i64, ptr %l22, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  store i64 %t271, ptr %l25, !tbaa !24
  %t273 = load i64, ptr %l25, !tbaa !24
  store i64 %t273, ptr %l161, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l164, !tbaa !29
  %t280 = load i64, ptr %l3, !tbaa !24
  store i64 %t280, ptr %l165, !tbaa !24
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t282, ptr %l167
  br label %bb64
bb64:
  %t283 = load i64, ptr %l25, !tbaa !24
  %t284 = load i64, ptr %l167, !tbaa !24
  %t286 = add i64 %t284, %t283
  %t287 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t288 = load ptr, ptr %l164, !tbaa !29
  %t289 = load i64, ptr %l165, !tbaa !24
  %t292 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t288, i64 %t289, i64 %t286, i64 %t287)
  store i32 %t292, ptr %l171
  br label %bb65
bb65:
  %t293 = load i32, ptr %l171, !tbaa !23
  %t294 = load i64, ptr %l161, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i32, ptr %t296, i64 %t294
  store i32 %t293, ptr %t297, !tbaa !33
  br label %bb66
bb66:
  %t298 = load i64, ptr %l24, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l24, !tbaa !24
  br label %bb60
bb67:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !29
  store ptr %t305, ptr %l175, !tbaa !29
  %t306 = load i32, ptr %l17, !tbaa !23
  store i32 %t306, ptr %l176, !tbaa !23
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = getelementptr %"compiler/generic:Program", ptr %t310, i32 0, i32 2
  %t313 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s9, ptr %t312, { i64, ptr } %t313)
  store i32 %t316, ptr %l181
  br label %bb68
bb68:
  %t317 = load ptr, ptr %l175, !tbaa !29
  %t318 = load i32, ptr %l176, !tbaa !23
  %t319 = load i32, ptr %l181, !tbaa !23
  %t320 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t317, i32 %t318, i32 %t319)
  store i32 %t320, ptr %l182
  br label %bb69
bb69:
  %t321 = load i32, ptr %l182, !tbaa !23
  store i32 %t321, ptr %l16, !tbaa !23
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l16, !tbaa !23
  %t326 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t322, i32 %t323)
  store i1 %t326, ptr %l185
  br label %bb70
bb70:
  %t327 = load i32, ptr %l16, !tbaa !23
  store i32 %t327, ptr %l186, !tbaa !23
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t329, ptr %l188
  br label %bb71
bb71:
  %t330 = load i64, ptr %l18, !tbaa !24
  %t331 = load i64, ptr %l188, !tbaa !24
  %t333 = add i64 %t331, %t330
  %t334 = load i1, ptr %l185, !tbaa !21
  %t335 = load i32, ptr %l186, !tbaa !23
  %t337 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s9, i1 false, i1 %t334, i32 %t335, i64 %t333)
  store %"compiler/check:typeCase" %t337, ptr %l191
  br label %bb72
bb72:
  %t338 = load %"compiler/check:typeCase", ptr %l191
  store %"compiler/check:typeCase" %t338, ptr %l26
  %t339 = load i64, ptr %l3, !tbaa !24
  %t341 = getelementptr %"compiler/check:typeCase", ptr %l26, i32 0, i32 4
  store i64 %t339, ptr %t341, !tbaa !24
  %t342 = getelementptr %"compiler/check:typeCase", ptr %l26, i32 0, i32 5
  store i1 true, ptr %t342, !tbaa !21
  %t343 = load %"compiler/check:typeCase", ptr %l26
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t343, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t345 = load i32, ptr %l16, !tbaa !23
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t349 = icmp eq i32 %t345, %t346
  br i1 %t349, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s13
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t356 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t351, ptr %t352)
  store i32 %t356, ptr %l200
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t359 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s13, i1 false, i1 false, i32 %t357, i64 0)
  store %"compiler/check:typeCase" %t359, ptr %l202
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t360 = load %"compiler/check:typeCase", ptr %l202
  store %"compiler/check:typeCase" %t360, ptr %rv
  br label %ret
bb79:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l16, !tbaa !23
  %t365 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t361, i32 %t362)
  store i1 %t365, ptr %l205
  br label %bb80
bb80:
  %t366 = load i32, ptr %l16, !tbaa !23
  store i32 %t366, ptr %l206, !tbaa !23
  %t368 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t368, ptr %l208
  br label %bb81
bb81:
  %t369 = load i1, ptr %l205, !tbaa !21
  %t370 = load i32, ptr %l206, !tbaa !23
  %t371 = load i64, ptr %l208, !tbaa !24
  %t372 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s0, i1 false, i1 %t369, i32 %t370, i64 %t371)
  store %"compiler/check:typeCase" %t372, ptr %l209
  br label %bb82
bb82:
  %t373 = load %"compiler/check:typeCase", ptr %l209
  store %"compiler/check:typeCase" %t373, ptr %l27
  %t374 = load i64, ptr %l3, !tbaa !24
  %t376 = getelementptr %"compiler/check:typeCase", ptr %l27, i32 0, i32 4
  store i64 %t374, ptr %t376, !tbaa !24
  %t377 = load %"compiler/check:typeCase", ptr %l27
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t377, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:typeCase", ptr %rv
  ret %"compiler/check:typeCase" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca %"compiler/names:Ref"
  %l37 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i32
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i32
  %l79 = alloca i1
  %l84 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca %"compiler/names:Ref"
  %l106 = alloca i1
  %l109 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca i1
  %l128 = alloca i32
  %l131 = alloca i1
  %l136 = alloca i32
  %l142 = alloca { i64, ptr }
  %l156 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca { i64, ptr }
  %l175 = alloca %"compiler/source:Span"
  %l178 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca i64
  %l190 = alloca %"compiler/diagmsg:Msg"
  %l191 = alloca i64
  %l197 = alloca i32
  %l201 = alloca i1
  %l205 = alloca i1
  %l207 = alloca i1
  %l211 = alloca i1
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t307 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l28
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l32
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l32
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 9}
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l37
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t54 = load i32, ptr %l37, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l5, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp ne i32 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load i32, ptr %l5, !tbaa !23
  store i32 %t61, ptr %l41, !tbaa !23
  br label %bb13
bb12:
  store i32 -1, ptr %l41, !tbaa !23
  br label %bb13
bb13:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb14:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 9}
  %t67 = trunc i64 4 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  store i1 %t73, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i32 %t88, ptr %l53
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i32, ptr %l53, !tbaa !23
  %t91 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l54
  br label %bb21
bb21:
  %t92 = load i32, ptr %l54, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb22:
  %t93 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 9}
  %t96 = trunc i64 8 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t99 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t100 = load i32, ptr %t99, !range !{i32 0, i32 9}
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l57, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t106)
  store ptr %t108, ptr %l62
  br label %bb28
bb27:
  br label %bb44
bb28:
  %t109 = load ptr, ptr %l62, !tbaa !29
  %t111 = getelementptr %"compiler/check:frame", ptr %t109, i32 0, i32 4
  %t112 = getelementptr %"compiler/generic:Context", ptr %t111, i32 0, i32 2
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t112, i32 %t113)
  %t117 = extractvalue { i32, i32 } %t116, 1
  %t118 = extractvalue { i32, i32 } %t116, 0
  store i32 %t118, ptr %l67
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb30, label %ok.120, !prof !99
ok.120:
  store i32 %t117, ptr %l66
  br label %bb29
bb29:
  %t121 = load i32, ptr %l66, !tbaa !23
  store i32 %t121, ptr %l60, !tbaa !23
  br label %bb32
bb30:
  br label %bb31
bb31:
  store i32 -1, ptr %l60, !tbaa !23
  br label %bb32
bb32:
  %t122 = load i32, ptr %l60, !tbaa !23
  store i32 %t122, ptr %l6, !tbaa !23
  %t123 = load i32, ptr %l6, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l6, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb35
bb34:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb36
bb35:
  %t137 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t139 = trunc i64 26 to i32
  %t140 = icmp eq i32 %t137, %t139
  %t142 = xor i1 %t140, true
  store i1 %t142, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t144 = load i1, ptr %l70, !tbaa !21
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l6, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t155 = load i32, ptr %l84, !range !{i32 0, i32 33}
  %t157 = trunc i64 27 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t162 = load i1, ptr %l79, !tbaa !21
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t163 = load i32, ptr %l6, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb116
bb45:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t166 = load ptr, ptr %l89, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 28}
  %t172 = icmp eq i64 %t170, 12
  store i1 %t172, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l90, !tbaa !21
  br i1 %t173, label %bb48, label %bb49
bb48:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t176, i32 0, i32 0
  %t178 = load %"compiler/source:Span", ptr %t177
  store %"compiler/source:Span" %t178, ptr %l7
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l97, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t187)
  store ptr %t189, ptr %l99
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l99, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 2
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t199 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t196, i64 %t193, i32 %t195)
  store %"compiler/names:Ref" %t199, ptr %l103
  br label %bb52
bb52:
  %t200 = load %"compiler/names:Ref", ptr %l103
  store %"compiler/names:Ref" %t200, ptr %l8
  %t201 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t202 = load i32, ptr %t201, !range !{i32 0, i32 9}
  %t204 = trunc i64 4 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb53, label %bb54
bb53:
  %t207 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t208 = load i64, ptr %t207, !tbaa !24
  %t210 = icmp sge i64 %t208, 0
  store i1 %t210, ptr %l106, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb55
bb55:
  %t212 = load i1, ptr %l106, !tbaa !21
  br i1 %t212, label %bb56, label %bb57
bb56:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l109, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t219 = load i64, ptr %t218, !tbaa !24
  %t220 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t221 = load i64, ptr %t220, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t217, i64 %t219, i64 %t221)
  store i32 %t225, ptr %l114
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l114, !tbaa !23
  %t228 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l115
  br label %bb59
bb59:
  %t229 = load i32, ptr %l115, !tbaa !23
  store i32 %t229, ptr %rv
  br label %ret
bb60:
  br label %bb116
bb61:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t231 = load ptr, ptr %l116, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l116, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 28}
  %t237 = icmp eq i64 %t235, 11
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb63
bb63:
  %t238 = load i1, ptr %l117, !tbaa !21
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 0
  %t243 = load %"compiler/source:Span", ptr %t242
  store %"compiler/source:Span" %t243, ptr %l9
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t247, i32 0, i32 1
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l10, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t253, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254
  store { i64, ptr } %t255, ptr %l11, !tbaa !27
  br label %bb66
bb65:
  br label %bb111
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l10, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i32 %t261, ptr %l128
  br label %bb67
bb67:
  %t262 = load i32, ptr %l128, !tbaa !23
  store i32 %t262, ptr %l12, !tbaa !23
  %t263 = load i32, ptr %l12, !tbaa !23
  %t265 = icmp slt i32 %t263, 0
  br i1 %t265, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb71
bb69:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l12, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l136
  br label %bb70
bb70:
  %t277 = load i32, ptr %l136, !range !{i32 0, i32 6}
  %t279 = trunc i64 1 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  store i1 %t282, ptr %l131, !tbaa !21
  br label %bb71
bb71:
  %t284 = load i1, ptr %l131, !tbaa !21
  br i1 %t284, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t286 = load ptr, ptr %l10, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %s8, ptr %t286)
  store { i64, ptr } %t288, ptr %l142
  br label %bb75
bb75:
  %t289 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t294 = icmp eq i64 %t292, 0
  br i1 %t294, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t297 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t301 = icmp eq i64 %t299, 1
  br i1 %t301, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l9
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 0
  store i64 0, ptr %t308
  %t310 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t304, 0
  %t312 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t310, { i64, ptr } %t305, 1
  %t314 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t312, { i64, ptr } %t306, 2
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t314, ptr %t315
  %t316 = load { i64, [5 x i64] }, ptr %t307
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 48, i64 8)
  store { i64, [5 x i64] } %t316, ptr %t318
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %s11, ptr %t303, ptr %t318)
  store i32 %t321, ptr %l156
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t322 = load i32, ptr %l156, !tbaa !23
  store i32 %t322, ptr %l14, !tbaa !23
  %t323 = load i32, ptr %l14, !tbaa !23
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t327 = icmp ne i32 %t323, %t324
  br i1 %t327, label %bb82, label %bb83
bb82:
  %t329 = load i32, ptr %l14, !tbaa !23
  store i32 %t329, ptr %l160, !tbaa !23
  br label %bb84
bb83:
  store i32 -1, ptr %l160, !tbaa !23
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  %t331 = load i32, ptr %l160, !tbaa !23
  store i32 %t331, ptr %rv
  br label %ret
bb85:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t336 = load i32, ptr %l12, !tbaa !23
  %t337 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t341 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t335, i32 %t336, { i64, ptr } %t337)
  store i1 %t341, ptr %l166
  br label %bb86
bb86:
  %t342 = load i1, ptr %l166, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb87, label %bb88
bb87:
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l168, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 0
  br i1 %t350, label %bb89, label %bb90
bb88:
  br label %bb98
bb89:
  %t352 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t352, ptr %l173, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 0
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l175
  br label %bb91
bb90:
  %t359 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t359, ptr %l172
  br label %bb92
bb91:
  %t361 = load %"compiler/source:Span", ptr %l175
  store %"compiler/source:Span" %t361, ptr %l172
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t363, ptr %l178, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t368 = sub i64 %t366, 1
  %t370 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i32, ptr %t371, i64 %t368
  %t373 = load i32, ptr %t372, !tbaa !33
  %t376 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t362, i32 %t373)
  store { i64, ptr } %t376, ptr %l183
  br label %bb93
bb93:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load i32, ptr %l12, !tbaa !23
  %t384 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t380, i32 %t381)
  store i64 %t384, ptr %l187
  br label %bb94
bb94:
  %t385 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t387 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t385)
  store i64 %t387, ptr %l189
  br label %bb95
bb95:
  %t388 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t389 = load i64, ptr %l187, !tbaa !24
  %t390 = load i64, ptr %l189, !tbaa !24
  %t391 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v0, { i64, ptr } %t388, i64 %t389, i64 %t390)
  store %"compiler/diagmsg:Msg" %t391, ptr %l190
  br label %bb96
bb96:
  %t392 = load ptr, ptr %l168, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l172
  %t394 = load %"compiler/diagmsg:Msg", ptr %l190
  %t395 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t392, %"compiler/source:Span" %t393, %"compiler/diagmsg:Msg" %t394)
  store i64 %t395, ptr %l191
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb98:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load %"compiler/source:Span", ptr %l9
  %t399 = load i32, ptr %l12, !tbaa !23
  %t400 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t405 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %t397, %"compiler/source:Span" %t398, i32 %t399, { i64, ptr } %t400)
  store i32 %t405, ptr %l197
  br label %bb99
bb99:
  %t406 = load i32, ptr %l197, !tbaa !23
  store i32 %t406, ptr %l15, !tbaa !23
  %t407 = load i32, ptr %l15, !tbaa !23
  %t408 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t411 = icmp eq i32 %t407, %t408
  br i1 %t411, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb103
bb101:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load i32, ptr %l15, !tbaa !23
  %t415 = load %"compiler/source:Span", ptr %l9
  %t419 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t413, i32 %t414, %"compiler/source:Span" %t415)
  store i1 %t419, ptr %l205
  br label %bb102
bb102:
  %t420 = load i1, ptr %l205, !tbaa !21
  %t421 = xor i1 %t420, true
  store i1 %t421, ptr %l201, !tbaa !21
  br label %bb103
bb103:
  %t423 = load i1, ptr %l201, !tbaa !21
  br i1 %t423, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb107
bb105:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/check:Checker", ptr %t424, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t428 = load i32, ptr %l15, !tbaa !23
  %t431 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t427, i32 %t428)
  store i1 %t431, ptr %l211
  br label %bb106
bb106:
  %t432 = load i1, ptr %l211, !tbaa !21
  %t433 = xor i1 %t432, true
  store i1 %t433, ptr %l207, !tbaa !21
  br label %bb107
bb107:
  %t435 = load i1, ptr %l207, !tbaa !21
  br i1 %t435, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb109:
  br label %bb110
bb110:
  %t437 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  store i32 %t437, ptr %rv
  br label %ret
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_8b8738bb0f25fa76_719b7d77c23398a)
  unreachable
bb116:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l44 = alloca i32
  %l52 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l6, !tbaa !23
  store i32 %a2, ptr %l7, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l6, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l16, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t30 = load i32, ptr %l22, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l25
  br label %bb10
bb10:
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l6, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t56 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t58 = trunc i64 25 to i32
  %t59 = icmp eq i32 %t56, %t58
  %t61 = xor i1 %t59, true
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t80 = load i32, ptr %l7, !tbaa !23
  %t90 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t78, i32 %t79, i32 %t80, ptr %a3, i1 %a4, i1 %a5)
  store i32 %t90, ptr %l52
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb24, label %ok.92, !prof !99
ok.92:
  br label %bb23
bb23:
  br label %bb26
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t11)
  store i32 %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load i32, ptr %l14, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  br i1 %a3, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t23 = load i64, ptr %l19, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t29 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %s2, ptr %t27, %"compiler/source:Span" %t28, i32 %t29, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t33 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t33, ptr %rv
  br label %ret
bb13:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t35)
  store ptr %t37, ptr %l26
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l33
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t50 = load i1, ptr %l33, !tbaa !21
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l38
  br label %bb21
bb20:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb22
bb21:
  %t60 = load i1, ptr %l38, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t64, ptr %l40, !tbaa !24
  br label %bb25
bb24:
  %t66 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb25
bb25:
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l43, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l44, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l4, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t76, i32 %t77, i64 %t68)
  store i32 %t82, ptr %l50
  br label %bb26
bb26:
  %t83 = load %"compiler/source:Span", ptr %l2
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = load i32, ptr %l50, !tbaa !23
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %t84, ptr %t85, i32 %t86, %"compiler/source:Span" %t83)
  store ptr %t88, ptr %l52
  br label %bb27
bb27:
  %t89 = load ptr, ptr %l52, !tbaa !29
  store ptr %t89, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l6 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l31 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i64, ptr %l6, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l17
  br label %bb6
bb6:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t31, i64 %t32)
  store ptr %t35, ptr %l22
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 7
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t48, i32 %t52)
  store i32 %t55, ptr %l31
  br label %bb14
bb14:
  %t56 = load i32, ptr %l31, !tbaa !23
  store i32 %t56, ptr %l4, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l4, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l34
  br label %bb15
bb15:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb19
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l40
  br label %bb18
bb18:
  %t73 = load i1, ptr %l40, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l35, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca i32
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l58 = alloca ptr
  %l63 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca i32
  %l103 = alloca ptr
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca i64
  %l118 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca i64
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i32
  %l156 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l166 = alloca ptr
  %l167 = alloca i64
  %l171 = alloca ptr
  %l176 = alloca i64
  %l178 = alloca ptr
  %l181 = alloca i64
  %l182 = alloca i32
  %l183 = alloca i64
  %l185 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca i32
  %l195 = alloca ptr
  %l198 = alloca i64
  %l202 = alloca { i64, i64, i64 }
  %l206 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i64
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l213 = alloca i32
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l221 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t264 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load i64, ptr %l29, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l30, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l31
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l33
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l30, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l31
  %t16 = load i32, ptr %l33, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l34
  br label %bb3
bb3:
  %t18 = load i64, ptr %l34, !tbaa !24
  store i64 %t18, ptr %l9, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l35, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l36
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l39, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l40, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l41
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l43
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l40, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l41
  %t32 = load i32, ptr %l43, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l44
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l36
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l39, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l44, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 45
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l49
  br label %bb7
bb7:
  %t53 = load i64, ptr %l49, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t54, i32 2, %"compiler/source:Span" %t55)
  store { i64, i64, i64 } %t59, ptr %l53
  br label %bb8
bb8:
  %t60 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t60, ptr %l11
  %t61 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l13, !tbaa !24
  %t67 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l58
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l58, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 10
  %t76 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l63
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l63, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 11
  %t85 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:ForIn", ptr %t88, i32 0, i32 3
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t93)
  store ptr %t95, ptr %l70
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t96 = load ptr, ptr %l70, !tbaa !29
  store ptr %t96, ptr %l71, !tbaa !29
  %t97 = load ptr, ptr %l71, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 15
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = load ptr, ptr %l71, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 15
  store i64 %t101, ptr %t104, !tbaa !24
  br label %bb16
bb16:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l74, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l75
  %t107 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t107, ptr %l76
  store i64 %a5, ptr %l77, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t109, %"compiler/source:Span" %t110, i64 %t111)
  store ptr %t115, ptr %l81
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l81, !tbaa !29
  store ptr %t116, ptr %l82, !tbaa !29
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb18, label %bb19
bb18:
  %t119 = icmp sle i64 0, 1152921504606846975
  br i1 %t119, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb20:
  %t121 = mul i64 0, 8
  %t122 = insertvalue { i64, ptr } undef, i64 0, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t123, ptr %l85, !tbaa !27
  %t124 = icmp sge i64 0, 0
  br i1 %t124, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb22:
  %t126 = icmp sle i64 0, 1152921504606846975
  br i1 %t126, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb24:
  %t128 = mul i64 0, 8
  %t129 = insertvalue { i64, ptr } undef, i64 0, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t130, ptr %l88, !tbaa !27
  %t131 = icmp sge i64 0, 0
  br i1 %t131, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb26:
  %t133 = icmp sle i64 0, 2305843009213693951
  br i1 %t133, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb28:
  %t135 = mul i64 0, 4
  %t136 = insertvalue { i64, ptr } undef, i64 0, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t138 = load ptr, ptr %l74, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l75
  %t140 = load %"compiler/source:Span", ptr %l76
  %t141 = load i64, ptr %l77, !tbaa !24
  %t142 = load ptr, ptr %l82, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t138, %"compiler/source:Span" %t139, %"compiler/source:Span" %t140, i64 %t141, ptr %t142, { i64, ptr } %t143, { i64, ptr } %t144, { i64, ptr } %t137)
  store ptr %t146, ptr %l92
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb30:
  %t147 = load ptr, ptr %l92, !tbaa !29
  store ptr %t147, ptr %l15, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l93, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l94, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l95
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l96, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l97
  %t153 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t153, ptr %l98, !tbaa !23
  store i32 15, ptr %l99
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  %t156 = load i64, ptr %l9, !tbaa !24
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t154, %"compiler/source:Span" %t155, i64 %t156)
  store ptr %t160, ptr %l103
  br label %bb31
bb31:
  %t161 = load ptr, ptr %l15, !tbaa !29
  %t163 = load ptr, ptr %l96, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l97
  %t165 = load i32, ptr %l98, !tbaa !23
  %t166 = load i32, ptr %l99, !range !{i32 0, i32 52}
  %t167 = load ptr, ptr %l103, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t163, %"compiler/source:Span" %t164, i32 %t165, i32 %t166, ptr %t167, ptr %t161)
  store ptr %t169, ptr %l106
  br label %bb32
bb32:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load ptr, ptr %l94, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l95
  %t173 = load ptr, ptr %l106, !tbaa !29
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172, ptr %t173, i64 %t170)
  store ptr %t175, ptr %l108
  br label %bb33
bb33:
  %t176 = load ptr, ptr %l93, !tbaa !29
  %t177 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t176, ptr %t177)
  br label %bb34
bb34:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l109, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l110, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l8, !tbaa !24
  %t184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l113
  br label %bb35
bb35:
  %t185 = load ptr, ptr %l110, !tbaa !29
  %t186 = load i32, ptr %l113, !tbaa !23
  %t187 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t187, ptr %l114
  br label %bb36
bb36:
  %t188 = load ptr, ptr %l109, !tbaa !29
  %t189 = load i32, ptr %l114, !tbaa !23
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %t188, i32 %t189)
  store i64 %t190, ptr %l115
  br label %bb37
bb37:
  %t191 = load i64, ptr %l115, !tbaa !24
  store i64 %t191, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb38, label %bb39
bb38:
  store i64 %a4, ptr %l118, !tbaa !24
  br label %bb40
bb39:
  %t198 = load i64, ptr %l16, !tbaa !24
  store i64 %t198, ptr %l118, !tbaa !24
  br label %bb40
bb40:
  %t200 = load i64, ptr %l118, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l121, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t202, ptr %l122
  %t203 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t203, ptr %l123
  store i64 %t200, ptr %l124, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load i64, ptr %l8, !tbaa !24
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t205, %"compiler/source:Span" %t206, i64 %t207)
  store ptr %t211, ptr %l128
  br label %bb41
bb41:
  %t212 = load ptr, ptr %l128, !tbaa !29
  store ptr %t212, ptr %l129, !tbaa !29
  %t213 = icmp sge i64 0, 0
  br i1 %t213, label %bb42, label %bb43
bb42:
  %t215 = icmp sle i64 0, 1152921504606846975
  br i1 %t215, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb44:
  %t217 = mul i64 0, 8
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t219, ptr %l132, !tbaa !27
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l133, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l1
  %t223 = load i64, ptr %l9, !tbaa !24
  %t227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t221, %"compiler/source:Span" %t222, i64 %t223)
  store ptr %t227, ptr %l137
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb46:
  %t228 = load ptr, ptr %l133, !tbaa !29
  %t229 = load ptr, ptr %l137, !tbaa !29
  %t230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t228, ptr %t229)
  store { i64, ptr } %t230, ptr %l138
  br label %bb47
bb47:
  %t231 = icmp sge i64 0, 0
  br i1 %t231, label %bb48, label %bb49
bb48:
  %t233 = icmp sle i64 0, 2305843009213693951
  br i1 %t233, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb50:
  %t235 = mul i64 0, 4
  %t236 = insertvalue { i64, ptr } undef, i64 0, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t238 = load ptr, ptr %l121, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l122
  %t240 = load %"compiler/source:Span", ptr %l123
  %t241 = load i64, ptr %l124, !tbaa !24
  %t242 = load ptr, ptr %l129, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t238, %"compiler/source:Span" %t239, %"compiler/source:Span" %t240, i64 %t241, ptr %t242, { i64, ptr } %t243, { i64, ptr } %t244, { i64, ptr } %t237)
  store ptr %t246, ptr %l142
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb52:
  %t247 = load ptr, ptr %l142, !tbaa !29
  store ptr %t247, ptr %l18, !tbaa !29
  %t248 = load i64, ptr %l16, !tbaa !24
  %t250 = icmp sge i64 %t248, 0
  br i1 %t250, label %bb53, label %bb54
bb53:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l145, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l146
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l147
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l148, !tbaa !29
  %t256 = load ptr, ptr %l18, !tbaa !29
  %t259 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t256)
  store i32 %t259, ptr %l151
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t260 = load ptr, ptr %l148, !tbaa !29
  %t261 = load i32, ptr %l151, !tbaa !23
  %t262 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t262, ptr %l152
  br label %bb56
bb56:
  %t263 = load ptr, ptr %l18, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t264
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 0
  store i64 2, ptr %t265
  %t266 = load %"compiler/source:Span", ptr %l147
  %t267 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t266, 0
  %t268 = load i32, ptr %l152, !tbaa !23
  %t269 = insertvalue { %"compiler/source:Span", i32, ptr } %t267, i32 %t268, 1
  %t271 = insertvalue { %"compiler/source:Span", i32, ptr } %t269, ptr %t263, 2
  %t272 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t271, ptr %t272
  %t273 = load { i64, [4 x i64] }, ptr %t264
  %t275 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t273, ptr %t275
  %t276 = load ptr, ptr %l145, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l146
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t276, %"compiler/source:Span" %t277, ptr %t275)
  store ptr %t279, ptr %l156
  br label %bb57
bb57:
  %t280 = load ptr, ptr %l156, !tbaa !29
  store ptr %t280, ptr %l18, !tbaa !29
  br label %bb58
bb58:
  %t281 = load ptr, ptr %l2, !tbaa !29
  %t283 = getelementptr %"compiler/ast:ForIn", ptr %t281, i32 0, i32 3
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb59, label %bb60
bb59:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t286)
  store ptr %t288, ptr %l160
  br label %bb61
bb60:
  br label %bb62
bb61:
  %t289 = load ptr, ptr %l160, !tbaa !29
  store ptr %t289, ptr %l161, !tbaa !29
  %t290 = load ptr, ptr %l161, !tbaa !29
  %t291 = getelementptr %"compiler/check:frame", ptr %t290, i32 0, i32 15
  %t292 = load i64, ptr %t291, !tbaa !24
  %t294 = sub i64 %t292, 1
  %t296 = load ptr, ptr %l161, !tbaa !29
  %t297 = getelementptr %"compiler/check:frame", ptr %t296, i32 0, i32 15
  store i64 %t294, ptr %t297, !tbaa !24
  br label %bb62
bb62:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l164, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t299, ptr %l165
  %t300 = load ptr, ptr %l2, !tbaa !29
  store ptr %t300, ptr %l166, !tbaa !29
  %t301 = load i64, ptr %l9, !tbaa !24
  store i64 %t301, ptr %l167, !tbaa !24
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l18, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t302, ptr %t303, %"compiler/source:Span" %t304, i1 false)
  store ptr %t308, ptr %l171
  br label %bb63
bb63:
  %t309 = load ptr, ptr %l164, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l165
  %t311 = load ptr, ptr %l166, !tbaa !29
  %t312 = load i64, ptr %l167, !tbaa !24
  %t313 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t309, %"compiler/source:Span" %t310, ptr %t311, i64 %t312, ptr %t313)
  br label %bb64
bb64:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t314, ptr %t315, ptr %a6, i32 %a7)
  br label %bb65
bb65:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t322)
  store ptr %t324, ptr %l178
  br label %bb66
bb66:
  %t325 = load ptr, ptr %l178, !tbaa !29
  %t327 = getelementptr %"compiler/check:frame", ptr %t325, i32 0, i32 10
  %t329 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t327)
  %t330 = extractvalue { i32, i64 } %t329, 1
  %t331 = extractvalue { i32, i64 } %t329, 0
  store i32 %t331, ptr %l182
  %t332 = icmp ne i32 %t331, 0
  br i1 %t332, label %bb68, label %ok.333, !prof !99
ok.333:
  store i64 %t330, ptr %l181
  br label %bb67
bb67:
  %t334 = load i64, ptr %l181, !tbaa !24
  store i64 %t334, ptr %l176, !tbaa !24
  br label %bb70
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t335)
  store ptr %t337, ptr %l185
  br label %bb71
bb71:
  %t338 = load ptr, ptr %l185, !tbaa !29
  %t340 = getelementptr %"compiler/check:frame", ptr %t338, i32 0, i32 11
  %t342 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t340)
  %t343 = extractvalue { i32, i64 } %t342, 1
  %t344 = extractvalue { i32, i64 } %t342, 0
  store i32 %t344, ptr %l189
  %t345 = icmp ne i32 %t344, 0
  br i1 %t345, label %bb73, label %ok.346, !prof !99
ok.346:
  store i64 %t343, ptr %l188
  br label %bb72
bb72:
  %t347 = load i64, ptr %l188, !tbaa !24
  store i64 %t347, ptr %l183, !tbaa !24
  br label %bb75
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i64, ptr %l12, !tbaa !24
  %t350 = load i64, ptr %l13, !tbaa !24
  %t351 = load i64, ptr %l14, !tbaa !24
  %t352 = load i64, ptr %l10, !tbaa !24
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t348, i64 %t349, i64 %t350, i64 %t351, i64 %t352)
  store ptr %t358, ptr %l195
  br label %bb76
bb76:
  %t359 = load ptr, ptr %l195, !tbaa !29
  store ptr %t359, ptr %l19, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/check:Checker", ptr %t360, i32 0, i32 45
  %t364 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t362)
  store i64 %t364, ptr %l198
  br label %bb77
bb77:
  %t365 = load i64, ptr %l198, !tbaa !24
  store i64 %t365, ptr %l20, !tbaa !24
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l1
  %t371 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t366, i32 3, %"compiler/source:Span" %t367)
  store { i64, i64, i64 } %t371, ptr %l202
  br label %bb78
bb78:
  %t372 = load { i64, i64, i64 }, ptr %l202
  store { i64, i64, i64 } %t372, ptr %l21
  %t373 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t374 = load i64, ptr %t373, !tbaa !24
  store i64 %t374, ptr %l22, !tbaa !24
  %t376 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t377 = load i64, ptr %t376, !tbaa !24
  store i64 %t377, ptr %l23, !tbaa !24
  %t379 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t380 = load i64, ptr %t379, !tbaa !24
  store i64 %t380, ptr %l24, !tbaa !24
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l206, !tbaa !29
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l207, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t384, ptr %l208
  %t385 = load i64, ptr %l9, !tbaa !24
  store i64 %t385, ptr %l209, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l210, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t387, ptr %l211
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t388)
  store i32 %t390, ptr %l213
  br label %bb79
bb79:
  %t391 = load ptr, ptr %l210, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l211
  %t393 = load i32, ptr %l213, !tbaa !23
  %t394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t391, %"compiler/source:Span" %t392, i32 %t393, i64 1)
  store ptr %t394, ptr %l214
  br label %bb80
bb80:
  %t395 = load ptr, ptr %l207, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l208
  %t397 = load i64, ptr %l209, !tbaa !24
  %t398 = load ptr, ptr %l214, !tbaa !29
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t395, %"compiler/source:Span" %t396, i64 %t397, ptr %t398)
  store ptr %t399, ptr %l215
  br label %bb81
bb81:
  %t400 = load ptr, ptr %l206, !tbaa !29
  %t401 = load ptr, ptr %l215, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t400, ptr %t401)
  br label %bb82
bb82:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l22, !tbaa !24
  %t404 = load i64, ptr %l23, !tbaa !24
  %t405 = load i64, ptr %l24, !tbaa !24
  %t406 = load i64, ptr %l20, !tbaa !24
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t402, i64 %t403, i64 %t404, i64 %t405, i64 %t406)
  store ptr %t412, ptr %l221
  br label %bb83
bb83:
  %t413 = load ptr, ptr %l221, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l1
  %t416 = load ptr, ptr %l19, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 0
  store i64 4, ptr %t420
  %t422 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t415, 0
  %t424 = insertvalue { %"compiler/source:Span", ptr, ptr } %t422, ptr %t416, 1
  %t426 = insertvalue { %"compiler/source:Span", ptr, ptr } %t424, ptr %t413, 2
  %t427 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t426, ptr %t427
  %t428 = load { i64, [3 x i64] }, ptr %t419
  %t430 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t428, ptr %t430
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t414, ptr %t430)
  br label %bb84
bb84:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i1
  %l29 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca %"compiler/typed:Local"
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l62 = alloca %"compiler/check:heldCand"
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l88 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca { i64, i64, i64 }
  %l102 = alloca ptr
  %l107 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l117 = alloca ptr
  %l121 = alloca ptr
  %l126 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l141 = alloca i64
  %l142 = alloca i32
  %l143 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca i64
  %l149 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca ptr
  %l162 = alloca ptr
  %s4 = alloca %olang.scope
  %t100 = alloca { i64, [3 x i64] }, align 8
  %t146 = alloca { i64, [3 x i64] }, align 8
  %t300 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l20
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t3)
  store i32 %t6, ptr %l23
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l20
  %t9 = load i32, ptr %l23, !tbaa !23
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9)
  store i64 %t10, ptr %l24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l24, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v2, ptr %t12, ptr %t13)
  store i1 %t16, ptr %l27
  br label %bb3
bb3:
  %t17 = load i1, ptr %l27, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l29, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 17
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = trunc i64 %t24 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t23, i32 %t26)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t31 = load ptr, ptr %l35, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l35, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l36, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t45 = load ptr, ptr %l8, !tbaa !29
  store ptr %t45, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t46 = load ptr, ptr %l41, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l42, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l8, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l9, !tbaa !23
  br label %bb18
bb17:
  br label %bb27
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l48
  br label %bb19
bb19:
  %t63 = load i32, ptr %l9, !tbaa !23
  %t64 = load ptr, ptr %l48, !tbaa !29
  %t66 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t64, i32 %t63)
  store %"compiler/typed:Local" %t66, ptr %l50
  br label %bb20
bb20:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l50, i32 0, i32 4
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 7}
  %t70 = trunc i64 1 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 124
  store ptr %t75, ptr %l54, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t76)
  store ptr %t78, ptr %l56
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t79 = load ptr, ptr %l56, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i32, ptr %l9, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i64, ptr %l7, !tbaa !24
  %t90 = call %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %s4, i64 %t82, i64 %t85, i64 %t86)
  store %"compiler/check:heldCand" %t90, ptr %l62
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load %"compiler/check:heldCand", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %t91, %"compiler/check:heldCand" %t92)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_b35f41bb006554d6_a1d87dcad76a5f72)
  unreachable
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_943678799cf3b8f7_240de00f13c53f3)
  unreachable
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  %t99 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 0
  store i64 0, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t94, 0
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t97, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t99, 2
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t109, ptr %t111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t93, ptr %t111)
  br label %bb39
bb39:
  store i64 -1, ptr %l10, !tbaa !24
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:ForIn", ptr %t114, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t119 = icmp ne i32 %t117, 0
  br i1 %t119, label %bb40, label %bb41
bb40:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l74, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l75
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t123)
  store i32 %t125, ptr %l77
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t126 = load ptr, ptr %l74, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l75
  %t128 = load i32, ptr %l77, !tbaa !23
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t126, %"compiler/source:Span" %t127, i32 %t128)
  store i64 %t129, ptr %l78
  br label %bb43
bb43:
  %t130 = load i64, ptr %l78, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l79, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l80
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = trunc i64 %t133 to i32
  store i32 %t135, ptr %l83, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l84, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l85
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l87
  br label %bb44
bb44:
  %t142 = load ptr, ptr %l84, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l85
  %t144 = load i32, ptr %l87, !tbaa !23
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t142, %"compiler/source:Span" %t143, i32 %t144, i64 0)
  store ptr %t145, ptr %l88
  br label %bb45
bb45:
  store { i64, [3 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l80
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l83, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, i32 %t150, 1
  %t152 = load ptr, ptr %l88, !tbaa !29
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr } %t151, ptr %t152, 2
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t153, ptr %t154
  %t155 = load { i64, [3 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t155, ptr %t157
  %t158 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t158, ptr %t157)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 45
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l93
  br label %bb48
bb48:
  %t165 = load i64, ptr %l93, !tbaa !24
  store i64 %t165, ptr %l11, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t171 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t166, i32 2, %"compiler/source:Span" %t167)
  store { i64, i64, i64 } %t171, ptr %l97
  br label %bb49
bb49:
  %t172 = load { i64, i64, i64 }, ptr %l97
  store { i64, i64, i64 } %t172, ptr %l12
  %t173 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 0
  %t174 = load i64, ptr %t173, !tbaa !24
  store i64 %t174, ptr %l13, !tbaa !24
  %t176 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l14, !tbaa !24
  %t179 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 2
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t182)
  store ptr %t184, ptr %l102
  br label %bb50
bb50:
  %t185 = load ptr, ptr %l102, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 10
  %t188 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t191)
  store ptr %t193, ptr %l107
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l107, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 11
  %t197 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  br label %bb53
bb53:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l112
  store i64 %a4, ptr %l113, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t205 = load i64, ptr %l7, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, i64 %t205)
  store ptr %t209, ptr %l117
  br label %bb54
bb54:
  %t210 = icmp sge i64 0, 0
  br i1 %t210, label %bb55, label %bb56
bb55:
  %t212 = icmp sle i64 0, 1152921504606846975
  br i1 %t212, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb57:
  %t214 = mul i64 0, 8
  %t215 = insertvalue { i64, ptr } undef, i64 0, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l112
  %t219 = load i64, ptr %l113, !tbaa !24
  %t220 = load ptr, ptr %l117, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i64 %t219, ptr %t220, { i64, ptr } %t216)
  store ptr %t222, ptr %l121
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb59:
  %t223 = load ptr, ptr %l121, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l13, !tbaa !24
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v0, ptr %v0, ptr %t224, %"compiler/source:Span" %t225, ptr %t223, i64 %t227)
  store ptr %t232, ptr %l126
  br label %bb60
bb60:
  %t233 = load ptr, ptr %l126, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load ptr, ptr %l2, !tbaa !29
  %t237 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t234, %"compiler/source:Span" %t235, ptr %t236, i64 %t237, ptr %t233)
  br label %bb61
bb61:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t244, ptr %t245, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t252)
  store ptr %t254, ptr %l138
  br label %bb63
bb63:
  %t255 = load ptr, ptr %l138, !tbaa !29
  %t257 = getelementptr %"compiler/check:frame", ptr %t255, i32 0, i32 10
  %t259 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t257)
  %t260 = extractvalue { i32, i64 } %t259, 1
  %t261 = extractvalue { i32, i64 } %t259, 0
  store i32 %t261, ptr %l142
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb65, label %ok.263, !prof !99
ok.263:
  store i64 %t260, ptr %l141
  br label %bb64
bb64:
  %t264 = load i64, ptr %l141, !tbaa !24
  store i64 %t264, ptr %l136, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t265)
  store ptr %t267, ptr %l145
  br label %bb68
bb68:
  %t268 = load ptr, ptr %l145, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 11
  %t272 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t270)
  %t273 = extractvalue { i32, i64 } %t272, 1
  %t274 = extractvalue { i32, i64 } %t272, 0
  store i32 %t274, ptr %l149
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb70, label %ok.276, !prof !99
ok.276:
  store i64 %t273, ptr %l148
  br label %bb69
bb69:
  %t277 = load i64, ptr %l148, !tbaa !24
  store i64 %t277, ptr %l143, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i64, ptr %l13, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t281 = load i64, ptr %l15, !tbaa !24
  %t282 = load i64, ptr %l11, !tbaa !24
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t278, i64 %t279, i64 %t280, i64 %t281, i64 %t282)
  store ptr %t288, ptr %l155
  br label %bb73
bb73:
  %t289 = load ptr, ptr %l155, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l156, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t291, ptr %l157
  store ptr %t289, ptr %l158, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  %t295 = load i64, ptr %l10, !tbaa !24
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v0, ptr %t293, %"compiler/source:Span" %t294, i64 %t295, i64 1)
  store ptr %t299, ptr %l162
  br label %bb74
bb74:
  store { i64, [3 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 0
  store i64 4, ptr %t301
  %t302 = load %"compiler/source:Span", ptr %l157
  %t303 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t302, 0
  %t304 = load ptr, ptr %l158, !tbaa !29
  %t305 = insertvalue { %"compiler/source:Span", ptr, ptr } %t303, ptr %t304, 1
  %t306 = load ptr, ptr %l162, !tbaa !29
  %t307 = insertvalue { %"compiler/source:Span", ptr, ptr } %t305, ptr %t306, 2
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t307, ptr %t308
  %t309 = load { i64, [3 x i64] }, ptr %t300
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t309, ptr %t311
  %t312 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t312, ptr %t311)
  br label %bb75
bb75:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecopyDoes(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/effects:Facts", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/effects:Facts", ptr %t22, i32 0, i32 21
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t29, ptr %l11, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l12, !tbaa !24
  %t32 = load i64, ptr %l12, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t43, ptr %l11, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/effects:Facts", ptr %t45, i32 0, i32 10
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/effects:Facts", ptr %t50, i32 0, i32 11
  %t53 = load i1, ptr %t52, !tbaa !21
  store i1 %t53, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t55 = load i1, ptr %l16, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/effects:Facts", ptr %t56, i32 0, i32 15
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t61 = load i1, ptr %l19, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t62, ptr %l23, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l24, !tbaa !24
  %t65 = load i64, ptr %l24, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l25, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l24, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t76, ptr %l23, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/effects:Facts", ptr %t78, i32 0, i32 5
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb18
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/effects:Facts", ptr %t83, i32 0, i32 19
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = icmp ne i64 %t86, 0
  store i1 %t88, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l28, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t91, ptr %l33, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l34, !tbaa !24
  %t94 = load i64, ptr %l34, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l35, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l34, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t105, ptr %l33, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/effects:Facts", ptr %t107, i32 0, i32 7
  %t110 = load i1, ptr %t109, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t112, ptr %l39, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l40, !tbaa !24
  %t115 = load i64, ptr %l40, !tbaa !24
  %t116 = mul i64 %t115, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l41, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l40, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t126, ptr %l39, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/effects:Facts", ptr %t128, i32 0, i32 2
  %t131 = load i1, ptr %t130, !tbaa !21
  br i1 %t131, label %bb25, label %bb26
bb25:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t133, ptr %l45, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  store i64 %t135, ptr %l46, !tbaa !24
  %t136 = load i64, ptr %l46, !tbaa !24
  %t137 = mul i64 %t136, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t137)
  %t139 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  store { i64, ptr } %t140, ptr %l47, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l46, !tbaa !24
  %t146 = mul i64 %t145, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t142, ptr %t144, i64 %t146, i1 false)
  %t147 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t147, ptr %l45, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t148, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/effects:Facts", ptr %t149, i32 0, i32 13
  %t152 = load i1, ptr %t151, !tbaa !21
  br i1 %t152, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t154, ptr %l51, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l52, !tbaa !24
  %t157 = load i64, ptr %l52, !tbaa !24
  %t158 = mul i64 %t157, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l53, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l52, !tbaa !24
  %t167 = mul i64 %t166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t163, ptr %t165, i64 %t167, i1 false)
  %t168 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t168, ptr %l51, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t169, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t170, ptr %l55, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l56, !tbaa !24
  %t173 = load i64, ptr %l56, !tbaa !24
  %t174 = mul i64 %t173, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  store { i64, ptr } %t177, ptr %l57, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = load i64, ptr %l56, !tbaa !24
  %t183 = mul i64 %t182, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t179, ptr %t181, i64 %t183, i1 false)
  %t184 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t184, ptr %l55, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t185, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efoldBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:litv"
  %l6 = alloca i1
  %l11 = alloca %"compiler/check:litv"
  %l14 = alloca i64
  %l20 = alloca i64
  %l28 = alloca %"compiler/check:litv"
  %l30 = alloca i1
  %l32 = alloca i1
  %l36 = alloca %"compiler/check:litv"
  %l38 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t4 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 6
  %t5 = load i1, ptr %t4, !tbaa !21
  store i1 %t5, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t9 = load %"compiler/check:litv", ptr %l1
  %t10 = load %"compiler/check:litv", ptr %l2
  %t14 = call %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %t8, %"compiler/check:litv" %t9, %"compiler/check:litv" %t10)
  store %"compiler/check:litv" %t14, ptr %l11
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t15 = load %"compiler/check:litv", ptr %l11
  store %"compiler/check:litv" %t15, ptr %rv
  br label %ret
bb7:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t18 = trunc i64 100 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = and i64 %t22, %t24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb13
bb9:
  %t29 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t31 = trunc i64 101 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = or i64 %t35, %t37
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t42 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = xor i64 %t43, %t45
  store i64 %t48, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l20, !tbaa !24
  store i64 %t50, ptr %l14, !tbaa !24
  br label %bb13
bb13:
  %t51 = load i64, ptr %l14, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t52)
  store %"compiler/check:litv" %t54, ptr %l28
  br label %bb14
bb14:
  %t55 = load %"compiler/check:litv", ptr %l28
  store %"compiler/check:litv" %t55, ptr %l4
  %t56 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb16:
  %t59 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t60 = load i1, ptr %t59, !tbaa !21
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l32, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s2, i1 true, i1 false, i1 true, i64 %t68, double 0x0000000000000000)
  store %"compiler/check:litv" %t70, ptr %l36
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t71 = load %"compiler/check:litv", ptr %l36
  store %"compiler/check:litv" %t71, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t72 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb27
bb26:
  %t75 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 5
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t78 = load i1, ptr %l38, !tbaa !21
  %t79 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 5
  store i1 %t78, ptr %t79, !tbaa !21
  %t80 = load %"compiler/check:litv", ptr %l4
  store %"compiler/check:litv" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elistName(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca [7 x { i64, ptr }]
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t2 = insertvalue [7 x { i64, ptr }] %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t3 = insertvalue [7 x { i64, ptr }] %t2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) }, 2
  %t4 = insertvalue [7 x { i64, ptr }] %t3, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d58, i32 0, i32 1) }, 3
  %t5 = insertvalue [7 x { i64, ptr }] %t4, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 4
  %t6 = insertvalue [7 x { i64, ptr }] %t5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) }, 5
  %t7 = insertvalue [7 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d61, i32 0, i32 1) }, 6
  store [7 x { i64, ptr }] %t7, ptr %l1
  %t10 = getelementptr [7 x { i64, ptr }], ptr %l1, i64 0, i64 %a0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !37
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = and i64 %t1, %t2
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t9 = and i64 %t5, %t6
  %t10 = load i64, ptr %l0, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = or i64 %t10, %t11
  %t15 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t18 = and i64 %t14, %t15
  %t21 = or i64 %t9, %t18
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8d3b159055c7af2c_5997e8ea93888888)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:UnrollAsk" @compiler_2fcheck_3aUnrollAsk_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:UnrollAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:UnrollAsk" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:UnrollAsk" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/check:UnrollAsk" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:UnrollAsk" %t14, i32 %a3, 3
  store %"compiler/check:UnrollAsk" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:UnrollAsk", ptr %rv
  ret %"compiler/check:UnrollAsk" %rr
}

define dso_local %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:roArg"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:roArg" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:roArg" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:roArg" %t16, { i64, [3 x i64] } %a2, 2
  %t20 = insertvalue %"compiler/check:roArg" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/check:roArg" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/check:roArg" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:roArg" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roArg", ptr %rv
  ret %"compiler/check:roArg" %rr
}

@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_empty_array = external constant [16 x i64]
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"a call of a name of this kind" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ecaughtAlts_2elocal_2e6 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2ecompiler_2fcheck_3aaltsCovered_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/check:altsCovered" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aaltsCovered(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:altsCovered"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/check:altsCovered"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:altsCovered", ptr %a0
  store %"compiler/check:altsCovered" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:altsCovered", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/check:altsCovered", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/check:altsCovered", ptr %l1
  store %"compiler/check:altsCovered" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:altsCovered", ptr %rv
  ret %"compiler/check:altsCovered" %rr
}

@olang_2esole_2eArray_3ccompiler_2fast_3aPath_26_3e_2e_2d1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aClause_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

@.d4 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d5 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Overflow" }>, align 8
@.d7 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Invalid" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"NoReturn" }>, align 8
@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Exported" }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Extern" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2eembed_2elocal_2e6 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.d17 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an extern function as a value (T21)" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aroFn_2e3 = weak hidden constant i1 false
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@olang_2esole_2ecompiler_2fdiag_3acontext_2e1 = weak hidden constant i1 false
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"CStr" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d23 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a literal of this kind" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aframe_2e55 = weak hidden constant i1 false
define linkonce_odr %"compiler/check:loopUse" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aloopUse(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:loopUse"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/check:loopUse"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:loopUse", ptr %a0
  store %"compiler/check:loopUse" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:loopUse", ptr %l1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/check:loopUse", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/check:loopUse", ptr %l1
  store %"compiler/check:loopUse" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:loopUse", ptr %rv
  ret %"compiler/check:loopUse" %rr
}

@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c">[...]" }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define internal i1 @olang_lambda_27(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3anarrowed_2e5 = weak hidden constant i1 false
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Narrow'" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Narrow'" }>, align 8
@.d34 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d35 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d36 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Overflow" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define internal i1 @olang_lambda_39(ptr %env, %"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 1
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb6
bb2:
  %t6 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 4
  %t7 = load double, ptr %t6, !tbaa !26
  %t9 = fcmp ole double %t7, 0x7fefffffffffffff
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 4
  %t12 = load double, ptr %t11, !tbaa !26
  %t14 = fcmp oge double %t12, 0xffefffffffffffff
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l6, !tbaa !21
  store i1 %t16, ptr %l3, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define linkonce_odr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext__Hfb2c811c78810c6f5b3ad7447b9f8624(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %t6 = alloca %olang.slotscope
  %t44 = alloca %olang.slotscope
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %a0
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t2, ptr %l1
  %t3 = ptrtoint ptr %v0 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_2c_20std_2fprelude_2ftext_3aString_3e_2e0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %v0
  %t8 = icmp eq ptr %t7, @__olang_slot_chunk
  %t9 = getelementptr %olang.scope, ptr %v0, i32 0, i32 2
  %t10 = load ptr, ptr %t9
  %t11 = select i1 %t8, ptr %t10, ptr %v0
  store %olang.scope zeroinitializer, ptr %t6
  store ptr @__olang_slot_chunk, ptr %t6
  %t12 = getelementptr %olang.scope, ptr %t6, i32 0, i32 2
  store ptr %t11, ptr %t12
  %t13 = getelementptr %olang.slotscope, ptr %t6, i32 0, i32 1
  store i64 0, ptr %t13
  %t14 = ptrtoint ptr %t6 to i64
  store i64 %t14, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t15 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l6, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = load i64, ptr %l2
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l8, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t39 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t38, ptr %t39, !tbaa !27
  br label %bb5
bb4:
  %t40 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t40, !tbaa !27
  br label %bb5
bb5:
  %t41 = ptrtoint ptr %v0 to i64
  store i64 %t41, ptr %l9, !tbaa !24
  %t42 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_2c_20std_2fprelude_2ftext_3aString_3e_2e1
  br i1 %t42, label %bb6, label %bb7
bb6:
  %t45 = load ptr, ptr %v0
  %t46 = icmp eq ptr %t45, @__olang_slot_chunk
  %t47 = getelementptr %olang.scope, ptr %v0, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  %t49 = select i1 %t46, ptr %t48, ptr %v0
  store %olang.scope zeroinitializer, ptr %t44
  store ptr @__olang_slot_chunk, ptr %t44
  %t50 = getelementptr %olang.scope, ptr %t44, i32 0, i32 2
  store ptr %t49, ptr %t50
  %t51 = getelementptr %olang.slotscope, ptr %t44, i32 0, i32 1
  store i64 0, ptr %t51
  %t52 = ptrtoint ptr %t44 to i64
  store i64 %t52, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t53 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb8, label %bb9
bb8:
  %t59 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l13, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l14, !tbaa !24
  %t63 = load i64, ptr %l14, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = load i64, ptr %l9
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  %t68 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l15, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l14, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t76, ptr %t77, !tbaa !27
  br label %bb10
bb9:
  %t78 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t78, !tbaa !27
  br label %bb10
bb10:
  %t79 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l1
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t79, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %rv
  ret %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %rr
}

@.d44 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"totals: " }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
declare void @__olang_errpay_pop()
@.d46 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a local made from it" }>, align 8
@.d47 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"writes a global" }>, align 8
@.d48 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"writes through what it is given" }>, align 8
@.d49 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"calls through a function value or an 'any'" }>, align 8
@.d50 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"calls C" }>, align 8
@.d51 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"starts tasks" }>, align 8
@.d52 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"may wait" }>, align 8
@.d53 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"may end the program" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d58 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Methods" }>, align 8
@.d61 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_2c_20std_2fprelude_2ftext_3aString_3e_2e0 = weak hidden constant i1 false
@__olang_slot_chunk = external global %olang.chunk
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_2c_20std_2fprelude_2ftext_3aString_3e_2e1 = weak hidden constant i1 false
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBefore(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoMain(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMainSignature(ptr %v0)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2fb1f9f5dda04b10_a3bd6c7ca1760a54 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Heda0e3070e2f5ab051ad1f451edd65eb(ptr %v0, ptr %a0)
declare %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H62ca4e6c77402fbaa86eb0d94ae649ee(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %a0, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_6af63211fe08a219_4bcf48e786826ca5 = external constant [0 x i8]
@olang_loc_31ceea79ef23e30c_3748df63b5867238 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferredCtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, i32 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodMeant(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estdTypeModule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunction(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownFunctionMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFnCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, %"compiler/generic:Desc" %a3, { i64, ptr } %a4)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordCalled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b1d60606349c196f_148fe1dbe07e141b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7fe1bea66cf2144e_3863a3a9e6f6a662 = external constant [0 x i8]
@olang_loc_b79520aaecc0f88f_d487c78520878463 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, i64 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %v0, ptr %a0)
declare %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisBind(ptr %v0, ptr %a0)
@olang_loc_7f447623c50cbf0b_d88fa4c796e8075f = external constant [0 x i8]
declare %"compiler/check:altsCovered" @compiler_2fcheck_3aaltsCovered_2ector(ptr %v0, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i1 %a1, i1 %a2, i1 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare %"compiler/check:errBind" @compiler_2fcheck_3aerrBind_2ector(ptr %v0, i32 %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2ePush_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, %"compiler/check:errBind" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrCarries(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e0002d39d824213_e3bfdf913f3455ef = external constant [0 x i8]
declare i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_f25f445d5459b9fe_e155a29b0e6cdb52 = external constant [0 x i8]
@olang_loc_7a5b0973d8f0076e_d42fa20e68e1cea2 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtPayload(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameUnused(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorTypeHint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchLoneUnused(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eTrunca_H5bf147fe04fb910fd8a08f646d33c634(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8c10df0be32d8eb1_d395e5eefe4361bd = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaredUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImmutCopy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueCopy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCopyOnWhat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCopyShape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_7f8223142f689eb4_f934e4a817092f38 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bdeebae2e62e4381_d7e2b33750a898f5 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDropTempRegistered(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDropRegistered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_2d16f3aa36d067c5_95008946090581a1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4b90e82c7a9c5937397e46eef988cfe3(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H031c7c147cc8ce0b988dd3fed8d142ad(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEmbedPathUndecided(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEmbedPathUnknown(ptr %v0)
declare %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2ePush_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0, %"compiler/check:EmbedAsk" %a1)
@olang_loc_1d0e70c978300aa7_2a4aae738133c57b = external constant [0 x i8]
declare { { i64, ptr }, { i64, ptr } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEmbedNotRead(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorAsResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_8058995779d73e9c_6a6c2092014b34b0 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %a0, %"compiler/check:factsMark" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i32 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeDefaultNotTrailing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e4171899205744bd_2a3775717c01c5d1 = external constant [0 x i8]
@olang_loc_f9f7abe6f4095c55_11136f6e879bf089 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_de04a3fa462e2701_a46741d0a252ba9d = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnTooDeep(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [3 x i64] } %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValueAway(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenSlot(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
@olang_loc_15eb6f7c806fc73b_bac9f6515206ea7f = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenMarks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6)
@olang_loc_e919a481eb9c0c53_bf698ad9ae031297 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %a0)
@olang_loc_bb0c9585cb5cd0e5_782fa8d07097a5f1 = external constant [0 x i8]
@olang_loc_78bdf75b8d9b61cd_a447015cda228549 = external constant [0 x i8]
@olang_loc_ce96f1d737413f70_b94e71a15147345c = external constant [0 x i8]
@olang_loc_cca9af72e1ece301_506f5d82865fcd8d = external constant [0 x i8]
@olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %v0, %"compiler/generic:Origin" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb1726e9607ca4add8166541fc83d3bee(ptr %v0, ptr %a0, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %v0, ptr %a0)
declare %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb10eca62c04bf212a25728cfc6f83c9c(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2fcheck_2eWhyAssigned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:nullNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3anullNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:nullNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(ptr %v0, ptr %v1, %"compiler/check:narrowed" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/check:errNarrow" @compiler_2fcheck_2ecompiler_2fcheck_3aerrNarrow_2eKilled(ptr %v0, ptr %v1, %"compiler/check:errNarrow" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:errNarrow" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
@olang_loc_4be822f0c0d0de23_1d47e77fc9d2ed77 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2eLen_3ccompiler_2fcheck_3aloopUse_3e(ptr %v0, ptr %a0)
declare %"compiler/check:loopUse" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2eAt_3ccompiler_2fcheck_3aloopUse_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aloopUse_3e_2ePush_3ccompiler_2fcheck_3aloopUse_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:loopUse" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowedAcrossLoop(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralMixed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_d0f72ce45fbcaa4b_31766cde14dc3f8f = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_108bcd44a7d76d1e_c10b21813ea4a0da = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_da08e6a1bfd31b51_4c78ede106fe65fd = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i64 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Hb4635a51dd989c2102029bfb32ae3a2f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f66b04275832bdf5_49261566e6ebbc09 = external constant [0 x i8]
@olang_loc_959932aa8b846e4e_2c1999e37dfb1a2 = external constant [0 x i8]
@olang_loc_f94ac378888081c5_5f597351c4418bf9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9e3e60c51c241998_753bf57c496fa07c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
@olang_loc_2c067c0920238e9c_6231d620e5a2e328 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fast_2eFirstYield(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderExpected(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H2c4b9eb360b9a0ada2008890a467b28d(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:Ask" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:Ask" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eLen__Hcf51b196874cac8430175c74f3bdddd4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eAt_3ccompiler_2fcheck_3aAssertAsk_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eSetA_H2f2d9e3b51ec05f25dc2320ca6b31566(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eTrun_Heefffe1e944651b1941f34d83e014b00(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5f447d0cb8af3524_fdbf87197f7ceb70 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOperand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_Ha2532e1d68e811abb948a2d41b0a02a3(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_2c_2_H2299030e35d289e69d6656a10d43050e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePutErrLn_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_cc3b7a6e318210b6_464c855cb4a991aa = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebareDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_894a72349cd7ef67_30624e129d4b77a3 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_8b8738bb0f25fa76_719b7d77c23398a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8 = external constant [0 x i8]
@olang_loc_19568a04807ed851_528b5bfe222c3865 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_130b25e968db6b32_47c65c95f253846 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0, %"compiler/check:heldCand" %a1)
@olang_loc_b35f41bb006554d6_a1d87dcad76a5f72 = external constant [0 x i8]
@olang_loc_943678799cf3b8f7_240de00f13c53f3 = external constant [0 x i8]
@olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_8d3b159055c7af2c_5997e8ea93888888 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
