; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/eval:cfn" = type { i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, { i64, ptr } }
%"compiler/eval:Machine" = type { ptr, i32, i64, { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/eval:alloc" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i32, i64, i1, i64, i1 }
%"compiler/eval:frame" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i64, i64, i1, i64, i32, i32, i64 }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/eval:reg" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"compiler/eval:scope" = type { i64, i1, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i1, i1 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/eval:genRec" = type { i64, i64, %"compiler/eval:frame", i64, %"compiler/eval:Ptr", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/eval:gkey" = type { i64, i32 }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/eval:global" = type { i64, i1, i64, i64, i64, i1, i1, i1 }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/eval:task" = type { i64, i64, i64, i64, i64 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i32
  %l14 = alloca i64
  %l30 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/eval:cfn"
  %l36 = alloca %"compiler/eval:cfn"
  %l45 = alloca i64
  %l48 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/eval:cfn"
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca %"compiler/eval:cfn"
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l88 = alloca i1
  %l95 = alloca { i64, ptr }
  %t49 = alloca %"compiler/eval:cfn", align 8
  %t59 = alloca i64
  %t149 = alloca %"compiler/eval:cfn", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 26
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eLen_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 31
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t10, i32 0, i32 0
  %t13 = load { i64, [2 x i64] }, ptr %t12
  %t14 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %t9, { i64, [2 x i64] } %t13, i64 %t14)
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 26
  %t21 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2ePush_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb3
bb3:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 27
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t33 = icmp sge i64 %t24, %t30
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 27
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l3, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l30, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = mul i64 2, %t43
  store i64 %t45, ptr %l33, !tbaa !24
  call void @llvm.memset.p0.i64(ptr %l34, i8 0, i64 264, i1 false)
  %t46 = load i64, ptr %l33, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb6, label %bb7
bb5:
  br label %bb25
bb6:
  call void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2feval_3acfn(ptr %t49, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t49, i64 264, i1 false)
  br label %bb8
bb7:
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb9, label %bb10
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %l36, i64 264, i1 false)
  br label %bb7
bb9:
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = icmp sle i64 %t53, 34937015291116575
  br i1 %t54, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8e30d4bcef98d937_821e6ec72834ca4b)
  unreachable
bb11:
  %t56 = load i64, ptr %l33, !tbaa !24
  %t57 = mul i64 %t56, 264
  %t58 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t57)
  store i64 0, ptr %t59
  br label %fill.60
fill.60:
  %t63 = load i64, ptr %t59
  %t64 = icmp slt i64 %t63, %t56
  br i1 %t64, label %fillb.61, label %filld.62
fillb.61:
  %t65 = getelementptr %"compiler/eval:cfn", ptr %t58, i64 %t63
  call void @llvm.memmove.p0.p0.i64(ptr %t65, ptr %l34, i64 264, i1 false)
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %t59
  br label %fill.60
filld.62:
  %t67 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t58, 1
  %t70 = load ptr, ptr %l30, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 27
  store { i64, ptr } %t68, ptr %t71, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = icmp sgt i64 %t76, %t77
  br i1 %t80, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8e30d4bcef98d937_821e6ec72834ca4b)
  unreachable
bb13:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb18
bb15:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = sub i64 %t86, %t87
  %t91 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t90, %t91
  %t96 = sub i64 %t94, 1
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sdiv i64 %t96, %t97
  store i64 %t100, ptr %l48, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb17
bb17:
  %t102 = load i64, ptr %l48, !tbaa !24
  store i64 %t102, ptr %l45, !tbaa !24
  br label %bb18
bb18:
  %t103 = load i64, ptr %l45, !tbaa !24
  store i64 %t103, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t112 = load i64, ptr %l4, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = mul i64 %t113, %t114
  %t120 = add i64 %t112, %t117
  store i64 %t120, ptr %l9, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/eval:Machine", ptr %t122, i32 0, i32 27
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l67, !tbaa !27
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/eval:cfn", ptr %t131, i64 %t128
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t132, i64 264, i1 false)
  %t134 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr %"compiler/eval:cfn", ptr %t135, i64 %t126
  call void @llvm.memmove.p0.p0.i64(ptr %t136, ptr %l71, i64 264, i1 false)
  br label %bb23
bb23:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t137, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb19
bb24:
  br label %bb25
bb25:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/eval:Machine", ptr %t142, i32 0, i32 27
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l76, !tbaa !27
  %t146 = load i64, ptr %l2, !tbaa !24
  store i64 %t146, ptr %l77, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edecode(ptr %t149, ptr %v0, ptr %v1, ptr %v0, ptr %t147, ptr %t148)
  call void @llvm.memmove.p0.p0.i64(ptr %l80, ptr %t149, i64 264, i1 false)
  br label %bb26
bb26:
  %t152 = load i64, ptr %l77, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr %"compiler/eval:cfn", ptr %t154, i64 %t152
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %l80, i64 264, i1 false)
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/eval:Machine", ptr %t156, i32 0, i32 27
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, ptr } %t159, ptr %l82, !tbaa !27
  %t160 = load i64, ptr %l2, !tbaa !24
  store i64 %t160, ptr %l83, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/eval:Machine", ptr %t161, i32 0, i32 25
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/mir:Fn", ptr %t164, i32 0, i32 0
  %t167 = load { i64, [2 x i64] }, ptr %t166
  %t170 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t163, { i64, [2 x i64] } %t167)
  store i1 %t170, ptr %l88
  br label %bb27
bb27:
  %t171 = load i1, ptr %l88, !tbaa !21
  %t172 = load i64, ptr %l83, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr %"compiler/eval:cfn", ptr %t174, i64 %t172
  %t176 = getelementptr %"compiler/eval:cfn", ptr %t175, i32 0, i32 16
  store i1 %t171, ptr %t176, !tbaa !21
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/mir:Fn", ptr %t177, i32 0, i32 0
  %t180 = load { i64, [2 x i64] }, ptr %t179
  store { i64, [2 x i64] } %t180, ptr %l10
  %t182 = load { i64, [2 x i64] }, ptr %l10
  %t184 = extractvalue { i64, [2 x i64] } %t182, 0
  %t185 = icmp eq i64 %t184, 3
  br i1 %t185, label %bb28, label %bb29
bb28:
  %t187 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t188 = getelementptr { i32, i32 }, ptr %t187, i32 0, i32 0
  %t189 = load i32, ptr %t188, !range !{i32 0, i32 10}
  store i32 %t189, ptr %l11
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/eval:Machine", ptr %t191, i32 0, i32 27
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l95, !tbaa !27
  %t195 = load i64, ptr %l2, !tbaa !24
  %t196 = load i32, ptr %l11, !range !{i32 0, i32 10}
  %t198 = trunc i64 1 to i32
  %t199 = icmp eq i32 %t196, %t198
  %t202 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr %"compiler/eval:cfn", ptr %t203, i64 %t195
  %t205 = getelementptr %"compiler/eval:cfn", ptr %t204, i32 0, i32 17
  store i1 %t199, ptr %t205, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8d25544d0bd70291_3d464b777e1774ad)
  unreachable
bb36:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l62 = alloca i64
  %l72 = alloca ptr
  %l86 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i32
  %l130 = alloca %"compiler/mir:Local"
  %l132 = alloca ptr
  %l136 = alloca %"compiler/eval:Ptr"
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l148 = alloca i64
  %l152 = alloca i64
  %l155 = alloca i64
  %l164 = alloca i64
  %l167 = alloca i1
  %l178 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %rv = alloca { i64, [5 x i64] }
  %t8 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 24
  store i1 false, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [5 x i64] }, ptr %t8, i32 0, i32 0
  store i64 0, ptr %t9
  %t10 = load { i64, [5 x i64] }, ptr %t8
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 21
  store { i64, [5 x i64] } %t10, ptr %t13
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 22
  store i64 -1, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 15
  store i64 0, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t22)
  br label %bb1
bb1:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t26)
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 91
  store i64 0, ptr %t30, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 19
  %t34 = getelementptr %"compiler/eval:Ptr", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp ne i64 %t35, 0
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 50
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l41, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t43, i32 0, i32 19
  %t46 = getelementptr %"compiler/eval:Ptr", ptr %t45, i32 0, i32 0
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t51 = and i64 %t47, %t48
  %t53 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/eval:alloc", ptr %t54, i64 %t51
  %t56 = getelementptr %"compiler/eval:alloc", ptr %t55, i32 0, i32 4
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  store i1 %t61, ptr %l39, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb5
bb5:
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb6, label %bb7
bb6:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 19
  %t68 = getelementptr %"compiler/eval:Ptr", ptr %t67, i32 0, i32 0
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t73 = and i64 %t69, %t70
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t64, i64 %t73)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t76 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 19
  store %"compiler/eval:Ptr" %t76, ptr %t84
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t85, i32 0, i32 20
  store i32 %t78, ptr %t89, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t90, { i64, [2 x i64] } %a1)
  store i64 %t94, ptr %l62
  br label %bb10
bb10:
  %t95 = load i64, ptr %l62, !tbaa !24
  store i64 %t95, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = icmp slt i64 %t96, 0
  br i1 %t98, label %bb11, label %bb12
bb11:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t102 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t102, ptr %t100, { i64, ptr } %t101)
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/eval:Machine", ptr %t105, i32 0, i32 21
  %t108 = load { i64, [5 x i64] }, ptr %t107
  store { i64, [5 x i64] } %t108, ptr %rv
  br label %ret
bb14:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/eval:Machine", ptr %t110, i32 0, i32 26
  %t113 = load i64, ptr %l5, !tbaa !24
  %t116 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l72
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l72, !tbaa !29
  store ptr %t117, ptr %l6, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/mir:Fn", ptr %t118, i32 0, i32 2
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr %"compiler/mir:Fn", ptr %t123, i32 0, i32 3
  %t126 = load %"compiler/source:Span", ptr %t125
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t128, i32 0, i32 78
  store i64 %t121, ptr %t132, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 79
  store %"compiler/source:Span" %t126, ptr %t137
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/eval:Machine", ptr %t138, i32 0, i32 60
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l5, !tbaa !24
  %t145 = load i64, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  %t149 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t143, i64 %t144, i64 %t145, i64 0)
  store i64 %t149, ptr %l86
  br label %bb16
bb16:
  %t150 = load i64, ptr %l86, !tbaa !24
  store i64 %t150, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = icmp slt i64 %t151, 0
  br i1 %t153, label %bb17, label %bb18
bb17:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 21
  %t158 = load { i64, [5 x i64] }, ptr %t157
  store { i64, [5 x i64] } %t158, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  store i64 0, ptr %l11, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l11, !tbaa !24
  %t168 = icmp sgt i64 %t164, %t165
  br i1 %t168, label %bb20, label %bb21
bb20:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb25
bb22:
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = sub i64 %t174, %t175
  %t179 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t178, %t179
  %t184 = sub i64 %t182, 1
  %t185 = load i64, ptr %l13, !tbaa !24
  %t188 = sdiv i64 %t184, %t185
  store i64 %t188, ptr %l99, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb24
bb24:
  %t190 = load i64, ptr %l99, !tbaa !24
  store i64 %t190, ptr %l96, !tbaa !24
  br label %bb25
bb25:
  %t191 = load i64, ptr %l96, !tbaa !24
  store i64 %t191, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  %t192 = load i64, ptr %l15, !tbaa !24
  %t193 = load i64, ptr %l14, !tbaa !24
  %t196 = icmp slt i64 %t192, %t193
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t200 = load i64, ptr %l11, !tbaa !24
  %t201 = load i64, ptr %l15, !tbaa !24
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = mul i64 %t201, %t202
  %t208 = add i64 %t200, %t205
  store i64 %t208, ptr %l16, !tbaa !24
  %t210 = load i64, ptr %l16, !tbaa !24
  store i64 %t210, ptr %l117, !tbaa !24
  %t211 = load ptr, ptr %l6, !tbaa !29
  %t213 = getelementptr %"compiler/mir:Fn", ptr %t211, i32 0, i32 4
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t213)
  store i64 %t215, ptr %l120
  br label %bb30
bb30:
  %t216 = load i64, ptr %l117, !tbaa !24
  %t217 = load i64, ptr %l120, !tbaa !24
  %t218 = icmp slt i64 %t216, %t217
  br i1 %t218, label %bb31, label %bb32
bb31:
  %t220 = load ptr, ptr %l6, !tbaa !29
  %t222 = getelementptr %"compiler/mir:Fn", ptr %t220, i32 0, i32 4
  %t223 = load i64, ptr %l16, !tbaa !24
  %t226 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t222, i64 %t223)
  store i32 %t226, ptr %l125
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t227 = load i32, ptr %l125, !tbaa !23
  store i32 %t227, ptr %l17, !tbaa !23
  %t228 = load ptr, ptr %l6, !tbaa !29
  %t230 = getelementptr %"compiler/mir:Fn", ptr %t228, i32 0, i32 7
  %t231 = load i32, ptr %l17, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t236 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t230, i64 %t233)
  store %"compiler/mir:Local" %t236, ptr %l130
  br label %bb34
bb34:
  %t237 = getelementptr %"compiler/mir:Local", ptr %l130, i32 0, i32 2
  %t238 = load i32, ptr %t237, !tbaa !23
  store i32 %t238, ptr %l18, !tbaa !23
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l132, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l10, !tbaa !24
  %t243 = load i32, ptr %l17, !tbaa !23
  %t247 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t241, i64 %t242, i32 %t243)
  store %"compiler/eval:Ptr" %t247, ptr %l136
  br label %bb35
bb35:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l18, !tbaa !23
  %t252 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t248, i32 %t249)
  store i64 %t252, ptr %l139
  br label %bb36
bb36:
  %t253 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t253, ptr %l140, !tbaa !27
  %t254 = load i64, ptr %l16, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i64, ptr %t257, i64 %t254
  %t259 = load i64, ptr %t258, !tbaa !34
  %t260 = load ptr, ptr %l132, !tbaa !29
  %t261 = load %"compiler/eval:Ptr", ptr %l136
  %t262 = load i64, ptr %l139, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t260, %"compiler/eval:Ptr" %t261, i64 %t262, i64 %t259)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t264 = load i64, ptr %l15, !tbaa !24
  %t267 = add i64 %t264, 1
  store i64 %t267, ptr %l15, !tbaa !24
  br label %bb26
bb40:
  store i64 0, ptr %l19, !tbaa !24
  %t269 = load ptr, ptr %l6, !tbaa !29
  %t271 = getelementptr %"compiler/mir:Fn", ptr %t269, i32 0, i32 6
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l148
  br label %bb41
bb41:
  %t274 = load i64, ptr %l148, !tbaa !24
  store i64 %t274, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t275 = load i64, ptr %l20, !tbaa !24
  %t276 = load i64, ptr %l19, !tbaa !24
  %t279 = icmp sgt i64 %t275, %t276
  br i1 %t279, label %bb42, label %bb43
bb42:
  %t281 = load i64, ptr %l21, !tbaa !24
  %t283 = icmp sgt i64 %t281, 0
  br i1 %t283, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb47
bb44:
  %t285 = load i64, ptr %l20, !tbaa !24
  %t286 = load i64, ptr %l19, !tbaa !24
  %t289 = sub i64 %t285, %t286
  %t290 = load i64, ptr %l21, !tbaa !24
  %t293 = add i64 %t289, %t290
  %t295 = sub i64 %t293, 1
  %t296 = load i64, ptr %l21, !tbaa !24
  %t299 = sdiv i64 %t295, %t296
  store i64 %t299, ptr %l155, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb46
bb46:
  %t301 = load i64, ptr %l155, !tbaa !24
  store i64 %t301, ptr %l152, !tbaa !24
  br label %bb47
bb47:
  %t302 = load i64, ptr %l152, !tbaa !24
  store i64 %t302, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  %t303 = load i64, ptr %l22, !tbaa !24
  %t304 = sub i64 %t303, 1
  store i64 %t304, ptr %l164, !tbaa !24
  %t305 = load i64, ptr %l22, !tbaa !24
  %t306 = icmp slt i64 %t305, 2147483648
  %t307 = load i64, ptr %l23, !tbaa !24
  %t308 = icmp sge i64 %t307, 0
  %t311 = and i1 %t306, %t308
  store i1 %t311, ptr %l167, !tbaa !21
  br label %bb48
bb48:
  %t312 = load i64, ptr %l23, !tbaa !24
  %t313 = load i64, ptr %l22, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t320 = load i64, ptr %l19, !tbaa !24
  %t321 = load i64, ptr %l23, !tbaa !24
  %t322 = load i64, ptr %l21, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/eval:Machine", ptr %t330, i32 0, i32 61
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  store { i64, ptr } %t333, ptr %l178, !tbaa !27
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/eval:Machine", ptr %t334, i32 0, i32 59
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l180, !tbaa !27
  %t338 = load i64, ptr %l10, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr %"compiler/eval:frame", ptr %t341, i64 %t338
  %t343 = getelementptr %"compiler/eval:frame", ptr %t342, i32 0, i32 5
  %t344 = load i64, ptr %t343, !tbaa !24
  %t348 = add i64 %t344, %t328
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/eval:Machine", ptr %t349, i32 0, i32 71
  %t352 = load i64, ptr %t351, !tbaa !24
  %t355 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr i64, ptr %t356, i64 %t348
  store i64 %t352, ptr %t357, !tbaa !34
  br label %bb52
bb52:
  %t358 = load i64, ptr %l23, !tbaa !24
  %t361 = add i64 %t358, 1
  store i64 %t361, ptr %l23, !tbaa !24
  br label %bb48
bb53:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t363, i64 %t364)
  br label %bb54
bb54:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %t367, i64 %t368)
  br label %bb55
bb55:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/eval:Machine", ptr %t371, i32 0, i32 21
  %t374 = load { i64, [5 x i64] }, ptr %t373
  store { i64, [5 x i64] } %t374, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eSave(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { %"compiler/eval:Ptr", i32 }
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { %"compiler/eval:Ptr", i32 }
  %l16 = alloca { %"compiler/eval:Ptr", i32 }
  %l17 = alloca i32
  %l22 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %l33 = alloca i1
  %l38 = alloca i32
  %l42 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l58 = alloca i1
  %l63 = alloca i32
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %t1, i64 %a1, i32 %a2)
  %t8 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t7, 1
  %t9 = extractvalue { i32, { %"compiler/eval:Ptr", i32 } } %t7, 0
  store i32 %t9, ptr %l17
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { %"compiler/eval:Ptr", i32 } %t8, ptr %l16
  br label %bb1
bb1:
  %t12 = load { %"compiler/eval:Ptr", i32 }, ptr %l16
  store { %"compiler/eval:Ptr", i32 } %t12, ptr %l12
  br label %bb3
bb2:
  %t13 = load i32, ptr %l17, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i64 } zeroinitializer, i32 %t21, 0
  store { i32, i64 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { %"compiler/eval:Ptr", i32 }, ptr %l12
  store { %"compiler/eval:Ptr", i32 } %t24, ptr %l4
  %t25 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l4, i32 0, i32 0
  %t26 = load %"compiler/eval:Ptr", ptr %t25
  store %"compiler/eval:Ptr" %t26, ptr %l5
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Snapshot", ptr %t28, i32 0, i32 1
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb4
bb4:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Snapshot", ptr %t34, i32 0, i32 0
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t36)
  store i64 %t38, ptr %l25
  br label %bb5
bb5:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t47 = call { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2esaveAlloc(ptr %v0, ptr %v1, ptr %t40, i64 %t42, ptr %t43, i1 true)
  %t48 = extractvalue { i32, i64 } %t47, 1
  %t49 = extractvalue { i32, i64 } %t47, 0
  store i32 %t49, ptr %l31
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb7, label %ok.51, !prof !99
ok.51:
  store i64 %t48, ptr %l30
  br label %bb6
bb6:
  %t52 = load i64, ptr %l30, !tbaa !24
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb12
bb7:
  %t53 = load i32, ptr %l31, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  store i1 %t56, ptr %l33, !tbaa !21
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  store i32 %t65, ptr %l8, !tbaa !23
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2edrop(ptr %v1, ptr %t66, i64 %t67, i64 %t68)
  br label %bb9
bb9:
  %t72 = load i32, ptr %l8, !tbaa !23
  store i32 %t72, ptr %l38, !tbaa !23
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb10, label %bb11
bb10:
  %t77 = load i32, ptr %l38, !tbaa !23
  %t78 = lshr i32 %t77, 16
  %t79 = and i32 %t77, 65535
  %t80 = icmp eq i32 %t78, 1
  %t81 = select i1 %t80, i32 1, i32 0
  %t82 = icmp eq i32 %t77, 0
  %t83 = shl i32 %t81, 16
  %t84 = or i32 %t83, %t79
  %t85 = select i1 %t82, i32 0, i32 %t84
  %t87 = insertvalue { i32, i64 } zeroinitializer, i32 %t85, 0
  store { i32, i64 } %t87, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e7a4fa5689cb83c4_e9f49c5f7d359a08)
  unreachable
bb12:
  %t88 = load i64, ptr %l26, !tbaa !24
  store i64 %t88, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t91 = load i64, ptr %l10, !tbaa !24
  store i64 %t91, ptr %l42, !tbaa !24
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Snapshot", ptr %t92, i32 0, i32 1
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t94)
  store i64 %t96, ptr %l45
  br label %bb14
bb14:
  %t97 = load i64, ptr %l42, !tbaa !24
  %t98 = load i64, ptr %l45, !tbaa !24
  %t99 = icmp slt i64 %t97, %t98
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb15, label %bb16
bb15:
  br label %bb30
bb16:
  br label %bb17
bb17:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/eval:Snapshot", ptr %t103, i32 0, i32 1
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t105, i64 %t106)
  store i64 %t109, ptr %l51
  br label %bb18
bb18:
  %t110 = load i64, ptr %l51, !tbaa !24
  %t111 = icmp slt i64 %t110, 0
  br i1 %t111, label %bb19, label %bb20
bb19:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t119 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2esaveWords(ptr %v0, ptr %v1, ptr %t113, i64 %t114, ptr %t115)
  store i32 %t119, ptr %l56
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb22, label %ok.121, !prof !99
ok.121:
  br label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb27
bb22:
  %t122 = load i32, ptr %l56, !tbaa !23
  %t123 = ashr i32 %t122, 16
  %t125 = icmp eq i32 %t123, 1
  store i1 %t125, ptr %l58, !tbaa !21
  %t126 = load i32, ptr %l56, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  store i32 %t134, ptr %l11, !tbaa !23
  br label %bb23
bb23:
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t136 = load i64, ptr %l6, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2edrop(ptr %v1, ptr %t135, i64 %t136, i64 %t137)
  br label %bb24
bb24:
  %t141 = load i32, ptr %l11, !tbaa !23
  store i32 %t141, ptr %l63, !tbaa !23
  %t143 = load i32, ptr %l63, !tbaa !23
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb25, label %bb26
bb25:
  %t146 = load i32, ptr %l63, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  %t156 = insertvalue { i32, i64 } zeroinitializer, i32 %t154, 0
  store { i32, i64 } %t156, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_75b3dda1da275889_df5a5485a99f3eed)
  unreachable
bb27:
  br label %bb28
bb28:
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb29
bb29:
  br label %bb13
bb30:
  %t162 = load i64, ptr %l9, !tbaa !24
  %t164 = insertvalue { i32, i64 } zeroinitializer, i64 %t162, 1
  store { i32, i64 } %t164, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eSaveRegs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:reg"
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"compiler/eval:scope"
  %l30 = alloca %"compiler/eval:reg"
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca i64
  %l64 = alloca i64
  %l68 = alloca %"compiler/eval:reg"
  %l69 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i32
  %l78 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i64
  %l91 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %t14 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/eval:Machine", ptr %t3, i32 0, i32 53
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 71
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t13 = and i64 %t9, %t10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t14, ptr %v0, ptr %t5, i64 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t14, i64 152, i1 false)
  br label %bb2
bb2:
  %t17 = getelementptr %"compiler/eval:scope", ptr %l20, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t26)
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 55
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t31, i64 %t32)
  store %"compiler/eval:reg" %t35, ptr %l30
  br label %bb8
bb8:
  %t36 = getelementptr %"compiler/eval:reg", ptr %l30, i32 0, i32 4
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  br label %bb3
bb10:
  store i64 0, ptr %l4, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t40, ptr %l33
  br label %bb11
bb11:
  %t41 = load i64, ptr %l33, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb17
bb14:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb16
bb16:
  %t68 = load i64, ptr %l40, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb19, label %bb20
bb19:
  br label %bb43
bb20:
  br label %bb21
bb21:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l9, !tbaa !24
  store ptr %l2, ptr %l58, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t89, ptr %l60
  br label %bb22
bb22:
  %t90 = load i64, ptr %l60, !tbaa !24
  %t91 = sub i64 %t90, 1
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t96, i64 %t95)
  store i64 %t98, ptr %l64
  br label %bb23
bb23:
  %t99 = load i64, ptr %l64, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/eval:Machine", ptr %t100, i32 0, i32 55
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t102, i64 %t103)
  store %"compiler/eval:reg" %t106, ptr %l68
  br label %bb24
bb24:
  %t107 = load %"compiler/eval:reg", ptr %l68
  store %"compiler/eval:reg" %t107, ptr %l11
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Snapshot", ptr %t108, i32 0, i32 5
  %t111 = getelementptr %"compiler/eval:reg", ptr %l11, i32 0, i32 2
  %t112 = load i64, ptr %t111, !tbaa !24
  %t115 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t110, i64 %t112)
  %t116 = extractvalue { i32, i64 } %t115, 1
  %t117 = extractvalue { i32, i64 } %t115, 0
  store i32 %t117, ptr %l74
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb26, label %ok.119, !prof !99
ok.119:
  store i64 %t116, ptr %l73
  br label %bb25
bb25:
  %t120 = load i64, ptr %l73, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb28
bb28:
  %t121 = load i64, ptr %l69, !tbaa !24
  store i64 %t121, ptr %l12, !tbaa !24
  %t122 = getelementptr %"compiler/eval:reg", ptr %l11, i32 0, i32 0
  %t123 = load i64, ptr %t122, !tbaa !24
  %t124 = load i64, ptr @G_2ecompiler_2feval_2egDtor, !tbaa !24
  %t127 = icmp ne i64 %t123, %t124
  br i1 %t127, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb31
bb30:
  %t129 = load i64, ptr %l12, !tbaa !24
  %t131 = icmp slt i64 %t129, 0
  store i1 %t131, ptr %l78, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l78, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  br label %bb42
bb33:
  br label %bb34
bb34:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/eval:Snapshot", ptr %t134, i32 0, i32 2
  store ptr %t136, ptr %l82, !tbaa !29
  %t137 = call ptr @__olang_scope_hold(ptr %v1)
  %t138 = ptrtoint ptr %t137 to i64
  store i64 %t138, ptr %l83, !tbaa !24
  %t139 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t141 = call ptr @__olang_region_make(ptr %v1)
  %t142 = ptrtoint ptr %t141 to i64
  store i64 %t142, ptr %l83, !tbaa !24
  br label %bb36
bb36:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/eval:Machine", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = getelementptr %"compiler/eval:reg", ptr %l11, i32 0, i32 1
  %t148 = load i64, ptr %t147, !tbaa !24
  %t150 = trunc i64 %t148 to i32
  %t152 = load i64, ptr %l83
  %t153 = inttoptr i64 %t152 to ptr
  %t155 = inttoptr i64 0 to ptr
  %t158 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %t153, ptr %t155, ptr %t146, i32 %t150)
  store { i64, ptr } %t158, ptr %l91
  br label %bb37
bb37:
  %t159 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t160 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t160, { i64, ptr } %t159)
  br label %bb38
bb38:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Snapshot", ptr %t162, i32 0, i32 3
  %t165 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t164, i64 %t165)
  br label %bb39
bb39:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/eval:Snapshot", ptr %t168, i32 0, i32 4
  %t171 = getelementptr %"compiler/eval:reg", ptr %l11, i32 0, i32 3
  %t172 = load i64, ptr %t171, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t170, i64 %t172)
  br label %bb40
bb40:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunlinkReg(ptr %v0, ptr %t175, i64 %t176)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t179 = load i64, ptr %l8, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l8, !tbaa !24
  br label %bb18
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaggregate(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i64 %a4, %"compiler/mir:Range" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, [4 x i64] }
  %l25 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i64
  %l32 = alloca %"compiler/eval:Ptr"
  %l37 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i1
  %l46 = alloca i32
  %l48 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca i32
  %l65 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca %"compiler/eval:Ptr"
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l89 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i64
  %l97 = alloca { i64, [4 x i64] }
  %l98 = alloca %"compiler/eval:Ptr"
  %l108 = alloca i64
  %l113 = alloca i32
  %l116 = alloca i32
  %l139 = alloca { i64, [4 x i64] }
  %l145 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca i64
  %l148 = alloca i64
  %l150 = alloca i64
  %l153 = alloca i64
  %l155 = alloca %"compiler/eval:Ptr"
  %l164 = alloca i32
  %l165 = alloca ptr
  %l166 = alloca i64
  %l167 = alloca i64
  %l172 = alloca i64
  %l174 = alloca %"compiler/eval:Ptr"
  %l179 = alloca i32
  %l181 = alloca ptr
  %l182 = alloca i64
  %l183 = alloca i64
  %l188 = alloca i64
  %l189 = alloca %"compiler/eval:Ptr"
  %l194 = alloca i32
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store %"compiler/mir:Range" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load i64, ptr %l29, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %t7, i64 0, i64 %t8)
  store %"compiler/eval:Ptr" %t11, ptr %l32
  br label %bb2
bb2:
  %t12 = load %"compiler/eval:Ptr", ptr %l32
  store %"compiler/eval:Ptr" %t12, ptr %l7
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/eval:Ptr", ptr %l7
  %t15 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t13, %"compiler/eval:Ptr" %t14, i64 %t15)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l37, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l41
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l37, !tbaa !29
  %t32 = load i32, ptr %l41, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t33, ptr %l42
  br label %bb5
bb5:
  %t34 = load i1, ptr %l42, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l46
  br label %bb8
bb7:
  br label %bb28
bb8:
  %t43 = load i32, ptr %l46, !tbaa !23
  store i32 %t43, ptr %l8, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l48, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l8, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l52
  br label %bb9
bb9:
  %t56 = load ptr, ptr %l48, !tbaa !29
  %t57 = load i32, ptr %l52, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l53
  br label %bb10
bb10:
  %t59 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t59, ptr %l9, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l8, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %s1, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l57
  br label %bb11
bb11:
  %t68 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t68, ptr %l10, !tbaa !27
  store i32 0, ptr %l11, !tbaa !23
  %t69 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  store i32 %t70, ptr %l12, !tbaa !23
  store i32 1, ptr %l13, !tbaa !23
  %t72 = load i32, ptr %l12, !tbaa !23
  %t73 = load i32, ptr %l11, !tbaa !23
  %t76 = icmp sgt i32 %t72, %t73
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = load i32, ptr %l13, !tbaa !23
  %t80 = icmp sgt i32 %t78, 0
  br i1 %t80, label %bb14, label %bb15
bb13:
  store i32 0, ptr %l62, !tbaa !23
  br label %bb17
bb14:
  %t82 = load i32, ptr %l12, !tbaa !23
  %t83 = load i32, ptr %l11, !tbaa !23
  %t86 = sub i32 %t82, %t83
  %t87 = load i32, ptr %l13, !tbaa !23
  %t90 = add i32 %t86, %t87
  %t92 = sub i32 %t90, 1
  %t93 = load i32, ptr %l13, !tbaa !23
  %t96 = sdiv i32 %t92, %t93
  store i32 %t96, ptr %l65, !tbaa !23
  br label %bb16
bb15:
  store i32 0, ptr %l65, !tbaa !23
  br label %bb16
bb16:
  %t98 = load i32, ptr %l65, !tbaa !23
  store i32 %t98, ptr %l62, !tbaa !23
  br label %bb17
bb17:
  %t99 = load i32, ptr %l62, !tbaa !23
  store i32 %t99, ptr %l14, !tbaa !23
  store i32 0, ptr %l15, !tbaa !23
  br label %bb18
bb18:
  %t100 = load i32, ptr %l15, !tbaa !23
  %t101 = load i32, ptr %l14, !tbaa !23
  %t104 = icmp slt i32 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb19, label %bb20
bb19:
  br label %bb26
bb20:
  br label %bb21
bb21:
  %t108 = load i32, ptr %l11, !tbaa !23
  %t109 = load i32, ptr %l15, !tbaa !23
  %t110 = load i32, ptr %l13, !tbaa !23
  %t113 = mul i32 %t109, %t110
  %t116 = add i32 %t108, %t113
  store i32 %t116, ptr %l16, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l83, !tbaa !29
  %t119 = load %"compiler/eval:Ptr", ptr %l7
  store %"compiler/eval:Ptr" %t119, ptr %l84
  %t120 = load i32, ptr %l16, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i64, ptr %t124, i64 %t122
  %t126 = load i64, ptr %t125, !tbaa !34
  store i64 %t126, ptr %l86, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t127, ptr %l87, !tbaa !27
  %t128 = load i32, ptr %l16, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t131 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 %t130
  %t134 = load i32, ptr %t133, !tbaa !33
  store i32 %t134, ptr %l89, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l90, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  store i64 %t136, ptr %l91, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l1, !tbaa !24
  %t139 = load %"compiler/mir:Range", ptr %l5
  %t140 = load i32, ptr %l16, !tbaa !23
  %t142 = sext i32 %t140 to i64
  %t147 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t137, i64 %t138, %"compiler/mir:Range" %t139, i64 %t142)
  store { i64, [4 x i64] } %t147, ptr %l97
  br label %bb22
bb22:
  %t148 = load ptr, ptr %l90, !tbaa !29
  %t149 = load i64, ptr %l91, !tbaa !24
  %t150 = load { i64, [4 x i64] }, ptr %l97
  %t151 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t148, i64 %t149, { i64, [4 x i64] } %t150, i64 1)
  store %"compiler/eval:Ptr" %t151, ptr %l98
  br label %bb23
bb23:
  %t152 = load ptr, ptr %l83, !tbaa !29
  %t153 = load %"compiler/eval:Ptr", ptr %l84
  %t154 = load i64, ptr %l86, !tbaa !24
  %t155 = load i32, ptr %l89, !tbaa !23
  %t156 = load %"compiler/eval:Ptr", ptr %l98
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epackInto(ptr %v0, ptr %t152, %"compiler/eval:Ptr" %t153, i64 %t154, i32 %t155, %"compiler/eval:Ptr" %t156)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t157 = load i32, ptr %l15, !tbaa !23
  %t160 = add i32 %t157, 1
  store i32 %t160, ptr %l15, !tbaa !23
  br label %bb18
bb26:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load %"compiler/eval:Ptr", ptr %l2
  %t164 = load %"compiler/eval:Ptr", ptr %l7
  %t165 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t162, %"compiler/eval:Ptr" %t163, %"compiler/eval:Ptr" %t164, i64 %t165)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb28:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l3, !tbaa !23
  %t174 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t170, i32 %t171)
  store i64 %t174, ptr %l108
  br label %bb29
bb29:
  %t175 = load i64, ptr %l108, !tbaa !24
  store i64 %t175, ptr %l17, !tbaa !24
  store i32 0, ptr %l18, !tbaa !23
  %t176 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t177 = load i32, ptr %t176, !tbaa !23
  store i32 %t177, ptr %l19, !tbaa !23
  store i32 1, ptr %l20, !tbaa !23
  %t179 = load i32, ptr %l19, !tbaa !23
  %t180 = load i32, ptr %l18, !tbaa !23
  %t183 = icmp sgt i32 %t179, %t180
  br i1 %t183, label %bb30, label %bb31
bb30:
  %t185 = load i32, ptr %l20, !tbaa !23
  %t187 = icmp sgt i32 %t185, 0
  br i1 %t187, label %bb32, label %bb33
bb31:
  store i32 0, ptr %l113, !tbaa !23
  br label %bb35
bb32:
  %t189 = load i32, ptr %l19, !tbaa !23
  %t190 = load i32, ptr %l18, !tbaa !23
  %t193 = sub i32 %t189, %t190
  %t194 = load i32, ptr %l20, !tbaa !23
  %t197 = add i32 %t193, %t194
  %t199 = sub i32 %t197, 1
  %t200 = load i32, ptr %l20, !tbaa !23
  %t203 = sdiv i32 %t199, %t200
  store i32 %t203, ptr %l116, !tbaa !23
  br label %bb34
bb33:
  store i32 0, ptr %l116, !tbaa !23
  br label %bb34
bb34:
  %t205 = load i32, ptr %l116, !tbaa !23
  store i32 %t205, ptr %l113, !tbaa !23
  br label %bb35
bb35:
  %t206 = load i32, ptr %l113, !tbaa !23
  store i32 %t206, ptr %l21, !tbaa !23
  store i32 0, ptr %l22, !tbaa !23
  br label %bb36
bb36:
  %t207 = load i32, ptr %l22, !tbaa !23
  %t208 = load i32, ptr %l21, !tbaa !23
  %t211 = icmp slt i32 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb37, label %bb38
bb37:
  br label %bb61
bb38:
  br label %bb39
bb39:
  %t215 = load i32, ptr %l18, !tbaa !23
  %t216 = load i32, ptr %l22, !tbaa !23
  %t217 = load i32, ptr %l20, !tbaa !23
  %t220 = mul i32 %t216, %t217
  %t223 = add i32 %t215, %t220
  store i32 %t223, ptr %l23, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i64, ptr %l1, !tbaa !24
  %t227 = load %"compiler/mir:Range", ptr %l5
  %t228 = load i32, ptr %l23, !tbaa !23
  %t230 = sext i32 %t228 to i64
  %t235 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t225, i64 %t226, %"compiler/mir:Range" %t227, i64 %t230)
  store { i64, [4 x i64] } %t235, ptr %l139
  br label %bb40
bb40:
  %t236 = load { i64, [4 x i64] }, ptr %l139
  store { i64, [4 x i64] } %t236, ptr %l24
  %t237 = load i64, ptr %l17, !tbaa !24
  %t238 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t241 = icmp eq i64 %t237, %t238
  br i1 %t241, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l3, !tbaa !23
  %t247 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l145
  br label %bb43
bb42:
  %t248 = load i64, ptr %l17, !tbaa !24
  %t249 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  %t252 = icmp eq i64 %t248, %t249
  br i1 %t252, label %bb47, label %bb48
bb43:
  %t254 = load i32, ptr %l145, !tbaa !23
  store i32 %t254, ptr %l25, !tbaa !23
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l146, !tbaa !29
  %t256 = load i64, ptr %l1, !tbaa !24
  store i64 %t256, ptr %l147, !tbaa !24
  %t257 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l148, !tbaa !24
  %t259 = load i32, ptr %l23, !tbaa !23
  %t261 = sext i32 %t259 to i64
  store i64 %t261, ptr %l150, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i32, ptr %l25, !tbaa !23
  %t266 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t262, i32 %t263)
  store i64 %t266, ptr %l153
  br label %bb44
bb44:
  %t267 = load i64, ptr %l150, !tbaa !24
  %t268 = load i64, ptr %l153, !tbaa !24
  %t269 = mul i64 %t267, %t268
  %t270 = load i64, ptr %l148, !tbaa !24
  %t272 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t270, i64 %t269)
  store %"compiler/eval:Ptr" %t272, ptr %l155
  br label %bb45
bb45:
  %t273 = load i32, ptr %l25, !tbaa !23
  %t274 = load { i64, [4 x i64] }, ptr %l24
  %t275 = load ptr, ptr %l146, !tbaa !29
  %t276 = load i64, ptr %l147, !tbaa !24
  %t277 = load %"compiler/eval:Ptr", ptr %l155
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t275, i64 %t276, %"compiler/eval:Ptr" %t277, i32 %t273, { i64, [4 x i64] } %t274)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l3, !tbaa !23
  %t282 = load i64, ptr %l4, !tbaa !24
  %t286 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t280, i32 %t281, i64 %t282)
  store i32 %t286, ptr %l164
  br label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l181, !tbaa !29
  %t288 = load i64, ptr %l1, !tbaa !24
  store i64 %t288, ptr %l182, !tbaa !24
  %t289 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t290 = load i64, ptr %t289, !tbaa !24
  store i64 %t290, ptr %l183, !tbaa !24
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l3, !tbaa !23
  %t293 = load i32, ptr %l23, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t299 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t291, i32 %t292, i64 %t295)
  store i64 %t299, ptr %l188
  br label %bb54
bb49:
  %t300 = load i32, ptr %l164, !tbaa !23
  store i32 %t300, ptr %l26, !tbaa !23
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l165, !tbaa !29
  %t302 = load i64, ptr %l1, !tbaa !24
  store i64 %t302, ptr %l166, !tbaa !24
  %t303 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t304 = load i64, ptr %t303, !tbaa !24
  store i64 %t304, ptr %l167, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i32, ptr %l26, !tbaa !23
  %t307 = load i32, ptr %l23, !tbaa !23
  %t309 = sext i32 %t307 to i64
  %t313 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t305, i32 %t306, i64 %t309)
  store i64 %t313, ptr %l172
  br label %bb50
bb50:
  %t314 = load i64, ptr %l172, !tbaa !24
  %t315 = add i64 8, %t314
  %t316 = load i64, ptr %l167, !tbaa !24
  %t318 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s9, i64 %t316, i64 %t315)
  store %"compiler/eval:Ptr" %t318, ptr %l174
  br label %bb51
bb51:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l26, !tbaa !23
  %t321 = load i32, ptr %l23, !tbaa !23
  %t323 = sext i32 %t321 to i64
  %t327 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t319, i32 %t320, i64 %t323)
  store i32 %t327, ptr %l179
  br label %bb52
bb52:
  %t328 = load { i64, [4 x i64] }, ptr %l24
  %t329 = load ptr, ptr %l165, !tbaa !29
  %t330 = load i64, ptr %l166, !tbaa !24
  %t331 = load %"compiler/eval:Ptr", ptr %l174
  %t332 = load i32, ptr %l179, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t329, i64 %t330, %"compiler/eval:Ptr" %t331, i32 %t332, { i64, [4 x i64] } %t328)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb54:
  %t334 = load i64, ptr %l183, !tbaa !24
  %t335 = load i64, ptr %l188, !tbaa !24
  %t336 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s10, i64 %t334, i64 %t335)
  store %"compiler/eval:Ptr" %t336, ptr %l189
  br label %bb55
bb55:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i32, ptr %l3, !tbaa !23
  %t339 = load i32, ptr %l23, !tbaa !23
  %t341 = sext i32 %t339 to i64
  %t345 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t337, i32 %t338, i64 %t341)
  store i32 %t345, ptr %l194
  br label %bb56
bb56:
  %t346 = load { i64, [4 x i64] }, ptr %l24
  %t347 = load ptr, ptr %l181, !tbaa !29
  %t348 = load i64, ptr %l182, !tbaa !24
  %t349 = load %"compiler/eval:Ptr", ptr %l189
  %t350 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t347, i64 %t348, %"compiler/eval:Ptr" %t349, i32 %t350, { i64, [4 x i64] } %t346)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t352 = load i32, ptr %l22, !tbaa !23
  %t355 = add i32 %t352, 1
  store i32 %t355, ptr %l22, !tbaa !23
  br label %bb36
bb61:
  %t357 = load i64, ptr %l17, !tbaa !24
  %t358 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  %t361 = icmp eq i64 %t357, %t358
  br i1 %t361, label %bb62, label %bb63
bb62:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load %"compiler/eval:Ptr", ptr %l7
  %t365 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t363, %"compiler/eval:Ptr" %t364, i64 8, i64 %t365)
  br label %bb64
bb63:
  %t369 = load i64, ptr %l17, !tbaa !24
  %t370 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t373 = icmp eq i64 %t369, %t370
  br i1 %t373, label %bb65, label %bb66
bb64:
  br label %bb69
bb65:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load %"compiler/eval:Ptr", ptr %l7
  %t377 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t375, %"compiler/eval:Ptr" %t376, i64 4, i64 %t377)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load %"compiler/eval:Ptr", ptr %l2
  %t383 = load %"compiler/eval:Ptr", ptr %l7
  %t384 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t381, %"compiler/eval:Ptr" %t382, %"compiler/eval:Ptr" %t383, i64 %t384)
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %rv = alloca %"compiler/eval:alloc"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 50
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t9 = and i64 %a1, %t6
  %t11 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:alloc", ptr %t12, i64 %t9
  %t14 = load %"compiler/eval:alloc", ptr %t13
  store %"compiler/eval:alloc" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:alloc", ptr %rv
  ret %"compiler/eval:alloc" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayTarget(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { %"compiler/eval:Ptr", i64 }
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l8 = alloca { %"compiler/eval:Ptr", i64 }
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/eval:Ptr"
  %l16 = alloca { %"compiler/eval:Ptr", i64 }
  %l22 = alloca { %"compiler/eval:Ptr", i64 }
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i64
  %l50 = alloca %"compiler/eval:Ptr"
  %l62 = alloca ptr
  %l66 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/eval:Ptr", ptr %l1
  %t3 = load i32, ptr %l3, !tbaa !23
  %t7 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %t2, i32 %t3)
  store { %"compiler/eval:Ptr", i64 } %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i64 }, ptr %l16
  store { %"compiler/eval:Ptr", i64 } %t8, ptr %l5
  %t9 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l5, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l6
  %t12 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l5, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/eval:Ptr", ptr %l2
  %t17 = load i32, ptr %l3, !tbaa !23
  %t21 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t15, %"compiler/eval:Ptr" %t16, i32 %t17)
  store { %"compiler/eval:Ptr", i64 } %t21, ptr %l22
  br label %bb2
bb2:
  %t22 = load { %"compiler/eval:Ptr", i64 }, ptr %l22
  store { %"compiler/eval:Ptr", i64 } %t22, ptr %l8
  %t23 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  store %"compiler/eval:Ptr" %t24, ptr %l9
  %t26 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l10, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l25, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l28
  br label %bb3
bb3:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i32, ptr %l28, !tbaa !23
  %t37 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t37, ptr %l29
  br label %bb4
bb4:
  %t38 = load i64, ptr %l29, !tbaa !24
  store i64 %t38, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l10, !tbaa !24
  %t43 = icmp eq i64 %t39, %t40
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/eval:Ptr", ptr %l6
  %t47 = load %"compiler/eval:Ptr", ptr %l9
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = mul i64 %t48, %t49
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t45, %"compiler/eval:Ptr" %t46, %"compiler/eval:Ptr" %t47, i64 %t52)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/eval:Ptr", ptr %l1
  %t63 = load %"compiler/eval:Ptr", ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t61, %"compiler/eval:Ptr" %t62, %"compiler/eval:Ptr" %t63, i64 16)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t73 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t79 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t67, i64 %t72, i64 %t73, i64 %t74)
  store %"compiler/eval:Ptr" %t79, ptr %l50
  br label %bb13
bb13:
  %t80 = load %"compiler/eval:Ptr", ptr %l50
  store %"compiler/eval:Ptr" %t80, ptr %l12
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Machine", ptr %t81, i32 0, i32 23
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/eval:Ptr", ptr %l12
  %t88 = load %"compiler/eval:Ptr", ptr %l9
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = mul i64 %t89, %t90
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t86, %"compiler/eval:Ptr" %t87, %"compiler/eval:Ptr" %t88, i64 %t93)
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/eval:Ptr", ptr %l1
  %t100 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t98, %"compiler/eval:Ptr" %t99, i64 8, i64 %t100)
  br label %bb18
bb18:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l62, !tbaa !29
  %t105 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t108 = load i64, ptr %t107, !tbaa !24
  %t110 = add i64 %t108, 8
  %t113 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t106, i64 %t110)
  store %"compiler/eval:Ptr" %t113, ptr %l66
  br label %bb19
bb19:
  %t114 = load %"compiler/eval:Ptr", ptr %l12
  %t115 = load ptr, ptr %l62, !tbaa !29
  %t116 = load %"compiler/eval:Ptr", ptr %l66
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t115, %"compiler/eval:Ptr" %t116, %"compiler/eval:Ptr" %t114)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eatomic(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/mir:Range" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca %"compiler/eval:Ptr"
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i64
  %l31 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/eval:Ptr"
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca %"compiler/eval:Ptr"
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca { i64, [4 x i64] }
  %l62 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca %"compiler/eval:Ptr"
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i64
  %l78 = alloca { i64, [4 x i64] }
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i64
  %l86 = alloca { i64, [4 x i64] }
  %l87 = alloca i64
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca %"compiler/eval:Ptr"
  %l95 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca i64
  %l101 = alloca { i64, [4 x i64] }
  %l102 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l11, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load %"compiler/mir:Range", ptr %l3
  %t10 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t4, i64 %t5, %"compiler/mir:Range" %t6, i64 0)
  store { i64, [4 x i64] } %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = load { i64, [4 x i64] }, ptr %l15
  %t14 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t11, i64 %t12, { i64, [4 x i64] } %t13, i64 1)
  store %"compiler/eval:Ptr" %t14, ptr %l16
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load %"compiler/eval:Ptr", ptr %l16
  %t17 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t15, %"compiler/eval:Ptr" %t16)
  store %"compiler/eval:Ptr" %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load %"compiler/eval:Ptr", ptr %l17
  store %"compiler/eval:Ptr" %t18, ptr %l5
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l19, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %a4)
  store i32 %t30, ptr %l23
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i32, ptr %l23, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load i32, ptr %l24, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t35, i32 %t34)
  store i64 %t39, ptr %l27
  br label %bb6
bb6:
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/eval:Ptr", ptr %l5
  %t43 = load i64, ptr %l7, !tbaa !24
  %t47 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t41, %"compiler/eval:Ptr" %t42, i64 %t43)
  store i64 %t47, ptr %l31
  br label %bb7
bb7:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 23
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb8, label %bb9
bb8:
  store i64 0, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t57 = trunc i64 24 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t60 = load i64, ptr %l8, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
bb14:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t64 = trunc i64 25 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l40, !tbaa !29
  %t68 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t68, ptr %l41
  %t69 = load i64, ptr %l7, !tbaa !24
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = load i64, ptr %l1, !tbaa !24
  store i64 %t71, ptr %l44, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load %"compiler/mir:Range", ptr %l3
  %t78 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t72, i64 %t73, %"compiler/mir:Range" %t74, i64 1)
  store { i64, [4 x i64] } %t78, ptr %l48
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load i64, ptr %l44, !tbaa !24
  %t81 = load { i64, [4 x i64] }, ptr %l48
  %t82 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t79, i64 %t80, { i64, [4 x i64] } %t81)
  store i64 %t82, ptr %l49
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load %"compiler/eval:Ptr", ptr %l41
  %t85 = load i64, ptr %l42, !tbaa !24
  %t86 = load i64, ptr %l49, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t83, %"compiler/eval:Ptr" %t84, i64 %t85, i64 %t86)
  br label %bb20
bb20:
  br label %bb50
bb21:
  %t87 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t89 = trunc i64 26 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l52, !tbaa !29
  %t93 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t93, ptr %l53
  %t94 = load i64, ptr %l7, !tbaa !24
  store i64 %t94, ptr %l54, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  store i64 %t95, ptr %l55, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l56, !tbaa !29
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l1, !tbaa !24
  %t100 = load %"compiler/mir:Range", ptr %l3
  %t104 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t98, i64 %t99, %"compiler/mir:Range" %t100, i64 1)
  store { i64, [4 x i64] } %t104, ptr %l61
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = load i64, ptr %l57, !tbaa !24
  %t107 = load { i64, [4 x i64] }, ptr %l61
  %t108 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t105, i64 %t106, { i64, [4 x i64] } %t107)
  store i64 %t108, ptr %l62
  br label %bb26
bb26:
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = load i64, ptr %l62, !tbaa !24
  %t111 = add i64 %t109, %t110
  store i64 %t111, ptr %l63, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l66
  br label %bb27
bb27:
  %t117 = load i64, ptr %l63, !tbaa !24
  %t118 = load i64, ptr %l66, !tbaa !24
  %t119 = and i64 %t117, %t118
  %t120 = load ptr, ptr %l52, !tbaa !29
  %t121 = load %"compiler/eval:Ptr", ptr %l53
  %t122 = load i64, ptr %l54, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t120, %"compiler/eval:Ptr" %t121, i64 %t122, i64 %t119)
  br label %bb28
bb28:
  br label %bb50
bb29:
  %t124 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t126 = trunc i64 27 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l70, !tbaa !29
  %t130 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t130, ptr %l71
  %t131 = load i64, ptr %l7, !tbaa !24
  store i64 %t131, ptr %l72, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l73, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  store i64 %t133, ptr %l74, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t136 = load %"compiler/mir:Range", ptr %l3
  %t140 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t134, i64 %t135, %"compiler/mir:Range" %t136, i64 1)
  store { i64, [4 x i64] } %t140, ptr %l78
  br label %bb33
bb33:
  %t141 = load ptr, ptr %l73, !tbaa !29
  %t142 = load i64, ptr %l74, !tbaa !24
  %t143 = load { i64, [4 x i64] }, ptr %l78
  %t144 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t141, i64 %t142, { i64, [4 x i64] } %t143)
  store i64 %t144, ptr %l79
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l70, !tbaa !29
  %t146 = load %"compiler/eval:Ptr", ptr %l71
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l79, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t145, %"compiler/eval:Ptr" %t146, i64 %t147, i64 %t148)
  br label %bb35
bb35:
  br label %bb50
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb49
bb39:
  %t149 = load i64, ptr %l8, !tbaa !24
  store i64 %t149, ptr %l80, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l81, !tbaa !29
  %t151 = load i64, ptr %l1, !tbaa !24
  store i64 %t151, ptr %l82, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  %t154 = load %"compiler/mir:Range", ptr %l3
  %t158 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t152, i64 %t153, %"compiler/mir:Range" %t154, i64 1)
  store { i64, [4 x i64] } %t158, ptr %l86
  br label %bb40
bb40:
  %t159 = load ptr, ptr %l81, !tbaa !29
  %t160 = load i64, ptr %l82, !tbaa !24
  %t161 = load { i64, [4 x i64] }, ptr %l86
  %t162 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t159, i64 %t160, { i64, [4 x i64] } %t161)
  store i64 %t162, ptr %l87
  br label %bb41
bb41:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i64, ptr %l7, !tbaa !24
  %t167 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t163, i64 %t164)
  store i64 %t167, ptr %l90
  br label %bb42
bb42:
  %t168 = load i64, ptr %l87, !tbaa !24
  %t169 = load i64, ptr %l90, !tbaa !24
  %t170 = and i64 %t168, %t169
  %t171 = load i64, ptr %l80, !tbaa !24
  %t173 = icmp eq i64 %t171, %t170
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l93, !tbaa !29
  %t176 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t176, ptr %l94
  %t177 = load i64, ptr %l7, !tbaa !24
  store i64 %t177, ptr %l95, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  %t179 = load i64, ptr %l1, !tbaa !24
  store i64 %t179, ptr %l97, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t182 = load %"compiler/mir:Range", ptr %l3
  %t186 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t180, i64 %t181, %"compiler/mir:Range" %t182, i64 2)
  store { i64, [4 x i64] } %t186, ptr %l101
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t187 = load ptr, ptr %l96, !tbaa !29
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = load { i64, [4 x i64] }, ptr %l101
  %t190 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t187, i64 %t188, { i64, [4 x i64] } %t189)
  store i64 %t190, ptr %l102
  br label %bb46
bb46:
  %t191 = load ptr, ptr %l93, !tbaa !29
  %t192 = load %"compiler/eval:Ptr", ptr %l94
  %t193 = load i64, ptr %l95, !tbaa !24
  %t194 = load i64, ptr %l102, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t191, %"compiler/eval:Ptr" %t192, i64 %t193, i64 %t194)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_561376b2ca02a7ba_25f299f9320c8ad6)
  unreachable
bb50:
  %t195 = load i64, ptr %l8, !tbaa !24
  store i64 %t195, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebitcast(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l20 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l51 = alloca i1
  %l56 = alloca i64
  %l67 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t7 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 2}
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t20, i32 %t21)
  store i64 %t24, ptr %l20
  br label %bb7
bb6:
  br label %bb40
bb7:
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = mul i64 8, %t25
  store i64 %t26, ptr %l3, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l25
  br label %bb8
bb8:
  %t36 = load i32, ptr %l25, !tbaa !23
  store i32 %t36, ptr %l4, !tbaa !23
  %t37 = load i32, ptr %l4, !tbaa !23
  %t39 = icmp eq i32 %t37, 11
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 10, ptr %l26, !tbaa !24
  br label %bb25
bb12:
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp eq i32 %t41, 12
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 7, ptr %l26, !tbaa !24
  br label %bb25
bb16:
  %t45 = load i32, ptr %l4, !tbaa !23
  %t47 = icmp eq i32 %t45, 13
  br i1 %t47, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 23, ptr %l26, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 52, ptr %l26, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7b1287020d5a411f_7f0f28d70ecde84b)
  unreachable
bb25:
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sub i64 %t52, %t53
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = shl i64 1, %t58
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %l39, !tbaa !24
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = shl i64 %t61, %t65
  store i64 %t66, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l1, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = load i64, ptr %l42, !tbaa !24
  %t72 = shl i64 1, %t71
  %t74 = sub i64 %t72, 1
  %t77 = and i64 %t68, %t74
  store i64 %t77, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = and i64 %t79, %t80
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = icmp ne i64 %t89, 0
  store i1 %t91, ptr %l51, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb28
bb28:
  %t93 = load i1, ptr %l51, !tbaa !21
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = sub i64 %t95, 1
  store i64 %t97, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = load i64, ptr %l56, !tbaa !24
  %t101 = ashr i64 %t94, %t100
  %t103 = and i64 %t101, 1
  %t105 = icmp eq i64 %t103, 1
  %t109 = xor i1 %t105, true
  br i1 %t109, label %bb31, label %bb32
bb30:
  br label %bb39
bb31:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNaNSignal, !tbaa !27
  %t113 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t113, ptr %t111, { i64, ptr } %t112)
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i64 0, ptr %rv
  br label %ret
bb34:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l5, !tbaa !24
  %t120 = sub i64 %t118, 1
  store i64 %t120, ptr %l67, !tbaa !24
  %t121 = load i64, ptr %l67, !tbaa !24
  %t122 = load i64, ptr %l67, !tbaa !24
  %t123 = shl i64 1, %t122
  %t126 = icmp eq i64 %t117, %t123
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNaNOp, !tbaa !27
  %t130 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t130, ptr %t128, { i64, ptr } %t129)
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i64 0, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca { %"compiler/eval:Ptr", i64 }
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca %"compiler/eval:Ptr"
  %l25 = alloca { %"compiler/eval:Ptr", i64 }
  %l32 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i64
  %l39 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l73 = alloca %"compiler/eval:Ptr"
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3)
  store i32 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i32, ptr %l18, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load { i64, [4 x i64] }, ptr %l2
  %t16 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t10, i64 %t11, { i64, [4 x i64] } %t12, i64 1)
  store %"compiler/eval:Ptr" %t16, ptr %l23
  br label %bb2
bb2:
  %t17 = load i32, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l19, !tbaa !29
  %t19 = load %"compiler/eval:Ptr", ptr %l23
  %t21 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t18, %"compiler/eval:Ptr" %t19, i32 %t17)
  store { %"compiler/eval:Ptr", i64 } %t21, ptr %l25
  br label %bb3
bb3:
  %t22 = load { %"compiler/eval:Ptr", i64 }, ptr %l25
  store { %"compiler/eval:Ptr", i64 } %t22, ptr %l4
  %t23 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  store %"compiler/eval:Ptr" %t24, ptr %l5
  %t26 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 23
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb8
bb6:
  %t36 = mul i64 0, 1
  %t37 = insertvalue { i64, ptr } undef, i64 0, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9c6d2d38b14ece16_85850a0ccdf8ec6a)
  unreachable
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l33, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l36
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l33, !tbaa !29
  %t48 = load i32, ptr %l36, !tbaa !23
  %t49 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t47, i32 %t48)
  store i64 %t49, ptr %l37
  br label %bb10
bb10:
  %t50 = load i64, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l37, !tbaa !24
  %t52 = mul i64 %t50, %t51
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l39, !tbaa !24
  %t55 = load i64, ptr %l39, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = load i64, ptr %l39, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3e93cd40ddf47e2b_3ba0afa8b25b773f)
  unreachable
bb13:
  %t72 = load i64, ptr %l11, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb18
bb15:
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l11, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l49, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb17
bb17:
  %t92 = load i64, ptr %l49, !tbaa !24
  store i64 %t92, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t93 = load i64, ptr %l46, !tbaa !24
  store i64 %t93, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load i64, ptr %l13, !tbaa !24
  %t95 = load i64, ptr %l12, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l14, !tbaa !24
  %t112 = load i64, ptr %l14, !tbaa !24
  store i64 %t112, ptr %l67, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l68, !tbaa !29
  %t114 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t124 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t115, i64 %t121)
  store %"compiler/eval:Ptr" %t124, ptr %l73
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l68, !tbaa !29
  %t126 = load %"compiler/eval:Ptr", ptr %l73
  %t127 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t125, %"compiler/eval:Ptr" %t126, i64 1)
  store i64 %t127, ptr %l74
  br label %bb24
bb24:
  %t128 = load i64, ptr %l74, !tbaa !24
  %t129 = trunc i64 %t128 to i8
  %t131 = load i64, ptr %l67, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i8, ptr %t133, i64 %t131
  store i8 %t129, ptr %t134, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l13, !tbaa !24
  br label %bb19
bb26:
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallExtern(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, %"compiler/mir:Range" %a4, %"compiler/eval:Ptr" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca { %"compiler/eval:Ptr", i64 }
  %l31 = alloca %"compiler/eval:Ptr"
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca %"compiler/eval:Ptr"
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca %"compiler/eval:Ptr"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i8
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca %"compiler/eval:Ptr"
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l91 = alloca i32
  %l95 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l113 = alloca i1
  %l121 = alloca i1
  %l125 = alloca i1
  %l128 = alloca i1
  %l132 = alloca i1
  %l135 = alloca i1
  %l137 = alloca i1
  %l145 = alloca i64
  %l148 = alloca i64
  %l149 = alloca %"compiler/eval:Ptr"
  %l151 = alloca %"compiler/eval:Ptr"
  %l155 = alloca i64
  %l159 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i64
  %l194 = alloca { i64, [4 x i64] }
  %l199 = alloca i32
  %l200 = alloca { i64, ptr }
  %l206 = alloca i32
  %l210 = alloca i1
  %l211 = alloca i64
  %l214 = alloca i32
  %l215 = alloca i8
  %l219 = alloca i64
  %l223 = alloca i64
  %l230 = alloca i64
  %l240 = alloca i32
  %l243 = alloca i64
  %l247 = alloca i1
  %l251 = alloca ptr
  %l255 = alloca %"compiler/eval:Ptr"
  %l257 = alloca { %"compiler/eval:Ptr", i64 }
  %l262 = alloca i32
  %l265 = alloca i64
  %l267 = alloca i8
  %l273 = alloca i1
  %l274 = alloca i64
  %l277 = alloca i32
  %l278 = alloca i8
  %l281 = alloca i1
  %l282 = alloca i64
  %l284 = alloca i8
  %l290 = alloca i64
  %l291 = alloca i64
  %l294 = alloca i64
  %l296 = alloca i64
  %l299 = alloca i64
  %l305 = alloca ptr
  %l309 = alloca %"compiler/eval:Ptr"
  %l310 = alloca %"compiler/eval:Ptr"
  %l311 = alloca i64
  %l313 = alloca i8
  %l316 = alloca i1
  %l332 = alloca ptr
  %l335 = alloca i32
  %l336 = alloca i32
  %l339 = alloca i1
  %l342 = alloca i1
  %l343 = alloca i64
  %l345 = alloca i8
  %l348 = alloca i64
  %l351 = alloca i64
  %l352 = alloca i64
  %l355 = alloca i64
  %l367 = alloca i64
  %l375 = alloca i64
  %l378 = alloca i64
  %l403 = alloca i64
  %l405 = alloca i8
  %l407 = alloca i8
  %l409 = alloca i64
  %l412 = alloca i64
  %l416 = alloca i64
  %l423 = alloca i64
  %l426 = alloca i64
  %l444 = alloca ptr
  %l449 = alloca %"compiler/eval:Ptr"
  %l450 = alloca i64
  %l467 = alloca i64
  %l473 = alloca i64
  %l475 = alloca i64
  %l490 = alloca i1
  %l494 = alloca i8
  %l496 = alloca i8
  %l498 = alloca i8
  %l501 = alloca i32
  %l502 = alloca i8
  %l503 = alloca i64
  %l507 = alloca i64
  %l508 = alloca i32
  %l509 = alloca i64
  %l515 = alloca i64
  %l516 = alloca i32
  %l524 = alloca ptr
  %l525 = alloca i32
  %l530 = alloca i64
  %l533 = alloca i64
  %l559 = alloca { i64, ptr }
  %l569 = alloca i64
  %l572 = alloca i64
  %l590 = alloca ptr
  %l595 = alloca %"compiler/eval:Ptr"
  %l605 = alloca i64
  %l612 = alloca i64
  %l614 = alloca i64
  %l624 = alloca i1
  %l626 = alloca ptr
  %l627 = alloca %"compiler/eval:Ptr"
  %l630 = alloca %"compiler/eval:Ptr"
  %l635 = alloca %"compiler/eval:Ptr"
  %l637 = alloca i1
  %l641 = alloca i1
  %l645 = alloca ptr
  %l646 = alloca %"compiler/eval:Ptr"
  %l649 = alloca i64
  %s0 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca i1
  %t178 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  store %"compiler/eval:Ptr" %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l72
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l72, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 35
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l78
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb3, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l77
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t18, ptr %l73, !tbaa !27
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t21 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t21, ptr %t19, { i64, ptr } %t20)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t25 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t25, ptr %l8, !tbaa !27
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l9, !tbaa !29
  %t31 = load ptr, ptr %l9, !tbaa !29
  store ptr %t31, ptr %l84, !tbaa !29
  %t32 = load ptr, ptr %l9, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l87
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l84, !tbaa !29
  %t38 = load i32, ptr %l87, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t39, ptr %l88
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t40, ptr %l10, !tbaa !27
  %t41 = load ptr, ptr %l9, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l91
  br label %bb9
bb9:
  %t46 = load i32, ptr %l91, !tbaa !23
  store i32 %t46, ptr %l11, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 2}
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t61 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t55, i64 %t58)
  store i1 %t61, ptr %l99
  br label %bb12
bb11:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb13
bb12:
  %t62 = load i1, ptr %l99, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l95, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l95, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t68, ptr %l103
  br label %bb16
bb15:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb17
bb16:
  %t69 = load i1, ptr %l103, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l101, !tbaa !21
  br label %bb17
bb17:
  %t72 = load i1, ptr %l101, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t75, ptr %l107
  br label %bb20
bb19:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb21
bb20:
  %t76 = load i1, ptr %l107, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l105, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l105, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyExtern, !tbaa !27
  %t82 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t82, ptr %t80, { i64, ptr } %t81)
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t86 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t86, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t88, ptr %l113
  br label %bb26
bb26:
  %t89 = load i1, ptr %l113, !tbaa !21
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l1, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t93 = load %"compiler/mir:Range", ptr %l4
  %t94 = load i32, ptr %l3, !tbaa !23
  %t95 = load %"compiler/eval:Ptr", ptr %l5
  %t96 = load i1, ptr %l6, !tbaa !21
  %t104 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eruntimeFn(ptr %v0, ptr %v0, ptr %t90, i64 %t91, { i64, ptr } %t92, %"compiler/mir:Range" %t93, i32 %t94, %"compiler/eval:Ptr" %t95, i1 %t96)
  store i1 %t104, ptr %l121
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load i1, ptr %l121, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/eval:Machine", ptr %t106, i32 0, i32 1
  %t109 = load i32, ptr %t108, !range !{i32 0, i32 2}
  %t111 = trunc i64 1 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb31, label %bb32
bb31:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewaitsForTask(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t115)
  store i1 %t118, ptr %l128
  br label %bb33
bb32:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb34
bb33:
  %t119 = load i1, ptr %l128, !tbaa !21
  store i1 %t119, ptr %l125, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l125, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l11, !tbaa !23
  %t126 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eforeignRef(ptr %v0, ptr %t122, i32 %t123)
  store i1 %t126, ptr %l132
  br label %bb38
bb38:
  %t127 = load i1, ptr %l132, !tbaa !21
  store i1 %t127, ptr %l12, !tbaa !21
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l11, !tbaa !23
  %t132 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t128, i32 %t129, i1 true)
  store i1 %t132, ptr %l135
  br label %bb39
bb39:
  %t133 = load i1, ptr %l135, !tbaa !21
  %t134 = xor i1 %t133, true
  br i1 %t134, label %bb40, label %bb41
bb40:
  %t136 = load i1, ptr %l12, !tbaa !21
  %t138 = xor i1 %t136, true
  store i1 %t138, ptr %l137, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb42
bb42:
  %t140 = load i1, ptr %l137, !tbaa !21
  br i1 %t140, label %bb43, label %bb44
bb43:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t143 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t143, ptr %t141, { i64, ptr } %t142)
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb46:
  %t147 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = sext i32 %t148 to i64
  store i64 %t150, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  store i64 %t152, ptr %l145, !tbaa !24
  %t153 = load i64, ptr %l145, !tbaa !24
  %t154 = icmp sge i64 %t153, 0
  br i1 %t154, label %bb47, label %bb48
bb47:
  %t156 = load i64, ptr %l145, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l14, !tbaa !27
  %t162 = load i64, ptr %l13, !tbaa !24
  store i64 %t162, ptr %l148, !tbaa !24
  store %"compiler/eval:Ptr" zeroinitializer, ptr %l149
  %t163 = load i64, ptr %l148, !tbaa !24
  %t164 = icmp sgt i64 %t163, 0
  br i1 %t164, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8455ed81fb66a668_e2c955a612231684)
  unreachable
bb49:
  %t166 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 0, i64 0)
  store %"compiler/eval:Ptr" %t166, ptr %l151
  br label %bb51
bb50:
  %t167 = load i64, ptr %l148, !tbaa !24
  %t168 = icmp sge i64 %t167, 0
  br i1 %t168, label %bb52, label %bb53
bb51:
  %t170 = load %"compiler/eval:Ptr", ptr %l151
  store %"compiler/eval:Ptr" %t170, ptr %l149
  br label %bb50
bb52:
  %t171 = load i64, ptr %l148, !tbaa !24
  %t172 = icmp sle i64 %t171, 576460752303423487
  br i1 %t172, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e6f2fd943c115655_f5638f66c9629791)
  unreachable
bb54:
  %t174 = load i64, ptr %l148, !tbaa !24
  %t175 = mul i64 %t174, 16
  %t176 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t175)
  %t177 = load %"compiler/eval:Ptr", ptr %l149
  store i64 0, ptr %t178
  br label %fill.179
fill.179:
  %t182 = load i64, ptr %t178
  %t183 = icmp slt i64 %t182, %t174
  br i1 %t183, label %fillb.180, label %filld.181
fillb.180:
  %t184 = getelementptr %"compiler/eval:Ptr", ptr %t176, i64 %t182
  store %"compiler/eval:Ptr" %t177, ptr %t184
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %t178
  br label %fill.179
filld.181:
  %t186 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t176, 1
  store { i64, ptr } %t187, ptr %l15, !tbaa !27
  %t189 = load i64, ptr %l13, !tbaa !24
  store i64 %t189, ptr %l155, !tbaa !24
  %t190 = load i64, ptr %l155, !tbaa !24
  %t191 = icmp sge i64 %t190, 0
  br i1 %t191, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_e6f2fd943c115655_f5638f66c9629791)
  unreachable
bb56:
  %t193 = load i64, ptr %l155, !tbaa !24
  %t194 = icmp sle i64 %t193, 1152921504606846975
  br i1 %t194, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_24365dba12301136_85ae2e45ea64b572)
  unreachable
bb58:
  %t196 = load i64, ptr %l155, !tbaa !24
  %t197 = mul i64 %t196, 8
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l16, !tbaa !27
  %t202 = load i64, ptr %l13, !tbaa !24
  store i64 %t202, ptr %l159, !tbaa !24
  %t203 = load i64, ptr %l159, !tbaa !24
  %t204 = icmp sge i64 %t203, 0
  br i1 %t204, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_24365dba12301136_85ae2e45ea64b572)
  unreachable
bb60:
  %t206 = load i64, ptr %l159, !tbaa !24
  %t207 = icmp sle i64 %t206, 1152921504606846975
  br i1 %t207, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_e79146937ca231cb_dd9a37031fe8e967)
  unreachable
bb62:
  %t209 = load i64, ptr %l159, !tbaa !24
  %t210 = mul i64 %t209, 8
  %t211 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t215 = load i64, ptr %l13, !tbaa !24
  store i64 %t215, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t217 = load i64, ptr %l20, !tbaa !24
  %t218 = load i64, ptr %l19, !tbaa !24
  %t221 = icmp sgt i64 %t217, %t218
  br i1 %t221, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_e79146937ca231cb_dd9a37031fe8e967)
  unreachable
bb64:
  %t223 = load i64, ptr %l21, !tbaa !24
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb69
bb66:
  %t227 = load i64, ptr %l20, !tbaa !24
  %t228 = load i64, ptr %l19, !tbaa !24
  %t231 = sub i64 %t227, %t228
  %t232 = load i64, ptr %l21, !tbaa !24
  %t235 = add i64 %t231, %t232
  %t237 = sub i64 %t235, 1
  %t238 = load i64, ptr %l21, !tbaa !24
  %t241 = sdiv i64 %t237, %t238
  store i64 %t241, ptr %l170, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb68
bb68:
  %t243 = load i64, ptr %l170, !tbaa !24
  store i64 %t243, ptr %l167, !tbaa !24
  br label %bb69
bb69:
  %t244 = load i64, ptr %l167, !tbaa !24
  store i64 %t244, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb70
bb70:
  %t245 = load i64, ptr %l23, !tbaa !24
  %t246 = load i64, ptr %l22, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb71, label %bb72
bb71:
  br label %bb149
bb72:
  br label %bb73
bb73:
  %t253 = load i64, ptr %l19, !tbaa !24
  %t254 = load i64, ptr %l23, !tbaa !24
  %t255 = load i64, ptr %l21, !tbaa !24
  %t258 = mul i64 %t254, %t255
  %t261 = add i64 %t253, %t258
  store i64 %t261, ptr %l24, !tbaa !24
  %t263 = load ptr, ptr %l7, !tbaa !29
  %t265 = getelementptr %"compiler/mir:Fn", ptr %t263, i32 0, i32 11
  %t266 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t270 = load i64, ptr %l24, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t276 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t265, i64 %t273)
  store { i64, [4 x i64] } %t276, ptr %l194
  br label %bb74
bb74:
  %t277 = load { i64, [4 x i64] }, ptr %l194
  store { i64, [4 x i64] } %t277, ptr %l25
  %t278 = load i64, ptr %l24, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t284 = icmp slt i64 %t278, %t281
  br i1 %t284, label %bb75, label %bb76
bb75:
  %t286 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t286, ptr %l200, !tbaa !27
  %t287 = load i64, ptr %l24, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t287
  %t292 = load i32, ptr %t291, !tbaa !33
  store i32 %t292, ptr %l199, !tbaa !23
  br label %bb78
bb76:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l1, !tbaa !24
  %t296 = load { i64, [4 x i64] }, ptr %l25
  %t300 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t294, i64 %t295, { i64, [4 x i64] } %t296)
  store i32 %t300, ptr %l206
  br label %bb77
bb77:
  %t301 = load i32, ptr %l206, !tbaa !23
  store i32 %t301, ptr %l199, !tbaa !23
  br label %bb78
bb78:
  %t302 = load i32, ptr %l199, !tbaa !23
  store i32 %t302, ptr %l26, !tbaa !23
  %t303 = load i64, ptr %l24, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i64, ptr %t306, i64 %t303
  store i64 -1, ptr %t307, !tbaa !34
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i32, ptr %l26, !tbaa !23
  %t312 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t308, i32 %t309, i1 false)
  store i1 %t312, ptr %l210
  br label %bb79
bb79:
  %t313 = load i1, ptr %l210, !tbaa !21
  br i1 %t313, label %bb80, label %bb81
bb80:
  %t314 = load i64, ptr %l24, !tbaa !24
  store i64 %t314, ptr %l211, !tbaa !24
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i32, ptr %l26, !tbaa !23
  %t319 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %t315, i32 %t316)
  store i32 %t319, ptr %l214
  br label %bb82
bb81:
  br label %bb90
bb82:
  %t320 = load i32, ptr %l214, !range !{i32 0, i32 12}
  %t321 = call i8 @std_2fffi_2eCode(i32 %t320)
  store i8 %t321, ptr %l215
  br label %bb83
bb83:
  %t322 = load i8, ptr %l215, !tbaa !22
  %t323 = load i64, ptr %l211, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr i8, ptr %t325, i64 %t323
  store i8 %t322, ptr %t326, !tbaa !32
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i64, ptr %l1, !tbaa !24
  %t329 = load { i64, [4 x i64] }, ptr %l25
  %t333 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t327, i64 %t328, { i64, [4 x i64] } %t329)
  store i64 %t333, ptr %l219
  br label %bb84
bb84:
  %t334 = load i64, ptr %l219, !tbaa !24
  store i64 %t334, ptr %l27, !tbaa !65
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l26, !tbaa !23
  %t340 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t336, i32 %t337)
  store i64 %t340, ptr %l223
  br label %bb85
bb85:
  %t341 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t342 = load i64, ptr %l223, !tbaa !24
  %t344 = icmp eq i64 %t342, %t341
  br i1 %t344, label %bb86, label %bb87
bb86:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i64, ptr %l27, !tbaa !65
  %t349 = load i32, ptr %l26, !tbaa !23
  %t353 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t346, i64 %t347, i32 %t349)
  store i64 %t353, ptr %l230
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t354 = load i64, ptr %l230, !tbaa !24
  store i64 %t354, ptr %l27, !tbaa !65
  br label %bb89
bb89:
  %t356 = load i64, ptr %l24, !tbaa !24
  %t357 = load i64, ptr %l27, !tbaa !65
  %t360 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr i64, ptr %t361, i64 %t356
  store i64 %t357, ptr %t362, !tbaa !85
  %t363 = load i64, ptr %l18, !tbaa !24
  %t366 = add i64 %t363, 1
  store i64 %t366, ptr %l18, !tbaa !24
  br label %bb148
bb90:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i64, ptr %l1, !tbaa !24
  %t370 = load { i64, [4 x i64] }, ptr %l25
  %t374 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t368, i64 %t369, { i64, [4 x i64] } %t370)
  store i32 %t374, ptr %l240
  br label %bb91
bb91:
  %t375 = load i32, ptr %l240, !tbaa !23
  store i32 %t375, ptr %l28, !tbaa !23
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i32, ptr %l28, !tbaa !23
  %t380 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t376, i32 %t377)
  store i64 %t380, ptr %l243
  br label %bb92
bb92:
  %t381 = load i64, ptr %l243, !tbaa !24
  store i64 %t381, ptr %l29, !tbaa !24
  %t382 = load i64, ptr %l29, !tbaa !24
  %t383 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t386 = icmp eq i64 %t382, %t383
  br i1 %t386, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l247, !tbaa !21
  br label %bb95
bb94:
  %t388 = load i64, ptr %l29, !tbaa !24
  %t389 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t392 = icmp eq i64 %t388, %t389
  store i1 %t392, ptr %l247, !tbaa !21
  br label %bb95
bb95:
  %t394 = load i1, ptr %l247, !tbaa !21
  br i1 %t394, label %bb96, label %bb97
bb96:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l251, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load i64, ptr %l1, !tbaa !24
  %t398 = load { i64, [4 x i64] }, ptr %l25
  %t402 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t396, i64 %t397, { i64, [4 x i64] } %t398, i64 1)
  store %"compiler/eval:Ptr" %t402, ptr %l255
  br label %bb98
bb97:
  br label %bb119
bb98:
  %t403 = load i32, ptr %l28, !tbaa !23
  %t404 = load ptr, ptr %l251, !tbaa !29
  %t405 = load %"compiler/eval:Ptr", ptr %l255
  %t407 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t404, %"compiler/eval:Ptr" %t405, i32 %t403)
  store { %"compiler/eval:Ptr", i64 } %t407, ptr %l257
  br label %bb99
bb99:
  %t408 = load { %"compiler/eval:Ptr", i64 }, ptr %l257
  store { %"compiler/eval:Ptr", i64 } %t408, ptr %l30
  %t409 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l30, i32 0, i32 0
  %t410 = load %"compiler/eval:Ptr", ptr %t409
  store %"compiler/eval:Ptr" %t410, ptr %l31
  %t412 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l30, i32 0, i32 1
  %t413 = load i64, ptr %t412, !tbaa !24
  store i64 %t413, ptr %l32, !tbaa !24
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load i32, ptr %l28, !tbaa !23
  %t419 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t415, i32 %t416)
  store i32 %t419, ptr %l262
  br label %bb100
bb100:
  %t420 = load i32, ptr %l262, !tbaa !23
  store i32 %t420, ptr %l33, !tbaa !23
  %t421 = getelementptr %"compiler/eval:Ptr", ptr %l31, i32 0, i32 0
  %t422 = load i64, ptr %t421, !tbaa !24
  %t424 = icmp eq i64 %t422, 0
  br i1 %t424, label %bb101, label %bb102
bb101:
  %t426 = load i64, ptr %l24, !tbaa !24
  store i64 %t426, ptr %l265, !tbaa !24
  %t428 = call i8 @std_2fffi_2eCode(i32 7)
  store i8 %t428, ptr %l267
  br label %bb103
bb102:
  br label %bb104
bb103:
  %t429 = load i8, ptr %l267, !tbaa !22
  %t430 = load i64, ptr %l265, !tbaa !24
  %t431 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr i8, ptr %t432, i64 %t430
  store i8 %t429, ptr %t433, !tbaa !32
  %t434 = load i64, ptr %l18, !tbaa !24
  %t437 = add i64 %t434, 1
  store i64 %t437, ptr %l18, !tbaa !24
  br label %bb148
bb104:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i32, ptr %l33, !tbaa !23
  %t443 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t439, i32 %t440, i1 false)
  store i1 %t443, ptr %l273
  br label %bb105
bb105:
  %t444 = load i1, ptr %l273, !tbaa !21
  br i1 %t444, label %bb106, label %bb107
bb106:
  %t445 = load i64, ptr %l24, !tbaa !24
  store i64 %t445, ptr %l274, !tbaa !24
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i32, ptr %l33, !tbaa !23
  %t450 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %t446, i32 %t447)
  store i32 %t450, ptr %l277
  br label %bb108
bb107:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load i32, ptr %l33, !tbaa !23
  %t455 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %t451, i32 %t452)
  store i1 %t455, ptr %l281
  br label %bb110
bb108:
  %t456 = load i32, ptr %l277, !range !{i32 0, i32 12}
  %t457 = call i8 @std_2fffi_2eArrayOf(i32 %t456)
  store i8 %t457, ptr %l278
  br label %bb109
bb109:
  %t458 = load i8, ptr %l278, !tbaa !22
  %t459 = load i64, ptr %l274, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr i8, ptr %t461, i64 %t459
  store i8 %t458, ptr %t462, !tbaa !32
  br label %bb116
bb110:
  %t463 = load i1, ptr %l281, !tbaa !21
  br i1 %t463, label %bb111, label %bb112
bb111:
  %t464 = load i64, ptr %l24, !tbaa !24
  store i64 %t464, ptr %l282, !tbaa !24
  %t466 = call i8 @std_2fffi_2eArrayOf(i32 4)
  store i8 %t466, ptr %l284
  br label %bb113
bb112:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t469 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t469, ptr %t467, { i64, ptr } %t468)
  br label %bb114
bb113:
  %t472 = load i8, ptr %l284, !tbaa !22
  %t473 = load i64, ptr %l282, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr i8, ptr %t475, i64 %t473
  store i8 %t472, ptr %t476, !tbaa !32
  br label %bb115
bb114:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  %t478 = load i64, ptr %l24, !tbaa !24
  %t479 = load %"compiler/eval:Ptr", ptr %l31
  %t482 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr %"compiler/eval:Ptr", ptr %t483, i64 %t478
  store %"compiler/eval:Ptr" %t479, ptr %t484
  %t485 = load i64, ptr %l24, !tbaa !24
  store i64 %t485, ptr %l290, !tbaa !24
  %t486 = load i64, ptr %l32, !tbaa !24
  store i64 %t486, ptr %l291, !tbaa !24
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load i32, ptr %l33, !tbaa !23
  %t491 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t487, i32 %t488)
  store i64 %t491, ptr %l294
  br label %bb117
bb117:
  %t492 = load i64, ptr %l291, !tbaa !24
  %t493 = load i64, ptr %l294, !tbaa !24
  %t494 = mul i64 %t492, %t493
  %t496 = load i64, ptr %l290, !tbaa !24
  %t497 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !27
  %t499 = getelementptr i64, ptr %t498, i64 %t496
  store i64 %t494, ptr %t499, !tbaa !34
  %t500 = load i64, ptr %l18, !tbaa !24
  store i64 %t500, ptr %l296, !tbaa !24
  %t501 = load i64, ptr %l24, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr i64, ptr %t504, i64 %t501
  %t506 = load i64, ptr %t505, !tbaa !34
  %t508 = call i64 @std_2fffi_2eWordsFor(i64 %t506)
  store i64 %t508, ptr %l299
  br label %bb118
bb118:
  %t509 = load i64, ptr %l299, !tbaa !24
  %t510 = add i64 1, %t509
  %t511 = load i64, ptr %l296, !tbaa !24
  %t513 = add i64 %t511, %t510
  store i64 %t513, ptr %l18, !tbaa !24
  br label %bb148
bb119:
  %t515 = load i64, ptr %l29, !tbaa !24
  %t516 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t519 = icmp eq i64 %t515, %t516
  br i1 %t519, label %bb120, label %bb121
bb120:
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l305, !tbaa !29
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i64, ptr %l1, !tbaa !24
  %t524 = load { i64, [4 x i64] }, ptr %l25
  %t528 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t522, i64 %t523, { i64, [4 x i64] } %t524, i64 1)
  store %"compiler/eval:Ptr" %t528, ptr %l309
  br label %bb122
bb121:
  br label %bb146
bb122:
  %t529 = load ptr, ptr %l305, !tbaa !29
  %t530 = load %"compiler/eval:Ptr", ptr %l309
  %t531 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t529, %"compiler/eval:Ptr" %t530)
  store %"compiler/eval:Ptr" %t531, ptr %l310
  br label %bb123
bb123:
  %t532 = load %"compiler/eval:Ptr", ptr %l310
  store %"compiler/eval:Ptr" %t532, ptr %l34
  %t533 = load i64, ptr %l24, !tbaa !24
  store i64 %t533, ptr %l311, !tbaa !24
  %t535 = call i8 @std_2fffi_2eCode(i32 7)
  store i8 %t535, ptr %l313
  br label %bb124
bb124:
  %t536 = load i8, ptr %l313, !tbaa !22
  %t537 = load i64, ptr %l311, !tbaa !24
  %t538 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = getelementptr i8, ptr %t539, i64 %t537
  store i8 %t536, ptr %t540, !tbaa !32
  %t541 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t542 = load i64, ptr %t541, !tbaa !24
  %t544 = icmp eq i64 %t542, 0
  br i1 %t544, label %bb125, label %bb126
bb125:
  %t546 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 1
  %t547 = load i64, ptr %t546, !tbaa !24
  %t549 = icmp eq i64 %t547, 0
  store i1 %t549, ptr %l316, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l316, !tbaa !21
  br label %bb127
bb127:
  %t551 = load i1, ptr %l316, !tbaa !21
  br i1 %t551, label %bb128, label %bb129
bb128:
  %t552 = load i64, ptr %l24, !tbaa !24
  %t554 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr i64, ptr %t555, i64 %t552
  store i64 0, ptr %t556, !tbaa !85
  %t557 = load i64, ptr %l18, !tbaa !24
  %t560 = add i64 %t557, 1
  store i64 %t560, ptr %l18, !tbaa !24
  br label %bb148
bb129:
  br label %bb130
bb130:
  %t562 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t563 = load i64, ptr %t562, !tbaa !24
  %t564 = load i64, ptr @G_2ecompiler_2feval_2eForeignId, !tbaa !24
  %t567 = icmp eq i64 %t563, %t564
  br i1 %t567, label %bb131, label %bb132
bb131:
  %t569 = load i64, ptr %l24, !tbaa !24
  %t570 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 1
  %t571 = load i64, ptr %t570, !tbaa !24
  %t575 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = getelementptr i64, ptr %t576, i64 %t569
  store i64 %t571, ptr %t577, !tbaa !85
  %t578 = load i64, ptr %l18, !tbaa !24
  %t581 = add i64 %t578, 1
  store i64 %t581, ptr %l18, !tbaa !24
  br label %bb148
bb132:
  br label %bb133
bb133:
  %t583 = load ptr, ptr %l9, !tbaa !29
  store ptr %t583, ptr %l332, !tbaa !29
  %t584 = load ptr, ptr %l9, !tbaa !29
  %t585 = load i32, ptr %l28, !tbaa !23
  %t588 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t584, i32 %t585)
  store i32 %t588, ptr %l335
  br label %bb134
bb134:
  %t589 = load ptr, ptr %l332, !tbaa !29
  %t590 = load i32, ptr %l335, !tbaa !23
  %t591 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t589, i32 %t590)
  store i32 %t591, ptr %l336
  br label %bb135
bb135:
  %t592 = load i32, ptr %l336, !tbaa !23
  store i32 %t592, ptr %l35, !tbaa !23
  %t593 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t594 = load i64, ptr %t593, !tbaa !24
  %t596 = icmp ne i64 %t594, 0
  br i1 %t596, label %bb136, label %bb137
bb136:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load i32, ptr %l35, !tbaa !23
  %t602 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %t598, i32 %t599)
  store i1 %t602, ptr %l342
  br label %bb138
bb137:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb139
bb138:
  %t603 = load i1, ptr %l342, !tbaa !21
  store i1 %t603, ptr %l339, !tbaa !21
  br label %bb139
bb139:
  %t604 = load i1, ptr %l339, !tbaa !21
  br i1 %t604, label %bb140, label %bb141
bb140:
  %t605 = load i64, ptr %l24, !tbaa !24
  store i64 %t605, ptr %l343, !tbaa !24
  %t607 = call i8 @std_2fffi_2eArrayOf(i32 4)
  store i8 %t607, ptr %l345
  br label %bb142
bb141:
  br label %bb145
bb142:
  %t608 = load i8, ptr %l345, !tbaa !22
  %t609 = load i64, ptr %l343, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr i8, ptr %t611, i64 %t609
  store i8 %t608, ptr %t612, !tbaa !32
  %t613 = load i64, ptr %l24, !tbaa !24
  %t614 = load %"compiler/eval:Ptr", ptr %l34
  %t617 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t618 = load ptr, ptr %t617, !tbaa !27
  %t619 = getelementptr %"compiler/eval:Ptr", ptr %t618, i64 %t613
  store %"compiler/eval:Ptr" %t614, ptr %t619
  %t620 = load i64, ptr %l24, !tbaa !24
  store i64 %t620, ptr %l348, !tbaa !24
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load i32, ptr %l35, !tbaa !23
  %t625 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t621, i32 %t622)
  store i64 %t625, ptr %l351
  br label %bb143
bb143:
  %t626 = load i64, ptr %l351, !tbaa !24
  %t627 = load i64, ptr %l348, !tbaa !24
  %t628 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !27
  %t630 = getelementptr i64, ptr %t629, i64 %t627
  store i64 %t626, ptr %t630, !tbaa !34
  %t631 = load i64, ptr %l18, !tbaa !24
  store i64 %t631, ptr %l352, !tbaa !24
  %t632 = load i64, ptr %l24, !tbaa !24
  %t634 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t635 = load ptr, ptr %t634, !tbaa !27
  %t636 = getelementptr i64, ptr %t635, i64 %t632
  %t637 = load i64, ptr %t636, !tbaa !34
  %t639 = call i64 @std_2fffi_2eWordsFor(i64 %t637)
  store i64 %t639, ptr %l355
  br label %bb144
bb144:
  %t640 = load i64, ptr %l355, !tbaa !24
  %t641 = add i64 1, %t640
  %t642 = load i64, ptr %l352, !tbaa !24
  %t644 = add i64 %t642, %t641
  store i64 %t644, ptr %l18, !tbaa !24
  br label %bb148
bb145:
  br label %bb146
bb146:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t648 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t648, ptr %t646, { i64, ptr } %t647)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb148:
  %t652 = load i64, ptr %l23, !tbaa !24
  %t655 = add i64 %t652, 1
  store i64 %t655, ptr %l23, !tbaa !24
  br label %bb70
bb149:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/eval:Machine", ptr %t657, i32 0, i32 23
  %t660 = load i1, ptr %t659, !tbaa !21
  br i1 %t660, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb151:
  br label %bb152
bb152:
  %t663 = load i64, ptr %l18, !tbaa !24
  store i64 %t663, ptr %l367, !tbaa !24
  %t664 = load i64, ptr %l367, !tbaa !24
  %t665 = icmp sge i64 %t664, 0
  br i1 %t665, label %bb153, label %bb154
bb153:
  %t667 = load i64, ptr %l367, !tbaa !24
  %t668 = icmp sle i64 %t667, 1152921504606846975
  br i1 %t668, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_84b043302e365534_8c4896c766887f8)
  unreachable
bb155:
  %t670 = load i64, ptr %l367, !tbaa !24
  %t671 = mul i64 %t670, 8
  %t672 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t671)
  %t673 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t672, 1
  store { i64, ptr } %t674, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  %t676 = load i64, ptr %l13, !tbaa !24
  store i64 %t676, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t678 = load i64, ptr %l39, !tbaa !24
  %t679 = load i64, ptr %l38, !tbaa !24
  %t682 = icmp sgt i64 %t678, %t679
  br i1 %t682, label %bb157, label %bb158
bb156:
  call void @__olang_check_failed(ptr @olang_loc_84b043302e365534_8c4896c766887f8)
  unreachable
bb157:
  %t684 = load i64, ptr %l40, !tbaa !24
  %t686 = icmp sgt i64 %t684, 0
  br i1 %t686, label %bb159, label %bb160
bb158:
  store i64 0, ptr %l375, !tbaa !24
  br label %bb162
bb159:
  %t688 = load i64, ptr %l39, !tbaa !24
  %t689 = load i64, ptr %l38, !tbaa !24
  %t692 = sub i64 %t688, %t689
  %t693 = load i64, ptr %l40, !tbaa !24
  %t696 = add i64 %t692, %t693
  %t698 = sub i64 %t696, 1
  %t699 = load i64, ptr %l40, !tbaa !24
  %t702 = sdiv i64 %t698, %t699
  store i64 %t702, ptr %l378, !tbaa !24
  br label %bb161
bb160:
  store i64 0, ptr %l378, !tbaa !24
  br label %bb161
bb161:
  %t704 = load i64, ptr %l378, !tbaa !24
  store i64 %t704, ptr %l375, !tbaa !24
  br label %bb162
bb162:
  %t705 = load i64, ptr %l375, !tbaa !24
  store i64 %t705, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb163
bb163:
  %t706 = load i64, ptr %l42, !tbaa !24
  %t707 = load i64, ptr %l41, !tbaa !24
  %t710 = icmp slt i64 %t706, %t707
  %t712 = xor i1 %t710, true
  br i1 %t712, label %bb164, label %bb165
bb164:
  br label %bb191
bb165:
  br label %bb166
bb166:
  %t714 = load i64, ptr %l38, !tbaa !24
  %t715 = load i64, ptr %l42, !tbaa !24
  %t716 = load i64, ptr %l40, !tbaa !24
  %t719 = mul i64 %t715, %t716
  %t722 = add i64 %t714, %t719
  store i64 %t722, ptr %l43, !tbaa !24
  %t724 = load i64, ptr %l43, !tbaa !24
  %t726 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = getelementptr i64, ptr %t727, i64 %t724
  %t729 = load i64, ptr %t728, !tbaa !34
  %t731 = icmp sge i64 %t729, 0
  br i1 %t731, label %bb167, label %bb168
bb167:
  %t733 = load i64, ptr %l43, !tbaa !24
  %t735 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t736 = load ptr, ptr %t735, !tbaa !27
  %t737 = getelementptr %"compiler/eval:Ptr", ptr %t736, i64 %t733
  %t738 = load %"compiler/eval:Ptr", ptr %t737
  store %"compiler/eval:Ptr" %t738, ptr %l44
  %t740 = load i64, ptr %l43, !tbaa !24
  %t742 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t743 = load ptr, ptr %t742, !tbaa !27
  %t744 = getelementptr i64, ptr %t743, i64 %t740
  %t745 = load i64, ptr %t744, !tbaa !34
  store i64 %t745, ptr %l45, !tbaa !24
  %t747 = load i64, ptr %l37, !tbaa !24
  store i64 %t747, ptr %l403, !tbaa !24
  %t748 = load i64, ptr %l43, !tbaa !24
  %t750 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t751 = load ptr, ptr %t750, !tbaa !27
  %t752 = getelementptr i8, ptr %t751, i64 %t748
  %t753 = load i8, ptr %t752, !tbaa !32
  store i8 %t753, ptr %l405, !tbaa !22
  %t755 = call i8 @std_2fffi_2eArrayOf(i32 4)
  store i8 %t755, ptr %l407
  br label %bb169
bb168:
  %t756 = load i64, ptr %l37, !tbaa !24
  %t757 = load i64, ptr %l43, !tbaa !24
  %t759 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr i64, ptr %t760, i64 %t757
  %t762 = load i64, ptr %t761, !tbaa !85
  %t765 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t766 = load ptr, ptr %t765, !tbaa !27
  %t767 = getelementptr i64, ptr %t766, i64 %t756
  store i64 %t762, ptr %t767, !tbaa !85
  %t768 = load i64, ptr %l37, !tbaa !24
  %t771 = add i64 %t768, 1
  store i64 %t771, ptr %l37, !tbaa !24
  br label %bb189
bb169:
  %t773 = load i8, ptr %l405, !tbaa !22
  %t774 = load i8, ptr %l407, !tbaa !22
  %t775 = icmp eq i8 %t773, %t774
  br i1 %t775, label %bb170, label %bb171
bb170:
  %t777 = load i64, ptr %l45, !tbaa !24
  store i64 %t777, ptr %l409, !tbaa !65
  br label %bb173
bb171:
  %t780 = load i64, ptr %l45, !tbaa !24
  store i64 %t780, ptr %l412, !tbaa !24
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t782 = load i64, ptr %l43, !tbaa !24
  %t784 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t785 = load ptr, ptr %t784, !tbaa !27
  %t786 = getelementptr i8, ptr %t785, i64 %t782
  %t787 = load i8, ptr %t786, !tbaa !32
  %t790 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ekindWidth(ptr %v0, ptr %t781, i8 %t787)
  store i64 %t790, ptr %l416
  br label %bb172
bb172:
  %t791 = load i64, ptr %l412, !tbaa !24
  %t792 = load i64, ptr %l416, !tbaa !24
  %t793 = sdiv i64 %t791, %t792
  store i64 %t793, ptr %l409, !tbaa !65
  br label %bb173
bb173:
  %t796 = load i64, ptr %l409, !tbaa !65
  %t797 = load i64, ptr %l403, !tbaa !24
  %t798 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t799 = load ptr, ptr %t798, !tbaa !27
  %t800 = getelementptr i64, ptr %t799, i64 %t797
  store i64 %t796, ptr %t800, !tbaa !85
  store i64 0, ptr %l46, !tbaa !24
  %t801 = load i64, ptr %l45, !tbaa !24
  store i64 %t801, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t803 = load i64, ptr %l47, !tbaa !24
  %t804 = load i64, ptr %l46, !tbaa !24
  %t807 = icmp sgt i64 %t803, %t804
  br i1 %t807, label %bb174, label %bb175
bb174:
  %t809 = load i64, ptr %l48, !tbaa !24
  %t811 = icmp sgt i64 %t809, 0
  br i1 %t811, label %bb176, label %bb177
bb175:
  store i64 0, ptr %l423, !tbaa !24
  br label %bb179
bb176:
  %t813 = load i64, ptr %l47, !tbaa !24
  %t814 = load i64, ptr %l46, !tbaa !24
  %t817 = sub i64 %t813, %t814
  %t818 = load i64, ptr %l48, !tbaa !24
  %t821 = add i64 %t817, %t818
  %t823 = sub i64 %t821, 1
  %t824 = load i64, ptr %l48, !tbaa !24
  %t827 = sdiv i64 %t823, %t824
  store i64 %t827, ptr %l426, !tbaa !24
  br label %bb178
bb177:
  store i64 0, ptr %l426, !tbaa !24
  br label %bb178
bb178:
  %t829 = load i64, ptr %l426, !tbaa !24
  store i64 %t829, ptr %l423, !tbaa !24
  br label %bb179
bb179:
  %t830 = load i64, ptr %l423, !tbaa !24
  store i64 %t830, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s26
  %t831 = load i64, ptr %l50, !tbaa !24
  %t832 = load i64, ptr %l49, !tbaa !24
  %t835 = icmp slt i64 %t831, %t832
  %t837 = xor i1 %t835, true
  br i1 %t837, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s26)
  br label %bb187
bb182:
  br label %bb183
bb183:
  %t839 = load i64, ptr %l46, !tbaa !24
  %t840 = load i64, ptr %l50, !tbaa !24
  %t841 = load i64, ptr %l48, !tbaa !24
  %t844 = mul i64 %t840, %t841
  %t847 = add i64 %t839, %t844
  store i64 %t847, ptr %l51, !tbaa !24
  %t849 = load ptr, ptr %l0, !tbaa !29
  store ptr %t849, ptr %l444, !tbaa !29
  %t850 = getelementptr %"compiler/eval:Ptr", ptr %l44, i32 0, i32 0
  %t851 = load i64, ptr %t850, !tbaa !24
  %t852 = getelementptr %"compiler/eval:Ptr", ptr %l44, i32 0, i32 1
  %t853 = load i64, ptr %t852, !tbaa !24
  %t854 = load i64, ptr %l51, !tbaa !24
  %t857 = add i64 %t853, %t854
  %t860 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 %t851, i64 %t857)
  store %"compiler/eval:Ptr" %t860, ptr %l449
  br label %bb184
bb184:
  %t861 = load ptr, ptr %l444, !tbaa !29
  %t862 = load %"compiler/eval:Ptr", ptr %l449
  %t863 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t861, %"compiler/eval:Ptr" %t862, i64 1)
  store i64 %t863, ptr %l450
  br label %bb185
bb185:
  %t864 = load i64, ptr %l450, !tbaa !24
  %t866 = load i64, ptr %l37, !tbaa !24
  %t868 = add i64 %t866, 1
  %t869 = load i64, ptr %l51, !tbaa !24
  %t871 = sdiv i64 %t869, 8
  %t874 = add i64 %t868, %t871
  %t875 = load i64, ptr %l37, !tbaa !24
  %t877 = add i64 %t875, 1
  %t878 = load i64, ptr %l51, !tbaa !24
  %t880 = sdiv i64 %t878, 8
  %t883 = add i64 %t877, %t880
  %t885 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t886 = load ptr, ptr %t885, !tbaa !27
  %t887 = getelementptr i64, ptr %t886, i64 %t883
  %t888 = load i64, ptr %t887, !tbaa !85
  %t890 = load i64, ptr %l51, !tbaa !24
  %t892 = srem i64 %t890, 8
  %t895 = mul i64 %t892, 8
  store i64 %t895, ptr %l467, !tbaa !65
  %t897 = load i64, ptr %l467, !tbaa !65
  %t898 = load i64, ptr %l467, !tbaa !65
  %t899 = shl i64 %t864, %t898
  %t902 = or i64 %t888, %t899
  %t905 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t906 = load ptr, ptr %t905, !tbaa !27
  %t907 = getelementptr i64, ptr %t906, i64 %t874
  store i64 %t902, ptr %t907, !tbaa !85
  call void @__olang_scope_close(ptr %s26)
  br label %bb186
bb186:
  %t908 = load i64, ptr %l50, !tbaa !24
  %t911 = add i64 %t908, 1
  store i64 %t911, ptr %l50, !tbaa !24
  br label %bb180
bb187:
  %t913 = load i64, ptr %l37, !tbaa !24
  store i64 %t913, ptr %l473, !tbaa !24
  %t914 = load i64, ptr %l45, !tbaa !24
  %t916 = call i64 @std_2fffi_2eWordsFor(i64 %t914)
  store i64 %t916, ptr %l475
  br label %bb188
bb188:
  %t917 = load i64, ptr %l475, !tbaa !24
  %t918 = add i64 1, %t917
  %t919 = load i64, ptr %l473, !tbaa !24
  %t921 = add i64 %t919, %t918
  store i64 %t921, ptr %l37, !tbaa !24
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t923 = load i64, ptr %l42, !tbaa !24
  %t926 = add i64 %t923, 1
  store i64 %t926, ptr %l42, !tbaa !24
  br label %bb163
bb191:
  %t928 = load i32, ptr %l11, !tbaa !23
  %t929 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t932 = icmp eq i32 %t928, %t929
  br i1 %t932, label %bb192, label %bb193
bb192:
  store i1 true, ptr %l490, !tbaa !21
  br label %bb194
bb193:
  %t934 = load i32, ptr %l11, !tbaa !23
  %t935 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t938 = icmp eq i32 %t934, %t935
  store i1 %t938, ptr %l490, !tbaa !21
  br label %bb194
bb194:
  %t940 = load i1, ptr %l490, !tbaa !21
  br i1 %t940, label %bb195, label %bb196
bb195:
  store i8 0, ptr %l494, !tbaa !22
  br label %bb203
bb196:
  %t941 = load i1, ptr %l12, !tbaa !21
  br i1 %t941, label %bb197, label %bb198
bb197:
  %t944 = call i8 @std_2fffi_2eCode(i32 7)
  store i8 %t944, ptr %l498
  br label %bb199
bb198:
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t946 = load i32, ptr %l11, !tbaa !23
  %t949 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %t945, i32 %t946)
  store i32 %t949, ptr %l501
  br label %bb200
bb199:
  %t950 = load i8, ptr %l498, !tbaa !22
  store i8 %t950, ptr %l496, !tbaa !22
  br label %bb202
bb200:
  %t951 = load i32, ptr %l501, !range !{i32 0, i32 12}
  %t952 = call i8 @std_2fffi_2eCode(i32 %t951)
  store i8 %t952, ptr %l502
  br label %bb201
bb201:
  %t953 = load i8, ptr %l502, !tbaa !22
  store i8 %t953, ptr %l496, !tbaa !22
  br label %bb202
bb202:
  %t954 = load i8, ptr %l496, !tbaa !22
  store i8 %t954, ptr %l494, !tbaa !22
  br label %bb203
bb203:
  %t955 = load i8, ptr %l494, !tbaa !22
  store i8 %t955, ptr %l53, !tbaa !22
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t958 = getelementptr %"compiler/eval:Machine", ptr %t956, i32 0, i32 36
  %t959 = load i64, ptr %l2, !tbaa !24
  %t962 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t958, i64 %t959)
  %t963 = extractvalue { i32, i64 } %t962, 1
  %t964 = extractvalue { i32, i64 } %t962, 0
  store i32 %t964, ptr %l508
  %t965 = icmp ne i32 %t964, 0
  br i1 %t965, label %bb205, label %ok.966, !prof !99
ok.966:
  store i64 %t963, ptr %l507
  br label %bb204
bb204:
  %t967 = load i64, ptr %l507, !tbaa !24
  store i64 %t967, ptr %l503, !tbaa !24
  br label %bb207
bb205:
  br label %bb206
bb206:
  store i64 -1, ptr %l503, !tbaa !24
  br label %bb207
bb207:
  %t968 = load i64, ptr %l503, !tbaa !24
  %t969 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t970 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t971 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t972 = load i8, ptr %l53, !tbaa !22
  %t979 = call { i32, i64 } @std_2fffi_2eCall(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t969, { i64, ptr } %t970, { i64, ptr } %t971, i8 %t972, i64 %t968)
  %t980 = extractvalue { i32, i64 } %t979, 1
  %t981 = extractvalue { i32, i64 } %t979, 0
  store i32 %t981, ptr %l516
  %t982 = icmp ne i32 %t981, 0
  br i1 %t982, label %bb209, label %ok.983, !prof !99
ok.983:
  store i64 %t980, ptr %l515
  br label %bb208
bb208:
  %t984 = load i64, ptr %l515, !tbaa !65
  store i64 %t984, ptr %l509, !tbaa !65
  br label %bb216
bb209:
  %t985 = load i32, ptr %l516, !tbaa !23
  %t986 = icmp eq i32 %t985, 65536
  br i1 %t986, label %bb210, label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb213
bb212:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiFind, !tbaa !27
  %t990 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t990, ptr %t988, { i64, ptr } %t989)
  br label %bb214
bb213:
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t995 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t995, ptr %t993, { i64, ptr } %t994)
  br label %bb215
bb214:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb215:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb216:
  %t1000 = load i64, ptr %l509, !tbaa !65
  store i64 %t1000, ptr %l55, !tbaa !65
  %t1001 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1001, ptr %l524, !tbaa !29
  %t1002 = call i32 @__olang_err()
  store i32 %t1002, ptr %l525
  br label %bb217
bb217:
  %t1003 = load i32, ptr %l525, !tbaa !23
  %t1004 = load ptr, ptr %l524, !tbaa !29
  %t1005 = getelementptr %"compiler/eval:Machine", ptr %t1004, i32 0, i32 95
  store i32 %t1003, ptr %t1005, !tbaa !23
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  %t1006 = load i64, ptr %l13, !tbaa !24
  store i64 %t1006, ptr %l57, !tbaa !24
  store i64 1, ptr %l58, !tbaa !24
  %t1008 = load i64, ptr %l57, !tbaa !24
  %t1009 = load i64, ptr %l56, !tbaa !24
  %t1012 = icmp sgt i64 %t1008, %t1009
  br i1 %t1012, label %bb218, label %bb219
bb218:
  %t1014 = load i64, ptr %l58, !tbaa !24
  %t1016 = icmp sgt i64 %t1014, 0
  br i1 %t1016, label %bb220, label %bb221
bb219:
  store i64 0, ptr %l530, !tbaa !24
  br label %bb223
bb220:
  %t1018 = load i64, ptr %l57, !tbaa !24
  %t1019 = load i64, ptr %l56, !tbaa !24
  %t1022 = sub i64 %t1018, %t1019
  %t1023 = load i64, ptr %l58, !tbaa !24
  %t1026 = add i64 %t1022, %t1023
  %t1028 = sub i64 %t1026, 1
  %t1029 = load i64, ptr %l58, !tbaa !24
  %t1032 = sdiv i64 %t1028, %t1029
  store i64 %t1032, ptr %l533, !tbaa !24
  br label %bb222
bb221:
  store i64 0, ptr %l533, !tbaa !24
  br label %bb222
bb222:
  %t1034 = load i64, ptr %l533, !tbaa !24
  store i64 %t1034, ptr %l530, !tbaa !24
  br label %bb223
bb223:
  %t1035 = load i64, ptr %l530, !tbaa !24
  store i64 %t1035, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb224
bb224:
  %t1036 = load i64, ptr %l60, !tbaa !24
  %t1037 = load i64, ptr %l59, !tbaa !24
  %t1040 = icmp slt i64 %t1036, %t1037
  %t1042 = xor i1 %t1040, true
  br i1 %t1042, label %bb225, label %bb226
bb225:
  br label %bb250
bb226:
  br label %bb227
bb227:
  %t1044 = load i64, ptr %l56, !tbaa !24
  %t1045 = load i64, ptr %l60, !tbaa !24
  %t1046 = load i64, ptr %l58, !tbaa !24
  %t1049 = mul i64 %t1045, %t1046
  %t1052 = add i64 %t1044, %t1049
  store i64 %t1052, ptr %l61, !tbaa !24
  %t1054 = load i64, ptr %l61, !tbaa !24
  %t1056 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t1057 = load ptr, ptr %t1056, !tbaa !27
  %t1058 = getelementptr i64, ptr %t1057, i64 %t1054
  %t1059 = load i64, ptr %t1058, !tbaa !34
  %t1061 = icmp sge i64 %t1059, 0
  br i1 %t1061, label %bb228, label %bb229
bb228:
  %t1063 = load i64, ptr %l61, !tbaa !24
  %t1065 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t1066 = load ptr, ptr %t1065, !tbaa !27
  %t1067 = getelementptr %"compiler/eval:Ptr", ptr %t1066, i64 %t1063
  %t1068 = load %"compiler/eval:Ptr", ptr %t1067
  store %"compiler/eval:Ptr" %t1068, ptr %l62
  %t1070 = load i64, ptr %l61, !tbaa !24
  %t1072 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t1073 = load ptr, ptr %t1072, !tbaa !27
  %t1074 = getelementptr i64, ptr %t1073, i64 %t1070
  %t1075 = load i64, ptr %t1074, !tbaa !34
  store i64 %t1075, ptr %l63, !tbaa !24
  %t1077 = load ptr, ptr %l0, !tbaa !29
  %t1079 = getelementptr %"compiler/eval:Machine", ptr %t1077, i32 0, i32 50
  %t1080 = load { i64, ptr }, ptr %t1079, !tbaa !27
  store { i64, ptr } %t1080, ptr %l559, !tbaa !27
  %t1081 = getelementptr %"compiler/eval:Ptr", ptr %l62, i32 0, i32 0
  %t1082 = load i64, ptr %t1081, !tbaa !24
  %t1083 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t1086 = and i64 %t1082, %t1083
  %t1088 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t1089 = load ptr, ptr %t1088, !tbaa !27
  %t1090 = getelementptr %"compiler/eval:alloc", ptr %t1089, i64 %t1086
  %t1091 = getelementptr %"compiler/eval:alloc", ptr %t1090, i32 0, i32 13
  %t1092 = load i1, ptr %t1091, !tbaa !21
  %t1094 = icmp eq i1 %t1092, false
  br i1 %t1094, label %bb230, label %bb231
bb229:
  %t1096 = load i64, ptr %l37, !tbaa !24
  %t1099 = add i64 %t1096, 1
  store i64 %t1099, ptr %l37, !tbaa !24
  br label %bb248
bb230:
  store i64 0, ptr %l64, !tbaa !24
  %t1101 = load i64, ptr %l63, !tbaa !24
  store i64 %t1101, ptr %l65, !tbaa !24
  store i64 1, ptr %l66, !tbaa !24
  %t1103 = load i64, ptr %l65, !tbaa !24
  %t1104 = load i64, ptr %l64, !tbaa !24
  %t1107 = icmp sgt i64 %t1103, %t1104
  br i1 %t1107, label %bb232, label %bb233
bb231:
  br label %bb246
bb232:
  %t1109 = load i64, ptr %l66, !tbaa !24
  %t1111 = icmp sgt i64 %t1109, 0
  br i1 %t1111, label %bb234, label %bb235
bb233:
  store i64 0, ptr %l569, !tbaa !24
  br label %bb237
bb234:
  %t1113 = load i64, ptr %l65, !tbaa !24
  %t1114 = load i64, ptr %l64, !tbaa !24
  %t1117 = sub i64 %t1113, %t1114
  %t1118 = load i64, ptr %l66, !tbaa !24
  %t1121 = add i64 %t1117, %t1118
  %t1123 = sub i64 %t1121, 1
  %t1124 = load i64, ptr %l66, !tbaa !24
  %t1127 = sdiv i64 %t1123, %t1124
  store i64 %t1127, ptr %l572, !tbaa !24
  br label %bb236
bb235:
  store i64 0, ptr %l572, !tbaa !24
  br label %bb236
bb236:
  %t1129 = load i64, ptr %l572, !tbaa !24
  store i64 %t1129, ptr %l569, !tbaa !24
  br label %bb237
bb237:
  %t1130 = load i64, ptr %l569, !tbaa !24
  store i64 %t1130, ptr %l67, !tbaa !24
  store i64 0, ptr %l68, !tbaa !24
  br label %bb238
bb238:
  store %olang.scope zeroinitializer, ptr %s37
  %t1131 = load i64, ptr %l68, !tbaa !24
  %t1132 = load i64, ptr %l67, !tbaa !24
  %t1135 = icmp slt i64 %t1131, %t1132
  %t1137 = xor i1 %t1135, true
  br i1 %t1137, label %bb239, label %bb240
bb239:
  call void @__olang_scope_close(ptr %s37)
  br label %bb245
bb240:
  br label %bb241
bb241:
  %t1139 = load i64, ptr %l64, !tbaa !24
  %t1140 = load i64, ptr %l68, !tbaa !24
  %t1141 = load i64, ptr %l66, !tbaa !24
  %t1144 = mul i64 %t1140, %t1141
  %t1147 = add i64 %t1139, %t1144
  store i64 %t1147, ptr %l69, !tbaa !24
  %t1149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1149, ptr %l590, !tbaa !29
  %t1150 = getelementptr %"compiler/eval:Ptr", ptr %l62, i32 0, i32 0
  %t1151 = load i64, ptr %t1150, !tbaa !24
  %t1152 = getelementptr %"compiler/eval:Ptr", ptr %l62, i32 0, i32 1
  %t1153 = load i64, ptr %t1152, !tbaa !24
  %t1154 = load i64, ptr %l69, !tbaa !24
  %t1157 = add i64 %t1153, %t1154
  %t1160 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s37, i64 %t1151, i64 %t1157)
  store %"compiler/eval:Ptr" %t1160, ptr %l595
  br label %bb242
bb242:
  %t1161 = load i64, ptr %l37, !tbaa !24
  %t1163 = add i64 %t1161, 1
  %t1164 = load i64, ptr %l69, !tbaa !24
  %t1166 = sdiv i64 %t1164, 8
  %t1169 = add i64 %t1163, %t1166
  %t1171 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t1172 = load ptr, ptr %t1171, !tbaa !27
  %t1173 = getelementptr i64, ptr %t1172, i64 %t1169
  %t1174 = load i64, ptr %t1173, !tbaa !85
  %t1175 = load i64, ptr %l69, !tbaa !24
  %t1177 = srem i64 %t1175, 8
  %t1180 = mul i64 %t1177, 8
  store i64 %t1180, ptr %l605, !tbaa !65
  %t1182 = load i64, ptr %l605, !tbaa !65
  %t1183 = load i64, ptr %l605, !tbaa !65
  %t1184 = lshr i64 %t1174, %t1183
  %t1186 = and i64 %t1184, 255
  %t1188 = load ptr, ptr %l590, !tbaa !29
  %t1189 = load %"compiler/eval:Ptr", ptr %l595
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1188, %"compiler/eval:Ptr" %t1189, i64 1, i64 %t1186)
  br label %bb243
bb243:
  call void @__olang_scope_close(ptr %s37)
  br label %bb244
bb244:
  %t1191 = load i64, ptr %l68, !tbaa !24
  %t1194 = add i64 %t1191, 1
  store i64 %t1194, ptr %l68, !tbaa !24
  br label %bb238
bb245:
  br label %bb246
bb246:
  %t1196 = load i64, ptr %l37, !tbaa !24
  store i64 %t1196, ptr %l612, !tbaa !24
  %t1197 = load i64, ptr %l63, !tbaa !24
  %t1199 = call i64 @std_2fffi_2eWordsFor(i64 %t1197)
  store i64 %t1199, ptr %l614
  br label %bb247
bb247:
  %t1200 = load i64, ptr %l614, !tbaa !24
  %t1201 = add i64 1, %t1200
  %t1202 = load i64, ptr %l612, !tbaa !24
  %t1204 = add i64 %t1202, %t1201
  store i64 %t1204, ptr %l37, !tbaa !24
  br label %bb248
bb248:
  br label %bb249
bb249:
  %t1206 = load i64, ptr %l60, !tbaa !24
  %t1209 = add i64 %t1206, 1
  store i64 %t1209, ptr %l60, !tbaa !24
  br label %bb224
bb250:
  %t1211 = load i1, ptr %l6, !tbaa !21
  br i1 %t1211, label %bb251, label %bb252
bb251:
  %t1213 = load i1, ptr %l12, !tbaa !21
  store i1 %t1213, ptr %l624, !tbaa !21
  br label %bb253
bb252:
  store i1 false, ptr %l624, !tbaa !21
  br label %bb253
bb253:
  %t1215 = load i1, ptr %l624, !tbaa !21
  br i1 %t1215, label %bb254, label %bb255
bb254:
  store %olang.scope zeroinitializer, ptr %s41
  %t1216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1216, ptr %l626, !tbaa !29
  %t1217 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t1217, ptr %l627
  %t1218 = load i64, ptr %l55, !tbaa !65
  %t1220 = icmp eq i64 %t1218, 0
  br i1 %t1220, label %bb256, label %bb257
bb255:
  %t1222 = load i1, ptr %l6, !tbaa !21
  br i1 %t1222, label %bb261, label %bb262
bb256:
  %t1224 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t1224, ptr %l630
  br label %bb259
bb257:
  %t1226 = load i64, ptr @G_2ecompiler_2feval_2eForeignId, !tbaa !24
  %t1227 = load i64, ptr %l55, !tbaa !65
  %t1231 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s41, i64 %t1226, i64 %t1227)
  store %"compiler/eval:Ptr" %t1231, ptr %l635
  br label %bb258
bb258:
  %t1232 = load %"compiler/eval:Ptr", ptr %l635
  store %"compiler/eval:Ptr" %t1232, ptr %l630
  br label %bb259
bb259:
  %t1233 = load ptr, ptr %l626, !tbaa !29
  %t1234 = load %"compiler/eval:Ptr", ptr %l627
  %t1235 = load %"compiler/eval:Ptr", ptr %l630
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t1233, %"compiler/eval:Ptr" %t1234, %"compiler/eval:Ptr" %t1235)
  br label %bb260
bb260:
  call void @__olang_scope_close(ptr %s41)
  br label %bb272
bb261:
  %t1236 = load i32, ptr %l11, !tbaa !23
  %t1237 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1240 = icmp ne i32 %t1236, %t1237
  store i1 %t1240, ptr %l637, !tbaa !21
  br label %bb263
bb262:
  store i1 false, ptr %l637, !tbaa !21
  br label %bb263
bb263:
  %t1242 = load i1, ptr %l637, !tbaa !21
  br i1 %t1242, label %bb264, label %bb265
bb264:
  %t1243 = load i32, ptr %l11, !tbaa !23
  %t1244 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t1247 = icmp ne i32 %t1243, %t1244
  store i1 %t1247, ptr %l641, !tbaa !21
  br label %bb266
bb265:
  store i1 false, ptr %l641, !tbaa !21
  br label %bb266
bb266:
  %t1249 = load i1, ptr %l641, !tbaa !21
  br i1 %t1249, label %bb267, label %bb268
bb267:
  %t1250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1250, ptr %l645, !tbaa !29
  %t1251 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t1251, ptr %l646
  %t1252 = load ptr, ptr %l0, !tbaa !29
  %t1253 = load i32, ptr %l11, !tbaa !23
  %t1256 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t1252, i32 %t1253)
  store i64 %t1256, ptr %l649
  br label %bb269
bb268:
  br label %bb271
bb269:
  %t1257 = load i64, ptr %l55, !tbaa !65
  %t1259 = load ptr, ptr %l645, !tbaa !29
  %t1260 = load %"compiler/eval:Ptr", ptr %l646
  %t1261 = load i64, ptr %l649, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1259, %"compiler/eval:Ptr" %t1260, i64 %t1261, i64 %t1257)
  br label %bb270
bb270:
  br label %bb271
bb271:
  br label %bb272
bb272:
  %t1263 = load ptr, ptr %l0, !tbaa !29
  %t1265 = getelementptr %"compiler/eval:Machine", ptr %t1263, i32 0, i32 23
  %t1266 = load i1, ptr %t1265, !tbaa !21
  %t1268 = xor i1 %t1266, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t1268, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallee(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [7 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca %"compiler/eval:alloc"
  %l11 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i64
  %l14 = alloca %"compiler/eval:Ptr"
  %l15 = alloca %"compiler/eval:Ptr"
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i64
  %l23 = alloca i64
  %l49 = alloca %"compiler/eval:Ptr"
  %l52 = alloca %"compiler/eval:Ptr"
  %l53 = alloca ptr
  %l57 = alloca %"compiler/eval:Ptr"
  %l58 = alloca %"compiler/eval:Ptr"
  %l71 = alloca %"compiler/eval:alloc"
  %l83 = alloca ptr
  %l87 = alloca { i64, [2 x i64] }
  %l88 = alloca i64
  %l103 = alloca %"compiler/eval:Ptr"
  %l104 = alloca ptr
  %l108 = alloca %"compiler/eval:Ptr"
  %l109 = alloca %"compiler/eval:Ptr"
  %l120 = alloca ptr
  %l128 = alloca %"compiler/eval:Ptr"
  %l129 = alloca %"compiler/eval:Ptr"
  %l136 = alloca i1
  %l139 = alloca %"compiler/eval:alloc"
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca %"compiler/eval:alloc"
  %l154 = alloca { i64, [2 x i64] }
  %l155 = alloca i64
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, %"compiler/eval:Ptr", i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [7 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load { i64, [2 x i64] }, ptr %l3
  %t14 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t10, { i64, [2 x i64] } %t11)
  store i64 %t14, ptr %l23
  br label %bb4
bb4:
  %t15 = load i64, ptr %l23, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t22 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t22, ptr %t20, { i64, ptr } %t21)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t28 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 %t25, 0
  %t30 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t28, %"compiler/eval:Ptr" %t26, 1
  %t31 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t30, i64 -1, 2
  store { i64, %"compiler/eval:Ptr", i64 } %t31, ptr %rv
  br label %ret
bb9:
  %t33 = load { i64, [7 x i64] }, ptr %l2
  %t35 = extractvalue { i64, [7 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 1
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t39 = getelementptr { i64, i32 }, ptr %t38, i32 0, i32 0
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t42 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t46 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t44, %"compiler/eval:Ptr" %t42, 1
  %t48 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t46, i64 %t43, 2
  store { i64, %"compiler/eval:Ptr", i64 } %t48, ptr %rv
  br label %ret
bb13:
  %t50 = load { i64, [7 x i64] }, ptr %l2
  %t52 = extractvalue { i64, [7 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 4
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyCFunc, !tbaa !27
  %t57 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t57, ptr %t55, { i64, ptr } %t56)
  br label %bb17
bb17:
  %t60 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t61 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t63 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t61, %"compiler/eval:Ptr" %t60, 1
  %t64 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t63, i64 -1, 2
  store { i64, %"compiler/eval:Ptr", i64 } %t64, ptr %rv
  br label %ret
bb18:
  %t66 = load { i64, [7 x i64] }, ptr %l2
  %t68 = extractvalue { i64, [7 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 2
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t71 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t72 = getelementptr { { i64, [4 x i64] } }, ptr %t71, i32 0, i32 0
  %t73 = load { i64, [4 x i64] }, ptr %t72
  store { i64, [4 x i64] } %t73, ptr %l6
  br label %bb21
bb20:
  br label %bb47
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load { i64, [4 x i64] }, ptr %l6
  %t81 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t75, i64 %t76, { i64, [4 x i64] } %t77, i64 3)
  store %"compiler/eval:Ptr" %t81, ptr %l49
  br label %bb22
bb22:
  %t82 = load %"compiler/eval:Ptr", ptr %l49
  store %"compiler/eval:Ptr" %t82, ptr %l7
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/eval:Ptr", ptr %l7
  %t87 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t83, %"compiler/eval:Ptr" %t84)
  store %"compiler/eval:Ptr" %t87, ptr %l52
  br label %bb23
bb23:
  %t88 = load %"compiler/eval:Ptr", ptr %l52
  store %"compiler/eval:Ptr" %t88, ptr %l8
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = add i64 %t93, 8
  %t98 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t91, i64 %t95)
  store %"compiler/eval:Ptr" %t98, ptr %l57
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l53, !tbaa !29
  %t100 = load %"compiler/eval:Ptr", ptr %l57
  %t101 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t99, %"compiler/eval:Ptr" %t100)
  store %"compiler/eval:Ptr" %t101, ptr %l58
  br label %bb25
bb25:
  %t102 = load %"compiler/eval:Ptr", ptr %l58
  store %"compiler/eval:Ptr" %t102, ptr %l9
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/eval:Machine", ptr %t103, i32 0, i32 23
  %t106 = load i1, ptr %t105, !tbaa !21
  br i1 %t106, label %bb26, label %bb27
bb26:
  %t108 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t109 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t111 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t109, %"compiler/eval:Ptr" %t108, 1
  %t112 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t111, i64 -1, 2
  call void @__olang_scope_close(ptr %s5)
  store { i64, %"compiler/eval:Ptr", i64 } %t112, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t114 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = icmp eq i64 %t115, 0
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t121 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t121, ptr %t119, { i64, ptr } %t120)
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t124 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t125 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t127 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t125, %"compiler/eval:Ptr" %t124, 1
  %t128 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t127, i64 -1, 2
  call void @__olang_scope_close(ptr %s5)
  store { i64, %"compiler/eval:Ptr", i64 } %t128, ptr %rv
  br label %ret
bb32:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t132 = load i64, ptr %t131, !tbaa !24
  %t135 = call %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %t130, i64 %t132)
  store %"compiler/eval:alloc" %t135, ptr %l71
  br label %bb33
bb33:
  %t136 = load %"compiler/eval:alloc", ptr %l71
  store %"compiler/eval:alloc" %t136, ptr %l10
  %t137 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 4
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t142 = icmp ne i64 %t138, %t139
  br i1 %t142, label %bb34, label %bb35
bb34:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t146 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t146, ptr %t144, { i64, ptr } %t145)
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t149 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t150 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t152 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t150, %"compiler/eval:Ptr" %t149, 1
  %t153 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t152, i64 -1, 2
  call void @__olang_scope_close(ptr %s5)
  store { i64, %"compiler/eval:Ptr", i64 } %t153, ptr %rv
  br label %ret
bb37:
  %t155 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 15
  %t156 = load i1, ptr %t155, !tbaa !21
  br i1 %t156, label %bb38, label %bb39
bb38:
  %t158 = load %"compiler/eval:Ptr", ptr %l9
  %t159 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 14
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t163 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t161, %"compiler/eval:Ptr" %t158, 1
  %t165 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t163, i64 %t160, 2
  call void @__olang_scope_close(ptr %s5)
  store { i64, %"compiler/eval:Ptr", i64 } %t165, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l83, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/eval:Machine", ptr %t168, i32 0, i32 32
  %t171 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 14
  %t172 = load i64, ptr %t171, !tbaa !24
  %t175 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t170, i64 %t172)
  store { i64, [2 x i64] } %t175, ptr %l87
  br label %bb41
bb41:
  %t176 = load ptr, ptr %l83, !tbaa !29
  %t177 = load { i64, [2 x i64] }, ptr %l87
  %t178 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t176, { i64, [2 x i64] } %t177)
  store i64 %t178, ptr %l88
  br label %bb42
bb42:
  %t179 = load i64, ptr %l88, !tbaa !24
  store i64 %t179, ptr %l11, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb43, label %bb44
bb43:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t186 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t186, ptr %t184, { i64, ptr } %t185)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t189 = load i64, ptr %l11, !tbaa !24
  %t190 = load %"compiler/eval:Ptr", ptr %l9
  %t192 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 %t189, 0
  %t194 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t192, %"compiler/eval:Ptr" %t190, 1
  %t195 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t194, i64 -1, 2
  call void @__olang_scope_close(ptr %s5)
  store { i64, %"compiler/eval:Ptr", i64 } %t195, ptr %rv
  br label %ret
bb47:
  %t197 = load { i64, [7 x i64] }, ptr %l2
  %t199 = extractvalue { i64, [7 x i64] } %t197, 0
  %t200 = icmp eq i64 %t199, 3
  br i1 %t200, label %bb48, label %bb49
bb48:
  %t202 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t203 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t202, i32 0, i32 0
  %t204 = load { i64, [4 x i64] }, ptr %t203
  store { i64, [4 x i64] } %t204, ptr %l12
  %t206 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t207 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t206, i32 0, i32 1
  %t208 = load i64, ptr %t207
  store i64 %t208, ptr %l13, !tbaa !24
  br label %bb50
bb49:
  br label %bb81
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i64, ptr %l1, !tbaa !24
  %t212 = load { i64, [4 x i64] }, ptr %l12
  %t216 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t210, i64 %t211, { i64, [4 x i64] } %t212, i64 3)
  store %"compiler/eval:Ptr" %t216, ptr %l103
  br label %bb51
bb51:
  %t217 = load %"compiler/eval:Ptr", ptr %l103
  store %"compiler/eval:Ptr" %t217, ptr %l14
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l104, !tbaa !29
  %t219 = getelementptr %"compiler/eval:Ptr", ptr %l14, i32 0, i32 0
  %t220 = load i64, ptr %t219, !tbaa !24
  %t221 = getelementptr %"compiler/eval:Ptr", ptr %l14, i32 0, i32 1
  %t222 = load i64, ptr %t221, !tbaa !24
  %t224 = add i64 %t222, 8
  %t227 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s11, i64 %t220, i64 %t224)
  store %"compiler/eval:Ptr" %t227, ptr %l108
  br label %bb52
bb52:
  %t228 = load ptr, ptr %l104, !tbaa !29
  %t229 = load %"compiler/eval:Ptr", ptr %l108
  %t230 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t228, %"compiler/eval:Ptr" %t229)
  store %"compiler/eval:Ptr" %t230, ptr %l109
  br label %bb53
bb53:
  %t231 = load %"compiler/eval:Ptr", ptr %l109
  store %"compiler/eval:Ptr" %t231, ptr %l15
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/eval:Machine", ptr %t232, i32 0, i32 23
  %t235 = load i1, ptr %t234, !tbaa !21
  br i1 %t235, label %bb54, label %bb55
bb54:
  %t237 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t238 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t240 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t238, %"compiler/eval:Ptr" %t237, 1
  %t241 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t240, i64 -1, 2
  call void @__olang_scope_close(ptr %s11)
  store { i64, %"compiler/eval:Ptr", i64 } %t241, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t243 = getelementptr %"compiler/eval:Ptr", ptr %l15, i32 0, i32 0
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = icmp eq i64 %t244, 0
  br i1 %t246, label %bb57, label %bb58
bb57:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t250 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t250, ptr %t248, { i64, ptr } %t249)
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t253 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t254 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t256 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t254, %"compiler/eval:Ptr" %t253, 1
  %t257 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t256, i64 -1, 2
  call void @__olang_scope_close(ptr %s11)
  store { i64, %"compiler/eval:Ptr", i64 } %t257, ptr %rv
  br label %ret
bb60:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l120, !tbaa !29
  %t260 = getelementptr %"compiler/eval:Ptr", ptr %l15, i32 0, i32 0
  %t261 = load i64, ptr %t260, !tbaa !24
  %t262 = getelementptr %"compiler/eval:Ptr", ptr %l15, i32 0, i32 1
  %t263 = load i64, ptr %t262, !tbaa !24
  %t264 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t265 = load i64, ptr %l13, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t270 = mul i64 8, %t268
  %t273 = add i64 %t263, %t270
  %t276 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s11, i64 %t261, i64 %t273)
  store %"compiler/eval:Ptr" %t276, ptr %l128
  br label %bb61
bb61:
  %t277 = load ptr, ptr %l120, !tbaa !29
  %t278 = load %"compiler/eval:Ptr", ptr %l128
  %t279 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t277, %"compiler/eval:Ptr" %t278)
  store %"compiler/eval:Ptr" %t279, ptr %l129
  br label %bb62
bb62:
  %t280 = load %"compiler/eval:Ptr", ptr %l129
  store %"compiler/eval:Ptr" %t280, ptr %l16
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/eval:Machine", ptr %t281, i32 0, i32 23
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb63, label %bb64
bb63:
  %t286 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t287 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t289 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t287, %"compiler/eval:Ptr" %t286, 1
  %t290 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t289, i64 -1, 2
  call void @__olang_scope_close(ptr %s11)
  store { i64, %"compiler/eval:Ptr", i64 } %t290, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t292 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t293 = load i64, ptr %t292, !tbaa !24
  %t295 = icmp eq i64 %t293, 0
  br i1 %t295, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb69
bb67:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t299 = load i64, ptr %t298, !tbaa !24
  %t302 = call %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %t297, i64 %t299)
  store %"compiler/eval:alloc" %t302, ptr %l139
  br label %bb68
bb68:
  %t303 = getelementptr %"compiler/eval:alloc", ptr %l139, i32 0, i32 4
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t308 = icmp ne i64 %t304, %t305
  store i1 %t308, ptr %l136, !tbaa !21
  br label %bb69
bb69:
  %t310 = load i1, ptr %l136, !tbaa !21
  br i1 %t310, label %bb70, label %bb71
bb70:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t313 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t313, ptr %t311, { i64, ptr } %t312)
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t316 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t317 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 -1, 0
  %t319 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t317, %"compiler/eval:Ptr" %t316, 1
  %t320 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t319, i64 -1, 2
  call void @__olang_scope_close(ptr %s11)
  store { i64, %"compiler/eval:Ptr", i64 } %t320, ptr %rv
  br label %ret
bb73:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l147, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/eval:Machine", ptr %t323, i32 0, i32 32
  store ptr %t325, ptr %l149, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t328 = load i64, ptr %t327, !tbaa !24
  %t331 = call %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %t326, i64 %t328)
  store %"compiler/eval:alloc" %t331, ptr %l152
  br label %bb74
bb74:
  %t332 = getelementptr %"compiler/eval:alloc", ptr %l152, i32 0, i32 14
  %t333 = load i64, ptr %t332, !tbaa !24
  %t334 = load ptr, ptr %l149, !tbaa !29
  %t336 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t334, i64 %t333)
  store { i64, [2 x i64] } %t336, ptr %l154
  br label %bb75
bb75:
  %t337 = load ptr, ptr %l147, !tbaa !29
  %t338 = load { i64, [2 x i64] }, ptr %l154
  %t339 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t337, { i64, [2 x i64] } %t338)
  store i64 %t339, ptr %l155
  br label %bb76
bb76:
  %t340 = load i64, ptr %l155, !tbaa !24
  store i64 %t340, ptr %l17, !tbaa !24
  %t341 = load i64, ptr %l17, !tbaa !24
  %t343 = icmp slt i64 %t341, 0
  br i1 %t343, label %bb77, label %bb78
bb77:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t347 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t347, ptr %t345, { i64, ptr } %t346)
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t350 = load i64, ptr %l17, !tbaa !24
  %t351 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t353 = insertvalue { i64, %"compiler/eval:Ptr", i64 } undef, i64 %t350, 0
  %t355 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t353, %"compiler/eval:Ptr" %t351, 1
  %t356 = insertvalue { i64, %"compiler/eval:Ptr", i64 } %t355, i64 -1, 2
  call void @__olang_scope_close(ptr %s11)
  store { i64, %"compiler/eval:Ptr", i64 } %t356, ptr %rv
  br label %ret
bb81:
  call void @__olang_check_failed(ptr @olang_loc_bde43f50f3dd47_4bb44709ac02dbdb)
  unreachable
ret:
  %rr = load { i64, %"compiler/eval:Ptr", i64 }, ptr %rv
  ret { i64, %"compiler/eval:Ptr", i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econvert(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca double
  %l12 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i64
  %l38 = alloca i1
  %l42 = alloca i1
  %l49 = alloca i64
  %l53 = alloca i1
  %l56 = alloca i64
  %l58 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l71 = alloca i64
  %l77 = alloca i64
  %l81 = alloca double
  %l88 = alloca i64
  %l94 = alloca i1
  %l102 = alloca i1
  %l109 = alloca i64
  %l111 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t17 = icmp ne i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t23 = icmp ne i64 %t19, %t20
  store i1 %t23, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t30 = icmp ne i64 %t26, %t27
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t37 = icmp ne i64 %t33, %t34
  store i1 %t37, ptr %l27, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l27, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l34
  br label %bb15
bb15:
  %t47 = load i64, ptr %l34, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb18
bb17:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t58 = icmp eq i64 %t54, %t55
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb18
bb18:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb21
bb20:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t62 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  store i1 %t65, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t67 = load i1, ptr %l42, !tbaa !21
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load i32, ptr %l2, !tbaa !23
  %t74 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t68, i64 %t69, i32 %t70)
  store i64 %t74, ptr %l49
  br label %bb24
bb23:
  br label %bb37
bb24:
  %t75 = load i64, ptr %l49, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t80 = icmp eq i64 %t76, %t77
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t82, i32 %t83)
  store i64 %t86, ptr %l56
  br label %bb27
bb26:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb28
bb27:
  %t87 = load i64, ptr %l56, !tbaa !24
  %t88 = icmp eq i64 %t87, 64
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb28
bb28:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t91 = load i64, ptr %l7, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  store i1 %t93, ptr %l58, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t95 = load i1, ptr %l58, !tbaa !21
  store i1 %t95, ptr %l8, !tbaa !21
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb32, label %bb33
bb32:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l7, !tbaa !24
  %t104 = load i1, ptr %l8, !tbaa !21
  %t105 = load i32, ptr %l3, !tbaa !23
  %t110 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintToFloat(ptr %v0, ptr %t102, i64 %t103, i1 %t104, i32 %t105)
  store i64 %t110, ptr %l68
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t111 = load i64, ptr %l68, !tbaa !24
  store i64 %t111, ptr %rv
  br label %ret
bb35:
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %l69, !tbaa !24
  %t113 = load i64, ptr %l6, !tbaa !24
  %t115 = call i64 @compiler_2feval_2ebmask(i64 %t113)
  store i64 %t115, ptr %l71
  br label %bb36
bb36:
  %t116 = load i64, ptr %l69, !tbaa !24
  %t117 = load i64, ptr %l71, !tbaa !24
  %t118 = and i64 %t116, %t117
  store i64 %t118, ptr %rv
  br label %ret
bb37:
  %t120 = load i64, ptr %l4, !tbaa !24
  %t121 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t124 = icmp ne i64 %t120, %t121
  br i1 %t124, label %bb38, label %bb39
bb38:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t126)
  store i64 %t128, ptr %l77
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t129 = load i64, ptr %l77, !tbaa !24
  store i64 %t129, ptr %rv
  br label %ret
bb41:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i64, ptr %l1, !tbaa !24
  %t132 = load i32, ptr %l2, !tbaa !23
  %t136 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t130, i64 %t131, i32 %t132)
  store double %t136, ptr %l81
  br label %bb42
bb42:
  %t137 = load double, ptr %l81, !tbaa !26
  store double %t137, ptr %l9, !tbaa !26
  %t138 = load i64, ptr %l5, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t142 = icmp eq i64 %t138, %t139
  br i1 %t142, label %bb43, label %bb44
bb43:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load double, ptr %l9, !tbaa !26
  %t146 = load i32, ptr %l3, !tbaa !23
  %t150 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %t144, double %t145, i32 %t146)
  store i64 %t150, ptr %l88
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t151 = load i64, ptr %l88, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
bb46:
  %t152 = load double, ptr %l9, !tbaa !26
  %t153 = load i64, ptr %l6, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t155 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t158 = icmp eq i64 %t154, %t155
  %t162 = call i1 @compiler_2feval_2efloatFits(double %t152, i64 %t153, i1 %t158)
  store i1 %t162, ptr %l94
  br label %bb47
bb47:
  %t163 = load i1, ptr %l94, !tbaa !21
  %t164 = xor i1 %t163, true
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyConvert, !tbaa !27
  %t168 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t168, ptr %t166, { i64, ptr } %t167)
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i64 0, ptr %rv
  br label %ret
bb51:
  %t172 = load i64, ptr %l5, !tbaa !24
  %t173 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t176 = icmp eq i64 %t172, %t173
  br i1 %t176, label %bb52, label %bb53
bb52:
  %t178 = load i64, ptr %l6, !tbaa !24
  %t180 = icmp eq i64 %t178, 64
  store i1 %t180, ptr %l102, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb54
bb54:
  %t182 = load i1, ptr %l102, !tbaa !21
  br i1 %t182, label %bb55, label %bb56
bb55:
  %t183 = load double, ptr %l9, !tbaa !26
  %t185 = fptoui double %t183 to i64
  store i64 %t185, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t188 = load double, ptr %l9, !tbaa !26
  %t190 = fptosi double %t188 to i64
  store i64 %t190, ptr %l109, !tbaa !24
  %t191 = load i64, ptr %l6, !tbaa !24
  %t193 = call i64 @compiler_2feval_2ebmask(i64 %t191)
  store i64 %t193, ptr %l111
  br label %bb58
bb58:
  %t194 = load i64, ptr %l109, !tbaa !24
  %t195 = load i64, ptr %l111, !tbaa !24
  %t196 = and i64 %t194, %t195
  store i64 %t196, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropDefers(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l21 = alloca i64
  %l28 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i64
  %l67 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i64
  %l75 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca i64
  %l83 = alloca i64
  %l88 = alloca ptr
  %l91 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 68
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 67
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l21
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t21 = load i64, ptr %l21, !tbaa !24
  %t23 = icmp eq i64 %t21, %a1
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l17, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb43
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 68
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  store i64 %t34, ptr %l28
  br label %bb10
bb10:
  %t36 = load i64, ptr %l28, !tbaa !24
  %t38 = icmp ne i64 %t36, %a2
  br i1 %t38, label %bb11, label %bb12
bb11:
  br label %bb42
bb12:
  br label %bb13
bb13:
  %t40 = load i64, ptr %l4, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 68
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l34
  br label %bb14
bb14:
  %t47 = load i64, ptr %l34, !tbaa !24
  %t48 = sub i64 %t47, 1
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb20
bb17:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l42, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb19
bb19:
  %t76 = load i64, ptr %l42, !tbaa !24
  store i64 %t76, ptr %l39, !tbaa !24
  br label %bb20
bb20:
  %t77 = load i64, ptr %l39, !tbaa !24
  store i64 %t77, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l10, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Machine", ptr %t96, i32 0, i32 67
  store ptr %t98, ptr %l61, !tbaa !29
  %t99 = load i64, ptr %l10, !tbaa !24
  store i64 %t99, ptr %l62, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/eval:Machine", ptr %t100, i32 0, i32 67
  %t103 = load i64, ptr %l10, !tbaa !24
  %t105 = add i64 %t103, 1
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t102, i64 %t105)
  store i64 %t108, ptr %l67
  br label %bb25
bb25:
  %t109 = load ptr, ptr %l61, !tbaa !29
  %t110 = load i64, ptr %l62, !tbaa !24
  %t111 = load i64, ptr %l67, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t109, i64 %t110, i64 %t111)
  br label %bb26
bb26:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/eval:Machine", ptr %t112, i32 0, i32 68
  store ptr %t114, ptr %l69, !tbaa !29
  %t115 = load i64, ptr %l10, !tbaa !24
  store i64 %t115, ptr %l70, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/eval:Machine", ptr %t116, i32 0, i32 68
  %t119 = load i64, ptr %l10, !tbaa !24
  %t121 = add i64 %t119, 1
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t118, i64 %t121)
  store i64 %t124, ptr %l75
  br label %bb27
bb27:
  %t125 = load ptr, ptr %l69, !tbaa !29
  %t126 = load i64, ptr %l70, !tbaa !24
  %t127 = load i64, ptr %l75, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126, i64 %t127)
  br label %bb28
bb28:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/eval:Machine", ptr %t128, i32 0, i32 69
  store ptr %t130, ptr %l77, !tbaa !29
  %t131 = load i64, ptr %l10, !tbaa !24
  store i64 %t131, ptr %l78, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/eval:Machine", ptr %t132, i32 0, i32 69
  %t135 = load i64, ptr %l10, !tbaa !24
  %t137 = add i64 %t135, 1
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t137)
  store i64 %t140, ptr %l83
  br label %bb29
bb29:
  %t141 = load ptr, ptr %l77, !tbaa !29
  %t142 = load i64, ptr %l78, !tbaa !24
  %t143 = load i64, ptr %l83, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142, i64 %t143)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t144 = load i64, ptr %l9, !tbaa !24
  %t147 = add i64 %t144, 1
  store i64 %t147, ptr %l9, !tbaa !24
  br label %bb21
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Machine", ptr %t149, i32 0, i32 67
  store ptr %t151, ptr %l88, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 67
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t154)
  store i64 %t156, ptr %l91
  br label %bb33
bb33:
  %t157 = load i64, ptr %l91, !tbaa !24
  %t158 = sub i64 %t157, 1
  %t159 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t159, i64 %t158)
  br label %bb34
bb34:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/eval:Machine", ptr %t161, i32 0, i32 68
  store ptr %t163, ptr %l94, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 68
  %t168 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t166)
  store i64 %t168, ptr %l97
  br label %bb35
bb35:
  %t169 = load i64, ptr %l97, !tbaa !24
  %t170 = sub i64 %t169, 1
  %t171 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t171, i64 %t170)
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/eval:Machine", ptr %t173, i32 0, i32 69
  store ptr %t175, ptr %l100, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/eval:Machine", ptr %t176, i32 0, i32 69
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t178)
  store i64 %t180, ptr %l103
  br label %bb37
bb37:
  %t181 = load i64, ptr %l103, !tbaa !24
  %t182 = sub i64 %t181, 1
  %t183 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t183, i64 %t182)
  br label %bb38
bb38:
  br i1 %a3, label %bb39, label %bb40
bb39:
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t187 = load i64, ptr %l4, !tbaa !24
  %t190 = sub i64 %t187, 1
  store i64 %t190, ptr %l4, !tbaa !24
  br label %bb2
bb43:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [7 x i64] }
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, %"compiler/eval:Ptr", i64 }
  %l9 = alloca i64
  %l10 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, [1 x i64] }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca { i64, %"compiler/eval:Ptr", i64 }
  %l71 = alloca i32
  %l77 = alloca ptr
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca %"compiler/eval:genRec"
  %l119 = alloca i64
  %l124 = alloca i64
  %l129 = alloca i64
  %l136 = alloca ptr
  %l137 = alloca i1
  %l144 = alloca i32
  %l147 = alloca i32
  %l166 = alloca i64
  %l169 = alloca i64
  %l175 = alloca i32
  %l178 = alloca i1
  %l180 = alloca ptr
  %l184 = alloca %"compiler/eval:Ptr"
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca i64
  %l192 = alloca { i64, [4 x i64] }
  %l193 = alloca %"compiler/eval:Ptr"
  %l194 = alloca %"compiler/eval:Ptr"
  %l195 = alloca ptr
  %l196 = alloca i64
  %l200 = alloca %"compiler/eval:Ptr"
  %l205 = alloca %"compiler/mir:Local"
  %l206 = alloca i32
  %l214 = alloca { i64, [4 x i64] }
  %l225 = alloca i64
  %l227 = alloca i64
  %l232 = alloca { i64, [1 x i64] }
  %l241 = alloca i1
  %l247 = alloca { i64, ptr }
  %l252 = alloca i64
  %l255 = alloca i64
  %l276 = alloca { i64, [1 x i64] }
  %l279 = alloca i64
  %l283 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i64
  %l300 = alloca { i64, [1 x i64] }
  %l301 = alloca i64
  %l305 = alloca { i64, [1 x i64] }
  %l306 = alloca i64
  %l324 = alloca i64
  %l327 = alloca i64
  %l349 = alloca i1
  %l354 = alloca ptr
  %l355 = alloca i64
  %l362 = alloca { i64, [1 x i64] }
  %l363 = alloca i64
  %l369 = alloca i1
  %l373 = alloca i1
  %l378 = alloca i64
  %l383 = alloca i64
  %l385 = alloca { i64, ptr }
  %l389 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %l403 = alloca { i64, ptr }
  %l411 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  %t86 = alloca %"compiler/eval:genRec", align 8
  %t105 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [7 x i64] } %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l55
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l55, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load { i64, [7 x i64] }, ptr %l2
  %t13 = call { i64, %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallee(ptr %v0, ptr %t7, i64 %t8, { i64, [7 x i64] } %t9)
  store { i64, %"compiler/eval:Ptr", i64 } %t13, ptr %l59
  br label %bb2
bb2:
  %t14 = load { i64, %"compiler/eval:Ptr", i64 }, ptr %l59
  store { i64, %"compiler/eval:Ptr", i64 } %t14, ptr %l8
  %t15 = getelementptr { i64, %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l9, !tbaa !24
  %t18 = getelementptr { i64, %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 1
  %t19 = load %"compiler/eval:Ptr", ptr %t18
  store %"compiler/eval:Ptr" %t19, ptr %l10
  %t21 = getelementptr { i64, %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = icmp sge i64 %t22, 0
  store i1 %t26, ptr %l12, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 23
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load { i64, [7 x i64] }, ptr %l2
  %t40 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %t34, i64 %t35, { i64, [7 x i64] } %t36)
  store i32 %t40, ptr %l71
  br label %bb6
bb6:
  %t41 = load i32, ptr %l71, !tbaa !23
  store i32 %t41, ptr %l13, !tbaa !23
  %t42 = load i1, ptr %l12, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l14, !tbaa !24
  store i1 false, ptr %l15, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 26
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %s0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l77
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l77, !tbaa !29
  %t54 = getelementptr %"compiler/mir:Fn", ptr %t52, i32 0, i32 25
  %t55 = load i1, ptr %t54, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp eq i64 %t58, 0
  br i1 %t60, label %bb13, label %bb14
bb12:
  br label %bb28
bb13:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t64 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t64, ptr %t62, { i64, ptr } %t63)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l85, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 26
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l89
  br label %bb17
bb17:
  %t76 = load %"compiler/eval:Ptr", ptr %l10
  %t77 = load ptr, ptr %l85, !tbaa !29
  %t78 = load ptr, ptr %l89, !tbaa !29
  %t80 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2egenIndex(ptr %v0, ptr %v0, ptr %t77, ptr %t78, %"compiler/eval:Ptr" %t76)
  store i64 %t80, ptr %l91
  br label %bb18
bb18:
  %t81 = load i64, ptr %l91, !tbaa !24
  store i64 %t81, ptr %l14, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/eval:Machine", ptr %t82, i32 0, i32 64
  %t85 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t86, ptr %v0, ptr %s3, ptr %t84, i64 %t85)
  call void @llvm.memmove.p0.p0.i64(ptr %l95, ptr %t86, i64 280, i1 false)
  br label %bb19
bb19:
  %t89 = getelementptr %"compiler/eval:genRec", ptr %l95, i32 0, i32 0
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l16, !tbaa !24
  %t92 = load i64, ptr %l16, !tbaa !24
  %t94 = icmp eq i64 %t92, 2
  br i1 %t94, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 78
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/eval:Machine", ptr %t101, i32 0, i32 79
  %t104 = load %"compiler/source:Span", ptr %t103
  store { i64, [5 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t108 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } undef, i32 13, 0
  %t110 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t108, i64 %t100, 1
  %t112 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t110, %"compiler/source:Span" %t104, 2
  %t113 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t112, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, 3
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  store { i32, i64, %"compiler/source:Span", { i64, ptr } } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t105
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v0, ptr %t96, { i64, [5 x i64] } %t115)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb23:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t121 = icmp eq i64 %t119, 3
  br i1 %t121, label %bb24, label %bb25
bb24:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l1, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load { i64, [7 x i64] }, ptr %l2
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenOver(ptr %v0, ptr %t123, i64 %t124, i64 %t125, { i64, [7 x i64] } %t126, i64 %t127, i64 %t128)
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb27:
  %t136 = load i64, ptr %l16, !tbaa !24
  %t138 = icmp eq i64 %t136, 1
  store i1 %t138, ptr %l15, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t140 = load i1, ptr %l15, !tbaa !21
  br i1 %t140, label %bb29, label %bb30
bb29:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l5, !tbaa !24
  %t145 = load i64, ptr %l6, !tbaa !24
  %t150 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erestoreGen(ptr %v0, ptr %t142, i64 %t143, i64 %t144, i64 %t145)
  store i64 %t150, ptr %l124
  br label %bb31
bb30:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l5, !tbaa !24
  %t154 = load i64, ptr %l6, !tbaa !24
  %t159 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t151, i64 %t152, i64 %t153, i64 %t154)
  store i64 %t159, ptr %l129
  br label %bb32
bb31:
  %t160 = load i64, ptr %l124, !tbaa !24
  store i64 %t160, ptr %l119, !tbaa !24
  br label %bb33
bb32:
  %t161 = load i64, ptr %l129, !tbaa !24
  store i64 %t161, ptr %l119, !tbaa !24
  br label %bb33
bb33:
  %t162 = load i64, ptr %l119, !tbaa !24
  store i64 %t162, ptr %l17, !tbaa !24
  %t163 = load i64, ptr %l17, !tbaa !24
  %t165 = icmp slt i64 %t163, 0
  br i1 %t165, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/eval:Machine", ptr %t168, i32 0, i32 26
  %t171 = load i64, ptr %l9, !tbaa !24
  %t174 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t170, i64 %t171)
  store ptr %t174, ptr %l136
  br label %bb37
bb37:
  %t175 = load ptr, ptr %l136, !tbaa !29
  store ptr %t175, ptr %l18, !tbaa !29
  %t176 = load { i64, [7 x i64] }, ptr %l2
  %t178 = extractvalue { i64, [7 x i64] } %t176, 0
  %t179 = icmp eq i64 %t178, 3
  br i1 %t179, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_11a19fcb84a16e6d_1ab7f06eb0f74619)
  unreachable
bb46:
  %t181 = load i1, ptr %l137, !tbaa !21
  store i1 %t181, ptr %l19, !tbaa !21
  store i32 0, ptr %l20, !tbaa !23
  %t182 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t183 = load i32, ptr %t182, !tbaa !23
  store i32 %t183, ptr %l21, !tbaa !23
  store i32 1, ptr %l22, !tbaa !23
  %t185 = load i32, ptr %l21, !tbaa !23
  %t186 = load i32, ptr %l20, !tbaa !23
  %t189 = icmp sgt i32 %t185, %t186
  br i1 %t189, label %bb47, label %bb48
bb47:
  %t191 = load i32, ptr %l22, !tbaa !23
  %t193 = icmp sgt i32 %t191, 0
  br i1 %t193, label %bb49, label %bb50
bb48:
  store i32 0, ptr %l144, !tbaa !23
  br label %bb52
bb49:
  %t195 = load i32, ptr %l21, !tbaa !23
  %t196 = load i32, ptr %l20, !tbaa !23
  %t199 = sub i32 %t195, %t196
  %t200 = load i32, ptr %l22, !tbaa !23
  %t203 = add i32 %t199, %t200
  %t205 = sub i32 %t203, 1
  %t206 = load i32, ptr %l22, !tbaa !23
  %t209 = sdiv i32 %t205, %t206
  store i32 %t209, ptr %l147, !tbaa !23
  br label %bb51
bb50:
  store i32 0, ptr %l147, !tbaa !23
  br label %bb51
bb51:
  %t211 = load i32, ptr %l147, !tbaa !23
  store i32 %t211, ptr %l144, !tbaa !23
  br label %bb52
bb52:
  %t212 = load i32, ptr %l144, !tbaa !23
  store i32 %t212, ptr %l23, !tbaa !23
  store i32 0, ptr %l24, !tbaa !23
  br label %bb53
bb53:
  %t213 = load i32, ptr %l24, !tbaa !23
  %t214 = load i32, ptr %l23, !tbaa !23
  %t217 = icmp slt i32 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb54, label %bb55
bb54:
  br label %bb78
bb55:
  br label %bb56
bb56:
  %t221 = load i32, ptr %l20, !tbaa !23
  %t222 = load i32, ptr %l24, !tbaa !23
  %t223 = load i32, ptr %l22, !tbaa !23
  %t226 = mul i32 %t222, %t223
  %t229 = add i32 %t221, %t226
  store i32 %t229, ptr %l25, !tbaa !23
  %t231 = load i32, ptr %l25, !tbaa !23
  %t233 = sext i32 %t231 to i64
  store i64 %t233, ptr %l166, !tbaa !24
  %t234 = load ptr, ptr %l18, !tbaa !29
  %t236 = getelementptr %"compiler/mir:Fn", ptr %t234, i32 0, i32 4
  %t238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t236)
  store i64 %t238, ptr %l169
  br label %bb57
bb57:
  %t239 = load i64, ptr %l166, !tbaa !24
  %t240 = load i64, ptr %l169, !tbaa !24
  %t241 = icmp slt i64 %t239, %t240
  br i1 %t241, label %bb58, label %bb59
bb58:
  %t243 = load ptr, ptr %l18, !tbaa !29
  %t245 = getelementptr %"compiler/mir:Fn", ptr %t243, i32 0, i32 4
  %t246 = load i32, ptr %l25, !tbaa !23
  %t248 = sext i32 %t246 to i64
  %t251 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t245, i64 %t248)
  store i32 %t251, ptr %l175
  br label %bb60
bb59:
  br label %bb76
bb60:
  %t252 = load i32, ptr %l175, !tbaa !23
  store i32 %t252, ptr %l26, !tbaa !23
  %t253 = load i32, ptr %l25, !tbaa !23
  %t255 = icmp eq i32 %t253, 0
  br i1 %t255, label %bb61, label %bb62
bb61:
  %t257 = load i1, ptr %l19, !tbaa !21
  store i1 %t257, ptr %l178, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb63
bb63:
  %t259 = load i1, ptr %l178, !tbaa !21
  br i1 %t259, label %bb64, label %bb65
bb64:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l180, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l17, !tbaa !24
  %t263 = load i32, ptr %l26, !tbaa !23
  %t267 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t261, i64 %t262, i32 %t263)
  store %"compiler/eval:Ptr" %t267, ptr %l184
  br label %bb66
bb65:
  br label %bb71
bb66:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l185, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l186, !tbaa !29
  %t270 = load i64, ptr %l1, !tbaa !24
  store i64 %t270, ptr %l187, !tbaa !24
  %t271 = load ptr, ptr %l7, !tbaa !29
  %t273 = getelementptr %"compiler/mir:Fn", ptr %t271, i32 0, i32 11
  %t274 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t275 = load i32, ptr %t274, !tbaa !23
  %t277 = sext i32 %t275 to i64
  %t280 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t273, i64 %t277)
  store { i64, [4 x i64] } %t280, ptr %l192
  br label %bb67
bb67:
  %t281 = load ptr, ptr %l186, !tbaa !29
  %t282 = load i64, ptr %l187, !tbaa !24
  %t283 = load { i64, [4 x i64] }, ptr %l192
  %t284 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t281, i64 %t282, { i64, [4 x i64] } %t283, i64 1)
  store %"compiler/eval:Ptr" %t284, ptr %l193
  br label %bb68
bb68:
  %t285 = load ptr, ptr %l185, !tbaa !29
  %t286 = load %"compiler/eval:Ptr", ptr %l193
  %t287 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t285, %"compiler/eval:Ptr" %t286)
  store %"compiler/eval:Ptr" %t287, ptr %l194
  br label %bb69
bb69:
  %t288 = load ptr, ptr %l180, !tbaa !29
  %t289 = load %"compiler/eval:Ptr", ptr %l184
  %t290 = load %"compiler/eval:Ptr", ptr %l194
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t288, %"compiler/eval:Ptr" %t289, %"compiler/eval:Ptr" %t290)
  br label %bb70
bb70:
  br label %bb77
bb71:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l195, !tbaa !29
  %t292 = load i64, ptr %l1, !tbaa !24
  store i64 %t292, ptr %l196, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i64, ptr %l17, !tbaa !24
  %t295 = load i32, ptr %l26, !tbaa !23
  %t299 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t293, i64 %t294, i32 %t295)
  store %"compiler/eval:Ptr" %t299, ptr %l200
  br label %bb72
bb72:
  %t300 = load ptr, ptr %l18, !tbaa !29
  %t302 = getelementptr %"compiler/mir:Fn", ptr %t300, i32 0, i32 7
  %t303 = load i32, ptr %l26, !tbaa !23
  %t305 = sext i32 %t303 to i64
  %t308 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t302, i64 %t305)
  store %"compiler/mir:Local" %t308, ptr %l205
  br label %bb73
bb73:
  %t309 = getelementptr %"compiler/mir:Local", ptr %l205, i32 0, i32 2
  %t310 = load i32, ptr %t309, !tbaa !23
  store i32 %t310, ptr %l206, !tbaa !23
  %t311 = load ptr, ptr %l7, !tbaa !29
  %t313 = getelementptr %"compiler/mir:Fn", ptr %t311, i32 0, i32 11
  %t314 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t315 = load i32, ptr %t314, !tbaa !23
  %t317 = sext i32 %t315 to i64
  %t318 = load i32, ptr %l25, !tbaa !23
  %t320 = sext i32 %t318 to i64
  %t323 = add i64 %t317, %t320
  %t326 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t313, i64 %t323)
  store { i64, [4 x i64] } %t326, ptr %l214
  br label %bb74
bb74:
  %t327 = load ptr, ptr %l195, !tbaa !29
  %t328 = load i64, ptr %l196, !tbaa !24
  %t329 = load %"compiler/eval:Ptr", ptr %l200
  %t330 = load i32, ptr %l206, !tbaa !23
  %t331 = load { i64, [4 x i64] }, ptr %l214
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t327, i64 %t328, %"compiler/eval:Ptr" %t329, i32 %t330, { i64, [4 x i64] } %t331)
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t332 = load i32, ptr %l24, !tbaa !23
  %t335 = add i32 %t332, 1
  store i32 %t335, ptr %l24, !tbaa !23
  br label %bb53
bb78:
  %t337 = load i1, ptr %l15, !tbaa !21
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb79, label %bb80
bb79:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load i64, ptr %l17, !tbaa !24
  %t343 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %t341, i64 %t342, i64 %t343)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  store i64 0, ptr %l27, !tbaa !24
  %t347 = load ptr, ptr %l18, !tbaa !29
  %t349 = getelementptr %"compiler/mir:Fn", ptr %t347, i32 0, i32 6
  store ptr %t349, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb83
bb83:
  %t351 = load i64, ptr %l29, !tbaa !24
  store i64 %t351, ptr %l225, !tbaa !24
  %t352 = load ptr, ptr %l28, !tbaa !29
  %t354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t352)
  store i64 %t354, ptr %l227
  br label %bb84
bb84:
  %t355 = load i64, ptr %l225, !tbaa !24
  %t356 = load i64, ptr %l227, !tbaa !24
  %t357 = icmp slt i64 %t355, %t356
  %t359 = xor i1 %t357, true
  br i1 %t359, label %bb85, label %bb86
bb85:
  br label %bb99
bb86:
  br label %bb87
bb87:
  %t361 = load ptr, ptr %l28, !tbaa !29
  %t362 = load i64, ptr %l29, !tbaa !24
  %t365 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t361, i64 %t362)
  store { i64, [1 x i64] } %t365, ptr %l232
  br label %bb88
bb88:
  %t366 = load { i64, [1 x i64] }, ptr %l232
  %t369 = extractvalue { i64, [1 x i64] } %t366, 0
  %t370 = icmp eq i64 %t369, 4
  br i1 %t370, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb97
bb92:
  br i1 true, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t372 = load i64, ptr %l27, !tbaa !24
  %t375 = add i64 %t372, 1
  store i64 %t375, ptr %l27, !tbaa !24
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_e8d82fb02ccf62bc_44b724ba703ff148)
  unreachable
bb97:
  br label %bb98
bb98:
  %t377 = load i64, ptr %l29, !tbaa !24
  %t380 = add i64 %t377, 1
  store i64 %t380, ptr %l29, !tbaa !24
  br label %bb83
bb99:
  %t382 = load { i64, [7 x i64] }, ptr %l2
  %t384 = extractvalue { i64, [7 x i64] } %t382, 0
  %t385 = icmp eq i64 %t384, 0
  br i1 %t385, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  store i1 true, ptr %l241, !tbaa !21
  br label %bb108
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_36e0ec838c111677_372a612bd7b0a623)
  unreachable
bb108:
  %t387 = load i1, ptr %l241, !tbaa !21
  store i1 %t387, ptr %l31, !tbaa !21
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/eval:Machine", ptr %t388, i32 0, i32 0
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t392 = load i32, ptr %l13, !tbaa !23
  %t395 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t391, i32 %t392)
  store { i64, ptr } %t395, ptr %l247
  br label %bb109
bb109:
  %t396 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t396, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t397 = load i64, ptr %l27, !tbaa !24
  store i64 %t397, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t399 = load i64, ptr %l34, !tbaa !24
  %t400 = load i64, ptr %l33, !tbaa !24
  %t403 = icmp sgt i64 %t399, %t400
  br i1 %t403, label %bb110, label %bb111
bb110:
  %t405 = load i64, ptr %l35, !tbaa !24
  %t407 = icmp sgt i64 %t405, 0
  br i1 %t407, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l252, !tbaa !24
  br label %bb115
bb112:
  %t409 = load i64, ptr %l34, !tbaa !24
  %t410 = load i64, ptr %l33, !tbaa !24
  %t413 = sub i64 %t409, %t410
  %t414 = load i64, ptr %l35, !tbaa !24
  %t417 = add i64 %t413, %t414
  %t419 = sub i64 %t417, 1
  %t420 = load i64, ptr %l35, !tbaa !24
  %t423 = sdiv i64 %t419, %t420
  store i64 %t423, ptr %l255, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l255, !tbaa !24
  br label %bb114
bb114:
  %t425 = load i64, ptr %l255, !tbaa !24
  store i64 %t425, ptr %l252, !tbaa !24
  br label %bb115
bb115:
  %t426 = load i64, ptr %l252, !tbaa !24
  store i64 %t426, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb116
bb116:
  %t427 = load i64, ptr %l37, !tbaa !24
  %t428 = load i64, ptr %l36, !tbaa !24
  %t431 = icmp slt i64 %t427, %t428
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb117, label %bb118
bb117:
  br label %bb187
bb118:
  br label %bb119
bb119:
  %t435 = load i64, ptr %l33, !tbaa !24
  %t436 = load i64, ptr %l37, !tbaa !24
  %t437 = load i64, ptr %l35, !tbaa !24
  %t440 = mul i64 %t436, %t437
  %t443 = add i64 %t435, %t440
  store i64 %t443, ptr %l38, !tbaa !24
  %t445 = load ptr, ptr %l18, !tbaa !29
  %t447 = getelementptr %"compiler/mir:Fn", ptr %t445, i32 0, i32 6
  %t448 = load i64, ptr %l38, !tbaa !24
  %t451 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t447, i64 %t448)
  store { i64, [1 x i64] } %t451, ptr %l276
  br label %bb120
bb120:
  %t452 = load { i64, [1 x i64] }, ptr %l276
  %t454 = extractvalue { i64, [1 x i64] } %t452, 0
  %t455 = icmp eq i64 %t454, 5
  br i1 %t455, label %bb121, label %bb122
bb121:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb123
bb122:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/eval:Machine", ptr %t457, i32 0, i32 71
  %t460 = load i64, ptr %t459, !tbaa !24
  store i64 %t460, ptr %l279, !tbaa !24
  br label %bb123
bb123:
  %t462 = load i64, ptr %l279, !tbaa !24
  store i64 %t462, ptr %l39, !tbaa !24
  %t463 = load i1, ptr %l31, !tbaa !21
  br i1 %t463, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l283, !tbaa !21
  br label %bb126
bb125:
  %t465 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = load i64, ptr %l27, !tbaa !24
  %t471 = icmp eq i64 %t467, %t468
  store i1 %t471, ptr %l283, !tbaa !21
  br label %bb126
bb126:
  %t473 = load i1, ptr %l283, !tbaa !21
  br i1 %t473, label %bb127, label %bb128
bb127:
  %t474 = load i64, ptr %l38, !tbaa !24
  %t475 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t476 = load i32, ptr %t475, !tbaa !23
  %t478 = sext i32 %t476 to i64
  %t481 = icmp slt i64 %t474, %t478
  br i1 %t481, label %bb129, label %bb130
bb128:
  %t483 = load ptr, ptr %l18, !tbaa !29
  %t485 = getelementptr %"compiler/mir:Fn", ptr %t483, i32 0, i32 6
  %t486 = load i64, ptr %l38, !tbaa !24
  %t489 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t485, i64 %t486)
  store { i64, [1 x i64] } %t489, ptr %l305
  br label %bb134
bb129:
  %t490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t490, ptr %l292, !tbaa !29
  %t491 = load i64, ptr %l1, !tbaa !24
  store i64 %t491, ptr %l293, !tbaa !24
  %t492 = load ptr, ptr %l7, !tbaa !29
  %t494 = getelementptr %"compiler/mir:Fn", ptr %t492, i32 0, i32 12
  %t495 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t496 = load i32, ptr %t495, !tbaa !23
  %t498 = sext i32 %t496 to i64
  %t499 = load i64, ptr %l38, !tbaa !24
  %t502 = add i64 %t498, %t499
  %t505 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t494, i64 %t502)
  store { i64, [1 x i64] } %t505, ptr %l300
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t506 = load ptr, ptr %l292, !tbaa !29
  %t507 = load i64, ptr %l293, !tbaa !24
  %t508 = load { i64, [1 x i64] }, ptr %l300
  %t509 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t506, i64 %t507, { i64, [1 x i64] } %t508)
  store i64 %t509, ptr %l301
  br label %bb132
bb132:
  %t510 = load i64, ptr %l301, !tbaa !24
  store i64 %t510, ptr %l39, !tbaa !24
  br label %bb133
bb133:
  br label %bb185
bb134:
  %t511 = load { i64, [1 x i64] }, ptr %l305
  store { i64, [1 x i64] } %t511, ptr %l40
  %t512 = load { i64, [1 x i64] }, ptr %l40
  %t514 = extractvalue { i64, [1 x i64] } %t512, 0
  %t515 = icmp eq i64 %t514, 0
  br i1 %t515, label %bb135, label %bb136
bb135:
  %t517 = getelementptr { i64, [1 x i64] }, ptr %l40, i32 0, i32 1
  %t518 = getelementptr { i64 }, ptr %t517, i32 0, i32 0
  %t519 = load i64, ptr %t518
  store i64 %t519, ptr %l41, !tbaa !24
  br label %bb137
bb136:
  br label %bb138
bb137:
  %t521 = load i64, ptr %l41, !tbaa !24
  store i64 %t521, ptr %l306, !tbaa !24
  br label %bb153
bb138:
  %t523 = load { i64, [1 x i64] }, ptr %l40
  %t525 = extractvalue { i64, [1 x i64] } %t523, 0
  %t526 = icmp eq i64 %t525, 1
  br i1 %t526, label %bb139, label %bb140
bb139:
  br label %bb143
bb140:
  %t528 = load { i64, [1 x i64] }, ptr %l40
  %t530 = extractvalue { i64, [1 x i64] } %t528, 0
  %t531 = icmp eq i64 %t530, 2
  br i1 %t531, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t533 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  store i64 %t533, ptr %l306, !tbaa !24
  br label %bb153
bb144:
  %t535 = load { i64, [1 x i64] }, ptr %l40
  %t537 = extractvalue { i64, [1 x i64] } %t535, 0
  %t538 = icmp eq i64 %t537, 3
  br i1 %t538, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t540 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  store i64 %t540, ptr %l306, !tbaa !24
  br label %bb153
bb148:
  br i1 true, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  store i64 -9, ptr %l306, !tbaa !24
  br label %bb153
bb152:
  call void @__olang_check_failed(ptr @olang_loc_5609b5c4ef82b256_83c053ae3d548522)
  unreachable
bb153:
  %t542 = load i64, ptr %l306, !tbaa !24
  store i64 %t542, ptr %l42, !tbaa !24
  store i1 false, ptr %l43, !tbaa !21
  store i64 0, ptr %l44, !tbaa !24
  %t543 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t545 = extractvalue { i64, ptr } %t543, 0
  store i64 %t545, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t547 = load i64, ptr %l45, !tbaa !24
  %t548 = load i64, ptr %l44, !tbaa !24
  %t551 = icmp sgt i64 %t547, %t548
  br i1 %t551, label %bb154, label %bb155
bb154:
  %t553 = load i64, ptr %l46, !tbaa !24
  %t555 = icmp sgt i64 %t553, 0
  br i1 %t555, label %bb156, label %bb157
bb155:
  store i64 0, ptr %l324, !tbaa !24
  br label %bb159
bb156:
  %t557 = load i64, ptr %l45, !tbaa !24
  %t558 = load i64, ptr %l44, !tbaa !24
  %t561 = sub i64 %t557, %t558
  %t562 = load i64, ptr %l46, !tbaa !24
  %t565 = add i64 %t561, %t562
  %t567 = sub i64 %t565, 1
  %t568 = load i64, ptr %l46, !tbaa !24
  %t571 = sdiv i64 %t567, %t568
  store i64 %t571, ptr %l327, !tbaa !24
  br label %bb158
bb157:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb158
bb158:
  %t573 = load i64, ptr %l327, !tbaa !24
  store i64 %t573, ptr %l324, !tbaa !24
  br label %bb159
bb159:
  %t574 = load i64, ptr %l324, !tbaa !24
  store i64 %t574, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb160
bb160:
  %t575 = load i64, ptr %l48, !tbaa !24
  %t576 = load i64, ptr %l47, !tbaa !24
  %t579 = icmp slt i64 %t575, %t576
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb161, label %bb162
bb161:
  br label %bb173
bb162:
  br label %bb163
bb163:
  %t583 = load i64, ptr %l44, !tbaa !24
  %t584 = load i64, ptr %l48, !tbaa !24
  %t585 = load i64, ptr %l46, !tbaa !24
  %t588 = mul i64 %t584, %t585
  %t591 = add i64 %t583, %t588
  store i64 %t591, ptr %l49, !tbaa !24
  %t593 = load i64, ptr %l49, !tbaa !24
  %t595 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t596 = load ptr, ptr %t595, !tbaa !27
  %t597 = getelementptr i64, ptr %t596, i64 %t593
  %t598 = load i64, ptr %t597, !tbaa !34
  %t599 = load i64, ptr %l42, !tbaa !24
  %t602 = icmp eq i64 %t598, %t599
  br i1 %t602, label %bb164, label %bb165
bb164:
  %t604 = load i64, ptr %l49, !tbaa !24
  %t605 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t606 = load i32, ptr %t605, !tbaa !23
  %t608 = sext i32 %t606 to i64
  %t611 = icmp slt i64 %t604, %t608
  store i1 %t611, ptr %l349, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb166
bb166:
  %t613 = load i1, ptr %l349, !tbaa !21
  br i1 %t613, label %bb167, label %bb168
bb167:
  %t614 = load ptr, ptr %l0, !tbaa !29
  store ptr %t614, ptr %l354, !tbaa !29
  %t615 = load i64, ptr %l1, !tbaa !24
  store i64 %t615, ptr %l355, !tbaa !24
  %t616 = load ptr, ptr %l7, !tbaa !29
  %t618 = getelementptr %"compiler/mir:Fn", ptr %t616, i32 0, i32 12
  %t619 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t620 = load i32, ptr %t619, !tbaa !23
  %t622 = sext i32 %t620 to i64
  %t623 = load i64, ptr %l49, !tbaa !24
  %t626 = add i64 %t622, %t623
  %t629 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t618, i64 %t626)
  store { i64, [1 x i64] } %t629, ptr %l362
  br label %bb169
bb168:
  br label %bb171
bb169:
  %t630 = load ptr, ptr %l354, !tbaa !29
  %t631 = load i64, ptr %l355, !tbaa !24
  %t632 = load { i64, [1 x i64] }, ptr %l362
  %t633 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t630, i64 %t631, { i64, [1 x i64] } %t632)
  store i64 %t633, ptr %l363
  br label %bb170
bb170:
  %t634 = load i64, ptr %l363, !tbaa !24
  store i64 %t634, ptr %l39, !tbaa !24
  store i1 true, ptr %l43, !tbaa !21
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t635 = load i64, ptr %l48, !tbaa !24
  %t638 = add i64 %t635, 1
  store i64 %t638, ptr %l48, !tbaa !24
  br label %bb160
bb173:
  %t640 = load i1, ptr %l43, !tbaa !21
  %t642 = xor i1 %t640, true
  br i1 %t642, label %bb174, label %bb175
bb174:
  %t644 = load i64, ptr %l42, !tbaa !24
  %t645 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t648 = icmp eq i64 %t644, %t645
  store i1 %t648, ptr %l369, !tbaa !21
  br label %bb176
bb175:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb176
bb176:
  %t650 = load i1, ptr %l369, !tbaa !21
  br i1 %t650, label %bb177, label %bb178
bb177:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/eval:Machine", ptr %t651, i32 0, i32 0
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load ptr, ptr %l18, !tbaa !29
  %t657 = getelementptr %"compiler/mir:Fn", ptr %t655, i32 0, i32 1
  %t658 = load i32, ptr %t657, !tbaa !23
  %t661 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t654, i32 %t658)
  store i64 %t661, ptr %l378
  br label %bb179
bb178:
  store i1 false, ptr %l373, !tbaa !21
  br label %bb180
bb179:
  %t662 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleTail, !tbaa !24
  %t663 = load i64, ptr %l378, !tbaa !24
  %t665 = icmp eq i64 %t663, %t662
  store i1 %t665, ptr %l373, !tbaa !21
  br label %bb180
bb180:
  %t667 = load i1, ptr %l373, !tbaa !21
  br i1 %t667, label %bb181, label %bb182
bb181:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load i64, ptr @G_2ecompiler_2feval_2esBlock, !tbaa !24
  %t672 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t668, i64 %t669)
  store i64 %t672, ptr %l383
  br label %bb183
bb182:
  br label %bb184
bb183:
  %t673 = load i64, ptr %l383, !tbaa !24
  store i64 %t673, ptr %l39, !tbaa !24
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t676 = getelementptr %"compiler/eval:Machine", ptr %t674, i32 0, i32 59
  %t677 = load { i64, ptr }, ptr %t676, !tbaa !27
  store { i64, ptr } %t677, ptr %l385, !tbaa !27
  %t678 = load i64, ptr %l17, !tbaa !24
  %t679 = load i64, ptr %l39, !tbaa !24
  %t682 = getelementptr { i64, ptr }, ptr %l385, i32 0, i32 1
  %t683 = load ptr, ptr %t682, !tbaa !27
  %t684 = getelementptr %"compiler/eval:frame", ptr %t683, i64 %t678
  %t685 = getelementptr %"compiler/eval:frame", ptr %t684, i32 0, i32 19
  store i64 %t679, ptr %t685, !tbaa !24
  br label %bb184
bb184:
  br label %bb185
bb185:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/eval:Machine", ptr %t686, i32 0, i32 61
  %t689 = load { i64, ptr }, ptr %t688, !tbaa !27
  store { i64, ptr } %t689, ptr %l389, !tbaa !27
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t692 = getelementptr %"compiler/eval:Machine", ptr %t690, i32 0, i32 59
  %t693 = load { i64, ptr }, ptr %t692, !tbaa !27
  store { i64, ptr } %t693, ptr %l391, !tbaa !27
  %t694 = load i64, ptr %l17, !tbaa !24
  %t696 = getelementptr { i64, ptr }, ptr %l391, i32 0, i32 1
  %t697 = load ptr, ptr %t696, !tbaa !27
  %t698 = getelementptr %"compiler/eval:frame", ptr %t697, i64 %t694
  %t699 = getelementptr %"compiler/eval:frame", ptr %t698, i32 0, i32 5
  %t700 = load i64, ptr %t699, !tbaa !24
  %t701 = load i64, ptr %l38, !tbaa !24
  %t704 = add i64 %t700, %t701
  %t705 = load i64, ptr %l39, !tbaa !24
  %t708 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !27
  %t710 = getelementptr i64, ptr %t709, i64 %t704
  store i64 %t705, ptr %t710, !tbaa !34
  br label %bb186
bb186:
  %t711 = load i64, ptr %l37, !tbaa !24
  %t714 = add i64 %t711, 1
  store i64 %t714, ptr %l37, !tbaa !24
  br label %bb116
bb187:
  %t716 = load i64, ptr %l14, !tbaa !24
  %t718 = icmp sge i64 %t716, 0
  br i1 %t718, label %bb188, label %bb189
bb188:
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = getelementptr %"compiler/eval:Machine", ptr %t720, i32 0, i32 59
  %t723 = load { i64, ptr }, ptr %t722, !tbaa !27
  store { i64, ptr } %t723, ptr %l403, !tbaa !27
  %t724 = load i64, ptr %l17, !tbaa !24
  %t725 = load i64, ptr %l14, !tbaa !24
  %t727 = trunc i64 %t725 to i32
  %t730 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !27
  %t732 = getelementptr %"compiler/eval:frame", ptr %t731, i64 %t724
  %t733 = getelementptr %"compiler/eval:frame", ptr %t732, i32 0, i32 18
  store i32 %t727, ptr %t733, !tbaa !23
  %t734 = load i64, ptr %l14, !tbaa !24
  store i64 2, ptr %l51, !tbaa !24
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t738 = getelementptr %"compiler/eval:Machine", ptr %t736, i32 0, i32 64
  %t742 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v0, ptr %t738, i64 %t734)
  store ptr %t742, ptr %l411
  br label %bb190
bb189:
  br label %bb191
bb190:
  %t743 = load ptr, ptr %l411, !tbaa !29
  %t745 = load i64, ptr %l51, !tbaa !24
  %t748 = getelementptr %"compiler/eval:genRec", ptr %t743, i32 0, i32 0
  store i64 %t745, ptr %t748, !tbaa !24
  br label %bb191
bb191:
  %t749 = load i1, ptr %l15, !tbaa !21
  %t751 = xor i1 %t749, true
  br i1 %t751, label %bb192, label %bb193
bb192:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i64, ptr %l17, !tbaa !24
  %t755 = load ptr, ptr %l18, !tbaa !29
  %t756 = load %"compiler/eval:Ptr", ptr %l10
  %t757 = load i64, ptr %l27, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloadCaptures(ptr %v0, ptr %v0, ptr %t753, i64 %t754, ptr %t755, %"compiler/eval:Ptr" %t756, i64 %t757)
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb195
bb195:
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/eval:Machine", ptr %t763, i32 0, i32 23
  %t766 = load i1, ptr %t765, !tbaa !21
  br i1 %t766, label %bb196, label %bb197
bb196:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb197:
  br label %bb198
bb198:
  %t769 = load i64, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t769, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t12 = icmp eq i32 %t10, 3
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 0, ptr %l7
  br label %bb54
bb5:
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t15, 4
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i32 1, ptr %l7
  br label %bb54
bb9:
  %t20 = load i32, ptr %l2, !tbaa !23
  %t22 = icmp eq i32 %t20, 5
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i32 2, ptr %l7
  br label %bb54
bb13:
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = icmp eq i32 %t25, 7
  br i1 %t27, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i32 4, ptr %l7
  br label %bb54
bb17:
  %t30 = load i32, ptr %l2, !tbaa !23
  %t32 = icmp eq i32 %t30, 8
  br i1 %t32, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i32 5, ptr %l7
  br label %bb54
bb21:
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = icmp eq i32 %t35, 9
  br i1 %t37, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 6, ptr %l7
  br label %bb54
bb25:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t42 = icmp eq i32 %t40, 10
  br i1 %t42, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i32 7, ptr %l7
  br label %bb54
bb29:
  %t45 = load i32, ptr %l2, !tbaa !23
  %t47 = icmp eq i32 %t45, 11
  br i1 %t47, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i32 8, ptr %l7
  br label %bb54
bb33:
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = icmp eq i32 %t50, 12
  br i1 %t52, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i32 9, ptr %l7
  br label %bb54
bb37:
  %t55 = load i32, ptr %l2, !tbaa !23
  %t57 = icmp eq i32 %t55, 13
  br i1 %t57, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i32 10, ptr %l7
  br label %bb54
bb41:
  %t60 = load i32, ptr %l2, !tbaa !23
  %t62 = icmp eq i32 %t60, 14
  br i1 %t62, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i32 11, ptr %l7
  br label %bb54
bb45:
  %t65 = load i32, ptr %l2, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t69 = icmp eq i32 %t65, %t66
  br i1 %t69, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i32 4, ptr %l7
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i32 3, ptr %l7
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_b477747d616f01f0_6d4a3c12dca1cf4c)
  unreachable
bb54:
  %t73 = load i32, ptr %l7, !range !{i32 0, i32 12}
  store i32 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = icmp eq i32 %t10, 11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = and i64 %t14, 65535
  %t18 = trunc i64 %t16 to i16
  %t20 = call i16 asm "", "=r,0"(i16 %t18)
  %t21 = bitcast i16 %t20 to half
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t23 = fpext half %t21 to double
  %t24 = call ptr @__olang_sb_room(ptr %s2, i64 48)
  %t25 = call i64 @__olang_fmt_float(ptr %t24, i64 48, double %t23, i32 2)
  call void @__olang_sb_add(ptr %s2, i64 %t25)
  %t26 = load ptr, ptr %s2
  %t27 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t28 = load i64, ptr %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t26, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l15, !tbaa !27
  %t32 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t33 = load ptr, ptr %t32
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %sbgrew.35, label %sbdone.36
sbgrew.35:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.36
sbdone.36:
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l8, !tbaa !27
  br label %bb18
bb5:
  %t38 = load i32, ptr %l3, !tbaa !23
  %t40 = icmp eq i32 %t38, 12
  br i1 %t40, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = and i64 %t42, 65535
  %t46 = trunc i64 %t44 to i16
  %t48 = bitcast i16 %t46 to bfloat
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t50 = fpext bfloat %t48 to double
  %t51 = call ptr @__olang_sb_room(ptr %s4, i64 48)
  %t52 = call i64 @__olang_fmt_float(ptr %t51, i64 48, double %t50, i32 3)
  call void @__olang_sb_add(ptr %s4, i64 %t52)
  %t53 = load ptr, ptr %s4
  %t54 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t55 = load i64, ptr %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t53, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l22, !tbaa !27
  %t59 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t60 = load ptr, ptr %t59
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %sbgrew.62, label %sbdone.63
sbgrew.62:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.63
sbdone.63:
  %t64 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  br label %bb18
bb9:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t67 = icmp eq i32 %t65, 13
  br i1 %t67, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = and i64 %t69, 4294967295
  %t73 = trunc i64 %t71 to i32
  %t75 = bitcast i32 %t73 to float
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t77 = fpext float %t75 to double
  %t78 = call ptr @__olang_sb_room(ptr %s6, i64 48)
  %t79 = call i64 @__olang_fmt_float(ptr %t78, i64 48, double %t77, i32 1)
  call void @__olang_sb_add(ptr %s6, i64 %t79)
  %t80 = load ptr, ptr %s6
  %t81 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t82 = load i64, ptr %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t80, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l29, !tbaa !27
  %t86 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t87 = load ptr, ptr %t86
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %sbgrew.89, label %sbdone.90
sbgrew.89:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.90
sbdone.90:
  %t91 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t95 = bitcast i64 %t92 to double
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t97 = call ptr @__olang_sb_room(ptr %s8, i64 48)
  %t98 = call i64 @__olang_fmt_float(ptr %t97, i64 48, double %t95, i32 0)
  call void @__olang_sb_add(ptr %s8, i64 %t98)
  %t99 = load ptr, ptr %s8
  %t100 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t101 = load i64, ptr %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t99, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l33, !tbaa !27
  %t105 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t106 = load ptr, ptr %t105
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %sbgrew.108, label %sbdone.109
sbgrew.108:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.109
sbdone.109:
  %t110 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t110, ptr %l8, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1a5820d8caa3da70_8ddb412d29c69c24)
  unreachable
bb18:
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eforeignRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i1
  %l28 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l20
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i32, ptr %l20, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l21
  br label %bb7
bb7:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l4, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l24
  br label %bb8
bb8:
  %t40 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t42 = trunc i64 18 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l31
  br label %bb11
bb10:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = load i32, ptr %l31, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l32
  br label %bb12
bb12:
  %t54 = load i32, ptr %l32, !range !{i32 0, i32 6}
  %t56 = trunc i64 5 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l27, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2egenIndex(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/eval:Ptr" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { { i64, ptr }, i64 }
  %l14 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca %"compiler/mir:Local"
  %l60 = alloca { { i64, ptr }, i64 }
  %l62 = alloca ptr
  %l63 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l72 = alloca %"compiler/eval:Ptr"
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 5
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_9c073bf56b8103e8_f70ded813690f4)
  unreachable
bb4:
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 5
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t20)
  store i64 %t22, ptr %l20
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9c073bf56b8103e8_f70ded813690f4)
  unreachable
bb6:
  %t23 = load i64, ptr %l20, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb12
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l27, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l27, !tbaa !24
  store i64 %t50, ptr %l24, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l24, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  store i64 %t70, ptr %l45, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/mir:Fn", ptr %t71, i32 0, i32 7
  store ptr %t73, ptr %l47, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/mir:Fn", ptr %t74, i32 0, i32 5
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t76, i64 %t77)
  store i32 %t80, ptr %l51
  br label %bb17
bb17:
  %t81 = load i32, ptr %l51, !tbaa !23
  %t82 = sext i32 %t81 to i64
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t85 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t83, i64 %t82)
  store %"compiler/mir:Local" %t85, ptr %l53
  br label %bb18
bb18:
  %t86 = getelementptr %"compiler/mir:Local", ptr %l53, i32 0, i32 2
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = load i64, ptr %l45, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t89
  store i32 %t87, ptr %t92, !tbaa !33
  br label %bb19
bb19:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l8, !tbaa !24
  br label %bb13
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t102 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %s0, ptr %s0, ptr %t98, { i64, ptr } %t99)
  store { { i64, ptr }, i64 } %t102, ptr %l60
  br label %bb21
bb21:
  %t103 = load { { i64, ptr }, i64 }, ptr %l60
  store { { i64, ptr }, i64 } %t103, ptr %l10
  %t104 = getelementptr { { i64, ptr }, i64 }, ptr %l10, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l62, !tbaa !29
  %t108 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l63, !tbaa !24
  %t110 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t115 = add i64 %t111, %t105
  store i64 %t115, ptr %l66, !tbaa !24
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/mir:Fn", ptr %t116, i32 0, i32 5
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t118)
  store i64 %t120, ptr %l69
  br label %bb22
bb22:
  %t121 = load i64, ptr %l69, !tbaa !24
  %t122 = mul i64 8, %t121
  %t123 = load i64, ptr %l66, !tbaa !24
  %t125 = add i64 %t123, %t122
  %t126 = load i64, ptr %l63, !tbaa !24
  %t128 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t126, i64 %t125)
  store %"compiler/eval:Ptr" %t128, ptr %l72
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l62, !tbaa !29
  %t130 = load %"compiler/eval:Ptr", ptr %l72
  %t131 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t129, %"compiler/eval:Ptr" %t130, i64 8)
  store i64 %t131, ptr %l73
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t132 = load i64, ptr %l73, !tbaa !24
  store i64 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenOver(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [7 x i64] } %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca %"compiler/mir:Call"
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca %"compiler/mir:Call"
  %l26 = alloca i64
  %l30 = alloca ptr
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l41 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l56 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t5 = icmp ne i64 %a4, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l14
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l17
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t17 = getelementptr %"compiler/mir:Fn", ptr %t15, i32 0, i32 14
  %t21 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t17, i64 %a5)
  store %"compiler/mir:Call" %t21, ptr %l21
  br label %bb6
bb6:
  %t22 = load %"compiler/mir:Call", ptr %l21
  store %"compiler/mir:Call" %t22, ptr %l6
  %t23 = getelementptr %"compiler/mir:Call", ptr %l6, i32 0, i32 7
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t28 = icmp eq i32 %t24, %t25
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l26
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 26
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %s0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l30
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l30, !tbaa !29
  %t42 = getelementptr %"compiler/mir:Fn", ptr %t40, i32 0, i32 26
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 26
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %s0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l38
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l38, !tbaa !29
  %t58 = getelementptr %"compiler/mir:Fn", ptr %t56, i32 0, i32 1
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t60, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb13
bb13:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %l8, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l43, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t74 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %t68, i64 %t69, { i64, [7 x i64] } %a3)
  store i32 %t74, ptr %l47
  br label %bb14
bb14:
  %t75 = load ptr, ptr %l43, !tbaa !29
  %t76 = load i32, ptr %l47, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l48
  br label %bb15
bb15:
  %t78 = load i32, ptr %l48, !tbaa !23
  store i32 %t78, ptr %l9, !tbaa !23
  %t79 = load i32, ptr %l8, !tbaa !23
  %t80 = load i32, ptr %l9, !tbaa !23
  %t83 = icmp ne i32 %t79, %t80
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i32, ptr %l8, !tbaa !23
  %t88 = load i32, ptr %l9, !tbaa !23
  %t93 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %t85, i64 %t86, i32 %t87, i32 %t88)
  store i64 %t93, ptr %l56
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t94 = load i64, ptr %l56, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  br label %bb19
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l1, !tbaa !24
  %t98 = getelementptr %"compiler/mir:Call", ptr %l6, i32 0, i32 6
  %t99 = load i32, ptr %t98, !tbaa !23
  %t103 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t96, i64 %t97, i32 %t99)
  store %"compiler/eval:Ptr" %t103, ptr %l61
  br label %bb20
bb20:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l57, !tbaa !29
  %t106 = load %"compiler/eval:Ptr", ptr %l61
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t105, %"compiler/eval:Ptr" %t106, i64 4, i64 %t104)
  br label %bb21
bb21:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l1, !tbaa !24
  %t110 = getelementptr %"compiler/mir:Call", ptr %l6, i32 0, i32 7
  %t111 = load i32, ptr %t110, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t108, i64 %t109, i32 %t111)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalWritten(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca %"compiler/eval:gkey"
  %l17 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64, i32, i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t14 = getelementptr { i64, i32, i32 }, ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 44
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s1, i64 %t20, i32 %t21)
  store %"compiler/eval:gkey" %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load %"compiler/eval:gkey", ptr %l16
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t25, %"compiler/eval:gkey" %t26)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l18
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l17
  br label %bb5
bb5:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l11, !tbaa !24
  store i64 %t33, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 74
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp ne i64 %t38, %t42
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar, !tbaa !27
  %t50 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t50, ptr %t48, { i64, ptr } %t49)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cdcdbab6c5a00ca5_1566754bdc1f9529)
  unreachable
bb21:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalsReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca %"compiler/mir:Lvalue"
  %l7 = alloca %"compiler/mir:Lvalue"
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Range"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l42 = alloca i1
  %l55 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca i1
  %l91 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l104 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 26
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 59
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:frame", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t14)
  store ptr %t17, ptr %l19
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l19, !tbaa !29
  store ptr %t18, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 1
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 2}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalWritten(ptr %v0, ptr %t27, %"compiler/mir:Lvalue" %a2)
  store i1 %t31, ptr %l26
  br label %bb4
bb3:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb5
bb4:
  %t32 = load i1, ptr %l26, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb5
bb5:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, [15 x i64] }, ptr %l3
  %t39 = extractvalue { i64, [15 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 0
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t43 = getelementptr { { i64, [4 x i64] } }, ptr %t42, i32 0, i32 0
  %t44 = load { i64, [4 x i64] }, ptr %t43
  store { i64, [4 x i64] } %t44, ptr %l5
  br label %bb15
bb10:
  %t46 = load { i64, [15 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [15 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 7
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t51, i32 0, i32 1
  %t53 = load { i64, [4 x i64] }, ptr %t52
  store { i64, [4 x i64] } %t53, ptr %l5
  br label %bb15
bb12:
  %t55 = load { i64, [15 x i64] }, ptr %l3
  %t57 = extractvalue { i64, [15 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 11
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t61 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t60, i32 0, i32 0
  %t62 = load { i64, [4 x i64] }, ptr %t61
  store { i64, [4 x i64] } %t62, ptr %l5
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = load { i64, [4 x i64] }, ptr %l5
  %t70 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t64, i64 %t65, { i64, [4 x i64] } %t66)
  store i1 %t70, ptr %l42
  br label %bb16
bb16:
  %t71 = load i1, ptr %l42, !tbaa !21
  store i1 %t71, ptr %l29, !tbaa !21
  br label %bb64
bb17:
  %t72 = load { i64, [15 x i64] }, ptr %l3
  %t74 = extractvalue { i64, [15 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 1
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t78 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t77, i32 0, i32 0
  %t79 = load %"compiler/mir:Lvalue", ptr %t78
  store %"compiler/mir:Lvalue" %t79, ptr %l6
  br label %bb24
bb19:
  %t81 = load { i64, [15 x i64] }, ptr %l3
  %t83 = extractvalue { i64, [15 x i64] } %t81, 0
  %t84 = icmp eq i64 %t83, 2
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t87 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t86, i32 0, i32 0
  %t88 = load %"compiler/mir:Lvalue", ptr %t87
  store %"compiler/mir:Lvalue" %t88, ptr %l6
  br label %bb24
bb21:
  %t90 = load { i64, [15 x i64] }, ptr %l3
  %t92 = extractvalue { i64, [15 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 5
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t95 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t96 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t95, i32 0, i32 0
  %t97 = load %"compiler/mir:Lvalue", ptr %t96
  store %"compiler/mir:Lvalue" %t97, ptr %l6
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load %"compiler/mir:Lvalue", ptr %l6
  %t105 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %t99, i64 %t100, %"compiler/mir:Lvalue" %t101)
  store i1 %t105, ptr %l55
  br label %bb25
bb25:
  %t106 = load i1, ptr %l55, !tbaa !21
  store i1 %t106, ptr %l29, !tbaa !21
  br label %bb64
bb26:
  %t107 = load { i64, [15 x i64] }, ptr %l3
  %t109 = extractvalue { i64, [15 x i64] } %t107, 0
  %t110 = icmp eq i64 %t109, 9
  br i1 %t110, label %bb27, label %bb28
bb27:
  %t112 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t113 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t112, i32 0, i32 0
  %t114 = load %"compiler/mir:Lvalue", ptr %t113
  store %"compiler/mir:Lvalue" %t114, ptr %l7
  %t116 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t117 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t116, i32 0, i32 1
  %t118 = load { i64, [4 x i64] }, ptr %t117
  store { i64, [4 x i64] } %t118, ptr %l8
  %t120 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t121 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t120, i32 0, i32 2
  %t122 = load { i64, [4 x i64] }, ptr %t121
  store { i64, [4 x i64] } %t122, ptr %l9
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l1, !tbaa !24
  %t126 = load %"compiler/mir:Lvalue", ptr %l7
  %t130 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %t124, i64 %t125, %"compiler/mir:Lvalue" %t126)
  store i1 %t130, ptr %l64
  br label %bb30
bb30:
  %t131 = load i1, ptr %l64, !tbaa !21
  br i1 %t131, label %bb31, label %bb32
bb31:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load { i64, [4 x i64] }, ptr %l8
  %t138 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t132, i64 %t133, { i64, [4 x i64] } %t134)
  store i1 %t138, ptr %l69
  br label %bb33
bb32:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb34
bb33:
  %t139 = load i1, ptr %l69, !tbaa !21
  store i1 %t139, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t140 = load i1, ptr %l65, !tbaa !21
  br i1 %t140, label %bb35, label %bb36
bb35:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l1, !tbaa !24
  %t143 = load { i64, [4 x i64] }, ptr %l9
  %t147 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t141, i64 %t142, { i64, [4 x i64] } %t143)
  store i1 %t147, ptr %l74
  br label %bb37
bb36:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb38
bb37:
  %t148 = load i1, ptr %l74, !tbaa !21
  store i1 %t148, ptr %l70, !tbaa !21
  br label %bb38
bb38:
  %t149 = load i1, ptr %l70, !tbaa !21
  store i1 %t149, ptr %l29, !tbaa !21
  br label %bb64
bb39:
  %t150 = load { i64, [15 x i64] }, ptr %l3
  %t152 = extractvalue { i64, [15 x i64] } %t150, 0
  %t153 = icmp eq i64 %t152, 3
  br i1 %t153, label %bb40, label %bb41
bb40:
  %t155 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t156 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t155, i32 0, i32 2
  %t157 = load %"compiler/mir:Range", ptr %t156
  store %"compiler/mir:Range" %t157, ptr %l10
  br label %bb48
bb41:
  %t159 = load { i64, [15 x i64] }, ptr %l3
  %t161 = extractvalue { i64, [15 x i64] } %t159, 0
  %t162 = icmp eq i64 %t161, 4
  br i1 %t162, label %bb42, label %bb43
bb42:
  %t164 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t165 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t164, i32 0, i32 2
  %t166 = load %"compiler/mir:Range", ptr %t165
  store %"compiler/mir:Range" %t166, ptr %l10
  br label %bb48
bb43:
  %t168 = load { i64, [15 x i64] }, ptr %l3
  %t170 = extractvalue { i64, [15 x i64] } %t168, 0
  %t171 = icmp eq i64 %t170, 6
  br i1 %t171, label %bb44, label %bb45
bb44:
  %t173 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t174 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t173, i32 0, i32 2
  %t175 = load %"compiler/mir:Range", ptr %t174
  store %"compiler/mir:Range" %t175, ptr %l10
  br label %bb48
bb45:
  %t177 = load { i64, [15 x i64] }, ptr %l3
  %t179 = extractvalue { i64, [15 x i64] } %t177, 0
  %t180 = icmp eq i64 %t179, 10
  br i1 %t180, label %bb46, label %bb47
bb46:
  %t182 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t183 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t182, i32 0, i32 3
  %t184 = load %"compiler/mir:Range", ptr %t183
  store %"compiler/mir:Range" %t184, ptr %l10
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l1, !tbaa !24
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t189 = load %"compiler/mir:Range", ptr %l10
  %t194 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v0, ptr %t186, i64 %t187, ptr %t188, %"compiler/mir:Range" %t189)
  store i1 %t194, ptr %l91
  br label %bb49
bb49:
  %t195 = load i1, ptr %l91, !tbaa !21
  store i1 %t195, ptr %l29, !tbaa !21
  br label %bb64
bb50:
  %t196 = load { i64, [15 x i64] }, ptr %l3
  %t198 = extractvalue { i64, [15 x i64] } %t196, 0
  %t199 = icmp eq i64 %t198, 8
  br i1 %t199, label %bb51, label %bb52
bb51:
  %t201 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t202 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t201, i32 0, i32 2
  %t203 = load { i64, [4 x i64] }, ptr %t202
  store { i64, [4 x i64] } %t203, ptr %l11
  %t205 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t206 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t205, i32 0, i32 3
  %t207 = load { i64, [4 x i64] }, ptr %t206
  store { i64, [4 x i64] } %t207, ptr %l12
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l1, !tbaa !24
  %t211 = load { i64, [4 x i64] }, ptr %l11
  %t215 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t209, i64 %t210, { i64, [4 x i64] } %t211)
  store i1 %t215, ptr %l99
  br label %bb54
bb54:
  %t216 = load i1, ptr %l99, !tbaa !21
  br i1 %t216, label %bb55, label %bb56
bb55:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i64, ptr %l1, !tbaa !24
  %t219 = load { i64, [4 x i64] }, ptr %l12
  %t223 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t217, i64 %t218, { i64, [4 x i64] } %t219)
  store i1 %t223, ptr %l104
  br label %bb57
bb56:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb58
bb57:
  %t224 = load i1, ptr %l104, !tbaa !21
  store i1 %t224, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t225 = load i1, ptr %l100, !tbaa !21
  store i1 %t225, ptr %l29, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_d7d71e32b1402da8_19cce939fe39e26c)
  unreachable
bb64:
  %t226 = load i1, ptr %l29, !tbaa !21
  store i1 %t226, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eholders(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr { ptr, i64, ptr }, ptr null, i32 1
  %t7 = ptrtoint ptr %t6 to i64
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t7, i64 8)
  %t9 = getelementptr { ptr, i64, ptr }, ptr %t8, i32 0, i32 0
  store ptr %t4, ptr %t9, !tbaa !28
  %t11 = getelementptr { ptr, i64, ptr }, ptr %t8, i32 0, i32 1
  store i64 %a3, ptr %t11, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t13 = call ptr @__olang_scope_hold(ptr %v0)
  %t14 = getelementptr { ptr, i64, ptr }, ptr %t8, i32 0, i32 2
  store ptr %t13, ptr %t14, !tbaa !28
  %t15 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_4, 0
  %t16 = insertvalue { ptr, ptr } %t15, ptr %t8, 1
  %t21 = extractvalue { ptr, ptr } %t16, 0
  %t22 = extractvalue { ptr, ptr } %t16, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenWalk(ptr %v0, ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i32 %a2, i1 true, ptr %t21, ptr %t22)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2einitFrame(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca { i64, [1 x i64] }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 7
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t15 = icmp eq i64 %t11, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 59
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l16, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t26, 1
  %t30 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/eval:frame", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/eval:frame", ptr %t32, i32 0, i32 7
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t38 = icmp ne i64 %t34, %t35
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l14, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 26
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 59
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/eval:frame", ptr %t52, i64 %t49
  %t54 = getelementptr %"compiler/eval:frame", ptr %t53, i32 0, i32 0
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t44, i64 %t55)
  store ptr %t58, ptr %l29
  br label %bb10
bb10:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t61 = getelementptr %"compiler/mir:Fn", ptr %t59, i32 0, i32 6
  store ptr %t61, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l32, !tbaa !24
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l34
  br label %bb12
bb12:
  %t67 = load i64, ptr %l32, !tbaa !24
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb13, label %bb14
bb13:
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t73, i64 %t74)
  store { i64, [1 x i64] } %t77, ptr %l39
  br label %bb16
bb16:
  %t78 = load { i64, [1 x i64] }, ptr %l39
  %t81 = extractvalue { i64, [1 x i64] } %t78, 0
  %t82 = icmp eq i64 %t81, 2
  br i1 %t82, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a8aea866c7f3b59a_8137d523407c73ee)
  unreachable
bb25:
  br label %bb26
bb26:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l3, !tbaa !24
  br label %bb11
bb27:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = load { i64, [4 x i64] }, ptr %l2
  %t8 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t2, i64 %t3, { i64, [4 x i64] } %t4)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l2
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t16, i64 %t17, i32 %t18)
  store i64 %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintToFloat(ptr %v0, ptr %a0, i64 %a1, i1 %a2, i32 %a3) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i32
  %l13 = alloca i64
  %l36 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a3)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !65
  %t15 = load i32, ptr %l4, !tbaa !23
  %t17 = icmp eq i32 %t15, 11
  br i1 %t17, label %bb4, label %bb5
bb3:
  br label %bb21
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load i64, ptr %l5, !tbaa !65
  %t21 = uitofp i64 %t19 to double
  %t22 = call double @llvm.arithmetic.fence.f64(double %t21)
  %t23 = fptrunc double %t22 to half
  %t25 = bitcast half %t23 to i16
  %t26 = call i16 asm "", "=r,0"(i16 %t25)
  %t28 = zext i16 %t26 to i64
  store i64 %t28, ptr %l13, !tbaa !24
  br label %bb20
bb7:
  %t30 = load i32, ptr %l4, !tbaa !23
  %t32 = icmp eq i32 %t30, 12
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t34 = load i64, ptr %l5, !tbaa !65
  %t36 = call bfloat @__olang_int_bf16(i64 %t34, i1 false)
  %t38 = bitcast bfloat %t36 to i16
  %t39 = call i16 asm "", "=r,0"(i16 %t38)
  %t41 = zext i16 %t39 to i64
  store i64 %t41, ptr %l13, !tbaa !24
  br label %bb20
bb11:
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = icmp eq i32 %t43, 13
  br i1 %t45, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t47 = load i64, ptr %l5, !tbaa !65
  %t49 = uitofp i64 %t47 to float
  %t51 = bitcast float %t49 to i32
  %t53 = zext i32 %t51 to i64
  store i64 %t53, ptr %l13, !tbaa !24
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t55 = load i64, ptr %l5, !tbaa !65
  %t57 = uitofp i64 %t55 to double
  %t59 = bitcast double %t57 to i64
  store i64 %t59, ptr %l13, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_20cdf2bac11b5657_20b8fcdfbd19fb1b)
  unreachable
bb20:
  %t62 = load i64, ptr %l13, !tbaa !24
  store i64 %t62, ptr %rv
  br label %ret
bb21:
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = icmp eq i32 %t63, 11
  br i1 %t65, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = sitofp i64 %t67 to double
  %t70 = call double @llvm.arithmetic.fence.f64(double %t69)
  %t71 = fptrunc double %t70 to half
  %t73 = bitcast half %t71 to i16
  %t74 = call i16 asm "", "=r,0"(i16 %t73)
  %t76 = zext i16 %t74 to i64
  store i64 %t76, ptr %l36, !tbaa !24
  br label %bb38
bb25:
  %t78 = load i32, ptr %l4, !tbaa !23
  %t80 = icmp eq i32 %t78, 12
  br i1 %t80, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t82 = load i64, ptr %l1, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  %t85 = sub i64 0, %t82
  %t86 = select i1 %t84, i64 %t85, i64 %t82
  %t87 = call bfloat @__olang_int_bf16(i64 %t86, i1 %t84)
  %t89 = bitcast bfloat %t87 to i16
  %t90 = call i16 asm "", "=r,0"(i16 %t89)
  %t92 = zext i16 %t90 to i64
  store i64 %t92, ptr %l36, !tbaa !24
  br label %bb38
bb29:
  %t94 = load i32, ptr %l4, !tbaa !23
  %t96 = icmp eq i32 %t94, 13
  br i1 %t96, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t98 = load i64, ptr %l1, !tbaa !24
  %t100 = sitofp i64 %t98 to float
  %t102 = bitcast float %t100 to i32
  %t104 = zext i32 %t102 to i64
  store i64 %t104, ptr %l36, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t106 = load i64, ptr %l1, !tbaa !24
  %t108 = sitofp i64 %t106 to double
  %t110 = bitcast double %t108 to i64
  store i64 %t110, ptr %l36, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_3dd741f2ac40c2b6_e435d9fa661ce11a)
  unreachable
bb38:
  %t113 = load i64, ptr %l36, !tbaa !24
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ekindWidth(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i8
  %l5 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = and i8 %a1, 127
  store i8 %t3, ptr %l2, !tbaa !22
  %t5 = load i8, ptr %l2, !tbaa !22
  %t7 = icmp eq i8 %t5, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t9 = load i8, ptr %l2, !tbaa !22
  %t11 = icmp eq i8 %t9, 5
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i64 1, ptr %l5, !tbaa !24
  br label %bb29
bb6:
  %t13 = load i8, ptr %l2, !tbaa !22
  %t15 = icmp eq i8 %t13, 2
  br i1 %t15, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t17 = load i8, ptr %l2, !tbaa !22
  %t19 = icmp eq i8 %t17, 6
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t21 = load i8, ptr %l2, !tbaa !22
  %t23 = icmp eq i8 %t21, 9
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t25 = load i8, ptr %l2, !tbaa !22
  %t27 = icmp eq i8 %t25, 10
  br i1 %t27, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 2, ptr %l5, !tbaa !24
  br label %bb29
bb16:
  %t29 = load i8, ptr %l2, !tbaa !22
  %t31 = icmp eq i8 %t29, 3
  br i1 %t31, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t33 = load i8, ptr %l2, !tbaa !22
  %t35 = icmp eq i8 %t33, 7
  br i1 %t35, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t37 = load i8, ptr %l2, !tbaa !22
  %t39 = icmp eq i8 %t37, 11
  br i1 %t39, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 4, ptr %l5, !tbaa !24
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 8, ptr %l5, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_57883a0fca4ce879_b5ee1d89385345fd)
  unreachable
bb29:
  %t41 = load i64, ptr %l5, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2elaneDots(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca %"compiler/eval:Ptr"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca %"compiler/eval:Ptr"
  %l37 = alloca %"compiler/eval:Ptr"
  %l41 = alloca { i64, [4 x i64] }
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca ptr
  %l50 = alloca %"compiler/eval:Ptr"
  %l51 = alloca %"compiler/eval:Ptr"
  %l52 = alloca ptr
  %l56 = alloca %"compiler/eval:Ptr"
  %l57 = alloca %"compiler/eval:Ptr"
  %l58 = alloca ptr
  %l59 = alloca i64
  %l63 = alloca { i64, [4 x i64] }
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l70 = alloca { i64, [4 x i64] }
  %l71 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l77 = alloca { i64, [4 x i64] }
  %l78 = alloca i64
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i32
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca i32
  %l118 = alloca i64
  %l121 = alloca i64
  %l144 = alloca %"compiler/eval:Ptr"
  %l147 = alloca i64
  %l151 = alloca i64
  %l154 = alloca i64
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l182 = alloca %"compiler/eval:Ptr"
  %l183 = alloca i64
  %l185 = alloca i64
  %l186 = alloca ptr
  %l187 = alloca ptr
  %l196 = alloca %"compiler/eval:Ptr"
  %l197 = alloca i64
  %l199 = alloca i64
  %l211 = alloca ptr
  %l212 = alloca %"compiler/eval:Ptr"
  %l213 = alloca i64
  %l214 = alloca i64
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l30, !tbaa !29
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l31, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load %"compiler/mir:Range", ptr %l2
  %t10 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t4, i64 %t5, %"compiler/mir:Range" %t6, i64 0)
  store { i64, [4 x i64] } %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l30, !tbaa !29
  %t12 = load i64, ptr %l31, !tbaa !24
  %t13 = load { i64, [4 x i64] }, ptr %l35
  %t14 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t11, i64 %t12, { i64, [4 x i64] } %t13, i64 1)
  store %"compiler/eval:Ptr" %t14, ptr %l36
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l29, !tbaa !29
  %t16 = load %"compiler/eval:Ptr", ptr %l36
  %t17 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t15, %"compiler/eval:Ptr" %t16)
  store %"compiler/eval:Ptr" %t17, ptr %l37
  br label %bb3
bb3:
  %t18 = load %"compiler/eval:Ptr", ptr %l37
  store %"compiler/eval:Ptr" %t18, ptr %l3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t21 = load %"compiler/mir:Range", ptr %l2
  %t25 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t19, i64 %t20, %"compiler/mir:Range" %t21, i64 1)
  store { i64, [4 x i64] } %t25, ptr %l41
  br label %bb4
bb4:
  %t26 = load { i64, [4 x i64] }, ptr %l41
  store { i64, [4 x i64] } %t26, ptr %l4
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load %"compiler/mir:Range", ptr %l2
  %t33 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t27, i64 %t28, %"compiler/mir:Range" %t29, i64 2)
  store { i64, [4 x i64] } %t33, ptr %l45
  br label %bb5
bb5:
  %t34 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t34, ptr %l5
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l46, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = load { i64, [4 x i64] }, ptr %l4
  %t42 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t36, i64 %t37, { i64, [4 x i64] } %t38, i64 2)
  store %"compiler/eval:Ptr" %t42, ptr %l50
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l46, !tbaa !29
  %t44 = load %"compiler/eval:Ptr", ptr %l50
  %t45 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t43, %"compiler/eval:Ptr" %t44)
  store %"compiler/eval:Ptr" %t45, ptr %l51
  br label %bb7
bb7:
  %t46 = load %"compiler/eval:Ptr", ptr %l51
  store %"compiler/eval:Ptr" %t46, ptr %l6
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load { i64, [4 x i64] }, ptr %l5
  %t54 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t48, i64 %t49, { i64, [4 x i64] } %t50, i64 3)
  store %"compiler/eval:Ptr" %t54, ptr %l56
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l52, !tbaa !29
  %t56 = load %"compiler/eval:Ptr", ptr %l56
  %t57 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t55, %"compiler/eval:Ptr" %t56)
  store %"compiler/eval:Ptr" %t57, ptr %l57
  br label %bb9
bb9:
  %t58 = load %"compiler/eval:Ptr", ptr %l57
  store %"compiler/eval:Ptr" %t58, ptr %l7
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l58, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  store i64 %t60, ptr %l59, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load %"compiler/mir:Range", ptr %l2
  %t67 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t61, i64 %t62, %"compiler/mir:Range" %t63, i64 3)
  store { i64, [4 x i64] } %t67, ptr %l63
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l58, !tbaa !29
  %t69 = load i64, ptr %l59, !tbaa !24
  %t70 = load { i64, [4 x i64] }, ptr %l63
  %t71 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t68, i64 %t69, { i64, [4 x i64] } %t70)
  store i64 %t71, ptr %l64
  br label %bb11
bb11:
  %t72 = load i64, ptr %l64, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l65, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  store i64 %t74, ptr %l66, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load %"compiler/mir:Range", ptr %l2
  %t81 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t75, i64 %t76, %"compiler/mir:Range" %t77, i64 4)
  store { i64, [4 x i64] } %t81, ptr %l70
  br label %bb12
bb12:
  %t82 = load ptr, ptr %l65, !tbaa !29
  %t83 = load i64, ptr %l66, !tbaa !24
  %t84 = load { i64, [4 x i64] }, ptr %l70
  %t85 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t82, i64 %t83, { i64, [4 x i64] } %t84)
  store i64 %t85, ptr %l71
  br label %bb13
bb13:
  %t86 = load i64, ptr %l71, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l72, !tbaa !29
  %t88 = load i64, ptr %l1, !tbaa !24
  store i64 %t88, ptr %l73, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  %t91 = load %"compiler/mir:Range", ptr %l2
  %t95 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t89, i64 %t90, %"compiler/mir:Range" %t91, i64 5)
  store { i64, [4 x i64] } %t95, ptr %l77
  br label %bb14
bb14:
  %t96 = load ptr, ptr %l72, !tbaa !29
  %t97 = load i64, ptr %l73, !tbaa !24
  %t98 = load { i64, [4 x i64] }, ptr %l77
  %t99 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t96, i64 %t97, { i64, [4 x i64] } %t98)
  store i64 %t99, ptr %l78
  br label %bb15
bb15:
  %t100 = load i64, ptr %l78, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/eval:Machine", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %l80, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/eval:Machine", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  store ptr %t108, ptr %l82, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/eval:Machine", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l84, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i64, ptr %l1, !tbaa !24
  %t115 = load { i64, [4 x i64] }, ptr %l4
  %t119 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t113, i64 %t114, { i64, [4 x i64] } %t115)
  store i32 %t119, ptr %l88
  br label %bb16
bb16:
  %t120 = load ptr, ptr %l84, !tbaa !29
  %t121 = load i32, ptr %l88, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t122, ptr %l89
  br label %bb17
bb17:
  %t123 = load ptr, ptr %l82, !tbaa !29
  %t124 = load i32, ptr %l89, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t125, ptr %l90
  br label %bb18
bb18:
  %t126 = load ptr, ptr %l80, !tbaa !29
  %t127 = load i32, ptr %l90, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t128, ptr %l91
  br label %bb19
bb19:
  %t129 = load i32, ptr %l91, !tbaa !23
  store i32 %t129, ptr %l11, !tbaa !23
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  store ptr %t133, ptr %l93, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/eval:Machine", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  store ptr %t137, ptr %l95, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/eval:Machine", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  store ptr %t141, ptr %l97, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load { i64, [4 x i64] }, ptr %l5
  %t148 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t142, i64 %t143, { i64, [4 x i64] } %t144)
  store i32 %t148, ptr %l101
  br label %bb20
bb20:
  %t149 = load ptr, ptr %l97, !tbaa !29
  %t150 = load i32, ptr %l101, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t151, ptr %l102
  br label %bb21
bb21:
  %t152 = load ptr, ptr %l95, !tbaa !29
  %t153 = load i32, ptr %l102, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l103
  br label %bb22
bb22:
  %t155 = load ptr, ptr %l93, !tbaa !29
  %t156 = load i32, ptr %l103, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t157, ptr %l104
  br label %bb23
bb23:
  %t158 = load i32, ptr %l104, !tbaa !23
  store i32 %t158, ptr %l12, !tbaa !23
  %t159 = load i32, ptr %l11, !tbaa !23
  %t161 = icmp eq i32 %t159, 12
  br i1 %t161, label %bb24, label %bb25
bb24:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/eval:Ptr", ptr %l3
  %t165 = load %"compiler/eval:Ptr", ptr %l6
  %t166 = load %"compiler/eval:Ptr", ptr %l7
  %t167 = load i64, ptr %l8, !tbaa !24
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epairDots(ptr %v0, ptr %t163, %"compiler/eval:Ptr" %t164, %"compiler/eval:Ptr" %t165, %"compiler/eval:Ptr" %t166, i64 %t167, i64 %t168, i64 %t169)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %ret
bb27:
  store i64 0, ptr %l13, !tbaa !24
  %t177 = load i64, ptr %l8, !tbaa !24
  store i64 %t177, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t179 = load i64, ptr %l14, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb28, label %bb29
bb28:
  %t185 = load i64, ptr %l15, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb33
bb30:
  %t189 = load i64, ptr %l14, !tbaa !24
  %t190 = load i64, ptr %l13, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l15, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l15, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l121, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb32
bb32:
  %t205 = load i64, ptr %l121, !tbaa !24
  store i64 %t205, ptr %l118, !tbaa !24
  br label %bb33
bb33:
  %t206 = load i64, ptr %l118, !tbaa !24
  store i64 %t206, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t207 = load i64, ptr %l17, !tbaa !24
  %t208 = load i64, ptr %l16, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb64
bb36:
  br label %bb37
bb37:
  %t215 = load i64, ptr %l13, !tbaa !24
  %t216 = load i64, ptr %l17, !tbaa !24
  %t217 = load i64, ptr %l15, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  store i64 %t223, ptr %l18, !tbaa !24
  %t225 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = load i64, ptr %l18, !tbaa !24
  %t231 = mul i64 4, %t229
  %t234 = add i64 %t228, %t231
  %t237 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t226, i64 %t234)
  store %"compiler/eval:Ptr" %t237, ptr %l144
  br label %bb38
bb38:
  %t238 = load %"compiler/eval:Ptr", ptr %l144
  store %"compiler/eval:Ptr" %t238, ptr %l19
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load %"compiler/eval:Ptr", ptr %l19
  %t243 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t239, %"compiler/eval:Ptr" %t240, i64 4)
  store i64 %t243, ptr %l147
  br label %bb39
bb39:
  %t244 = load i64, ptr %l147, !tbaa !24
  store i64 %t244, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  store i64 4, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t245 = load i64, ptr %l22, !tbaa !24
  %t246 = load i64, ptr %l21, !tbaa !24
  %t249 = icmp sgt i64 %t245, %t246
  br i1 %t249, label %bb40, label %bb41
bb40:
  %t251 = load i64, ptr %l23, !tbaa !24
  %t253 = icmp sgt i64 %t251, 0
  br i1 %t253, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb45
bb42:
  %t255 = load i64, ptr %l22, !tbaa !24
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = sub i64 %t255, %t256
  %t260 = load i64, ptr %l23, !tbaa !24
  %t263 = add i64 %t259, %t260
  %t265 = sub i64 %t263, 1
  %t266 = load i64, ptr %l23, !tbaa !24
  %t269 = sdiv i64 %t265, %t266
  store i64 %t269, ptr %l154, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l154, !tbaa !24
  br label %bb44
bb44:
  %t271 = load i64, ptr %l154, !tbaa !24
  store i64 %t271, ptr %l151, !tbaa !24
  br label %bb45
bb45:
  %t272 = load i64, ptr %l151, !tbaa !24
  store i64 %t272, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t273 = load i64, ptr %l25, !tbaa !24
  %t274 = load i64, ptr %l24, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb48:
  br label %bb49
bb49:
  %t281 = load i64, ptr %l21, !tbaa !24
  %t282 = load i64, ptr %l25, !tbaa !24
  %t283 = load i64, ptr %l23, !tbaa !24
  %t286 = mul i64 %t282, %t283
  %t289 = add i64 %t281, %t286
  store i64 %t289, ptr %l26, !tbaa !24
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l172, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l173, !tbaa !29
  %t293 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t294 = load i64, ptr %t293, !tbaa !24
  %t295 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 1
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = load i64, ptr %l18, !tbaa !24
  %t298 = load i64, ptr %l9, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  %t305 = load i64, ptr %l26, !tbaa !24
  %t308 = add i64 %t304, %t305
  %t311 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t294, i64 %t308)
  store %"compiler/eval:Ptr" %t311, ptr %l182
  br label %bb50
bb50:
  %t312 = load ptr, ptr %l173, !tbaa !29
  %t313 = load %"compiler/eval:Ptr", ptr %l182
  %t314 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t312, %"compiler/eval:Ptr" %t313, i64 1)
  store i64 %t314, ptr %l183
  br label %bb51
bb51:
  %t315 = load i32, ptr %l11, !tbaa !23
  %t316 = load ptr, ptr %l172, !tbaa !29
  %t317 = load i64, ptr %l183, !tbaa !24
  %t319 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t316, i64 %t317, i32 %t315)
  store i64 %t319, ptr %l185
  br label %bb52
bb52:
  %t320 = load i64, ptr %l185, !tbaa !24
  store i64 %t320, ptr %l27, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l186, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l187, !tbaa !29
  %t323 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t324 = load i64, ptr %t323, !tbaa !24
  %t325 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t326 = load i64, ptr %t325, !tbaa !24
  %t327 = load i64, ptr %l18, !tbaa !24
  %t328 = load i64, ptr %l10, !tbaa !24
  %t331 = mul i64 %t327, %t328
  %t334 = add i64 %t326, %t331
  %t335 = load i64, ptr %l26, !tbaa !24
  %t338 = add i64 %t334, %t335
  %t341 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t324, i64 %t338)
  store %"compiler/eval:Ptr" %t341, ptr %l196
  br label %bb53
bb53:
  %t342 = load ptr, ptr %l187, !tbaa !29
  %t343 = load %"compiler/eval:Ptr", ptr %l196
  %t344 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t342, %"compiler/eval:Ptr" %t343, i64 1)
  store i64 %t344, ptr %l197
  br label %bb54
bb54:
  %t345 = load i32, ptr %l12, !tbaa !23
  %t346 = load ptr, ptr %l186, !tbaa !29
  %t347 = load i64, ptr %l197, !tbaa !24
  %t349 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t346, i64 %t347, i32 %t345)
  store i64 %t349, ptr %l199
  br label %bb55
bb55:
  %t350 = load i64, ptr %l199, !tbaa !24
  %t351 = load i64, ptr %l20, !tbaa !24
  %t353 = load i64, ptr %l27, !tbaa !24
  %t357 = mul i64 %t353, %t350
  %t360 = add i64 %t351, %t357
  store i64 %t360, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb56:
  %t362 = load i64, ptr %l25, !tbaa !24
  %t365 = add i64 %t362, 1
  store i64 %t365, ptr %l25, !tbaa !24
  br label %bb46
bb57:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/eval:Machine", ptr %t367, i32 0, i32 23
  %t370 = load i1, ptr %t369, !tbaa !21
  br i1 %t370, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb59:
  br label %bb60
bb60:
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l211, !tbaa !29
  %t373 = load %"compiler/eval:Ptr", ptr %l19
  store %"compiler/eval:Ptr" %t373, ptr %l212
  %t374 = load i64, ptr %l20, !tbaa !24
  store i64 %t374, ptr %l213, !tbaa !24
  %t375 = call i64 @compiler_2feval_2ebmask(i64 32)
  store i64 %t375, ptr %l214
  br label %bb61
bb61:
  %t376 = load i64, ptr %l213, !tbaa !24
  %t377 = load i64, ptr %l214, !tbaa !24
  %t378 = and i64 %t376, %t377
  %t379 = load ptr, ptr %l211, !tbaa !29
  %t380 = load %"compiler/eval:Ptr", ptr %l212
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t379, %"compiler/eval:Ptr" %t380, i64 4, i64 %t378)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb63:
  %t382 = load i64, ptr %l17, !tbaa !24
  %t385 = add i64 %t382, 1
  store i64 %t385, ptr %l17, !tbaa !24
  br label %bb34
bb64:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i32
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l59 = alloca i32
  %l65 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca ptr
  %l99 = alloca i64
  %l102 = alloca ptr
  %l106 = alloca i32
  %l115 = alloca i1
  %l119 = alloca i1
  %l123 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l135 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l149 = alloca i32
  %l152 = alloca i32
  %l155 = alloca i32
  %l156 = alloca { i64, ptr }
  %l161 = alloca i64
  %l164 = alloca i64
  %l185 = alloca i32
  %l198 = alloca i1
  %l201 = alloca i32
  %l204 = alloca ptr
  %l207 = alloca i32
  %l213 = alloca i1
  %l217 = alloca ptr
  %l220 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = inttoptr i64 0 to ptr
  %t12 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v2, ptr %t9, ptr %t6, i32 %t7)
  store { i64, ptr } %t12, ptr %l32
  br label %bb1
bb1:
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t13, ptr %lp5
  %t14 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t15 = load ptr, ptr %lp5
  store { i64, ptr } %t14, ptr %t15, !tbaa !27
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %lp5
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v2, ptr %t16, { i64, ptr } %t18)
  br label %bb2
bb2:
  %t21 = load ptr, ptr %lp5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l35, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l36, !tbaa !24
  %t25 = load i64, ptr %l36, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l37, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l36, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v2, ptr %s0, ptr %t37, { i64, ptr } %t36)
  store i1 %t41, ptr %l40
  br label %bb3
bb3:
  %t42 = load i1, ptr %l40, !tbaa !21
  br i1 %t42, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t43 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %lp5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v2, ptr %v2, ptr %t45, { i64, ptr } %t47, i1 true)
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t50, i32 %t51)
  store i64 %t54, ptr %l46
  br label %bb9
bb9:
  %t55 = load i64, ptr %l46, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l2, !tbaa !29
  store ptr %t56, ptr %l47, !tbaa !29
  %t57 = load i64, ptr %l7, !tbaa !24
  store i64 %t57, ptr %l48, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t58, i32 %t59)
  store i64 %t62, ptr %l51
  br label %bb10
bb10:
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t65 = load i64, ptr %l48, !tbaa !24
  %t66 = call i64 @__olang_fmt_i64(ptr null, i64 %t65)
  %t67 = add i64 %t64, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = load i64, ptr %l51, !tbaa !24
  %t72 = call i64 @__olang_fmt_i64(ptr null, i64 %t71)
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t63, i64 %t64)
  %t75 = getelementptr i8, ptr %t74, i64 %t64
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t65)
  %t77 = getelementptr i8, ptr %t75, i64 %t66
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  %t79 = call i64 @__olang_fmt_i64(ptr %t78, i64 %t71)
  %t80 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t74, 1
  %t83 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t83, { i64, ptr } %t81)
  br label %bb11
bb11:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l56
  br label %bb12
bb12:
  %t90 = load i32, ptr %l56, !tbaa !23
  store i32 %t90, ptr %l8, !tbaa !23
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t92 = load i32, ptr %l8, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l59
  br label %bb13
bb13:
  %t96 = load i32, ptr %l59, !range !{i32 0, i32 33}
  %t98 = trunc i64 18 to i32
  %t99 = icmp eq i32 %t96, %t98
  store i1 %t99, ptr %l9, !tbaa !21
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l4, !tbaa !29
  store ptr %t107, ptr %l65, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l1, !tbaa !23
  %t112 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l68
  br label %bb16
bb15:
  br label %bb34
bb16:
  %t113 = load ptr, ptr %l65, !tbaa !29
  %t114 = load i32, ptr %l68, !tbaa !23
  %t115 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s4, ptr %t113, i32 %t114)
  store { i64, ptr } %t115, ptr %l69
  br label %bb17
bb17:
  %t116 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb18, label %bb19
bb18:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb23
bb20:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l12, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l77, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb22
bb22:
  %t145 = load i64, ptr %l77, !tbaa !24
  store i64 %t145, ptr %l74, !tbaa !24
  br label %bb23
bb23:
  %t146 = load i64, ptr %l74, !tbaa !24
  store i64 %t146, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t155 = load i64, ptr %l10, !tbaa !24
  %t156 = load i64, ptr %l14, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l15, !tbaa !24
  %t165 = load ptr, ptr %l2, !tbaa !29
  store ptr %t165, ptr %l95, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l1, !tbaa !23
  %t168 = load i64, ptr %l15, !tbaa !24
  %t172 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t166, i32 %t167, i64 %t168)
  store i64 %t172, ptr %l99
  br label %bb28
bb28:
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t175 = load i64, ptr %l99, !tbaa !24
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t177 = add i64 %t174, %t176
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t173, i64 %t174)
  %t182 = getelementptr i8, ptr %t181, i64 %t174
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t175)
  %t184 = getelementptr i8, ptr %t182, i64 %t176
  call void @olang_textcopy(ptr %t184, ptr %t178, i64 %t179)
  %t185 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t181, 1
  %t188 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t188, { i64, ptr } %t186)
  br label %bb29
bb29:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l102, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i32, ptr %l1, !tbaa !23
  %t193 = load i64, ptr %l15, !tbaa !24
  %t197 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t191, i32 %t192, i64 %t193)
  store i32 %t197, ptr %l106
  br label %bb30
bb30:
  %t198 = load ptr, ptr %l2, !tbaa !29
  %t199 = load ptr, ptr %l3, !tbaa !29
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i32, ptr %l106, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %v1, ptr %v2, ptr %t200, i32 %t201, ptr %t198, ptr %t199)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t207 = add i64 %t204, 1
  store i64 %t207, ptr %l14, !tbaa !24
  br label %bb24
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t209 = load i64, ptr %l7, !tbaa !24
  %t210 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  %t213 = icmp eq i64 %t209, %t210
  br i1 %t213, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb37
bb36:
  %t215 = load i64, ptr %l7, !tbaa !24
  %t216 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t219 = icmp eq i64 %t215, %t216
  store i1 %t219, ptr %l115, !tbaa !21
  br label %bb37
bb37:
  %t221 = load i1, ptr %l115, !tbaa !21
  br i1 %t221, label %bb38, label %bb39
bb38:
  %t222 = load i1, ptr %l9, !tbaa !21
  store i1 %t222, ptr %l119, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb40
bb40:
  %t224 = load i1, ptr %l119, !tbaa !21
  br i1 %t224, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t225 = load ptr, ptr %l4, !tbaa !29
  %t226 = load i32, ptr %l8, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s9, ptr %t225, i32 %t226)
  store { i64, ptr } %t229, ptr %l123
  br label %bb43
bb42:
  br label %bb52
bb43:
  %t230 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t230, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  store i64 %t233, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t235 = load i64, ptr %l17, !tbaa !24
  %t236 = load i64, ptr %l18, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb46:
  br label %bb47
bb47:
  %t243 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t243, ptr %l130, !tbaa !27
  %t244 = load i64, ptr %l17, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i32, ptr %t247, i64 %t244
  %t249 = load i32, ptr %t248, !tbaa !33
  %t251 = load ptr, ptr %l2, !tbaa !29
  store ptr %t251, ptr %l133, !tbaa !29
  %t252 = load ptr, ptr %l4, !tbaa !29
  %t254 = getelementptr %"compiler/types:Table", ptr %t252, i32 0, i32 0
  %t255 = load ptr, ptr %t254, !tbaa !29
  store ptr %t255, ptr %l135, !tbaa !29
  %t257 = load ptr, ptr %l135, !tbaa !29
  %t258 = call ptr @__olang_scope_of(ptr %t257, ptr null)
  %t259 = call ptr @__olang_scope_hold(ptr %t258)
  %t260 = ptrtoint ptr %t259 to i64
  %t262 = inttoptr i64 %t260 to ptr
  %t263 = load ptr, ptr %l135, !tbaa !29
  %t265 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t262, ptr %s10, ptr %t263, i32 %t249)
  store { i64, ptr } %t265, ptr %l138
  br label %bb48
bb48:
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t268 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = add i64 %t267, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t266, i64 %t267)
  %t273 = getelementptr i8, ptr %t272, i64 %t267
  call void @olang_textcopy(ptr %t273, ptr %t269, i64 %t270)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t272, 1
  %t277 = load ptr, ptr %l133, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s10, ptr %t277, { i64, ptr } %t275)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb50:
  %t279 = load i64, ptr %l17, !tbaa !24
  %t282 = add i64 %t279, 1
  store i64 %t282, ptr %l17, !tbaa !24
  br label %bb44
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb52:
  %t284 = load i64, ptr %l7, !tbaa !24
  %t285 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  %t288 = icmp eq i64 %t284, %t285
  br i1 %t288, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s14
  store i64 0, ptr %l20, !tbaa !24
  %t290 = load ptr, ptr %l4, !tbaa !29
  store ptr %t290, ptr %l147, !tbaa !29
  %t291 = load i1, ptr %l9, !tbaa !21
  br i1 %t291, label %bb55, label %bb56
bb54:
  br label %bb78
bb55:
  %t293 = load ptr, ptr %l4, !tbaa !29
  %t294 = load i32, ptr %l8, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t293, i32 %t294)
  store i32 %t297, ptr %l152
  br label %bb57
bb56:
  %t298 = load ptr, ptr %l4, !tbaa !29
  %t299 = load i32, ptr %l8, !tbaa !23
  %t302 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t298, i32 %t299)
  store i32 %t302, ptr %l155
  br label %bb58
bb57:
  %t303 = load i32, ptr %l152, !tbaa !23
  store i32 %t303, ptr %l149, !tbaa !23
  br label %bb59
bb58:
  %t304 = load i32, ptr %l155, !tbaa !23
  store i32 %t304, ptr %l149, !tbaa !23
  br label %bb59
bb59:
  %t305 = load ptr, ptr %l147, !tbaa !29
  %t306 = load i32, ptr %l149, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s14, ptr %t305, i32 %t306)
  store { i64, ptr } %t307, ptr %l156
  br label %bb60
bb60:
  %t308 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t311 = load i64, ptr %l21, !tbaa !24
  %t312 = load i64, ptr %l20, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb61, label %bb62
bb61:
  %t317 = load i64, ptr %l22, !tbaa !24
  %t319 = icmp sgt i64 %t317, 0
  br i1 %t319, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb66
bb63:
  %t321 = load i64, ptr %l21, !tbaa !24
  %t322 = load i64, ptr %l20, !tbaa !24
  %t325 = sub i64 %t321, %t322
  %t326 = load i64, ptr %l22, !tbaa !24
  %t329 = add i64 %t325, %t326
  %t331 = sub i64 %t329, 1
  %t332 = load i64, ptr %l22, !tbaa !24
  %t335 = sdiv i64 %t331, %t332
  store i64 %t335, ptr %l164, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb65
bb65:
  %t337 = load i64, ptr %l164, !tbaa !24
  store i64 %t337, ptr %l161, !tbaa !24
  br label %bb66
bb66:
  %t338 = load i64, ptr %l161, !tbaa !24
  store i64 %t338, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb67
bb67:
  %t339 = load i64, ptr %l24, !tbaa !24
  %t340 = load i64, ptr %l23, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb68, label %bb69
bb68:
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t347 = load i64, ptr %l20, !tbaa !24
  %t348 = load i64, ptr %l24, !tbaa !24
  %t349 = load i64, ptr %l22, !tbaa !24
  %t352 = mul i64 %t348, %t349
  %t355 = add i64 %t347, %t352
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i32, ptr %l1, !tbaa !23
  %t363 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t357, i32 %t358, i64 %t355)
  store i32 %t363, ptr %l185
  br label %bb71
bb71:
  %t364 = load i32, ptr %l185, !tbaa !23
  store i32 %t364, ptr %l26, !tbaa !23
  %t365 = load i32, ptr %l26, !tbaa !23
  %t367 = icmp ne i32 %t365, 0
  br i1 %t367, label %bb72, label %bb73
bb72:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i32, ptr %l26, !tbaa !23
  %t371 = load ptr, ptr %l2, !tbaa !29
  %t372 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %v1, ptr %v2, ptr %t369, i32 %t370, ptr %t371, ptr %t372)
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t377 = load i64, ptr %l24, !tbaa !24
  %t380 = add i64 %t377, 1
  store i64 %t380, ptr %l24, !tbaa !24
  br label %bb67
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  %t382 = load i64, ptr %l7, !tbaa !24
  %t383 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t386 = icmp eq i64 %t382, %t383
  br i1 %t386, label %bb79, label %bb80
bb79:
  %t388 = load ptr, ptr %l4, !tbaa !29
  %t389 = load i32, ptr %l8, !tbaa !23
  %t392 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t388, i32 %t389)
  store i32 %t392, ptr %l201
  br label %bb81
bb80:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb82
bb81:
  %t393 = load i32, ptr %l201, !range !{i32 0, i32 33}
  %t395 = trunc i64 20 to i32
  %t396 = icmp eq i32 %t393, %t395
  store i1 %t396, ptr %l198, !tbaa !21
  br label %bb82
bb82:
  %t398 = load i1, ptr %l198, !tbaa !21
  br i1 %t398, label %bb83, label %bb84
bb83:
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l204, !tbaa !29
  %t400 = load ptr, ptr %l4, !tbaa !29
  %t401 = load i32, ptr %l8, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t400, i32 %t401)
  store i32 %t404, ptr %l207
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t406 = load ptr, ptr %l3, !tbaa !29
  %t407 = load ptr, ptr %l204, !tbaa !29
  %t408 = load i32, ptr %l207, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %v1, ptr %v2, ptr %t407, i32 %t408, ptr %t405, ptr %t406)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t411 = load i64, ptr %l7, !tbaa !24
  %t412 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t415 = icmp eq i64 %t411, %t412
  br i1 %t415, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb90
bb89:
  %t417 = load i64, ptr %l7, !tbaa !24
  %t418 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t421 = icmp eq i64 %t417, %t418
  store i1 %t421, ptr %l213, !tbaa !21
  br label %bb90
bb90:
  %t423 = load i1, ptr %l213, !tbaa !21
  br i1 %t423, label %bb91, label %bb92
bb91:
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l217, !tbaa !29
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i32, ptr %l1, !tbaa !23
  %t429 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t425, i32 %t426)
  store i32 %t429, ptr %l220
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t430 = load ptr, ptr %l2, !tbaa !29
  %t431 = load ptr, ptr %l3, !tbaa !29
  %t432 = load ptr, ptr %l217, !tbaa !29
  %t433 = load i32, ptr %l220, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elayoutOf(ptr %v0, ptr %v1, ptr %v2, ptr %t432, i32 %t433, ptr %t430, ptr %t431)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t436 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t436, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elenOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i64
  %l28 = alloca ptr
  %l32 = alloca %"compiler/eval:Ptr"
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a3)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l5, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l4, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i32, ptr %l19, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l20
  br label %bb6
bb6:
  %t31 = load i32, ptr %l20, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l23
  br label %bb8
bb8:
  %t37 = load i32, ptr %l23, !tbaa !23
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t53 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t47, i64 %a1, { i64, [4 x i64] } %a2, i64 1)
  store %"compiler/eval:Ptr" %t53, ptr %l32
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/eval:Ptr", ptr %l32
  %t56 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t54, %"compiler/eval:Ptr" %t55, i64 8)
  store i64 %t56, ptr %l33
  br label %bb14
bb14:
  %t57 = load i64, ptr %l33, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2emoveOut(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l22 = alloca %"compiler/eval:scope"
  %l32 = alloca %"compiler/eval:scope"
  %l42 = alloca %"compiler/eval:scope"
  %l46 = alloca i1
  %l49 = alloca i1
  %l64 = alloca %"compiler/eval:scope"
  %l68 = alloca i64
  %l73 = alloca ptr
  %t22 = alloca %"compiler/eval:scope", align 8
  %t43 = alloca %"compiler/eval:scope", align 8
  %t63 = alloca %"compiler/eval:scope", align 8
  %t106 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp ne i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i1, ptr %l15, !tbaa !21
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 53
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t21 = and i64 %t17, %t18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t22, ptr %v0, ptr %t16, i64 %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t22, i64 152, i1 false)
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t25 = getelementptr %"compiler/eval:scope", ptr %l22, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t30 = icmp eq i64 %t26, %t27
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l16, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 53
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t42 = and i64 %t38, %t39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t43, ptr %v0, ptr %t37, i64 %t42)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t43, i64 152, i1 false)
  br label %bb13
bb13:
  %t46 = getelementptr %"compiler/eval:scope", ptr %l32, i32 0, i32 5
  %t47 = load i64, ptr %t46, !tbaa !24
  store i64 %t47, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l2, !tbaa !24
  %t53 = icmp eq i64 %t49, %t50
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t55, i32 0, i32 53
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t62 = and i64 %t58, %t59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t63, ptr %v0, ptr %t57, i64 %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l42, ptr %t63, i64 152, i1 false)
  br label %bb16
bb15:
  br label %bb31
bb16:
  %t66 = getelementptr %"compiler/eval:scope", ptr %l42, i32 0, i32 5
  %t67 = load i64, ptr %t66, !tbaa !24
  store i64 %t67, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb20
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l49
  br label %bb19
bb19:
  %t78 = load i1, ptr %l49, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edisown(ptr %v0, ptr %t82, i64 %t83)
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %t86, i64 %t87, i64 %t88)
  br label %bb25
bb25:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t93 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t96 = and i64 %t92, %t93
  store i64 %t96, ptr %l6, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/eval:Machine", ptr %t98, i32 0, i32 53
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t105 = and i64 %t101, %t102
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t106, ptr %v0, ptr %t100, i64 %t105)
  call void @llvm.memmove.p0.p0.i64(ptr %l64, ptr %t106, i64 152, i1 false)
  br label %bb26
bb26:
  %t109 = getelementptr %"compiler/eval:scope", ptr %l64, i32 0, i32 2
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t114 = icmp ne i64 %t110, %t111
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t116 = load i64, ptr %l5, !tbaa !24
  store i64 %t116, ptr %l68, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb29
bb29:
  %t118 = load i64, ptr %l68, !tbaa !24
  store i64 %t118, ptr %l7, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/eval:Machine", ptr %t119, i32 0, i32 53
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t121, i64 %t122)
  store ptr %t125, ptr %l73
  br label %bb30
bb30:
  %t126 = load ptr, ptr %l73, !tbaa !29
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = getelementptr %"compiler/eval:scope", ptr %t126, i32 0, i32 16
  store i64 %t128, ptr %t131, !tbaa !24
  br label %ret
bb31:
  %t132 = load i64, ptr %l4, !tbaa !24
  store i64 %t132, ptr %l3, !tbaa !24
  br label %bb32
bb32:
  br label %bb1
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enamedShape(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i64
  %rv = alloca i64
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l6, !tbaa !29
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load i32, ptr %l10, !range !{i32 0, i32 6}
  store i32 %t15, ptr %l3
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t18 = trunc i64 0 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  store i64 %t21, ptr %l11, !tbaa !24
  br label %bb24
bb6:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb14
bb13:
  %t40 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  store i64 %t40, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l11, !tbaa !24
  br label %bb24
bb15:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t45 = trunc i64 2 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t48 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  store i64 %t48, ptr %l11, !tbaa !24
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t50 = load i64, ptr @G_2ecompiler_2feval_2evNone, !tbaa !24
  store i64 %t50, ptr %l11, !tbaa !24
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3ad4fb4c50638c0b_118ff119db9b3957)
  unreachable
bb24:
  %t52 = load i64, ptr %l11, !tbaa !24
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t1, i32 %t2, i1 false)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t12, ptr %l13
  br label %bb5
bb5:
  %t13 = load i64, ptr %l13, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t18 = icmp eq i64 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t28, ptr %l21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l21, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb10:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  %t34 = icmp ne i64 %t30, %t31
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l27, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l30
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = load i32, ptr %l30, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l31
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t49, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l38, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i32, ptr %t66, i64 %t63
  %t68 = load i32, ptr %t67, !tbaa !33
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %t70, i32 %t68)
  store i1 %t74, ptr %l43
  br label %bb20
bb20:
  %t75 = load i1, ptr %l43, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb16
bb25:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflowsWide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, i64 }
  %l12 = alloca { i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, i64 }
  %l17 = alloca i64
  %l18 = alloca { i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, i64 }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, i64 }
  %l31 = alloca { i64, i64 }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, i64, i64, i64 }
  %l36 = alloca i64
  %l37 = alloca { i64, i64 }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, i64 }
  %l41 = alloca { i64, i64 }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, i64 }
  %l48 = alloca { i64, [4 x i64] }
  %l52 = alloca i32
  %l55 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i1
  %l68 = alloca i64
  %l71 = alloca ptr
  %l75 = alloca i64
  %l77 = alloca double
  %l80 = alloca i1
  %l85 = alloca { i64, i64 }
  %l88 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i1
  %l97 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i1
  %l106 = alloca i1
  %l111 = alloca { i64, i64 }
  %l120 = alloca i1
  %l124 = alloca { i64, i64 }
  %l130 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i64
  %l139 = alloca { i64, [4 x i64] }
  %l140 = alloca { i64, i64 }
  %l146 = alloca { i64, i64 }
  %l150 = alloca i1
  %l154 = alloca i1
  %l158 = alloca i1
  %l161 = alloca i1
  %l167 = alloca i1
  %l176 = alloca i1
  %l181 = alloca { i64, i64 }
  %l187 = alloca i1
  %l192 = alloca { i64, i64 }
  %l197 = alloca i1
  %l200 = alloca i1
  %l203 = alloca i1
  %l211 = alloca { i64, i64 }
  %l218 = alloca { i64, i64, i64, i64 }
  %l224 = alloca i1
  %l231 = alloca { i64, i64 }
  %l237 = alloca { i64, i64 }
  %l244 = alloca i64
  %l250 = alloca { i64, i64 }
  %l259 = alloca { i64, i64 }
  %l268 = alloca i1
  %l278 = alloca i64
  %l284 = alloca i64
  %l293 = alloca i1
  %l304 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l4
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l48
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l48
  store { i64, [4 x i64] } %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l5
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l52
  br label %bb2
bb2:
  %t16 = load i32, ptr %l52, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l55
  br label %bb3
bb3:
  %t22 = load i64, ptr %l55, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l57, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l61
  br label %bb4
bb4:
  %t35 = load ptr, ptr %l57, !tbaa !29
  %t36 = load i32, ptr %l61, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t37, ptr %l62
  br label %bb5
bb5:
  %t38 = load i1, ptr %l62, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l8, !tbaa !21
  %t41 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l6, !tbaa !23
  %t50 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l68
  br label %bb8
bb7:
  br label %bb23
bb8:
  %t51 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t52 = load i64, ptr %l68, !tbaa !24
  %t54 = icmp eq i64 %t52, %t51
  br i1 %t54, label %bb9, label %bb10
bb9:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l71, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load { i64, [4 x i64] }, ptr %l5
  %t63 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t57, i64 %t58, { i64, [4 x i64] } %t59)
  store i64 %t63, ptr %l75
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load ptr, ptr %l71, !tbaa !29
  %t66 = load i64, ptr %l75, !tbaa !24
  %t68 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t65, i64 %t66, i32 %t64)
  store double %t68, ptr %l77
  br label %bb12
bb12:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i1, ptr %l8, !tbaa !21
  %t71 = load double, ptr %l77, !tbaa !26
  %t74 = call i1 @compiler_2feval_2efloatFits(double %t71, i64 %t69, i1 %t70)
  store i1 %t74, ptr %l80
  br label %bb13
bb13:
  %t75 = load i1, ptr %l80, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %rv
  br label %ret
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load { i64, [4 x i64] }, ptr %l5
  %t84 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t78, i64 %t79, { i64, [4 x i64] } %t80)
  store { i64, i64 } %t84, ptr %l85
  br label %bb15
bb15:
  %t85 = load { i64, i64 }, ptr %l85
  store { i64, i64 } %t85, ptr %l9
  %t86 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !24
  %t89 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t87, ptr %l88, !tbaa !24
  store i64 %t90, ptr %l89, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l6, !tbaa !23
  %t98 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l92
  br label %bb16
bb16:
  %t99 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t100 = load i64, ptr %l92, !tbaa !24
  %t102 = icmp ne i64 %t100, %t99
  br i1 %t102, label %bb17, label %bb18
bb17:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/eval:Machine", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l97, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l101
  br label %bb19
bb18:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb21
bb19:
  %t116 = load ptr, ptr %l97, !tbaa !29
  %t117 = load i32, ptr %l101, !tbaa !23
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t118, ptr %l102
  br label %bb20
bb20:
  %t119 = load i1, ptr %l102, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l95, !tbaa !21
  br label %bb21
bb21:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load i1, ptr %l8, !tbaa !21
  %t124 = load i64, ptr %l88, !tbaa !24
  %t125 = load i64, ptr %l89, !tbaa !24
  %t126 = load i1, ptr %l95, !tbaa !21
  %t129 = call i1 @compiler_2feval_2efits128(i64 %t124, i64 %t125, i1 %t126, i64 %t122, i1 %t123)
  store i1 %t129, ptr %l106
  br label %bb22
bb22:
  %t130 = load i1, ptr %l106, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %rv
  br label %ret
bb23:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t135 = load { i64, [4 x i64] }, ptr %l5
  %t139 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t133, i64 %t134, { i64, [4 x i64] } %t135)
  store { i64, i64 } %t139, ptr %l111
  br label %bb24
bb24:
  %t140 = load { i64, i64 }, ptr %l111
  store { i64, i64 } %t140, ptr %l12
  %t141 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t142 = load i64, ptr %t141, !tbaa !24
  store i64 %t142, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l14, !tbaa !24
  %t147 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t149 = trunc i64 0 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb25, label %bb26
bb25:
  %t152 = load i1, ptr %l8, !tbaa !21
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb27, label %bb28
bb26:
  br label %bb37
bb27:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb31
bb30:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t162 = icmp ne i64 %t160, 0
  store i1 %t162, ptr %l120, !tbaa !21
  br label %bb31
bb31:
  %t164 = load i1, ptr %l120, !tbaa !21
  store i1 %t164, ptr %rv
  br label %ret
bb32:
  %t165 = load i64, ptr %l7, !tbaa !24
  %t167 = call { i64, i64 } @compiler_2feval_2ewideMin(i64 %t165)
  store { i64, i64 } %t167, ptr %l124
  br label %bb33
bb33:
  %t168 = load { i64, i64 }, ptr %l124
  store { i64, i64 } %t168, ptr %l15
  %t169 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 0
  %t170 = load i64, ptr %t169, !tbaa !24
  %t172 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l13, !tbaa !24
  %t179 = icmp eq i64 %t175, %t170
  br i1 %t179, label %bb34, label %bb35
bb34:
  %t181 = load i64, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = icmp eq i64 %t181, %t182
  store i1 %t185, ptr %l130, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb36
bb36:
  %t187 = load i1, ptr %l130, !tbaa !21
  store i1 %t187, ptr %rv
  br label %ret
bb37:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l134, !tbaa !29
  %t189 = load i64, ptr %l1, !tbaa !24
  store i64 %t189, ptr %l135, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i64, ptr %l1, !tbaa !24
  %t192 = load %"compiler/mir:Range", ptr %l4
  %t196 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t190, i64 %t191, %"compiler/mir:Range" %t192, i64 1)
  store { i64, [4 x i64] } %t196, ptr %l139
  br label %bb38
bb38:
  %t197 = load ptr, ptr %l134, !tbaa !29
  %t198 = load i64, ptr %l135, !tbaa !24
  %t199 = load { i64, [4 x i64] }, ptr %l139
  %t200 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t197, i64 %t198, { i64, [4 x i64] } %t199)
  store { i64, i64 } %t200, ptr %l140
  br label %bb39
bb39:
  %t201 = load { i64, i64 }, ptr %l140
  store { i64, i64 } %t201, ptr %l18
  %t202 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 0
  %t203 = load i64, ptr %t202, !tbaa !24
  store i64 %t203, ptr %l19, !tbaa !24
  %t205 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 1
  %t206 = load i64, ptr %t205, !tbaa !24
  store i64 %t206, ptr %l20, !tbaa !24
  %t208 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t210 = trunc i64 6 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb40, label %bb41
bb40:
  %t213 = load i64, ptr %l7, !tbaa !24
  %t215 = call { i64, i64 } @compiler_2feval_2ewideMin(i64 %t213)
  store { i64, i64 } %t215, ptr %l146
  br label %bb42
bb41:
  br label %bb55
bb42:
  %t216 = load { i64, i64 }, ptr %l146
  store { i64, i64 } %t216, ptr %l21
  %t217 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 0
  %t218 = load i64, ptr %t217, !tbaa !24
  store i64 %t218, ptr %l22, !tbaa !24
  %t220 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 1
  %t221 = load i64, ptr %t220, !tbaa !24
  store i64 %t221, ptr %l23, !tbaa !24
  %t223 = load i1, ptr %l8, !tbaa !21
  br i1 %t223, label %bb43, label %bb44
bb43:
  %t225 = load i64, ptr %l13, !tbaa !24
  %t226 = load i64, ptr %l22, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  store i1 %t229, ptr %l150, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb45
bb45:
  %t231 = load i1, ptr %l150, !tbaa !21
  br i1 %t231, label %bb46, label %bb47
bb46:
  %t232 = load i64, ptr %l14, !tbaa !24
  %t233 = load i64, ptr %l23, !tbaa !24
  %t236 = icmp eq i64 %t232, %t233
  store i1 %t236, ptr %l154, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb48
bb48:
  %t238 = load i1, ptr %l154, !tbaa !21
  br i1 %t238, label %bb49, label %bb50
bb49:
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = icmp eq i64 %t239, -1
  store i1 %t241, ptr %l158, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb51
bb51:
  %t243 = load i1, ptr %l158, !tbaa !21
  br i1 %t243, label %bb52, label %bb53
bb52:
  %t244 = load i64, ptr %l20, !tbaa !24
  %t246 = icmp eq i64 %t244, -1
  store i1 %t246, ptr %l161, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb54
bb54:
  %t248 = load i1, ptr %l161, !tbaa !21
  store i1 %t248, ptr %rv
  br label %ret
bb55:
  %t249 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t251 = trunc i64 5 to i32
  %t252 = icmp eq i32 %t249, %t251
  br i1 %t252, label %bb56, label %bb57
bb56:
  %t254 = load i1, ptr %l8, !tbaa !21
  br i1 %t254, label %bb58, label %bb59
bb57:
  br label %bb101
bb58:
  %t256 = load i64, ptr %l14, !tbaa !24
  %t258 = icmp slt i64 %t256, 0
  %t259 = load i64, ptr %l20, !tbaa !24
  %t261 = icmp slt i64 %t259, 0
  %t264 = icmp ne i1 %t258, %t261
  store i1 %t264, ptr %l167, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb60
bb60:
  %t266 = load i1, ptr %l167, !tbaa !21
  store i1 %t266, ptr %l24, !tbaa !21
  %t267 = load i64, ptr %l13, !tbaa !24
  store i64 %t267, ptr %l25, !tbaa !24
  %t269 = load i64, ptr %l14, !tbaa !24
  store i64 %t269, ptr %l26, !tbaa !24
  %t271 = load i1, ptr %l8, !tbaa !21
  br i1 %t271, label %bb61, label %bb62
bb61:
  %t273 = load i64, ptr %l14, !tbaa !24
  %t275 = icmp slt i64 %t273, 0
  store i1 %t275, ptr %l176, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb63
bb63:
  %t277 = load i1, ptr %l176, !tbaa !21
  br i1 %t277, label %bb64, label %bb65
bb64:
  %t278 = load i64, ptr %l13, !tbaa !24
  %t279 = load i64, ptr %l14, !tbaa !24
  %t282 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t278, i64 %t279)
  store { i64, i64 } %t282, ptr %l181
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t283 = load { i64, i64 }, ptr %l181
  store { i64, i64 } %t283, ptr %l27
  %t284 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 0
  %t285 = load i64, ptr %t284, !tbaa !24
  store i64 %t285, ptr %l25, !tbaa !24
  %t287 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 1
  %t288 = load i64, ptr %t287, !tbaa !24
  store i64 %t288, ptr %l26, !tbaa !24
  br label %bb67
bb67:
  %t290 = load i64, ptr %l19, !tbaa !24
  store i64 %t290, ptr %l28, !tbaa !24
  %t292 = load i64, ptr %l20, !tbaa !24
  store i64 %t292, ptr %l29, !tbaa !24
  %t294 = load i1, ptr %l8, !tbaa !21
  br i1 %t294, label %bb68, label %bb69
bb68:
  %t296 = load i64, ptr %l20, !tbaa !24
  %t298 = icmp slt i64 %t296, 0
  store i1 %t298, ptr %l187, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb70
bb70:
  %t300 = load i1, ptr %l187, !tbaa !21
  br i1 %t300, label %bb71, label %bb72
bb71:
  %t301 = load i64, ptr %l19, !tbaa !24
  %t302 = load i64, ptr %l20, !tbaa !24
  %t305 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t301, i64 %t302)
  store { i64, i64 } %t305, ptr %l192
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t306 = load { i64, i64 }, ptr %l192
  store { i64, i64 } %t306, ptr %l30
  %t307 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 0
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l28, !tbaa !24
  %t310 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 1
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l29, !tbaa !24
  br label %bb74
bb74:
  %t313 = load i64, ptr %l25, !tbaa !24
  %t315 = icmp eq i64 %t313, 0
  br i1 %t315, label %bb75, label %bb76
bb75:
  %t317 = load i64, ptr %l26, !tbaa !24
  %t319 = icmp eq i64 %t317, 0
  store i1 %t319, ptr %l197, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb77
bb77:
  %t321 = load i1, ptr %l197, !tbaa !21
  br i1 %t321, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb83
bb79:
  %t322 = load i64, ptr %l28, !tbaa !24
  %t324 = icmp eq i64 %t322, 0
  br i1 %t324, label %bb80, label %bb81
bb80:
  %t326 = load i64, ptr %l29, !tbaa !24
  %t328 = icmp eq i64 %t326, 0
  store i1 %t328, ptr %l203, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb82
bb82:
  %t330 = load i1, ptr %l203, !tbaa !21
  store i1 %t330, ptr %l200, !tbaa !21
  br label %bb83
bb83:
  %t331 = load i1, ptr %l200, !tbaa !21
  br i1 %t331, label %bb84, label %bb85
bb84:
  store i1 false, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t333 = load i64, ptr %l25, !tbaa !24
  %t334 = load i64, ptr %l26, !tbaa !24
  %t335 = load i64, ptr %l28, !tbaa !24
  %t336 = load i64, ptr %l29, !tbaa !24
  %t341 = call { i64, i64 } @compiler_2feval_2emul128(i64 %t333, i64 %t334, i64 %t335, i64 %t336)
  store { i64, i64 } %t341, ptr %l211
  br label %bb87
bb87:
  %t342 = load { i64, i64 }, ptr %l211
  store { i64, i64 } %t342, ptr %l31
  %t343 = getelementptr { i64, i64 }, ptr %l31, i32 0, i32 0
  %t344 = load i64, ptr %t343, !tbaa !24
  store i64 %t344, ptr %l32, !tbaa !24
  %t346 = getelementptr { i64, i64 }, ptr %l31, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  store i64 %t347, ptr %l33, !tbaa !24
  %t349 = load i64, ptr %l32, !tbaa !24
  %t350 = load i64, ptr %l33, !tbaa !24
  %t351 = load i64, ptr %l25, !tbaa !24
  %t352 = load i64, ptr %l26, !tbaa !24
  %t357 = call { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %t349, i64 %t350, i64 %t351, i64 %t352)
  store { i64, i64, i64, i64 } %t357, ptr %l218
  br label %bb88
bb88:
  %t358 = load { i64, i64, i64, i64 }, ptr %l218
  store { i64, i64, i64, i64 } %t358, ptr %l34
  %t359 = getelementptr { i64, i64, i64, i64 }, ptr %l34, i32 0, i32 0
  %t360 = load i64, ptr %t359, !tbaa !24
  %t362 = getelementptr { i64, i64, i64, i64 }, ptr %l34, i32 0, i32 1
  %t363 = load i64, ptr %t362, !tbaa !24
  store i64 %t363, ptr %l36, !tbaa !24
  %t366 = load i64, ptr %l28, !tbaa !24
  %t369 = icmp ne i64 %t360, %t366
  br i1 %t369, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l224, !tbaa !21
  br label %bb91
bb90:
  %t371 = load i64, ptr %l36, !tbaa !24
  %t372 = load i64, ptr %l29, !tbaa !24
  %t375 = icmp ne i64 %t371, %t372
  store i1 %t375, ptr %l224, !tbaa !21
  br label %bb91
bb91:
  %t377 = load i1, ptr %l224, !tbaa !21
  br i1 %t377, label %bb92, label %bb93
bb92:
  store i1 true, ptr %rv
  br label %ret
bb93:
  br label %bb94
bb94:
  %t379 = load i64, ptr %l7, !tbaa !24
  %t380 = load i1, ptr %l8, !tbaa !21
  %t383 = call { i64, i64 } @compiler_2feval_2ewideMax(i64 %t379, i1 %t380)
  store { i64, i64 } %t383, ptr %l231
  br label %bb95
bb95:
  %t384 = load { i64, i64 }, ptr %l231
  store { i64, i64 } %t384, ptr %l37
  %t385 = getelementptr { i64, i64 }, ptr %l37, i32 0, i32 0
  %t386 = load i64, ptr %t385, !tbaa !24
  store i64 %t386, ptr %l38, !tbaa !24
  %t388 = getelementptr { i64, i64 }, ptr %l37, i32 0, i32 1
  %t389 = load i64, ptr %t388, !tbaa !24
  store i64 %t389, ptr %l39, !tbaa !24
  %t391 = load i1, ptr %l24, !tbaa !21
  br i1 %t391, label %bb96, label %bb97
bb96:
  %t393 = load i64, ptr %l38, !tbaa !24
  %t394 = load i64, ptr %l39, !tbaa !24
  %t397 = call { i64, i64 } @compiler_2feval_2eadd128(i64 %t393, i64 %t394, i64 1, i64 0)
  store { i64, i64 } %t397, ptr %l237
  br label %bb98
bb97:
  br label %bb99
bb98:
  %t398 = load { i64, i64 }, ptr %l237
  store { i64, i64 } %t398, ptr %l40
  %t399 = getelementptr { i64, i64 }, ptr %l40, i32 0, i32 0
  %t400 = load i64, ptr %t399, !tbaa !24
  store i64 %t400, ptr %l38, !tbaa !24
  %t402 = getelementptr { i64, i64 }, ptr %l40, i32 0, i32 1
  %t403 = load i64, ptr %t402, !tbaa !24
  store i64 %t403, ptr %l39, !tbaa !24
  br label %bb99
bb99:
  %t405 = load i64, ptr %l32, !tbaa !24
  %t406 = load i64, ptr %l33, !tbaa !24
  %t407 = load i64, ptr %l38, !tbaa !24
  %t408 = load i64, ptr %l39, !tbaa !24
  %t413 = call i64 @compiler_2feval_2ecmp128(i64 %t405, i64 %t406, i64 %t407, i64 %t408, i1 false)
  store i64 %t413, ptr %l244
  br label %bb100
bb100:
  %t414 = load i64, ptr %l244, !tbaa !24
  %t415 = icmp sgt i64 %t414, 0
  store i1 %t415, ptr %rv
  br label %ret
bb101:
  %t417 = load i64, ptr %l13, !tbaa !24
  %t418 = load i64, ptr %l14, !tbaa !24
  %t419 = load i64, ptr %l19, !tbaa !24
  %t420 = load i64, ptr %l20, !tbaa !24
  %t425 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t417, i64 %t418, i64 %t419, i64 %t420)
  store { i64, i64 } %t425, ptr %l250
  br label %bb102
bb102:
  %t426 = load { i64, i64 }, ptr %l250
  store { i64, i64 } %t426, ptr %l41
  %t427 = getelementptr { i64, i64 }, ptr %l41, i32 0, i32 0
  %t428 = load i64, ptr %t427, !tbaa !24
  store i64 %t428, ptr %l42, !tbaa !24
  %t430 = getelementptr { i64, i64 }, ptr %l41, i32 0, i32 1
  %t431 = load i64, ptr %t430, !tbaa !24
  store i64 %t431, ptr %l43, !tbaa !24
  %t433 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t435 = trunc i64 3 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb103, label %bb104
bb103:
  %t438 = load i64, ptr %l13, !tbaa !24
  %t439 = load i64, ptr %l14, !tbaa !24
  %t440 = load i64, ptr %l19, !tbaa !24
  %t441 = load i64, ptr %l20, !tbaa !24
  %t446 = call { i64, i64 } @compiler_2feval_2eadd128(i64 %t438, i64 %t439, i64 %t440, i64 %t441)
  store { i64, i64 } %t446, ptr %l259
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t447 = load { i64, i64 }, ptr %l259
  store { i64, i64 } %t447, ptr %l44
  %t448 = getelementptr { i64, i64 }, ptr %l44, i32 0, i32 0
  %t449 = load i64, ptr %t448, !tbaa !24
  store i64 %t449, ptr %l42, !tbaa !24
  %t451 = getelementptr { i64, i64 }, ptr %l44, i32 0, i32 1
  %t452 = load i64, ptr %t451, !tbaa !24
  store i64 %t452, ptr %l43, !tbaa !24
  br label %bb106
bb106:
  %t454 = load i64, ptr %l7, !tbaa !24
  %t456 = icmp slt i64 %t454, 128
  br i1 %t456, label %bb107, label %bb108
bb107:
  %t458 = load i64, ptr %l42, !tbaa !24
  %t459 = load i64, ptr %l43, !tbaa !24
  %t460 = load i64, ptr %l7, !tbaa !24
  %t461 = load i1, ptr %l8, !tbaa !21
  %t466 = call i1 @compiler_2feval_2efits128(i64 %t458, i64 %t459, i1 true, i64 %t460, i1 %t461)
  store i1 %t466, ptr %l268
  br label %bb109
bb108:
  br label %bb110
bb109:
  %t467 = load i1, ptr %l268, !tbaa !21
  %t468 = xor i1 %t467, true
  store i1 %t468, ptr %rv
  br label %ret
bb110:
  %t470 = load i1, ptr %l8, !tbaa !21
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb111, label %bb112
bb111:
  %t474 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t476 = trunc i64 3 to i32
  %t477 = icmp eq i32 %t474, %t476
  br i1 %t477, label %bb113, label %bb114
bb112:
  br label %bb118
bb113:
  %t479 = load i64, ptr %l42, !tbaa !24
  %t480 = load i64, ptr %l43, !tbaa !24
  %t481 = load i64, ptr %l13, !tbaa !24
  %t482 = load i64, ptr %l14, !tbaa !24
  %t487 = call i64 @compiler_2feval_2ecmp128(i64 %t479, i64 %t480, i64 %t481, i64 %t482, i1 false)
  store i64 %t487, ptr %l278
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t488 = load i64, ptr %l278, !tbaa !24
  %t489 = icmp slt i64 %t488, 0
  store i1 %t489, ptr %rv
  br label %ret
bb116:
  %t491 = load i64, ptr %l13, !tbaa !24
  %t492 = load i64, ptr %l14, !tbaa !24
  %t493 = load i64, ptr %l19, !tbaa !24
  %t494 = load i64, ptr %l20, !tbaa !24
  %t499 = call i64 @compiler_2feval_2ecmp128(i64 %t491, i64 %t492, i64 %t493, i64 %t494, i1 false)
  store i64 %t499, ptr %l284
  br label %bb117
bb117:
  %t500 = load i64, ptr %l284, !tbaa !24
  %t501 = icmp slt i64 %t500, 0
  store i1 %t501, ptr %rv
  br label %ret
bb118:
  %t503 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t505 = trunc i64 3 to i32
  %t506 = icmp eq i32 %t503, %t505
  br i1 %t506, label %bb119, label %bb120
bb119:
  %t508 = load i64, ptr %l14, !tbaa !24
  %t510 = icmp slt i64 %t508, 0
  %t511 = load i64, ptr %l20, !tbaa !24
  %t513 = icmp slt i64 %t511, 0
  %t516 = icmp eq i1 %t510, %t513
  br i1 %t516, label %bb121, label %bb122
bb120:
  br label %bb124
bb121:
  %t518 = load i64, ptr %l43, !tbaa !24
  %t520 = icmp slt i64 %t518, 0
  %t521 = load i64, ptr %l14, !tbaa !24
  %t523 = icmp slt i64 %t521, 0
  %t526 = icmp ne i1 %t520, %t523
  store i1 %t526, ptr %l293, !tbaa !21
  br label %bb123
bb122:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb123
bb123:
  %t528 = load i1, ptr %l293, !tbaa !21
  store i1 %t528, ptr %rv
  br label %ret
bb124:
  %t529 = load i64, ptr %l14, !tbaa !24
  %t531 = icmp slt i64 %t529, 0
  %t532 = load i64, ptr %l20, !tbaa !24
  %t534 = icmp slt i64 %t532, 0
  %t537 = icmp ne i1 %t531, %t534
  br i1 %t537, label %bb125, label %bb126
bb125:
  %t539 = load i64, ptr %l43, !tbaa !24
  %t541 = icmp slt i64 %t539, 0
  %t542 = load i64, ptr %l14, !tbaa !24
  %t544 = icmp slt i64 %t542, 0
  %t547 = icmp ne i1 %t541, %t544
  store i1 %t547, ptr %l304, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb127
bb127:
  %t549 = load i1, ptr %l304, !tbaa !21
  store i1 %t549, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2epackInto(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i32 %a3, %"compiler/eval:Ptr" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i64
  %l4 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i32
  %l24 = alloca i32
  %l30 = alloca i32
  %l34 = alloca i64
  %l36 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca %"compiler/eval:Ptr"
  %l72 = alloca i64
  %l73 = alloca i32
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i64
  %l82 = alloca %"compiler/eval:Ptr"
  %l89 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca i32
  %l100 = alloca i1
  %l110 = alloca %"compiler/eval:Ptr"
  %l111 = alloca ptr
  %l112 = alloca %"compiler/eval:Ptr"
  %l113 = alloca { i64, ptr }
  %l116 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/eval:Ptr" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a3)
  store i32 %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load i32, ptr %l20, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l5, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l24
  br label %bb2
bb2:
  %t18 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l30
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t31 = load i32, ptr %l30, !tbaa !23
  store i32 %t31, ptr %l6, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l34
  br label %bb6
bb6:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l36, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l5, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l40
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l36, !tbaa !29
  %t54 = load i32, ptr %l40, !tbaa !23
  %t55 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t55, ptr %l41
  br label %bb8
bb8:
  %t56 = load i64, ptr %l41, !tbaa !24
  store i64 %t56, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb9, label %bb10
bb9:
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb11:
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l48, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb13
bb13:
  %t83 = load i64, ptr %l48, !tbaa !24
  store i64 %t83, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t84 = load i64, ptr %l45, !tbaa !24
  store i64 %t84, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load i64, ptr %l12, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l13, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l66, !tbaa !29
  %t104 = load %"compiler/eval:Ptr", ptr %l1
  store %"compiler/eval:Ptr" %t104, ptr %l67
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l72, !tbaa !24
  %t114 = load i32, ptr %l6, !tbaa !23
  store i32 %t114, ptr %l73, !tbaa !23
  %t115 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l74, !tbaa !24
  %t117 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  store i64 %t118, ptr %l75, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  store i64 %t119, ptr %l76, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t120, i32 %t121)
  store i64 %t124, ptr %l79
  br label %bb19
bb19:
  %t125 = load i64, ptr %l76, !tbaa !24
  %t126 = load i64, ptr %l79, !tbaa !24
  %t127 = mul i64 %t125, %t126
  %t128 = load i64, ptr %l75, !tbaa !24
  %t130 = add i64 %t128, %t127
  %t131 = load i64, ptr %l74, !tbaa !24
  %t133 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t131, i64 %t130)
  store %"compiler/eval:Ptr" %t133, ptr %l82
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l66, !tbaa !29
  %t135 = load %"compiler/eval:Ptr", ptr %l67
  %t136 = load i64, ptr %l72, !tbaa !24
  %t137 = load i32, ptr %l73, !tbaa !23
  %t138 = load %"compiler/eval:Ptr", ptr %l82
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epackInto(ptr %v0, ptr %t134, %"compiler/eval:Ptr" %t135, i64 %t136, i32 %t137, %"compiler/eval:Ptr" %t138)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb15
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/eval:Machine", ptr %t144, i32 0, i32 0
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i32, ptr %l5, !tbaa !23
  %t151 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %t147, i32 %t148)
  store i64 %t151, ptr %l89
  br label %bb25
bb25:
  %t152 = load i64, ptr %l89, !tbaa !24
  store i64 %t152, ptr %l14, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/eval:Machine", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load i32, ptr %l5, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawBits(ptr %v0, ptr %s0, ptr %t156, i32 %t157)
  store { i64, ptr } %t160, ptr %l93
  br label %bb26
bb26:
  %t161 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t161, ptr %l15, !tbaa !27
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 0
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t166 = load i32, ptr %l5, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawType(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l97
  br label %bb27
bb27:
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t171 = load i32, ptr %l97, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb30
bb29:
  %t175 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t179 = icmp eq i64 %t177, 0
  store i1 %t179, ptr %l100, !tbaa !21
  br label %bb30
bb30:
  %t181 = load i1, ptr %l100, !tbaa !21
  br i1 %t181, label %bb31, label %bb32
bb31:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/eval:Ptr", ptr %l1
  %t184 = load i64, ptr %l2, !tbaa !24
  %t185 = load %"compiler/eval:Ptr", ptr %l4
  %t186 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopyBits(ptr %v0, ptr %t182, %"compiler/eval:Ptr" %t183, i64 %t184, %"compiler/eval:Ptr" %t185, i64 0, i64 %t186)
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %t192, i64 3, i64 8)
  store %"compiler/eval:Ptr" %t194, ptr %l110
  br label %bb35
bb35:
  %t195 = load %"compiler/eval:Ptr", ptr %l110
  store %"compiler/eval:Ptr" %t195, ptr %l16
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l111, !tbaa !29
  %t197 = load %"compiler/eval:Ptr", ptr %l16
  store %"compiler/eval:Ptr" %t197, ptr %l112
  %t198 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t198, ptr %l113, !tbaa !27
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/eval:Ptr", ptr %l4
  %t203 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t199, %"compiler/eval:Ptr" %t200, i64 4)
  store i64 %t203, ptr %l116
  br label %bb36
bb36:
  %t204 = load i64, ptr %l116, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i64, ptr %t206, i64 %t204
  %t208 = load i64, ptr %t207, !tbaa !34
  %t209 = load ptr, ptr %l111, !tbaa !29
  %t210 = load %"compiler/eval:Ptr", ptr %l112
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t209, %"compiler/eval:Ptr" %t210, i64 8, i64 %t208)
  br label %bb37
bb37:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/eval:Ptr", ptr %l1
  %t214 = load i64, ptr %l2, !tbaa !24
  %t215 = load %"compiler/eval:Ptr", ptr %l16
  %t216 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopyBits(ptr %v0, ptr %t212, %"compiler/eval:Ptr" %t213, i64 %t214, %"compiler/eval:Ptr" %t215, i64 0, i64 %t216)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i32
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca { %"compiler/eval:Ptr", i32 }
  %l25 = alloca i64
  %l26 = alloca { %"compiler/eval:Ptr", i32 }
  %l27 = alloca i32
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l44 = alloca %"compiler/eval:Ptr"
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca %"compiler/eval:gkey"
  %l63 = alloca i64
  %l64 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i1
  %l82 = alloca %"compiler/eval:global"
  %l93 = alloca %"compiler/eval:global"
  %l95 = alloca %"compiler/eval:Ptr"
  %l103 = alloca i32
  %l106 = alloca i32
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca i64
  %l147 = alloca i64
  %l149 = alloca %"compiler/eval:Ptr"
  %l153 = alloca i32
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l169 = alloca %"compiler/eval:Ptr"
  %l172 = alloca i64
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca { %"compiler/eval:Ptr", i32 }
  %l190 = alloca { %"compiler/eval:Ptr", i32 }
  %l195 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i32
  %l202 = alloca i1
  %l206 = alloca %"compiler/eval:Ptr"
  %l217 = alloca i64
  %l225 = alloca %"compiler/eval:Ptr"
  %l229 = alloca i32
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i32 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Lvalue" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l30, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  %t18 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t18, ptr %l5
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t22 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 0
  %t23 = load { i64, [2 x i64] }, ptr %t22
  store { i64, [2 x i64] } %t23, ptr %l7
  %t25 = load { i64, [2 x i64] }, ptr %l7
  %t27 = extractvalue { i64, [2 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 1
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t30 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t31 = getelementptr { i32 }, ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i32, ptr %l8, !tbaa !23
  %t40 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t34, i64 %t35, i32 %t36)
  store %"compiler/eval:Ptr" %t40, ptr %l44
  br label %bb4
bb4:
  %t41 = load %"compiler/eval:Ptr", ptr %l44
  store %"compiler/eval:Ptr" %t41, ptr %l5
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 27
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l46, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/eval:cfn", ptr %t49, i64 %t46
  %t51 = getelementptr %"compiler/eval:cfn", ptr %t50, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l48, !tbaa !27
  %t53 = load i32, ptr %l8, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t57 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/mir:Local", ptr %t58, i64 %t55
  %t60 = getelementptr %"compiler/mir:Local", ptr %t59, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb33
bb5:
  %t63 = load { i64, [2 x i64] }, ptr %l7
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 2
  br i1 %t66, label %bb6, label %bb7
bb6:
  %t68 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t69 = getelementptr { i64, i32, i32 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t73 = getelementptr { i64, i32, i32 }, ptr %t72, i32 0, i32 1
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l10, !tbaa !23
  %t76 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t77 = getelementptr { i64, i32, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l11, !tbaa !23
  br label %bb8
bb7:
  br label %bb28
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 44
  store ptr %t82, ptr %l59, !tbaa !29
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i32, ptr %l10, !tbaa !23
  %t87 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s2, i64 %t83, i32 %t84)
  store %"compiler/eval:gkey" %t87, ptr %l62
  br label %bb9
bb9:
  %t88 = load ptr, ptr %l59, !tbaa !29
  %t89 = load %"compiler/eval:gkey", ptr %l62
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t88, %"compiler/eval:gkey" %t89)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l64
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb11, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l63
  br label %bb10
bb10:
  %t95 = load i64, ptr %l63, !tbaa !24
  store i64 %t95, ptr %l57, !tbaa !24
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t98 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t98, ptr %t96, { i64, ptr } %t97)
  br label %bb13
bb13:
  %t101 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t102 = load i32, ptr %l11, !tbaa !23
  %t104 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t101, 0
  %t106 = insertvalue { %"compiler/eval:Ptr", i32 } %t104, i32 %t102, 1
  call void @__olang_scope_close(ptr %s2)
  store { %"compiler/eval:Ptr", i32 } %t106, ptr %rv
  br label %ret
bb14:
  %t108 = load i64, ptr %l57, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/eval:Machine", ptr %t109, i32 0, i32 1
  %t112 = load i32, ptr %t111, !range !{i32 0, i32 2}
  %t114 = trunc i64 0 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb15, label %bb16
bb15:
  %t117 = load i64, ptr %l12, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/eval:Machine", ptr %t118, i32 0, i32 74
  %t121 = load i64, ptr %t120, !tbaa !24
  %t124 = icmp ne i64 %t117, %t121
  store i1 %t124, ptr %l73, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb17
bb17:
  %t126 = load i1, ptr %l73, !tbaa !21
  br i1 %t126, label %bb18, label %bb19
bb18:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 43
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t129, i64 %t130)
  store %"compiler/eval:global" %t133, ptr %l82
  br label %bb20
bb19:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb21
bb20:
  %t134 = getelementptr %"compiler/eval:global", ptr %l82, i32 0, i32 4
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = icmp ne i64 %t135, 2
  store i1 %t137, ptr %l78, !tbaa !21
  br label %bb21
bb21:
  %t139 = load i1, ptr %l78, !tbaa !21
  br i1 %t139, label %bb22, label %bb23
bb22:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoGlobal, !tbaa !27
  %t142 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t142, ptr %t140, { i64, ptr } %t141)
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t145 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t146 = load i32, ptr %l11, !tbaa !23
  %t148 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t145, 0
  %t150 = insertvalue { %"compiler/eval:Ptr", i32 } %t148, i32 %t146, 1
  call void @__olang_scope_close(ptr %s2)
  store { %"compiler/eval:Ptr", i32 } %t150, ptr %rv
  br label %ret
bb25:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 43
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t154, i64 %t155)
  store %"compiler/eval:global" %t158, ptr %l93
  br label %bb26
bb26:
  %t159 = getelementptr %"compiler/eval:global", ptr %l93, i32 0, i32 3
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t160, i64 0)
  store %"compiler/eval:Ptr" %t162, ptr %l95
  br label %bb27
bb27:
  %t163 = load %"compiler/eval:Ptr", ptr %l95
  store %"compiler/eval:Ptr" %t163, ptr %l5
  %t164 = load i32, ptr %l11, !tbaa !23
  store i32 %t164, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb28:
  %t166 = load { i64, [2 x i64] }, ptr %l7
  %t168 = extractvalue { i64, [2 x i64] } %t166, 0
  %t169 = icmp eq i64 %t168, 0
  br i1 %t169, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_de6102181a77a536_5fca55a0d6277082)
  unreachable
bb33:
  store i32 0, ptr %l13, !tbaa !23
  %t171 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t172 = getelementptr %"compiler/mir:Range", ptr %t171, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  store i32 %t173, ptr %l14, !tbaa !23
  store i32 1, ptr %l15, !tbaa !23
  %t175 = load i32, ptr %l14, !tbaa !23
  %t176 = load i32, ptr %l13, !tbaa !23
  %t179 = icmp sgt i32 %t175, %t176
  br i1 %t179, label %bb34, label %bb35
bb34:
  %t181 = load i32, ptr %l15, !tbaa !23
  %t183 = icmp sgt i32 %t181, 0
  br i1 %t183, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l103, !tbaa !23
  br label %bb39
bb36:
  %t185 = load i32, ptr %l14, !tbaa !23
  %t186 = load i32, ptr %l13, !tbaa !23
  %t189 = sub i32 %t185, %t186
  %t190 = load i32, ptr %l15, !tbaa !23
  %t193 = add i32 %t189, %t190
  %t195 = sub i32 %t193, 1
  %t196 = load i32, ptr %l15, !tbaa !23
  %t199 = sdiv i32 %t195, %t196
  store i32 %t199, ptr %l106, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l106, !tbaa !23
  br label %bb38
bb38:
  %t201 = load i32, ptr %l106, !tbaa !23
  store i32 %t201, ptr %l103, !tbaa !23
  br label %bb39
bb39:
  %t202 = load i32, ptr %l103, !tbaa !23
  store i32 %t202, ptr %l16, !tbaa !23
  store i32 0, ptr %l17, !tbaa !23
  br label %bb40
bb40:
  %t203 = load i32, ptr %l17, !tbaa !23
  %t204 = load i32, ptr %l16, !tbaa !23
  %t207 = icmp slt i32 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb41, label %bb42
bb41:
  br label %bb96
bb42:
  br label %bb43
bb43:
  %t211 = load i32, ptr %l13, !tbaa !23
  %t212 = load i32, ptr %l17, !tbaa !23
  %t213 = load i32, ptr %l15, !tbaa !23
  %t216 = mul i32 %t212, %t213
  %t219 = add i32 %t211, %t216
  store i32 %t219, ptr %l18, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/eval:Machine", ptr %t221, i32 0, i32 23
  %t224 = load i1, ptr %t223, !tbaa !21
  br i1 %t224, label %bb44, label %bb45
bb44:
  %t226 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t227 = load i32, ptr %l6, !tbaa !23
  %t229 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t226, 0
  %t231 = insertvalue { %"compiler/eval:Ptr", i32 } %t229, i32 %t227, 1
  store { %"compiler/eval:Ptr", i32 } %t231, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/eval:Machine", ptr %t233, i32 0, i32 27
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l130, !tbaa !27
  %t237 = load i64, ptr %l3, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr %"compiler/eval:cfn", ptr %t240, i64 %t237
  %t242 = getelementptr %"compiler/eval:cfn", ptr %t241, i32 0, i32 3
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  store { i64, ptr } %t243, ptr %l132, !tbaa !27
  %t244 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t245 = getelementptr %"compiler/mir:Range", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  %t249 = load i32, ptr %l18, !tbaa !23
  %t251 = sext i32 %t249 to i64
  %t254 = add i64 %t248, %t251
  %t256 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr { i64, [1 x i64] }, ptr %t257, i64 %t254
  %t259 = load { i64, [1 x i64] }, ptr %t258
  store { i64, [1 x i64] } %t259, ptr %l19
  %t261 = load { i64, [1 x i64] }, ptr %l19
  %t263 = extractvalue { i64, [1 x i64] } %t261, 0
  %t264 = icmp eq i64 %t263, 0
  br i1 %t264, label %bb47, label %bb48
bb47:
  %t266 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t267 = getelementptr { i64 }, ptr %t266, i32 0, i32 0
  %t268 = load i64, ptr %t267
  store i64 %t268, ptr %l20, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t271 = load i64, ptr %t270, !tbaa !24
  store i64 %t271, ptr %l142, !tbaa !24
  %t272 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t273 = load i64, ptr %t272, !tbaa !24
  store i64 %t273, ptr %l143, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l6, !tbaa !23
  %t276 = load i64, ptr %l20, !tbaa !24
  %t280 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t274, i32 %t275, i64 %t276)
  store i64 %t280, ptr %l147
  br label %bb50
bb50:
  %t281 = load i64, ptr %l143, !tbaa !24
  %t282 = load i64, ptr %l147, !tbaa !24
  %t283 = add i64 %t281, %t282
  %t284 = load i64, ptr %l142, !tbaa !24
  %t286 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s9, i64 %t284, i64 %t283)
  store %"compiler/eval:Ptr" %t286, ptr %l149
  br label %bb51
bb51:
  %t287 = load %"compiler/eval:Ptr", ptr %l149
  store %"compiler/eval:Ptr" %t287, ptr %l5
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i32, ptr %l6, !tbaa !23
  %t290 = load i64, ptr %l20, !tbaa !24
  %t294 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t288, i32 %t289, i64 %t290)
  store i32 %t294, ptr %l153
  br label %bb52
bb52:
  %t295 = load i32, ptr %l153, !tbaa !23
  store i32 %t295, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  br label %bb94
bb53:
  %t296 = load { i64, [1 x i64] }, ptr %l19
  %t298 = extractvalue { i64, [1 x i64] } %t296, 0
  %t299 = icmp eq i64 %t298, 1
  br i1 %t299, label %bb54, label %bb55
bb54:
  %t301 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t302 = getelementptr { i32 }, ptr %t301, i32 0, i32 0
  %t303 = load i32, ptr %t302
  store i32 %t303, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb62
bb56:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/eval:Machine", ptr %t305, i32 0, i32 27
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l158, !tbaa !27
  %t309 = load i64, ptr %l3, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr %"compiler/eval:cfn", ptr %t312, i64 %t309
  %t314 = getelementptr %"compiler/eval:cfn", ptr %t313, i32 0, i32 1
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l160, !tbaa !27
  %t316 = load i32, ptr %l21, !tbaa !23
  %t318 = sext i32 %t316 to i64
  %t320 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr %"compiler/mir:Local", ptr %t321, i64 %t318
  %t323 = getelementptr %"compiler/mir:Local", ptr %t322, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  store i32 %t324, ptr %l22, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l164, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l165, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i64, ptr %l1, !tbaa !24
  %t330 = load i32, ptr %l21, !tbaa !23
  %t334 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t328, i64 %t329, i32 %t330)
  store %"compiler/eval:Ptr" %t334, ptr %l169
  br label %bb57
bb57:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l22, !tbaa !23
  %t339 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t335, i32 %t336)
  store i64 %t339, ptr %l172
  br label %bb58
bb58:
  %t340 = load ptr, ptr %l165, !tbaa !29
  %t341 = load %"compiler/eval:Ptr", ptr %l169
  %t342 = load i64, ptr %l172, !tbaa !24
  %t343 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t340, %"compiler/eval:Ptr" %t341, i64 %t342)
  store i64 %t343, ptr %l173
  br label %bb59
bb59:
  %t344 = load i32, ptr %l22, !tbaa !23
  %t345 = load ptr, ptr %l164, !tbaa !29
  %t346 = load i64, ptr %l173, !tbaa !24
  %t348 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t345, i64 %t346, i32 %t344)
  store i64 %t348, ptr %l175
  br label %bb60
bb60:
  %t349 = load i64, ptr %l175, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/eval:Ptr", ptr %l5
  %t352 = load i32, ptr %l6, !tbaa !23
  %t358 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %t350, %"compiler/eval:Ptr" %t351, i32 %t352, i64 %t349)
  store { %"compiler/eval:Ptr", i32 } %t358, ptr %l180
  br label %bb61
bb61:
  %t359 = load { %"compiler/eval:Ptr", i32 }, ptr %l180
  store { %"compiler/eval:Ptr", i32 } %t359, ptr %l24
  %t360 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l24, i32 0, i32 0
  %t361 = load %"compiler/eval:Ptr", ptr %t360
  store %"compiler/eval:Ptr" %t361, ptr %l5
  %t363 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l24, i32 0, i32 1
  %t364 = load i32, ptr %t363, !tbaa !23
  store i32 %t364, ptr %l6, !tbaa !23
  br label %bb94
bb62:
  %t366 = load { i64, [1 x i64] }, ptr %l19
  %t368 = extractvalue { i64, [1 x i64] } %t366, 0
  %t369 = icmp eq i64 %t368, 2
  br i1 %t369, label %bb63, label %bb64
bb63:
  %t371 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t372 = getelementptr { i64 }, ptr %t371, i32 0, i32 0
  %t373 = load i64, ptr %t372
  store i64 %t373, ptr %l25, !tbaa !24
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load %"compiler/eval:Ptr", ptr %l5
  %t377 = load i32, ptr %l6, !tbaa !23
  %t378 = load i64, ptr %l25, !tbaa !24
  %t383 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %t375, %"compiler/eval:Ptr" %t376, i32 %t377, i64 %t378)
  store { %"compiler/eval:Ptr", i32 } %t383, ptr %l190
  br label %bb66
bb66:
  %t384 = load { %"compiler/eval:Ptr", i32 }, ptr %l190
  store { %"compiler/eval:Ptr", i32 } %t384, ptr %l26
  %t385 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l26, i32 0, i32 0
  %t386 = load %"compiler/eval:Ptr", ptr %t385
  store %"compiler/eval:Ptr" %t386, ptr %l5
  %t388 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l26, i32 0, i32 1
  %t389 = load i32, ptr %t388, !tbaa !23
  store i32 %t389, ptr %l6, !tbaa !23
  br label %bb94
bb67:
  %t391 = load { i64, [1 x i64] }, ptr %l19
  %t393 = extractvalue { i64, [1 x i64] } %t391, 0
  %t394 = icmp eq i64 %t393, 3
  br i1 %t394, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb82
bb70:
  %t396 = load ptr, ptr %l4, !tbaa !29
  store ptr %t396, ptr %l195, !tbaa !29
  %t397 = load ptr, ptr %l4, !tbaa !29
  %t398 = load i32, ptr %l6, !tbaa !23
  %t401 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t397, i32 %t398)
  store i32 %t401, ptr %l198
  br label %bb71
bb71:
  %t402 = load ptr, ptr %l195, !tbaa !29
  %t403 = load i32, ptr %l198, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t404, ptr %l199
  br label %bb72
bb72:
  %t405 = load i32, ptr %l199, !tbaa !23
  store i32 %t405, ptr %l27, !tbaa !23
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l27, !tbaa !23
  %t410 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %t406, i32 %t407)
  store i1 %t410, ptr %l202
  br label %bb73
bb73:
  %t411 = load i1, ptr %l202, !tbaa !21
  %t412 = xor i1 %t411, true
  br i1 %t412, label %bb74, label %bb75
bb74:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/eval:Ptr", ptr %l5
  %t418 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t414, %"compiler/eval:Ptr" %t415)
  store %"compiler/eval:Ptr" %t418, ptr %l206
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t419 = load %"compiler/eval:Ptr", ptr %l206
  store %"compiler/eval:Ptr" %t419, ptr %l5
  br label %bb77
bb77:
  %t420 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t421 = load i64, ptr %t420, !tbaa !24
  %t423 = icmp eq i64 %t421, 0
  br i1 %t423, label %bb78, label %bb79
bb78:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNull, !tbaa !27
  %t427 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t427, ptr %t425, { i64, ptr } %t426)
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t430 = load i32, ptr %l27, !tbaa !23
  store i32 %t430, ptr %l6, !tbaa !23
  br label %bb94
bb82:
  %t432 = load { i64, [1 x i64] }, ptr %l19
  %t434 = extractvalue { i64, [1 x i64] } %t432, 0
  %t435 = icmp eq i64 %t434, 4
  br i1 %t435, label %bb83, label %bb84
bb83:
  %t437 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t438 = getelementptr { i64 }, ptr %t437, i32 0, i32 0
  %t439 = load i64, ptr %t438
  store i64 %t439, ptr %l28, !tbaa !24
  br label %bb85
bb84:
  br label %bb93
bb85:
  store %olang.scope zeroinitializer, ptr %s15
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load %"compiler/eval:Ptr", ptr %l5
  %t445 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t441, %"compiler/eval:Ptr" %t442, i64 8)
  store i64 %t445, ptr %l217
  br label %bb86
bb86:
  %t446 = load i64, ptr %l28, !tbaa !24
  %t447 = load i64, ptr %l217, !tbaa !24
  %t449 = icmp ne i64 %t447, %t446
  br i1 %t449, label %bb87, label %bb88
bb87:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyPayload, !tbaa !27
  %t453 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t453, ptr %t451, { i64, ptr } %t452)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t456 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t457 = load i64, ptr %t456, !tbaa !24
  %t458 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t459 = load i64, ptr %t458, !tbaa !24
  %t461 = add i64 %t459, 8
  %t464 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s15, i64 %t457, i64 %t461)
  store %"compiler/eval:Ptr" %t464, ptr %l225
  br label %bb91
bb91:
  %t465 = load %"compiler/eval:Ptr", ptr %l225
  store %"compiler/eval:Ptr" %t465, ptr %l5
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i32, ptr %l6, !tbaa !23
  %t468 = load i64, ptr %l28, !tbaa !24
  %t472 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t466, i32 %t467, i64 %t468)
  store i32 %t472, ptr %l229
  br label %bb92
bb92:
  %t473 = load i32, ptr %l229, !tbaa !23
  store i32 %t473, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_c157b2e02f5238d7_241c429033d52203)
  unreachable
bb94:
  br label %bb95
bb95:
  %t474 = load i32, ptr %l17, !tbaa !23
  %t477 = add i32 %t474, 1
  store i32 %t477, ptr %l17, !tbaa !23
  br label %bb40
bb96:
  %t479 = load %"compiler/eval:Ptr", ptr %l5
  %t480 = load i32, ptr %l6, !tbaa !23
  %t482 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t479, 0
  %t484 = insertvalue { %"compiler/eval:Ptr", i32 } %t482, i32 %t480, 1
  store { %"compiler/eval:Ptr", i32 } %t484, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i32 }, ptr %rv
  ret { %"compiler/eval:Ptr", i32 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eprim(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca %"compiler/eval:Ptr"
  %l18 = alloca %"compiler/eval:Ptr"
  %l19 = alloca %"compiler/eval:Ptr"
  %l20 = alloca %"compiler/eval:Ptr"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca %"compiler/eval:Ptr"
  %l28 = alloca %"compiler/eval:Ptr"
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/eval:Ptr"
  %l39 = alloca %"compiler/eval:Ptr"
  %l43 = alloca { i64, [4 x i64] }
  %l47 = alloca i32
  %l54 = alloca i64
  %l61 = alloca i64
  %l73 = alloca %"compiler/eval:Ptr"
  %l74 = alloca ptr
  %l75 = alloca i64
  %l79 = alloca { i64, [4 x i64] }
  %l80 = alloca %"compiler/eval:Ptr"
  %l83 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l114 = alloca ptr
  %l120 = alloca %"compiler/eval:Ptr"
  %l121 = alloca %"compiler/eval:Ptr"
  %l122 = alloca ptr
  %l128 = alloca %"compiler/eval:Ptr"
  %l129 = alloca %"compiler/eval:Ptr"
  %l133 = alloca i1
  %l144 = alloca ptr
  %l148 = alloca %"compiler/eval:Ptr"
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca i64
  %l156 = alloca { i64, [4 x i64] }
  %l157 = alloca i64
  %l159 = alloca i64
  %l162 = alloca ptr
  %l166 = alloca i64
  %l169 = alloca i64
  %l172 = alloca ptr
  %l176 = alloca i64
  %l178 = alloca i64
  %l184 = alloca %"compiler/eval:Ptr"
  %l185 = alloca ptr
  %l189 = alloca %"compiler/eval:Ptr"
  %l190 = alloca %"compiler/eval:Ptr"
  %l193 = alloca i1
  %l199 = alloca %"compiler/eval:Ptr"
  %l200 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i64
  %l207 = alloca { i64, [4 x i64] }
  %l208 = alloca i32
  %l209 = alloca %"compiler/eval:Ptr"
  %l212 = alloca i64
  %l215 = alloca ptr
  %l216 = alloca i64
  %l220 = alloca %"compiler/eval:Ptr"
  %l238 = alloca i64
  %l253 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca i64
  %l261 = alloca { i64, [4 x i64] }
  %l262 = alloca i64
  %l266 = alloca i64
  %l270 = alloca i32
  %l271 = alloca i64
  %l274 = alloca i64
  %l275 = alloca i64
  %l277 = alloca i64
  %l280 = alloca i64
  %l282 = alloca i64
  %l285 = alloca i64
  %l289 = alloca i64
  %l292 = alloca i1
  %l295 = alloca i1
  %l303 = alloca i64
  %l304 = alloca ptr
  %l305 = alloca i64
  %l309 = alloca { i64, [4 x i64] }
  %l310 = alloca i32
  %l311 = alloca ptr
  %l312 = alloca i64
  %l316 = alloca { i64, [4 x i64] }
  %l317 = alloca i64
  %l324 = alloca i1
  %l328 = alloca i1
  %l332 = alloca i1
  %l343 = alloca i64
  %l346 = alloca i1
  %l352 = alloca %"compiler/eval:Ptr"
  %l353 = alloca ptr
  %l354 = alloca i64
  %l358 = alloca { i64, [4 x i64] }
  %l359 = alloca %"compiler/eval:Ptr"
  %l362 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i64
  %l395 = alloca i64
  %l402 = alloca %"compiler/eval:Ptr"
  %l403 = alloca ptr
  %l409 = alloca %"compiler/eval:Ptr"
  %l410 = alloca %"compiler/eval:Ptr"
  %l411 = alloca ptr
  %l417 = alloca %"compiler/eval:Ptr"
  %l419 = alloca i64
  %l420 = alloca %"compiler/eval:Ptr"
  %l423 = alloca %"compiler/eval:Ptr"
  %l424 = alloca ptr
  %l430 = alloca %"compiler/eval:Ptr"
  %l431 = alloca %"compiler/eval:Ptr"
  %l432 = alloca ptr
  %l438 = alloca %"compiler/eval:Ptr"
  %l440 = alloca i64
  %l441 = alloca %"compiler/eval:Ptr"
  %l445 = alloca i1
  %l456 = alloca i64
  %l458 = alloca i64
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l4
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l43
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l43
  store { i64, [4 x i64] } %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l5
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l47
  br label %bb2
bb2:
  %t16 = load i32, ptr %l47, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t19 = trunc i64 22 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t24 = load { i64, [4 x i64] }, ptr %l5
  %t25 = load i32, ptr %l6, !tbaa !23
  %t30 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elenOf(ptr %v0, ptr %t22, i64 %t23, { i64, [4 x i64] } %t24, i32 %t25)
  store i64 %t30, ptr %l54
  br label %bb6
bb6:
  %t31 = load i64, ptr %l54, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
bb7:
  %t32 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t34 = trunc i64 40 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load %"compiler/mir:Range", ptr %l4
  %t40 = load i32, ptr %l3, !tbaa !23
  %t45 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elaneDot(ptr %v0, ptr %t37, i64 %t38, %"compiler/mir:Range" %t39, i32 %t40)
  store i64 %t45, ptr %l61
  br label %bb11
bb11:
  %t46 = load i64, ptr %l61, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
bb12:
  %t47 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t49 = trunc i64 41 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load %"compiler/mir:Range", ptr %l4
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2elaneDots(ptr %v0, ptr %t52, i64 %t53, %"compiler/mir:Range" %t54)
  br label %bb16
bb16:
  store i64 0, ptr %rv
  br label %ret
bb17:
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t61 = trunc i64 19 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb50
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = load { i64, [4 x i64] }, ptr %l5
  %t70 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t64, i64 %t65, { i64, [4 x i64] } %t66, i64 1)
  store %"compiler/eval:Ptr" %t70, ptr %l73
  br label %bb21
bb21:
  %t71 = load %"compiler/eval:Ptr", ptr %l73
  store %"compiler/eval:Ptr" %t71, ptr %l7
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l74, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l75, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t76 = load %"compiler/mir:Range", ptr %l4
  %t80 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t74, i64 %t75, %"compiler/mir:Range" %t76, i64 1)
  store { i64, [4 x i64] } %t80, ptr %l79
  br label %bb22
bb22:
  %t81 = load ptr, ptr %l74, !tbaa !29
  %t82 = load i64, ptr %l75, !tbaa !24
  %t83 = load { i64, [4 x i64] }, ptr %l79
  %t84 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t81, i64 %t82, { i64, [4 x i64] } %t83, i64 2)
  store %"compiler/eval:Ptr" %t84, ptr %l80
  br label %bb23
bb23:
  %t85 = load %"compiler/eval:Ptr", ptr %l80
  store %"compiler/eval:Ptr" %t85, ptr %l8
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l6, !tbaa !23
  %t90 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t86, i32 %t87)
  store i64 %t90, ptr %l83
  br label %bb24
bb24:
  %t91 = load i64, ptr %l83, !tbaa !24
  store i64 %t91, ptr %l9, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 23
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  store i64 0, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store i64 0, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t100 = add i64 %t98, 7
  %t102 = sdiv i64 %t100, 8
  store i64 %t102, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t110 = load i64, ptr %l12, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb33
bb30:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l12, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l96, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb32
bb32:
  %t130 = load i64, ptr %l96, !tbaa !24
  store i64 %t130, ptr %l93, !tbaa !24
  br label %bb33
bb33:
  %t131 = load i64, ptr %l93, !tbaa !24
  store i64 %t131, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l14, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb36:
  br label %bb37
bb37:
  %t140 = load i64, ptr %l10, !tbaa !24
  %t141 = load i64, ptr %l14, !tbaa !24
  %t142 = load i64, ptr %l12, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  store i64 %t148, ptr %l15, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l114, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t154 = load i64, ptr %t153, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t157 = mul i64 8, %t155
  %t160 = add i64 %t154, %t157
  %t163 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t152, i64 %t160)
  store %"compiler/eval:Ptr" %t163, ptr %l120
  br label %bb38
bb38:
  %t164 = load ptr, ptr %l114, !tbaa !29
  %t165 = load %"compiler/eval:Ptr", ptr %l120
  %t166 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t164, %"compiler/eval:Ptr" %t165)
  store %"compiler/eval:Ptr" %t166, ptr %l121
  br label %bb39
bb39:
  %t167 = load %"compiler/eval:Ptr", ptr %l121
  store %"compiler/eval:Ptr" %t167, ptr %l16
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l122, !tbaa !29
  %t169 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 1
  %t172 = load i64, ptr %t171, !tbaa !24
  %t173 = load i64, ptr %l15, !tbaa !24
  %t175 = mul i64 8, %t173
  %t178 = add i64 %t172, %t175
  %t181 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t170, i64 %t178)
  store %"compiler/eval:Ptr" %t181, ptr %l128
  br label %bb40
bb40:
  %t182 = load ptr, ptr %l122, !tbaa !29
  %t183 = load %"compiler/eval:Ptr", ptr %l128
  %t184 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t182, %"compiler/eval:Ptr" %t183)
  store %"compiler/eval:Ptr" %t184, ptr %l129
  br label %bb41
bb41:
  %t185 = load %"compiler/eval:Ptr", ptr %l129
  store %"compiler/eval:Ptr" %t185, ptr %l17
  %t186 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = getelementptr %"compiler/eval:Ptr", ptr %l17, i32 0, i32 0
  %t189 = load i64, ptr %t188, !tbaa !24
  %t192 = icmp ne i64 %t187, %t189
  br i1 %t192, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb44
bb43:
  %t194 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 1
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = getelementptr %"compiler/eval:Ptr", ptr %l17, i32 0, i32 1
  %t197 = load i64, ptr %t196, !tbaa !24
  %t200 = icmp ne i64 %t195, %t197
  store i1 %t200, ptr %l133, !tbaa !21
  br label %bb44
bb44:
  %t202 = load i1, ptr %l133, !tbaa !21
  br i1 %t202, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s7)
  store i64 0, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb48:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t207 = add i64 %t204, 1
  store i64 %t207, ptr %l14, !tbaa !24
  br label %bb34
bb49:
  store i64 1, ptr %rv
  br label %ret
bb50:
  %t210 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t212 = trunc i64 23 to i32
  %t213 = icmp eq i32 %t210, %t212
  br i1 %t213, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb61
bb53:
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l144, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i64, ptr %l1, !tbaa !24
  %t218 = load { i64, [4 x i64] }, ptr %l5
  %t222 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t216, i64 %t217, { i64, [4 x i64] } %t218, i64 1)
  store %"compiler/eval:Ptr" %t222, ptr %l148
  br label %bb54
bb54:
  %t223 = load i32, ptr %l6, !tbaa !23
  %t224 = load ptr, ptr %l144, !tbaa !29
  %t225 = load %"compiler/eval:Ptr", ptr %l148
  %t227 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %t224, %"compiler/eval:Ptr" %t225, i32 %t223)
  store i64 %t227, ptr %l150
  br label %bb55
bb55:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l151, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  store i64 %t229, ptr %l152, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l1, !tbaa !24
  %t232 = load %"compiler/mir:Range", ptr %l4
  %t236 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t230, i64 %t231, %"compiler/mir:Range" %t232, i64 1)
  store { i64, [4 x i64] } %t236, ptr %l156
  br label %bb56
bb56:
  %t237 = load ptr, ptr %l151, !tbaa !29
  %t238 = load i64, ptr %l152, !tbaa !24
  %t239 = load { i64, [4 x i64] }, ptr %l156
  %t240 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t237, i64 %t238, { i64, [4 x i64] } %t239)
  store i64 %t240, ptr %l157
  br label %bb57
bb57:
  %t241 = load i64, ptr %l150, !tbaa !24
  %t242 = load i64, ptr %l157, !tbaa !24
  %t243 = icmp eq i64 %t241, %t242
  br i1 %t243, label %bb58, label %bb59
bb58:
  store i64 1, ptr %l159, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb60
bb60:
  %t245 = load i64, ptr %l159, !tbaa !24
  store i64 %t245, ptr %rv
  br label %ret
bb61:
  %t246 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t248 = trunc i64 20 to i32
  %t249 = icmp eq i32 %t246, %t248
  br i1 %t249, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l162, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i64, ptr %l1, !tbaa !24
  %t254 = load { i64, [4 x i64] }, ptr %l5
  %t258 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t252, i64 %t253, { i64, [4 x i64] } %t254)
  store i64 %t258, ptr %l166
  br label %bb65
bb65:
  %t259 = load i32, ptr %l6, !tbaa !23
  %t260 = load i32, ptr %l3, !tbaa !23
  %t261 = load ptr, ptr %l162, !tbaa !29
  %t262 = load i64, ptr %l166, !tbaa !24
  %t265 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econvert(ptr %v0, ptr %t261, i64 %t262, i32 %t259, i32 %t260)
  store i64 %t265, ptr %l169
  br label %bb66
bb66:
  %t266 = load i64, ptr %l169, !tbaa !24
  store i64 %t266, ptr %rv
  br label %ret
bb67:
  %t267 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t269 = trunc i64 21 to i32
  %t270 = icmp eq i32 %t267, %t269
  br i1 %t270, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l172, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i64, ptr %l1, !tbaa !24
  %t275 = load { i64, [4 x i64] }, ptr %l5
  %t279 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t273, i64 %t274, { i64, [4 x i64] } %t275)
  store i64 %t279, ptr %l176
  br label %bb71
bb71:
  %t280 = load i32, ptr %l6, !tbaa !23
  %t281 = load ptr, ptr %l172, !tbaa !29
  %t282 = load i64, ptr %l176, !tbaa !24
  %t284 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebitcast(ptr %v0, ptr %t281, i64 %t282, i32 %t280)
  store i64 %t284, ptr %l178
  br label %bb72
bb72:
  %t285 = load i64, ptr %l178, !tbaa !24
  store i64 %t285, ptr %rv
  br label %ret
bb73:
  %t286 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t288 = trunc i64 46 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb93
bb76:
  store %olang.scope zeroinitializer, ptr %s13
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i64, ptr %l1, !tbaa !24
  %t293 = load { i64, [4 x i64] }, ptr %l5
  %t297 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t291, i64 %t292, { i64, [4 x i64] } %t293, i64 1)
  store %"compiler/eval:Ptr" %t297, ptr %l184
  br label %bb77
bb77:
  %t298 = load %"compiler/eval:Ptr", ptr %l184
  store %"compiler/eval:Ptr" %t298, ptr %l18
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l185, !tbaa !29
  %t300 = getelementptr %"compiler/eval:Ptr", ptr %l18, i32 0, i32 0
  %t301 = load i64, ptr %t300, !tbaa !24
  %t302 = getelementptr %"compiler/eval:Ptr", ptr %l18, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t305 = add i64 %t303, 8
  %t308 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s13, i64 %t301, i64 %t305)
  store %"compiler/eval:Ptr" %t308, ptr %l189
  br label %bb78
bb78:
  %t309 = load ptr, ptr %l185, !tbaa !29
  %t310 = load %"compiler/eval:Ptr", ptr %l189
  %t311 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t309, %"compiler/eval:Ptr" %t310)
  store %"compiler/eval:Ptr" %t311, ptr %l190
  br label %bb79
bb79:
  %t312 = load %"compiler/eval:Ptr", ptr %l190
  store %"compiler/eval:Ptr" %t312, ptr %l19
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/eval:Machine", ptr %t313, i32 0, i32 23
  %t316 = load i1, ptr %t315, !tbaa !21
  br i1 %t316, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb82
bb81:
  %t318 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t319 = load i64, ptr %t318, !tbaa !24
  %t321 = icmp eq i64 %t319, 0
  store i1 %t321, ptr %l193, !tbaa !21
  br label %bb82
bb82:
  %t323 = load i1, ptr %l193, !tbaa !21
  br i1 %t323, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s13)
  store i64 0, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load %"compiler/eval:Ptr", ptr %l19
  %t329 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t325, %"compiler/eval:Ptr" %t326)
  store %"compiler/eval:Ptr" %t329, ptr %l199
  br label %bb86
bb86:
  %t330 = load %"compiler/eval:Ptr", ptr %l199
  store %"compiler/eval:Ptr" %t330, ptr %l20
  %t331 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t332 = load i64, ptr %t331, !tbaa !24
  store i64 %t332, ptr %l200, !tbaa !24
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l201, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l202, !tbaa !29
  %t335 = load i64, ptr %l1, !tbaa !24
  store i64 %t335, ptr %l203, !tbaa !24
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i64, ptr %l1, !tbaa !24
  %t338 = load %"compiler/mir:Range", ptr %l4
  %t342 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t336, i64 %t337, %"compiler/mir:Range" %t338, i64 1)
  store { i64, [4 x i64] } %t342, ptr %l207
  br label %bb87
bb87:
  %t343 = load ptr, ptr %l202, !tbaa !29
  %t344 = load i64, ptr %l203, !tbaa !24
  %t345 = load { i64, [4 x i64] }, ptr %l207
  %t346 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t343, i64 %t344, { i64, [4 x i64] } %t345)
  store i32 %t346, ptr %l208
  br label %bb88
bb88:
  %t347 = load ptr, ptr %l201, !tbaa !29
  %t348 = load i32, ptr %l208, !tbaa !23
  %t349 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %t347, i32 %t348)
  store %"compiler/eval:Ptr" %t349, ptr %l209
  br label %bb89
bb89:
  %t350 = getelementptr %"compiler/eval:Ptr", ptr %l209, i32 0, i32 0
  %t351 = load i64, ptr %t350, !tbaa !24
  %t352 = load i64, ptr %l200, !tbaa !24
  %t354 = icmp eq i64 %t352, %t351
  br i1 %t354, label %bb90, label %bb91
bb90:
  store i64 1, ptr %l212, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s13)
  %t356 = load i64, ptr %l212, !tbaa !24
  store i64 %t356, ptr %rv
  br label %ret
bb93:
  %t357 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t359 = trunc i64 29 to i32
  %t360 = icmp eq i32 %t357, %t359
  br i1 %t360, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l215, !tbaa !29
  %t363 = load i64, ptr %l1, !tbaa !24
  store i64 %t363, ptr %l216, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i64, ptr %l1, !tbaa !24
  %t366 = load { i64, [4 x i64] }, ptr %l5
  %t370 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t364, i64 %t365, { i64, [4 x i64] } %t366, i64 1)
  store %"compiler/eval:Ptr" %t370, ptr %l220
  br label %bb97
bb97:
  %t371 = load i32, ptr %l6, !tbaa !23
  %t372 = load ptr, ptr %l215, !tbaa !29
  %t373 = load i64, ptr %l216, !tbaa !24
  %t374 = load %"compiler/eval:Ptr", ptr %l220
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eretire(ptr %v0, ptr %t372, i64 %t373, %"compiler/eval:Ptr" %t374, i32 %t371)
  br label %bb98
bb98:
  store i64 0, ptr %rv
  br label %ret
bb99:
  %t377 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t379 = trunc i64 24 to i32
  %t380 = icmp eq i32 %t377, %t379
  br i1 %t380, label %bb100, label %bb101
bb100:
  br label %bb110
bb101:
  %t382 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t384 = trunc i64 25 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb102, label %bb103
bb102:
  br label %bb110
bb103:
  %t387 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t389 = trunc i64 26 to i32
  %t390 = icmp eq i32 %t387, %t389
  br i1 %t390, label %bb104, label %bb105
bb104:
  br label %bb110
bb105:
  %t392 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t394 = trunc i64 27 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb106, label %bb107
bb106:
  br label %bb110
bb107:
  %t397 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t399 = trunc i64 28 to i32
  %t400 = icmp eq i32 %t397, %t399
  br i1 %t400, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l1, !tbaa !24
  %t404 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t405 = load %"compiler/mir:Range", ptr %l4
  %t406 = load i32, ptr %l6, !tbaa !23
  %t412 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eatomic(ptr %v0, ptr %t402, i64 %t403, i32 %t404, %"compiler/mir:Range" %t405, i32 %t406)
  store i64 %t412, ptr %l238
  br label %bb111
bb111:
  %t413 = load i64, ptr %l238, !tbaa !24
  store i64 %t413, ptr %rv
  br label %ret
bb112:
  %t414 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t416 = trunc i64 32 to i32
  %t417 = icmp eq i32 %t414, %t416
  br i1 %t417, label %bb113, label %bb114
bb113:
  br label %bb125
bb114:
  %t419 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t421 = trunc i64 33 to i32
  %t422 = icmp eq i32 %t419, %t421
  br i1 %t422, label %bb115, label %bb116
bb115:
  br label %bb125
bb116:
  %t424 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t426 = trunc i64 34 to i32
  %t427 = icmp eq i32 %t424, %t426
  br i1 %t427, label %bb117, label %bb118
bb117:
  br label %bb125
bb118:
  %t429 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t431 = trunc i64 37 to i32
  %t432 = icmp eq i32 %t429, %t431
  br i1 %t432, label %bb119, label %bb120
bb119:
  br label %bb125
bb120:
  %t434 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t436 = trunc i64 35 to i32
  %t437 = icmp eq i32 %t434, %t436
  br i1 %t437, label %bb121, label %bb122
bb121:
  br label %bb125
bb122:
  %t439 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t441 = trunc i64 36 to i32
  %t442 = icmp eq i32 %t439, %t441
  br i1 %t442, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb142
bb125:
  store i64 0, ptr %l21, !tbaa !24
  %t444 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t446 = trunc i64 35 to i32
  %t447 = icmp eq i32 %t444, %t446
  br i1 %t447, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l253, !tbaa !21
  br label %bb128
bb127:
  %t449 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t451 = trunc i64 36 to i32
  %t452 = icmp eq i32 %t449, %t451
  store i1 %t452, ptr %l253, !tbaa !21
  br label %bb128
bb128:
  %t454 = load i1, ptr %l253, !tbaa !21
  br i1 %t454, label %bb129, label %bb130
bb129:
  %t455 = load ptr, ptr %l0, !tbaa !29
  store ptr %t455, ptr %l256, !tbaa !29
  %t456 = load i64, ptr %l1, !tbaa !24
  store i64 %t456, ptr %l257, !tbaa !24
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load i64, ptr %l1, !tbaa !24
  %t459 = load %"compiler/mir:Range", ptr %l4
  %t463 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t457, i64 %t458, %"compiler/mir:Range" %t459, i64 1)
  store { i64, [4 x i64] } %t463, ptr %l261
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t464 = load ptr, ptr %l256, !tbaa !29
  %t465 = load i64, ptr %l257, !tbaa !24
  %t466 = load { i64, [4 x i64] }, ptr %l261
  %t467 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t464, i64 %t465, { i64, [4 x i64] } %t466)
  store i64 %t467, ptr %l262
  br label %bb132
bb132:
  %t468 = load i64, ptr %l262, !tbaa !24
  store i64 %t468, ptr %l21, !tbaa !24
  br label %bb133
bb133:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load i64, ptr %l1, !tbaa !24
  %t471 = load { i64, [4 x i64] }, ptr %l5
  %t475 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t469, i64 %t470, { i64, [4 x i64] } %t471)
  store i64 %t475, ptr %l266
  br label %bb134
bb134:
  %t476 = load i64, ptr %l266, !tbaa !24
  store i64 %t476, ptr %l22, !tbaa !24
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/eval:Machine", ptr %t477, i32 0, i32 23
  %t480 = load i1, ptr %t479, !tbaa !21
  br i1 %t480, label %bb135, label %bb136
bb135:
  store i64 0, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t483 = load i32, ptr %l2, !range !{i32 0, i32 54}
  store i32 %t483, ptr %l270
  %t484 = load i64, ptr %l22, !tbaa !24
  store i64 %t484, ptr %l271, !tbaa !24
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l6, !tbaa !23
  %t489 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t485, i32 %t486)
  store i64 %t489, ptr %l274
  br label %bb138
bb138:
  %t490 = load i64, ptr %l274, !tbaa !24
  %t491 = call i64 @compiler_2feval_2ebmask(i64 %t490)
  store i64 %t491, ptr %l275
  br label %bb139
bb139:
  %t492 = load i64, ptr %l271, !tbaa !24
  %t493 = load i64, ptr %l275, !tbaa !24
  %t494 = and i64 %t492, %t493
  store i64 %t494, ptr %l277, !tbaa !65
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i32, ptr %l6, !tbaa !23
  %t500 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t496, i32 %t497)
  store i64 %t500, ptr %l280
  br label %bb140
bb140:
  %t501 = load i64, ptr %l21, !tbaa !24
  %t502 = load i32, ptr %l270, !range !{i32 0, i32 54}
  %t503 = load i64, ptr %l277, !tbaa !65
  %t504 = load i64, ptr %l280, !tbaa !24
  %t506 = call i64 @compiler_2feval_2ebitOp(i32 %t502, i64 %t503, i64 %t504, i64 %t501)
  store i64 %t506, ptr %l282
  br label %bb141
bb141:
  %t507 = load i64, ptr %l282, !tbaa !24
  store i64 %t507, ptr %rv
  br label %ret
bb142:
  br i1 true, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_c5a1577ee3e22d75_549c323efc9636a1)
  unreachable
bb147:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load i32, ptr %l6, !tbaa !23
  %t512 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t508, i32 %t509)
  store i64 %t512, ptr %l285
  br label %bb148
bb148:
  %t513 = load i64, ptr %l285, !tbaa !24
  store i64 %t513, ptr %l23, !tbaa !24
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i64, ptr %l1, !tbaa !24
  %t516 = load { i64, [4 x i64] }, ptr %l5
  %t520 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t514, i64 %t515, { i64, [4 x i64] } %t516)
  store i64 %t520, ptr %l289
  br label %bb149
bb149:
  %t521 = load i64, ptr %l289, !tbaa !24
  store i64 %t521, ptr %l24, !tbaa !24
  %t522 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t524 = trunc i64 0 to i32
  %t525 = icmp eq i32 %t522, %t524
  br i1 %t525, label %bb150, label %bb151
bb150:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb152
bb151:
  %t527 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t529 = trunc i64 1 to i32
  %t530 = icmp eq i32 %t527, %t529
  store i1 %t530, ptr %l292, !tbaa !21
  br label %bb152
bb152:
  %t532 = load i1, ptr %l292, !tbaa !21
  br i1 %t532, label %bb153, label %bb154
bb153:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb155
bb154:
  %t533 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t535 = trunc i64 2 to i32
  %t536 = icmp eq i32 %t533, %t535
  store i1 %t536, ptr %l295, !tbaa !21
  br label %bb155
bb155:
  %t538 = load i1, ptr %l295, !tbaa !21
  br i1 %t538, label %bb156, label %bb157
bb156:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t541 = load i64, ptr %l24, !tbaa !24
  %t542 = load i32, ptr %l6, !tbaa !23
  %t543 = load i64, ptr %l23, !tbaa !24
  %t549 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %t539, i32 %t540, i64 %t541, i32 %t542, i64 %t543)
  store i64 %t549, ptr %l303
  br label %bb158
bb157:
  br label %bb159
bb158:
  %t550 = load i64, ptr %l303, !tbaa !24
  store i64 %t550, ptr %rv
  br label %ret
bb159:
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l304, !tbaa !29
  %t552 = load i64, ptr %l1, !tbaa !24
  store i64 %t552, ptr %l305, !tbaa !24
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load i64, ptr %l1, !tbaa !24
  %t555 = load %"compiler/mir:Range", ptr %l4
  %t559 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t553, i64 %t554, %"compiler/mir:Range" %t555, i64 1)
  store { i64, [4 x i64] } %t559, ptr %l309
  br label %bb160
bb160:
  %t560 = load ptr, ptr %l304, !tbaa !29
  %t561 = load i64, ptr %l305, !tbaa !24
  %t562 = load { i64, [4 x i64] }, ptr %l309
  %t563 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t560, i64 %t561, { i64, [4 x i64] } %t562)
  store i32 %t563, ptr %l310
  br label %bb161
bb161:
  %t564 = load i32, ptr %l310, !tbaa !23
  store i32 %t564, ptr %l25, !tbaa !23
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l311, !tbaa !29
  %t566 = load i64, ptr %l1, !tbaa !24
  store i64 %t566, ptr %l312, !tbaa !24
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i64, ptr %l1, !tbaa !24
  %t569 = load %"compiler/mir:Range", ptr %l4
  %t573 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t567, i64 %t568, %"compiler/mir:Range" %t569, i64 1)
  store { i64, [4 x i64] } %t573, ptr %l316
  br label %bb162
bb162:
  %t574 = load ptr, ptr %l311, !tbaa !29
  %t575 = load i64, ptr %l312, !tbaa !24
  %t576 = load { i64, [4 x i64] }, ptr %l316
  %t577 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t574, i64 %t575, { i64, [4 x i64] } %t576)
  store i64 %t577, ptr %l317
  br label %bb163
bb163:
  %t578 = load i64, ptr %l317, !tbaa !24
  store i64 %t578, ptr %l26, !tbaa !24
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = getelementptr %"compiler/eval:Machine", ptr %t579, i32 0, i32 23
  %t582 = load i1, ptr %t581, !tbaa !21
  br i1 %t582, label %bb164, label %bb165
bb164:
  store i64 0, ptr %rv
  br label %ret
bb165:
  br label %bb166
bb166:
  %t585 = load i64, ptr %l23, !tbaa !24
  %t586 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t589 = icmp eq i64 %t585, %t586
  br i1 %t589, label %bb167, label %bb168
bb167:
  store i1 true, ptr %l324, !tbaa !21
  br label %bb169
bb168:
  %t591 = load i64, ptr %l23, !tbaa !24
  %t592 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t595 = icmp eq i64 %t591, %t592
  store i1 %t595, ptr %l324, !tbaa !21
  br label %bb169
bb169:
  %t597 = load i1, ptr %l324, !tbaa !21
  br i1 %t597, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l328, !tbaa !21
  br label %bb172
bb171:
  %t598 = load i64, ptr %l23, !tbaa !24
  %t599 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t602 = icmp eq i64 %t598, %t599
  store i1 %t602, ptr %l328, !tbaa !21
  br label %bb172
bb172:
  %t604 = load i1, ptr %l328, !tbaa !21
  br i1 %t604, label %bb173, label %bb174
bb173:
  store i1 true, ptr %l332, !tbaa !21
  br label %bb175
bb174:
  %t605 = load i64, ptr %l23, !tbaa !24
  %t606 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t609 = icmp eq i64 %t605, %t606
  store i1 %t609, ptr %l332, !tbaa !21
  br label %bb175
bb175:
  %t611 = load i1, ptr %l332, !tbaa !21
  br i1 %t611, label %bb176, label %bb177
bb176:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t614 = load i64, ptr %l24, !tbaa !24
  %t615 = load i64, ptr %l26, !tbaa !24
  %t616 = load i32, ptr %l6, !tbaa !23
  %t617 = load i32, ptr %l25, !tbaa !23
  %t618 = load i64, ptr %l23, !tbaa !24
  %t626 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %t612, i32 %t613, i64 %t614, i64 %t615, i32 %t616, i32 %t617, i64 %t618)
  store i64 %t626, ptr %l343
  br label %bb178
bb177:
  br label %bb179
bb178:
  %t627 = load i64, ptr %l343, !tbaa !24
  store i64 %t627, ptr %rv
  br label %ret
bb179:
  %t628 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t630 = trunc i64 13 to i32
  %t631 = icmp eq i32 %t628, %t630
  br i1 %t631, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l346, !tbaa !21
  br label %bb182
bb181:
  %t633 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t635 = trunc i64 14 to i32
  %t636 = icmp eq i32 %t633, %t635
  store i1 %t636, ptr %l346, !tbaa !21
  br label %bb182
bb182:
  %t638 = load i1, ptr %l346, !tbaa !21
  br i1 %t638, label %bb183, label %bb184
bb183:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = load i64, ptr %l1, !tbaa !24
  %t641 = load { i64, [4 x i64] }, ptr %l5
  %t645 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t639, i64 %t640, { i64, [4 x i64] } %t641, i64 1)
  store %"compiler/eval:Ptr" %t645, ptr %l352
  br label %bb185
bb184:
  br label %bb229
bb185:
  %t646 = load %"compiler/eval:Ptr", ptr %l352
  store %"compiler/eval:Ptr" %t646, ptr %l27
  %t647 = load ptr, ptr %l0, !tbaa !29
  store ptr %t647, ptr %l353, !tbaa !29
  %t648 = load i64, ptr %l1, !tbaa !24
  store i64 %t648, ptr %l354, !tbaa !24
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load i64, ptr %l1, !tbaa !24
  %t651 = load %"compiler/mir:Range", ptr %l4
  %t655 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t649, i64 %t650, %"compiler/mir:Range" %t651, i64 1)
  store { i64, [4 x i64] } %t655, ptr %l358
  br label %bb186
bb186:
  %t656 = load ptr, ptr %l353, !tbaa !29
  %t657 = load i64, ptr %l354, !tbaa !24
  %t658 = load { i64, [4 x i64] }, ptr %l358
  %t659 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t656, i64 %t657, { i64, [4 x i64] } %t658, i64 2)
  store %"compiler/eval:Ptr" %t659, ptr %l359
  br label %bb187
bb187:
  %t660 = load %"compiler/eval:Ptr", ptr %l359
  store %"compiler/eval:Ptr" %t660, ptr %l28
  store i1 true, ptr %l29, !tbaa !21
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t662 = load i32, ptr %l6, !tbaa !23
  %t665 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t661, i32 %t662)
  store i64 %t665, ptr %l362
  br label %bb188
bb188:
  %t666 = load i64, ptr %l362, !tbaa !24
  store i64 %t666, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  %t667 = load i64, ptr %l30, !tbaa !24
  %t669 = add i64 %t667, 7
  %t671 = sdiv i64 %t669, 8
  store i64 %t671, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t673 = load i64, ptr %l32, !tbaa !24
  %t674 = load i64, ptr %l31, !tbaa !24
  %t677 = icmp sgt i64 %t673, %t674
  br i1 %t677, label %bb189, label %bb190
bb189:
  %t679 = load i64, ptr %l33, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb191, label %bb192
bb190:
  store i64 0, ptr %l369, !tbaa !24
  br label %bb194
bb191:
  %t683 = load i64, ptr %l32, !tbaa !24
  %t684 = load i64, ptr %l31, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l33, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l33, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l372, !tbaa !24
  br label %bb193
bb192:
  store i64 0, ptr %l372, !tbaa !24
  br label %bb193
bb193:
  %t699 = load i64, ptr %l372, !tbaa !24
  store i64 %t699, ptr %l369, !tbaa !24
  br label %bb194
bb194:
  %t700 = load i64, ptr %l369, !tbaa !24
  store i64 %t700, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb195
bb195:
  store %olang.scope zeroinitializer, ptr %s26
  %t701 = load i64, ptr %l35, !tbaa !24
  %t702 = load i64, ptr %l34, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb196, label %bb197
bb196:
  call void @__olang_scope_close(ptr %s26)
  br label %bb225
bb197:
  br label %bb198
bb198:
  %t709 = load i64, ptr %l31, !tbaa !24
  %t710 = load i64, ptr %l35, !tbaa !24
  %t711 = load i64, ptr %l33, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l36, !tbaa !24
  %t719 = load i64, ptr %l30, !tbaa !24
  %t720 = load i64, ptr %l36, !tbaa !24
  %t722 = mul i64 8, %t720
  %t725 = sub i64 %t719, %t722
  %t727 = icmp sge i64 %t725, 8
  br i1 %t727, label %bb199, label %bb200
bb199:
  store i64 8, ptr %l395, !tbaa !24
  br label %bb201
bb200:
  %t729 = load i64, ptr %l30, !tbaa !24
  %t730 = load i64, ptr %l36, !tbaa !24
  %t732 = mul i64 8, %t730
  %t735 = sub i64 %t729, %t732
  store i64 %t735, ptr %l395, !tbaa !24
  br label %bb201
bb201:
  %t737 = load i64, ptr %l395, !tbaa !24
  store i64 %t737, ptr %l37, !tbaa !24
  %t738 = load i64, ptr %l37, !tbaa !24
  %t740 = icmp eq i64 %t738, 8
  br i1 %t740, label %bb202, label %bb203
bb202:
  %t742 = load ptr, ptr %l0, !tbaa !29
  store ptr %t742, ptr %l403, !tbaa !29
  %t743 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 0
  %t744 = load i64, ptr %t743, !tbaa !24
  %t745 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 1
  %t746 = load i64, ptr %t745, !tbaa !24
  %t747 = load i64, ptr %l36, !tbaa !24
  %t749 = mul i64 8, %t747
  %t752 = add i64 %t746, %t749
  %t755 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 %t744, i64 %t752)
  store %"compiler/eval:Ptr" %t755, ptr %l409
  br label %bb204
bb203:
  %t756 = load ptr, ptr %l0, !tbaa !29
  store ptr %t756, ptr %l411, !tbaa !29
  %t757 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 0
  %t758 = load i64, ptr %t757, !tbaa !24
  %t759 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 1
  %t760 = load i64, ptr %t759, !tbaa !24
  %t761 = load i64, ptr %l36, !tbaa !24
  %t763 = mul i64 8, %t761
  %t766 = add i64 %t760, %t763
  %t769 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 %t758, i64 %t766)
  store %"compiler/eval:Ptr" %t769, ptr %l417
  br label %bb206
bb204:
  %t770 = load ptr, ptr %l403, !tbaa !29
  %t771 = load %"compiler/eval:Ptr", ptr %l409
  %t772 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t770, %"compiler/eval:Ptr" %t771)
  store %"compiler/eval:Ptr" %t772, ptr %l410
  br label %bb205
bb205:
  %t773 = load %"compiler/eval:Ptr", ptr %l410
  store %"compiler/eval:Ptr" %t773, ptr %l402
  br label %bb209
bb206:
  %t774 = load i64, ptr %l37, !tbaa !24
  %t775 = load ptr, ptr %l411, !tbaa !29
  %t776 = load %"compiler/eval:Ptr", ptr %l417
  %t778 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t775, %"compiler/eval:Ptr" %t776, i64 %t774)
  store i64 %t778, ptr %l419
  br label %bb207
bb207:
  %t779 = load i64, ptr %l419, !tbaa !24
  %t780 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 0, i64 %t779)
  store %"compiler/eval:Ptr" %t780, ptr %l420
  br label %bb208
bb208:
  %t781 = load %"compiler/eval:Ptr", ptr %l420
  store %"compiler/eval:Ptr" %t781, ptr %l402
  br label %bb209
bb209:
  %t782 = load %"compiler/eval:Ptr", ptr %l402
  store %"compiler/eval:Ptr" %t782, ptr %l38
  %t783 = load i64, ptr %l37, !tbaa !24
  %t785 = icmp eq i64 %t783, 8
  br i1 %t785, label %bb210, label %bb211
bb210:
  %t787 = load ptr, ptr %l0, !tbaa !29
  store ptr %t787, ptr %l424, !tbaa !29
  %t788 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 0
  %t789 = load i64, ptr %t788, !tbaa !24
  %t790 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 1
  %t791 = load i64, ptr %t790, !tbaa !24
  %t792 = load i64, ptr %l36, !tbaa !24
  %t794 = mul i64 8, %t792
  %t797 = add i64 %t791, %t794
  %t800 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 %t789, i64 %t797)
  store %"compiler/eval:Ptr" %t800, ptr %l430
  br label %bb212
bb211:
  %t801 = load ptr, ptr %l0, !tbaa !29
  store ptr %t801, ptr %l432, !tbaa !29
  %t802 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 0
  %t803 = load i64, ptr %t802, !tbaa !24
  %t804 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 1
  %t805 = load i64, ptr %t804, !tbaa !24
  %t806 = load i64, ptr %l36, !tbaa !24
  %t808 = mul i64 8, %t806
  %t811 = add i64 %t805, %t808
  %t814 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 %t803, i64 %t811)
  store %"compiler/eval:Ptr" %t814, ptr %l438
  br label %bb214
bb212:
  %t815 = load ptr, ptr %l424, !tbaa !29
  %t816 = load %"compiler/eval:Ptr", ptr %l430
  %t817 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t815, %"compiler/eval:Ptr" %t816)
  store %"compiler/eval:Ptr" %t817, ptr %l431
  br label %bb213
bb213:
  %t818 = load %"compiler/eval:Ptr", ptr %l431
  store %"compiler/eval:Ptr" %t818, ptr %l423
  br label %bb217
bb214:
  %t819 = load i64, ptr %l37, !tbaa !24
  %t820 = load ptr, ptr %l432, !tbaa !29
  %t821 = load %"compiler/eval:Ptr", ptr %l438
  %t823 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t820, %"compiler/eval:Ptr" %t821, i64 %t819)
  store i64 %t823, ptr %l440
  br label %bb215
bb215:
  %t824 = load i64, ptr %l440, !tbaa !24
  %t825 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 0, i64 %t824)
  store %"compiler/eval:Ptr" %t825, ptr %l441
  br label %bb216
bb216:
  %t826 = load %"compiler/eval:Ptr", ptr %l441
  store %"compiler/eval:Ptr" %t826, ptr %l423
  br label %bb217
bb217:
  %t827 = load %"compiler/eval:Ptr", ptr %l423
  store %"compiler/eval:Ptr" %t827, ptr %l39
  %t828 = getelementptr %"compiler/eval:Ptr", ptr %l38, i32 0, i32 0
  %t829 = load i64, ptr %t828, !tbaa !24
  %t830 = getelementptr %"compiler/eval:Ptr", ptr %l39, i32 0, i32 0
  %t831 = load i64, ptr %t830, !tbaa !24
  %t834 = icmp ne i64 %t829, %t831
  br i1 %t834, label %bb218, label %bb219
bb218:
  store i1 true, ptr %l445, !tbaa !21
  br label %bb220
bb219:
  %t836 = getelementptr %"compiler/eval:Ptr", ptr %l38, i32 0, i32 1
  %t837 = load i64, ptr %t836, !tbaa !24
  %t838 = getelementptr %"compiler/eval:Ptr", ptr %l39, i32 0, i32 1
  %t839 = load i64, ptr %t838, !tbaa !24
  %t842 = icmp ne i64 %t837, %t839
  store i1 %t842, ptr %l445, !tbaa !21
  br label %bb220
bb220:
  %t844 = load i1, ptr %l445, !tbaa !21
  br i1 %t844, label %bb221, label %bb222
bb221:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb223
bb222:
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s26)
  br label %bb224
bb224:
  %t845 = load i64, ptr %l35, !tbaa !24
  %t848 = add i64 %t845, 1
  store i64 %t848, ptr %l35, !tbaa !24
  br label %bb195
bb225:
  %t850 = load i1, ptr %l29, !tbaa !21
  %t851 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t853 = trunc i64 13 to i32
  %t854 = icmp eq i32 %t851, %t853
  %t857 = icmp eq i1 %t850, %t854
  br i1 %t857, label %bb226, label %bb227
bb226:
  store i64 1, ptr %l456, !tbaa !24
  br label %bb228
bb227:
  store i64 0, ptr %l456, !tbaa !24
  br label %bb228
bb228:
  %t859 = load i64, ptr %l456, !tbaa !24
  store i64 %t859, ptr %rv
  br label %ret
bb229:
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t862 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t860)
  store i64 %t862, ptr %l458
  br label %bb230
bb230:
  %t863 = load i64, ptr %l458, !tbaa !24
  store i64 %t863, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/eval:frame"
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca %"compiler/eval:frame"
  %l125 = alloca i64
  %l128 = alloca i64
  %l153 = alloca ptr
  %l154 = alloca i64
  %l156 = alloca i64
  %l160 = alloca { i64, ptr }
  %l167 = alloca i64
  %l170 = alloca i64
  %l179 = alloca i64
  %l182 = alloca i1
  %l193 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l205 = alloca i64
  %l208 = alloca i64
  %l226 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca %"compiler/eval:Ptr"
  %l241 = alloca { i64, ptr }
  %l258 = alloca i64
  %l261 = alloca i64
  %l270 = alloca i64
  %l273 = alloca i1
  %l284 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l303 = alloca i64
  %l307 = alloca i64
  %l308 = alloca %"compiler/eval:frame"
  %l310 = alloca %"compiler/eval:frame"
  %l314 = alloca { i64, ptr }
  %l321 = alloca i64
  %l324 = alloca i64
  %l343 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l347 = alloca %"compiler/eval:frame"
  %l352 = alloca { i64, ptr }
  %l355 = alloca %"compiler/eval:frame"
  %l356 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t144 = alloca %"compiler/eval:frame", align 8
  %t606 = alloca %"compiler/eval:frame", align 8
  %t618 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 11
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sge i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l49, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 1
  %t17 = load i32, ptr %t16, !range !{i32 0, i32 2}
  %t19 = trunc i64 0 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t22 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDepth, !tbaa !27
  store { i64, ptr } %t22, ptr %l53, !tbaa !27
  br label %bb5
bb4:
  %t24 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyRunDepth, !tbaa !27
  store { i64, ptr } %t24, ptr %l53, !tbaa !27
  br label %bb5
bb5:
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = load ptr, ptr %l49, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t26, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 27
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l58, !tbaa !27
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/eval:cfn", ptr %t37, i64 %t34
  %t39 = getelementptr %"compiler/eval:cfn", ptr %t38, i32 0, i32 17
  %t40 = load i1, ptr %t39, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 12
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l62, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 1
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 2}
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb9:
  br label %bb21
bb10:
  store i64 2000, ptr %l66, !tbaa !24
  br label %bb12
bb11:
  store i64 100000, ptr %l66, !tbaa !24
  br label %bb12
bb12:
  %t54 = load i64, ptr %l62, !tbaa !24
  %t55 = load i64, ptr %l66, !tbaa !24
  %t56 = icmp sge i64 %t54, %t55
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estopAtComparison(ptr %v0, ptr %t58)
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l69, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 2}
  %t66 = trunc i64 0 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb16, label %bb17
bb16:
  %t69 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyEqDepth, !tbaa !27
  store { i64, ptr } %t69, ptr %l73, !tbaa !27
  br label %bb18
bb17:
  %t71 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyRunEqDepth, !tbaa !27
  store { i64, ptr } %t71, ptr %l73, !tbaa !27
  br label %bb18
bb18:
  %t73 = load ptr, ptr @__olang_prog_scope
  %t74 = load ptr, ptr %l69, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l73, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t73, ptr %t74, { i64, ptr } %t75)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l77, !tbaa !29
  %t78 = load ptr, ptr %l77, !tbaa !29
  %t79 = getelementptr %"compiler/eval:Machine", ptr %t78, i32 0, i32 12
  %t80 = load i64, ptr %t79, !tbaa !24
  %t83 = add i64 %t80, 1
  %t85 = load ptr, ptr %l77, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t85, i32 0, i32 12
  store i64 %t83, ptr %t86, !tbaa !24
  br label %bb21
bb21:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 27
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l82, !tbaa !27
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/eval:cfn", ptr %t94, i64 %t91
  %t96 = getelementptr %"compiler/eval:cfn", ptr %t95, i32 0, i32 16
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/eval:Machine", ptr %t99, i32 0, i32 24
  store i1 true, ptr %t101, !tbaa !21
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/eval:Machine", ptr %t102, i32 0, i32 27
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l87, !tbaa !27
  %t106 = load i64, ptr %l1, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/eval:cfn", ptr %t109, i64 %t106
  %t111 = getelementptr %"compiler/eval:cfn", ptr %t110, i32 0, i32 1
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l4, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l5, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/eval:Machine", ptr %t118, i32 0, i32 27
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l93, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/eval:cfn", ptr %t125, i64 %t122
  %t127 = getelementptr %"compiler/eval:cfn", ptr %t126, i32 0, i32 2
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  store i64 %t130, ptr %l6, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/eval:Machine", ptr %t132, i32 0, i32 27
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l98, !tbaa !27
  %t136 = load i64, ptr %l1, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/eval:cfn", ptr %t139, i64 %t136
  %t141 = getelementptr %"compiler/eval:cfn", ptr %t140, i32 0, i32 15
  %t142 = load i64, ptr %t141, !tbaa !24
  store i64 %t142, ptr %l7, !tbaa !24
  call void @compiler_2feval_3aframe_2ector(ptr %t144, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l101, ptr %t144, i64 136, i1 false)
  br label %bb25
bb25:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l101, i64 136, i1 false)
  %t145 = load i64, ptr %l1, !tbaa !24
  %t153 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 0
  store i64 %t145, ptr %t153, !tbaa !24
  %t156 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 7
  store i64 %a2, ptr %t156, !tbaa !24
  %t159 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 8
  store i64 %a3, ptr %t159, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/eval:Machine", ptr %t160, i32 0, i32 62
  %t163 = load i64, ptr %t162, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/eval:Machine", ptr %t165, i32 0, i32 62
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = load i64, ptr %l5, !tbaa !24
  %t172 = add i64 %t168, %t169
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/eval:Machine", ptr %t174, i32 0, i32 62
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load i64, ptr %l5, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t189 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 3
  store i64 %t163, ptr %t189, !tbaa !24
  %t192 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 4
  store i64 %t172, ptr %t192, !tbaa !24
  %t195 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 5
  store i64 %t185, ptr %t195, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 63
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l125
  br label %bb26
bb26:
  %t201 = load i64, ptr %l125, !tbaa !24
  %t202 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 9
  store i64 %t201, ptr %t202, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr @G_2ecompiler_2feval_2esStore, !tbaa !24
  %t207 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t203, i64 %t204)
  store i64 %t207, ptr %l128
  br label %bb27
bb27:
  %t208 = load i64, ptr %l128, !tbaa !24
  %t209 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 6
  store i64 %t208, ptr %t209, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/eval:Machine", ptr %t210, i32 0, i32 62
  %t213 = load i64, ptr %t212, !tbaa !24
  %t214 = load i64, ptr %l5, !tbaa !24
  %t217 = add i64 %t213, %t214
  %t218 = load i64, ptr %l6, !tbaa !24
  %t221 = add i64 %t217, %t218
  %t222 = load i64, ptr %l7, !tbaa !24
  %t225 = add i64 %t221, %t222
  store i64 %t225, ptr %l15, !tbaa !24
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/eval:Machine", ptr %t228, i32 0, i32 61
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t236 = icmp sgt i64 %t227, %t233
  br i1 %t236, label %bb28, label %bb29
bb28:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/eval:Machine", ptr %t238, i32 0, i32 61
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t243, 0
  store i64 %t245, ptr %l17, !tbaa !24
  br label %bb30
bb29:
  br label %bb56
bb30:
  %t247 = load i64, ptr %l17, !tbaa !24
  %t248 = load i64, ptr %l15, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t255 = load i64, ptr %l17, !tbaa !24
  %t258 = mul i64 %t255, 2
  store i64 %t258, ptr %l17, !tbaa !24
  br label %bb34
bb34:
  br label %bb30
bb35:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l153, !tbaa !29
  %t261 = call ptr @__olang_scope_hold(ptr %v0)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l154, !tbaa !24
  %t263 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e61
  br i1 %t263, label %bb36, label %bb37
bb36:
  %t265 = call ptr @__olang_region_make(ptr %v0)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l154, !tbaa !24
  br label %bb37
bb37:
  %t267 = load i64, ptr %l17, !tbaa !24
  store i64 %t267, ptr %l156, !tbaa !24
  %t268 = load i64, ptr %l156, !tbaa !24
  %t269 = icmp sge i64 %t268, 0
  br i1 %t269, label %bb38, label %bb39
bb38:
  %t271 = load i64, ptr %l156, !tbaa !24
  %t272 = icmp sle i64 %t271, 1152921504606846975
  br i1 %t272, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d3c8ecceb8a6d93b_6543c983ba03c11f)
  unreachable
bb40:
  %t274 = load i64, ptr %l156, !tbaa !24
  %t275 = mul i64 %t274, 8
  %t276 = load i64, ptr %l154
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = call ptr @__olang_scope_alloc_zeroed(ptr %t277, i64 %t275)
  %t279 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t281 = load ptr, ptr %l153, !tbaa !29
  %t282 = getelementptr %"compiler/eval:Machine", ptr %t281, i32 0, i32 61
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  store { i64, ptr } %t283, ptr %l160, !tbaa !27
  %t285 = load ptr, ptr %l153, !tbaa !29
  %t286 = getelementptr %"compiler/eval:Machine", ptr %t285, i32 0, i32 61
  store { i64, ptr } %t280, ptr %t286, !tbaa !27
  %t287 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e61
  br i1 %t287, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_d3c8ecceb8a6d93b_6543c983ba03c11f)
  unreachable
bb42:
  %t289 = load { i64, ptr }, ptr %l160
  %t290 = extractvalue { i64, ptr } %t289, 1
  call void @__olang_region_release(ptr %t290)
  store { i64, ptr } zeroinitializer, ptr %l160
  br label %bb43
bb43:
  store i64 0, ptr %l18, !tbaa !24
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/eval:Machine", ptr %t291, i32 0, i32 62
  %t294 = load i64, ptr %t293, !tbaa !24
  store i64 %t294, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t296 = load i64, ptr %l19, !tbaa !24
  %t297 = load i64, ptr %l18, !tbaa !24
  %t300 = icmp sgt i64 %t296, %t297
  br i1 %t300, label %bb44, label %bb45
bb44:
  %t302 = load i64, ptr %l20, !tbaa !24
  %t304 = icmp sgt i64 %t302, 0
  br i1 %t304, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb49
bb46:
  %t306 = load i64, ptr %l19, !tbaa !24
  %t307 = load i64, ptr %l18, !tbaa !24
  %t310 = sub i64 %t306, %t307
  %t311 = load i64, ptr %l20, !tbaa !24
  %t314 = add i64 %t310, %t311
  %t316 = sub i64 %t314, 1
  %t317 = load i64, ptr %l20, !tbaa !24
  %t320 = sdiv i64 %t316, %t317
  store i64 %t320, ptr %l170, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l170, !tbaa !24
  br label %bb48
bb48:
  %t322 = load i64, ptr %l170, !tbaa !24
  store i64 %t322, ptr %l167, !tbaa !24
  br label %bb49
bb49:
  %t323 = load i64, ptr %l167, !tbaa !24
  store i64 %t323, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t324 = load i64, ptr %l21, !tbaa !24
  %t325 = sub i64 %t324, 1
  store i64 %t325, ptr %l179, !tbaa !24
  %t326 = load i64, ptr %l21, !tbaa !24
  %t327 = icmp slt i64 %t326, 2147483648
  %t328 = load i64, ptr %l22, !tbaa !24
  %t329 = icmp sge i64 %t328, 0
  %t332 = and i1 %t327, %t329
  store i1 %t332, ptr %l182, !tbaa !21
  br label %bb50
bb50:
  %t333 = load i64, ptr %l22, !tbaa !24
  %t334 = load i64, ptr %l21, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb51, label %bb52
bb51:
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t341 = load i64, ptr %l18, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t343 = load i64, ptr %l20, !tbaa !24
  %t346 = mul i64 %t342, %t343
  %t349 = add i64 %t341, %t346
  store i64 %t349, ptr %l23, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/eval:Machine", ptr %t351, i32 0, i32 61
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  store { i64, ptr } %t354, ptr %l193, !tbaa !27
  %t355 = load i64, ptr %l23, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t356, ptr %l195, !tbaa !27
  %t357 = load i64, ptr %l23, !tbaa !24
  %t359 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = getelementptr i64, ptr %t360, i64 %t357
  %t362 = load i64, ptr %t361, !tbaa !34
  %t365 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr i64, ptr %t366, i64 %t355
  store i64 %t362, ptr %t367, !tbaa !34
  br label %bb54
bb54:
  %t368 = load i64, ptr %l22, !tbaa !24
  %t371 = add i64 %t368, 1
  store i64 %t371, ptr %l22, !tbaa !24
  br label %bb50
bb55:
  br label %bb56
bb56:
  store i64 0, ptr %l24, !tbaa !24
  %t373 = load i64, ptr %l5, !tbaa !24
  store i64 %t373, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t375 = load i64, ptr %l25, !tbaa !24
  %t376 = load i64, ptr %l24, !tbaa !24
  %t379 = icmp sgt i64 %t375, %t376
  br i1 %t379, label %bb57, label %bb58
bb57:
  %t381 = load i64, ptr %l26, !tbaa !24
  %t383 = icmp sgt i64 %t381, 0
  br i1 %t383, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb62
bb59:
  %t385 = load i64, ptr %l25, !tbaa !24
  %t386 = load i64, ptr %l24, !tbaa !24
  %t389 = sub i64 %t385, %t386
  %t390 = load i64, ptr %l26, !tbaa !24
  %t393 = add i64 %t389, %t390
  %t395 = sub i64 %t393, 1
  %t396 = load i64, ptr %l26, !tbaa !24
  %t399 = sdiv i64 %t395, %t396
  store i64 %t399, ptr %l208, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb61
bb61:
  %t401 = load i64, ptr %l208, !tbaa !24
  store i64 %t401, ptr %l205, !tbaa !24
  br label %bb62
bb62:
  %t402 = load i64, ptr %l205, !tbaa !24
  store i64 %t402, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb63
bb63:
  %t403 = load i64, ptr %l28, !tbaa !24
  %t404 = load i64, ptr %l27, !tbaa !24
  %t407 = icmp slt i64 %t403, %t404
  %t409 = xor i1 %t407, true
  br i1 %t409, label %bb64, label %bb65
bb64:
  br label %bb73
bb65:
  br label %bb66
bb66:
  %t411 = load i64, ptr %l24, !tbaa !24
  %t412 = load i64, ptr %l28, !tbaa !24
  %t413 = load i64, ptr %l26, !tbaa !24
  %t416 = mul i64 %t412, %t413
  %t419 = add i64 %t411, %t416
  store i64 %t419, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t421 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t421, ptr %l226, !tbaa !27
  %t422 = load i64, ptr %l29, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr %"compiler/mir:Local", ptr %t425, i64 %t422
  %t427 = getelementptr %"compiler/mir:Local", ptr %t426, i32 0, i32 4
  %t428 = load { i64, [1 x i64] }, ptr %t427
  %t430 = extractvalue { i64, [1 x i64] } %t428, 0
  %t431 = icmp eq i64 %t430, 3
  br i1 %t431, label %bb67, label %bb68
bb67:
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l230, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t435, ptr %l232, !tbaa !27
  %t436 = load i64, ptr %l29, !tbaa !24
  %t438 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr %"compiler/mir:Local", ptr %t439, i64 %t436
  %t441 = getelementptr %"compiler/mir:Local", ptr %t440, i32 0, i32 2
  %t442 = load i32, ptr %t441, !tbaa !23
  %t445 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t434, i32 %t442)
  store i64 %t445, ptr %l235
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t446 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t447 = getelementptr %"compiler/eval:frame", ptr %l8, i32 0, i32 6
  %t448 = load i64, ptr %t447, !tbaa !24
  %t449 = load ptr, ptr %l230, !tbaa !29
  %t450 = load i64, ptr %l235, !tbaa !24
  %t453 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t449, i64 %t450, i64 %t446, i64 %t448)
  store %"compiler/eval:Ptr" %t453, ptr %l238
  br label %bb70
bb70:
  %t454 = getelementptr %"compiler/eval:Ptr", ptr %l238, i32 0, i32 0
  %t455 = load i64, ptr %t454, !tbaa !24
  store i64 %t455, ptr %l30, !tbaa !24
  br label %bb71
bb71:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/eval:Machine", ptr %t457, i32 0, i32 61
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  store { i64, ptr } %t460, ptr %l241, !tbaa !27
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/eval:Machine", ptr %t461, i32 0, i32 62
  %t464 = load i64, ptr %t463, !tbaa !24
  %t465 = load i64, ptr %l29, !tbaa !24
  %t468 = add i64 %t464, %t465
  %t469 = load i64, ptr %l30, !tbaa !24
  %t472 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr i64, ptr %t473, i64 %t468
  store i64 %t469, ptr %t474, !tbaa !34
  br label %bb72
bb72:
  %t475 = load i64, ptr %l28, !tbaa !24
  %t478 = add i64 %t475, 1
  store i64 %t478, ptr %l28, !tbaa !24
  br label %bb63
bb73:
  %t480 = load i64, ptr %l5, !tbaa !24
  store i64 %t480, ptr %l31, !tbaa !24
  %t482 = load i64, ptr %l15, !tbaa !24
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/eval:Machine", ptr %t483, i32 0, i32 62
  %t486 = load i64, ptr %t485, !tbaa !24
  %t489 = sub i64 %t482, %t486
  store i64 %t489, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t491 = load i64, ptr %l32, !tbaa !24
  %t492 = load i64, ptr %l31, !tbaa !24
  %t495 = icmp sgt i64 %t491, %t492
  br i1 %t495, label %bb74, label %bb75
bb74:
  %t497 = load i64, ptr %l33, !tbaa !24
  %t499 = icmp sgt i64 %t497, 0
  br i1 %t499, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l258, !tbaa !24
  br label %bb79
bb76:
  %t501 = load i64, ptr %l32, !tbaa !24
  %t502 = load i64, ptr %l31, !tbaa !24
  %t505 = sub i64 %t501, %t502
  %t506 = load i64, ptr %l33, !tbaa !24
  %t509 = add i64 %t505, %t506
  %t511 = sub i64 %t509, 1
  %t512 = load i64, ptr %l33, !tbaa !24
  %t515 = sdiv i64 %t511, %t512
  store i64 %t515, ptr %l261, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb78
bb78:
  %t517 = load i64, ptr %l261, !tbaa !24
  store i64 %t517, ptr %l258, !tbaa !24
  br label %bb79
bb79:
  %t518 = load i64, ptr %l258, !tbaa !24
  store i64 %t518, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t519 = load i64, ptr %l34, !tbaa !24
  %t520 = sub i64 %t519, 1
  store i64 %t520, ptr %l270, !tbaa !24
  %t521 = load i64, ptr %l34, !tbaa !24
  %t522 = icmp slt i64 %t521, 2147483648
  %t523 = load i64, ptr %l35, !tbaa !24
  %t524 = icmp sge i64 %t523, 0
  %t527 = and i1 %t522, %t524
  store i1 %t527, ptr %l273, !tbaa !21
  br label %bb80
bb80:
  %t528 = load i64, ptr %l35, !tbaa !24
  %t529 = load i64, ptr %l34, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t536 = load i64, ptr %l31, !tbaa !24
  %t537 = load i64, ptr %l35, !tbaa !24
  %t538 = load i64, ptr %l33, !tbaa !24
  %t541 = mul i64 %t537, %t538
  %t544 = add i64 %t536, %t541
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t548 = getelementptr %"compiler/eval:Machine", ptr %t546, i32 0, i32 61
  %t549 = load { i64, ptr }, ptr %t548, !tbaa !27
  store { i64, ptr } %t549, ptr %l284, !tbaa !27
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/eval:Machine", ptr %t550, i32 0, i32 62
  %t553 = load i64, ptr %t552, !tbaa !24
  %t557 = add i64 %t553, %t544
  %t559 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = getelementptr i64, ptr %t560, i64 %t557
  store i64 0, ptr %t561, !tbaa !34
  br label %bb84
bb84:
  %t562 = load i64, ptr %l35, !tbaa !24
  %t565 = add i64 %t562, 1
  store i64 %t565, ptr %l35, !tbaa !24
  br label %bb80
bb85:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i64, ptr %l15, !tbaa !24
  %t571 = getelementptr %"compiler/eval:Machine", ptr %t567, i32 0, i32 62
  store i64 %t568, ptr %t571, !tbaa !24
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/eval:Machine", ptr %t572, i32 0, i32 60
  %t575 = load i64, ptr %t574, !tbaa !24
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/eval:Machine", ptr %t576, i32 0, i32 59
  %t579 = load { i64, ptr }, ptr %t578, !tbaa !27
  %t581 = extractvalue { i64, ptr } %t579, 0
  %t584 = icmp sge i64 %t575, %t581
  br i1 %t584, label %bb86, label %bb87
bb86:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/eval:Machine", ptr %t586, i32 0, i32 59
  %t589 = load { i64, ptr }, ptr %t588, !tbaa !27
  store { i64, ptr } %t589, ptr %l37, !tbaa !27
  %t591 = load ptr, ptr %l0, !tbaa !29
  store ptr %t591, ptr %l302, !tbaa !29
  %t592 = call ptr @__olang_scope_hold(ptr %v0)
  %t593 = ptrtoint ptr %t592 to i64
  store i64 %t593, ptr %l303, !tbaa !24
  %t594 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e59
  br i1 %t594, label %bb88, label %bb89
bb87:
  br label %bb111
bb88:
  %t596 = call ptr @__olang_region_make(ptr %v0)
  %t597 = ptrtoint ptr %t596 to i64
  store i64 %t597, ptr %l303, !tbaa !24
  br label %bb89
bb89:
  %t598 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t602 = mul i64 2, %t600
  store i64 %t602, ptr %l307, !tbaa !24
  call void @llvm.memset.p0.i64(ptr %l308, i8 0, i64 136, i1 false)
  %t603 = load i64, ptr %l307, !tbaa !24
  %t604 = icmp sgt i64 %t603, 0
  br i1 %t604, label %bb90, label %bb91
bb90:
  call void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2feval_3aframe(ptr %t606)
  call void @llvm.memmove.p0.p0.i64(ptr %l310, ptr %t606, i64 136, i1 false)
  br label %bb92
bb91:
  %t607 = load i64, ptr %l307, !tbaa !24
  %t608 = icmp sge i64 %t607, 0
  br i1 %t608, label %bb93, label %bb94
bb92:
  call void @llvm.memmove.p0.p0.i64(ptr %l308, ptr %l310, i64 136, i1 false)
  br label %bb91
bb93:
  %t610 = load i64, ptr %l307, !tbaa !24
  %t611 = icmp sle i64 %t610, 67818912035696880
  br i1 %t611, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_d67750d3ea89b5a6_4cf132db9678b04a)
  unreachable
bb95:
  %t613 = load i64, ptr %l307, !tbaa !24
  %t614 = mul i64 %t613, 136
  %t615 = load i64, ptr %l303
  %t616 = inttoptr i64 %t615 to ptr
  %t617 = call ptr @__olang_held_alloc(ptr %t616, i64 %t614)
  store i64 0, ptr %t618
  br label %fill.619
fill.619:
  %t622 = load i64, ptr %t618
  %t623 = icmp slt i64 %t622, %t613
  br i1 %t623, label %fillb.620, label %filld.621
fillb.620:
  %t624 = getelementptr %"compiler/eval:frame", ptr %t617, i64 %t622
  call void @llvm.memmove.p0.p0.i64(ptr %t624, ptr %l308, i64 136, i1 false)
  %t625 = add i64 %t622, 1
  store i64 %t625, ptr %t618
  br label %fill.619
filld.621:
  %t626 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t627 = insertvalue { i64, ptr } %t626, ptr %t617, 1
  %t628 = load ptr, ptr %l302, !tbaa !29
  %t629 = getelementptr %"compiler/eval:Machine", ptr %t628, i32 0, i32 59
  %t630 = load { i64, ptr }, ptr %t629, !tbaa !27
  store { i64, ptr } %t630, ptr %l314, !tbaa !27
  %t632 = load ptr, ptr %l302, !tbaa !29
  %t633 = getelementptr %"compiler/eval:Machine", ptr %t632, i32 0, i32 59
  store { i64, ptr } %t627, ptr %t633, !tbaa !27
  %t634 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e59
  br i1 %t634, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_d67750d3ea89b5a6_4cf132db9678b04a)
  unreachable
bb97:
  %t636 = load { i64, ptr }, ptr %l314
  %t637 = extractvalue { i64, ptr } %t636, 1
  call void @__olang_region_release(ptr %t637)
  store { i64, ptr } zeroinitializer, ptr %l314
  br label %bb98
bb98:
  store i64 0, ptr %l38, !tbaa !24
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/eval:Machine", ptr %t638, i32 0, i32 60
  %t641 = load i64, ptr %t640, !tbaa !24
  store i64 %t641, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t643 = load i64, ptr %l39, !tbaa !24
  %t644 = load i64, ptr %l38, !tbaa !24
  %t647 = icmp sgt i64 %t643, %t644
  br i1 %t647, label %bb99, label %bb100
bb99:
  %t649 = load i64, ptr %l40, !tbaa !24
  %t651 = icmp sgt i64 %t649, 0
  br i1 %t651, label %bb101, label %bb102
bb100:
  store i64 0, ptr %l321, !tbaa !24
  br label %bb104
bb101:
  %t653 = load i64, ptr %l39, !tbaa !24
  %t654 = load i64, ptr %l38, !tbaa !24
  %t657 = sub i64 %t653, %t654
  %t658 = load i64, ptr %l40, !tbaa !24
  %t661 = add i64 %t657, %t658
  %t663 = sub i64 %t661, 1
  %t664 = load i64, ptr %l40, !tbaa !24
  %t667 = sdiv i64 %t663, %t664
  store i64 %t667, ptr %l324, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l324, !tbaa !24
  br label %bb103
bb103:
  %t669 = load i64, ptr %l324, !tbaa !24
  store i64 %t669, ptr %l321, !tbaa !24
  br label %bb104
bb104:
  %t670 = load i64, ptr %l321, !tbaa !24
  store i64 %t670, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb105
bb105:
  %t671 = load i64, ptr %l42, !tbaa !24
  %t672 = load i64, ptr %l41, !tbaa !24
  %t675 = icmp slt i64 %t671, %t672
  %t677 = xor i1 %t675, true
  br i1 %t677, label %bb106, label %bb107
bb106:
  br label %bb110
bb107:
  br label %bb108
bb108:
  %t679 = load i64, ptr %l38, !tbaa !24
  %t680 = load i64, ptr %l42, !tbaa !24
  %t681 = load i64, ptr %l40, !tbaa !24
  %t684 = mul i64 %t680, %t681
  %t687 = add i64 %t679, %t684
  store i64 %t687, ptr %l43, !tbaa !24
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t691 = getelementptr %"compiler/eval:Machine", ptr %t689, i32 0, i32 59
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  store { i64, ptr } %t692, ptr %l343, !tbaa !27
  %t693 = load i64, ptr %l43, !tbaa !24
  %t694 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t694, ptr %l345, !tbaa !27
  %t695 = load i64, ptr %l43, !tbaa !24
  %t697 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !27
  %t699 = getelementptr %"compiler/eval:frame", ptr %t698, i64 %t695
  call void @llvm.memmove.p0.p0.i64(ptr %l347, ptr %t699, i64 136, i1 false)
  %t701 = getelementptr { i64, ptr }, ptr %l343, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !27
  %t703 = getelementptr %"compiler/eval:frame", ptr %t702, i64 %t693
  call void @llvm.memmove.p0.p0.i64(ptr %t703, ptr %l347, i64 136, i1 false)
  br label %bb109
bb109:
  %t704 = load i64, ptr %l42, !tbaa !24
  %t707 = add i64 %t704, 1
  store i64 %t707, ptr %l42, !tbaa !24
  br label %bb105
bb110:
  br label %bb111
bb111:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t711 = getelementptr %"compiler/eval:Machine", ptr %t709, i32 0, i32 59
  %t712 = load { i64, ptr }, ptr %t711, !tbaa !27
  store { i64, ptr } %t712, ptr %l352, !tbaa !27
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr %"compiler/eval:Machine", ptr %t713, i32 0, i32 60
  %t716 = load i64, ptr %t715, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l355, ptr %l8, i64 136, i1 false)
  %t718 = getelementptr { i64, ptr }, ptr %l352, i32 0, i32 1
  %t719 = load ptr, ptr %t718, !tbaa !27
  %t720 = getelementptr %"compiler/eval:frame", ptr %t719, i64 %t716
  call void @llvm.memmove.p0.p0.i64(ptr %t720, ptr %l355, i64 136, i1 false)
  %t721 = load ptr, ptr %l0, !tbaa !29
  store ptr %t721, ptr %l356, !tbaa !29
  %t722 = load ptr, ptr %l356, !tbaa !29
  %t723 = getelementptr %"compiler/eval:Machine", ptr %t722, i32 0, i32 60
  %t724 = load i64, ptr %t723, !tbaa !24
  %t727 = add i64 %t724, 1
  %t729 = load ptr, ptr %l356, !tbaa !29
  %t730 = getelementptr %"compiler/eval:Machine", ptr %t729, i32 0, i32 60
  store i64 %t727, ptr %t730, !tbaa !24
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t733 = getelementptr %"compiler/eval:Machine", ptr %t731, i32 0, i32 60
  %t734 = load i64, ptr %t733, !tbaa !24
  %t736 = sub i64 %t734, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t736, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { %"compiler/eval:Ptr", i64 }
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca %"compiler/eval:Ptr"
  %l27 = alloca { %"compiler/eval:Ptr", i64 }
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca ptr
  %l86 = alloca %"compiler/eval:Ptr"
  %l87 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3)
  store i32 %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load i32, ptr %l20, !tbaa !23
  store i32 %t8, ptr %l5, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l21, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load { i64, [4 x i64] }, ptr %l2
  %t16 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t10, i64 %t11, { i64, [4 x i64] } %t12, i64 1)
  store %"compiler/eval:Ptr" %t16, ptr %l25
  br label %bb2
bb2:
  %t17 = load i32, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l21, !tbaa !29
  %t19 = load %"compiler/eval:Ptr", ptr %l25
  %t21 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t18, %"compiler/eval:Ptr" %t19, i32 %t17)
  store { %"compiler/eval:Ptr", i64 } %t21, ptr %l27
  br label %bb3
bb3:
  %t22 = load { %"compiler/eval:Ptr", i64 }, ptr %l27
  store { %"compiler/eval:Ptr", i64 } %t22, ptr %l6
  %t23 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l6, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  store %"compiler/eval:Ptr" %t24, ptr %l7
  %t26 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l6, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 23
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 50
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  %t38 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t43 = and i64 %t39, %t40
  %t45 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/eval:alloc", ptr %t46, i64 %t43
  %t48 = getelementptr %"compiler/eval:alloc", ptr %t47, i32 0, i32 13
  %t49 = load i1, ptr %t48, !tbaa !21
  store i1 %t49, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t51 = load i1, ptr %l32, !tbaa !21
  br i1 %t51, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l39, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l40, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l5, !tbaa !23
  %t58 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l43
  br label %bb10
bb10:
  %t59 = load ptr, ptr %l40, !tbaa !29
  %t60 = load i32, ptr %l43, !tbaa !23
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t61, ptr %l44
  br label %bb11
bb11:
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = load i64, ptr %l44, !tbaa !24
  %t64 = mul i64 %t62, %t63
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l4, !tbaa !24
  store i64 %t76, ptr %l10, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  br i1 %t82, label %bb15, label %bb16
bb15:
  %t84 = load i64, ptr %l9, !tbaa !24
  store i64 %t84, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  store i64 %t86, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load i64, ptr %l13, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb23
bb20:
  %t98 = load i64, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l63, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb22
bb22:
  %t114 = load i64, ptr %l63, !tbaa !24
  store i64 %t114, ptr %l60, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l60, !tbaa !24
  store i64 %t115, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l15, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l16, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t145 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t136, i64 %t142)
  store %"compiler/eval:Ptr" %t145, ptr %l86
  br label %bb28
bb28:
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t146, ptr %l87, !tbaa !27
  %t147 = load i64, ptr %l16, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t147
  %t152 = load i8, ptr %t151, !tbaa !32
  %t154 = zext i8 %t152 to i64
  %t155 = load ptr, ptr %l81, !tbaa !29
  %t156 = load %"compiler/eval:Ptr", ptr %l86
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t155, %"compiler/eval:Ptr" %t156, i64 1, i64 %t154)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l15, !tbaa !24
  br label %bb24
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereleaseHeld(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i32
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca ptr
  %l27 = alloca %"compiler/eval:Ptr"
  %l28 = alloca i64
  %l32 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca %"compiler/eval:Ptr"
  %l40 = alloca i64
  %l44 = alloca i1
  %l50 = alloca %"compiler/eval:scope"
  %l54 = alloca i1
  %l57 = alloca i1
  %t83 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l3, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load %"compiler/eval:Ptr", ptr %l1
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t3, %"compiler/eval:Ptr" %t4, i64 8)
  store i64 %t7, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp eq i64 %t8, 0
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l8, !tbaa !21
  store i1 %t11, ptr %l5, !tbaa !21
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb5
bb5:
  %t20 = load i1, ptr %l16, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l21, !tbaa !21
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/eval:Ptr", ptr %l1
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %t32, %"compiler/eval:Ptr" %t33, i32 %t34)
  store %"compiler/eval:Ptr" %t38, ptr %l27
  br label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l1
  %t41 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eanchorRegion(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40, i32 %t41)
  store i64 %t45, ptr %l32
  br label %bb14
bb12:
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load %"compiler/eval:Ptr", ptr %l27
  %t48 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %t46, %"compiler/eval:Ptr" %t47)
  store i64 %t48, ptr %l28
  br label %bb13
bb13:
  %t49 = load i64, ptr %l28, !tbaa !24
  store i64 %t49, ptr %l22, !tbaa !24
  br label %bb15
bb14:
  %t50 = load i64, ptr %l32, !tbaa !24
  store i64 %t50, ptr %l22, !tbaa !24
  br label %bb15
bb15:
  %t51 = load i64, ptr %l22, !tbaa !24
  store i64 %t51, ptr %l6, !tbaa !24
  %t52 = load i1, ptr %l5, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 23
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l36, !tbaa !29
  %t60 = load %"compiler/eval:Ptr", ptr %l1
  store %"compiler/eval:Ptr" %t60, ptr %l37
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l40
  br label %bb22
bb22:
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = load %"compiler/eval:Ptr", ptr %l37
  %t68 = load i64, ptr %l40, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t66, %"compiler/eval:Ptr" %t67, i64 %t68)
  br label %bb23
bb23:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t73 = load i1, ptr %l3, !tbaa !21
  br i1 %t73, label %bb27, label %bb28
bb27:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/eval:Machine", ptr %t75, i32 0, i32 53
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t82 = and i64 %t78, %t79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t83, ptr %v0, ptr %t77, i64 %t82)
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t83, i64 152, i1 false)
  br label %bb29
bb28:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb30
bb29:
  %t86 = getelementptr %"compiler/eval:scope", ptr %l50, i32 0, i32 19
  %t87 = load i1, ptr %t86, !tbaa !21
  %t89 = xor i1 %t87, true
  store i1 %t89, ptr %l44, !tbaa !21
  br label %bb30
bb30:
  %t91 = load i1, ptr %l44, !tbaa !21
  br i1 %t91, label %bb31, label %bb32
bb31:
  br label %ret
bb32:
  br label %bb33
bb33:
  br i1 %a4, label %bb34, label %bb35
bb34:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eslotRegion(ptr %v0, ptr %t94, i64 %t95)
  store i1 %t98, ptr %l57
  br label %bb36
bb35:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb37
bb36:
  %t99 = load i1, ptr %l57, !tbaa !21
  %t100 = xor i1 %t99, true
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb37
bb37:
  %t102 = load i1, ptr %l54, !tbaa !21
  br i1 %t102, label %bb38, label %bb39
bb38:
  br label %ret
bb39:
  br label %bb40
bb40:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %t103, i64 %t104)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eretire(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca { %"compiler/eval:Ptr", i64 }
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, [8 x i64] }
  %l13 = alloca i32
  %l19 = alloca { %"compiler/eval:Ptr", i64 }
  %l23 = alloca i1
  %l33 = alloca i1
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca i1
  %l79 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca %"compiler/mir:BasicBlock"
  %l101 = alloca ptr
  %l104 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a2, i32 %a3)
  store { %"compiler/eval:Ptr", i64 } %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i64 }, ptr %l19
  store { %"compiler/eval:Ptr", i64 } %t8, ptr %l4
  %t9 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l5
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 23
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb4
bb3:
  %t17 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l23, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t28 = and i64 %t24, %t25
  store i64 %t28, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 51
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = icmp sge i64 %t30, %t34
  br i1 %t37, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb10
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 50
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l35, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/eval:alloc", ptr %t46, i64 %t43
  %t48 = getelementptr %"compiler/eval:alloc", ptr %t47, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t53 = icmp eq i64 %t49, %t50
  store i1 %t53, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 50
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l42, !tbaa !27
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/eval:alloc", ptr %t63, i64 %t60
  %t65 = getelementptr %"compiler/eval:alloc", ptr %t64, i32 0, i32 9
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = icmp sge i64 %t66, 0
  store i1 %t68, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t70 = load i1, ptr %l40, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 78
  %t74 = load i64, ptr %t73, !tbaa !24
  store i64 %t74, ptr %l7, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 79
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l8
  %t81 = load i64, ptr %l1, !tbaa !24
  store i64 %t81, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sge i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 82
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 26
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/eval:Machine", ptr %t93, i32 0, i32 59
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l59, !tbaa !27
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/eval:frame", ptr %t100, i64 %t97
  %t102 = getelementptr %"compiler/eval:frame", ptr %t101, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %s3, ptr %t92, i64 %t103)
  store ptr %t106, ptr %l62
  br label %bb20
bb19:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb22
bb20:
  %t107 = load ptr, ptr %l62, !tbaa !29
  %t109 = getelementptr %"compiler/mir:Fn", ptr %t107, i32 0, i32 2
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t113 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t111, i64 %t110)
  store i1 %t113, ptr %l65
  br label %bb21
bb21:
  %t114 = load i1, ptr %l65, !tbaa !21
  store i1 %t114, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t115 = load i1, ptr %l53, !tbaa !21
  %t116 = xor i1 %t115, true
  br i1 %t116, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = sub i64 %t118, 1
  store i64 %t121, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  br label %bb17
bb27:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb28, label %bb29
bb28:
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load i64, ptr %l1, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  store i1 %t131, ptr %l72, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l72, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/eval:Machine", ptr %t134, i32 0, i32 26
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/eval:Machine", ptr %t137, i32 0, i32 59
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l79, !tbaa !27
  %t141 = load i64, ptr %l9, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/eval:frame", ptr %t144, i64 %t141
  %t146 = getelementptr %"compiler/eval:frame", ptr %t145, i32 0, i32 0
  %t147 = load i64, ptr %t146, !tbaa !24
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t136, i64 %t147)
  store ptr %t150, ptr %l82
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t151 = load ptr, ptr %l82, !tbaa !29
  store ptr %t151, ptr %l10, !tbaa !29
  %t152 = load ptr, ptr %l10, !tbaa !29
  %t154 = getelementptr %"compiler/mir:Fn", ptr %t152, i32 0, i32 9
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 59
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l86, !tbaa !27
  %t159 = load i64, ptr %l9, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr %"compiler/eval:frame", ptr %t162, i64 %t159
  %t164 = getelementptr %"compiler/eval:frame", ptr %t163, i32 0, i32 1
  %t165 = load i64, ptr %t164, !tbaa !24
  %t168 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s4, ptr %t154, i64 %t165)
  store %"compiler/mir:BasicBlock" %t168, ptr %l89
  br label %bb34
bb34:
  %t169 = getelementptr %"compiler/mir:BasicBlock", ptr %l89, i32 0, i32 1
  %t170 = load { i64, [8 x i64] }, ptr %t169
  store { i64, [8 x i64] } %t170, ptr %l11
  %t172 = load { i64, [8 x i64] }, ptr %l11
  %t174 = extractvalue { i64, [8 x i64] } %t172, 0
  %t175 = icmp eq i64 %t174, 4
  br i1 %t175, label %bb35, label %bb36
bb35:
  %t177 = getelementptr { i64, [8 x i64] }, ptr %l11, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32 }, ptr %t177, i32 0, i32 0
  %t179 = load %"compiler/source:Span", ptr %t178
  %t181 = getelementptr { i64, [8 x i64] }, ptr %l11, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32 }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l13, !tbaa !23
  %t185 = load ptr, ptr %l10, !tbaa !29
  %t187 = getelementptr %"compiler/mir:Fn", ptr %t185, i32 0, i32 2
  %t188 = load i64, ptr %t187, !tbaa !24
  store i64 %t188, ptr %l7, !tbaa !24
  store %"compiler/source:Span" %t179, ptr %l8
  br label %bb37
bb36:
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb38:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 80
  store ptr %t198, ptr %l101, !tbaa !29
  %t199 = load i64, ptr %l7, !tbaa !24
  %t200 = load %"compiler/source:Span", ptr %l8
  %t203 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %s0, i64 %t199, %"compiler/source:Span" %t200)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t203, ptr %l104
  br label %bb39
bb39:
  %t204 = load ptr, ptr %l101, !tbaa !29
  %t205 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l104
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %t204, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t205)
  br label %bb40
bb40:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/eval:Machine", ptr %t206, i32 0, i32 50
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l106, !tbaa !27
  %t210 = load i64, ptr %l6, !tbaa !24
  store i64 %t210, ptr %l107, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/eval:Machine", ptr %t211, i32 0, i32 80
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t213)
  store i64 %t215, ptr %l110
  br label %bb41
bb41:
  %t216 = load i64, ptr %l110, !tbaa !24
  %t217 = sub i64 %t216, 1
  %t219 = load i64, ptr %l107, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr %"compiler/eval:alloc", ptr %t221, i64 %t219
  %t223 = getelementptr %"compiler/eval:alloc", ptr %t222, i32 0, i32 9
  store i64 %t217, ptr %t223, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eruntimeFn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3, i32 %a4, %"compiler/eval:Ptr" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l8 = alloca { ptr, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca [3 x i64]
  %l21 = alloca [24 x i8]
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i8
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca %"std/prelude/text:StringBuilder"
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i32
  %l68 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca i64
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i64
  %l82 = alloca { i64, [4 x i64] }
  %l83 = alloca i64
  %l86 = alloca i1
  %l87 = alloca i64
  %l90 = alloca i64
  %l95 = alloca { i64, ptr }
  %l97 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i1
  %l131 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i64
  %l141 = alloca { i64, [4 x i64] }
  %l142 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca i64
  %l146 = alloca { i64, [4 x i64] }
  %l147 = alloca i64
  %l151 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l155 = alloca { i64, [4 x i64] }
  %l156 = alloca i64
  %l159 = alloca ptr
  %l160 = alloca i64
  %l162 = alloca { i64, [4 x i64] }
  %l163 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca ptr
  %l169 = alloca i64
  %l171 = alloca { i64, [4 x i64] }
  %l176 = alloca i1
  %l181 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i64
  %l186 = alloca { i64, [4 x i64] }
  %l187 = alloca { i64, ptr }
  %l191 = alloca i32
  %l196 = alloca i64
  %l199 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i1
  %l227 = alloca i64
  %l234 = alloca ptr
  %l235 = alloca i64
  %l237 = alloca { i64, [4 x i64] }
  %l241 = alloca i1
  %l243 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca i64
  %l247 = alloca { i64, [4 x i64] }
  %l248 = alloca i64
  %l251 = alloca ptr
  %l252 = alloca i64
  %l254 = alloca { i64, [4 x i64] }
  %l255 = alloca { i64, ptr }
  %l257 = alloca i1
  %l258 = alloca i64
  %l263 = alloca i64
  %l268 = alloca i64
  %l269 = alloca ptr
  %l270 = alloca i64
  %l272 = alloca { i64, [4 x i64] }
  %l277 = alloca i1
  %l278 = alloca ptr
  %l279 = alloca i64
  %l281 = alloca { i64, [4 x i64] }
  %l282 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l284 = alloca i64
  %l286 = alloca { i64, [4 x i64] }
  %l287 = alloca i64
  %l288 = alloca ptr
  %l289 = alloca i64
  %l291 = alloca { i64, [4 x i64] }
  %l292 = alloca i64
  %l293 = alloca i32
  %l294 = alloca ptr
  %l295 = alloca i64
  %l297 = alloca { i64, [4 x i64] }
  %l298 = alloca i64
  %l299 = alloca i32
  %l300 = alloca ptr
  %l301 = alloca i64
  %l303 = alloca { i64, [4 x i64] }
  %l304 = alloca i64
  %l305 = alloca i32
  %l306 = alloca ptr
  %l307 = alloca i64
  %l309 = alloca { i64, [4 x i64] }
  %l310 = alloca { i64, ptr }
  %l311 = alloca i32
  %l314 = alloca i1
  %l315 = alloca ptr
  %l316 = alloca i64
  %l318 = alloca { i64, [4 x i64] }
  %l319 = alloca { i64, ptr }
  %l320 = alloca ptr
  %l321 = alloca i64
  %l323 = alloca { i64, [4 x i64] }
  %l324 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l326 = alloca i64
  %l328 = alloca { i64, [4 x i64] }
  %l329 = alloca i64
  %l330 = alloca ptr
  %l331 = alloca i64
  %l333 = alloca { i64, [4 x i64] }
  %l334 = alloca i64
  %l335 = alloca i32
  %l336 = alloca ptr
  %l337 = alloca i64
  %l339 = alloca { i64, [4 x i64] }
  %l340 = alloca i64
  %l341 = alloca i32
  %l342 = alloca ptr
  %l343 = alloca i64
  %l345 = alloca { i64, [4 x i64] }
  %l346 = alloca i64
  %l347 = alloca i32
  %l348 = alloca ptr
  %l349 = alloca i64
  %l351 = alloca { i64, [4 x i64] }
  %l352 = alloca { i64, ptr }
  %l353 = alloca i32
  %l356 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca i64
  %l360 = alloca { i64, [4 x i64] }
  %l361 = alloca { i64, ptr }
  %l362 = alloca ptr
  %l363 = alloca i64
  %l365 = alloca { i64, [4 x i64] }
  %l366 = alloca { i64, ptr }
  %l367 = alloca ptr
  %l368 = alloca i64
  %l370 = alloca { i64, [4 x i64] }
  %l371 = alloca i64
  %l372 = alloca i32
  %l375 = alloca i1
  %l376 = alloca ptr
  %l377 = alloca i64
  %l379 = alloca { i64, [4 x i64] }
  %l380 = alloca { i64, ptr }
  %l382 = alloca i32
  %l384 = alloca ptr
  %l385 = alloca i64
  %l387 = alloca { i64, [4 x i64] }
  %l392 = alloca i1
  %l394 = alloca i1
  %l395 = alloca ptr
  %l396 = alloca i64
  %l398 = alloca { i64, [4 x i64] }
  %l399 = alloca { i64, ptr }
  %l402 = alloca i64
  %l411 = alloca i64
  %l414 = alloca i64
  %l423 = alloca i64
  %l426 = alloca i1
  %l447 = alloca i64
  %l453 = alloca ptr
  %l454 = alloca i64
  %l456 = alloca { i64, [4 x i64] }
  %l457 = alloca { i64, ptr }
  %l458 = alloca ptr
  %l459 = alloca i64
  %l461 = alloca { i64, [4 x i64] }
  %l462 = alloca { i64, ptr }
  %l463 = alloca ptr
  %l464 = alloca i64
  %l466 = alloca { i64, [4 x i64] }
  %l467 = alloca i64
  %l470 = alloca i1
  %l471 = alloca i64
  %l472 = alloca { i64, ptr }
  %l473 = alloca { i64, ptr }
  %l474 = alloca { i64, ptr }
  %l475 = alloca i8
  %l476 = alloca ptr
  %l477 = alloca i64
  %l479 = alloca { i64, [4 x i64] }
  %l480 = alloca i64
  %l481 = alloca i64
  %l487 = alloca i64
  %l494 = alloca i64
  %l497 = alloca i64
  %l506 = alloca i64
  %l509 = alloca i1
  %l526 = alloca i64
  %l533 = alloca ptr
  %l534 = alloca i64
  %l536 = alloca { i64, [4 x i64] }
  %l541 = alloca i1
  %l542 = alloca ptr
  %l543 = alloca i64
  %l545 = alloca { i64, [4 x i64] }
  %l546 = alloca { i64, ptr }
  %l547 = alloca ptr
  %l548 = alloca i64
  %l550 = alloca { i64, [4 x i64] }
  %l551 = alloca { i64, ptr }
  %l552 = alloca ptr
  %l553 = alloca i64
  %l555 = alloca { i64, [4 x i64] }
  %l556 = alloca i64
  %l558 = alloca i32
  %l561 = alloca i1
  %l562 = alloca ptr
  %l563 = alloca i64
  %l565 = alloca { i64, [4 x i64] }
  %l566 = alloca { i64, ptr }
  %l567 = alloca ptr
  %l568 = alloca i64
  %l570 = alloca { i64, [4 x i64] }
  %l571 = alloca { i64, ptr }
  %l572 = alloca ptr
  %l573 = alloca i64
  %l575 = alloca { i64, [4 x i64] }
  %l576 = alloca i64
  %l577 = alloca i8
  %l578 = alloca ptr
  %l579 = alloca i64
  %l581 = alloca { i64, [4 x i64] }
  %l582 = alloca i64
  %l583 = alloca i32
  %l586 = alloca i1
  %l588 = alloca i1
  %l590 = alloca i1
  %l591 = alloca { i64, ptr }
  %l597 = alloca i1
  %l600 = alloca i64
  %l608 = alloca i64
  %l611 = alloca i64
  %l620 = alloca i64
  %l623 = alloca i1
  %l634 = alloca { i64, ptr }
  %l641 = alloca ptr
  %l642 = alloca i64
  %l644 = alloca { i64, [4 x i64] }
  %l645 = alloca { i64, ptr }
  %l646 = alloca ptr
  %l647 = alloca i64
  %l649 = alloca { i64, [4 x i64] }
  %l650 = alloca i64
  %l654 = alloca i1
  %l656 = alloca i1
  %l658 = alloca i1
  %l660 = alloca i1
  %l662 = alloca i1
  %l664 = alloca i1
  %l666 = alloca i1
  %l668 = alloca i1
  %l671 = alloca i1
  %l675 = alloca ptr
  %l676 = alloca i64
  %l678 = alloca { i64, [4 x i64] }
  %l679 = alloca { i64, ptr }
  %l680 = alloca ptr
  %l681 = alloca i64
  %l683 = alloca { i64, [4 x i64] }
  %l684 = alloca i64
  %l685 = alloca %"std/prelude/text:StringBuilder"
  %l690 = alloca i64
  %l693 = alloca i64
  %l721 = alloca { i64, ptr }
  %l730 = alloca i1
  %l732 = alloca i1
  %l734 = alloca i1
  %l736 = alloca i1
  %l738 = alloca i1
  %l740 = alloca ptr
  %l741 = alloca i32
  %l745 = alloca i32
  %l747 = alloca i1
  %l751 = alloca ptr
  %l752 = alloca %"compiler/eval:Ptr"
  %l755 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %rv = alloca i1
  %t11 = alloca { ptr, %"compiler/mir:Range", ptr }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l68
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l68, !tbaa !29
  %t9 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr null, i32 1
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr %t11, i32 0, i32 0
  store ptr %t6, ptr %t12, !tbaa !28
  %t14 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr %t11, i32 0, i32 1
  store %"compiler/mir:Range" %a3, ptr %t14, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t16 = call ptr @__olang_scope_hold(ptr %v0)
  %t17 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr %t11, i32 0, i32 2
  store ptr %t16, ptr %t17, !tbaa !28
  %t18 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_12, 0
  %t19 = insertvalue { ptr, ptr } %t18, ptr %t11, 1
  store { ptr, ptr } %t19, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t23, ptr %l73
  br label %bb2
bb2:
  %t24 = load i1, ptr %l73, !tbaa !21
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 83
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l76
  br label %bb6
bb6:
  %t30 = load i64, ptr %l76, !tbaa !24
  store i64 %t30, ptr %l9, !tbaa !24
  br label %bb348
bb7:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t33, ptr %l78
  br label %bb8
bb8:
  %t34 = load i1, ptr %l78, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb40
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l79, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  store i64 %t36, ptr %l80, !tbaa !24
  %t37 = load { ptr, ptr }, ptr %l8
  %t39 = extractvalue { ptr, ptr } %t37, 0
  %t40 = extractvalue { ptr, ptr } %t37, 1
  %t41 = call { i64, [4 x i64] } %t39(ptr %t40, i64 0)
  store { i64, [4 x i64] } %t41, ptr %l82
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l79, !tbaa !29
  %t43 = load i64, ptr %l80, !tbaa !24
  %t44 = load { i64, [4 x i64] }, ptr %l82
  %t45 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t42, i64 %t43, { i64, [4 x i64] } %t44)
  store i64 %t45, ptr %l83
  br label %bb13
bb13:
  %t46 = load i64, ptr %l83, !tbaa !24
  store i64 %t46, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l10, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb17
bb15:
  %t51 = load i64, ptr %l10, !tbaa !24
  store i64 %t51, ptr %l87, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 83
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l90
  br label %bb16
bb16:
  %t57 = load i64, ptr %l87, !tbaa !24
  %t58 = load i64, ptr %l90, !tbaa !24
  %t59 = icmp sge i64 %t57, %t58
  store i1 %t59, ptr %l86, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l86, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb39
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 83
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l95
  br label %bb20
bb20:
  %t69 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t69, ptr %l11, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l97, !tbaa !24
  %t73 = load i64, ptr %l97, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load i64, ptr %l97, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t86 = load i64, ptr %l14, !tbaa !24
  %t87 = load i64, ptr %l13, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7289625dc306da68_1bb592dfdbe27504)
  unreachable
bb23:
  %t92 = load i64, ptr %l15, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb28
bb25:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l15, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l108, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l108, !tbaa !24
  store i64 %t112, ptr %l105, !tbaa !24
  br label %bb28
bb28:
  %t113 = load i64, ptr %l105, !tbaa !24
  store i64 %t113, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t114 = load i64, ptr %l16, !tbaa !24
  %t115 = sub i64 %t114, 1
  store i64 %t115, ptr %l117, !tbaa !24
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = icmp slt i64 %t116, 2147483648
  %t118 = load i64, ptr %l17, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  %t122 = and i1 %t117, %t119
  store i1 %t122, ptr %l120, !tbaa !21
  br label %bb29
bb29:
  %t123 = load i64, ptr %l17, !tbaa !24
  %t124 = load i64, ptr %l16, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load i64, ptr %l17, !tbaa !24
  %t133 = load i64, ptr %l15, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l18, !tbaa !24
  %t141 = load i64, ptr %l18, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t142, ptr %l131, !tbaa !27
  %t143 = load i64, ptr %l18, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i8, ptr %t146, i64 %t143
  %t148 = load i8, ptr %t147, !tbaa !32
  %t152 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i8, ptr %t153, i64 %t141
  store i8 %t148, ptr %t154, !tbaa !32
  br label %bb33
bb33:
  %t155 = load i64, ptr %l17, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l17, !tbaa !24
  br label %bb29
bb34:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l138, !tbaa !29
  %t161 = load i64, ptr %l1, !tbaa !24
  store i64 %t161, ptr %l139, !tbaa !24
  %t162 = load { ptr, ptr }, ptr %l8
  %t164 = extractvalue { ptr, ptr } %t162, 0
  %t165 = extractvalue { ptr, ptr } %t162, 1
  %t166 = call { i64, [4 x i64] } %t164(ptr %t165, i64 1)
  store { i64, [4 x i64] } %t166, ptr %l141
  br label %bb35
bb35:
  %t167 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t167, ptr %l142, !tbaa !27
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l143, !tbaa !29
  %t169 = load i64, ptr %l1, !tbaa !24
  store i64 %t169, ptr %l144, !tbaa !24
  %t170 = load { ptr, ptr }, ptr %l8
  %t172 = extractvalue { ptr, ptr } %t170, 0
  %t173 = extractvalue { ptr, ptr } %t170, 1
  %t174 = call { i64, [4 x i64] } %t172(ptr %t173, i64 2)
  store { i64, [4 x i64] } %t174, ptr %l146
  br label %bb36
bb36:
  %t175 = load ptr, ptr %l143, !tbaa !29
  %t176 = load i64, ptr %l144, !tbaa !24
  %t177 = load { i64, [4 x i64] }, ptr %l146
  %t178 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t175, i64 %t176, { i64, [4 x i64] } %t177)
  store i64 %t178, ptr %l147
  br label %bb37
bb37:
  %t179 = load ptr, ptr %l138, !tbaa !29
  %t180 = load i64, ptr %l139, !tbaa !24
  %t181 = load { i64, [4 x i64] }, ptr %l141
  %t182 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t183 = load i64, ptr %l147, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s4, ptr %t179, i64 %t180, { i64, [4 x i64] } %t181, { i64, ptr } %t182, i64 %t183)
  br label %bb38
bb38:
  %t184 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  br label %bb348
bb40:
  %t188 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t188, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t190, ptr %l151
  br label %bb41
bb41:
  %t191 = load i1, ptr %l151, !tbaa !21
  br i1 %t191, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb54
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l152, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  store i64 %t193, ptr %l153, !tbaa !24
  %t194 = load { ptr, ptr }, ptr %l8
  %t196 = extractvalue { ptr, ptr } %t194, 0
  %t197 = extractvalue { ptr, ptr } %t194, 1
  %t198 = call { i64, [4 x i64] } %t196(ptr %t197, i64 2)
  store { i64, [4 x i64] } %t198, ptr %l155
  br label %bb45
bb45:
  %t199 = load ptr, ptr %l152, !tbaa !29
  %t200 = load i64, ptr %l153, !tbaa !24
  %t201 = load { i64, [4 x i64] }, ptr %l155
  %t202 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t199, i64 %t200, { i64, [4 x i64] } %t201)
  store i64 %t202, ptr %l156
  br label %bb46
bb46:
  %t203 = load i64, ptr %l156, !tbaa !24
  %t204 = icmp sge i64 %t203, 0
  br i1 %t204, label %bb47, label %bb48
bb47:
  %t206 = load i64, ptr %l156, !tbaa !24
  %t207 = mul i64 %t206, 1
  %t208 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  store { i64, ptr } %t210, ptr %l19, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l159, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  store i64 %t213, ptr %l160, !tbaa !24
  %t214 = load { ptr, ptr }, ptr %l8
  %t216 = extractvalue { ptr, ptr } %t214, 0
  %t217 = extractvalue { ptr, ptr } %t214, 1
  %t218 = call { i64, [4 x i64] } %t216(ptr %t217, i64 0)
  store { i64, [4 x i64] } %t218, ptr %l162
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_d526727003b18a55_2e4fcca09321f611)
  unreachable
bb49:
  %t219 = load ptr, ptr %l159, !tbaa !29
  %t220 = load i64, ptr %l160, !tbaa !24
  %t221 = load { i64, [4 x i64] }, ptr %l162
  %t222 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s8, ptr %t219, i64 %t220, { i64, [4 x i64] } %t221)
  store { i64, ptr } %t222, ptr %l163
  br label %bb50
bb50:
  %t223 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t231 = extractvalue { i64, ptr } %t223, 1
  %t232 = extractvalue { i64, ptr } %t223, 0
  %t234 = call i64 @__olang_env(ptr %t228, ptr %t231, i64 %t226)
  store i64 %t234, ptr %l167
  br label %bb51
bb51:
  %t235 = load i64, ptr %l167, !tbaa !24
  store i64 %t235, ptr %l9, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l168, !tbaa !29
  %t237 = load i64, ptr %l1, !tbaa !24
  store i64 %t237, ptr %l169, !tbaa !24
  %t238 = load { ptr, ptr }, ptr %l8
  %t240 = extractvalue { ptr, ptr } %t238, 0
  %t241 = extractvalue { ptr, ptr } %t238, 1
  %t242 = call { i64, [4 x i64] } %t240(ptr %t241, i64 1)
  store { i64, [4 x i64] } %t242, ptr %l171
  br label %bb52
bb52:
  %t243 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = load ptr, ptr %l168, !tbaa !29
  %t248 = load i64, ptr %l169, !tbaa !24
  %t249 = load { i64, [4 x i64] }, ptr %l171
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s8, ptr %t247, i64 %t248, { i64, [4 x i64] } %t249, { i64, ptr } %t243, i64 %t246)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb348
bb54:
  %t252 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t254 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t252, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t254, ptr %l176
  br label %bb55
bb55:
  %t255 = load i1, ptr %l176, !tbaa !21
  br i1 %t255, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/eval:Machine", ptr %t256, i32 0, i32 95
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  store i64 %t261, ptr %l9, !tbaa !24
  br label %bb348
bb59:
  %t263 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t265 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t263, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t265, ptr %l181
  br label %bb60
bb60:
  %t266 = load i1, ptr %l181, !tbaa !21
  br i1 %t266, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb81
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t267 = insertvalue [3 x i64] undef, i64 0, 0
  %t268 = insertvalue [3 x i64] %t267, i64 0, 1
  %t269 = insertvalue [3 x i64] %t268, i64 0, 2
  store [3 x i64] %t269, ptr %l20
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l183, !tbaa !29
  %t272 = load i64, ptr %l1, !tbaa !24
  store i64 %t272, ptr %l184, !tbaa !24
  %t273 = load { ptr, ptr }, ptr %l8
  %t275 = extractvalue { ptr, ptr } %t273, 0
  %t276 = extractvalue { ptr, ptr } %t273, 1
  %t277 = call { i64, [4 x i64] } %t275(ptr %t276, i64 0)
  store { i64, [4 x i64] } %t277, ptr %l186
  br label %bb64
bb64:
  %t278 = load ptr, ptr %l183, !tbaa !29
  %t279 = load i64, ptr %l184, !tbaa !24
  %t280 = load { i64, [4 x i64] }, ptr %l186
  %t281 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s10, ptr %t278, i64 %t279, { i64, [4 x i64] } %t280)
  store { i64, ptr } %t281, ptr %l187
  br label %bb65
bb65:
  %t283 = insertvalue { i64, ptr } undef, i64 3, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %l20, 1
  %t286 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t290 = extractvalue { i64, ptr } %t284, 1
  %t291 = extractvalue { i64, ptr } %t284, 0
  %t292 = call i32 @__olang_stat(ptr %t287, ptr %t290)
  store i32 %t292, ptr %l191
  br label %bb66
bb66:
  %t293 = load i32, ptr %l191, !tbaa !23
  %t294 = sext i32 %t293 to i64
  store i64 %t294, ptr %l9, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  store i64 24, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t296 = load i64, ptr %l23, !tbaa !24
  %t297 = load i64, ptr %l22, !tbaa !24
  %t300 = icmp sgt i64 %t296, %t297
  br i1 %t300, label %bb67, label %bb68
bb67:
  %t302 = load i64, ptr %l24, !tbaa !24
  %t304 = icmp sgt i64 %t302, 0
  br i1 %t304, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb72
bb69:
  %t306 = load i64, ptr %l23, !tbaa !24
  %t307 = load i64, ptr %l22, !tbaa !24
  %t310 = sub i64 %t306, %t307
  %t311 = load i64, ptr %l24, !tbaa !24
  %t314 = add i64 %t310, %t311
  %t316 = sub i64 %t314, 1
  %t317 = load i64, ptr %l24, !tbaa !24
  %t320 = sdiv i64 %t316, %t317
  store i64 %t320, ptr %l199, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb71
bb71:
  %t322 = load i64, ptr %l199, !tbaa !24
  store i64 %t322, ptr %l196, !tbaa !24
  br label %bb72
bb72:
  %t323 = load i64, ptr %l196, !tbaa !24
  store i64 %t323, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t324 = load i64, ptr %l25, !tbaa !24
  %t325 = sub i64 %t324, 1
  store i64 %t325, ptr %l208, !tbaa !24
  %t326 = load i64, ptr %l25, !tbaa !24
  %t327 = icmp slt i64 %t326, 2147483648
  %t328 = load i64, ptr %l26, !tbaa !24
  %t329 = icmp sge i64 %t328, 0
  %t332 = and i1 %t327, %t329
  store i1 %t332, ptr %l211, !tbaa !21
  br label %bb73
bb73:
  %t333 = load i64, ptr %l26, !tbaa !24
  %t334 = load i64, ptr %l25, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb74, label %bb75
bb74:
  br label %bb78
bb75:
  br label %bb76
bb76:
  %t341 = load i64, ptr %l22, !tbaa !24
  %t342 = load i64, ptr %l26, !tbaa !24
  %t343 = load i64, ptr %l24, !tbaa !24
  %t346 = mul i64 %t342, %t343
  %t349 = add i64 %t341, %t346
  store i64 %t349, ptr %l27, !tbaa !24
  %t351 = load i64, ptr %l27, !tbaa !24
  %t352 = load i64, ptr %l27, !tbaa !24
  %t354 = sdiv i64 %t352, 8
  %t356 = getelementptr [3 x i64], ptr %l20, i64 0, i64 %t354
  %t357 = load i64, ptr %t356, !tbaa !34
  %t358 = load i64, ptr %l27, !tbaa !24
  %t360 = srem i64 %t358, 8
  %t362 = mul i64 8, %t360
  store i64 %t362, ptr %l227, !tbaa !24
  %t364 = load i64, ptr %l227, !tbaa !24
  %t365 = load i64, ptr %l227, !tbaa !24
  %t366 = ashr i64 %t357, %t365
  %t368 = and i64 %t366, 255
  %t370 = trunc i64 %t368 to i8
  %t373 = getelementptr [24 x i8], ptr %l21, i64 0, i64 %t351
  store i8 %t370, ptr %t373, !tbaa !32
  br label %bb77
bb77:
  %t374 = load i64, ptr %l26, !tbaa !24
  %t377 = add i64 %t374, 1
  store i64 %t377, ptr %l26, !tbaa !24
  br label %bb73
bb78:
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l234, !tbaa !29
  %t380 = load i64, ptr %l1, !tbaa !24
  store i64 %t380, ptr %l235, !tbaa !24
  %t381 = load { ptr, ptr }, ptr %l8
  %t383 = extractvalue { ptr, ptr } %t381, 0
  %t384 = extractvalue { ptr, ptr } %t381, 1
  %t385 = call { i64, [4 x i64] } %t383(ptr %t384, i64 1)
  store { i64, [4 x i64] } %t385, ptr %l237
  br label %bb79
bb79:
  %t387 = insertvalue { i64, ptr } undef, i64 24, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %l21, 1
  %t389 = load ptr, ptr %l234, !tbaa !29
  %t390 = load i64, ptr %l235, !tbaa !24
  %t391 = load { i64, [4 x i64] }, ptr %l237
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s10, ptr %t389, i64 %t390, { i64, [4 x i64] } %t391, { i64, ptr } %t388, i64 24)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s10)
  br label %bb348
bb81:
  %t393 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t395 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t393, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t395, ptr %l241
  br label %bb82
bb82:
  %t396 = load i1, ptr %l241, !tbaa !21
  br i1 %t396, label %bb83, label %bb84
bb83:
  br label %bb88
bb84:
  %t397 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t399 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t397, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t399, ptr %l243
  br label %bb85
bb85:
  %t400 = load i1, ptr %l243, !tbaa !21
  br i1 %t400, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb103
bb88:
  store %olang.scope zeroinitializer, ptr %s14
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l244, !tbaa !29
  %t402 = load i64, ptr %l1, !tbaa !24
  store i64 %t402, ptr %l245, !tbaa !24
  %t403 = load { ptr, ptr }, ptr %l8
  %t405 = extractvalue { ptr, ptr } %t403, 0
  %t406 = extractvalue { ptr, ptr } %t403, 1
  %t407 = call { i64, [4 x i64] } %t405(ptr %t406, i64 2)
  store { i64, [4 x i64] } %t407, ptr %l247
  br label %bb89
bb89:
  %t408 = load ptr, ptr %l244, !tbaa !29
  %t409 = load i64, ptr %l245, !tbaa !24
  %t410 = load { i64, [4 x i64] }, ptr %l247
  %t411 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t408, i64 %t409, { i64, [4 x i64] } %t410)
  store i64 %t411, ptr %l248
  br label %bb90
bb90:
  %t412 = load i64, ptr %l248, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb91, label %bb92
bb91:
  %t415 = load i64, ptr %l248, !tbaa !24
  %t416 = mul i64 %t415, 1
  %t417 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t416)
  %t418 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t417, 1
  store { i64, ptr } %t419, ptr %l28, !tbaa !27
  %t421 = load ptr, ptr %l0, !tbaa !29
  store ptr %t421, ptr %l251, !tbaa !29
  %t422 = load i64, ptr %l1, !tbaa !24
  store i64 %t422, ptr %l252, !tbaa !24
  %t423 = load { ptr, ptr }, ptr %l8
  %t425 = extractvalue { ptr, ptr } %t423, 0
  %t426 = extractvalue { ptr, ptr } %t423, 1
  %t427 = call { i64, [4 x i64] } %t425(ptr %t426, i64 0)
  store { i64, [4 x i64] } %t427, ptr %l254
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_1269d295d9d04536_be9a6b7fb42413f2)
  unreachable
bb93:
  %t428 = load ptr, ptr %l251, !tbaa !29
  %t429 = load i64, ptr %l252, !tbaa !24
  %t430 = load { i64, [4 x i64] }, ptr %l254
  %t431 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s14, ptr %t428, i64 %t429, { i64, [4 x i64] } %t430)
  store { i64, ptr } %t431, ptr %l255
  br label %bb94
bb94:
  %t432 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t432, ptr %l29, !tbaa !27
  %t433 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t435 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s14, { i64, ptr } %t433, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t435, ptr %l257
  br label %bb95
bb95:
  %t436 = load i1, ptr %l257, !tbaa !21
  br i1 %t436, label %bb96, label %bb97
bb96:
  %t437 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t443 = extractvalue { i64, ptr } %t437, 1
  %t444 = extractvalue { i64, ptr } %t437, 0
  %t446 = extractvalue { i64, ptr } %t438, 1
  %t447 = extractvalue { i64, ptr } %t438, 0
  %t449 = call i64 @__olang_dir(ptr %t443, ptr %t446, i64 %t441)
  store i64 %t449, ptr %l263
  br label %bb98
bb97:
  %t450 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t451 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t456 = extractvalue { i64, ptr } %t450, 1
  %t457 = extractvalue { i64, ptr } %t450, 0
  %t459 = extractvalue { i64, ptr } %t451, 1
  %t460 = extractvalue { i64, ptr } %t451, 0
  %t462 = call i64 @__olang_realpath(ptr %t456, ptr %t459, i64 %t454)
  store i64 %t462, ptr %l268
  br label %bb99
bb98:
  %t463 = load i64, ptr %l263, !tbaa !24
  store i64 %t463, ptr %l258, !tbaa !24
  br label %bb100
bb99:
  %t464 = load i64, ptr %l268, !tbaa !24
  store i64 %t464, ptr %l258, !tbaa !24
  br label %bb100
bb100:
  %t465 = load i64, ptr %l258, !tbaa !24
  store i64 %t465, ptr %l9, !tbaa !24
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l269, !tbaa !29
  %t467 = load i64, ptr %l1, !tbaa !24
  store i64 %t467, ptr %l270, !tbaa !24
  %t468 = load { ptr, ptr }, ptr %l8
  %t470 = extractvalue { ptr, ptr } %t468, 0
  %t471 = extractvalue { ptr, ptr } %t468, 1
  %t472 = call { i64, [4 x i64] } %t470(ptr %t471, i64 1)
  store { i64, [4 x i64] } %t472, ptr %l272
  br label %bb101
bb101:
  %t473 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t474 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t474, 0
  %t477 = load ptr, ptr %l269, !tbaa !29
  %t478 = load i64, ptr %l270, !tbaa !24
  %t479 = load { i64, [4 x i64] }, ptr %l272
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s14, ptr %t477, i64 %t478, { i64, [4 x i64] } %t479, { i64, ptr } %t473, i64 %t476)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s14)
  br label %bb348
bb103:
  %t482 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t484 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t482, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t484, ptr %l277
  br label %bb104
bb104:
  %t485 = load i1, ptr %l277, !tbaa !21
  br i1 %t485, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb121
bb107:
  store %olang.scope zeroinitializer, ptr %s15
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l278, !tbaa !29
  %t487 = load i64, ptr %l1, !tbaa !24
  store i64 %t487, ptr %l279, !tbaa !24
  %t488 = load { ptr, ptr }, ptr %l8
  %t490 = extractvalue { ptr, ptr } %t488, 0
  %t491 = extractvalue { ptr, ptr } %t488, 1
  %t492 = call { i64, [4 x i64] } %t490(ptr %t491, i64 0)
  store { i64, [4 x i64] } %t492, ptr %l281
  br label %bb108
bb108:
  %t493 = load ptr, ptr %l278, !tbaa !29
  %t494 = load i64, ptr %l279, !tbaa !24
  %t495 = load { i64, [4 x i64] }, ptr %l281
  %t496 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s15, ptr %t493, i64 %t494, { i64, [4 x i64] } %t495)
  store { i64, ptr } %t496, ptr %l282
  br label %bb109
bb109:
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l283, !tbaa !29
  %t498 = load i64, ptr %l1, !tbaa !24
  store i64 %t498, ptr %l284, !tbaa !24
  %t499 = load { ptr, ptr }, ptr %l8
  %t501 = extractvalue { ptr, ptr } %t499, 0
  %t502 = extractvalue { ptr, ptr } %t499, 1
  %t503 = call { i64, [4 x i64] } %t501(ptr %t502, i64 1)
  store { i64, [4 x i64] } %t503, ptr %l286
  br label %bb110
bb110:
  %t504 = load ptr, ptr %l283, !tbaa !29
  %t505 = load i64, ptr %l284, !tbaa !24
  %t506 = load { i64, [4 x i64] }, ptr %l286
  %t507 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t504, i64 %t505, { i64, [4 x i64] } %t506)
  store i64 %t507, ptr %l287
  br label %bb111
bb111:
  %t508 = load ptr, ptr %l0, !tbaa !29
  store ptr %t508, ptr %l288, !tbaa !29
  %t509 = load i64, ptr %l1, !tbaa !24
  store i64 %t509, ptr %l289, !tbaa !24
  %t510 = load { ptr, ptr }, ptr %l8
  %t512 = extractvalue { ptr, ptr } %t510, 0
  %t513 = extractvalue { ptr, ptr } %t510, 1
  %t514 = call { i64, [4 x i64] } %t512(ptr %t513, i64 2)
  store { i64, [4 x i64] } %t514, ptr %l291
  br label %bb112
bb112:
  %t515 = load ptr, ptr %l288, !tbaa !29
  %t516 = load i64, ptr %l289, !tbaa !24
  %t517 = load { i64, [4 x i64] }, ptr %l291
  %t518 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t515, i64 %t516, { i64, [4 x i64] } %t517)
  store i64 %t518, ptr %l292
  br label %bb113
bb113:
  %t519 = load i64, ptr %l292, !tbaa !24
  %t520 = trunc i64 %t519 to i32
  store i32 %t520, ptr %l293, !tbaa !23
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l294, !tbaa !29
  %t522 = load i64, ptr %l1, !tbaa !24
  store i64 %t522, ptr %l295, !tbaa !24
  %t523 = load { ptr, ptr }, ptr %l8
  %t525 = extractvalue { ptr, ptr } %t523, 0
  %t526 = extractvalue { ptr, ptr } %t523, 1
  %t527 = call { i64, [4 x i64] } %t525(ptr %t526, i64 3)
  store { i64, [4 x i64] } %t527, ptr %l297
  br label %bb114
bb114:
  %t528 = load ptr, ptr %l294, !tbaa !29
  %t529 = load i64, ptr %l295, !tbaa !24
  %t530 = load { i64, [4 x i64] }, ptr %l297
  %t531 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t528, i64 %t529, { i64, [4 x i64] } %t530)
  store i64 %t531, ptr %l298
  br label %bb115
bb115:
  %t532 = load i64, ptr %l298, !tbaa !24
  %t533 = trunc i64 %t532 to i32
  store i32 %t533, ptr %l299, !tbaa !23
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l300, !tbaa !29
  %t535 = load i64, ptr %l1, !tbaa !24
  store i64 %t535, ptr %l301, !tbaa !24
  %t536 = load { ptr, ptr }, ptr %l8
  %t538 = extractvalue { ptr, ptr } %t536, 0
  %t539 = extractvalue { ptr, ptr } %t536, 1
  %t540 = call { i64, [4 x i64] } %t538(ptr %t539, i64 4)
  store { i64, [4 x i64] } %t540, ptr %l303
  br label %bb116
bb116:
  %t541 = load ptr, ptr %l300, !tbaa !29
  %t542 = load i64, ptr %l301, !tbaa !24
  %t543 = load { i64, [4 x i64] }, ptr %l303
  %t544 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t541, i64 %t542, { i64, [4 x i64] } %t543)
  store i64 %t544, ptr %l304
  br label %bb117
bb117:
  %t545 = load i64, ptr %l304, !tbaa !24
  %t546 = trunc i64 %t545 to i32
  store i32 %t546, ptr %l305, !tbaa !23
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l306, !tbaa !29
  %t548 = load i64, ptr %l1, !tbaa !24
  store i64 %t548, ptr %l307, !tbaa !24
  %t549 = load { ptr, ptr }, ptr %l8
  %t551 = extractvalue { ptr, ptr } %t549, 0
  %t552 = extractvalue { ptr, ptr } %t549, 1
  %t553 = call { i64, [4 x i64] } %t551(ptr %t552, i64 5)
  store { i64, [4 x i64] } %t553, ptr %l309
  br label %bb118
bb118:
  %t554 = load ptr, ptr %l306, !tbaa !29
  %t555 = load i64, ptr %l307, !tbaa !24
  %t556 = load { i64, [4 x i64] }, ptr %l309
  %t557 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s15, ptr %t554, i64 %t555, { i64, [4 x i64] } %t556)
  store { i64, ptr } %t557, ptr %l310
  br label %bb119
bb119:
  %t558 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t559 = extractvalue { i64, ptr } %t558, 1
  %t560 = extractvalue { i64, ptr } %t558, 0
  %t561 = load i64, ptr %l287, !tbaa !24
  %t562 = load i32, ptr %l293, !tbaa !23
  %t563 = load i32, ptr %l299, !tbaa !23
  %t564 = load i32, ptr %l305, !tbaa !23
  %t565 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  %t568 = call i32 @__olang_spawn(ptr %t559, i64 %t561, i32 %t562, i32 %t563, i32 %t564, ptr %t566)
  store i32 %t568, ptr %l311
  br label %bb120
bb120:
  %t569 = load i32, ptr %l311, !tbaa !23
  %t570 = sext i32 %t569 to i64
  store i64 %t570, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb348
bb121:
  %t572 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t574 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t572, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t574, ptr %l314
  br label %bb122
bb122:
  %t575 = load i1, ptr %l314, !tbaa !21
  br i1 %t575, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb141
bb125:
  store %olang.scope zeroinitializer, ptr %s16
  %t576 = load ptr, ptr %l0, !tbaa !29
  store ptr %t576, ptr %l315, !tbaa !29
  %t577 = load i64, ptr %l1, !tbaa !24
  store i64 %t577, ptr %l316, !tbaa !24
  %t578 = load { ptr, ptr }, ptr %l8
  %t580 = extractvalue { ptr, ptr } %t578, 0
  %t581 = extractvalue { ptr, ptr } %t578, 1
  %t582 = call { i64, [4 x i64] } %t580(ptr %t581, i64 0)
  store { i64, [4 x i64] } %t582, ptr %l318
  br label %bb126
bb126:
  %t583 = load ptr, ptr %l315, !tbaa !29
  %t584 = load i64, ptr %l316, !tbaa !24
  %t585 = load { i64, [4 x i64] }, ptr %l318
  %t586 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s16, ptr %t583, i64 %t584, { i64, [4 x i64] } %t585)
  store { i64, ptr } %t586, ptr %l319
  br label %bb127
bb127:
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l320, !tbaa !29
  %t588 = load i64, ptr %l1, !tbaa !24
  store i64 %t588, ptr %l321, !tbaa !24
  %t589 = load { ptr, ptr }, ptr %l8
  %t591 = extractvalue { ptr, ptr } %t589, 0
  %t592 = extractvalue { ptr, ptr } %t589, 1
  %t593 = call { i64, [4 x i64] } %t591(ptr %t592, i64 1)
  store { i64, [4 x i64] } %t593, ptr %l323
  br label %bb128
bb128:
  %t594 = load ptr, ptr %l320, !tbaa !29
  %t595 = load i64, ptr %l321, !tbaa !24
  %t596 = load { i64, [4 x i64] }, ptr %l323
  %t597 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s16, ptr %t594, i64 %t595, { i64, [4 x i64] } %t596)
  store { i64, ptr } %t597, ptr %l324
  br label %bb129
bb129:
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l325, !tbaa !29
  %t599 = load i64, ptr %l1, !tbaa !24
  store i64 %t599, ptr %l326, !tbaa !24
  %t600 = load { ptr, ptr }, ptr %l8
  %t602 = extractvalue { ptr, ptr } %t600, 0
  %t603 = extractvalue { ptr, ptr } %t600, 1
  %t604 = call { i64, [4 x i64] } %t602(ptr %t603, i64 2)
  store { i64, [4 x i64] } %t604, ptr %l328
  br label %bb130
bb130:
  %t605 = load ptr, ptr %l325, !tbaa !29
  %t606 = load i64, ptr %l326, !tbaa !24
  %t607 = load { i64, [4 x i64] }, ptr %l328
  %t608 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t605, i64 %t606, { i64, [4 x i64] } %t607)
  store i64 %t608, ptr %l329
  br label %bb131
bb131:
  %t609 = load ptr, ptr %l0, !tbaa !29
  store ptr %t609, ptr %l330, !tbaa !29
  %t610 = load i64, ptr %l1, !tbaa !24
  store i64 %t610, ptr %l331, !tbaa !24
  %t611 = load { ptr, ptr }, ptr %l8
  %t613 = extractvalue { ptr, ptr } %t611, 0
  %t614 = extractvalue { ptr, ptr } %t611, 1
  %t615 = call { i64, [4 x i64] } %t613(ptr %t614, i64 3)
  store { i64, [4 x i64] } %t615, ptr %l333
  br label %bb132
bb132:
  %t616 = load ptr, ptr %l330, !tbaa !29
  %t617 = load i64, ptr %l331, !tbaa !24
  %t618 = load { i64, [4 x i64] }, ptr %l333
  %t619 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t616, i64 %t617, { i64, [4 x i64] } %t618)
  store i64 %t619, ptr %l334
  br label %bb133
bb133:
  %t620 = load i64, ptr %l334, !tbaa !24
  %t621 = trunc i64 %t620 to i32
  store i32 %t621, ptr %l335, !tbaa !23
  %t622 = load ptr, ptr %l0, !tbaa !29
  store ptr %t622, ptr %l336, !tbaa !29
  %t623 = load i64, ptr %l1, !tbaa !24
  store i64 %t623, ptr %l337, !tbaa !24
  %t624 = load { ptr, ptr }, ptr %l8
  %t626 = extractvalue { ptr, ptr } %t624, 0
  %t627 = extractvalue { ptr, ptr } %t624, 1
  %t628 = call { i64, [4 x i64] } %t626(ptr %t627, i64 4)
  store { i64, [4 x i64] } %t628, ptr %l339
  br label %bb134
bb134:
  %t629 = load ptr, ptr %l336, !tbaa !29
  %t630 = load i64, ptr %l337, !tbaa !24
  %t631 = load { i64, [4 x i64] }, ptr %l339
  %t632 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t629, i64 %t630, { i64, [4 x i64] } %t631)
  store i64 %t632, ptr %l340
  br label %bb135
bb135:
  %t633 = load i64, ptr %l340, !tbaa !24
  %t634 = trunc i64 %t633 to i32
  store i32 %t634, ptr %l341, !tbaa !23
  %t635 = load ptr, ptr %l0, !tbaa !29
  store ptr %t635, ptr %l342, !tbaa !29
  %t636 = load i64, ptr %l1, !tbaa !24
  store i64 %t636, ptr %l343, !tbaa !24
  %t637 = load { ptr, ptr }, ptr %l8
  %t639 = extractvalue { ptr, ptr } %t637, 0
  %t640 = extractvalue { ptr, ptr } %t637, 1
  %t641 = call { i64, [4 x i64] } %t639(ptr %t640, i64 5)
  store { i64, [4 x i64] } %t641, ptr %l345
  br label %bb136
bb136:
  %t642 = load ptr, ptr %l342, !tbaa !29
  %t643 = load i64, ptr %l343, !tbaa !24
  %t644 = load { i64, [4 x i64] }, ptr %l345
  %t645 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t642, i64 %t643, { i64, [4 x i64] } %t644)
  store i64 %t645, ptr %l346
  br label %bb137
bb137:
  %t646 = load i64, ptr %l346, !tbaa !24
  %t647 = trunc i64 %t646 to i32
  store i32 %t647, ptr %l347, !tbaa !23
  %t648 = load ptr, ptr %l0, !tbaa !29
  store ptr %t648, ptr %l348, !tbaa !29
  %t649 = load i64, ptr %l1, !tbaa !24
  store i64 %t649, ptr %l349, !tbaa !24
  %t650 = load { ptr, ptr }, ptr %l8
  %t652 = extractvalue { ptr, ptr } %t650, 0
  %t653 = extractvalue { ptr, ptr } %t650, 1
  %t654 = call { i64, [4 x i64] } %t652(ptr %t653, i64 6)
  store { i64, [4 x i64] } %t654, ptr %l351
  br label %bb138
bb138:
  %t655 = load ptr, ptr %l348, !tbaa !29
  %t656 = load i64, ptr %l349, !tbaa !24
  %t657 = load { i64, [4 x i64] }, ptr %l351
  %t658 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s16, ptr %t655, i64 %t656, { i64, [4 x i64] } %t657)
  store { i64, ptr } %t658, ptr %l352
  br label %bb139
bb139:
  %t659 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t659, 1
  %t661 = extractvalue { i64, ptr } %t659, 0
  %t662 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 1
  %t664 = extractvalue { i64, ptr } %t662, 0
  %t665 = load i64, ptr %l329, !tbaa !24
  %t666 = load i32, ptr %l335, !tbaa !23
  %t667 = load i32, ptr %l341, !tbaa !23
  %t668 = load i32, ptr %l347, !tbaa !23
  %t669 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t669, 1
  %t671 = extractvalue { i64, ptr } %t669, 0
  %t672 = call i32 @__olang_spawn_as(ptr %t660, ptr %t663, i64 %t665, i32 %t666, i32 %t667, i32 %t668, ptr %t670)
  store i32 %t672, ptr %l353
  br label %bb140
bb140:
  %t673 = load i32, ptr %l353, !tbaa !23
  %t674 = sext i32 %t673 to i64
  store i64 %t674, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb348
bb141:
  %t676 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t678 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t676, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t678, ptr %l356
  br label %bb142
bb142:
  %t679 = load i1, ptr %l356, !tbaa !21
  br i1 %t679, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb153
bb145:
  store %olang.scope zeroinitializer, ptr %s17
  %t680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t680, ptr %l357, !tbaa !29
  %t681 = load i64, ptr %l1, !tbaa !24
  store i64 %t681, ptr %l358, !tbaa !24
  %t682 = load { ptr, ptr }, ptr %l8
  %t684 = extractvalue { ptr, ptr } %t682, 0
  %t685 = extractvalue { ptr, ptr } %t682, 1
  %t686 = call { i64, [4 x i64] } %t684(ptr %t685, i64 0)
  store { i64, [4 x i64] } %t686, ptr %l360
  br label %bb146
bb146:
  %t687 = load ptr, ptr %l357, !tbaa !29
  %t688 = load i64, ptr %l358, !tbaa !24
  %t689 = load { i64, [4 x i64] }, ptr %l360
  %t690 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s17, ptr %t687, i64 %t688, { i64, [4 x i64] } %t689)
  store { i64, ptr } %t690, ptr %l361
  br label %bb147
bb147:
  %t691 = load ptr, ptr %l0, !tbaa !29
  store ptr %t691, ptr %l362, !tbaa !29
  %t692 = load i64, ptr %l1, !tbaa !24
  store i64 %t692, ptr %l363, !tbaa !24
  %t693 = load { ptr, ptr }, ptr %l8
  %t695 = extractvalue { ptr, ptr } %t693, 0
  %t696 = extractvalue { ptr, ptr } %t693, 1
  %t697 = call { i64, [4 x i64] } %t695(ptr %t696, i64 1)
  store { i64, [4 x i64] } %t697, ptr %l365
  br label %bb148
bb148:
  %t698 = load ptr, ptr %l362, !tbaa !29
  %t699 = load i64, ptr %l363, !tbaa !24
  %t700 = load { i64, [4 x i64] }, ptr %l365
  %t701 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s17, ptr %t698, i64 %t699, { i64, [4 x i64] } %t700)
  store { i64, ptr } %t701, ptr %l366
  br label %bb149
bb149:
  %t702 = load ptr, ptr %l0, !tbaa !29
  store ptr %t702, ptr %l367, !tbaa !29
  %t703 = load i64, ptr %l1, !tbaa !24
  store i64 %t703, ptr %l368, !tbaa !24
  %t704 = load { ptr, ptr }, ptr %l8
  %t706 = extractvalue { ptr, ptr } %t704, 0
  %t707 = extractvalue { ptr, ptr } %t704, 1
  %t708 = call { i64, [4 x i64] } %t706(ptr %t707, i64 2)
  store { i64, [4 x i64] } %t708, ptr %l370
  br label %bb150
bb150:
  %t709 = load ptr, ptr %l367, !tbaa !29
  %t710 = load i64, ptr %l368, !tbaa !24
  %t711 = load { i64, [4 x i64] }, ptr %l370
  %t712 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t709, i64 %t710, { i64, [4 x i64] } %t711)
  store i64 %t712, ptr %l371
  br label %bb151
bb151:
  %t713 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t714 = extractvalue { i64, ptr } %t713, 1
  %t715 = extractvalue { i64, ptr } %t713, 0
  %t716 = load { i64, ptr }, ptr %l366, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t716, 1
  %t718 = extractvalue { i64, ptr } %t716, 0
  %t719 = load i64, ptr %l371, !tbaa !24
  %t720 = call i32 @__olang_exec(ptr %t714, ptr %t717, i64 %t719)
  store i32 %t720, ptr %l372
  br label %bb152
bb152:
  %t721 = load i32, ptr %l372, !tbaa !23
  %t722 = sext i32 %t721 to i64
  store i64 %t722, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb348
bb153:
  %t724 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t726 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t724, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t726, ptr %l375
  br label %bb154
bb154:
  %t727 = load i1, ptr %l375, !tbaa !21
  br i1 %t727, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb163
bb157:
  store %olang.scope zeroinitializer, ptr %s18
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l376, !tbaa !29
  %t729 = load i64, ptr %l1, !tbaa !24
  store i64 %t729, ptr %l377, !tbaa !24
  %t730 = load { ptr, ptr }, ptr %l8
  %t732 = extractvalue { ptr, ptr } %t730, 0
  %t733 = extractvalue { ptr, ptr } %t730, 1
  %t734 = call { i64, [4 x i64] } %t732(ptr %t733, i64 0)
  store { i64, [4 x i64] } %t734, ptr %l379
  br label %bb158
bb158:
  %t735 = load ptr, ptr %l376, !tbaa !29
  %t736 = load i64, ptr %l377, !tbaa !24
  %t737 = load { i64, [4 x i64] }, ptr %l379
  %t738 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s18, ptr %t735, i64 %t736, { i64, [4 x i64] } %t737)
  store { i64, ptr } %t738, ptr %l380
  br label %bb159
bb159:
  %t739 = load { i64, ptr }, ptr %l380, !tbaa !27
  store { i64, ptr } %t739, ptr %l30, !tbaa !27
  %t740 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t742 = extractvalue { i64, ptr } %t740, 1
  %t743 = extractvalue { i64, ptr } %t740, 0
  %t744 = call i32 @__olang_mkdtemp(ptr %t742)
  store i32 %t744, ptr %l382
  br label %bb160
bb160:
  %t745 = load i32, ptr %l382, !tbaa !23
  %t746 = sext i32 %t745 to i64
  store i64 %t746, ptr %l9, !tbaa !24
  %t748 = load ptr, ptr %l0, !tbaa !29
  store ptr %t748, ptr %l384, !tbaa !29
  %t749 = load i64, ptr %l1, !tbaa !24
  store i64 %t749, ptr %l385, !tbaa !24
  %t750 = load { ptr, ptr }, ptr %l8
  %t752 = extractvalue { ptr, ptr } %t750, 0
  %t753 = extractvalue { ptr, ptr } %t750, 1
  %t754 = call { i64, [4 x i64] } %t752(ptr %t753, i64 0)
  store { i64, [4 x i64] } %t754, ptr %l387
  br label %bb161
bb161:
  %t755 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t756 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t758 = extractvalue { i64, ptr } %t756, 0
  %t759 = load ptr, ptr %l384, !tbaa !29
  %t760 = load i64, ptr %l385, !tbaa !24
  %t761 = load { i64, [4 x i64] }, ptr %l387
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s18, ptr %t759, i64 %t760, { i64, [4 x i64] } %t761, { i64, ptr } %t755, i64 %t758)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s18)
  br label %bb348
bb163:
  %t764 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t766 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t764, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t766, ptr %l392
  br label %bb164
bb164:
  %t767 = load i1, ptr %l392, !tbaa !21
  br i1 %t767, label %bb165, label %bb166
bb165:
  br label %bb170
bb166:
  %t768 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t770 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t768, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t770, ptr %l394
  br label %bb167
bb167:
  %t771 = load i1, ptr %l394, !tbaa !21
  br i1 %t771, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb217
bb170:
  store %olang.scope zeroinitializer, ptr %s19
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l395, !tbaa !29
  %t773 = load i64, ptr %l1, !tbaa !24
  store i64 %t773, ptr %l396, !tbaa !24
  %t774 = load { ptr, ptr }, ptr %l8
  %t776 = extractvalue { ptr, ptr } %t774, 0
  %t777 = extractvalue { ptr, ptr } %t774, 1
  %t778 = call { i64, [4 x i64] } %t776(ptr %t777, i64 2)
  store { i64, [4 x i64] } %t778, ptr %l398
  br label %bb171
bb171:
  %t779 = load ptr, ptr %l395, !tbaa !29
  %t780 = load i64, ptr %l396, !tbaa !24
  %t781 = load { i64, [4 x i64] }, ptr %l398
  %t782 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s19, ptr %t779, i64 %t780, { i64, [4 x i64] } %t781)
  store { i64, ptr } %t782, ptr %l399
  br label %bb172
bb172:
  %t783 = load { i64, ptr }, ptr %l399, !tbaa !27
  store { i64, ptr } %t783, ptr %l31, !tbaa !27
  %t784 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t788 = sdiv i64 %t786, 8
  store i64 %t788, ptr %l402, !tbaa !24
  %t789 = load i64, ptr %l402, !tbaa !24
  %t790 = icmp sge i64 %t789, 0
  br i1 %t790, label %bb173, label %bb174
bb173:
  %t792 = load i64, ptr %l402, !tbaa !24
  %t793 = icmp sle i64 %t792, 1152921504606846975
  br i1 %t793, label %bb175, label %bb176
bb174:
  call void @__olang_check_failed(ptr @olang_loc_d5c4bb6f444265cb_1686743ce9a847e7)
  unreachable
bb175:
  %t795 = load i64, ptr %l402, !tbaa !24
  %t796 = mul i64 %t795, 8
  %t797 = call ptr @__olang_scope_alloc_zeroed(ptr %s19, i64 %t796)
  %t798 = insertvalue { i64, ptr } undef, i64 %t795, 0
  %t799 = insertvalue { i64, ptr } %t798, ptr %t797, 1
  store { i64, ptr } %t799, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t801 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t801, 0
  store i64 %t803, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t805 = load i64, ptr %l34, !tbaa !24
  %t806 = load i64, ptr %l33, !tbaa !24
  %t809 = icmp sgt i64 %t805, %t806
  br i1 %t809, label %bb177, label %bb178
bb176:
  call void @__olang_check_failed(ptr @olang_loc_d5c4bb6f444265cb_1686743ce9a847e7)
  unreachable
bb177:
  %t811 = load i64, ptr %l35, !tbaa !24
  %t813 = icmp sgt i64 %t811, 0
  br i1 %t813, label %bb179, label %bb180
bb178:
  store i64 0, ptr %l411, !tbaa !24
  br label %bb182
bb179:
  %t815 = load i64, ptr %l34, !tbaa !24
  %t816 = load i64, ptr %l33, !tbaa !24
  %t819 = sub i64 %t815, %t816
  %t820 = load i64, ptr %l35, !tbaa !24
  %t823 = add i64 %t819, %t820
  %t825 = sub i64 %t823, 1
  %t826 = load i64, ptr %l35, !tbaa !24
  %t829 = sdiv i64 %t825, %t826
  store i64 %t829, ptr %l414, !tbaa !24
  br label %bb181
bb180:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb181
bb181:
  %t831 = load i64, ptr %l414, !tbaa !24
  store i64 %t831, ptr %l411, !tbaa !24
  br label %bb182
bb182:
  %t832 = load i64, ptr %l411, !tbaa !24
  store i64 %t832, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  %t833 = load i64, ptr %l36, !tbaa !24
  %t834 = sub i64 %t833, 1
  store i64 %t834, ptr %l423, !tbaa !24
  %t835 = load i64, ptr %l36, !tbaa !24
  %t836 = icmp slt i64 %t835, 2147483648
  %t837 = load i64, ptr %l37, !tbaa !24
  %t838 = icmp sge i64 %t837, 0
  %t841 = and i1 %t836, %t838
  store i1 %t841, ptr %l426, !tbaa !21
  br label %bb183
bb183:
  %t842 = load i64, ptr %l37, !tbaa !24
  %t843 = load i64, ptr %l36, !tbaa !24
  %t846 = icmp slt i64 %t842, %t843
  %t848 = xor i1 %t846, true
  br i1 %t848, label %bb184, label %bb185
bb184:
  br label %bb188
bb185:
  br label %bb186
bb186:
  %t850 = load i64, ptr %l33, !tbaa !24
  %t851 = load i64, ptr %l37, !tbaa !24
  %t852 = load i64, ptr %l35, !tbaa !24
  %t855 = mul i64 %t851, %t852
  %t858 = add i64 %t850, %t855
  store i64 %t858, ptr %l38, !tbaa !24
  %t860 = load i64, ptr %l38, !tbaa !24
  %t862 = sdiv i64 %t860, 8
  %t863 = load i64, ptr %l38, !tbaa !24
  %t865 = sdiv i64 %t863, 8
  %t867 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t868 = load ptr, ptr %t867, !tbaa !27
  %t869 = getelementptr i64, ptr %t868, i64 %t865
  %t870 = load i64, ptr %t869, !tbaa !85
  %t871 = load i64, ptr %l38, !tbaa !24
  %t873 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr i8, ptr %t874, i64 %t871
  %t876 = load i8, ptr %t875, !tbaa !32
  %t878 = zext i8 %t876 to i64
  %t879 = load i64, ptr %l38, !tbaa !24
  %t881 = srem i64 %t879, 8
  %t883 = mul i64 8, %t881
  store i64 %t883, ptr %l447, !tbaa !65
  %t886 = load i64, ptr %l447, !tbaa !65
  %t887 = load i64, ptr %l447, !tbaa !65
  %t888 = shl i64 %t878, %t887
  %t891 = or i64 %t870, %t888
  %t894 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t895 = load ptr, ptr %t894, !tbaa !27
  %t896 = getelementptr i64, ptr %t895, i64 %t862
  store i64 %t891, ptr %t896, !tbaa !85
  br label %bb187
bb187:
  %t897 = load i64, ptr %l37, !tbaa !24
  %t900 = add i64 %t897, 1
  store i64 %t900, ptr %l37, !tbaa !24
  br label %bb183
bb188:
  %t902 = load ptr, ptr %l0, !tbaa !29
  store ptr %t902, ptr %l453, !tbaa !29
  %t903 = load i64, ptr %l1, !tbaa !24
  store i64 %t903, ptr %l454, !tbaa !24
  %t904 = load { ptr, ptr }, ptr %l8
  %t906 = extractvalue { ptr, ptr } %t904, 0
  %t907 = extractvalue { ptr, ptr } %t904, 1
  %t908 = call { i64, [4 x i64] } %t906(ptr %t907, i64 0)
  store { i64, [4 x i64] } %t908, ptr %l456
  br label %bb189
bb189:
  %t909 = load ptr, ptr %l453, !tbaa !29
  %t910 = load i64, ptr %l454, !tbaa !24
  %t911 = load { i64, [4 x i64] }, ptr %l456
  %t912 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s19, ptr %t909, i64 %t910, { i64, [4 x i64] } %t911)
  store { i64, ptr } %t912, ptr %l457
  br label %bb190
bb190:
  %t913 = load { i64, ptr }, ptr %l457, !tbaa !27
  store { i64, ptr } %t913, ptr %l39, !tbaa !27
  %t914 = load ptr, ptr %l0, !tbaa !29
  store ptr %t914, ptr %l458, !tbaa !29
  %t915 = load i64, ptr %l1, !tbaa !24
  store i64 %t915, ptr %l459, !tbaa !24
  %t916 = load { ptr, ptr }, ptr %l8
  %t918 = extractvalue { ptr, ptr } %t916, 0
  %t919 = extractvalue { ptr, ptr } %t916, 1
  %t920 = call { i64, [4 x i64] } %t918(ptr %t919, i64 1)
  store { i64, [4 x i64] } %t920, ptr %l461
  br label %bb191
bb191:
  %t921 = load ptr, ptr %l458, !tbaa !29
  %t922 = load i64, ptr %l459, !tbaa !24
  %t923 = load { i64, [4 x i64] }, ptr %l461
  %t924 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s19, ptr %t921, i64 %t922, { i64, [4 x i64] } %t923)
  store { i64, ptr } %t924, ptr %l462
  br label %bb192
bb192:
  %t925 = load { i64, ptr }, ptr %l462, !tbaa !27
  store { i64, ptr } %t925, ptr %l40, !tbaa !27
  %t926 = load ptr, ptr %l0, !tbaa !29
  store ptr %t926, ptr %l463, !tbaa !29
  %t927 = load i64, ptr %l1, !tbaa !24
  store i64 %t927, ptr %l464, !tbaa !24
  %t928 = load { ptr, ptr }, ptr %l8
  %t930 = extractvalue { ptr, ptr } %t928, 0
  %t931 = extractvalue { ptr, ptr } %t928, 1
  %t932 = call { i64, [4 x i64] } %t930(ptr %t931, i64 3)
  store { i64, [4 x i64] } %t932, ptr %l466
  br label %bb193
bb193:
  %t933 = load ptr, ptr %l463, !tbaa !29
  %t934 = load i64, ptr %l464, !tbaa !24
  %t935 = load { i64, [4 x i64] }, ptr %l466
  %t936 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t933, i64 %t934, { i64, [4 x i64] } %t935)
  store i64 %t936, ptr %l467
  br label %bb194
bb194:
  %t937 = load i64, ptr %l467, !tbaa !24
  %t938 = trunc i64 %t937 to i8
  store i8 %t938, ptr %l41, !tbaa !22
  %t940 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t942 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s19, { i64, ptr } %t940, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t942, ptr %l470
  br label %bb195
bb195:
  %t943 = load i1, ptr %l470, !tbaa !21
  br i1 %t943, label %bb196, label %bb197
bb196:
  %t944 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t944, ptr %l472, !tbaa !27
  %t945 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t945, ptr %l473, !tbaa !27
  %t946 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t946, ptr %l474, !tbaa !27
  %t947 = load i8, ptr %l41, !tbaa !22
  store i8 %t947, ptr %l475, !tbaa !22
  %t948 = load ptr, ptr %l0, !tbaa !29
  store ptr %t948, ptr %l476, !tbaa !29
  %t949 = load i64, ptr %l1, !tbaa !24
  store i64 %t949, ptr %l477, !tbaa !24
  %t950 = load { ptr, ptr }, ptr %l8
  %t952 = extractvalue { ptr, ptr } %t950, 0
  %t953 = extractvalue { ptr, ptr } %t950, 1
  %t954 = call { i64, [4 x i64] } %t952(ptr %t953, i64 4)
  store { i64, [4 x i64] } %t954, ptr %l479
  br label %bb198
bb197:
  %t955 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t956 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t957 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t958 = load i8, ptr %l41, !tbaa !22
  %t960 = extractvalue { i64, ptr } %t955, 1
  %t961 = extractvalue { i64, ptr } %t955, 0
  %t963 = extractvalue { i64, ptr } %t956, 1
  %t964 = extractvalue { i64, ptr } %t956, 0
  %t966 = extractvalue { i64, ptr } %t957, 1
  %t967 = extractvalue { i64, ptr } %t957, 0
  %t969 = call i64 @__olang_dyncall(ptr %t960, ptr %t963, ptr %t966, i8 zeroext %t958)
  store i64 %t969, ptr %l487
  br label %bb201
bb198:
  %t970 = load ptr, ptr %l476, !tbaa !29
  %t971 = load i64, ptr %l477, !tbaa !24
  %t972 = load { i64, [4 x i64] }, ptr %l479
  %t973 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t970, i64 %t971, { i64, [4 x i64] } %t972)
  store i64 %t973, ptr %l480
  br label %bb199
bb199:
  %t974 = load { i64, ptr }, ptr %l472, !tbaa !27
  %t975 = extractvalue { i64, ptr } %t974, 1
  %t976 = extractvalue { i64, ptr } %t974, 0
  %t977 = load { i64, ptr }, ptr %l473, !tbaa !27
  %t978 = extractvalue { i64, ptr } %t977, 1
  %t979 = extractvalue { i64, ptr } %t977, 0
  %t980 = load { i64, ptr }, ptr %l474, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t980, 1
  %t982 = extractvalue { i64, ptr } %t980, 0
  %t983 = load i8, ptr %l475, !tbaa !22
  %t984 = load i64, ptr %l480, !tbaa !24
  %t985 = call i64 @__olang_dyncall_var(ptr %t975, ptr %t978, ptr %t981, i8 zeroext %t983, i64 %t984)
  store i64 %t985, ptr %l481
  br label %bb200
bb200:
  %t986 = load i64, ptr %l481, !tbaa !65
  store i64 %t986, ptr %l471, !tbaa !24
  br label %bb202
bb201:
  %t988 = load i64, ptr %l487, !tbaa !65
  store i64 %t988, ptr %l471, !tbaa !24
  br label %bb202
bb202:
  %t990 = load i64, ptr %l471, !tbaa !24
  store i64 %t990, ptr %l9, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  %t991 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t993 = extractvalue { i64, ptr } %t991, 0
  store i64 %t993, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t995 = load i64, ptr %l43, !tbaa !24
  %t996 = load i64, ptr %l42, !tbaa !24
  %t999 = icmp sgt i64 %t995, %t996
  br i1 %t999, label %bb203, label %bb204
bb203:
  %t1001 = load i64, ptr %l44, !tbaa !24
  %t1003 = icmp sgt i64 %t1001, 0
  br i1 %t1003, label %bb205, label %bb206
bb204:
  store i64 0, ptr %l494, !tbaa !24
  br label %bb208
bb205:
  %t1005 = load i64, ptr %l43, !tbaa !24
  %t1006 = load i64, ptr %l42, !tbaa !24
  %t1009 = sub i64 %t1005, %t1006
  %t1010 = load i64, ptr %l44, !tbaa !24
  %t1013 = add i64 %t1009, %t1010
  %t1015 = sub i64 %t1013, 1
  %t1016 = load i64, ptr %l44, !tbaa !24
  %t1019 = sdiv i64 %t1015, %t1016
  store i64 %t1019, ptr %l497, !tbaa !24
  br label %bb207
bb206:
  store i64 0, ptr %l497, !tbaa !24
  br label %bb207
bb207:
  %t1021 = load i64, ptr %l497, !tbaa !24
  store i64 %t1021, ptr %l494, !tbaa !24
  br label %bb208
bb208:
  %t1022 = load i64, ptr %l494, !tbaa !24
  store i64 %t1022, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  %t1023 = load i64, ptr %l45, !tbaa !24
  %t1024 = sub i64 %t1023, 1
  store i64 %t1024, ptr %l506, !tbaa !24
  %t1025 = load i64, ptr %l45, !tbaa !24
  %t1026 = icmp slt i64 %t1025, 2147483648
  %t1027 = load i64, ptr %l46, !tbaa !24
  %t1028 = icmp sge i64 %t1027, 0
  %t1031 = and i1 %t1026, %t1028
  store i1 %t1031, ptr %l509, !tbaa !21
  br label %bb209
bb209:
  %t1032 = load i64, ptr %l46, !tbaa !24
  %t1033 = load i64, ptr %l45, !tbaa !24
  %t1036 = icmp slt i64 %t1032, %t1033
  %t1038 = xor i1 %t1036, true
  br i1 %t1038, label %bb210, label %bb211
bb210:
  br label %bb214
bb211:
  br label %bb212
bb212:
  %t1040 = load i64, ptr %l42, !tbaa !24
  %t1041 = load i64, ptr %l46, !tbaa !24
  %t1042 = load i64, ptr %l44, !tbaa !24
  %t1045 = mul i64 %t1041, %t1042
  %t1048 = add i64 %t1040, %t1045
  store i64 %t1048, ptr %l47, !tbaa !24
  %t1050 = load i64, ptr %l47, !tbaa !24
  %t1051 = load i64, ptr %l47, !tbaa !24
  %t1053 = sdiv i64 %t1051, 8
  %t1055 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t1056 = load ptr, ptr %t1055, !tbaa !27
  %t1057 = getelementptr i64, ptr %t1056, i64 %t1053
  %t1058 = load i64, ptr %t1057, !tbaa !85
  %t1059 = load i64, ptr %l47, !tbaa !24
  %t1061 = srem i64 %t1059, 8
  %t1063 = mul i64 8, %t1061
  store i64 %t1063, ptr %l526, !tbaa !65
  %t1066 = load i64, ptr %l526, !tbaa !65
  %t1067 = load i64, ptr %l526, !tbaa !65
  %t1068 = lshr i64 %t1058, %t1067
  %t1070 = and i64 %t1068, 255
  %t1072 = trunc i64 %t1070 to i8
  %t1075 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t1076 = load ptr, ptr %t1075, !tbaa !27
  %t1077 = getelementptr i8, ptr %t1076, i64 %t1050
  store i8 %t1072, ptr %t1077, !tbaa !32
  br label %bb213
bb213:
  %t1078 = load i64, ptr %l46, !tbaa !24
  %t1081 = add i64 %t1078, 1
  store i64 %t1081, ptr %l46, !tbaa !24
  br label %bb209
bb214:
  %t1083 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1083, ptr %l533, !tbaa !29
  %t1084 = load i64, ptr %l1, !tbaa !24
  store i64 %t1084, ptr %l534, !tbaa !24
  %t1085 = load { ptr, ptr }, ptr %l8
  %t1087 = extractvalue { ptr, ptr } %t1085, 0
  %t1088 = extractvalue { ptr, ptr } %t1085, 1
  %t1089 = call { i64, [4 x i64] } %t1087(ptr %t1088, i64 2)
  store { i64, [4 x i64] } %t1089, ptr %l536
  br label %bb215
bb215:
  %t1090 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1091 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t1093 = extractvalue { i64, ptr } %t1091, 0
  %t1094 = load ptr, ptr %l533, !tbaa !29
  %t1095 = load i64, ptr %l534, !tbaa !24
  %t1096 = load { i64, [4 x i64] }, ptr %l536
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s19, ptr %t1094, i64 %t1095, { i64, [4 x i64] } %t1096, { i64, ptr } %t1090, i64 %t1093)
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s19)
  br label %bb348
bb217:
  %t1099 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1099, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t1101, ptr %l541
  br label %bb218
bb218:
  %t1102 = load i1, ptr %l541, !tbaa !21
  br i1 %t1102, label %bb219, label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb229
bb221:
  store %olang.scope zeroinitializer, ptr %s26
  %t1103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1103, ptr %l542, !tbaa !29
  %t1104 = load i64, ptr %l1, !tbaa !24
  store i64 %t1104, ptr %l543, !tbaa !24
  %t1105 = load { ptr, ptr }, ptr %l8
  %t1107 = extractvalue { ptr, ptr } %t1105, 0
  %t1108 = extractvalue { ptr, ptr } %t1105, 1
  %t1109 = call { i64, [4 x i64] } %t1107(ptr %t1108, i64 0)
  store { i64, [4 x i64] } %t1109, ptr %l545
  br label %bb222
bb222:
  %t1110 = load ptr, ptr %l542, !tbaa !29
  %t1111 = load i64, ptr %l543, !tbaa !24
  %t1112 = load { i64, [4 x i64] }, ptr %l545
  %t1113 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s26, ptr %t1110, i64 %t1111, { i64, [4 x i64] } %t1112)
  store { i64, ptr } %t1113, ptr %l546
  br label %bb223
bb223:
  %t1114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1114, ptr %l547, !tbaa !29
  %t1115 = load i64, ptr %l1, !tbaa !24
  store i64 %t1115, ptr %l548, !tbaa !24
  %t1116 = load { ptr, ptr }, ptr %l8
  %t1118 = extractvalue { ptr, ptr } %t1116, 0
  %t1119 = extractvalue { ptr, ptr } %t1116, 1
  %t1120 = call { i64, [4 x i64] } %t1118(ptr %t1119, i64 1)
  store { i64, [4 x i64] } %t1120, ptr %l550
  br label %bb224
bb224:
  %t1121 = load ptr, ptr %l547, !tbaa !29
  %t1122 = load i64, ptr %l548, !tbaa !24
  %t1123 = load { i64, [4 x i64] }, ptr %l550
  %t1124 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s26, ptr %t1121, i64 %t1122, { i64, [4 x i64] } %t1123)
  store { i64, ptr } %t1124, ptr %l551
  br label %bb225
bb225:
  %t1125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1125, ptr %l552, !tbaa !29
  %t1126 = load i64, ptr %l1, !tbaa !24
  store i64 %t1126, ptr %l553, !tbaa !24
  %t1127 = load { ptr, ptr }, ptr %l8
  %t1129 = extractvalue { ptr, ptr } %t1127, 0
  %t1130 = extractvalue { ptr, ptr } %t1127, 1
  %t1131 = call { i64, [4 x i64] } %t1129(ptr %t1130, i64 2)
  store { i64, [4 x i64] } %t1131, ptr %l555
  br label %bb226
bb226:
  %t1132 = load ptr, ptr %l552, !tbaa !29
  %t1133 = load i64, ptr %l553, !tbaa !24
  %t1134 = load { i64, [4 x i64] }, ptr %l555
  %t1135 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t1132, i64 %t1133, { i64, [4 x i64] } %t1134)
  store i64 %t1135, ptr %l556
  br label %bb227
bb227:
  %t1136 = load i64, ptr %l556, !tbaa !24
  %t1137 = trunc i64 %t1136 to i8
  %t1138 = load { i64, ptr }, ptr %l546, !tbaa !27
  %t1139 = extractvalue { i64, ptr } %t1138, 1
  %t1140 = extractvalue { i64, ptr } %t1138, 0
  %t1141 = load { i64, ptr }, ptr %l551, !tbaa !27
  %t1142 = extractvalue { i64, ptr } %t1141, 1
  %t1143 = extractvalue { i64, ptr } %t1141, 0
  %t1145 = call i32 @__olang_dyncall_check(ptr %t1139, ptr %t1142, i8 zeroext %t1137)
  store i32 %t1145, ptr %l558
  br label %bb228
bb228:
  %t1146 = load i32, ptr %l558, !tbaa !23
  %t1147 = sext i32 %t1146 to i64
  store i64 %t1147, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb348
bb229:
  %t1149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1149, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t1151, ptr %l561
  br label %bb230
bb230:
  %t1152 = load i1, ptr %l561, !tbaa !21
  br i1 %t1152, label %bb231, label %bb232
bb231:
  br label %bb233
bb232:
  br label %bb243
bb233:
  store %olang.scope zeroinitializer, ptr %s27
  %t1153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1153, ptr %l562, !tbaa !29
  %t1154 = load i64, ptr %l1, !tbaa !24
  store i64 %t1154, ptr %l563, !tbaa !24
  %t1155 = load { ptr, ptr }, ptr %l8
  %t1157 = extractvalue { ptr, ptr } %t1155, 0
  %t1158 = extractvalue { ptr, ptr } %t1155, 1
  %t1159 = call { i64, [4 x i64] } %t1157(ptr %t1158, i64 0)
  store { i64, [4 x i64] } %t1159, ptr %l565
  br label %bb234
bb234:
  %t1160 = load ptr, ptr %l562, !tbaa !29
  %t1161 = load i64, ptr %l563, !tbaa !24
  %t1162 = load { i64, [4 x i64] }, ptr %l565
  %t1163 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s27, ptr %t1160, i64 %t1161, { i64, [4 x i64] } %t1162)
  store { i64, ptr } %t1163, ptr %l566
  br label %bb235
bb235:
  %t1164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1164, ptr %l567, !tbaa !29
  %t1165 = load i64, ptr %l1, !tbaa !24
  store i64 %t1165, ptr %l568, !tbaa !24
  %t1166 = load { ptr, ptr }, ptr %l8
  %t1168 = extractvalue { ptr, ptr } %t1166, 0
  %t1169 = extractvalue { ptr, ptr } %t1166, 1
  %t1170 = call { i64, [4 x i64] } %t1168(ptr %t1169, i64 1)
  store { i64, [4 x i64] } %t1170, ptr %l570
  br label %bb236
bb236:
  %t1171 = load ptr, ptr %l567, !tbaa !29
  %t1172 = load i64, ptr %l568, !tbaa !24
  %t1173 = load { i64, [4 x i64] }, ptr %l570
  %t1174 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s27, ptr %t1171, i64 %t1172, { i64, [4 x i64] } %t1173)
  store { i64, ptr } %t1174, ptr %l571
  br label %bb237
bb237:
  %t1175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1175, ptr %l572, !tbaa !29
  %t1176 = load i64, ptr %l1, !tbaa !24
  store i64 %t1176, ptr %l573, !tbaa !24
  %t1177 = load { ptr, ptr }, ptr %l8
  %t1179 = extractvalue { ptr, ptr } %t1177, 0
  %t1180 = extractvalue { ptr, ptr } %t1177, 1
  %t1181 = call { i64, [4 x i64] } %t1179(ptr %t1180, i64 2)
  store { i64, [4 x i64] } %t1181, ptr %l575
  br label %bb238
bb238:
  %t1182 = load ptr, ptr %l572, !tbaa !29
  %t1183 = load i64, ptr %l573, !tbaa !24
  %t1184 = load { i64, [4 x i64] }, ptr %l575
  %t1185 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t1182, i64 %t1183, { i64, [4 x i64] } %t1184)
  store i64 %t1185, ptr %l576
  br label %bb239
bb239:
  %t1186 = load i64, ptr %l576, !tbaa !24
  %t1187 = trunc i64 %t1186 to i8
  store i8 %t1187, ptr %l577, !tbaa !22
  %t1188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1188, ptr %l578, !tbaa !29
  %t1189 = load i64, ptr %l1, !tbaa !24
  store i64 %t1189, ptr %l579, !tbaa !24
  %t1190 = load { ptr, ptr }, ptr %l8
  %t1192 = extractvalue { ptr, ptr } %t1190, 0
  %t1193 = extractvalue { ptr, ptr } %t1190, 1
  %t1194 = call { i64, [4 x i64] } %t1192(ptr %t1193, i64 3)
  store { i64, [4 x i64] } %t1194, ptr %l581
  br label %bb240
bb240:
  %t1195 = load ptr, ptr %l578, !tbaa !29
  %t1196 = load i64, ptr %l579, !tbaa !24
  %t1197 = load { i64, [4 x i64] }, ptr %l581
  %t1198 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t1195, i64 %t1196, { i64, [4 x i64] } %t1197)
  store i64 %t1198, ptr %l582
  br label %bb241
bb241:
  %t1199 = load { i64, ptr }, ptr %l566, !tbaa !27
  %t1200 = extractvalue { i64, ptr } %t1199, 1
  %t1201 = extractvalue { i64, ptr } %t1199, 0
  %t1202 = load { i64, ptr }, ptr %l571, !tbaa !27
  %t1203 = extractvalue { i64, ptr } %t1202, 1
  %t1204 = extractvalue { i64, ptr } %t1202, 0
  %t1205 = load i8, ptr %l577, !tbaa !22
  %t1206 = load i64, ptr %l582, !tbaa !24
  %t1207 = call i32 @__olang_dyncall_var_check(ptr %t1200, ptr %t1203, i8 zeroext %t1205, i64 %t1206)
  store i32 %t1207, ptr %l583
  br label %bb242
bb242:
  %t1208 = load i32, ptr %l583, !tbaa !23
  %t1209 = sext i32 %t1208 to i64
  store i64 %t1209, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb348
bb243:
  %t1211 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1213 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1211, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t1213, ptr %l586
  br label %bb244
bb244:
  %t1214 = load i1, ptr %l586, !tbaa !21
  br i1 %t1214, label %bb245, label %bb246
bb245:
  br label %bb250
bb246:
  %t1215 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1217 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1215, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t1217, ptr %l588
  br label %bb247
bb247:
  %t1218 = load i1, ptr %l588, !tbaa !21
  br i1 %t1218, label %bb248, label %bb249
bb248:
  br label %bb250
bb249:
  br label %bb277
bb250:
  store %olang.scope zeroinitializer, ptr %s28
  %t1219 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s28, { i64, ptr } %t1219, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t1221, ptr %l590
  br label %bb251
bb251:
  %t1222 = load i1, ptr %l590, !tbaa !21
  br i1 %t1222, label %bb252, label %bb253
bb252:
  %t1223 = load ptr, ptr %l0, !tbaa !29
  %t1225 = getelementptr %"compiler/eval:Machine", ptr %t1223, i32 0, i32 85
  %t1226 = load { i64, ptr }, ptr %t1225, !tbaa !27
  store { i64, ptr } %t1226, ptr %l591, !tbaa !27
  br label %bb254
bb253:
  %t1228 = load ptr, ptr %l0, !tbaa !29
  %t1230 = getelementptr %"compiler/eval:Machine", ptr %t1228, i32 0, i32 84
  %t1231 = load { i64, ptr }, ptr %t1230, !tbaa !27
  store { i64, ptr } %t1231, ptr %l591, !tbaa !27
  br label %bb254
bb254:
  %t1233 = load { i64, ptr }, ptr %l591, !tbaa !27
  store { i64, ptr } %t1233, ptr %l48, !tbaa !27
  store i64 -1, ptr %l9, !tbaa !24
  %t1234 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s28, { i64, ptr } %t1234, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t1236, ptr %l597
  br label %bb255
bb255:
  %t1237 = load i1, ptr %l597, !tbaa !21
  %t1238 = xor i1 %t1237, true
  br i1 %t1238, label %bb256, label %bb257
bb256:
  store %olang.scope zeroinitializer, ptr %s29
  %t1240 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1242 = extractvalue { i64, ptr } %t1240, 0
  store i64 %t1242, ptr %l600, !tbaa !24
  %t1243 = load i64, ptr %l600, !tbaa !24
  %t1244 = icmp sge i64 %t1243, 0
  br i1 %t1244, label %bb258, label %bb259
bb257:
  br label %bb276
bb258:
  %t1246 = load i64, ptr %l600, !tbaa !24
  %t1247 = mul i64 %t1246, 1
  %t1248 = call ptr @__olang_scope_alloc_zeroed(ptr %s29, i64 %t1247)
  %t1249 = insertvalue { i64, ptr } undef, i64 %t1246, 0
  %t1250 = insertvalue { i64, ptr } %t1249, ptr %t1248, 1
  store { i64, ptr } %t1250, ptr %l49, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  %t1252 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1254 = extractvalue { i64, ptr } %t1252, 0
  store i64 %t1254, ptr %l51, !tbaa !24
  store i64 1, ptr %l52, !tbaa !24
  %t1256 = load i64, ptr %l51, !tbaa !24
  %t1257 = load i64, ptr %l50, !tbaa !24
  %t1260 = icmp sgt i64 %t1256, %t1257
  br i1 %t1260, label %bb260, label %bb261
bb259:
  call void @__olang_check_failed(ptr @olang_loc_72e3b80bf5d68934_41b0c6a64027e678)
  unreachable
bb260:
  %t1262 = load i64, ptr %l52, !tbaa !24
  %t1264 = icmp sgt i64 %t1262, 0
  br i1 %t1264, label %bb262, label %bb263
bb261:
  store i64 0, ptr %l608, !tbaa !24
  br label %bb265
bb262:
  %t1266 = load i64, ptr %l51, !tbaa !24
  %t1267 = load i64, ptr %l50, !tbaa !24
  %t1270 = sub i64 %t1266, %t1267
  %t1271 = load i64, ptr %l52, !tbaa !24
  %t1274 = add i64 %t1270, %t1271
  %t1276 = sub i64 %t1274, 1
  %t1277 = load i64, ptr %l52, !tbaa !24
  %t1280 = sdiv i64 %t1276, %t1277
  store i64 %t1280, ptr %l611, !tbaa !24
  br label %bb264
bb263:
  store i64 0, ptr %l611, !tbaa !24
  br label %bb264
bb264:
  %t1282 = load i64, ptr %l611, !tbaa !24
  store i64 %t1282, ptr %l608, !tbaa !24
  br label %bb265
bb265:
  %t1283 = load i64, ptr %l608, !tbaa !24
  store i64 %t1283, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  %t1284 = load i64, ptr %l53, !tbaa !24
  %t1285 = sub i64 %t1284, 1
  store i64 %t1285, ptr %l620, !tbaa !24
  %t1286 = load i64, ptr %l53, !tbaa !24
  %t1287 = icmp slt i64 %t1286, 2147483648
  %t1288 = load i64, ptr %l54, !tbaa !24
  %t1289 = icmp sge i64 %t1288, 0
  %t1292 = and i1 %t1287, %t1289
  store i1 %t1292, ptr %l623, !tbaa !21
  br label %bb266
bb266:
  %t1293 = load i64, ptr %l54, !tbaa !24
  %t1294 = load i64, ptr %l53, !tbaa !24
  %t1297 = icmp slt i64 %t1293, %t1294
  %t1299 = xor i1 %t1297, true
  br i1 %t1299, label %bb267, label %bb268
bb267:
  br label %bb271
bb268:
  br label %bb269
bb269:
  %t1301 = load i64, ptr %l50, !tbaa !24
  %t1302 = load i64, ptr %l54, !tbaa !24
  %t1303 = load i64, ptr %l52, !tbaa !24
  %t1306 = mul i64 %t1302, %t1303
  %t1309 = add i64 %t1301, %t1306
  store i64 %t1309, ptr %l55, !tbaa !24
  %t1311 = load i64, ptr %l55, !tbaa !24
  %t1312 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t1312, ptr %l634, !tbaa !27
  %t1313 = load i64, ptr %l55, !tbaa !24
  %t1315 = getelementptr { i64, ptr }, ptr %l634, i32 0, i32 1
  %t1316 = load ptr, ptr %t1315, !tbaa !27
  %t1317 = getelementptr i8, ptr %t1316, i64 %t1313
  %t1318 = load i8, ptr %t1317, !tbaa !32
  %t1322 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1323 = load ptr, ptr %t1322, !tbaa !27
  %t1324 = getelementptr i8, ptr %t1323, i64 %t1311
  store i8 %t1318, ptr %t1324, !tbaa !32
  br label %bb270
bb270:
  %t1325 = load i64, ptr %l54, !tbaa !24
  %t1328 = add i64 %t1325, 1
  store i64 %t1328, ptr %l54, !tbaa !24
  br label %bb266
bb271:
  %t1330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1330, ptr %l641, !tbaa !29
  %t1331 = load i64, ptr %l1, !tbaa !24
  store i64 %t1331, ptr %l642, !tbaa !24
  %t1332 = load { ptr, ptr }, ptr %l8
  %t1334 = extractvalue { ptr, ptr } %t1332, 0
  %t1335 = extractvalue { ptr, ptr } %t1332, 1
  %t1336 = call { i64, [4 x i64] } %t1334(ptr %t1335, i64 0)
  store { i64, [4 x i64] } %t1336, ptr %l644
  br label %bb272
bb272:
  %t1337 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t1337, ptr %l645, !tbaa !27
  %t1338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1338, ptr %l646, !tbaa !29
  %t1339 = load i64, ptr %l1, !tbaa !24
  store i64 %t1339, ptr %l647, !tbaa !24
  %t1340 = load { ptr, ptr }, ptr %l8
  %t1342 = extractvalue { ptr, ptr } %t1340, 0
  %t1343 = extractvalue { ptr, ptr } %t1340, 1
  %t1344 = call { i64, [4 x i64] } %t1342(ptr %t1343, i64 1)
  store { i64, [4 x i64] } %t1344, ptr %l649
  br label %bb273
bb273:
  %t1345 = load ptr, ptr %l646, !tbaa !29
  %t1346 = load i64, ptr %l647, !tbaa !24
  %t1347 = load { i64, [4 x i64] }, ptr %l649
  %t1348 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t1345, i64 %t1346, { i64, [4 x i64] } %t1347)
  store i64 %t1348, ptr %l650
  br label %bb274
bb274:
  %t1349 = load ptr, ptr %l641, !tbaa !29
  %t1350 = load i64, ptr %l642, !tbaa !24
  %t1351 = load { i64, [4 x i64] }, ptr %l644
  %t1352 = load { i64, ptr }, ptr %l645, !tbaa !27
  %t1353 = load i64, ptr %l650, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s29, ptr %t1349, i64 %t1350, { i64, [4 x i64] } %t1351, { i64, ptr } %t1352, i64 %t1353)
  br label %bb275
bb275:
  %t1354 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1356 = extractvalue { i64, ptr } %t1354, 0
  store i64 %t1356, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb276
bb276:
  call void @__olang_scope_close(ptr %s28)
  br label %bb348
bb277:
  %t1358 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1360 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1358, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t1360, ptr %l654
  br label %bb278
bb278:
  %t1361 = load i1, ptr %l654, !tbaa !21
  br i1 %t1361, label %bb279, label %bb280
bb279:
  br label %bb281
bb280:
  br label %bb282
bb281:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb348
bb282:
  %t1362 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1364 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1362, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t1364, ptr %l656
  br label %bb283
bb283:
  %t1365 = load i1, ptr %l656, !tbaa !21
  br i1 %t1365, label %bb284, label %bb285
bb284:
  br label %bb292
bb285:
  %t1366 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1368 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1366, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t1368, ptr %l658
  br label %bb286
bb286:
  %t1369 = load i1, ptr %l658, !tbaa !21
  br i1 %t1369, label %bb287, label %bb288
bb287:
  br label %bb292
bb288:
  %t1370 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1370, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t1372, ptr %l660
  br label %bb289
bb289:
  %t1373 = load i1, ptr %l660, !tbaa !21
  br i1 %t1373, label %bb290, label %bb291
bb290:
  br label %bb292
bb291:
  br label %bb293
bb292:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb348
bb293:
  %t1374 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1376 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1374, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t1376, ptr %l662
  br label %bb294
bb294:
  %t1377 = load i1, ptr %l662, !tbaa !21
  br i1 %t1377, label %bb295, label %bb296
bb295:
  br label %bb297
bb296:
  br label %bb298
bb297:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb348
bb298:
  %t1378 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1380 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1378, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t1380, ptr %l664
  br label %bb299
bb299:
  %t1381 = load i1, ptr %l664, !tbaa !21
  br i1 %t1381, label %bb300, label %bb301
bb300:
  br label %bb302
bb301:
  br label %bb303
bb302:
  store i64 1, ptr %l9, !tbaa !24
  br label %bb348
bb303:
  %t1382 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1384 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1382, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t1384, ptr %l666
  br label %bb304
bb304:
  %t1385 = load i1, ptr %l666, !tbaa !21
  br i1 %t1385, label %bb305, label %bb306
bb305:
  br label %bb307
bb306:
  br label %bb308
bb307:
  br label %bb348
bb308:
  %t1386 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1386, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t1388, ptr %l668
  br label %bb309
bb309:
  %t1389 = load i1, ptr %l668, !tbaa !21
  br i1 %t1389, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  br label %bb313
bb312:
  %t1390 = load ptr, ptr %l0, !tbaa !29
  %t1392 = getelementptr %"compiler/eval:Machine", ptr %t1390, i32 0, i32 86
  store i1 true, ptr %t1392, !tbaa !21
  br label %bb348
bb313:
  %t1393 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1395 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1393, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t1395, ptr %l671
  br label %bb314
bb314:
  %t1396 = load i1, ptr %l671, !tbaa !21
  br i1 %t1396, label %bb315, label %bb316
bb315:
  br label %bb317
bb316:
  br label %bb342
bb317:
  %t1397 = load ptr, ptr %l0, !tbaa !29
  %t1399 = getelementptr %"compiler/eval:Machine", ptr %t1397, i32 0, i32 1
  %t1400 = load i32, ptr %t1399, !range !{i32 0, i32 2}
  %t1402 = trunc i64 1 to i32
  %t1403 = icmp eq i32 %t1400, %t1402
  br i1 %t1403, label %bb318, label %bb319
bb318:
  store %olang.scope zeroinitializer, ptr %s40
  %t1405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1405, ptr %l675, !tbaa !29
  %t1406 = load i64, ptr %l1, !tbaa !24
  store i64 %t1406, ptr %l676, !tbaa !24
  %t1407 = load { ptr, ptr }, ptr %l8
  %t1409 = extractvalue { ptr, ptr } %t1407, 0
  %t1410 = extractvalue { ptr, ptr } %t1407, 1
  %t1411 = call { i64, [4 x i64] } %t1409(ptr %t1410, i64 0)
  store { i64, [4 x i64] } %t1411, ptr %l678
  br label %bb320
bb319:
  br label %bb341
bb320:
  %t1412 = load ptr, ptr %l675, !tbaa !29
  %t1413 = load i64, ptr %l676, !tbaa !24
  %t1414 = load { i64, [4 x i64] }, ptr %l678
  %t1415 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s40, ptr %t1412, i64 %t1413, { i64, [4 x i64] } %t1414)
  store { i64, ptr } %t1415, ptr %l679
  br label %bb321
bb321:
  %t1416 = load { i64, ptr }, ptr %l679, !tbaa !27
  store { i64, ptr } %t1416, ptr %l56, !tbaa !27
  %t1417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1417, ptr %l680, !tbaa !29
  %t1418 = load i64, ptr %l1, !tbaa !24
  store i64 %t1418, ptr %l681, !tbaa !24
  %t1419 = load { ptr, ptr }, ptr %l8
  %t1421 = extractvalue { ptr, ptr } %t1419, 0
  %t1422 = extractvalue { ptr, ptr } %t1419, 1
  %t1423 = call { i64, [4 x i64] } %t1421(ptr %t1422, i64 1)
  store { i64, [4 x i64] } %t1423, ptr %l683
  br label %bb322
bb322:
  %t1424 = load ptr, ptr %l680, !tbaa !29
  %t1425 = load i64, ptr %l681, !tbaa !24
  %t1426 = load { i64, [4 x i64] }, ptr %l683
  %t1427 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t1424, i64 %t1425, { i64, [4 x i64] } %t1426)
  store i64 %t1427, ptr %l684
  br label %bb323
bb323:
  %t1428 = load i64, ptr %l684, !tbaa !24
  store i64 %t1428, ptr %l57, !tbaa !24
  %t1429 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s40)
  store %"std/prelude/text:StringBuilder" %t1429, ptr %l685
  br label %bb324
bb324:
  %t1430 = load %"std/prelude/text:StringBuilder", ptr %l685
  store %"std/prelude/text:StringBuilder" %t1430, ptr %l58
  store i64 0, ptr %l59, !tbaa !24
  %t1431 = load i64, ptr %l57, !tbaa !24
  store i64 %t1431, ptr %l60, !tbaa !24
  store i64 1, ptr %l61, !tbaa !24
  %t1433 = load i64, ptr %l60, !tbaa !24
  %t1434 = load i64, ptr %l59, !tbaa !24
  %t1437 = icmp sgt i64 %t1433, %t1434
  br i1 %t1437, label %bb325, label %bb326
bb325:
  %t1439 = load i64, ptr %l61, !tbaa !24
  %t1441 = icmp sgt i64 %t1439, 0
  br i1 %t1441, label %bb327, label %bb328
bb326:
  store i64 0, ptr %l690, !tbaa !24
  br label %bb330
bb327:
  %t1443 = load i64, ptr %l60, !tbaa !24
  %t1444 = load i64, ptr %l59, !tbaa !24
  %t1447 = sub i64 %t1443, %t1444
  %t1448 = load i64, ptr %l61, !tbaa !24
  %t1451 = add i64 %t1447, %t1448
  %t1453 = sub i64 %t1451, 1
  %t1454 = load i64, ptr %l61, !tbaa !24
  %t1457 = sdiv i64 %t1453, %t1454
  store i64 %t1457, ptr %l693, !tbaa !24
  br label %bb329
bb328:
  store i64 0, ptr %l693, !tbaa !24
  br label %bb329
bb329:
  %t1459 = load i64, ptr %l693, !tbaa !24
  store i64 %t1459, ptr %l690, !tbaa !24
  br label %bb330
bb330:
  %t1460 = load i64, ptr %l690, !tbaa !24
  store i64 %t1460, ptr %l62, !tbaa !24
  store i64 0, ptr %l63, !tbaa !24
  br label %bb331
bb331:
  %t1461 = load i64, ptr %l63, !tbaa !24
  %t1462 = load i64, ptr %l62, !tbaa !24
  %t1465 = icmp slt i64 %t1461, %t1462
  %t1467 = xor i1 %t1465, true
  br i1 %t1467, label %bb332, label %bb333
bb332:
  br label %bb337
bb333:
  br label %bb334
bb334:
  %t1469 = load i64, ptr %l59, !tbaa !24
  %t1470 = load i64, ptr %l63, !tbaa !24
  %t1471 = load i64, ptr %l61, !tbaa !24
  %t1474 = mul i64 %t1470, %t1471
  %t1477 = add i64 %t1469, %t1474
  %t1481 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t1482 = load ptr, ptr %t1481, !tbaa !27
  %t1483 = getelementptr i8, ptr %t1482, i64 %t1477
  %t1484 = load i8, ptr %t1483, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s40, ptr %l58, i8 %t1484)
  br label %bb335
bb335:
  br label %bb336
bb336:
  %t1488 = load i64, ptr %l63, !tbaa !24
  %t1491 = add i64 %t1488, 1
  store i64 %t1491, ptr %l63, !tbaa !24
  br label %bb331
bb337:
  %t1493 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  %t1494 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s40, ptr %t1494, ptr %l58, { i64, ptr } %t1493)
  br label %bb338
bb338:
  %t1498 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s40, ptr %s40, ptr %l58)
  store { i64, ptr } %t1498, ptr %l721
  br label %bb339
bb339:
  %t1499 = load { i64, ptr }, ptr %l721, !tbaa !27
  call void @std_2fos_2eOnCrash(ptr %s40, { i64, ptr } %t1499)
  br label %bb340
bb340:
  call void @__olang_scope_close(ptr %s40)
  br label %bb341
bb341:
  br label %bb348
bb342:
  br i1 true, label %bb343, label %bb344
bb343:
  br label %bb345
bb344:
  br label %bb347
bb345:
  %t1501 = load ptr, ptr %l0, !tbaa !29
  %t1502 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiFind, !tbaa !27
  %t1503 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t1503, ptr %t1501, { i64, ptr } %t1502)
  br label %bb346
bb346:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb347:
  call void @__olang_check_failed(ptr @olang_loc_a18e8c5cba1eb19a_a9626f5dd72b6766)
  unreachable
bb348:
  %t1507 = load ptr, ptr %l0, !tbaa !29
  %t1509 = getelementptr %"compiler/eval:Machine", ptr %t1507, i32 0, i32 23
  %t1510 = load i1, ptr %t1509, !tbaa !21
  br i1 %t1510, label %bb349, label %bb350
bb349:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb350:
  br label %bb351
bb351:
  %t1513 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1515 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1513, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t1515, ptr %l730
  br label %bb352
bb352:
  %t1516 = load i1, ptr %l730, !tbaa !21
  %t1517 = xor i1 %t1516, true
  br i1 %t1517, label %bb353, label %bb354
bb353:
  %t1519 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1521 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1519, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t1521, ptr %l734
  br label %bb355
bb354:
  store i1 false, ptr %l732, !tbaa !21
  br label %bb356
bb355:
  %t1522 = load i1, ptr %l734, !tbaa !21
  %t1523 = xor i1 %t1522, true
  store i1 %t1523, ptr %l732, !tbaa !21
  br label %bb356
bb356:
  %t1525 = load i1, ptr %l732, !tbaa !21
  br i1 %t1525, label %bb357, label %bb358
bb357:
  %t1526 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1528 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1526, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t1528, ptr %l738
  br label %bb359
bb358:
  store i1 false, ptr %l736, !tbaa !21
  br label %bb360
bb359:
  %t1529 = load i1, ptr %l738, !tbaa !21
  %t1530 = xor i1 %t1529, true
  store i1 %t1530, ptr %l736, !tbaa !21
  br label %bb360
bb360:
  %t1532 = load i1, ptr %l736, !tbaa !21
  br i1 %t1532, label %bb361, label %bb362
bb361:
  %t1533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1533, ptr %l740, !tbaa !29
  %t1534 = call i32 @__olang_err()
  store i32 %t1534, ptr %l741
  br label %bb363
bb362:
  br label %bb364
bb363:
  %t1535 = load i32, ptr %l741, !tbaa !23
  %t1536 = load ptr, ptr %l740, !tbaa !29
  %t1537 = getelementptr %"compiler/eval:Machine", ptr %t1536, i32 0, i32 95
  store i32 %t1535, ptr %t1537, !tbaa !23
  br label %bb364
bb364:
  %t1538 = load ptr, ptr %l0, !tbaa !29
  %t1540 = getelementptr %"compiler/eval:Machine", ptr %t1538, i32 0, i32 0
  %t1541 = load ptr, ptr %t1540, !tbaa !29
  %t1545 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1541, i32 %a4)
  store i32 %t1545, ptr %l745
  br label %bb365
bb365:
  %t1546 = load i32, ptr %l745, !tbaa !23
  store i32 %t1546, ptr %l65, !tbaa !23
  br i1 %a6, label %bb366, label %bb367
bb366:
  %t1549 = load i32, ptr %l65, !tbaa !23
  %t1550 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1553 = icmp ne i32 %t1549, %t1550
  store i1 %t1553, ptr %l747, !tbaa !21
  br label %bb368
bb367:
  store i1 false, ptr %l747, !tbaa !21
  br label %bb368
bb368:
  %t1555 = load i1, ptr %l747, !tbaa !21
  br i1 %t1555, label %bb369, label %bb370
bb369:
  %t1556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1556, ptr %l751, !tbaa !29
  store %"compiler/eval:Ptr" %a5, ptr %l752
  %t1558 = load ptr, ptr %l0, !tbaa !29
  %t1559 = load i32, ptr %l65, !tbaa !23
  %t1562 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t1558, i32 %t1559)
  store i64 %t1562, ptr %l755
  br label %bb371
bb370:
  br label %bb373
bb371:
  %t1563 = load i64, ptr %l9, !tbaa !24
  %t1564 = load ptr, ptr %l751, !tbaa !29
  %t1565 = load %"compiler/eval:Ptr", ptr %l752
  %t1566 = load i64, ptr %l755, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1564, %"compiler/eval:Ptr" %t1565, i64 %t1566, i64 %t1563)
  br label %bb372
bb372:
  br label %bb373
bb373:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2esettle(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l18 = alloca %"compiler/eval:scope"
  %l25 = alloca i64
  %l29 = alloca i1
  %t22 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t5, i64 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 53
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t21 = and i64 %t17, %t18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t22, ptr %v0, ptr %t16, i64 %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t22, i64 152, i1 false)
  br label %bb7
bb7:
  %t25 = getelementptr %"compiler/eval:scope", ptr %l18, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t30 = icmp ne i64 %t26, %t27
  store i1 %t30, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l12, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eanchorRegion(ptr %v0, ptr %t33, %"compiler/eval:Ptr" %a2, i32 %a3)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb15
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 23
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l29, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2emoveOut(ptr %v0, ptr %t53, i64 %t54, i64 %t55)
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %t59, i64 %t60)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshapeOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l88 = alloca i32
  %l90 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i1
  %l105 = alloca i64
  %l112 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load i32, ptr %l12, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i32, ptr %l15, !range !{i32 0, i32 33}
  store i32 %t22, ptr %l4
  %t23 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t28 = load i64, ptr @G_2ecompiler_2feval_2evVoid, !tbaa !24
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb107
bb7:
  %t30 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t32 = trunc i64 2 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb107
bb11:
  %t37 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t39 = trunc i64 3 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  %t42 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t44 = trunc i64 4 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t47 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t49 = trunc i64 5 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t52 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t54 = trunc i64 6 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t57 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  store i64 %t57, ptr %l16, !tbaa !24
  br label %bb107
bb21:
  %t59 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t61 = trunc i64 7 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t64 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t66 = trunc i64 8 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t69 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t71 = trunc i64 9 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t74 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t76 = trunc i64 10 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t79 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  store i64 %t79, ptr %l16, !tbaa !24
  br label %bb107
bb31:
  %t81 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t83 = trunc i64 31 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb43
bb34:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t86, i32 %t87)
  store i64 %t90, ptr %l45
  br label %bb35
bb35:
  %t91 = load i64, ptr %l45, !tbaa !24
  %t92 = icmp sgt i64 %t91, 64
  br i1 %t92, label %bb36, label %bb37
bb36:
  %t94 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  store i64 %t94, ptr %l47, !tbaa !24
  br label %bb42
bb37:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load i32, ptr %l3, !tbaa !23
  %t100 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t100, ptr %l51
  br label %bb38
bb38:
  %t101 = load i64, ptr %l51, !tbaa !24
  %t102 = icmp eq i64 %t101, 1
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  store i64 %t104, ptr %l53, !tbaa !24
  br label %bb41
bb40:
  %t106 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  store i64 %t106, ptr %l53, !tbaa !24
  br label %bb41
bb41:
  %t108 = load i64, ptr %l53, !tbaa !24
  store i64 %t108, ptr %l47, !tbaa !24
  br label %bb42
bb42:
  %t109 = load i64, ptr %l47, !tbaa !24
  store i64 %t109, ptr %l16, !tbaa !24
  br label %bb107
bb43:
  %t110 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t112 = trunc i64 11 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb44, label %bb45
bb44:
  br label %bb52
bb45:
  %t115 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t117 = trunc i64 12 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t120 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t122 = trunc i64 13 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb48, label %bb49
bb48:
  br label %bb52
bb49:
  %t125 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t127 = trunc i64 14 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t130 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  store i64 %t130, ptr %l16, !tbaa !24
  br label %bb107
bb53:
  %t132 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t134 = trunc i64 15 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t137 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  store i64 %t137, ptr %l16, !tbaa !24
  br label %bb107
bb57:
  %t139 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t141 = trunc i64 16 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t144 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  store i64 %t144, ptr %l16, !tbaa !24
  br label %bb107
bb61:
  %t146 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t148 = trunc i64 20 to i32
  %t149 = icmp eq i32 %t146, %t148
  br i1 %t149, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb70
bb64:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l73, !tbaa !29
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t153 = load i32, ptr %l3, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l76
  br label %bb65
bb65:
  %t157 = load ptr, ptr %l73, !tbaa !29
  %t158 = load i32, ptr %l76, !tbaa !23
  %t159 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t159, ptr %l77
  br label %bb66
bb66:
  %t160 = load i1, ptr %l77, !tbaa !21
  br i1 %t160, label %bb67, label %bb68
bb67:
  %t161 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  store i64 %t161, ptr %l78, !tbaa !24
  br label %bb69
bb68:
  %t163 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  store i64 %t163, ptr %l78, !tbaa !24
  br label %bb69
bb69:
  %t165 = load i64, ptr %l78, !tbaa !24
  store i64 %t165, ptr %l16, !tbaa !24
  br label %bb107
bb70:
  %t166 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t168 = trunc i64 21 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t171 = load i64, ptr @G_2ecompiler_2feval_2evFunc, !tbaa !24
  store i64 %t171, ptr %l16, !tbaa !24
  br label %bb107
bb74:
  %t173 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t175 = trunc i64 19 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load i32, ptr %l3, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l88
  br label %bb78
bb78:
  %t183 = load i32, ptr %l88, !tbaa !23
  %t184 = icmp eq i32 %t183, 0
  br i1 %t184, label %bb79, label %bb80
bb79:
  %t186 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  store i64 %t186, ptr %l90, !tbaa !24
  br label %bb81
bb80:
  %t188 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  store i64 %t188, ptr %l90, !tbaa !24
  br label %bb81
bb81:
  %t190 = load i64, ptr %l90, !tbaa !24
  store i64 %t190, ptr %l16, !tbaa !24
  br label %bb107
bb82:
  %t191 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t193 = trunc i64 22 to i32
  %t194 = icmp eq i32 %t191, %t193
  br i1 %t194, label %bb83, label %bb84
bb83:
  br label %bb87
bb84:
  %t196 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t198 = trunc i64 23 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t201 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  store i64 %t201, ptr %l16, !tbaa !24
  br label %bb107
bb88:
  %t203 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t205 = trunc i64 24 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t208 = load ptr, ptr %l2, !tbaa !29
  store ptr %t208, ptr %l100, !tbaa !29
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t210 = load i32, ptr %l3, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t213, ptr %l103
  br label %bb92
bb92:
  %t214 = load ptr, ptr %l100, !tbaa !29
  %t215 = load i32, ptr %l103, !tbaa !23
  %t216 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t216, ptr %l104
  br label %bb93
bb93:
  %t217 = load i1, ptr %l104, !tbaa !21
  br i1 %t217, label %bb94, label %bb95
bb94:
  %t218 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  store i64 %t218, ptr %l105, !tbaa !24
  br label %bb96
bb95:
  %t220 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  store i64 %t220, ptr %l105, !tbaa !24
  br label %bb96
bb96:
  %t222 = load i64, ptr %l105, !tbaa !24
  store i64 %t222, ptr %l16, !tbaa !24
  br label %bb107
bb97:
  %t223 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t225 = trunc i64 18 to i32
  %t226 = icmp eq i32 %t223, %t225
  br i1 %t226, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l3, !tbaa !23
  %t232 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enamedShape(ptr %v0, ptr %t228, i32 %t229)
  store i64 %t232, ptr %l112
  br label %bb101
bb101:
  %t233 = load i64, ptr %l112, !tbaa !24
  store i64 %t233, ptr %l16, !tbaa !24
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t234 = load i64, ptr @G_2ecompiler_2feval_2evNone, !tbaa !24
  store i64 %t234, ptr %l16, !tbaa !24
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_5b67d157b70117f_cddce93e80c09b93)
  unreachable
bb107:
  %t236 = load i64, ptr %l16, !tbaa !24
  store i64 %t236, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eslotRegion(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca %"compiler/eval:scope"
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l22 = alloca %"compiler/eval:scope"
  %rv = alloca i1
  %t9 = alloca %"compiler/eval:scope", align 8
  %t34 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 53
  %t5 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t8 = and i64 %a1, %t5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t9, ptr %v0, ptr %t3, i64 %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t9, i64 152, i1 false)
  br label %bb1
bb1:
  %t12 = getelementptr %"compiler/eval:scope", ptr %l8, i32 0, i32 5
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp ne i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t19, i64 %t20)
  store i1 %t23, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 53
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t33 = and i64 %t29, %t30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t34, ptr %v0, ptr %t28, i64 %t33)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t34, i64 152, i1 false)
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t37 = getelementptr %"compiler/eval:scope", ptr %l22, i32 0, i32 18
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estmtAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca { i64, [21 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/mir:Lvalue"
  %l9 = alloca { i64, [15 x i64] }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:ScopeInfo"
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l25 = alloca %"compiler/eval:Ptr"
  %l27 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, [1 x i64] }
  %l36 = alloca i32
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca i64
  %l41 = alloca i1
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/mir:Lvalue"
  %l45 = alloca { %"compiler/eval:Ptr", i32 }
  %l46 = alloca %"compiler/eval:Ptr"
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca { i64, [21 x i64] }
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca %"compiler/mir:Lvalue"
  %l53 = alloca { %"compiler/eval:Ptr", i32 }
  %l54 = alloca %"compiler/eval:Ptr"
  %l55 = alloca i32
  %l56 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i32
  %l59 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca { i64, [1 x i64] }
  %l62 = alloca i32
  %l63 = alloca { i64, [4 x i64] }
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca { i64, [4 x i64] }
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, [4 x i64] }
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca i64
  %l70 = alloca %"compiler/eval:Ptr"
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, [4 x i64] }
  %l73 = alloca i32
  %l74 = alloca %"compiler/mir:Range"
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/mir:Lvalue"
  %l80 = alloca %"compiler/mir:Lvalue"
  %l81 = alloca { i64, [4 x i64] }
  %l82 = alloca { %"compiler/eval:Ptr", i32 }
  %l83 = alloca %"compiler/eval:Ptr"
  %l84 = alloca i32
  %l85 = alloca { %"compiler/eval:Ptr", i32 }
  %l86 = alloca %"compiler/eval:Ptr"
  %l87 = alloca i32
  %l88 = alloca { %"compiler/eval:Ptr", i64 }
  %l89 = alloca %"compiler/eval:Ptr"
  %l90 = alloca i64
  %l91 = alloca { %"compiler/eval:Ptr", i64 }
  %l92 = alloca %"compiler/eval:Ptr"
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i32
  %l99 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca { i64, [21 x i64] }
  %l134 = alloca { i64, [21 x i64] }
  %l143 = alloca i1
  %l148 = alloca i1
  %l154 = alloca { i64, [21 x i64] }
  %l162 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l171 = alloca i64
  %l175 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l182 = alloca i64
  %l183 = alloca ptr
  %l186 = alloca i64
  %l189 = alloca %"compiler/eval:Ptr"
  %l191 = alloca { i64, [21 x i64] }
  %l195 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l207 = alloca i1
  %l209 = alloca { i64, ptr }
  %l215 = alloca i64
  %l223 = alloca { i64, ptr }
  %l225 = alloca { i64, [21 x i64] }
  %l229 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l236 = alloca i64
  %l252 = alloca i64
  %l254 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l274 = alloca ptr
  %l283 = alloca %"compiler/eval:Ptr"
  %l291 = alloca ptr
  %l294 = alloca { i64, [21 x i64] }
  %l302 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l322 = alloca i1
  %l327 = alloca { i64, ptr }
  %l329 = alloca { i64, [21 x i64] }
  %l336 = alloca { i64, [21 x i64] }
  %l361 = alloca { i64, [21 x i64] }
  %l373 = alloca i64
  %l377 = alloca i1
  %l382 = alloca i1
  %l386 = alloca i1
  %l389 = alloca i1
  %l393 = alloca ptr
  %l397 = alloca %"compiler/eval:Ptr"
  %l398 = alloca %"compiler/eval:Ptr"
  %l409 = alloca i1
  %l418 = alloca ptr
  %l421 = alloca { i64, [21 x i64] }
  %l425 = alloca { i64, [21 x i64] }
  %l429 = alloca { i64, [21 x i64] }
  %l439 = alloca { %"compiler/eval:Ptr", i32 }
  %l444 = alloca i64
  %l446 = alloca { i64, ptr }
  %l448 = alloca { i64, ptr }
  %l450 = alloca { i64, [21 x i64] }
  %l454 = alloca { i64, [21 x i64] }
  %l456 = alloca { i64, [21 x i64] }
  %l460 = alloca i64
  %l464 = alloca { i64, ptr }
  %l466 = alloca { i64, [21 x i64] }
  %l477 = alloca { %"compiler/eval:Ptr", i32 }
  %l482 = alloca i64
  %l483 = alloca ptr
  %l487 = alloca i64
  %l492 = alloca i64
  %l496 = alloca { i64, ptr }
  %l498 = alloca { i64, [21 x i64] }
  %l508 = alloca i64
  %l511 = alloca i1
  %l514 = alloca i1
  %l515 = alloca i1
  %l521 = alloca %"compiler/eval:scope"
  %l528 = alloca { i64, ptr }
  %l530 = alloca { i64, [21 x i64] }
  %l544 = alloca { i64, [21 x i64] }
  %l553 = alloca i64
  %l558 = alloca ptr
  %l561 = alloca i64
  %l562 = alloca i64
  %l563 = alloca ptr
  %l567 = alloca %"compiler/eval:Ptr"
  %l568 = alloca %"compiler/eval:Ptr"
  %l569 = alloca { i64, [21 x i64] }
  %l577 = alloca ptr
  %l581 = alloca i64
  %l583 = alloca i64
  %l587 = alloca %"compiler/eval:Ptr"
  %l591 = alloca ptr
  %l592 = alloca %"compiler/eval:Ptr"
  %l596 = alloca i32
  %l598 = alloca { i64, [21 x i64] }
  %l616 = alloca { i64, [21 x i64] }
  %l622 = alloca i64
  %l625 = alloca i64
  %l626 = alloca i32
  %l630 = alloca ptr
  %l633 = alloca i64
  %l637 = alloca i64
  %l642 = alloca i64
  %l646 = alloca { i64, ptr }
  %l648 = alloca { i64, [21 x i64] }
  %l660 = alloca { %"compiler/eval:Ptr", i32 }
  %l666 = alloca { %"compiler/eval:Ptr", i32 }
  %l672 = alloca { %"compiler/eval:Ptr", i64 }
  %l678 = alloca { %"compiler/eval:Ptr", i64 }
  %l681 = alloca ptr
  %l685 = alloca i64
  %l689 = alloca i32
  %l690 = alloca i64
  %l695 = alloca i1
  %l699 = alloca i1
  %l705 = alloca ptr
  %l706 = alloca %"compiler/eval:Ptr"
  %l707 = alloca %"compiler/eval:Ptr"
  %l708 = alloca i64
  %l709 = alloca ptr
  %l712 = alloca i32
  %l713 = alloca i64
  %l715 = alloca { i64, [21 x i64] }
  %l731 = alloca { i64, ptr }
  %l732 = alloca i64
  %t1010 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 27
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l99, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:cfn", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i32 0, i32 13
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l101, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t16 = mul i64 %t12, %t13
  %t18 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb1, label %bb2
bb1:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %t27, i64 %t28, i64 %t29, i64 %t30, i64 %t31)
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 23
  %t40 = load i1, ptr %t39, !tbaa !21
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb4, label %bb5
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 59
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l117, !tbaa !27
  %t48 = load i64, ptr %l1, !tbaa !24
  store i64 %t48, ptr %l118, !tbaa !24
  %t49 = load i64, ptr %l118, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/eval:frame", ptr %t51, i64 %t49
  %t53 = getelementptr %"compiler/eval:frame", ptr %t52, i32 0, i32 2
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = add i64 %t54, 1
  %t59 = load i64, ptr %l118, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr %"compiler/eval:frame", ptr %t61, i64 %t59
  %t63 = getelementptr %"compiler/eval:frame", ptr %t62, i32 0, i32 2
  store i64 %t57, ptr %t63, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
bb7:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 27
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l123, !tbaa !27
  %t68 = load i64, ptr %l2, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr %"compiler/eval:cfn", ptr %t71, i64 %t68
  %t73 = getelementptr %"compiler/eval:cfn", ptr %t72, i32 0, i32 10
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l125, !tbaa !27
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i1, ptr %t78, i64 %t75
  %t80 = load i1, ptr %t79, !tbaa !31
  store i1 %t80, ptr %l5, !tbaa !21
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/eval:Machine", ptr %t82, i32 0, i32 27
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l129, !tbaa !27
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr %"compiler/eval:cfn", ptr %t89, i64 %t86
  %t91 = getelementptr %"compiler/eval:cfn", ptr %t90, i32 0, i32 7
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l131, !tbaa !27
  %t93 = load i64, ptr %l3, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, [21 x i64] }, ptr %t96, i64 %t93
  call void @llvm.memmove.p0.p0.i64(ptr %l133, ptr %t97, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l133, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l134, ptr %l6, i64 176, i1 false)
  %t98 = load { i64, [21 x i64] }, ptr %l134
  %t99 = extractvalue { i64, [21 x i64] } %t98, 0
  %t100 = icmp eq i64 %t99, 0
  br i1 %t100, label %bb8, label %bb9
bb8:
  %t102 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t102, i32 0, i32 0
  %t104 = load %"compiler/source:Span", ptr %t103
  store %"compiler/source:Span" %t104, ptr %l7
  %t106 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t106, i32 0, i32 1
  %t108 = load %"compiler/mir:Lvalue", ptr %t107
  store %"compiler/mir:Lvalue" %t108, ptr %l8
  %t110 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t110, i32 0, i32 2
  %t112 = load { i64, [15 x i64] }, ptr %t111
  store { i64, [15 x i64] } %t112, ptr %l9
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l2, !tbaa !24
  %t116 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t114, i64 %t115, %"compiler/source:Span" %t116)
  br label %bb11
bb11:
  %t120 = load i1, ptr %l5, !tbaa !21
  br i1 %t120, label %bb12, label %bb13
bb12:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  %t124 = load %"compiler/mir:Lvalue", ptr %l8
  %t125 = load { i64, [15 x i64] }, ptr %l9
  %t130 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalsReady(ptr %v0, ptr %t122, i64 %t123, %"compiler/mir:Lvalue" %t124, { i64, [15 x i64] } %t125)
  store i1 %t130, ptr %l148
  br label %bb14
bb13:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb15
bb14:
  %t131 = load i1, ptr %l148, !tbaa !21
  %t132 = xor i1 %t131, true
  store i1 %t132, ptr %l143, !tbaa !21
  br label %bb15
bb15:
  %t134 = load i1, ptr %l143, !tbaa !21
  br i1 %t134, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t137 = load %"compiler/mir:Lvalue", ptr %l8
  %t138 = load { i64, [15 x i64] }, ptr %l9
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eassign(ptr %v0, ptr %t135, i64 %t136, %"compiler/mir:Lvalue" %t137, { i64, [15 x i64] } %t138)
  br label %bb19
bb19:
  br label %bb278
bb20:
  call void @llvm.memmove.p0.p0.i64(ptr %l154, ptr %l6, i64 176, i1 false)
  %t143 = load { i64, [21 x i64] }, ptr %l154
  %t144 = extractvalue { i64, [21 x i64] } %t143, 0
  %t145 = icmp eq i64 %t144, 1
  br i1 %t145, label %bb21, label %bb22
bb21:
  %t147 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32 }, ptr %t147, i32 0, i32 0
  %t149 = load %"compiler/source:Span", ptr %t148
  store %"compiler/source:Span" %t149, ptr %l10
  %t151 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32 }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l11, !tbaa !23
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l2, !tbaa !24
  %t157 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t155, i64 %t156, %"compiler/source:Span" %t157)
  br label %bb24
bb24:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/eval:Machine", ptr %t161, i32 0, i32 27
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %l162, !tbaa !27
  %t165 = load i64, ptr %l2, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr %"compiler/eval:cfn", ptr %t168, i64 %t165
  %t170 = getelementptr %"compiler/eval:cfn", ptr %t169, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l164, !tbaa !27
  %t172 = load i32, ptr %l11, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t176 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr %"compiler/mir:Local", ptr %t177, i64 %t174
  %t179 = load %"compiler/mir:Local", ptr %t178
  store %"compiler/mir:Local" %t179, ptr %l12
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i64, ptr %l1, !tbaa !24
  %t183 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 4
  %t184 = load { i64, [1 x i64] }, ptr %t183
  %t188 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t181, i64 %t182, { i64, [1 x i64] } %t184)
  store i64 %t188, ptr %l171
  br label %bb25
bb25:
  %t189 = load i64, ptr %l171, !tbaa !24
  store i64 %t189, ptr %l13, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/eval:Machine", ptr %t190, i32 0, i32 23
  %t193 = load i1, ptr %t192, !tbaa !21
  br i1 %t193, label %bb26, label %bb27
bb26:
  br label %ret
bb27:
  br label %bb28
bb28:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/eval:Machine", ptr %t195, i32 0, i32 61
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l175, !tbaa !27
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/eval:Machine", ptr %t199, i32 0, i32 59
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l177, !tbaa !27
  %t203 = load i64, ptr %l1, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr %"compiler/eval:frame", ptr %t206, i64 %t203
  %t208 = getelementptr %"compiler/eval:frame", ptr %t207, i32 0, i32 3
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i32, ptr %l11, !tbaa !23
  %t212 = sext i32 %t210 to i64
  %t215 = add i64 %t209, %t212
  store i64 %t215, ptr %l182, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l183, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t219 = load i32, ptr %t218, !tbaa !23
  %t222 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t217, i32 %t219)
  store i64 %t222, ptr %l186
  br label %bb29
bb29:
  %t223 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t224 = load i64, ptr %l13, !tbaa !24
  %t225 = load ptr, ptr %l183, !tbaa !29
  %t226 = load i64, ptr %l186, !tbaa !24
  %t229 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t225, i64 %t226, i64 %t223, i64 %t224)
  store %"compiler/eval:Ptr" %t229, ptr %l189
  br label %bb30
bb30:
  %t230 = getelementptr %"compiler/eval:Ptr", ptr %l189, i32 0, i32 0
  %t231 = load i64, ptr %t230, !tbaa !24
  %t233 = load i64, ptr %l182, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i64, ptr %t235, i64 %t233
  store i64 %t231, ptr %t236, !tbaa !34
  br label %bb278
bb31:
  call void @llvm.memmove.p0.p0.i64(ptr %l191, ptr %l6, i64 176, i1 false)
  %t237 = load { i64, [21 x i64] }, ptr %l191
  %t238 = extractvalue { i64, [21 x i64] } %t237, 0
  %t239 = icmp eq i64 %t238, 2
  br i1 %t239, label %bb32, label %bb33
bb32:
  %t241 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32 }, ptr %t241, i32 0, i32 1
  %t243 = load i32, ptr %t242
  store i32 %t243, ptr %l14, !tbaa !23
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/eval:Machine", ptr %t245, i32 0, i32 59
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l195, !tbaa !27
  %t249 = load i64, ptr %l1, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr %"compiler/eval:frame", ptr %t252, i64 %t249
  %t254 = getelementptr %"compiler/eval:frame", ptr %t253, i32 0, i32 3
  %t255 = load i64, ptr %t254, !tbaa !24
  %t256 = load i32, ptr %l14, !tbaa !23
  %t258 = sext i32 %t256 to i64
  %t261 = add i64 %t255, %t258
  store i64 %t261, ptr %l15, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/eval:Machine", ptr %t263, i32 0, i32 61
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l202, !tbaa !27
  %t267 = load i64, ptr %l15, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i64, ptr %t270, i64 %t267
  %t272 = load i64, ptr %t271, !tbaa !34
  store i64 %t272, ptr %l16, !tbaa !24
  %t274 = load i64, ptr %l16, !tbaa !24
  %t276 = icmp ne i64 %t274, 0
  br i1 %t276, label %bb35, label %bb36
bb35:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/eval:Machine", ptr %t278, i32 0, i32 50
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  store { i64, ptr } %t281, ptr %l209, !tbaa !27
  %t282 = load i64, ptr %l16, !tbaa !24
  %t283 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t286 = and i64 %t282, %t283
  %t288 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr %"compiler/eval:alloc", ptr %t289, i64 %t286
  %t291 = getelementptr %"compiler/eval:alloc", ptr %t290, i32 0, i32 3
  %t292 = load i64, ptr %t291, !tbaa !24
  %t293 = load i64, ptr %l16, !tbaa !24
  %t294 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t294, ptr %l215, !tbaa !24
  %t296 = load i64, ptr %l215, !tbaa !24
  %t297 = load i64, ptr %l215, !tbaa !24
  %t298 = ashr i64 %t293, %t297
  %t301 = icmp eq i64 %t292, %t298
  store i1 %t301, ptr %l207, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb37
bb37:
  %t303 = load i1, ptr %l207, !tbaa !21
  br i1 %t303, label %bb38, label %bb39
bb38:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i64, ptr %l16, !tbaa !24
  %t306 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t309 = and i64 %t305, %t306
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t304, i64 %t309)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/eval:Machine", ptr %t312, i32 0, i32 61
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l223, !tbaa !27
  %t316 = load i64, ptr %l15, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i64, ptr %t319, i64 %t316
  store i64 0, ptr %t320, !tbaa !34
  br label %bb278
bb42:
  call void @llvm.memmove.p0.p0.i64(ptr %l225, ptr %l6, i64 176, i1 false)
  %t321 = load { i64, [21 x i64] }, ptr %l225
  %t322 = extractvalue { i64, [21 x i64] } %t321, 0
  %t323 = icmp eq i64 %t322, 3
  br i1 %t323, label %bb43, label %bb44
bb43:
  %t325 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", i32 }, ptr %t325, i32 0, i32 1
  %t327 = load i32, ptr %t326
  store i32 %t327, ptr %l17, !tbaa !23
  br label %bb45
bb44:
  br label %bb77
bb45:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/eval:Machine", ptr %t329, i32 0, i32 27
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l229, !tbaa !27
  %t333 = load i64, ptr %l2, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr %"compiler/eval:cfn", ptr %t336, i64 %t333
  %t338 = getelementptr %"compiler/eval:cfn", ptr %t337, i32 0, i32 2
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  store { i64, ptr } %t339, ptr %l231, !tbaa !27
  %t340 = load i32, ptr %l17, !tbaa !23
  %t342 = sext i32 %t340 to i64
  %t344 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr %"compiler/mir:ScopeInfo", ptr %t345, i64 %t342
  %t347 = load %"compiler/mir:ScopeInfo", ptr %t346
  store %"compiler/mir:ScopeInfo" %t347, ptr %l18
  %t349 = getelementptr %"compiler/mir:ScopeInfo", ptr %l18, i32 0, i32 0
  %t350 = load i32, ptr %t349, !range !{i32 0, i32 7}
  store i32 %t350, ptr %l19
  %t352 = load i32, ptr %l19, !range !{i32 0, i32 7}
  %t354 = trunc i64 5 to i32
  %t355 = icmp eq i32 %t352, %t354
  br i1 %t355, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t357 = load i64, ptr @G_2ecompiler_2feval_2esInert, !tbaa !24
  store i64 %t357, ptr %l236, !tbaa !24
  br label %bb66
bb49:
  %t359 = load i32, ptr %l19, !range !{i32 0, i32 7}
  %t361 = trunc i64 6 to i32
  %t362 = icmp eq i32 %t359, %t361
  br i1 %t362, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t364 = load i64, ptr @G_2ecompiler_2feval_2esBuilder, !tbaa !24
  store i64 %t364, ptr %l236, !tbaa !24
  br label %bb66
bb53:
  %t366 = load i32, ptr %l19, !range !{i32 0, i32 7}
  %t368 = trunc i64 4 to i32
  %t369 = icmp eq i32 %t366, %t368
  br i1 %t369, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t371 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  store i64 %t371, ptr %l236, !tbaa !24
  br label %bb66
bb57:
  %t373 = load i32, ptr %l19, !range !{i32 0, i32 7}
  %t375 = trunc i64 3 to i32
  %t376 = icmp eq i32 %t373, %t375
  br i1 %t376, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t378 = load i64, ptr @G_2ecompiler_2feval_2esJoin, !tbaa !24
  store i64 %t378, ptr %l236, !tbaa !24
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  %t380 = load i64, ptr @G_2ecompiler_2feval_2esBlock, !tbaa !24
  store i64 %t380, ptr %l236, !tbaa !24
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_fe5b662c8cf4b58_7006b7c636f2421c)
  unreachable
bb66:
  %t382 = load i64, ptr %l236, !tbaa !24
  store i64 %t382, ptr %l20, !tbaa !24
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l20, !tbaa !24
  %t387 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t383, i64 %t384)
  store i64 %t387, ptr %l252
  br label %bb67
bb67:
  %t388 = load i64, ptr %l252, !tbaa !24
  store i64 %t388, ptr %l21, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/eval:Machine", ptr %t389, i32 0, i32 61
  %t392 = load { i64, ptr }, ptr %t391, !tbaa !27
  store { i64, ptr } %t392, ptr %l254, !tbaa !27
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/eval:Machine", ptr %t393, i32 0, i32 59
  %t396 = load { i64, ptr }, ptr %t395, !tbaa !27
  store { i64, ptr } %t396, ptr %l256, !tbaa !27
  %t397 = load i64, ptr %l1, !tbaa !24
  %t399 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr %"compiler/eval:frame", ptr %t400, i64 %t397
  %t402 = getelementptr %"compiler/eval:frame", ptr %t401, i32 0, i32 4
  %t403 = load i64, ptr %t402, !tbaa !24
  %t404 = load i32, ptr %l17, !tbaa !23
  %t406 = sext i32 %t404 to i64
  %t409 = add i64 %t403, %t406
  %t410 = load i64, ptr %l21, !tbaa !24
  %t413 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr i64, ptr %t414, i64 %t409
  store i64 %t410, ptr %t415, !tbaa !34
  %t416 = load i64, ptr %l20, !tbaa !24
  %t417 = load i64, ptr @G_2ecompiler_2feval_2esJoin, !tbaa !24
  %t420 = icmp eq i64 %t416, %t417
  br i1 %t420, label %bb68, label %bb69
bb68:
  %t422 = load i64, ptr %l21, !tbaa !24
  %t423 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t426 = and i64 %t422, %t423
  %t428 = getelementptr %"compiler/mir:ScopeInfo", ptr %l18, i32 0, i32 4
  %t429 = load i32, ptr %t428, !tbaa !23
  %t431 = sext i32 %t429 to i64
  store i64 %t431, ptr %l23, !tbaa !24
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/eval:Machine", ptr %t433, i32 0, i32 53
  %t439 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t435, i64 %t426)
  store ptr %t439, ptr %l274
  br label %bb70
bb69:
  br label %bb71
bb70:
  %t440 = load ptr, ptr %l274, !tbaa !29
  %t442 = load i64, ptr %l23, !tbaa !24
  %t445 = getelementptr %"compiler/eval:scope", ptr %t440, i32 0, i32 14
  store i64 %t442, ptr %t445, !tbaa !24
  br label %bb71
bb71:
  %t446 = load i64, ptr %l20, !tbaa !24
  %t447 = load i64, ptr @G_2ecompiler_2feval_2esBuilder, !tbaa !24
  %t450 = icmp eq i64 %t446, %t447
  br i1 %t450, label %bb72, label %bb73
bb72:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t454 = load i64, ptr %l21, !tbaa !24
  %t458 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t452, i64 64, i64 %t453, i64 %t454)
  store %"compiler/eval:Ptr" %t458, ptr %l283
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t459 = load %"compiler/eval:Ptr", ptr %l283
  store %"compiler/eval:Ptr" %t459, ptr %l25
  %t460 = load i64, ptr %l21, !tbaa !24
  %t461 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t464 = and i64 %t460, %t461
  %t466 = getelementptr %"compiler/eval:Ptr", ptr %l25, i32 0, i32 0
  %t467 = load i64, ptr %t466, !tbaa !24
  store i64 %t467, ptr %l27, !tbaa !24
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/eval:Machine", ptr %t469, i32 0, i32 53
  %t475 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t471, i64 %t464)
  store ptr %t475, ptr %l291
  br label %bb75
bb75:
  %t476 = load ptr, ptr %l291, !tbaa !29
  %t478 = load i64, ptr %l27, !tbaa !24
  %t481 = getelementptr %"compiler/eval:scope", ptr %t476, i32 0, i32 8
  store i64 %t478, ptr %t481, !tbaa !24
  br label %bb76
bb76:
  br label %bb278
bb77:
  call void @llvm.memmove.p0.p0.i64(ptr %l294, ptr %l6, i64 176, i1 false)
  %t482 = load { i64, [21 x i64] }, ptr %l294
  %t483 = extractvalue { i64, [21 x i64] } %t482, 0
  %t484 = icmp eq i64 %t483, 4
  br i1 %t484, label %bb78, label %bb79
bb78:
  %t486 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t487 = getelementptr { %"compiler/source:Span", i32 }, ptr %t486, i32 0, i32 1
  %t488 = load i32, ptr %t487
  store i32 %t488, ptr %l29, !tbaa !23
  br label %bb80
bb79:
  br label %bb87
bb80:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i64, ptr %l1, !tbaa !24
  %t492 = load i32, ptr %l29, !tbaa !23
  %t494 = sext i32 %t492 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropDefers(ptr %v0, ptr %t490, i64 %t491, i64 %t494, i1 false)
  br label %bb81
bb81:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/eval:Machine", ptr %t498, i32 0, i32 61
  %t501 = load { i64, ptr }, ptr %t500, !tbaa !27
  store { i64, ptr } %t501, ptr %l302, !tbaa !27
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/eval:Machine", ptr %t502, i32 0, i32 59
  %t505 = load { i64, ptr }, ptr %t504, !tbaa !27
  store { i64, ptr } %t505, ptr %l304, !tbaa !27
  %t506 = load i64, ptr %l1, !tbaa !24
  %t508 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr %"compiler/eval:frame", ptr %t509, i64 %t506
  %t511 = getelementptr %"compiler/eval:frame", ptr %t510, i32 0, i32 4
  %t512 = load i64, ptr %t511, !tbaa !24
  %t513 = load i32, ptr %l29, !tbaa !23
  %t515 = sext i32 %t513 to i64
  %t518 = add i64 %t512, %t515
  %t520 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = getelementptr i64, ptr %t521, i64 %t518
  %t523 = load i64, ptr %t522, !tbaa !34
  store i64 %t523, ptr %l30, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/eval:Machine", ptr %t525, i32 0, i32 61
  %t528 = load { i64, ptr }, ptr %t527, !tbaa !27
  store { i64, ptr } %t528, ptr %l312, !tbaa !27
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/eval:Machine", ptr %t529, i32 0, i32 59
  %t532 = load { i64, ptr }, ptr %t531, !tbaa !27
  store { i64, ptr } %t532, ptr %l314, !tbaa !27
  %t533 = load i64, ptr %l1, !tbaa !24
  %t535 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr %"compiler/eval:frame", ptr %t536, i64 %t533
  %t538 = getelementptr %"compiler/eval:frame", ptr %t537, i32 0, i32 4
  %t539 = load i64, ptr %t538, !tbaa !24
  %t540 = load i32, ptr %l29, !tbaa !23
  %t542 = sext i32 %t540 to i64
  %t545 = add i64 %t539, %t542
  %t547 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !27
  %t549 = getelementptr i64, ptr %t548, i64 %t545
  store i64 0, ptr %t549, !tbaa !34
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load i64, ptr %l30, !tbaa !24
  %t554 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t550, i64 %t551)
  store i1 %t554, ptr %l322
  br label %bb82
bb82:
  %t555 = load i1, ptr %l322, !tbaa !21
  br i1 %t555, label %bb83, label %bb84
bb83:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/eval:Machine", ptr %t556, i32 0, i32 63
  %t559 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t558, i64 %t559)
  br label %bb85
bb84:
  br label %bb86
bb85:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/eval:Machine", ptr %t562, i32 0, i32 59
  %t565 = load { i64, ptr }, ptr %t564, !tbaa !27
  store { i64, ptr } %t565, ptr %l327, !tbaa !27
  %t566 = load i64, ptr %l1, !tbaa !24
  %t568 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !27
  %t570 = getelementptr %"compiler/eval:frame", ptr %t569, i64 %t566
  %t571 = getelementptr %"compiler/eval:frame", ptr %t570, i32 0, i32 10
  store i1 true, ptr %t571, !tbaa !21
  br label %ret
bb86:
  br label %bb278
bb87:
  call void @llvm.memmove.p0.p0.i64(ptr %l329, ptr %l6, i64 176, i1 false)
  %t572 = load { i64, [21 x i64] }, ptr %l329
  %t573 = extractvalue { i64, [21 x i64] } %t572, 0
  %t574 = icmp eq i64 %t573, 14
  br i1 %t574, label %bb88, label %bb89
bb88:
  %t576 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t577 = getelementptr { %"compiler/source:Span" }, ptr %t576, i32 0, i32 0
  %t578 = load %"compiler/source:Span", ptr %t577
  store %"compiler/source:Span" %t578, ptr %l31
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load i64, ptr %l1, !tbaa !24
  %t582 = load i64, ptr %l2, !tbaa !24
  %t583 = load %"compiler/source:Span", ptr %l31
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %t580, i64 %t581, i64 %t582, %"compiler/source:Span" %t583)
  br label %bb91
bb91:
  br label %bb278
bb92:
  call void @llvm.memmove.p0.p0.i64(ptr %l336, ptr %l6, i64 176, i1 false)
  %t588 = load { i64, [21 x i64] }, ptr %l336
  %t589 = extractvalue { i64, [21 x i64] } %t588, 0
  %t590 = icmp eq i64 %t589, 19
  br i1 %t590, label %bb93, label %bb94
bb93:
  %t592 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t593 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t592, i32 0, i32 1
  %t594 = load i32, ptr %t593
  store i32 %t594, ptr %l32, !tbaa !23
  %t596 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t597 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t596, i32 0, i32 2
  %t598 = load i32, ptr %t597
  store i32 %t598, ptr %l33, !tbaa !23
  br label %bb95
bb94:
  br label %bb106
bb95:
  %t600 = load i32, ptr %l33, !tbaa !23
  %t601 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t604 = icmp eq i32 %t600, %t601
  br i1 %t604, label %bb96, label %bb97
bb96:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load i64, ptr %l1, !tbaa !24
  %t608 = load i32, ptr %l32, !tbaa !23
  %t610 = sext i32 %t608 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropDefers(ptr %v0, ptr %t606, i64 %t607, i64 %t610, i1 true)
  br label %bb98
bb97:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/eval:Machine", ptr %t614, i32 0, i32 1
  %t617 = load i32, ptr %t616, !range !{i32 0, i32 2}
  %t619 = trunc i64 1 to i32
  %t620 = icmp eq i32 %t617, %t619
  br i1 %t620, label %bb99, label %bb100
bb98:
  br label %bb105
bb99:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/eval:Machine", ptr %t622, i32 0, i32 67
  %t625 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t624, i64 %t625)
  br label %bb101
bb100:
  br label %bb104
bb101:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/eval:Machine", ptr %t628, i32 0, i32 68
  %t631 = load i32, ptr %l32, !tbaa !23
  %t633 = sext i32 %t631 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t630, i64 %t633)
  br label %bb102
bb102:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/eval:Machine", ptr %t636, i32 0, i32 69
  %t639 = load i32, ptr %l33, !tbaa !23
  %t641 = sext i32 %t639 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t638, i64 %t641)
  br label %bb103
bb103:
  br label %bb104
bb104:
  br label %bb105
bb105:
  br label %bb278
bb106:
  call void @llvm.memmove.p0.p0.i64(ptr %l361, ptr %l6, i64 176, i1 false)
  %t644 = load { i64, [21 x i64] }, ptr %l361
  %t645 = extractvalue { i64, [21 x i64] } %t644, 0
  %t646 = icmp eq i64 %t645, 5
  br i1 %t646, label %bb107, label %bb108
bb107:
  %t648 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t649 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t648, i32 0, i32 0
  %t650 = load %"compiler/source:Span", ptr %t649
  store %"compiler/source:Span" %t650, ptr %l34
  %t652 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t652, i32 0, i32 1
  %t654 = load { i64, [1 x i64] }, ptr %t653
  store { i64, [1 x i64] } %t654, ptr %l35
  %t656 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t657 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t656, i32 0, i32 2
  %t658 = load i32, ptr %t657
  store i32 %t658, ptr %l36, !tbaa !23
  %t660 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t661 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t660, i32 0, i32 3
  %t662 = load { i64, [4 x i64] }, ptr %t661
  store { i64, [4 x i64] } %t662, ptr %l37
  br label %bb109
bb108:
  br label %bb136
bb109:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load i64, ptr %l2, !tbaa !24
  %t666 = load %"compiler/source:Span", ptr %l34
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t664, i64 %t665, %"compiler/source:Span" %t666)
  br label %bb110
bb110:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load i64, ptr %l1, !tbaa !24
  %t672 = load { i64, [1 x i64] }, ptr %l35
  %t676 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t670, i64 %t671, { i64, [1 x i64] } %t672)
  store i64 %t676, ptr %l373
  br label %bb111
bb111:
  %t677 = load i64, ptr %l373, !tbaa !24
  store i64 %t677, ptr %l38, !tbaa !24
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/eval:Machine", ptr %t678, i32 0, i32 1
  %t681 = load i32, ptr %t680, !range !{i32 0, i32 2}
  %t683 = trunc i64 0 to i32
  %t684 = icmp eq i32 %t681, %t683
  br i1 %t684, label %bb112, label %bb113
bb112:
  %t686 = load i64, ptr %l38, !tbaa !24
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t689 = getelementptr %"compiler/eval:Machine", ptr %t687, i32 0, i32 71
  %t690 = load i64, ptr %t689, !tbaa !24
  %t693 = icmp eq i64 %t686, %t690
  br i1 %t693, label %bb114, label %bb115
bb113:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb121
bb114:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/eval:Machine", ptr %t695, i32 0, i32 74
  %t698 = load i64, ptr %t697, !tbaa !24
  %t700 = icmp sge i64 %t698, 0
  store i1 %t700, ptr %l382, !tbaa !21
  br label %bb116
bb115:
  store i1 false, ptr %l382, !tbaa !21
  br label %bb116
bb116:
  %t702 = load i1, ptr %l382, !tbaa !21
  br i1 %t702, label %bb117, label %bb118
bb117:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i64, ptr %l1, !tbaa !24
  %t707 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2einitFrame(ptr %v0, ptr %t703, i64 %t704)
  store i1 %t707, ptr %l389
  br label %bb119
bb118:
  store i1 false, ptr %l386, !tbaa !21
  br label %bb120
bb119:
  %t708 = load i1, ptr %l389, !tbaa !21
  store i1 %t708, ptr %l386, !tbaa !21
  br label %bb120
bb120:
  %t709 = load i1, ptr %l386, !tbaa !21
  %t710 = xor i1 %t709, true
  store i1 %t710, ptr %l377, !tbaa !21
  br label %bb121
bb121:
  %t712 = load i1, ptr %l377, !tbaa !21
  br i1 %t712, label %bb122, label %bb123
bb122:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDestructor, !tbaa !27
  %t715 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t715, ptr %t713, { i64, ptr } %t714)
  br label %bb124
bb123:
  br label %bb125
bb124:
  br label %ret
bb125:
  %t718 = load ptr, ptr %l0, !tbaa !29
  store ptr %t718, ptr %l393, !tbaa !29
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i64, ptr %l1, !tbaa !24
  %t721 = load { i64, [4 x i64] }, ptr %l37
  %t725 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t719, i64 %t720, { i64, [4 x i64] } %t721, i64 1)
  store %"compiler/eval:Ptr" %t725, ptr %l397
  br label %bb126
bb126:
  %t726 = load ptr, ptr %l393, !tbaa !29
  %t727 = load %"compiler/eval:Ptr", ptr %l397
  %t728 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t726, %"compiler/eval:Ptr" %t727)
  store %"compiler/eval:Ptr" %t728, ptr %l398
  br label %bb127
bb127:
  %t729 = load %"compiler/eval:Ptr", ptr %l398
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load i64, ptr %l38, !tbaa !24
  %t732 = load i64, ptr @G_2ecompiler_2feval_2egDtor, !tbaa !24
  %t733 = load i32, ptr %l36, !tbaa !23
  %t735 = sext i32 %t733 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %t730, i64 %t731, i64 %t732, i64 %t735, %"compiler/eval:Ptr" %t729)
  br label %bb128
bb128:
  %t742 = load i64, ptr %l38, !tbaa !24
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = getelementptr %"compiler/eval:Machine", ptr %t743, i32 0, i32 71
  %t746 = load i64, ptr %t745, !tbaa !24
  %t749 = icmp eq i64 %t742, %t746
  br i1 %t749, label %bb129, label %bb130
bb129:
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t753 = getelementptr %"compiler/eval:Machine", ptr %t751, i32 0, i32 74
  %t754 = load i64, ptr %t753, !tbaa !24
  %t756 = icmp sge i64 %t754, 0
  store i1 %t756, ptr %l409, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l409, !tbaa !21
  br label %bb131
bb131:
  %t758 = load i1, ptr %l409, !tbaa !21
  br i1 %t758, label %bb132, label %bb133
bb132:
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t761 = getelementptr %"compiler/eval:Machine", ptr %t759, i32 0, i32 74
  %t762 = load i64, ptr %t761, !tbaa !24
  store i1 true, ptr %l41, !tbaa !21
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t766 = getelementptr %"compiler/eval:Machine", ptr %t764, i32 0, i32 43
  %t770 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t766, i64 %t762)
  store ptr %t770, ptr %l418
  br label %bb134
bb133:
  br label %bb135
bb134:
  %t771 = load ptr, ptr %l418, !tbaa !29
  %t773 = load i1, ptr %l41, !tbaa !21
  %t776 = getelementptr %"compiler/eval:global", ptr %t771, i32 0, i32 7
  store i1 %t773, ptr %t776, !tbaa !21
  br label %bb135
bb135:
  br label %bb278
bb136:
  call void @llvm.memmove.p0.p0.i64(ptr %l421, ptr %l6, i64 176, i1 false)
  %t777 = load { i64, [21 x i64] }, ptr %l421
  %t778 = extractvalue { i64, [21 x i64] } %t777, 0
  %t779 = icmp eq i64 %t778, 6
  br i1 %t779, label %bb137, label %bb138
bb137:
  %t781 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t782 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t781, i32 0, i32 0
  %t783 = load %"compiler/source:Span", ptr %t782
  store %"compiler/source:Span" %t783, ptr %l43
  %t785 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t785, i32 0, i32 1
  %t787 = load %"compiler/mir:Lvalue", ptr %t786
  store %"compiler/mir:Lvalue" %t787, ptr %l44
  br label %bb143
bb138:
  call void @llvm.memmove.p0.p0.i64(ptr %l425, ptr %l6, i64 176, i1 false)
  %t789 = load { i64, [21 x i64] }, ptr %l425
  %t790 = extractvalue { i64, [21 x i64] } %t789, 0
  %t791 = icmp eq i64 %t790, 7
  br i1 %t791, label %bb139, label %bb140
bb139:
  %t793 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t794 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t793, i32 0, i32 0
  %t795 = load %"compiler/source:Span", ptr %t794
  store %"compiler/source:Span" %t795, ptr %l43
  %t797 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t798 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t797, i32 0, i32 1
  %t799 = load %"compiler/mir:Lvalue", ptr %t798
  store %"compiler/mir:Lvalue" %t799, ptr %l44
  br label %bb143
bb140:
  call void @llvm.memmove.p0.p0.i64(ptr %l429, ptr %l6, i64 176, i1 false)
  %t801 = load { i64, [21 x i64] }, ptr %l429
  %t802 = extractvalue { i64, [21 x i64] } %t801, 0
  %t803 = icmp eq i64 %t802, 8
  br i1 %t803, label %bb141, label %bb142
bb141:
  %t805 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t806 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t805, i32 0, i32 0
  %t807 = load %"compiler/source:Span", ptr %t806
  store %"compiler/source:Span" %t807, ptr %l43
  %t809 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t810 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t809, i32 0, i32 1
  %t811 = load %"compiler/mir:Lvalue", ptr %t810
  store %"compiler/mir:Lvalue" %t811, ptr %l44
  br label %bb143
bb142:
  br label %bb152
bb143:
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t814 = load i64, ptr %l2, !tbaa !24
  %t815 = load %"compiler/source:Span", ptr %l43
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t813, i64 %t814, %"compiler/source:Span" %t815)
  br label %bb144
bb144:
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t820 = load i64, ptr %l1, !tbaa !24
  %t821 = load %"compiler/mir:Lvalue", ptr %l44
  %t825 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t819, i64 %t820, %"compiler/mir:Lvalue" %t821)
  store { %"compiler/eval:Ptr", i32 } %t825, ptr %l439
  br label %bb145
bb145:
  %t826 = load { %"compiler/eval:Ptr", i32 }, ptr %l439
  store { %"compiler/eval:Ptr", i32 } %t826, ptr %l45
  %t827 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l45, i32 0, i32 0
  %t828 = load %"compiler/eval:Ptr", ptr %t827
  store %"compiler/eval:Ptr" %t828, ptr %l46
  %t830 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l45, i32 0, i32 1
  %t831 = load i32, ptr %t830, !tbaa !23
  store i32 %t831, ptr %l47, !tbaa !23
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t835 = getelementptr %"compiler/eval:Machine", ptr %t833, i32 0, i32 63
  %t837 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t835)
  store i64 %t837, ptr %l444
  br label %bb146
bb146:
  %t838 = load i64, ptr %l444, !tbaa !24
  store i64 %t838, ptr %l48, !tbaa !24
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t841 = getelementptr %"compiler/eval:Machine", ptr %t839, i32 0, i32 27
  %t842 = load { i64, ptr }, ptr %t841, !tbaa !27
  store { i64, ptr } %t842, ptr %l446, !tbaa !27
  %t843 = load i64, ptr %l2, !tbaa !24
  %t845 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t846 = load ptr, ptr %t845, !tbaa !27
  %t847 = getelementptr %"compiler/eval:cfn", ptr %t846, i64 %t843
  %t848 = getelementptr %"compiler/eval:cfn", ptr %t847, i32 0, i32 7
  %t849 = load { i64, ptr }, ptr %t848, !tbaa !27
  store { i64, ptr } %t849, ptr %l448, !tbaa !27
  %t850 = load i64, ptr %l3, !tbaa !24
  %t852 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t853 = load ptr, ptr %t852, !tbaa !27
  %t854 = getelementptr { i64, [21 x i64] }, ptr %t853, i64 %t850
  call void @llvm.memmove.p0.p0.i64(ptr %l450, ptr %t854, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %l450, i64 176, i1 false)
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t856 = load %"compiler/eval:Ptr", ptr %l46
  %t857 = load i32, ptr %l47, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %l454, ptr %l49, i64 176, i1 false)
  %t858 = load { i64, [21 x i64] }, ptr %l454
  %t859 = extractvalue { i64, [21 x i64] } %t858, 0
  %t860 = icmp eq i64 %t859, 8
  call void @llvm.memmove.p0.p0.i64(ptr %l456, ptr %l49, i64 176, i1 false)
  %t861 = load { i64, [21 x i64] }, ptr %l456
  %t862 = extractvalue { i64, [21 x i64] } %t861, 0
  %t863 = icmp eq i64 %t862, 7
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereleaseHeld(ptr %v0, ptr %t855, %"compiler/eval:Ptr" %t856, i32 %t857, i1 %t860, i1 %t863)
  br label %bb147
bb147:
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/eval:Machine", ptr %t869, i32 0, i32 63
  %t873 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t871)
  store i64 %t873, ptr %l460
  br label %bb148
bb148:
  %t874 = load i64, ptr %l48, !tbaa !24
  %t875 = load i64, ptr %l460, !tbaa !24
  %t877 = icmp sgt i64 %t875, %t874
  br i1 %t877, label %bb149, label %bb150
bb149:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t881 = getelementptr %"compiler/eval:Machine", ptr %t879, i32 0, i32 59
  %t882 = load { i64, ptr }, ptr %t881, !tbaa !27
  store { i64, ptr } %t882, ptr %l464, !tbaa !27
  %t883 = load i64, ptr %l1, !tbaa !24
  %t885 = getelementptr { i64, ptr }, ptr %l464, i32 0, i32 1
  %t886 = load ptr, ptr %t885, !tbaa !27
  %t887 = getelementptr %"compiler/eval:frame", ptr %t886, i64 %t883
  %t888 = getelementptr %"compiler/eval:frame", ptr %t887, i32 0, i32 10
  store i1 true, ptr %t888, !tbaa !21
  br label %ret
bb150:
  br label %bb151
bb151:
  br label %bb278
bb152:
  call void @llvm.memmove.p0.p0.i64(ptr %l466, ptr %l6, i64 176, i1 false)
  %t889 = load { i64, [21 x i64] }, ptr %l466
  %t890 = extractvalue { i64, [21 x i64] } %t889, 0
  %t891 = icmp eq i64 %t890, 9
  br i1 %t891, label %bb153, label %bb154
bb153:
  %t893 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t894 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t893, i32 0, i32 0
  %t895 = load %"compiler/source:Span", ptr %t894
  store %"compiler/source:Span" %t895, ptr %l50
  %t897 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t898 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t897, i32 0, i32 1
  %t899 = load i32, ptr %t898
  store i32 %t899, ptr %l51, !tbaa !23
  %t901 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t902 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t901, i32 0, i32 2
  %t903 = load %"compiler/mir:Lvalue", ptr %t902
  store %"compiler/mir:Lvalue" %t903, ptr %l52
  br label %bb155
bb154:
  br label %bb165
bb155:
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t906 = load i64, ptr %l2, !tbaa !24
  %t907 = load %"compiler/source:Span", ptr %l50
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t905, i64 %t906, %"compiler/source:Span" %t907)
  br label %bb156
bb156:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t912 = load i64, ptr %l1, !tbaa !24
  %t913 = load %"compiler/mir:Lvalue", ptr %l52
  %t917 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t911, i64 %t912, %"compiler/mir:Lvalue" %t913)
  store { %"compiler/eval:Ptr", i32 } %t917, ptr %l477
  br label %bb157
bb157:
  %t918 = load { %"compiler/eval:Ptr", i32 }, ptr %l477
  store { %"compiler/eval:Ptr", i32 } %t918, ptr %l53
  %t919 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l53, i32 0, i32 0
  %t920 = load %"compiler/eval:Ptr", ptr %t919
  store %"compiler/eval:Ptr" %t920, ptr %l54
  %t922 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l53, i32 0, i32 1
  %t923 = load i32, ptr %t922, !tbaa !23
  store i32 %t923, ptr %l55, !tbaa !23
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t927 = getelementptr %"compiler/eval:Machine", ptr %t925, i32 0, i32 63
  %t929 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t927)
  store i64 %t929, ptr %l482
  br label %bb158
bb158:
  %t930 = load i64, ptr %l482, !tbaa !24
  store i64 %t930, ptr %l56, !tbaa !24
  %t931 = load ptr, ptr %l0, !tbaa !29
  store ptr %t931, ptr %l483, !tbaa !29
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load i64, ptr %l1, !tbaa !24
  %t934 = load i32, ptr %l51, !tbaa !23
  %t938 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eheldScope(ptr %v0, ptr %t932, i64 %t933, i32 %t934)
  store i64 %t938, ptr %l487
  br label %bb159
bb159:
  %t939 = load %"compiler/eval:Ptr", ptr %l54
  %t940 = load i32, ptr %l55, !tbaa !23
  %t941 = load ptr, ptr %l483, !tbaa !29
  %t942 = load i64, ptr %l487, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2esettle(ptr %v0, ptr %t941, i64 %t942, %"compiler/eval:Ptr" %t939, i32 %t940)
  br label %bb160
bb160:
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t947 = getelementptr %"compiler/eval:Machine", ptr %t945, i32 0, i32 63
  %t949 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t947)
  store i64 %t949, ptr %l492
  br label %bb161
bb161:
  %t950 = load i64, ptr %l56, !tbaa !24
  %t951 = load i64, ptr %l492, !tbaa !24
  %t953 = icmp sgt i64 %t951, %t950
  br i1 %t953, label %bb162, label %bb163
bb162:
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t957 = getelementptr %"compiler/eval:Machine", ptr %t955, i32 0, i32 59
  %t958 = load { i64, ptr }, ptr %t957, !tbaa !27
  store { i64, ptr } %t958, ptr %l496, !tbaa !27
  %t959 = load i64, ptr %l1, !tbaa !24
  %t961 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t962 = load ptr, ptr %t961, !tbaa !27
  %t963 = getelementptr %"compiler/eval:frame", ptr %t962, i64 %t959
  %t964 = getelementptr %"compiler/eval:frame", ptr %t963, i32 0, i32 10
  store i1 true, ptr %t964, !tbaa !21
  br label %ret
bb163:
  br label %bb164
bb164:
  br label %bb278
bb165:
  call void @llvm.memmove.p0.p0.i64(ptr %l498, ptr %l6, i64 176, i1 false)
  %t965 = load { i64, [21 x i64] }, ptr %l498
  %t966 = extractvalue { i64, [21 x i64] } %t965, 0
  %t967 = icmp eq i64 %t966, 10
  br i1 %t967, label %bb166, label %bb167
bb166:
  %t969 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t970 = getelementptr { %"compiler/source:Span", i32 }, ptr %t969, i32 0, i32 0
  %t971 = load %"compiler/source:Span", ptr %t970
  store %"compiler/source:Span" %t971, ptr %l57
  %t973 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t974 = getelementptr { %"compiler/source:Span", i32 }, ptr %t973, i32 0, i32 1
  %t975 = load i32, ptr %t974
  store i32 %t975, ptr %l58, !tbaa !23
  br label %bb168
bb167:
  br label %bb183
bb168:
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t978 = load i64, ptr %l2, !tbaa !24
  %t979 = load %"compiler/source:Span", ptr %l57
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t977, i64 %t978, %"compiler/source:Span" %t979)
  br label %bb169
bb169:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load i64, ptr %l1, !tbaa !24
  %t985 = load i32, ptr %l58, !tbaa !23
  %t989 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eheldScope(ptr %v0, ptr %t983, i64 %t984, i32 %t985)
  store i64 %t989, ptr %l508
  br label %bb170
bb170:
  %t990 = load i64, ptr %l508, !tbaa !24
  store i64 %t990, ptr %l59, !tbaa !24
  %t991 = load i64, ptr %l59, !tbaa !24
  %t993 = icmp ne i64 %t991, 0
  br i1 %t993, label %bb171, label %bb172
bb171:
  %t995 = load ptr, ptr %l0, !tbaa !29
  %t996 = load i64, ptr %l59, !tbaa !24
  %t999 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t995, i64 %t996)
  store i1 %t999, ptr %l514
  br label %bb173
bb172:
  store i1 false, ptr %l511, !tbaa !21
  br label %bb174
bb173:
  %t1000 = load i1, ptr %l514, !tbaa !21
  store i1 %t1000, ptr %l511, !tbaa !21
  br label %bb174
bb174:
  %t1001 = load i1, ptr %l511, !tbaa !21
  br i1 %t1001, label %bb175, label %bb176
bb175:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1004 = getelementptr %"compiler/eval:Machine", ptr %t1002, i32 0, i32 53
  %t1005 = load i64, ptr %l59, !tbaa !24
  %t1006 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t1009 = and i64 %t1005, %t1006
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t1010, ptr %v0, ptr %t1004, i64 %t1009)
  call void @llvm.memmove.p0.p0.i64(ptr %l521, ptr %t1010, i64 152, i1 false)
  br label %bb177
bb176:
  store i1 false, ptr %l515, !tbaa !21
  br label %bb178
bb177:
  %t1013 = getelementptr %"compiler/eval:scope", ptr %l521, i32 0, i32 2
  %t1014 = load i64, ptr %t1013, !tbaa !24
  %t1015 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t1018 = icmp eq i64 %t1014, %t1015
  store i1 %t1018, ptr %l515, !tbaa !21
  br label %bb178
bb178:
  %t1020 = load i1, ptr %l515, !tbaa !21
  br i1 %t1020, label %bb179, label %bb180
bb179:
  %t1021 = load ptr, ptr %l0, !tbaa !29
  %t1022 = load i64, ptr %l59, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %t1021, i64 %t1022)
  br label %bb181
bb180:
  br label %bb182
bb181:
  %t1025 = load ptr, ptr %l0, !tbaa !29
  %t1027 = getelementptr %"compiler/eval:Machine", ptr %t1025, i32 0, i32 59
  %t1028 = load { i64, ptr }, ptr %t1027, !tbaa !27
  store { i64, ptr } %t1028, ptr %l528, !tbaa !27
  %t1029 = load i64, ptr %l1, !tbaa !24
  %t1031 = getelementptr { i64, ptr }, ptr %l528, i32 0, i32 1
  %t1032 = load ptr, ptr %t1031, !tbaa !27
  %t1033 = getelementptr %"compiler/eval:frame", ptr %t1032, i64 %t1029
  %t1034 = getelementptr %"compiler/eval:frame", ptr %t1033, i32 0, i32 10
  store i1 true, ptr %t1034, !tbaa !21
  br label %ret
bb182:
  br label %bb278
bb183:
  call void @llvm.memmove.p0.p0.i64(ptr %l530, ptr %l6, i64 176, i1 false)
  %t1035 = load { i64, [21 x i64] }, ptr %l530
  %t1036 = extractvalue { i64, [21 x i64] } %t1035, 0
  %t1037 = icmp eq i64 %t1036, 11
  br i1 %t1037, label %bb184, label %bb185
bb184:
  %t1039 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1040 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1039, i32 0, i32 0
  %t1041 = load %"compiler/source:Span", ptr %t1040
  store %"compiler/source:Span" %t1041, ptr %l60
  %t1043 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1044 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1043, i32 0, i32 1
  %t1045 = load { i64, [1 x i64] }, ptr %t1044
  store { i64, [1 x i64] } %t1045, ptr %l61
  %t1047 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1048 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1047, i32 0, i32 2
  %t1049 = load i32, ptr %t1048, !range !{i32 0, i32 8}
  store i32 %t1049, ptr %l62
  %t1051 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1052 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1051, i32 0, i32 3
  %t1053 = load { i64, [4 x i64] }, ptr %t1052
  store { i64, [4 x i64] } %t1053, ptr %l63
  br label %bb186
bb185:
  br label %bb189
bb186:
  %t1055 = load ptr, ptr %l0, !tbaa !29
  %t1056 = load i64, ptr %l2, !tbaa !24
  %t1057 = load %"compiler/source:Span", ptr %l60
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1055, i64 %t1056, %"compiler/source:Span" %t1057)
  br label %bb187
bb187:
  %t1061 = load ptr, ptr %l0, !tbaa !29
  %t1062 = load i64, ptr %l1, !tbaa !24
  %t1063 = load { i64, [1 x i64] }, ptr %l61
  %t1064 = load i32, ptr %l62, !range !{i32 0, i32 8}
  %t1065 = load { i64, [4 x i64] }, ptr %l63
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrite(ptr %v0, ptr %t1061, i64 %t1062, { i64, [1 x i64] } %t1063, i32 %t1064, { i64, [4 x i64] } %t1065)
  br label %bb188
bb188:
  br label %bb278
bb189:
  call void @llvm.memmove.p0.p0.i64(ptr %l544, ptr %l6, i64 176, i1 false)
  %t1071 = load { i64, [21 x i64] }, ptr %l544
  %t1072 = extractvalue { i64, [21 x i64] } %t1071, 0
  %t1073 = icmp eq i64 %t1072, 15
  br i1 %t1073, label %bb190, label %bb191
bb190:
  %t1075 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1076 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t1075, i32 0, i32 0
  %t1077 = load %"compiler/source:Span", ptr %t1076
  store %"compiler/source:Span" %t1077, ptr %l64
  %t1079 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1080 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t1079, i32 0, i32 1
  %t1081 = load { i64, [4 x i64] }, ptr %t1080
  store { i64, [4 x i64] } %t1081, ptr %l65
  br label %bb192
bb191:
  br label %bb203
bb192:
  %t1083 = load ptr, ptr %l0, !tbaa !29
  %t1084 = load i64, ptr %l2, !tbaa !24
  %t1085 = load %"compiler/source:Span", ptr %l64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1083, i64 %t1084, %"compiler/source:Span" %t1085)
  br label %bb193
bb193:
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1091 = getelementptr %"compiler/eval:Machine", ptr %t1089, i32 0, i32 14
  %t1093 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eLen_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t1091)
  store i64 %t1093, ptr %l553
  br label %bb194
bb194:
  %t1094 = load i64, ptr %l553, !tbaa !24
  %t1095 = icmp eq i64 %t1094, 0
  br i1 %t1095, label %bb195, label %bb196
bb195:
  %t1097 = load ptr, ptr %l0, !tbaa !29
  %t1098 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t1099 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t1099, ptr %t1097, { i64, ptr } %t1098)
  br label %bb197
bb196:
  br label %bb198
bb197:
  br label %ret
bb198:
  %t1102 = load ptr, ptr %l0, !tbaa !29
  %t1104 = getelementptr %"compiler/eval:Machine", ptr %t1102, i32 0, i32 14
  store ptr %t1104, ptr %l558, !tbaa !29
  %t1105 = load ptr, ptr %l0, !tbaa !29
  %t1107 = getelementptr %"compiler/eval:Machine", ptr %t1105, i32 0, i32 14
  %t1109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eLen_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t1107)
  store i64 %t1109, ptr %l561
  br label %bb199
bb199:
  %t1110 = load i64, ptr %l561, !tbaa !24
  %t1111 = sub i64 %t1110, 1
  store i64 %t1111, ptr %l562, !tbaa !24
  %t1112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1112, ptr %l563, !tbaa !29
  %t1113 = load ptr, ptr %l0, !tbaa !29
  %t1114 = load i64, ptr %l1, !tbaa !24
  %t1115 = load { i64, [4 x i64] }, ptr %l65
  %t1119 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t1113, i64 %t1114, { i64, [4 x i64] } %t1115, i64 1)
  store %"compiler/eval:Ptr" %t1119, ptr %l567
  br label %bb200
bb200:
  %t1120 = load ptr, ptr %l563, !tbaa !29
  %t1121 = load %"compiler/eval:Ptr", ptr %l567
  %t1122 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t1120, %"compiler/eval:Ptr" %t1121)
  store %"compiler/eval:Ptr" %t1122, ptr %l568
  br label %bb201
bb201:
  %t1123 = load ptr, ptr %l558, !tbaa !29
  %t1124 = load i64, ptr %l562, !tbaa !24
  %t1125 = load %"compiler/eval:Ptr", ptr %l568
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eSetAt_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t1123, i64 %t1124, %"compiler/eval:Ptr" %t1125)
  br label %bb202
bb202:
  br label %bb278
bb203:
  call void @llvm.memmove.p0.p0.i64(ptr %l569, ptr %l6, i64 176, i1 false)
  %t1126 = load { i64, [21 x i64] }, ptr %l569
  %t1127 = extractvalue { i64, [21 x i64] } %t1126, 0
  %t1128 = icmp eq i64 %t1127, 17
  br i1 %t1128, label %bb204, label %bb205
bb204:
  %t1130 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1131 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t1130, i32 0, i32 0
  %t1132 = load %"compiler/source:Span", ptr %t1131
  store %"compiler/source:Span" %t1132, ptr %l66
  %t1134 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1135 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t1134, i32 0, i32 1
  %t1136 = load { i64, [4 x i64] }, ptr %t1135
  store { i64, [4 x i64] } %t1136, ptr %l67
  %t1138 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1139 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t1138, i32 0, i32 2
  %t1140 = load { i64, [4 x i64] }, ptr %t1139
  store { i64, [4 x i64] } %t1140, ptr %l68
  br label %bb206
bb205:
  br label %bb216
bb206:
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1143 = load i64, ptr %l2, !tbaa !24
  %t1144 = load %"compiler/source:Span", ptr %l66
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1142, i64 %t1143, %"compiler/source:Span" %t1144)
  br label %bb207
bb207:
  %t1148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1148, ptr %l577, !tbaa !29
  %t1149 = load ptr, ptr %l0, !tbaa !29
  %t1150 = load i64, ptr %l1, !tbaa !24
  %t1151 = load { i64, [4 x i64] }, ptr %l68
  %t1155 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t1149, i64 %t1150, { i64, [4 x i64] } %t1151)
  store i64 %t1155, ptr %l581
  br label %bb208
bb208:
  %t1156 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t1157 = load ptr, ptr %l577, !tbaa !29
  %t1158 = load i64, ptr %l581, !tbaa !24
  %t1160 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t1157, i64 %t1158, i32 %t1156)
  store i64 %t1160, ptr %l583
  br label %bb209
bb209:
  %t1161 = load i64, ptr %l583, !tbaa !24
  store i64 %t1161, ptr %l69, !tbaa !24
  %t1162 = load ptr, ptr %l0, !tbaa !29
  %t1163 = load i64, ptr %l1, !tbaa !24
  %t1164 = load { i64, [4 x i64] }, ptr %l67
  %t1168 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t1162, i64 %t1163, { i64, [4 x i64] } %t1164, i64 1)
  store %"compiler/eval:Ptr" %t1168, ptr %l587
  br label %bb210
bb210:
  %t1169 = load %"compiler/eval:Ptr", ptr %l587
  store %"compiler/eval:Ptr" %t1169, ptr %l70
  %t1170 = load ptr, ptr %l0, !tbaa !29
  %t1172 = getelementptr %"compiler/eval:Machine", ptr %t1170, i32 0, i32 23
  %t1173 = load i1, ptr %t1172, !tbaa !21
  %t1175 = xor i1 %t1173, true
  br i1 %t1175, label %bb211, label %bb212
bb211:
  %t1177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1177, ptr %l591, !tbaa !29
  %t1178 = load %"compiler/eval:Ptr", ptr %l70
  store %"compiler/eval:Ptr" %t1178, ptr %l592
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1180 = load i64, ptr %l1, !tbaa !24
  %t1181 = load { i64, [4 x i64] }, ptr %l67
  %t1185 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1179, i64 %t1180, { i64, [4 x i64] } %t1181)
  store i32 %t1185, ptr %l596
  br label %bb213
bb212:
  br label %bb215
bb213:
  %t1186 = load i64, ptr %l69, !tbaa !24
  %t1187 = load ptr, ptr %l591, !tbaa !29
  %t1188 = load %"compiler/eval:Ptr", ptr %l592
  %t1189 = load i32, ptr %l596, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eholders(ptr %v0, ptr %t1187, %"compiler/eval:Ptr" %t1188, i32 %t1189, i64 %t1186)
  br label %bb214
bb214:
  br label %bb215
bb215:
  br label %bb278
bb216:
  call void @llvm.memmove.p0.p0.i64(ptr %l598, ptr %l6, i64 176, i1 false)
  %t1191 = load { i64, [21 x i64] }, ptr %l598
  %t1192 = extractvalue { i64, [21 x i64] } %t1191, 0
  %t1193 = icmp eq i64 %t1192, 18
  br i1 %t1193, label %bb217, label %bb218
bb217:
  %t1195 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1196 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t1195, i32 0, i32 0
  %t1197 = load %"compiler/source:Span", ptr %t1196
  store %"compiler/source:Span" %t1197, ptr %l71
  %t1199 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1200 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t1199, i32 0, i32 1
  %t1201 = load { i64, [4 x i64] }, ptr %t1200
  store { i64, [4 x i64] } %t1201, ptr %l72
  %t1203 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1204 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t1203, i32 0, i32 2
  %t1205 = load i32, ptr %t1204
  store i32 %t1205, ptr %l73, !tbaa !23
  %t1207 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1208 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t1207, i32 0, i32 3
  %t1209 = load %"compiler/mir:Range", ptr %t1208
  store %"compiler/mir:Range" %t1209, ptr %l74
  br label %bb219
bb218:
  br label %bb225
bb219:
  %t1211 = load ptr, ptr %l0, !tbaa !29
  %t1212 = load i64, ptr %l2, !tbaa !24
  %t1213 = load %"compiler/source:Span", ptr %l71
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1211, i64 %t1212, %"compiler/source:Span" %t1213)
  br label %bb220
bb220:
  %t1217 = load ptr, ptr %l0, !tbaa !29
  %t1219 = getelementptr %"compiler/eval:Machine", ptr %t1217, i32 0, i32 1
  %t1220 = load i32, ptr %t1219, !range !{i32 0, i32 2}
  %t1222 = trunc i64 1 to i32
  %t1223 = icmp eq i32 %t1220, %t1222
  br i1 %t1223, label %bb221, label %bb222
bb221:
  %t1225 = load ptr, ptr %l0, !tbaa !29
  %t1226 = load i64, ptr %l1, !tbaa !24
  %t1227 = load i64, ptr %l2, !tbaa !24
  %t1228 = load { i64, [4 x i64] }, ptr %l72
  %t1229 = load i32, ptr %l73, !tbaa !23
  %t1230 = load %"compiler/mir:Range", ptr %l74
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereclaim(ptr %v0, ptr %t1225, i64 %t1226, i64 %t1227, { i64, [4 x i64] } %t1228, i32 %t1229, %"compiler/mir:Range" %t1230)
  br label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb224
bb224:
  br label %bb278
bb225:
  call void @llvm.memmove.p0.p0.i64(ptr %l616, ptr %l6, i64 176, i1 false)
  %t1237 = load { i64, [21 x i64] }, ptr %l616
  %t1238 = extractvalue { i64, [21 x i64] } %t1237, 0
  %t1239 = icmp eq i64 %t1238, 16
  br i1 %t1239, label %bb226, label %bb227
bb226:
  %t1241 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1242 = getelementptr { %"compiler/source:Span" }, ptr %t1241, i32 0, i32 0
  %t1243 = load %"compiler/source:Span", ptr %t1242
  store %"compiler/source:Span" %t1243, ptr %l75
  br label %bb228
bb227:
  br label %bb243
bb228:
  %t1245 = load ptr, ptr %l0, !tbaa !29
  %t1246 = load i64, ptr %l2, !tbaa !24
  %t1247 = load %"compiler/source:Span", ptr %l75
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1245, i64 %t1246, %"compiler/source:Span" %t1247)
  br label %bb229
bb229:
  %t1251 = load ptr, ptr %l0, !tbaa !29
  %t1253 = getelementptr %"compiler/eval:Machine", ptr %t1251, i32 0, i32 13
  %t1255 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t1253)
  %t1256 = extractvalue { i32, i64 } %t1255, 1
  %t1257 = extractvalue { i32, i64 } %t1255, 0
  store i32 %t1257, ptr %l626
  %t1258 = icmp ne i32 %t1257, 0
  br i1 %t1258, label %bb231, label %ok.1259, !prof !99
ok.1259:
  store i64 %t1256, ptr %l625
  br label %bb230
bb230:
  %t1260 = load i64, ptr %l625, !tbaa !24
  store i64 %t1260, ptr %l622, !tbaa !24
  br label %bb234
bb231:
  br label %bb232
bb232:
  %t1261 = load ptr, ptr %l0, !tbaa !29
  %t1262 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t1263 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t1263, ptr %t1261, { i64, ptr } %t1262)
  br label %bb233
bb233:
  br label %ret
bb234:
  %t1266 = load i64, ptr %l622, !tbaa !24
  store i64 %t1266, ptr %l76, !tbaa !24
  %t1267 = load ptr, ptr %l0, !tbaa !29
  %t1269 = getelementptr %"compiler/eval:Machine", ptr %t1267, i32 0, i32 14
  store ptr %t1269, ptr %l630, !tbaa !29
  %t1270 = load ptr, ptr %l0, !tbaa !29
  %t1272 = getelementptr %"compiler/eval:Machine", ptr %t1270, i32 0, i32 14
  %t1274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eLen_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t1272)
  store i64 %t1274, ptr %l633
  br label %bb235
bb235:
  %t1275 = load i64, ptr %l633, !tbaa !24
  %t1276 = sub i64 %t1275, 1
  %t1277 = load ptr, ptr %l630, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eTruncate_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %t1277, i64 %t1276)
  br label %bb236
bb236:
  %t1279 = load ptr, ptr %l0, !tbaa !29
  %t1281 = getelementptr %"compiler/eval:Machine", ptr %t1279, i32 0, i32 63
  %t1283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t1281)
  store i64 %t1283, ptr %l637
  br label %bb237
bb237:
  %t1284 = load i64, ptr %l637, !tbaa !24
  store i64 %t1284, ptr %l77, !tbaa !24
  %t1285 = load ptr, ptr %l0, !tbaa !29
  %t1286 = load i64, ptr %l76, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %t1285, i64 %t1286)
  br label %bb238
bb238:
  %t1289 = load ptr, ptr %l0, !tbaa !29
  %t1291 = getelementptr %"compiler/eval:Machine", ptr %t1289, i32 0, i32 63
  %t1293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t1291)
  store i64 %t1293, ptr %l642
  br label %bb239
bb239:
  %t1294 = load i64, ptr %l77, !tbaa !24
  %t1295 = load i64, ptr %l642, !tbaa !24
  %t1297 = icmp sgt i64 %t1295, %t1294
  br i1 %t1297, label %bb240, label %bb241
bb240:
  %t1299 = load ptr, ptr %l0, !tbaa !29
  %t1301 = getelementptr %"compiler/eval:Machine", ptr %t1299, i32 0, i32 59
  %t1302 = load { i64, ptr }, ptr %t1301, !tbaa !27
  store { i64, ptr } %t1302, ptr %l646, !tbaa !27
  %t1303 = load i64, ptr %l1, !tbaa !24
  %t1305 = getelementptr { i64, ptr }, ptr %l646, i32 0, i32 1
  %t1306 = load ptr, ptr %t1305, !tbaa !27
  %t1307 = getelementptr %"compiler/eval:frame", ptr %t1306, i64 %t1303
  %t1308 = getelementptr %"compiler/eval:frame", ptr %t1307, i32 0, i32 10
  store i1 true, ptr %t1308, !tbaa !21
  br label %ret
bb241:
  br label %bb242
bb242:
  br label %bb278
bb243:
  call void @llvm.memmove.p0.p0.i64(ptr %l648, ptr %l6, i64 176, i1 false)
  %t1309 = load { i64, [21 x i64] }, ptr %l648
  %t1310 = extractvalue { i64, [21 x i64] } %t1309, 0
  %t1311 = icmp eq i64 %t1310, 12
  br i1 %t1311, label %bb244, label %bb245
bb244:
  %t1313 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1314 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1313, i32 0, i32 0
  %t1315 = load %"compiler/source:Span", ptr %t1314
  store %"compiler/source:Span" %t1315, ptr %l78
  %t1317 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1318 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1317, i32 0, i32 1
  %t1319 = load %"compiler/mir:Lvalue", ptr %t1318
  store %"compiler/mir:Lvalue" %t1319, ptr %l79
  %t1321 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1322 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1321, i32 0, i32 2
  %t1323 = load %"compiler/mir:Lvalue", ptr %t1322
  store %"compiler/mir:Lvalue" %t1323, ptr %l80
  %t1325 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1326 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1325, i32 0, i32 3
  %t1327 = load { i64, [4 x i64] }, ptr %t1326
  store { i64, [4 x i64] } %t1327, ptr %l81
  br label %bb246
bb245:
  br label %bb271
bb246:
  %t1329 = load ptr, ptr %l0, !tbaa !29
  %t1330 = load i64, ptr %l2, !tbaa !24
  %t1331 = load %"compiler/source:Span", ptr %l78
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1329, i64 %t1330, %"compiler/source:Span" %t1331)
  br label %bb247
bb247:
  %t1335 = load ptr, ptr %l0, !tbaa !29
  %t1336 = load i64, ptr %l1, !tbaa !24
  %t1337 = load %"compiler/mir:Lvalue", ptr %l79
  %t1341 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t1335, i64 %t1336, %"compiler/mir:Lvalue" %t1337)
  store { %"compiler/eval:Ptr", i32 } %t1341, ptr %l660
  br label %bb248
bb248:
  %t1342 = load { %"compiler/eval:Ptr", i32 }, ptr %l660
  store { %"compiler/eval:Ptr", i32 } %t1342, ptr %l82
  %t1343 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l82, i32 0, i32 0
  %t1344 = load %"compiler/eval:Ptr", ptr %t1343
  store %"compiler/eval:Ptr" %t1344, ptr %l83
  %t1346 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l82, i32 0, i32 1
  %t1347 = load i32, ptr %t1346, !tbaa !23
  store i32 %t1347, ptr %l84, !tbaa !23
  %t1349 = load ptr, ptr %l0, !tbaa !29
  %t1350 = load i64, ptr %l1, !tbaa !24
  %t1351 = load %"compiler/mir:Lvalue", ptr %l80
  %t1355 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t1349, i64 %t1350, %"compiler/mir:Lvalue" %t1351)
  store { %"compiler/eval:Ptr", i32 } %t1355, ptr %l666
  br label %bb249
bb249:
  %t1356 = load { %"compiler/eval:Ptr", i32 }, ptr %l666
  store { %"compiler/eval:Ptr", i32 } %t1356, ptr %l85
  %t1357 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l85, i32 0, i32 0
  %t1358 = load %"compiler/eval:Ptr", ptr %t1357
  store %"compiler/eval:Ptr" %t1358, ptr %l86
  %t1360 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l85, i32 0, i32 1
  %t1361 = load i32, ptr %t1360, !tbaa !23
  store i32 %t1361, ptr %l87, !tbaa !23
  %t1363 = load ptr, ptr %l0, !tbaa !29
  %t1364 = load %"compiler/eval:Ptr", ptr %l83
  %t1365 = load i32, ptr %l84, !tbaa !23
  %t1369 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1363, %"compiler/eval:Ptr" %t1364, i32 %t1365)
  store { %"compiler/eval:Ptr", i64 } %t1369, ptr %l672
  br label %bb250
bb250:
  %t1370 = load { %"compiler/eval:Ptr", i64 }, ptr %l672
  store { %"compiler/eval:Ptr", i64 } %t1370, ptr %l88
  %t1371 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l88, i32 0, i32 0
  %t1372 = load %"compiler/eval:Ptr", ptr %t1371
  store %"compiler/eval:Ptr" %t1372, ptr %l89
  %t1374 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l88, i32 0, i32 1
  %t1375 = load i64, ptr %t1374, !tbaa !24
  store i64 %t1375, ptr %l90, !tbaa !24
  %t1377 = load ptr, ptr %l0, !tbaa !29
  %t1378 = load %"compiler/eval:Ptr", ptr %l86
  %t1379 = load i32, ptr %l87, !tbaa !23
  %t1383 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1377, %"compiler/eval:Ptr" %t1378, i32 %t1379)
  store { %"compiler/eval:Ptr", i64 } %t1383, ptr %l678
  br label %bb251
bb251:
  %t1384 = load { %"compiler/eval:Ptr", i64 }, ptr %l678
  store { %"compiler/eval:Ptr", i64 } %t1384, ptr %l91
  %t1385 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l91, i32 0, i32 0
  %t1386 = load %"compiler/eval:Ptr", ptr %t1385
  store %"compiler/eval:Ptr" %t1386, ptr %l92
  %t1388 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l91, i32 0, i32 1
  %t1389 = load i64, ptr %t1388, !tbaa !24
  store i64 %t1389, ptr %l93, !tbaa !24
  %t1391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1391, ptr %l681, !tbaa !29
  %t1392 = load ptr, ptr %l0, !tbaa !29
  %t1393 = load i64, ptr %l1, !tbaa !24
  %t1394 = load { i64, [4 x i64] }, ptr %l81
  %t1398 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t1392, i64 %t1393, { i64, [4 x i64] } %t1394)
  store i64 %t1398, ptr %l685
  br label %bb252
bb252:
  %t1399 = load ptr, ptr %l0, !tbaa !29
  %t1400 = load i64, ptr %l1, !tbaa !24
  %t1401 = load { i64, [4 x i64] }, ptr %l81
  %t1405 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1399, i64 %t1400, { i64, [4 x i64] } %t1401)
  store i32 %t1405, ptr %l689
  br label %bb253
bb253:
  %t1406 = load ptr, ptr %l681, !tbaa !29
  %t1407 = load i64, ptr %l685, !tbaa !24
  %t1408 = load i32, ptr %l689, !tbaa !23
  %t1409 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t1406, i64 %t1407, i32 %t1408)
  store i64 %t1409, ptr %l690
  br label %bb254
bb254:
  %t1410 = load i64, ptr %l690, !tbaa !24
  store i64 %t1410, ptr %l94, !tbaa !24
  %t1411 = load ptr, ptr %l0, !tbaa !29
  %t1413 = getelementptr %"compiler/eval:Machine", ptr %t1411, i32 0, i32 23
  %t1414 = load i1, ptr %t1413, !tbaa !21
  br i1 %t1414, label %bb255, label %bb256
bb255:
  br label %ret
bb256:
  br label %bb257
bb257:
  %t1416 = load i64, ptr %l94, !tbaa !24
  %t1418 = icmp slt i64 %t1416, 0
  br i1 %t1418, label %bb258, label %bb259
bb258:
  store i1 true, ptr %l695, !tbaa !21
  br label %bb260
bb259:
  %t1420 = load i64, ptr %l94, !tbaa !24
  %t1421 = load i64, ptr %l90, !tbaa !24
  %t1424 = icmp sgt i64 %t1420, %t1421
  store i1 %t1424, ptr %l695, !tbaa !21
  br label %bb260
bb260:
  %t1426 = load i1, ptr %l695, !tbaa !21
  br i1 %t1426, label %bb261, label %bb262
bb261:
  store i1 true, ptr %l699, !tbaa !21
  br label %bb263
bb262:
  %t1427 = load i64, ptr %l94, !tbaa !24
  %t1428 = load i64, ptr %l93, !tbaa !24
  %t1431 = icmp sgt i64 %t1427, %t1428
  store i1 %t1431, ptr %l699, !tbaa !21
  br label %bb263
bb263:
  %t1433 = load i1, ptr %l699, !tbaa !21
  br i1 %t1433, label %bb264, label %bb265
bb264:
  %t1434 = load ptr, ptr %l0, !tbaa !29
  %t1435 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyOutside, !tbaa !27
  %t1436 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t1436, ptr %t1434, { i64, ptr } %t1435)
  br label %bb266
bb265:
  br label %bb267
bb266:
  br label %ret
bb267:
  %t1439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1439, ptr %l705, !tbaa !29
  %t1440 = load %"compiler/eval:Ptr", ptr %l89
  store %"compiler/eval:Ptr" %t1440, ptr %l706
  %t1441 = load %"compiler/eval:Ptr", ptr %l92
  store %"compiler/eval:Ptr" %t1441, ptr %l707
  %t1442 = load i64, ptr %l94, !tbaa !24
  store i64 %t1442, ptr %l708, !tbaa !24
  %t1443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1443, ptr %l709, !tbaa !29
  %t1444 = load ptr, ptr %l0, !tbaa !29
  %t1445 = load i32, ptr %l84, !tbaa !23
  %t1448 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t1444, i32 %t1445)
  store i32 %t1448, ptr %l712
  br label %bb268
bb268:
  %t1449 = load ptr, ptr %l709, !tbaa !29
  %t1450 = load i32, ptr %l712, !tbaa !23
  %t1451 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t1449, i32 %t1450)
  store i64 %t1451, ptr %l713
  br label %bb269
bb269:
  %t1452 = load i64, ptr %l708, !tbaa !24
  %t1453 = load i64, ptr %l713, !tbaa !24
  %t1454 = mul i64 %t1452, %t1453
  %t1455 = load ptr, ptr %l705, !tbaa !29
  %t1456 = load %"compiler/eval:Ptr", ptr %l706
  %t1457 = load %"compiler/eval:Ptr", ptr %l707
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t1455, %"compiler/eval:Ptr" %t1456, %"compiler/eval:Ptr" %t1457, i64 %t1454)
  br label %bb270
bb270:
  br label %bb278
bb271:
  call void @llvm.memmove.p0.p0.i64(ptr %l715, ptr %l6, i64 176, i1 false)
  %t1459 = load { i64, [21 x i64] }, ptr %l715
  %t1460 = extractvalue { i64, [21 x i64] } %t1459, 0
  %t1461 = icmp eq i64 %t1460, 13
  br i1 %t1461, label %bb272, label %bb273
bb272:
  %t1463 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1464 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1463, i32 0, i32 0
  %t1465 = load %"compiler/source:Span", ptr %t1464
  store %"compiler/source:Span" %t1465, ptr %l95
  %t1467 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1468 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1467, i32 0, i32 1
  %t1469 = load i32, ptr %t1468
  store i32 %t1469, ptr %l96, !tbaa !23
  %t1471 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1472 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1471, i32 0, i32 2
  %t1473 = load i32, ptr %t1472
  store i32 %t1473, ptr %l97, !tbaa !23
  br label %bb274
bb273:
  br label %bb277
bb274:
  %t1475 = load ptr, ptr %l0, !tbaa !29
  %t1476 = load i64, ptr %l2, !tbaa !24
  %t1477 = load %"compiler/source:Span", ptr %l95
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1475, i64 %t1476, %"compiler/source:Span" %t1477)
  br label %bb275
bb275:
  %t1481 = load ptr, ptr %l0, !tbaa !29
  %t1482 = load i64, ptr %l1, !tbaa !24
  %t1483 = load i32, ptr %l96, !tbaa !23
  %t1484 = load i32, ptr %l97, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2espawn(ptr %v0, ptr %t1481, i64 %t1482, i32 %t1483, i32 %t1484)
  br label %bb276
bb276:
  br label %bb278
bb277:
  call void @__olang_check_failed(ptr @olang_loc_7f284a3be8281e29_2098fbd9ac092a4d)
  unreachable
bb278:
  %t1489 = load ptr, ptr %l0, !tbaa !29
  %t1491 = getelementptr %"compiler/eval:Machine", ptr %t1489, i32 0, i32 23
  %t1492 = load i1, ptr %t1491, !tbaa !21
  %t1494 = xor i1 %t1492, true
  br i1 %t1494, label %bb279, label %bb280
bb279:
  %t1496 = load ptr, ptr %l0, !tbaa !29
  %t1498 = getelementptr %"compiler/eval:Machine", ptr %t1496, i32 0, i32 59
  %t1499 = load { i64, ptr }, ptr %t1498, !tbaa !27
  store { i64, ptr } %t1499, ptr %l731, !tbaa !27
  %t1500 = load i64, ptr %l1, !tbaa !24
  store i64 %t1500, ptr %l732, !tbaa !24
  %t1501 = load i64, ptr %l732, !tbaa !24
  %t1502 = getelementptr { i64, ptr }, ptr %l731, i32 0, i32 1
  %t1503 = load ptr, ptr %t1502, !tbaa !27
  %t1504 = getelementptr %"compiler/eval:frame", ptr %t1503, i64 %t1501
  %t1505 = getelementptr %"compiler/eval:frame", ptr %t1504, i32 0, i32 2
  %t1506 = load i64, ptr %t1505, !tbaa !24
  %t1509 = add i64 %t1506, 1
  %t1511 = load i64, ptr %l732, !tbaa !24
  %t1512 = getelementptr { i64, ptr }, ptr %l731, i32 0, i32 1
  %t1513 = load ptr, ptr %t1512, !tbaa !27
  %t1514 = getelementptr %"compiler/eval:frame", ptr %t1513, i64 %t1511
  %t1515 = getelementptr %"compiler/eval:frame", ptr %t1514, i32 0, i32 2
  store i64 %t1509, ptr %t1515, !tbaa !24
  br label %bb281
bb280:
  br label %bb281
bb281:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estopAtComparison(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, [8 x i64] }
  %l5 = alloca i32
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l40 = alloca %"compiler/mir:BasicBlock"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp sgt i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 27
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 59
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr %"compiler/eval:frame", ptr %t23, i64 %t20
  %t25 = getelementptr %"compiler/eval:frame", ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/eval:cfn", ptr %t29, i64 %t26
  %t31 = getelementptr %"compiler/eval:cfn", ptr %t30, i32 0, i32 17
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t34 = load i1, ptr %l13, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = sub i64 %t37, 1
  store i64 %t40, ptr %l1, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 26
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 59
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l30, !tbaa !27
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr %"compiler/eval:frame", ptr %t56, i64 %t53
  %t58 = getelementptr %"compiler/eval:frame", ptr %t57, i32 0, i32 0
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l33, !tbaa !29
  store ptr %t63, ptr %l2, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/mir:Fn", ptr %t64, i32 0, i32 9
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 59
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l37, !tbaa !27
  %t71 = load i64, ptr %l1, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/eval:frame", ptr %t74, i64 %t71
  %t76 = getelementptr %"compiler/eval:frame", ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s0, ptr %t66, i64 %t77)
  store %"compiler/mir:BasicBlock" %t80, ptr %l40
  br label %bb14
bb14:
  %t81 = getelementptr %"compiler/mir:BasicBlock", ptr %l40, i32 0, i32 1
  %t82 = load { i64, [8 x i64] }, ptr %t81
  store { i64, [8 x i64] } %t82, ptr %l3
  %t84 = load { i64, [8 x i64] }, ptr %l3
  %t86 = extractvalue { i64, [8 x i64] } %t84, 0
  %t87 = icmp eq i64 %t86, 4
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = getelementptr { i64, [8 x i64] }, ptr %l3, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  %t93 = getelementptr { i64, [8 x i64] }, ptr %l3, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32 }, ptr %t93, i32 0, i32 1
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l5, !tbaa !23
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/mir:Fn", ptr %t97, i32 0, i32 2
  %t100 = load i64, ptr %t99, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/eval:Machine", ptr %t104, i32 0, i32 78
  store i64 %t100, ptr %t108, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/eval:Machine", ptr %t109, i32 0, i32 79
  store %"compiler/source:Span" %t91, ptr %t113
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2esuspend(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/mir:Range" %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/mir:Range"
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:frame"
  %l8 = alloca %"compiler/eval:genRec"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l46 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca %"compiler/eval:frame"
  %l61 = alloca %"compiler/eval:genRec"
  %l62 = alloca %"compiler/eval:genRec"
  %l63 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l157 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l176 = alloca i32
  %l179 = alloca i32
  %l204 = alloca { i64, [1 x i64] }
  %l212 = alloca { i64, ptr }
  %l234 = alloca %"compiler/eval:frame"
  %l241 = alloca i64
  %l245 = alloca i64
  %l248 = alloca i64
  %l269 = alloca i64
  %l272 = alloca ptr
  %l276 = alloca i64
  %l277 = alloca ptr
  %l281 = alloca i64
  %l286 = alloca ptr
  %l287 = alloca i64
  %l288 = alloca %"compiler/eval:genRec"
  %l290 = alloca %"compiler/eval:genRec"
  %l293 = alloca %"compiler/eval:frame"
  %s0 = alloca %olang.scope
  %t52 = alloca %"compiler/eval:genRec", align 8
  %t582 = alloca %"compiler/eval:genRec", align 8
  %t586 = alloca %"compiler/eval:genRec", align 8
  %t591 = alloca %"compiler/eval:frame", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 59
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l39, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 18
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  store i64 %t13, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l46
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %t22, i64 %t23, { i64, [4 x i64] } %a2)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 23
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 59
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l53, !tbaa !27
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/eval:frame", ptr %t40, i64 %t37
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t41, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l55, i64 136, i1 false)
  %t44 = sext i32 %a3 to i64
  %t46 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 1
  store i64 %t44, ptr %t46, !tbaa !24
  %t47 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 2
  store i64 0, ptr %t47, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 64
  %t51 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t52, ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t52, i64 280, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l62, ptr %l61, i64 280, i1 false)
  %t55 = call ptr @__olang_scope_hold(ptr %s0)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l63, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = call ptr @__olang_region_make_part(ptr %s0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l63, !tbaa !24
  br label %bb11
bb11:
  %t61 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l65, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l66, !tbaa !24
  %t66 = load i64, ptr %l66, !tbaa !24
  %t67 = mul i64 %t66, 8
  %t68 = load i64, ptr %l63
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = call ptr @__olang_held_alloc(ptr %t69, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l67, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l66, !tbaa !24
  %t78 = mul i64 %t77, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t80 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81, !tbaa !27
  %t82 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t82, label %bb12, label %bb13
bb12:
  %t84 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t85 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb14, label %bb15
bb13:
  %t91 = call ptr @__olang_scope_hold(ptr %s0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l71, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t93, label %bb16, label %bb17
bb14:
  %t95 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t96 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t96, !tbaa !27
  br label %bb15
bb15:
  %t97 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 0
  %t99 = load i64, ptr %l63
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = load { i64, ptr }, ptr %t98
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr null
  call void @__olang_region_settle_in(ptr %t100, ptr %t105)
  br label %bb13
bb16:
  %t106 = call ptr @__olang_region_make_part(ptr %s0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l71, !tbaa !24
  br label %bb17
bb17:
  %t108 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t108, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l73, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l74, !tbaa !24
  %t113 = load i64, ptr %l74, !tbaa !24
  %t114 = mul i64 %t113, 8
  %t115 = load i64, ptr %l71
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call ptr @__olang_held_alloc(ptr %t116, i64 %t114)
  %t118 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l75, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l74, !tbaa !24
  %t125 = mul i64 %t124, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t127 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t128 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t127, i32 0, i32 0
  store { i64, ptr } %t126, ptr %t128, !tbaa !27
  %t129 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t129, label %bb18, label %bb19
bb18:
  %t131 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t136 = icmp eq i64 %t134, 0
  br i1 %t136, label %bb20, label %bb21
bb19:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l62, i64 280, i1 false)
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/eval:Machine", ptr %t138, i32 0, i32 62
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 3
  %t143 = load i64, ptr %t142, !tbaa !24
  %t146 = sub i64 %t141, %t143
  store i64 %t146, ptr %l9, !tbaa !24
  %t148 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 8
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = icmp slt i64 %t149, 0
  br i1 %t151, label %bb22, label %bb23
bb20:
  %t153 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t153, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t154, !tbaa !27
  br label %bb21
bb21:
  %t155 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t155, i32 0, i32 0
  %t157 = load i64, ptr %l71
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = load { i64, ptr }, ptr %t156
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = call ptr @__olang_region_or(ptr %t160, ptr null)
  %t162 = icmp ne ptr %t161, null
  %t163 = select i1 %t162, ptr %t161, ptr null
  call void @__olang_region_settle_in(ptr %t158, ptr %t163)
  br label %bb19
bb22:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 66
  %t168 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t166)
  store i64 %t168, ptr %l87
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t169 = load i64, ptr %l87, !tbaa !24
  %t170 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 8
  store i64 %t169, ptr %t170, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/eval:Machine", ptr %t172, i32 0, i32 27
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l90, !tbaa !27
  %t176 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 0
  %t177 = load i64, ptr %t176, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr %"compiler/eval:cfn", ptr %t180, i64 %t177
  %t182 = getelementptr %"compiler/eval:cfn", ptr %t181, i32 0, i32 2
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = add i64 %t171, %t185
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t192 = load i64, ptr %l11, !tbaa !24
  %t193 = load i64, ptr %l10, !tbaa !24
  %t196 = icmp sgt i64 %t192, %t193
  br i1 %t196, label %bb25, label %bb26
bb25:
  %t198 = load i64, ptr %l12, !tbaa !24
  %t200 = icmp sgt i64 %t198, 0
  br i1 %t200, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb30
bb27:
  %t202 = load i64, ptr %l11, !tbaa !24
  %t203 = load i64, ptr %l10, !tbaa !24
  %t206 = sub i64 %t202, %t203
  %t207 = load i64, ptr %l12, !tbaa !24
  %t210 = add i64 %t206, %t207
  %t212 = sub i64 %t210, 1
  %t213 = load i64, ptr %l12, !tbaa !24
  %t216 = sdiv i64 %t212, %t213
  store i64 %t216, ptr %l102, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb29
bb29:
  %t218 = load i64, ptr %l102, !tbaa !24
  store i64 %t218, ptr %l99, !tbaa !24
  br label %bb30
bb30:
  %t219 = load i64, ptr %l99, !tbaa !24
  store i64 %t219, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t220 = load i64, ptr %l14, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t228 = load i64, ptr %l10, !tbaa !24
  %t229 = load i64, ptr %l14, !tbaa !24
  %t230 = load i64, ptr %l12, !tbaa !24
  %t233 = mul i64 %t229, %t230
  %t236 = add i64 %t228, %t233
  store i64 %t236, ptr %l15, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/eval:Machine", ptr %t238, i32 0, i32 66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t240, i64 0)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t242 = load i64, ptr %l14, !tbaa !24
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %l14, !tbaa !24
  br label %bb31
bb37:
  br label %bb38
bb38:
  %t247 = load i64, ptr %l9, !tbaa !24
  %t249 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 9
  store i64 %t247, ptr %t249, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t250 = load i64, ptr %l9, !tbaa !24
  store i64 %t250, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t253 = load i64, ptr %l16, !tbaa !24
  %t256 = icmp sgt i64 %t252, %t253
  br i1 %t256, label %bb39, label %bb40
bb39:
  %t258 = load i64, ptr %l18, !tbaa !24
  %t260 = icmp sgt i64 %t258, 0
  br i1 %t260, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb44
bb41:
  %t262 = load i64, ptr %l17, !tbaa !24
  %t263 = load i64, ptr %l16, !tbaa !24
  %t266 = sub i64 %t262, %t263
  %t267 = load i64, ptr %l18, !tbaa !24
  %t270 = add i64 %t266, %t267
  %t272 = sub i64 %t270, 1
  %t273 = load i64, ptr %l18, !tbaa !24
  %t276 = sdiv i64 %t272, %t273
  store i64 %t276, ptr %l133, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb43
bb43:
  %t278 = load i64, ptr %l133, !tbaa !24
  store i64 %t278, ptr %l130, !tbaa !24
  br label %bb44
bb44:
  %t279 = load i64, ptr %l130, !tbaa !24
  store i64 %t279, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb45
bb45:
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = load i64, ptr %l19, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb46, label %bb47
bb46:
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t288 = load i64, ptr %l16, !tbaa !24
  %t289 = load i64, ptr %l20, !tbaa !24
  %t290 = load i64, ptr %l18, !tbaa !24
  %t293 = mul i64 %t289, %t290
  %t296 = add i64 %t288, %t293
  store i64 %t296, ptr %l21, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/eval:Machine", ptr %t298, i32 0, i32 66
  %t301 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 8
  %t302 = load i64, ptr %t301, !tbaa !24
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = add i64 %t302, %t303
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/eval:Machine", ptr %t307, i32 0, i32 61
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l157, !tbaa !27
  %t311 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 3
  %t312 = load i64, ptr %t311, !tbaa !24
  %t313 = load i64, ptr %l21, !tbaa !24
  %t316 = add i64 %t312, %t313
  %t318 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i64, ptr %t319, i64 %t316
  %t321 = load i64, ptr %t320, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t300, i64 %t306, i64 %t321)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t325 = load i64, ptr %l20, !tbaa !24
  %t328 = add i64 %t325, 1
  store i64 %t328, ptr %l20, !tbaa !24
  br label %bb45
bb51:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/eval:Machine", ptr %t330, i32 0, i32 26
  %t333 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 0
  %t334 = load i64, ptr %t333, !tbaa !24
  %t337 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t332, i64 %t334)
  store ptr %t337, ptr %l168
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l168, !tbaa !29
  store ptr %t338, ptr %l22, !tbaa !29
  %t339 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 8
  %t340 = load i64, ptr %t339, !tbaa !24
  %t341 = load i64, ptr %l9, !tbaa !24
  %t344 = add i64 %t340, %t341
  store i64 %t344, ptr %l23, !tbaa !24
  store i32 0, ptr %l24, !tbaa !23
  %t346 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t347 = load i32, ptr %t346, !tbaa !23
  store i32 %t347, ptr %l25, !tbaa !23
  store i32 1, ptr %l26, !tbaa !23
  %t349 = load i32, ptr %l25, !tbaa !23
  %t350 = load i32, ptr %l24, !tbaa !23
  %t353 = icmp sgt i32 %t349, %t350
  br i1 %t353, label %bb53, label %bb54
bb53:
  %t355 = load i32, ptr %l26, !tbaa !23
  %t357 = icmp sgt i32 %t355, 0
  br i1 %t357, label %bb55, label %bb56
bb54:
  store i32 0, ptr %l176, !tbaa !23
  br label %bb58
bb55:
  %t359 = load i32, ptr %l25, !tbaa !23
  %t360 = load i32, ptr %l24, !tbaa !23
  %t363 = sub i32 %t359, %t360
  %t364 = load i32, ptr %l26, !tbaa !23
  %t367 = add i32 %t363, %t364
  %t369 = sub i32 %t367, 1
  %t370 = load i32, ptr %l26, !tbaa !23
  %t373 = sdiv i32 %t369, %t370
  store i32 %t373, ptr %l179, !tbaa !23
  br label %bb57
bb56:
  store i32 0, ptr %l179, !tbaa !23
  br label %bb57
bb57:
  %t375 = load i32, ptr %l179, !tbaa !23
  store i32 %t375, ptr %l176, !tbaa !23
  br label %bb58
bb58:
  %t376 = load i32, ptr %l176, !tbaa !23
  store i32 %t376, ptr %l27, !tbaa !23
  store i32 0, ptr %l28, !tbaa !23
  br label %bb59
bb59:
  %t377 = load i32, ptr %l28, !tbaa !23
  %t378 = load i32, ptr %l27, !tbaa !23
  %t381 = icmp slt i32 %t377, %t378
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb60, label %bb61
bb60:
  br label %bb75
bb61:
  br label %bb62
bb62:
  %t385 = load i32, ptr %l24, !tbaa !23
  %t386 = load i32, ptr %l28, !tbaa !23
  %t387 = load i32, ptr %l26, !tbaa !23
  %t390 = mul i32 %t386, %t387
  %t393 = add i32 %t385, %t390
  %t395 = load ptr, ptr %l22, !tbaa !29
  %t397 = getelementptr %"compiler/mir:Fn", ptr %t395, i32 0, i32 12
  %t398 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t399 = load i32, ptr %t398, !tbaa !23
  %t401 = sext i32 %t399 to i64
  %t404 = sext i32 %t393 to i64
  %t407 = add i64 %t401, %t404
  %t410 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t397, i64 %t407)
  store { i64, [1 x i64] } %t410, ptr %l204
  br label %bb63
bb63:
  %t411 = load { i64, [1 x i64] }, ptr %l204
  store { i64, [1 x i64] } %t411, ptr %l30
  %t412 = load { i64, [1 x i64] }, ptr %l30
  %t414 = extractvalue { i64, [1 x i64] } %t412, 0
  %t415 = icmp eq i64 %t414, 0
  br i1 %t415, label %bb64, label %bb65
bb64:
  %t417 = getelementptr { i64, [1 x i64] }, ptr %l30, i32 0, i32 1
  %t418 = getelementptr { i32 }, ptr %t417, i32 0, i32 0
  %t419 = load i32, ptr %t418
  store i32 %t419, ptr %l31, !tbaa !23
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/eval:Machine", ptr %t421, i32 0, i32 66
  %t424 = load i64, ptr %l23, !tbaa !24
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/eval:Machine", ptr %t425, i32 0, i32 61
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  store { i64, ptr } %t428, ptr %l212, !tbaa !27
  %t429 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 4
  %t430 = load i64, ptr %t429, !tbaa !24
  %t431 = load i32, ptr %l31, !tbaa !23
  %t433 = sext i32 %t431 to i64
  %t436 = add i64 %t430, %t433
  %t438 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr i64, ptr %t439, i64 %t436
  %t441 = load i64, ptr %t440, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t423, i64 %t424, i64 %t441)
  br label %bb67
bb67:
  %t445 = load i64, ptr %l23, !tbaa !24
  %t448 = add i64 %t445, 1
  store i64 %t448, ptr %l23, !tbaa !24
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_77ec49cd2ef2b53_f798fa63e9acfcff)
  unreachable
bb73:
  br label %bb74
bb74:
  %t450 = load i32, ptr %l28, !tbaa !23
  %t453 = add i32 %t450, 1
  store i32 %t453, ptr %l28, !tbaa !23
  br label %bb59
bb75:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/eval:Machine", ptr %t455, i32 0, i32 66
  %t458 = load i64, ptr %l23, !tbaa !24
  %t459 = getelementptr %"compiler/eval:frame", ptr %l7, i32 0, i32 6
  %t460 = load i64, ptr %t459, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t457, i64 %t458, i64 %t460)
  br label %bb76
bb76:
  %t464 = load i64, ptr %l23, !tbaa !24
  %t466 = add i64 %t464, 1
  %t467 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 8
  %t468 = load i64, ptr %t467, !tbaa !24
  %t469 = load i64, ptr %l9, !tbaa !24
  %t472 = add i64 %t468, %t469
  %t475 = sub i64 %t466, %t472
  %t477 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 10
  store i64 %t475, ptr %t477, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l234, ptr %l7, i64 136, i1 false)
  %t478 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t478, ptr %l234, i64 136, i1 false)
  %t481 = sext i32 %a5 to i64
  %t483 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 3
  store i64 %t481, ptr %t483, !tbaa !24
  %t484 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %s0, ptr %t484)
  br label %bb77
bb77:
  %t486 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %s0, ptr %t486)
  br label %bb78
bb78:
  store i64 0, ptr %l32, !tbaa !24
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/eval:Machine", ptr %t488, i32 0, i32 67
  %t492 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t490)
  store i64 %t492, ptr %l241
  br label %bb79
bb79:
  %t493 = load i64, ptr %l241, !tbaa !24
  store i64 %t493, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t494 = load i64, ptr %l33, !tbaa !24
  %t495 = load i64, ptr %l32, !tbaa !24
  %t498 = icmp sgt i64 %t494, %t495
  br i1 %t498, label %bb80, label %bb81
bb80:
  %t500 = load i64, ptr %l34, !tbaa !24
  %t502 = icmp sgt i64 %t500, 0
  br i1 %t502, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l245, !tbaa !24
  br label %bb85
bb82:
  %t504 = load i64, ptr %l33, !tbaa !24
  %t505 = load i64, ptr %l32, !tbaa !24
  %t508 = sub i64 %t504, %t505
  %t509 = load i64, ptr %l34, !tbaa !24
  %t512 = add i64 %t508, %t509
  %t514 = sub i64 %t512, 1
  %t515 = load i64, ptr %l34, !tbaa !24
  %t518 = sdiv i64 %t514, %t515
  store i64 %t518, ptr %l248, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l248, !tbaa !24
  br label %bb84
bb84:
  %t520 = load i64, ptr %l248, !tbaa !24
  store i64 %t520, ptr %l245, !tbaa !24
  br label %bb85
bb85:
  %t521 = load i64, ptr %l245, !tbaa !24
  store i64 %t521, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb86
bb86:
  %t522 = load i64, ptr %l36, !tbaa !24
  %t523 = load i64, ptr %l35, !tbaa !24
  %t526 = icmp slt i64 %t522, %t523
  %t528 = xor i1 %t526, true
  br i1 %t528, label %bb87, label %bb88
bb87:
  br label %bb99
bb88:
  br label %bb89
bb89:
  %t530 = load i64, ptr %l32, !tbaa !24
  %t531 = load i64, ptr %l36, !tbaa !24
  %t532 = load i64, ptr %l34, !tbaa !24
  %t535 = mul i64 %t531, %t532
  %t538 = add i64 %t530, %t535
  store i64 %t538, ptr %l37, !tbaa !24
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/eval:Machine", ptr %t540, i32 0, i32 67
  %t543 = load i64, ptr %l37, !tbaa !24
  %t546 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t542, i64 %t543)
  store i64 %t546, ptr %l269
  br label %bb90
bb90:
  %t547 = load i64, ptr %l1, !tbaa !24
  %t548 = load i64, ptr %l269, !tbaa !24
  %t550 = icmp ne i64 %t548, %t547
  br i1 %t550, label %bb91, label %bb92
bb91:
  br label %bb98
bb92:
  br label %bb93
bb93:
  %t552 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 6
  store ptr %t552, ptr %l272, !tbaa !29
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/eval:Machine", ptr %t553, i32 0, i32 68
  %t556 = load i64, ptr %l37, !tbaa !24
  %t559 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t555, i64 %t556)
  store i64 %t559, ptr %l276
  br label %bb94
bb94:
  %t560 = load ptr, ptr %l272, !tbaa !29
  %t561 = load i64, ptr %l276, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t560, i64 %t561)
  br label %bb95
bb95:
  %t562 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 7
  store ptr %t562, ptr %l277, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = getelementptr %"compiler/eval:Machine", ptr %t563, i32 0, i32 69
  %t566 = load i64, ptr %l37, !tbaa !24
  %t569 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t565, i64 %t566)
  store i64 %t569, ptr %l281
  br label %bb96
bb96:
  %t570 = load ptr, ptr %l277, !tbaa !29
  %t571 = load i64, ptr %l281, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t570, i64 %t571)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t572 = load i64, ptr %l36, !tbaa !24
  %t575 = add i64 %t572, 1
  store i64 %t575, ptr %l36, !tbaa !24
  br label %bb86
bb99:
  %t577 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 0
  store i64 1, ptr %t577, !tbaa !24
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = getelementptr %"compiler/eval:Machine", ptr %t578, i32 0, i32 64
  store ptr %t580, ptr %l286, !tbaa !29
  %t581 = load i64, ptr %l6, !tbaa !24
  store i64 %t581, ptr %l287, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l288, ptr %l8, i64 280, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3agenRec(ptr %t582, ptr %s0, ptr %l288)
  call void @llvm.memmove.p0.p0.i64(ptr %l290, ptr %t582, i64 280, i1 false)
  br label %bb100
bb100:
  %t584 = load ptr, ptr %l286, !tbaa !29
  %t585 = load i64, ptr %l287, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t586, ptr %l290, i64 280, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %s0, ptr %t584, i64 %t585, ptr %t586)
  br label %bb101
bb101:
  %t587 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %t587)
  br label %bb102
bb102:
  %t589 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l293, ptr %l7, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t591, ptr %l293, i64 136, i1 false)
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereturned(ptr %v0, ptr %t589, ptr %t591)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etoTargets(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/eval:task"
  %l6 = alloca ptr
  %l7 = alloca %"compiler/mir:Task"
  %l8 = alloca { { i64, ptr }, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/eval:Ptr"
  %l19 = alloca i32
  %l20 = alloca %"compiler/eval:Ptr"
  %l25 = alloca %"compiler/eval:task"
  %l29 = alloca ptr
  %l33 = alloca %"compiler/mir:Task"
  %l36 = alloca %"compiler/mir:Task"
  %l39 = alloca { { i64, ptr }, i64 }
  %l48 = alloca %"compiler/eval:Ptr"
  %l53 = alloca i64
  %l56 = alloca i64
  %l74 = alloca ptr
  %l80 = alloca %"compiler/eval:Ptr"
  %l81 = alloca %"compiler/eval:Ptr"
  %l84 = alloca i32
  %l89 = alloca i32
  %l92 = alloca %"compiler/eval:Ptr"
  %l94 = alloca i64
  %l95 = alloca i64
  %l99 = alloca i64
  %l101 = alloca %"compiler/eval:Ptr"
  %l106 = alloca i1
  %l108 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i32
  %l116 = alloca i1
  %l118 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i32
  %l125 = alloca ptr
  %l143 = alloca %"compiler/eval:Ptr"
  %l144 = alloca i64
  %l150 = alloca ptr
  %l151 = alloca %"compiler/eval:Ptr"
  %l152 = alloca %"compiler/eval:Ptr"
  %l155 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t23 = alloca %"compiler/mir:Task", align 8
  %t33 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 57
  %t7 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t3, i64 %a2)
  store %"compiler/eval:task" %t7, ptr %l25
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:task", ptr %l25
  store %"compiler/eval:task" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 26
  %t12 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  store ptr %t16, ptr %l29
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l29, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t20 = getelementptr %"compiler/mir:Fn", ptr %t18, i32 0, i32 16
  %t21 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t23, ptr %v0, ptr %t20, i64 %t22)
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %t23, i64 144, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l33, i64 144, i1 false)
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l6, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %l7, i64 144, i1 false)
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l36, i64 144, i1 false)
  %t35 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v0, ptr %s0, ptr %t26, ptr %t27, ptr %t33, i64 %t30)
  store { { i64, ptr }, i64 } %t35, ptr %l39
  br label %bb4
bb4:
  %t36 = load { { i64, ptr }, i64 }, ptr %l39
  store { { i64, ptr }, i64 } %t36, ptr %l8
  %t37 = getelementptr { { i64, ptr }, i64 }, ptr %l8, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l9, !tbaa !24
  %t40 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 3
  %t41 = getelementptr %"compiler/mir:Range", ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  store i64 %t44, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t48 = icmp eq i64 %t46, 0
  br i1 %t48, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t56 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t50, i64 %t51, { i64, [4 x i64] } %a3, i64 1)
  store %"compiler/eval:Ptr" %t56, ptr %l48
  br label %bb8
bb8:
  %t57 = load %"compiler/eval:Ptr", ptr %l48
  store %"compiler/eval:Ptr" %t57, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  store i64 %t58, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t60 = load i64, ptr %l13, !tbaa !24
  %t61 = load i64, ptr %l12, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb9, label %bb10
bb9:
  %t66 = load i64, ptr %l14, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb14
bb11:
  %t70 = load i64, ptr %l13, !tbaa !24
  %t71 = load i64, ptr %l12, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l14, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l14, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l56, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb13
bb13:
  %t86 = load i64, ptr %l56, !tbaa !24
  store i64 %t86, ptr %l53, !tbaa !24
  br label %bb14
bb14:
  %t87 = load i64, ptr %l53, !tbaa !24
  store i64 %t87, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load i64, ptr %l16, !tbaa !24
  %t89 = load i64, ptr %l15, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t96 = load i64, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l16, !tbaa !24
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l17, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l74, !tbaa !29
  %t107 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l17, !tbaa !24
  %t112 = mul i64 8, %t110
  %t115 = add i64 %t109, %t112
  %t118 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t108, i64 %t115)
  store %"compiler/eval:Ptr" %t118, ptr %l80
  br label %bb19
bb19:
  %t119 = load ptr, ptr %l74, !tbaa !29
  %t120 = load %"compiler/eval:Ptr", ptr %l80
  %t121 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t119, %"compiler/eval:Ptr" %t120)
  store %"compiler/eval:Ptr" %t121, ptr %l81
  br label %bb20
bb20:
  %t122 = load %"compiler/eval:Ptr", ptr %l81
  store %"compiler/eval:Ptr" %t122, ptr %l18
  %t123 = load i64, ptr %l10, !tbaa !24
  %t125 = icmp eq i64 %t123, 1
  br i1 %t125, label %bb21, label %bb22
bb21:
  %t127 = load i32, ptr %l4, !tbaa !23
  store i32 %t127, ptr %l84, !tbaa !23
  br label %bb24
bb22:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l4, !tbaa !23
  %t131 = load i64, ptr %l17, !tbaa !24
  %t135 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t129, i32 %t130, i64 %t131)
  store i32 %t135, ptr %l89
  br label %bb23
bb23:
  %t136 = load i32, ptr %l89, !tbaa !23
  store i32 %t136, ptr %l84, !tbaa !23
  br label %bb24
bb24:
  %t137 = load i32, ptr %l84, !tbaa !23
  store i32 %t137, ptr %l19, !tbaa !23
  %t138 = load i64, ptr %l10, !tbaa !24
  %t140 = icmp eq i64 %t138, 1
  br i1 %t140, label %bb25, label %bb26
bb25:
  %t142 = load %"compiler/eval:Ptr", ptr %l11
  store %"compiler/eval:Ptr" %t142, ptr %l92
  br label %bb29
bb26:
  %t144 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l94, !tbaa !24
  %t146 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t147 = load i64, ptr %t146, !tbaa !24
  store i64 %t147, ptr %l95, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l4, !tbaa !23
  %t150 = load i64, ptr %l17, !tbaa !24
  %t154 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t148, i32 %t149, i64 %t150)
  store i64 %t154, ptr %l99
  br label %bb27
bb27:
  %t155 = load i64, ptr %l95, !tbaa !24
  %t156 = load i64, ptr %l99, !tbaa !24
  %t157 = add i64 %t155, %t156
  %t158 = load i64, ptr %l94, !tbaa !24
  %t160 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t158, i64 %t157)
  store %"compiler/eval:Ptr" %t160, ptr %l101
  br label %bb28
bb28:
  %t161 = load %"compiler/eval:Ptr", ptr %l101
  store %"compiler/eval:Ptr" %t161, ptr %l92
  br label %bb29
bb29:
  %t162 = load %"compiler/eval:Ptr", ptr %l92
  store %"compiler/eval:Ptr" %t162, ptr %l20
  %t163 = load i64, ptr %l17, !tbaa !24
  %t164 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 7
  %t165 = getelementptr %"compiler/mir:Range", ptr %t164, i32 0, i32 1
  %t166 = load i32, ptr %t165, !tbaa !23
  %t168 = sext i32 %t166 to i64
  %t171 = icmp slt i64 %t163, %t168
  br i1 %t171, label %bb30, label %bb31
bb30:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/eval:Machine", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l108, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/eval:Machine", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t181 = load i32, ptr %l19, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l112
  br label %bb32
bb31:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb34
bb32:
  %t185 = load ptr, ptr %l108, !tbaa !29
  %t186 = load i32, ptr %l112, !tbaa !23
  %t187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t187, ptr %l113
  br label %bb33
bb33:
  %t188 = load i32, ptr %l113, !range !{i32 0, i32 33}
  %t190 = trunc i64 19 to i32
  %t191 = icmp eq i32 %t188, %t190
  store i1 %t191, ptr %l106, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l106, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Machine", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l118, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/eval:Machine", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load i32, ptr %l19, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l122
  br label %bb37
bb36:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb39
bb37:
  %t206 = load ptr, ptr %l118, !tbaa !29
  %t207 = load i32, ptr %l122, !tbaa !23
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t208, ptr %l123
  br label %bb38
bb38:
  %t209 = load i32, ptr %l123, !tbaa !23
  %t210 = icmp eq i32 %t209, 0
  store i1 %t210, ptr %l116, !tbaa !21
  br label %bb39
bb39:
  %t212 = load i1, ptr %l116, !tbaa !21
  br i1 %t212, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l125, !tbaa !29
  %t214 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 2
  %t215 = load i64, ptr %t214, !tbaa !24
  %t216 = load i64, ptr %l9, !tbaa !24
  %t217 = load i64, ptr %l10, !tbaa !24
  %t219 = mul i64 8, %t217
  %t222 = add i64 %t216, %t219
  %t223 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 4
  %t224 = getelementptr %"compiler/mir:Range", ptr %t223, i32 0, i32 1
  %t225 = load i32, ptr %t224, !tbaa !23
  %t227 = sext i32 %t225 to i64
  %t229 = mul i64 16, %t227
  %t232 = add i64 %t222, %t229
  %t233 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 2
  %t234 = getelementptr %"compiler/mir:Range", ptr %t233, i32 0, i32 1
  %t235 = load i32, ptr %t234, !tbaa !23
  %t237 = sext i32 %t235 to i64
  %t239 = mul i64 8, %t237
  %t242 = add i64 %t232, %t239
  %t244 = add i64 %t242, 16
  %t245 = load i64, ptr %l17, !tbaa !24
  %t247 = mul i64 8, %t245
  %t250 = add i64 %t244, %t247
  %t253 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t215, i64 %t250)
  store %"compiler/eval:Ptr" %t253, ptr %l143
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t254 = load ptr, ptr %l125, !tbaa !29
  %t255 = load %"compiler/eval:Ptr", ptr %l143
  %t256 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t254, %"compiler/eval:Ptr" %t255, i64 8)
  store i64 %t256, ptr %l144
  br label %bb43
bb43:
  %t257 = load i64, ptr %l144, !tbaa !24
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load %"compiler/eval:Ptr", ptr %l18
  %t260 = load %"compiler/eval:Ptr", ptr %l20
  %t261 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayTarget(ptr %v0, ptr %t258, %"compiler/eval:Ptr" %t259, %"compiler/eval:Ptr" %t260, i32 %t261, i64 %t257)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb45:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l150, !tbaa !29
  %t269 = load %"compiler/eval:Ptr", ptr %l18
  store %"compiler/eval:Ptr" %t269, ptr %l151
  %t270 = load %"compiler/eval:Ptr", ptr %l20
  store %"compiler/eval:Ptr" %t270, ptr %l152
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i32, ptr %l19, !tbaa !23
  %t275 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t271, i32 %t272)
  store i64 %t275, ptr %l155
  br label %bb46
bb46:
  %t276 = load ptr, ptr %l150, !tbaa !29
  %t277 = load %"compiler/eval:Ptr", ptr %l151
  %t278 = load %"compiler/eval:Ptr", ptr %l152
  %t279 = load i64, ptr %l155, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t276, %"compiler/eval:Ptr" %t277, %"compiler/eval:Ptr" %t278, i64 %t279)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb48:
  %t280 = load i64, ptr %l16, !tbaa !24
  %t283 = add i64 %t280, 1
  store i64 %t283, ptr %l16, !tbaa !24
  br label %bb15
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [7 x i64] } %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l38 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l47 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l56 = alloca i64
  %l62 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i32
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l5, !tbaa !24
  %t10 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i32 }, ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11
  store i32 %t12, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  br label %bb18
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 35
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l19
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb5, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l18
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t25, ptr %l14, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t27, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l21, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l30
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb14
bb11:
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = load i32, ptr %l30, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s1, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l31
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t53 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t51, i64 %t50)
  store i1 %t53, ptr %l33
  br label %bb13
bb13:
  %t54 = load i1, ptr %l33, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l23, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyExtern, !tbaa !27
  %t60 = load %"compiler/source:Span", ptr %l2
  %t62 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t58, 0
  %t64 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t62, %"compiler/source:Span" %t60, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t64, ptr %l38
  %t65 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l38, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l40, !tbaa !24
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t81 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l38, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t81, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l38
  store { { i64, ptr }, %"compiler/source:Span" } %t82, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb44
bb18:
  %t83 = load { i64, [7 x i64] }, ptr %l1
  %t85 = extractvalue { i64, [7 x i64] } %t83, 0
  %t86 = icmp eq i64 %t85, 4
  br i1 %t86, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t88 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyCFunc, !tbaa !27
  %t90 = load %"compiler/source:Span", ptr %l2
  %t92 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t88, 0
  %t94 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t92, %"compiler/source:Span" %t90, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t94, ptr %l47
  %t95 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l47, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l48, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l49, !tbaa !24
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l50, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t111 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l47, i32 0, i32 0
  store { i64, ptr } %t110, ptr %t111, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t112 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l47
  store { { i64, ptr }, %"compiler/source:Span" } %t112, ptr %rv
  br label %ret
bb22:
  %t113 = load { i64, [7 x i64] }, ptr %l1
  %t115 = extractvalue { i64, [7 x i64] } %t113, 0
  %t116 = icmp eq i64 %t115, 0
  br i1 %t116, label %bb23, label %bb24
bb23:
  %t118 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t118, i32 0, i32 0
  %t120 = load { i64, [2 x i64] }, ptr %t119
  store { i64, [2 x i64] } %t120, ptr %l8
  br label %bb25
bb24:
  br label %bb39
bb25:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, [2 x i64] }, ptr %l8
  %t126 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t122, { i64, [2 x i64] } %t123)
  store i64 %t126, ptr %l56
  br label %bb26
bb26:
  %t127 = load i64, ptr %l56, !tbaa !24
  store i64 %t127, ptr %l9, !tbaa !24
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = icmp slt i64 %t128, 0
  br i1 %t130, label %bb27, label %bb28
bb27:
  %t132 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t134 = load %"compiler/source:Span", ptr %l2
  %t136 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t132, 0
  %t138 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t136, %"compiler/source:Span" %t134, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t138, ptr %l62
  %t139 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l62, i32 0, i32 0
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l63, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l64, !tbaa !24
  %t143 = load i64, ptr %l64, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l65, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l64, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t155 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l62, i32 0, i32 0
  store { i64, ptr } %t154, ptr %t155, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l62
  store { { i64, ptr }, %"compiler/source:Span" } %t156, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t157 = load ptr, ptr %l3, !tbaa !29
  %t158 = load i64, ptr %l9, !tbaa !24
  %t161 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v1, ptr %t157, i64 %t158)
  %t162 = extractvalue { i32, i1 } %t161, 1
  %t163 = extractvalue { i32, i1 } %t161, 0
  store i32 %t163, ptr %l70
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb31, label %ok.165, !prof !99
ok.165:
  store i1 %t162, ptr %l69
  br label %bb30
bb30:
  %t166 = load i1, ptr %l69, !tbaa !21
  store i1 %t166, ptr %l66, !tbaa !21
  br label %bb33
bb31:
  br label %bb32
bb32:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb33
bb33:
  %t167 = load i1, ptr %l66, !tbaa !21
  %t168 = xor i1 %t167, true
  br i1 %t168, label %bb34, label %bb35
bb34:
  %t170 = load ptr, ptr %l3, !tbaa !29
  %t171 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t170, i64 %t171, i1 true)
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t175 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %a4, i64 %t175)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_69287ebff671eb2d_9fd35f0201a42c21)
  unreachable
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t178, ptr %l77, !tbaa !27
  %t179 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t179, ptr %l78
  br label %bb45
bb45:
  %t180 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t181 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t180, 0
  %t182 = load %"compiler/source:Span", ptr %l78
  %t183 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t181, %"compiler/source:Span" %t182, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t183, ptr %l79
  %t184 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l79, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l80, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l81, !tbaa !24
  %t188 = load i64, ptr %l81, !tbaa !24
  %t189 = mul i64 %t188, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t189)
  %t191 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l82, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l81, !tbaa !24
  %t198 = mul i64 %t197, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  %t199 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t200 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l79, i32 0, i32 0
  store { i64, ptr } %t199, ptr %t200, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t201 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l79
  store { { i64, ptr }, %"compiler/source:Span" } %t201, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, %"compiler/source:Span" } %rr
}

define dso_local { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyTerm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, [8 x i64] } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l2 = alloca { i64, [8 x i64] }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l15 = alloca i1
  %l21 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l38 = alloca %"compiler/mir:Call"
  %l43 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, %"compiler/source:Span" }
  store { i64, [8 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [8 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 9
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l5
  %t10 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 20}
  store i32 %t12, ptr %l6
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t14 = load i32, ptr %l6, !range !{i32 0, i32 20}
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t19 = load i32, ptr %l6, !range !{i32 0, i32 20}
  %t21 = trunc i64 1 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyEnds, !tbaa !27
  %t27 = load %"compiler/source:Span", ptr %l5
  %t29 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t25, 0
  %t31 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t29, %"compiler/source:Span" %t27, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t31, ptr %l21
  %t32 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l21, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t48 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l21, i32 0, i32 0
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l21
  store { { i64, ptr }, %"compiler/source:Span" } %t49, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb23
bb10:
  %t50 = load { i64, [8 x i64] }, ptr %l2
  %t52 = extractvalue { i64, [8 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 4
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t55 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32 }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l7
  %t59 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l8, !tbaa !23
  br label %bb15
bb12:
  %t63 = load { i64, [8 x i64] }, ptr %l2
  %t65 = extractvalue { i64, [8 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 6
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32 }, ptr %t68, i32 0, i32 0
  %t70 = load %"compiler/source:Span", ptr %t69
  store %"compiler/source:Span" %t70, ptr %l7
  %t72 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32 }, ptr %t72, i32 0, i32 1
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l8, !tbaa !23
  br label %bb15
bb14:
  br label %bb18
bb15:
  store ptr %a0, ptr %l33, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %a1, i32 0, i32 14
  %t80 = load i32, ptr %l8, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t85 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %t79, i64 %t82)
  store %"compiler/mir:Call" %t85, ptr %l38
  br label %bb16
bb16:
  %t86 = getelementptr %"compiler/mir:Call", ptr %l38, i32 0, i32 0
  %t87 = load { i64, [7 x i64] }, ptr %t86
  %t88 = load %"compiler/source:Span", ptr %l7
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t96 = call { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyCall(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t91, { i64, [7 x i64] } %t87, %"compiler/source:Span" %t88, ptr %a3, ptr %a4)
  store { { i64, ptr }, %"compiler/source:Span" } %t96, ptr %l43
  br label %bb17
bb17:
  %t97 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l43, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l44, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l45, !tbaa !24
  %t101 = load i64, ptr %l45, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l46, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l45, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t113 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l43, i32 0, i32 0
  store { i64, ptr } %t112, ptr %t113, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t114 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l43
  store { { i64, ptr }, %"compiler/source:Span" } %t114, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_86c25f3ef178583f_f0c157887637479b)
  unreachable
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t115, ptr %l48, !tbaa !27
  %t116 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t116, ptr %l49
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t118 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t117, 0
  %t119 = load %"compiler/source:Span", ptr %l49
  %t120 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t118, %"compiler/source:Span" %t119, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t120, ptr %l50
  %t121 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l50, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l51, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l52, !tbaa !24
  %t125 = load i64, ptr %l52, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l53, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l52, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t137 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l50, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t137, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t138 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l50
  store { { i64, ptr }, %"compiler/source:Span" } %t138, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, %"compiler/source:Span" } %rr
}

define dso_local void @compiler_2feval_2efibFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l28 = alloca %"compiler/mir:Fn"
  %l32 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l44 = alloca i32
  %l48 = alloca i32
  %l52 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i32
  %l58 = alloca i32
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, [4 x i64] }
  %l70 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca %"compiler/mir:Lvalue"
  %l82 = alloca { i64, [21 x i64] }
  %l84 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca { i64, [4 x i64] }
  %l89 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i32
  %l94 = alloca i32
  %l95 = alloca { i64, [4 x i64] }
  %l98 = alloca ptr
  %l100 = alloca { i64, [2 x i64] }
  %l102 = alloca { i64, [7 x i64] }
  %l103 = alloca ptr
  %l105 = alloca %"compiler/mir:Lvalue"
  %l107 = alloca { i64, ptr }
  %l108 = alloca %"compiler/mir:Range"
  %l109 = alloca %"compiler/mir:Range"
  %l111 = alloca %"compiler/mir:Lvalue"
  %l115 = alloca %"compiler/mir:Call"
  %l116 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i32
  %l125 = alloca i64
  %l126 = alloca i32
  %l127 = alloca i32
  %l128 = alloca { i64, [4 x i64] }
  %l131 = alloca ptr
  %l133 = alloca { i64, [2 x i64] }
  %l135 = alloca { i64, [7 x i64] }
  %l136 = alloca ptr
  %l138 = alloca %"compiler/mir:Lvalue"
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/mir:Range"
  %l142 = alloca %"compiler/mir:Range"
  %l144 = alloca %"compiler/mir:Lvalue"
  %l148 = alloca %"compiler/mir:Call"
  %l149 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca i64
  %l159 = alloca i32
  %l160 = alloca i32
  %l162 = alloca %"compiler/mir:Lvalue"
  %l163 = alloca { i64, [4 x i64] }
  %l165 = alloca %"compiler/mir:Lvalue"
  %l171 = alloca { i64, [21 x i64] }
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/mir:Lvalue"
  %l180 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/mir:Fn", align 8
  %t98 = alloca { i64, [4 x i64] }, align 8
  %t117 = alloca { i64, [4 x i64] }, align 8
  %t125 = alloca { i64, [8 x i64] }, align 8
  %t142 = alloca { i64, [21 x i64] }, align 8
  %t157 = alloca { i64, [8 x i64] }, align 8
  %t176 = alloca { i64, [4 x i64] }, align 8
  %t195 = alloca { i64, [7 x i64] }, align 8
  %t207 = alloca { i64, [4 x i64] }, align 8
  %t247 = alloca { i64, [8 x i64] }, align 8
  %t266 = alloca { i64, [4 x i64] }, align 8
  %t285 = alloca { i64, [7 x i64] }, align 8
  %t297 = alloca { i64, [4 x i64] }, align 8
  %t337 = alloca { i64, [8 x i64] }, align 8
  %t357 = alloca { i64, [4 x i64] }, align 8
  %t366 = alloca { i64, [4 x i64] }, align 8
  %t383 = alloca { i64, [21 x i64] }, align 8
  %t400 = alloca { i64, [4 x i64] }, align 8
  %t406 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i32 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i32, ptr %l18, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l22
  br label %bb2
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l19, !tbaa !29
  %t13 = load i32, ptr %l22, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t12, i32 %t13, i32 %t11, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t15, ptr %l24
  br label %bb3
bb3:
  %t16 = load i32, ptr %l24, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t20, ptr %v0, ptr %v1, ptr %t17, i64 %t18, i32 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t20, i64 808, i1 false)
  br label %bb4
bb4:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t24, ptr %lp4
  %t25 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l28, i64 808, i1 false)
  %t26 = load ptr, ptr %lp4
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t26, i32 %t27, %"compiler/source:Span" %t28)
  store i32 %t32, ptr %l32
  br label %bb5
bb5:
  %t33 = load i32, ptr %l32, !tbaa !23
  store i32 %t33, ptr %l5, !tbaa !23
  %t34 = load ptr, ptr %lp4
  %t35 = load i32, ptr %l2, !tbaa !23
  %t36 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t34, i32 %t35, %"compiler/source:Span" %t36)
  store i32 %t40, ptr %l36
  br label %bb6
bb6:
  %t41 = load i32, ptr %l36, !tbaa !23
  store i32 %t41, ptr %l6, !tbaa !23
  %t42 = load ptr, ptr %lp4
  %t43 = load i32, ptr %l2, !tbaa !23
  %t44 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t48 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t42, i32 %t43, %"compiler/source:Span" %t44)
  store i32 %t48, ptr %l40
  br label %bb7
bb7:
  %t49 = load i32, ptr %l40, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t50 = load ptr, ptr %lp4
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t56 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t50, i32 %t51, %"compiler/source:Span" %t52)
  store i32 %t56, ptr %l44
  br label %bb8
bb8:
  %t57 = load i32, ptr %l44, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %lp4
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t64 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t58, i32 %t59, %"compiler/source:Span" %t60)
  store i32 %t64, ptr %l48
  br label %bb9
bb9:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l9, !tbaa !23
  %t66 = load ptr, ptr %lp4
  %t67 = load i32, ptr %l2, !tbaa !23
  %t68 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t72 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t66, i32 %t67, %"compiler/source:Span" %t68)
  store i32 %t72, ptr %l52
  br label %bb10
bb10:
  %t73 = load i32, ptr %l52, !tbaa !23
  store i32 %t73, ptr %l10, !tbaa !23
  %t74 = load ptr, ptr %lp4
  %t76 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l54
  br label %bb11
bb11:
  %t77 = load i32, ptr %l54, !tbaa !23
  store i32 %t77, ptr %l11, !tbaa !23
  %t78 = load ptr, ptr %lp4
  %t80 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t78)
  store i32 %t80, ptr %l56
  br label %bb12
bb12:
  %t81 = load i32, ptr %l56, !tbaa !23
  store i32 %t81, ptr %l12, !tbaa !23
  %t82 = load ptr, ptr %lp4
  %t84 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t82)
  store i32 %t84, ptr %l58
  br label %bb13
bb13:
  %t85 = load i32, ptr %l58, !tbaa !23
  store i32 %t85, ptr %l13, !tbaa !23
  %t86 = load ptr, ptr %lp4
  %t88 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t86)
  store i32 %t88, ptr %l60
  br label %bb14
bb14:
  %t89 = load i32, ptr %l60, !tbaa !23
  store i32 %t89, ptr %l14, !tbaa !23
  %t90 = load ptr, ptr %lp4
  store ptr %t90, ptr %l61, !tbaa !29
  %t91 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t91, ptr %l62, !tbaa !23
  %t92 = load i32, ptr %l5, !tbaa !23
  %t94 = sext i32 %t92 to i64
  store i64 %t94, ptr %l64, !tbaa !24
  store i32 15, ptr %l65
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t95, ptr %l66, !tbaa !23
  %t96 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t96, ptr %l67
  br label %bb15
bb15:
  %t97 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 0
  store i64 2, ptr %t99
  %t101 = insertvalue { i32, i64 } undef, i32 %t97, 0
  %t102 = insertvalue { i32, i64 } %t101, i64 2, 1
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  store { i32, i64 } %t102, ptr %t103
  %t104 = load { i64, [4 x i64] }, ptr %t98
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t106 = load i32, ptr %l62, !tbaa !23
  %t107 = load i64, ptr %l64, !tbaa !24
  %t108 = load i32, ptr %l65, !range !{i32 0, i32 54}
  %t109 = load i32, ptr %l66, !tbaa !23
  %t110 = load { i64, [4 x i64] }, ptr %l67
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t105, i32 %t106, i64 %t107, i32 %t108, i32 %t109, { i64, [4 x i64] } %t110, { i64, [4 x i64] } %t104)
  br label %bb16
bb16:
  %t112 = load ptr, ptr %lp4
  store ptr %t112, ptr %l70, !tbaa !29
  %t113 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t113, ptr %l71, !tbaa !23
  %t114 = load i32, ptr %l5, !tbaa !23
  %t116 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t114)
  store %"compiler/mir:Lvalue" %t116, ptr %l73
  br label %bb17
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t117
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 0
  store i64 1, ptr %t118
  %t119 = load %"compiler/mir:Lvalue", ptr %l73
  %t120 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t119, 0
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t120, ptr %t121
  %t122 = load { i64, [4 x i64] }, ptr %t117
  %t123 = load i32, ptr %l11, !tbaa !23
  %t124 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [8 x i64] }, ptr %t125, i32 0, i32 0
  store i64 2, ptr %t126
  %t128 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t122, 0
  %t130 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t128, i32 %t123, 1
  %t132 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t130, i32 %t124, 2
  %t133 = getelementptr { i64, [8 x i64] }, ptr %t125, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t132, ptr %t133
  %t134 = load { i64, [8 x i64] }, ptr %t125
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = load i32, ptr %l71, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t135, i32 %t136, { i64, [8 x i64] } %t134)
  br label %bb18
bb18:
  %t138 = load ptr, ptr %lp4
  %t139 = load i32, ptr %l11, !tbaa !23
  %t140 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t141 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t142, i32 0, i32 0
  store i64 4, ptr %t143
  %t145 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t140, 0
  %t147 = insertvalue { %"compiler/source:Span", i32 } %t145, i32 %t141, 1
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t147, ptr %t148
  %t149 = load { i64, [21 x i64] }, ptr %t142
  store { i64, [21 x i64] } %t149, ptr %l82
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t138, i32 %t139, ptr %l82)
  br label %bb19
bb19:
  %t153 = load ptr, ptr %lp4
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load i32, ptr %l11, !tbaa !23
  store i32 %t154, ptr %l85, !tbaa !23
  %t155 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t155, ptr %l86
  %t156 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t156, ptr %l87
  br label %bb20
bb20:
  store { i64, [8 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [8 x i64] }, ptr %t157, i32 0, i32 0
  store i64 5, ptr %t158
  %t159 = load %"compiler/source:Span", ptr %l86
  %t160 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t159, 0
  %t161 = load { i64, [4 x i64] }, ptr %l87
  %t162 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t160, { i64, [4 x i64] } %t161, 1
  %t163 = getelementptr { i64, [8 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t162, ptr %t163
  %t164 = load { i64, [8 x i64] }, ptr %t157
  %t165 = load ptr, ptr %l84, !tbaa !29
  %t166 = load i32, ptr %l85, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t165, i32 %t166, { i64, [8 x i64] } %t164)
  br label %bb21
bb21:
  %t168 = load ptr, ptr %lp4
  store ptr %t168, ptr %l89, !tbaa !29
  %t169 = load i32, ptr %l12, !tbaa !23
  store i32 %t169, ptr %l90, !tbaa !23
  %t170 = load i32, ptr %l6, !tbaa !23
  %t172 = sext i32 %t170 to i64
  store i64 %t172, ptr %l92, !tbaa !24
  store i32 4, ptr %l93
  %t173 = load i32, ptr %l2, !tbaa !23
  store i32 %t173, ptr %l94, !tbaa !23
  %t174 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t174, ptr %l95
  br label %bb22
bb22:
  %t175 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 0
  store i64 2, ptr %t177
  %t179 = insertvalue { i32, i64 } undef, i32 %t175, 0
  %t180 = insertvalue { i32, i64 } %t179, i64 1, 1
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  store { i32, i64 } %t180, ptr %t181
  %t182 = load { i64, [4 x i64] }, ptr %t176
  %t183 = load ptr, ptr %l89, !tbaa !29
  %t184 = load i32, ptr %l90, !tbaa !23
  %t185 = load i64, ptr %l92, !tbaa !24
  %t186 = load i32, ptr %l93, !range !{i32 0, i32 54}
  %t187 = load i32, ptr %l94, !tbaa !23
  %t188 = load { i64, [4 x i64] }, ptr %l95
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t183, i32 %t184, i64 %t185, i32 %t186, i32 %t187, { i64, [4 x i64] } %t188, { i64, [4 x i64] } %t182)
  br label %bb23
bb23:
  %t190 = load ptr, ptr %lp4
  store ptr %t190, ptr %l98, !tbaa !29
  %t191 = load i64, ptr %l1, !tbaa !24
  %t193 = call { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %t191)
  store { i64, [2 x i64] } %t193, ptr %l100
  br label %bb24
bb24:
  %t194 = load i32, ptr %l3, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t195
  %t196 = getelementptr { i64, [7 x i64] }, ptr %t195, i32 0, i32 0
  store i64 0, ptr %t196
  %t197 = load { i64, [2 x i64] }, ptr %l100
  %t198 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t197, 0
  %t200 = insertvalue { { i64, [2 x i64] }, i32 } %t198, i32 %t194, 1
  %t201 = getelementptr { i64, [7 x i64] }, ptr %t195, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t200, ptr %t201
  %t202 = load { i64, [7 x i64] }, ptr %t195
  store { i64, [7 x i64] } %t202, ptr %l102
  %t203 = load ptr, ptr %lp4
  store ptr %t203, ptr %l103, !tbaa !29
  %t204 = load i32, ptr %l6, !tbaa !23
  %t206 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t204)
  store %"compiler/mir:Lvalue" %t206, ptr %l105
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 0
  store i64 1, ptr %t208
  %t209 = load %"compiler/mir:Lvalue", ptr %l105
  %t210 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t209, 0
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t210, ptr %t211
  %t212 = load { i64, [4 x i64] }, ptr %t207
  %t213 = mul i64 1, 40
  %t214 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 1, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l107, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i64 0
  store { i64, [4 x i64] } %t212, ptr %t220
  %t221 = load ptr, ptr %l103, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t223 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t221, { i64, ptr } %t222)
  store %"compiler/mir:Range" %t223, ptr %l108
  br label %bb26
bb26:
  %t224 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t224, ptr %l109
  %t225 = load i32, ptr %l8, !tbaa !23
  %t227 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t225)
  store %"compiler/mir:Lvalue" %t227, ptr %l111
  br label %bb27
bb27:
  %t228 = load i32, ptr %l13, !tbaa !23
  %t229 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t230 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t231 = load { i64, [7 x i64] }, ptr %l102
  %t232 = load %"compiler/mir:Range", ptr %l108
  %t233 = load %"compiler/mir:Range", ptr %l109
  %t234 = load %"compiler/mir:Lvalue", ptr %l111
  %t238 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t231, %"compiler/mir:Range" %t232, %"compiler/mir:Range" %t233, %"compiler/mir:Lvalue" %t234, i1 true, i32 %t228, i32 %t229, i32 %t230)
  store %"compiler/mir:Call" %t238, ptr %l115
  br label %bb28
bb28:
  %t239 = load ptr, ptr %l98, !tbaa !29
  %t240 = load %"compiler/mir:Call", ptr %l115
  %t241 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t239, %"compiler/mir:Call" %t240)
  store i32 %t241, ptr %l116
  br label %bb29
bb29:
  %t242 = load i32, ptr %l116, !tbaa !23
  %t243 = load ptr, ptr %lp4
  %t244 = load i32, ptr %l12, !tbaa !23
  %t245 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [8 x i64] }, ptr %t247, i32 0, i32 0
  store i64 4, ptr %t248
  %t250 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t245, 0
  %t252 = insertvalue { %"compiler/source:Span", i32 } %t250, i32 %t242, 1
  %t253 = getelementptr { i64, [8 x i64] }, ptr %t247, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t252, ptr %t253
  %t254 = load { i64, [8 x i64] }, ptr %t247
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t243, i32 %t244, { i64, [8 x i64] } %t254)
  br label %bb30
bb30:
  %t258 = load ptr, ptr %lp4
  store ptr %t258, ptr %l122, !tbaa !29
  %t259 = load i32, ptr %l13, !tbaa !23
  store i32 %t259, ptr %l123, !tbaa !23
  %t260 = load i32, ptr %l7, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l125, !tbaa !24
  store i32 4, ptr %l126
  %t263 = load i32, ptr %l2, !tbaa !23
  store i32 %t263, ptr %l127, !tbaa !23
  %t264 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t264, ptr %l128
  br label %bb31
bb31:
  %t265 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [4 x i64] }, ptr %t266, i32 0, i32 0
  store i64 2, ptr %t267
  %t269 = insertvalue { i32, i64 } undef, i32 %t265, 0
  %t270 = insertvalue { i32, i64 } %t269, i64 2, 1
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t266, i32 0, i32 1
  store { i32, i64 } %t270, ptr %t271
  %t272 = load { i64, [4 x i64] }, ptr %t266
  %t273 = load ptr, ptr %l122, !tbaa !29
  %t274 = load i32, ptr %l123, !tbaa !23
  %t275 = load i64, ptr %l125, !tbaa !24
  %t276 = load i32, ptr %l126, !range !{i32 0, i32 54}
  %t277 = load i32, ptr %l127, !tbaa !23
  %t278 = load { i64, [4 x i64] }, ptr %l128
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t273, i32 %t274, i64 %t275, i32 %t276, i32 %t277, { i64, [4 x i64] } %t278, { i64, [4 x i64] } %t272)
  br label %bb32
bb32:
  %t280 = load ptr, ptr %lp4
  store ptr %t280, ptr %l131, !tbaa !29
  %t281 = load i64, ptr %l1, !tbaa !24
  %t283 = call { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %t281)
  store { i64, [2 x i64] } %t283, ptr %l133
  br label %bb33
bb33:
  %t284 = load i32, ptr %l3, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t285
  %t286 = getelementptr { i64, [7 x i64] }, ptr %t285, i32 0, i32 0
  store i64 0, ptr %t286
  %t287 = load { i64, [2 x i64] }, ptr %l133
  %t288 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t287, 0
  %t290 = insertvalue { { i64, [2 x i64] }, i32 } %t288, i32 %t284, 1
  %t291 = getelementptr { i64, [7 x i64] }, ptr %t285, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t290, ptr %t291
  %t292 = load { i64, [7 x i64] }, ptr %t285
  store { i64, [7 x i64] } %t292, ptr %l135
  %t293 = load ptr, ptr %lp4
  store ptr %t293, ptr %l136, !tbaa !29
  %t294 = load i32, ptr %l7, !tbaa !23
  %t296 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t294)
  store %"compiler/mir:Lvalue" %t296, ptr %l138
  br label %bb34
bb34:
  store { i64, [4 x i64] } zeroinitializer, ptr %t297
  %t298 = getelementptr { i64, [4 x i64] }, ptr %t297, i32 0, i32 0
  store i64 1, ptr %t298
  %t299 = load %"compiler/mir:Lvalue", ptr %l138
  %t300 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t299, 0
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t297, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t300, ptr %t301
  %t302 = load { i64, [4 x i64] }, ptr %t297
  %t303 = mul i64 1, 40
  %t304 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 1, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l140, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr { i64, [4 x i64] }, ptr %t309, i64 0
  store { i64, [4 x i64] } %t302, ptr %t310
  %t311 = load ptr, ptr %l136, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t313 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t311, { i64, ptr } %t312)
  store %"compiler/mir:Range" %t313, ptr %l141
  br label %bb35
bb35:
  %t314 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t314, ptr %l142
  %t315 = load i32, ptr %l9, !tbaa !23
  %t317 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t315)
  store %"compiler/mir:Lvalue" %t317, ptr %l144
  br label %bb36
bb36:
  %t318 = load i32, ptr %l14, !tbaa !23
  %t319 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t320 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t321 = load { i64, [7 x i64] }, ptr %l135
  %t322 = load %"compiler/mir:Range", ptr %l141
  %t323 = load %"compiler/mir:Range", ptr %l142
  %t324 = load %"compiler/mir:Lvalue", ptr %l144
  %t328 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t321, %"compiler/mir:Range" %t322, %"compiler/mir:Range" %t323, %"compiler/mir:Lvalue" %t324, i1 true, i32 %t318, i32 %t319, i32 %t320)
  store %"compiler/mir:Call" %t328, ptr %l148
  br label %bb37
bb37:
  %t329 = load ptr, ptr %l131, !tbaa !29
  %t330 = load %"compiler/mir:Call", ptr %l148
  %t331 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t329, %"compiler/mir:Call" %t330)
  store i32 %t331, ptr %l149
  br label %bb38
bb38:
  %t332 = load i32, ptr %l149, !tbaa !23
  %t333 = load ptr, ptr %lp4
  %t334 = load i32, ptr %l13, !tbaa !23
  %t335 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [8 x i64] }, ptr %t337, i32 0, i32 0
  store i64 4, ptr %t338
  %t340 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t335, 0
  %t342 = insertvalue { %"compiler/source:Span", i32 } %t340, i32 %t332, 1
  %t343 = getelementptr { i64, [8 x i64] }, ptr %t337, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t342, ptr %t343
  %t344 = load { i64, [8 x i64] }, ptr %t337
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t333, i32 %t334, { i64, [8 x i64] } %t344)
  br label %bb39
bb39:
  %t348 = load ptr, ptr %lp4
  store ptr %t348, ptr %l155, !tbaa !29
  %t349 = load i32, ptr %l14, !tbaa !23
  store i32 %t349, ptr %l156, !tbaa !23
  %t350 = load i32, ptr %l10, !tbaa !23
  %t352 = sext i32 %t350 to i64
  store i64 %t352, ptr %l158, !tbaa !24
  store i32 3, ptr %l159
  %t353 = load i32, ptr %l2, !tbaa !23
  store i32 %t353, ptr %l160, !tbaa !23
  %t354 = load i32, ptr %l8, !tbaa !23
  %t356 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t354)
  store %"compiler/mir:Lvalue" %t356, ptr %l162
  br label %bb40
bb40:
  store { i64, [4 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [4 x i64] }, ptr %t357, i32 0, i32 0
  store i64 1, ptr %t358
  %t359 = load %"compiler/mir:Lvalue", ptr %l162
  %t360 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t359, 0
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t357, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t360, ptr %t361
  %t362 = load { i64, [4 x i64] }, ptr %t357
  store { i64, [4 x i64] } %t362, ptr %l163
  %t363 = load i32, ptr %l9, !tbaa !23
  %t365 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t363)
  store %"compiler/mir:Lvalue" %t365, ptr %l165
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t366
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t366, i32 0, i32 0
  store i64 1, ptr %t367
  %t368 = load %"compiler/mir:Lvalue", ptr %l165
  %t369 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t368, 0
  %t370 = getelementptr { i64, [4 x i64] }, ptr %t366, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t369, ptr %t370
  %t371 = load { i64, [4 x i64] }, ptr %t366
  %t372 = load ptr, ptr %l155, !tbaa !29
  %t373 = load i32, ptr %l156, !tbaa !23
  %t374 = load i64, ptr %l158, !tbaa !24
  %t375 = load i32, ptr %l159, !range !{i32 0, i32 54}
  %t376 = load i32, ptr %l160, !tbaa !23
  %t377 = load { i64, [4 x i64] }, ptr %l163
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t372, i32 %t373, i64 %t374, i32 %t375, i32 %t376, { i64, [4 x i64] } %t377, { i64, [4 x i64] } %t371)
  br label %bb42
bb42:
  %t379 = load ptr, ptr %lp4
  %t380 = load i32, ptr %l14, !tbaa !23
  %t381 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t382 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t383
  %t384 = getelementptr { i64, [21 x i64] }, ptr %t383, i32 0, i32 0
  store i64 4, ptr %t384
  %t386 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t381, 0
  %t388 = insertvalue { %"compiler/source:Span", i32 } %t386, i32 %t382, 1
  %t389 = getelementptr { i64, [21 x i64] }, ptr %t383, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t388, ptr %t389
  %t390 = load { i64, [21 x i64] }, ptr %t383
  store { i64, [21 x i64] } %t390, ptr %l171
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t379, i32 %t380, ptr %l171)
  br label %bb43
bb43:
  %t394 = load ptr, ptr %lp4
  store ptr %t394, ptr %l173, !tbaa !29
  %t395 = load i32, ptr %l14, !tbaa !23
  store i32 %t395, ptr %l174, !tbaa !23
  %t396 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t396, ptr %l175
  %t397 = load i32, ptr %l10, !tbaa !23
  %t399 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t397)
  store %"compiler/mir:Lvalue" %t399, ptr %l177
  br label %bb44
bb44:
  store { i64, [4 x i64] } zeroinitializer, ptr %t400
  %t401 = getelementptr { i64, [4 x i64] }, ptr %t400, i32 0, i32 0
  store i64 1, ptr %t401
  %t402 = load %"compiler/mir:Lvalue", ptr %l177
  %t403 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t402, 0
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t400, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t403, ptr %t404
  %t405 = load { i64, [4 x i64] }, ptr %t400
  store { i64, [8 x i64] } zeroinitializer, ptr %t406
  %t407 = getelementptr { i64, [8 x i64] }, ptr %t406, i32 0, i32 0
  store i64 5, ptr %t407
  %t408 = load %"compiler/source:Span", ptr %l175
  %t409 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t408, 0
  %t411 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t409, { i64, [4 x i64] } %t405, 1
  %t412 = getelementptr { i64, [8 x i64] }, ptr %t406, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t411, ptr %t412
  %t413 = load { i64, [8 x i64] }, ptr %t406
  %t414 = load ptr, ptr %l173, !tbaa !29
  %t415 = load i32, ptr %l174, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t414, i32 %t415, { i64, [8 x i64] } %t413)
  br label %bb45
bb45:
  %t417 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l180, ptr %t417, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l180, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2efits128(i64 %a0, i64 %a1, i1 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, i64 }
  %l8 = alloca { i64, i64 }
  %l12 = alloca i1
  %l19 = alloca { i64, i64 }
  %l26 = alloca i64
  %l30 = alloca { i64, i64 }
  %l37 = alloca i64
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp slt i64 %t3, 0
  store i1 %t5, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l12, !tbaa !21
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t8 = load i1, ptr %l4, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb6, label %bb7
bb5:
  br label %bb11
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = call { i64, i64 } @compiler_2feval_2ewideMin(i64 %t13)
  store { i64, i64 } %t15, ptr %l19
  br label %bb9
bb9:
  %t16 = load { i64, i64 }, ptr %l19
  store { i64, i64 } %t16, ptr %l5
  %t17 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = load i64, ptr %l0, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  %t31 = call i64 @compiler_2feval_2ecmp128(i64 %t23, i64 %t24, i64 %t18, i64 %t21, i1 true)
  store i64 %t31, ptr %l26
  br label %bb10
bb10:
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  store i1 %t33, ptr %rv
  br label %ret
bb11:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i1, ptr %l4, !tbaa !21
  %t39 = call { i64, i64 } @compiler_2feval_2ewideMax(i64 %t35, i1 %t36)
  store { i64, i64 } %t39, ptr %l30
  br label %bb12
bb12:
  %t40 = load { i64, i64 }, ptr %l30
  store { i64, i64 } %t40, ptr %l8
  %t41 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = load i64, ptr %l0, !tbaa !24
  %t48 = load i64, ptr %l1, !tbaa !24
  %t55 = call i64 @compiler_2feval_2ecmp128(i64 %t47, i64 %t48, i64 %t42, i64 %t45, i1 false)
  store i64 %t55, ptr %l37
  br label %bb13
bb13:
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sle i64 %t56, 0
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_3aSnapshot_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca %"compiler/eval:Snapshot"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l6
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call ptr @__olang_scope_hold(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = call ptr @__olang_region_make(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l10
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t29, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l12
  br label %bb8
bb8:
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e1
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l10
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_region_or(ptr %t37, ptr null)
  %t39 = call ptr @__olang_region_home(ptr %t38)
  %t40 = icmp ne ptr %t39, null
  %t41 = select i1 %t40, ptr %t39, ptr null
  call void @__olang_region_settle_in(ptr %t34, ptr %t41)
  br label %bb10
bb10:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l1
  %t43 = call ptr @__olang_scope_hold(ptr %v0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l14, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e2
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = call ptr @__olang_region_make(ptr %v0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l14, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l14
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t50, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l16
  br label %bb13
bb13:
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e2
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l14
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  call void @__olang_region_settle_in(ptr %t55, ptr %t62)
  br label %bb15
bb15:
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l2
  %t64 = call ptr @__olang_scope_hold(ptr %v0)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l18, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e3
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = call ptr @__olang_region_make(ptr %v0)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l18, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l18
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t71, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l20
  br label %bb18
bb18:
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e3
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t75 = load i64, ptr %l18
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = call ptr @__olang_region_or(ptr %t79, ptr null)
  %t81 = call ptr @__olang_region_home(ptr %t80)
  %t82 = icmp ne ptr %t81, null
  %t83 = select i1 %t82, ptr %t81, ptr null
  call void @__olang_region_settle_in(ptr %t76, ptr %t83)
  br label %bb20
bb20:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l3
  %t85 = call ptr @__olang_scope_hold(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l22, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e4
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = call ptr @__olang_region_make(ptr %v0)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l22, !tbaa !24
  br label %bb22
bb22:
  %t91 = load i64, ptr %l22
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t92, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l24
  br label %bb23
bb23:
  %t94 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e4
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = load i64, ptr %l22
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t104)
  br label %bb25
bb25:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l4
  %t106 = call ptr @__olang_scope_hold(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l26, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e5
  br i1 %t108, label %bb26, label %bb27
bb26:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l26, !tbaa !24
  br label %bb27
bb27:
  %t112 = load i64, ptr %l26
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t113)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %l28
  br label %bb28
bb28:
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e5
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load i64, ptr %l26
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr null
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = call ptr @__olang_region_or(ptr %t128, ptr null)
  %t130 = call ptr @__olang_region_home(ptr %t129)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr %t125
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = call ptr @__olang_region_home(ptr %t136)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr %t132
  call void @__olang_region_settle_in(ptr %t118, ptr %t139)
  br label %bb30
bb30:
  %t140 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  %t141 = getelementptr %"compiler/eval:Snapshot", ptr %l30, i32 0, i32 0
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %t141
  %t143 = getelementptr %"compiler/eval:Snapshot", ptr %l30, i32 0, i32 1
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t143
  %t145 = getelementptr %"compiler/eval:Snapshot", ptr %l30, i32 0, i32 2
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %t145
  %t147 = getelementptr %"compiler/eval:Snapshot", ptr %l30, i32 0, i32 3
  %t148 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %t147
  %t149 = getelementptr %"compiler/eval:Snapshot", ptr %l30, i32 0, i32 4
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %t149
  %t151 = getelementptr %"compiler/eval:Snapshot", ptr %l30, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t140, ptr %t151
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2feval_3acfn(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/eval:cfn"
  %t1 = alloca %"compiler/eval:cfn", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2feval_3acfn_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 264, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_empty_array = external constant [16 x i64]
@.d0 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_bench_" }>, align 8
@.d1 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_tile_bf16" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare i32 @__olang_err()
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_float(ptr, i64, double, i32)
declare void @__olang_sb_add(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal void @olang_lambda_4(ptr %env, %"compiler/eval:Ptr" %a0) #0 {
entry:
  %l0 = alloca %"compiler/eval:Ptr"
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l12 = alloca %"compiler/eval:Ptr"
  %l15 = alloca i64
  %l21 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l44 = alloca i1
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  store %"compiler/eval:Ptr" %a0, ptr %l0
  %cp0 = getelementptr { ptr, i64, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, i64, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i64, ptr %cp1, !tbaa !28
  %vq0 = getelementptr { ptr, i64, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/eval:Ptr", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp eq i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = getelementptr %"compiler/eval:Ptr", ptr %l0, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = getelementptr %"compiler/eval:Ptr", ptr %l0, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = sub i64 %t9, 8
  %t14 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t7, i64 %t11)
  store %"compiler/eval:Ptr" %t14, ptr %l12
  br label %bb4
bb4:
  %t15 = load %"compiler/eval:Ptr", ptr %l12
  store %"compiler/eval:Ptr" %t15, ptr %l1
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load %"compiler/eval:Ptr", ptr %l1
  %t20 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %vc0, ptr %t16, %"compiler/eval:Ptr" %t17, i64 8)
  store i64 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i64, ptr %l15, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = ashr i64 %t22, 16
  %t26 = and i64 %t24, 3
  store i64 %t26, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp eq i64 %t28, 3
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 23
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t38, %cv1
  store i64 %t42, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l27, !tbaa !24
  %t45 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb17
bb13:
  %t49 = load i64, ptr %l27, !tbaa !24
  %t51 = icmp sgt i64 %t49, 3
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i64 3, ptr %l33, !tbaa !24
  br label %bb16
bb15:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t55 = load i64, ptr %l33, !tbaa !24
  store i64 %t55, ptr %l30, !tbaa !24
  br label %bb17
bb17:
  %t56 = load i64, ptr %l30, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t58 = load %"compiler/eval:Ptr", ptr %l1
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = and i64 %t59, -196609
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = shl i64 %t62, 16
  %t67 = or i64 %t61, %t64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %vc0, ptr %t57, %"compiler/eval:Ptr" %t58, i64 8, i64 %t67)
  br label %bb18
bb18:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  store i1 %t77, ptr %l44, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 17
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t85 = load i1, ptr %l47, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load %"compiler/eval:Ptr", ptr %l0
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eholderCheck(ptr %vc0, ptr %t86, %"compiler/eval:Ptr" %t87)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare double @llvm.arithmetic.fence.f64(double)
declare bfloat @__olang_int_bf16(i64, i1)
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@olang_2esole_2ecompiler_2feval_3aMachine_2e61 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2feval_3aMachine_2e59 = weak hidden constant i1 false
define linkonce_odr void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2feval_3aframe(ptr %out) #0 {
entry:
  %l0 = alloca %"compiler/eval:frame"
  %t1 = alloca %"compiler/eval:frame", align 8
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_3aframe_2ector(ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 136, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define internal { i64, [4 x i64] } @olang_lambda_12(ptr %env, i64 %a0) #0 {
entry:
  %l2 = alloca %"compiler/mir:Range"
  %l9 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %cp0 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/mir:Range", ptr %cp1, !tbaa !28
  store %"compiler/mir:Range" %cv1, ptr %l2
  %vq0 = getelementptr { ptr, %"compiler/mir:Range", ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/mir:Fn", ptr %cv0, i32 0, i32 11
  %t4 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t11 = add i64 %t7, %a0
  %t14 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %vc0, ptr %t3, i64 %t11)
  store { i64, [4 x i64] } %t14, ptr %l9
  br label %bb1
bb1:
  %t15 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

@.d13 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_arg_count" }>, align 8
@.d14 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_arg" }>, align 8
@.d15 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_env" }>, align 8
declare i64 @__olang_env(ptr, ptr, i64)
@.d16 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_err" }>, align 8
@.d17 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_stat" }>, align 8
declare i32 @__olang_stat(ptr, ptr)
@.d18 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_dir" }>, align 8
@.d19 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_realpath" }>, align 8
@.d20 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_dir" }>, align 8
declare i64 @__olang_dir(ptr, ptr, i64)
declare i64 @__olang_realpath(ptr, ptr, i64)
@.d21 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"__olang_spawn" }>, align 8
declare i32 @__olang_spawn(ptr, i64, i32, i32, i32, ptr)
@.d22 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_spawn_as" }>, align 8
declare i32 @__olang_spawn_as(ptr, ptr, i64, i32, i32, i32, ptr)
@.d23 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_exec" }>, align 8
declare i32 @__olang_exec(ptr, ptr, i64)
@.d24 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_mkdtemp" }>, align 8
declare i32 @__olang_mkdtemp(ptr)
@.d25 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_dyncall" }>, align 8
@.d26 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_dyncall_var" }>, align 8
@.d27 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_dyncall_var" }>, align 8
declare i64 @__olang_dyncall(ptr, ptr, ptr, i8 zeroext)
declare i64 @__olang_dyncall_var(ptr, ptr, ptr, i8 zeroext, i64)
@.d28 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_dyncall_check" }>, align 8
declare i32 @__olang_dyncall_check(ptr, ptr, i8 zeroext)
@.d29 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_dyncall_var_check" }>, align 8
declare i32 @__olang_dyncall_var_check(ptr, ptr, i8 zeroext, i64)
@.d30 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_test_running" }>, align 8
@.d31 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_test_source" }>, align 8
@.d32 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_test_running" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_fuzz_input" }>, align 8
@.d35 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_bench_on" }>, align 8
@.d36 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_bench_allocs_made" }>, align 8
@.d37 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"__olang_bench_bytes_made" }>, align 8
@.d38 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"__olang_bench_instructions" }>, align 8
@.d39 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_tile_bf16" }>, align 8
@.d40 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_bench_keep" }>, align 8
@.d41 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_test_detach" }>, align 8
@.d42 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_on_crash" }>, align 8
@.d43 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_err" }>, align 8
@.d44 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_arg_count" }>, align 8
@.d45 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_arg" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3agenRec(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/eval:genRec"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 280, i1 false)
  %t2 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 6
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 280, i1 false)
  br label %ret
ret:
  ret void
}

@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_run_on_stack" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eLen_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2ePush_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8e30d4bcef98d937_821e6ec72834ca4b = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edecode(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_8d25544d0bd70291_3d464b777e1774ad = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eslotMask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaFree = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eNullPtr = available_externally constant <{ [16 x i8] }> <{ [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@G_2ecompiler_2feval_2eWhyNoBody = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2erRequest = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { %"compiler/eval:Ptr", i32 } } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobalAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2esaveAlloc(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2edrop(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_e7a4fa5689cb83c4_e9f49c5f7d359a08 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2esaveWords(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_75b3dda1da275889_df5a5485a99f3eed = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2egDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunlinkReg(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i64 %a3)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i64 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i64 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evFixed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evEnum = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [4 x i64] } %a4)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2feval_2evOrd = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
@G_2ecompiler_2feval_2eaValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_561376b2ca02a7ba_25f299f9320c8ad6 = external constant [0 x i8]
@G_2ecompiler_2feval_2evFloat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7b1287020d5a411f_7f0f28d70ecde84b = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyNaNSignal = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNaNOp = external constant <{ [8 x i8], ptr }>
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
@olang_loc_9c6d2d38b14ece16_85850a0ccdf8ec6a = external constant [0 x i8]
@olang_loc_3e93cd40ddf47e2b_3ba0afa8b25b773f = external constant [0 x i8]
declare ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2feval_2eWhyExtern = external constant <{ [8 x i8], ptr }>
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewaitsForTask(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@G_2ecompiler_2feval_2eWhyFfiPass = external constant <{ [8 x i8], ptr }>
@olang_loc_8455ed81fb66a668_e2c955a612231684 = external constant [0 x i8]
@olang_loc_e6f2fd943c115655_f5638f66c9629791 = external constant [0 x i8]
@olang_loc_24365dba12301136_85ae2e45ea64b572 = external constant [0 x i8]
@olang_loc_e79146937ca231cb_dd9a37031fe8e967 = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i8 @std_2fffi_2eCode(i32 %a0)
@G_2ecompiler_2feval_2evInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2feval_2evPair = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i8 @std_2fffi_2eArrayOf(i32 %a0)
declare i64 @std_2fffi_2eWordsFor(i64 %a0)
@G_2ecompiler_2feval_2evPtr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
@G_2ecompiler_2feval_2eForeignId = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@olang_loc_84b043302e365534_8c4896c766887f8 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i32, i64 } @std_2fffi_2eCall(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i8 %a3, i64 %a4)
@G_2ecompiler_2feval_2eWhyFfiFind = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyCFunc = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNullCall = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eaCode = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyNotModelled = external constant <{ [8 x i8], ptr }>
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_bde43f50f3dd47_4bb44709ac02dbdb = external constant [0 x i8]
@G_2ecompiler_2feval_2evUint = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ebmask(i64 %a0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %a0)
declare double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %a0, double %a1, i32 %a2)
declare i1 @compiler_2feval_2efloatFits(double %a0, i64 %a1, i1 %a2)
@G_2ecompiler_2feval_2eWhyConvert = external constant <{ [8 x i8], ptr }>
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erestoreGen(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_11a19fcb84a16e6d_1ab7f06eb0f74619 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e8d82fb02ccf62bc_44b724ba703ff148 = external constant [0 x i8]
@olang_loc_36e0ec838c111677_372a612bd7b0a623 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_5609b5c4ef82b256_83c053ae3d548522 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleTail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloadCaptures(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/eval:Ptr" %a3, i64 %a4)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_b477747d616f01f0_6d4a3c12dca1cf4c = external constant [0 x i8]
@olang_loc_1a5820d8caa3da70_8ddb412d29c69c24 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c073bf56b8103e8_f70ded813690f4 = external constant [0 x i8]
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2feval_2erCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %v0, i64 %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1)
@G_2ecompiler_2feval_2eWhyWritesGlobalVar = external constant <{ [8 x i8], ptr }>
@olang_loc_cdcdbab6c5a00ca5_1566754bdc1f9529 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/mir:Range" %a3)
@olang_loc_d7d71e32b1402da8_19cce939fe39e26c = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenWalk(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i1 %a3, ptr %a4c, ptr %a4e)
@G_2ecompiler_2feval_2erGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_a8aea866c7f3b59a_8137d523407c73ee = external constant [0 x i8]
@olang_loc_20cdf2bac11b5657_20b8fcdfbd19fb1b = external constant [0 x i8]
@olang_loc_3dd741f2ac40c2b6_e435d9fa661ce11a = external constant [0 x i8]
@olang_loc_57883a0fca4ce879_b5ee1d89385345fd = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2epairDots(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, %"compiler/eval:Ptr" %a3, i64 %a4, i64 %a5, i64 %a6)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@G_2ecompiler_2feval_2evAgg = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2esRegion = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edisown(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@olang_loc_3ad4fb4c50638c0b_118ff119db9b3957 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare { i64, i64 } @compiler_2feval_2ewideMin(i64 %a0)
declare { i64, i64 } @compiler_2feval_2eneg128(i64 %a0, i64 %a1)
declare { i64, i64 } @compiler_2feval_2emul128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, i64 } @compiler_2feval_2ewideMax(i64 %a0, i1 %a1)
declare { i64, i64 } @compiler_2feval_2eadd128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare i64 @compiler_2feval_2ecmp128(i64 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4)
declare { i64, i64 } @compiler_2feval_2esub128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawBits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawType(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopyBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, %"compiler/eval:Ptr" %a3, i64 %a4, i64 %a5)
declare %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyNoGlobal = external constant <{ [8 x i8], ptr }>
@olang_loc_de6102181a77a536_5fca55a0d6277082 = external constant [0 x i8]
declare { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2eWhyNull = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyPayload = external constant <{ [8 x i8], ptr }>
@olang_loc_c157b2e02f5238d7_241c429033d52203 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elaneDot(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i32 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ebitOp(i32 %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_c5a1577ee3e22d75_549c323efc9636a1 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i64 %a4)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5, i64 %a6)
@G_2ecompiler_2feval_2eWhyDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyRunDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyEqDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyRunEqDepth = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_3aframe_2ector(ptr %out, ptr %v0)
@G_2ecompiler_2feval_2esStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d3c8ecceb8a6d93b_6543c983ba03c11f = external constant [0 x i8]
@olang_loc_d67750d3ea89b5a6_4cf132db9678b04a = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eanchorRegion(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseRegion(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %a0, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7289625dc306da68_1bb592dfdbe27504 = external constant [0 x i8]
@olang_loc_d526727003b18a55_2e4fcca09321f611 = external constant [0 x i8]
@olang_loc_1269d295d9d04536_be9a6b7fb42413f2 = external constant [0 x i8]
@olang_loc_d5c4bb6f444265cb_1686743ce9a847e7 = external constant [0 x i8]
@olang_loc_72e3b80bf5d68934_41b0c6a64027e678 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@G_2ecompiler_2feval_2eInterpCrash = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
@olang_loc_a18e8c5cba1eb19a_a9626f5dd72b6766 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evVoid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evWide = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@olang_loc_5b67d157b70117f_cddce93e80c09b93 = external constant [0 x i8]
@G_2ecompiler_2feval_2efastStride = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eassign(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2, { i64, [15 x i64] } %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
@G_2ecompiler_2feval_2eslotBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esInert = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esBuilder = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esJoin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@olang_loc_fe5b662c8cf4b58_7006b7c636f2421c = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2feval_2eWhyDestructor = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/eval:Ptr" %a4)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eheldScope(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrite(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2, i32 %a3, { i64, [4 x i64] } %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eLen_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eSetAt_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereclaim(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4, %"compiler/mir:Range" %a5)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aPtr_3e_2eTruncate_3ccompiler_2feval_3aPtr_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyOutside = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2espawn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
@olang_loc_7f284a3be8281e29_2098fbd9ac092a4d = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
@olang_loc_77ec49cd2ef2b53_f798fa63e9acfcff = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %a0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereturned(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_69287ebff671eb2d_9fd35f0201a42c21 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@G_2ecompiler_2feval_2eWhyEnds = external constant <{ [8 x i8], ptr }>
@olang_loc_86c25f3ef178583f_f0c157887637479b = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare void @compiler_2feval_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2feval_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eB0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 %a0)
declare void @compiler_2feval_2etprim(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i32 %a4, { i64, [4 x i64] } %a5, { i64, [4 x i64] } %a6)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
@G_2ecompiler_2feval_2eS0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2feval_3acfn_2ector(ptr %out, ptr %v0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eholderCheck(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
