; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/scan:scanner" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
define dso_local { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i8
  %l21 = alloca i8
  %l22 = alloca { i64, i64 }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l64 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l81 = alloca i64
  %l93 = alloca { i64, ptr }
  %l107 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i64
  %l138 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l163 = alloca i1
  %l176 = alloca { i64, ptr }
  %l182 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l193 = alloca i64
  %l194 = alloca i64
  %l195 = alloca { i64, ptr }
  %l199 = alloca i64
  %l207 = alloca { i64, i64 }
  %l210 = alloca { i64, i64 }
  %l211 = alloca i32
  %l221 = alloca ptr
  %l224 = alloca i8
  %l227 = alloca i8
  %l230 = alloca i8
  %l233 = alloca i8
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca i64
  %l243 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = icmp sge i64 %t5, 6
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l30, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 34
  store i1 %t15, ptr %l29, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l29, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t18, ptr %l34, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 1
  %t22 = load i8, ptr %t21, !tbaa !32
  %t24 = icmp eq i8 %t22, 34
  store i1 %t24, ptr %l33, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l33, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l38, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 2
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = icmp eq i8 %t31, 34
  store i1 %t33, ptr %l37, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l41, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = sub i64 %t39, 3
  store i64 %t41, ptr %l44, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l45, !tbaa !24
  %t44 = icmp sge i64 3, 0
  br i1 %t44, label %bb13, label %bb14
bb12:
  br label %bb69
bb13:
  %t46 = load i64, ptr %l44, !tbaa !24
  %t47 = icmp sle i64 3, %t46
  br i1 %t47, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e0eb014d323e7d9_3ee0f0ba74559745)
  unreachable
bb15:
  %t49 = load i64, ptr %l44, !tbaa !24
  %t50 = load i64, ptr %l45, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e0eb014d323e7d9_3ee0f0ba74559745)
  unreachable
bb17:
  %t53 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l44, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 3
  %t57 = sub i64 %t55, 3
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l2, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t61, i8 10)
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l54
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb20, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l53
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e0eb014d323e7d9_3ee0f0ba74559745)
  unreachable
bb19:
  %t69 = load i64, ptr %l53, !tbaa !24
  store i64 %t69, ptr %l50, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb22
bb22:
  %t70 = load i64, ptr %l50, !tbaa !24
  store i64 %t70, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l64, !tbaa !27
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i8, ptr %t93, i64 %t90
  %t95 = load i8, ptr %t94, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l1, i8 %t95)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb25
bb31:
  %t107 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %s0, ptr %s2, ptr %l1)
  store { i64, ptr } %t107, ptr %l74
  br label %bb32
bb32:
  %t108 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t108, ptr %l75, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l76, !tbaa !24
  %t111 = load i64, ptr %l76, !tbaa !24
  %t112 = mul i64 %t111, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l77, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l76, !tbaa !24
  %t121 = mul i64 %t120, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t117, ptr %t119, i64 %t121, i1 false)
  %t122 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t122, ptr %l75, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t123 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t123, ptr %rv
  br label %ret
bb33:
  %t124 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t130 = call i64 @compiler_2fscan_2elastLineStart(ptr %v0, { i64, ptr } %t124, i64 %t127)
  store i64 %t130, ptr %l81
  br label %bb34
bb34:
  %t131 = load i64, ptr %l81, !tbaa !24
  store i64 %t131, ptr %l8, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = sub i64 %t134, %t135
  store i64 %t138, ptr %l9, !tbaa !24
  %t140 = load i64, ptr %l3, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l10, !tbaa !24
  store i1 true, ptr %l11, !tbaa !21
  br label %bb35
bb35:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb36, label %bb37
bb36:
  br label %bb67
bb37:
  br label %bb38
bb38:
  %t152 = load i64, ptr %l10, !tbaa !24
  store i64 %t152, ptr %l12, !tbaa !24
  br label %bb39
bb39:
  %t154 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t154, ptr %l93, !tbaa !27
  %t155 = load i64, ptr %l12, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t155
  %t160 = load i8, ptr %t159, !tbaa !32
  %t162 = icmp ne i8 %t160, 10
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l12, !tbaa !24
  br label %bb43
bb43:
  br label %bb39
bb44:
  %t171 = load i1, ptr %l11, !tbaa !21
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb45, label %bb46
bb45:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l1, i8 10)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  store i1 false, ptr %l11, !tbaa !21
  %t176 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t177 = load i64, ptr %l10, !tbaa !24
  %t178 = load i64, ptr %l12, !tbaa !24
  %t182 = call i1 @compiler_2fscan_2eblankLine(ptr %v0, { i64, ptr } %t176, i64 %t177, i64 %t178)
  store i1 %t182, ptr %l107
  br label %bb49
bb49:
  %t183 = load i1, ptr %l107, !tbaa !21
  %t184 = xor i1 %t183, true
  br i1 %t184, label %bb50, label %bb51
bb50:
  %t186 = load i64, ptr %l10, !tbaa !24
  %t187 = load i64, ptr %l9, !tbaa !24
  %t190 = add i64 %t186, %t187
  store i64 %t190, ptr %l13, !tbaa !24
  %t192 = load i64, ptr %l12, !tbaa !24
  store i64 %t192, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb52, label %bb53
bb51:
  br label %bb65
bb52:
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb57
bb54:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l13, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l15, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l119, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb56
bb56:
  %t220 = load i64, ptr %l119, !tbaa !24
  store i64 %t220, ptr %l116, !tbaa !24
  br label %bb57
bb57:
  %t221 = load i64, ptr %l116, !tbaa !24
  store i64 %t221, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb58
bb58:
  %t222 = load i64, ptr %l17, !tbaa !24
  %t223 = load i64, ptr %l16, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l17, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  %t240 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t240, ptr %l138, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i8, ptr %t244, i64 %t238
  %t246 = load i8, ptr %t245, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l1, i8 %t246)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = add i64 %t250, 1
  store i64 %t253, ptr %l17, !tbaa !24
  br label %bb58
bb64:
  br label %bb65
bb65:
  %t255 = load i64, ptr %l12, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l10, !tbaa !24
  br label %bb66
bb66:
  br label %bb35
bb67:
  %t260 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %s0, ptr %s1, ptr %l1)
  store { i64, ptr } %t260, ptr %l148
  br label %bb68
bb68:
  %t261 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t261, ptr %l149, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l150, !tbaa !24
  %t264 = load i64, ptr %l150, !tbaa !24
  %t265 = mul i64 %t264, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l151, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l150, !tbaa !24
  %t274 = mul i64 %t273, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t275, ptr %l149, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t276 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t276, ptr %rv
  br label %ret
bb69:
  store i64 1, ptr %l19, !tbaa !24
  br label %bb70
bb70:
  %t277 = load i64, ptr %l19, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t282 = sub i64 %t280, 1
  %t285 = icmp slt i64 %t277, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb71, label %bb72
bb71:
  br label %bb115
bb72:
  br label %bb73
bb73:
  %t289 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t289, ptr %l158, !tbaa !27
  %t290 = load i64, ptr %l19, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr i8, ptr %t293, i64 %t290
  %t295 = load i8, ptr %t294, !tbaa !32
  store i8 %t295, ptr %l20, !tbaa !22
  %t297 = load i8, ptr %l20, !tbaa !22
  %t299 = icmp ne i8 %t297, 92
  br i1 %t299, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb76
bb75:
  %t301 = load i64, ptr %l19, !tbaa !24
  %t303 = add i64 %t301, 1
  %t304 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t308 = sub i64 %t306, 1
  %t311 = icmp sge i64 %t303, %t308
  store i1 %t311, ptr %l163, !tbaa !21
  br label %bb76
bb76:
  %t313 = load i1, ptr %l163, !tbaa !21
  br i1 %t313, label %bb77, label %bb78
bb77:
  %t314 = load i8, ptr %l20, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l1, i8 %t314)
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t318 = load i64, ptr %l19, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l19, !tbaa !24
  br label %bb114
bb80:
  %t323 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t323, ptr %l176, !tbaa !27
  %t324 = load i64, ptr %l19, !tbaa !24
  %t326 = add i64 %t324, 1
  %t328 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i8, ptr %t329, i64 %t326
  %t331 = load i8, ptr %t330, !tbaa !32
  store i8 %t331, ptr %l21, !tbaa !22
  %t333 = load i8, ptr %l21, !tbaa !22
  %t335 = icmp eq i8 %t333, 120
  br i1 %t335, label %bb81, label %bb82
bb81:
  %t337 = load i64, ptr %l19, !tbaa !24
  %t339 = add i64 %t337, 3
  %t340 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t345 = icmp slt i64 %t339, %t342
  store i1 %t345, ptr %l182, !tbaa !21
  br label %bb83
bb82:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb83
bb83:
  %t347 = load i1, ptr %l182, !tbaa !21
  br i1 %t347, label %bb84, label %bb85
bb84:
  store ptr %l1, ptr %l188, !tbaa !29
  %t348 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t348, ptr %l189, !tbaa !27
  %t349 = load i64, ptr %l19, !tbaa !24
  %t351 = add i64 %t349, 2
  %t353 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i8, ptr %t354, i64 %t351
  %t356 = load i8, ptr %t355, !tbaa !32
  %t358 = call i64 @compiler_2fscan_2ehexDigit(i8 %t356)
  store i64 %t358, ptr %l193
  br label %bb86
bb85:
  %t359 = load i8, ptr %l21, !tbaa !22
  %t361 = icmp eq i8 %t359, 117
  br i1 %t361, label %bb89, label %bb90
bb86:
  %t363 = load i64, ptr %l193, !tbaa !24
  %t364 = mul i64 %t363, 16
  store i64 %t364, ptr %l194, !tbaa !24
  %t365 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t365, ptr %l195, !tbaa !27
  %t366 = load i64, ptr %l19, !tbaa !24
  %t368 = add i64 %t366, 3
  %t370 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i8, ptr %t371, i64 %t368
  %t373 = load i8, ptr %t372, !tbaa !32
  %t375 = call i64 @compiler_2fscan_2ehexDigit(i8 %t373)
  store i64 %t375, ptr %l199
  br label %bb87
bb87:
  %t376 = load i64, ptr %l194, !tbaa !24
  %t377 = load i64, ptr %l199, !tbaa !24
  %t378 = add i64 %t376, %t377
  %t380 = trunc i64 %t378 to i8
  %t381 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %t381, i8 %t380)
  br label %bb88
bb88:
  %t383 = load i64, ptr %l19, !tbaa !24
  %t386 = add i64 %t383, 4
  store i64 %t386, ptr %l19, !tbaa !24
  br label %bb113
bb89:
  %t388 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t389 = load i64, ptr %l19, !tbaa !24
  %t392 = call { i32, { i64, i64 } } @compiler_2fscan_2eunicodeEscape(ptr %v0, { i64, ptr } %t388, i64 %t389)
  %t393 = extractvalue { i32, { i64, i64 } } %t392, 1
  %t394 = extractvalue { i32, { i64, i64 } } %t392, 0
  store i32 %t394, ptr %l211
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb92, label %ok.396, !prof !99
ok.396:
  store { i64, i64 } %t393, ptr %l210
  br label %bb91
bb90:
  store ptr %l1, ptr %l221, !tbaa !29
  %t397 = load i8, ptr %l21, !tbaa !22
  %t399 = icmp eq i8 %t397, 110
  br i1 %t399, label %bb99, label %bb100
bb91:
  %t401 = load { i64, i64 }, ptr %l210
  store { i64, i64 } %t401, ptr %l207
  br label %bb94
bb92:
  br label %bb93
bb93:
  %t402 = load i64, ptr %l19, !tbaa !24
  %t404 = add i64 %t402, 2
  %t405 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t407 = insertvalue { i64, i64 } %t405, i64 %t404, 1
  store { i64, i64 } %t407, ptr %l207
  br label %bb94
bb94:
  %t408 = load { i64, i64 }, ptr %l207
  store { i64, i64 } %t408, ptr %l22
  %t409 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 0
  %t410 = load i64, ptr %t409, !tbaa !24
  store i64 %t410, ptr %l23, !tbaa !24
  %t412 = getelementptr { i64, i64 }, ptr %l22, i32 0, i32 1
  %t413 = load i64, ptr %t412, !tbaa !24
  store i64 %t413, ptr %l24, !tbaa !24
  %t415 = load i64, ptr %l23, !tbaa !24
  %t417 = icmp sge i64 %t415, 0
  br i1 %t417, label %bb95, label %bb96
bb95:
  %t419 = load i64, ptr %l23, !tbaa !24
  call void @compiler_2fscan_2epushUtf8(ptr %s0, ptr %l1, i64 %t419)
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  %t422 = load i64, ptr %l24, !tbaa !24
  store i64 %t422, ptr %l19, !tbaa !24
  br label %bb112
bb99:
  store i8 10, ptr %l224, !tbaa !22
  br label %bb110
bb100:
  %t424 = load i8, ptr %l21, !tbaa !22
  %t426 = icmp eq i8 %t424, 116
  br i1 %t426, label %bb101, label %bb102
bb101:
  store i8 9, ptr %l227, !tbaa !22
  br label %bb109
bb102:
  %t428 = load i8, ptr %l21, !tbaa !22
  %t430 = icmp eq i8 %t428, 114
  br i1 %t430, label %bb103, label %bb104
bb103:
  store i8 13, ptr %l230, !tbaa !22
  br label %bb108
bb104:
  %t432 = load i8, ptr %l21, !tbaa !22
  %t434 = icmp eq i8 %t432, 48
  br i1 %t434, label %bb105, label %bb106
bb105:
  store i8 0, ptr %l233, !tbaa !22
  br label %bb107
bb106:
  %t436 = load i8, ptr %l21, !tbaa !22
  store i8 %t436, ptr %l233, !tbaa !22
  br label %bb107
bb107:
  %t439 = load i8, ptr %l233, !tbaa !22
  store i8 %t439, ptr %l230, !tbaa !22
  br label %bb108
bb108:
  %t440 = load i8, ptr %l230, !tbaa !22
  store i8 %t440, ptr %l227, !tbaa !22
  br label %bb109
bb109:
  %t441 = load i8, ptr %l227, !tbaa !22
  store i8 %t441, ptr %l224, !tbaa !22
  br label %bb110
bb110:
  %t442 = load ptr, ptr %l221, !tbaa !29
  %t443 = load i8, ptr %l224, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %t442, i8 %t443)
  br label %bb111
bb111:
  %t444 = load i64, ptr %l19, !tbaa !24
  %t447 = add i64 %t444, 2
  store i64 %t447, ptr %l19, !tbaa !24
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  br label %bb70
bb115:
  %t450 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t450, ptr %l240
  br label %bb116
bb116:
  %t451 = load { i64, ptr }, ptr %l240, !tbaa !27
  store { i64, ptr } %t451, ptr %l241, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  store i64 %t453, ptr %l242, !tbaa !24
  %t454 = load i64, ptr %l242, !tbaa !24
  %t455 = mul i64 %t454, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t455)
  %t457 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  store { i64, ptr } %t458, ptr %l243, !tbaa !27
  %t459 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !27
  %t461 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !27
  %t463 = load i64, ptr %l242, !tbaa !24
  %t464 = mul i64 %t463, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t460, ptr %t462, i64 %t464, i1 false)
  %t465 = load { i64, ptr }, ptr %l243, !tbaa !27
  store { i64, ptr } %t465, ptr %l241, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t466 = load { i64, ptr }, ptr %l241, !tbaa !27
  store { i64, ptr } %t466, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fscan_2eblockComment(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = add i64 %t7, 1
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 35
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = add i64 %t28, 1
  %t32 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t37 = icmp eq i8 %t35, 35
  store i1 %t37, ptr %l16, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = add i64 %t40, 2
  store i64 %t42, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t44, 1
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  br label %bb1
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscan_2ecanStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca { i32, i64 }
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l44 = alloca { i32, i64 }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t2
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  %t11 = call i1 @compiler_2fscan_2eisWordChar(i8 %t9)
  store i1 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i8, ptr %l2, !tbaa !22
  %t15 = icmp eq i8 %t13, 32
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i8, ptr %l2, !tbaa !22
  %t20 = icmp eq i8 %t18, 9
  store i1 %t20, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t23 = load i8, ptr %l2, !tbaa !22
  %t25 = icmp eq i8 %t23, 10
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i8, ptr %l2, !tbaa !22
  %t30 = icmp eq i8 %t28, 35
  store i1 %t30, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t33 = load i8, ptr %l2, !tbaa !22
  %t35 = icmp eq i8 %t33, 34
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb19
bb18:
  %t38 = load i8, ptr %l2, !tbaa !22
  %t40 = icmp eq i8 %t38, 39
  store i1 %t40, ptr %l25, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t44 = load i8, ptr %l2, !tbaa !22
  %t46 = icmp eq i8 %t44, 33
  br i1 %t46, label %bb23, label %bb24
bb23:
  %t48 = load i64, ptr %l1, !tbaa !24
  %t50 = add i64 %t48, 1
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t56 = icmp slt i64 %t50, %t53
  br i1 %t56, label %bb25, label %bb26
bb24:
  br label %bb28
bb25:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 61
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb27
bb27:
  %t70 = load i1, ptr %l36, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb28:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %t71, i64 %t72)
  store { i32, i64 } %t75, ptr %l44
  br label %bb29
bb29:
  %t76 = load { i32, i64 }, ptr %l44
  store { i32, i64 } %t76, ptr %l3
  %t77 = getelementptr { i32, i64 }, ptr %l3, i32 0, i32 0
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 116}
  %t82 = trunc i64 0 to i32
  %t83 = icmp eq i32 %t78, %t82
  %t85 = xor i1 %t83, true
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i8
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 3
  %t2 = load i8, ptr %t1, !tbaa !22
  store i8 %t2, ptr %l1, !tbaa !22
  %t4 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t5 = load i32, ptr %t4, !range !{i32 0, i32 31}
  store i32 %t5, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t9 = trunc i64 0 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t12 = load i8, ptr %l1, !tbaa !22
  %t13 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t16 = add i64 %t14, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = getelementptr i8, ptr %t20, i64 %t14
  store i8 %t12, ptr %t21
  %t22 = getelementptr i8, ptr %t21, i64 1
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t20, 1
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  br label %bb125
bb4:
  %t26 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  br label %bb125
bb8:
  %t33 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t35 = trunc i64 2 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  br label %bb125
bb12:
  %t40 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t42 = trunc i64 3 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  br label %bb125
bb16:
  %t47 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t49 = trunc i64 4 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t52, ptr %l5, !tbaa !27
  br label %bb125
bb20:
  %t54 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t56 = trunc i64 5 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  br label %bb125
bb24:
  %t61 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t63 = trunc i64 6 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  br label %bb125
bb28:
  %t68 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t70 = trunc i64 7 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  br label %bb125
bb32:
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t77 = trunc i64 8 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t80, ptr %l5, !tbaa !27
  br label %bb125
bb36:
  %t82 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t84 = trunc i64 9 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  br label %bb125
bb40:
  %t89 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t91 = trunc i64 10 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t94, ptr %l5, !tbaa !27
  br label %bb125
bb44:
  %t96 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t98 = trunc i64 11 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb125
bb48:
  %t103 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t105 = trunc i64 12 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t108, ptr %l5, !tbaa !27
  br label %bb125
bb52:
  %t110 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t112 = trunc i64 13 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t115, ptr %l5, !tbaa !27
  br label %bb125
bb56:
  %t117 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t119 = trunc i64 14 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t122, ptr %l5, !tbaa !27
  br label %bb125
bb60:
  %t124 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t126 = trunc i64 15 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t129 = load i8, ptr %l1, !tbaa !22
  %t130 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t133 = add i64 %t131, 1
  %t134 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t130, i64 %t131)
  %t138 = getelementptr i8, ptr %t137, i64 %t131
  store i8 %t129, ptr %t138
  %t139 = getelementptr i8, ptr %t138, i64 1
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t137, 1
  store { i64, ptr } %t141, ptr %l5, !tbaa !27
  br label %bb125
bb64:
  %t143 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t145 = trunc i64 16 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l72, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t148, ptr %l5, !tbaa !27
  br label %bb125
bb68:
  %t150 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t152 = trunc i64 17 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t155, ptr %l5, !tbaa !27
  br label %bb125
bb72:
  %t157 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t159 = trunc i64 18 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t162, ptr %l5, !tbaa !27
  br label %bb125
bb76:
  %t164 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t166 = trunc i64 19 to i32
  %t167 = icmp eq i32 %t164, %t166
  br i1 %t167, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l84, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t169, ptr %l5, !tbaa !27
  br label %bb125
bb80:
  %t171 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t173 = trunc i64 20 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t176, ptr %l5, !tbaa !27
  br label %bb125
bb84:
  %t178 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t180 = trunc i64 21 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t183, ptr %l5, !tbaa !27
  br label %bb125
bb88:
  %t185 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t187 = trunc i64 22 to i32
  %t188 = icmp eq i32 %t185, %t187
  br i1 %t188, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  store { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l96, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t190, ptr %l5, !tbaa !27
  br label %bb125
bb92:
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t194 = trunc i64 23 to i32
  %t195 = icmp eq i32 %t192, %t194
  br i1 %t195, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  store { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t197, ptr %l5, !tbaa !27
  br label %bb125
bb96:
  %t199 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t201 = trunc i64 24 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t204, ptr %l5, !tbaa !27
  br label %bb125
bb100:
  %t206 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t208 = trunc i64 25 to i32
  %t209 = icmp eq i32 %t206, %t208
  br i1 %t209, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l108, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t211, ptr %l5, !tbaa !27
  br label %bb125
bb104:
  %t213 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t215 = trunc i64 26 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  %t218 = load i8, ptr %l1, !tbaa !22
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t222 = add i64 %t220, 1
  %t223 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t219, i64 %t220)
  %t227 = getelementptr i8, ptr %t226, i64 %t220
  store i8 %t218, ptr %t227
  %t228 = getelementptr i8, ptr %t227, i64 1
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t226, 1
  store { i64, ptr } %t230, ptr %l5, !tbaa !27
  br label %bb125
bb108:
  %t232 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t234 = trunc i64 27 to i32
  %t235 = icmp eq i32 %t232, %t234
  br i1 %t235, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t237 = load i8, ptr %l1, !tbaa !22
  %t238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t241 = add i64 %t239, 1
  %t242 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t238, i64 %t239)
  %t246 = getelementptr i8, ptr %t245, i64 %t239
  store i8 %t237, ptr %t246
  %t247 = getelementptr i8, ptr %t246, i64 1
  call void @olang_textcopy(ptr %t247, ptr %t242, i64 %t243)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t245, 1
  store { i64, ptr } %t249, ptr %l5, !tbaa !27
  br label %bb125
bb112:
  %t251 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t253 = trunc i64 28 to i32
  %t254 = icmp eq i32 %t251, %t253
  br i1 %t254, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l120, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t256, ptr %l5, !tbaa !27
  br label %bb125
bb116:
  %t258 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t260 = trunc i64 29 to i32
  %t261 = icmp eq i32 %t258, %t260
  br i1 %t261, label %bb117, label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  store { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t263, ptr %l5, !tbaa !27
  br label %bb125
bb120:
  %t265 = load i32, ptr %l2, !range !{i32 0, i32 31}
  %t267 = trunc i64 30 to i32
  %t268 = icmp eq i32 %t265, %t267
  br i1 %t268, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  store { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l128, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t270, ptr %l5, !tbaa !27
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_39af88013a73b478_a5c9d135875fcb24)
  unreachable
bb125:
  %t272 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l130, !tbaa !24
  %t274 = load i64, ptr %l130, !tbaa !24
  %t275 = mul i64 %t274, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l131, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l130, !tbaa !24
  %t284 = mul i64 %t283, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t280, ptr %t282, i64 %t284, i1 false)
  %t285 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t285, ptr %l5, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t286, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0) #0 {
entry:
  %l0 = alloca %"compiler/scan:Diag"
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/scan:Diag" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scan:Diag", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 31}
  store i32 %t2, ptr %l1
  %t4 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb4:
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  %t14 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t16 = trunc i64 2 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  %t19 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb12:
  %t24 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb16:
  %t29 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t31 = trunc i64 5 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb20:
  %t34 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t36 = trunc i64 6 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb24:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t41 = trunc i64 7 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb28:
  %t44 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t46 = trunc i64 8 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t51 = trunc i64 9 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb34:
  %t54 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t56 = trunc i64 10 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  %t59 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t61 = trunc i64 11 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  %t64 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t66 = trunc i64 12 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  %t69 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t71 = trunc i64 13 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb44:
  %t74 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t76 = trunc i64 15 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb45, label %bb46
bb45:
  br label %bb53
bb46:
  %t79 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t81 = trunc i64 16 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  %t84 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t86 = trunc i64 17 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  %t89 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t91 = trunc i64 18 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb54:
  %t94 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t96 = trunc i64 14 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb58:
  %t99 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t101 = trunc i64 19 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb62:
  %t104 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t106 = trunc i64 20 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb63, label %bb64
bb63:
  br label %bb71
bb64:
  %t109 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t111 = trunc i64 21 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  %t114 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t116 = trunc i64 22 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t119 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t121 = trunc i64 23 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb72:
  %t124 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t126 = trunc i64 24 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  %t129 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t131 = trunc i64 26 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb78:
  %t134 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t136 = trunc i64 25 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb79, label %bb80
bb79:
  br label %bb83
bb80:
  %t139 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t141 = trunc i64 27 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb84:
  %t144 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t146 = trunc i64 28 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb88:
  %t149 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t151 = trunc i64 29 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb89, label %bb90
bb89:
  br label %bb93
bb90:
  %t154 = load i32, ptr %l1, !range !{i32 0, i32 31}
  %t156 = trunc i64 30 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb94
bb93:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_3aab5bd1ecbcb485_f7a3519a1de9c361)
  unreachable
bb95:
  %t159 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eblockEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l7 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = add i64 %t5, 2
  %t10 = call i64 @compiler_2fscan_2eblockComment(ptr %v0, { i64, ptr } %t4, i64 %t7)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = add i64 %t20, 2
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t18, i32 7, i64 %t19, i64 %t22, i8 0)
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scan:scanner", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2echar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i64
  %l23 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca i64
  %l86 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = add i64 %t10, 1
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sge i64 %t14, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t20, i32 10, i64 %t21, i64 %t22, i8 0)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
bb4:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l5, !tbaa !22
  %t37 = load i8, ptr %l5, !tbaa !22
  %t39 = icmp eq i8 %t37, 10
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t41, i32 11, i64 %t42, i64 %t43, i8 0)
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t48 = load i64, ptr %l4, !tbaa !24
  store i64 %t48, ptr %rv
  br label %ret
bb8:
  %t50 = load i8, ptr %l5, !tbaa !22
  %t52 = icmp eq i8 %t50, 39
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t54, i32 12, i64 %t55, i64 %t58, i8 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %rv
  br label %ret
bb12:
  %t67 = load i8, ptr %l5, !tbaa !22
  %t69 = icmp eq i8 %t67, 92
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = icmp sge i64 %t73, %t74
  br i1 %t77, label %bb15, label %bb16
bb14:
  %t79 = load i8, ptr %l5, !tbaa !22
  %t81 = icmp uge i8 %t79, -128
  br i1 %t81, label %bb24, label %bb25
bb15:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t83, i32 10, i64 %t84, i64 %t85, i8 0)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t90 = load i64, ptr %l3, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
bb18:
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l53, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t95
  %t100 = load i8, ptr %t99, !tbaa !32
  %t104 = icmp eq i8 %t100, 10
  br i1 %t104, label %bb19, label %bb20
bb19:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = add i64 %t108, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t106, i32 11, i64 %t107, i64 %t110, i8 0)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t115 = load i64, ptr %l4, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %rv
  br label %ret
bb22:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i64, ptr %l4, !tbaa !24
  %t123 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eescape(ptr %v0, ptr %t119, i64 %t120, i8 39)
  store i64 %t123, ptr %l68
  br label %bb23
bb23:
  %t124 = load i64, ptr %l68, !tbaa !24
  store i64 %t124, ptr %l4, !tbaa !24
  br label %bb28
bb24:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l1, !tbaa !24
  %t127 = load i64, ptr %l4, !tbaa !24
  %t131 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ewideChar(ptr %v0, ptr %t125, i64 %t126, i64 %t127)
  store i64 %t131, ptr %l74
  br label %bb26
bb25:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l4, !tbaa !24
  br label %bb27
bb26:
  %t137 = load i64, ptr %l74, !tbaa !24
  store i64 %t137, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t138 = load i64, ptr %l4, !tbaa !24
  %t139 = load i64, ptr %l3, !tbaa !24
  %t142 = icmp sge i64 %t138, %t139
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i64, ptr %l1, !tbaa !24
  %t146 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t144, i32 10, i64 %t145, i64 %t146, i8 0)
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t151 = load i64, ptr %l3, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
bb32:
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t153, ptr %l86, !tbaa !27
  %t154 = load i64, ptr %l4, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t154
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = icmp eq i8 %t159, 39
  br i1 %t161, label %bb33, label %bb34
bb33:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t167, ptr %l92, !tbaa !27
  %t168 = load i64, ptr %l4, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i8, ptr %t171, i64 %t168
  %t173 = load i8, ptr %t172, !tbaa !32
  %t175 = icmp eq i8 %t173, 10
  br i1 %t175, label %bb36, label %bb37
bb36:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t179 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t177, i32 11, i64 %t178, i64 %t179, i8 0)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t184 = load i64, ptr %l4, !tbaa !24
  store i64 %t184, ptr %rv
  br label %ret
bb39:
  %t186 = load i64, ptr %l4, !tbaa !24
  store i64 %t186, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  %t188 = load i64, ptr %l7, !tbaa !24
  %t189 = load i64, ptr %l3, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  br i1 %t192, label %bb41, label %bb42
bb41:
  %t194 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t194, ptr %l106, !tbaa !27
  %t195 = load i64, ptr %l7, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr i8, ptr %t198, i64 %t195
  %t200 = load i8, ptr %t199, !tbaa !32
  %t202 = icmp ne i8 %t200, 39
  store i1 %t202, ptr %l105, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t204 = load i1, ptr %l105, !tbaa !21
  br i1 %t204, label %bb44, label %bb45
bb44:
  %t205 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t205, ptr %l111, !tbaa !27
  %t206 = load i64, ptr %l7, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i8, ptr %t209, i64 %t206
  %t211 = load i8, ptr %t210, !tbaa !32
  %t213 = icmp ne i8 %t211, 10
  store i1 %t213, ptr %l110, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb46
bb46:
  %t215 = load i1, ptr %l110, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t218 = load i64, ptr %l7, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l7, !tbaa !24
  br label %bb50
bb50:
  br label %bb40
bb51:
  %t223 = load i64, ptr %l7, !tbaa !24
  %t224 = load i64, ptr %l3, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  br i1 %t227, label %bb52, label %bb53
bb52:
  %t229 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t229, ptr %l123, !tbaa !27
  %t230 = load i64, ptr %l7, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i8, ptr %t233, i64 %t230
  %t235 = load i8, ptr %t234, !tbaa !32
  %t237 = icmp eq i8 %t235, 39
  store i1 %t237, ptr %l122, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb54
bb54:
  %t239 = load i1, ptr %l122, !tbaa !21
  br i1 %t239, label %bb55, label %bb56
bb55:
  %t240 = load i64, ptr %l7, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l127, !tbaa !24
  br label %bb57
bb56:
  %t244 = load i64, ptr %l7, !tbaa !24
  store i64 %t244, ptr %l127, !tbaa !24
  br label %bb57
bb57:
  %t246 = load i64, ptr %l127, !tbaa !24
  store i64 %t246, ptr %l8, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l1, !tbaa !24
  %t249 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t247, i32 13, i64 %t248, i64 %t249, i8 0)
  br label %bb58
bb58:
  %t254 = load i64, ptr %l8, !tbaa !24
  store i64 %t254, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ecloseBeforeDecl(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eLen_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scan:scanner", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  store i1 %t14, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t19 = trunc i64 33 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t24 = trunc i64 41 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t30 = trunc i64 40 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t36 = trunc i64 43 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l22, !tbaa !21
  store i1 %t39, ptr %l3, !tbaa !21
  %t40 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t42 = trunc i64 37 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scan:scanner", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  store i64 %a2, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb38
bb19:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t58 = icmp slt i64 %t52, %t55
  br i1 %t58, label %bb20, label %bb21
bb20:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t60, ptr %l35, !tbaa !27
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 32
  br i1 %t68, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb25
bb22:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb24
bb23:
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t70, ptr %l40, !tbaa !27
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t78 = icmp eq i8 %t76, 9
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l39, !tbaa !21
  store i1 %t80, ptr %l34, !tbaa !21
  br label %bb25
bb25:
  %t81 = load i1, ptr %l34, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l5, !tbaa !24
  br label %bb29
bb29:
  br label %bb19
bb30:
  %t89 = load i64, ptr %l5, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t95 = icmp slt i64 %t89, %t92
  br i1 %t95, label %bb31, label %bb32
bb31:
  %t97 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t97, ptr %l53, !tbaa !27
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = call i1 @compiler_2fscan_2eisLetter(i8 %t103)
  store i1 %t105, ptr %l56
  br label %bb33
bb32:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb37
bb33:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb36
bb35:
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l58, !tbaa !27
  %t108 = load i64, ptr %l5, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i8, ptr %t111, i64 %t108
  %t113 = load i8, ptr %t112, !tbaa !32
  %t115 = icmp eq i8 %t113, 95
  store i1 %t115, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t117 = load i1, ptr %l57, !tbaa !21
  store i1 %t117, ptr %l52, !tbaa !21
  br label %bb37
bb37:
  %t118 = load i1, ptr %l52, !tbaa !21
  store i1 %t118, ptr %l3, !tbaa !21
  br label %bb38
bb38:
  %t119 = load i1, ptr %l3, !tbaa !21
  br i1 %t119, label %bb39, label %bb40
bb39:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scan:scanner", ptr %t121, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eClear_Hee3cbaa7ef2d16f687a523c73aa64228(ptr %v0, ptr %t123)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i8
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca i1
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i8 0, ptr %l7, !tbaa !22
  br label %bb1
bb1:
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l19, !tbaa !27
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 %t21
  %t26 = load i8, ptr %t25, !tbaa !32
  store i8 %t26, ptr %l8, !tbaa !22
  %t28 = load i8, ptr %l8, !tbaa !22
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i1 @compiler_2fscan_2edigitOf(i8 %t28, i64 %t29)
  store i1 %t32, ptr %l24
  br label %bb5
bb5:
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l6, !tbaa !24
  br label %bb26
bb7:
  %t39 = load i8, ptr %l8, !tbaa !22
  %t41 = icmp eq i8 %t39, 95
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load i8, ptr %l7, !tbaa !22
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call i1 @compiler_2fscan_2edigitOf(i8 %t43, i64 %t44)
  store i1 %t47, ptr %l32
  br label %bb10
bb9:
  br label %bb28
bb10:
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = add i64 %t49, 1
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %l39, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t61
  %t66 = load i8, ptr %t65, !tbaa !32
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = call i1 @compiler_2fscan_2edigitOf(i8 %t66, i64 %t67)
  store i1 %t70, ptr %l44
  br label %bb16
bb15:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb17
bb16:
  %t71 = load i1, ptr %l44, !tbaa !21
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t72 = load i1, ptr %l38, !tbaa !21
  %t75 = xor i1 %t72, true
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t77 = load i8, ptr %l7, !tbaa !22
  %t79 = icmp ne i8 %t77, 95
  store i1 %t79, ptr %l47, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t81 = load i1, ptr %l47, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t84, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t82, i32 28, i64 %t83, i64 %t86, i8 0)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t91 = load i8, ptr %l8, !tbaa !22
  store i8 %t91, ptr %l7, !tbaa !22
  %t93 = load i64, ptr %l5, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l5, !tbaa !24
  br label %bb27
bb27:
  br label %bb1
bb28:
  %t98 = load i64, ptr %l5, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t101 = insertvalue { i64, i64 } undef, i64 %t98, 0
  %t103 = insertvalue { i64, i64 } %t101, i64 %t99, 1
  store { i64, i64 } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ejunk(ptr %v0, ptr %a0, i8 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i32
  %l29 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t1, 13
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scan:scanner", ptr %t5, i32 0, i32 5
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = add i64 %t14, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t12, i32 4, i64 %t13, i64 %t16, i8 0)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scan:scanner", ptr %t21, i32 0, i32 5
  store i1 true, ptr %t23, !tbaa !21
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = add i64 %t24, 1
  store i64 %t26, ptr %rv
  br label %ret
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scan:scanner", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = add i64 %t32, 1
  %t37 = call i64 @compiler_2fscan_2ejunkEnd(ptr %v0, { i64, ptr } %t31, i64 %t34)
  store i64 %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = load i64, ptr %l22, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t39 = load i8, ptr %l1, !tbaa !22
  %t41 = icmp eq i8 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb9:
  store i32 3, ptr %l25
  br label %bb14
bb10:
  %t44 = load i8, ptr %l1, !tbaa !22
  %t46 = icmp uge i8 %t44, -128
  br i1 %t46, label %bb11, label %bb12
bb11:
  store i32 1, ptr %l29
  br label %bb13
bb12:
  store i32 0, ptr %l29
  br label %bb13
bb13:
  %t50 = load i32, ptr %l29, !range !{i32 0, i32 31}
  store i32 %t50, ptr %l25
  br label %bb14
bb14:
  %t51 = load i32, ptr %l25, !range !{i32 0, i32 31}
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l2, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i8, ptr %l1, !tbaa !22
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t52, i32 %t51, i64 %t54, i64 %t55, i8 %t56)
  br label %bb15
bb15:
  %t62 = load i64, ptr %l3, !tbaa !24
  store i64 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2enumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca { i64, i64 }
  %l7 = alloca i64
  %l9 = alloca { i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, i64 }
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, i64 }
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l31 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, i64 }
  %l61 = alloca ptr
  %l63 = alloca i32
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca i32
  %l89 = alloca { i64, ptr }
  %l97 = alloca { i64, i64 }
  %l102 = alloca i1
  %l106 = alloca { i64, i64 }
  %l120 = alloca i1
  %l129 = alloca i1
  %l130 = alloca { i64, ptr }
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l149 = alloca i1
  %l150 = alloca { i64, ptr }
  %l159 = alloca i1
  %l162 = alloca { i64, i64 }
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l22, !tbaa !27
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i8, ptr %t14, i64 %t11
  %t16 = load i8, ptr %t15, !tbaa !32
  %t18 = icmp eq i8 %t16, 48
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = add i64 %t20, 1
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  store i1 %t26, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l31, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  store i8 %t37, ptr %l4, !tbaa !22
  %t39 = load i8, ptr %l4, !tbaa !22
  %t41 = icmp eq i8 %t39, 120
  br i1 %t41, label %bb6, label %bb7
bb5:
  br label %bb47
bb6:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb8
bb7:
  %t43 = load i8, ptr %l4, !tbaa !22
  %t45 = icmp eq i8 %t43, 88
  store i1 %t45, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t47 = load i1, ptr %l37, !tbaa !21
  br i1 %t47, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb11
bb10:
  %t48 = load i8, ptr %l4, !tbaa !22
  %t50 = icmp eq i8 %t48, 98
  store i1 %t50, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l40, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t53 = load i8, ptr %l4, !tbaa !22
  %t55 = icmp eq i8 %t53, 66
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l43, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load i8, ptr %l4, !tbaa !22
  %t60 = icmp eq i8 %t58, 120
  br i1 %t60, label %bb17, label %bb18
bb16:
  br label %bb46
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i8, ptr %l4, !tbaa !22
  %t64 = icmp eq i8 %t62, 88
  store i1 %t64, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t66 = load i1, ptr %l48, !tbaa !21
  store i1 %t66, ptr %l5, !tbaa !21
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l51, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t70 = add i64 %t68, 2
  store i64 %t70, ptr %l53, !tbaa !24
  %t71 = load i1, ptr %l5, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i64 16, ptr %l55, !tbaa !24
  br label %bb22
bb21:
  store i64 2, ptr %l55, !tbaa !24
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l51, !tbaa !29
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = load i64, ptr %l55, !tbaa !24
  %t76 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store { i64, i64 } %t76, ptr %l56
  br label %bb23
bb23:
  %t77 = load { i64, i64 }, ptr %l56
  store { i64, i64 } %t77, ptr %l6
  %t78 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t81 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t86 = icmp eq i64 %t82, 0
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load i1, ptr %l5, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  store i32 24, ptr %l63
  br label %bb28
bb27:
  store i32 25, ptr %l63
  br label %bb28
bb28:
  %t93 = load i64, ptr %l1, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = load i32, ptr %l63, !range !{i32 0, i32 31}
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t95, i32 %t96, i64 %t93, i64 %t94, i8 0)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  br i1 %t103, label %bb31, label %bb32
bb31:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l72, !tbaa !27
  %t106 = load i64, ptr %l7, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 %t106
  %t111 = load i8, ptr %t110, !tbaa !32
  %t113 = call i1 @compiler_2fscan_2eisDigit(i8 %t111)
  store i1 %t113, ptr %l75
  br label %bb33
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb38
bb33:
  %t114 = load i1, ptr %l75, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb37
bb35:
  %t115 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t115, ptr %l77, !tbaa !27
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t116
  %t121 = load i8, ptr %t120, !tbaa !32
  %t123 = call i1 @compiler_2fscan_2eisLetter(i8 %t121)
  store i1 %t123, ptr %l80
  br label %bb36
bb36:
  %t124 = load i1, ptr %l80, !tbaa !21
  store i1 %t124, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t125 = load i1, ptr %l76, !tbaa !21
  store i1 %t125, ptr %l71, !tbaa !21
  br label %bb38
bb38:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l81, !tbaa !29
  %t128 = load i1, ptr %l5, !tbaa !21
  br i1 %t128, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  store i32 26, ptr %l83
  br label %bb43
bb42:
  store i32 27, ptr %l83
  br label %bb43
bb43:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = add i64 %t133, 1
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l89, !tbaa !27
  %t137 = load i64, ptr %l7, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t137
  %t142 = load i8, ptr %t141, !tbaa !32
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load i32, ptr %l83, !range !{i32 0, i32 31}
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t143, i32 %t144, i64 %t132, i64 %t135, i8 %t142)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t148 = load i64, ptr %l7, !tbaa !24
  %t150 = insertvalue { i32, i64 } undef, i32 2, 0
  %t152 = insertvalue { i32, i64 } %t150, i64 %t148, 1
  store { i32, i64 } %t152, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  %t158 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t154, i64 %t155, i64 10)
  store { i64, i64 } %t158, ptr %l97
  br label %bb48
bb48:
  %t159 = load { i64, i64 }, ptr %l97
  store { i64, i64 } %t159, ptr %l9
  %t160 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 0
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l10, !tbaa !24
  store i32 2, ptr %l11
  %t164 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t165 = load i64, ptr %l10, !tbaa !24
  %t168 = call i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %t164, i64 %t165)
  store i1 %t168, ptr %l102
  br label %bb49
bb49:
  %t169 = load i1, ptr %l102, !tbaa !21
  br i1 %t169, label %bb50, label %bb51
bb50:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i64, ptr %l10, !tbaa !24
  %t173 = add i64 %t171, 1
  %t176 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t170, i64 %t173, i64 10)
  store { i64, i64 } %t176, ptr %l106
  br label %bb52
bb51:
  br label %bb62
bb52:
  %t177 = load { i64, i64 }, ptr %l106
  store { i64, i64 } %t177, ptr %l12
  %t178 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %l13, !tbaa !24
  %t181 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  %t186 = icmp eq i64 %t182, 0
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i64, ptr %l10, !tbaa !24
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t188, i32 29, i64 %t189, i64 %t192, i8 0)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t197 = load i64, ptr %l13, !tbaa !24
  store i64 %t197, ptr %l10, !tbaa !24
  store i32 3, ptr %l11
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = call i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %t200, i64 %t201)
  store i1 %t204, ptr %l120
  br label %bb57
bb57:
  %t205 = load i1, ptr %l120, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l10, !tbaa !24
  %t210 = add i64 %t208, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t206, i32 30, i64 %t207, i64 %t210, i8 0)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t215 = load i64, ptr %l10, !tbaa !24
  %t216 = load i64, ptr %l3, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t221, ptr %l130, !tbaa !27
  %t222 = load i64, ptr %l10, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i8, ptr %t225, i64 %t222
  %t227 = load i8, ptr %t226, !tbaa !32
  %t229 = icmp eq i8 %t227, 101
  br i1 %t229, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb65:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb67
bb66:
  %t231 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t231, ptr %l135, !tbaa !27
  %t232 = load i64, ptr %l10, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i8, ptr %t235, i64 %t232
  %t237 = load i8, ptr %t236, !tbaa !32
  %t239 = icmp eq i8 %t237, 69
  store i1 %t239, ptr %l134, !tbaa !21
  br label %bb67
bb67:
  %t241 = load i1, ptr %l134, !tbaa !21
  store i1 %t241, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t242 = load i1, ptr %l129, !tbaa !21
  br i1 %t242, label %bb69, label %bb70
bb69:
  %t243 = load i64, ptr %l10, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l15, !tbaa !24
  %t247 = load i64, ptr %l15, !tbaa !24
  %t248 = load i64, ptr %l3, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  br i1 %t251, label %bb71, label %bb72
bb70:
  br label %bb85
bb71:
  %t253 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t253, ptr %l145, !tbaa !27
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i8, ptr %t257, i64 %t254
  %t259 = load i8, ptr %t258, !tbaa !32
  %t261 = icmp eq i8 %t259, 43
  br i1 %t261, label %bb73, label %bb74
bb72:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb76
bb73:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb75
bb74:
  %t263 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t263, ptr %l150, !tbaa !27
  %t264 = load i64, ptr %l15, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i8, ptr %t267, i64 %t264
  %t269 = load i8, ptr %t268, !tbaa !32
  %t271 = icmp eq i8 %t269, 45
  store i1 %t271, ptr %l149, !tbaa !21
  br label %bb75
bb75:
  %t273 = load i1, ptr %l149, !tbaa !21
  store i1 %t273, ptr %l144, !tbaa !21
  br label %bb76
bb76:
  %t274 = load i1, ptr %l144, !tbaa !21
  br i1 %t274, label %bb77, label %bb78
bb77:
  %t275 = load i64, ptr %l15, !tbaa !24
  %t278 = add i64 %t275, 1
  store i64 %t278, ptr %l15, !tbaa !24
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t280 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t281 = load i64, ptr %l15, !tbaa !24
  %t284 = call i1 @compiler_2fscan_2eexponentDigits(ptr %v0, { i64, ptr } %t280, i64 %t281)
  store i1 %t284, ptr %l159
  br label %bb80
bb80:
  %t285 = load i1, ptr %l159, !tbaa !21
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i64, ptr %l15, !tbaa !24
  %t290 = call { i64, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2edigits(ptr %v0, ptr %t286, i64 %t287, i64 10)
  store { i64, i64 } %t290, ptr %l162
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t291 = load { i64, i64 }, ptr %l162
  store { i64, i64 } %t291, ptr %l16
  %t292 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t293 = load i64, ptr %t292, !tbaa !24
  %t297 = insertvalue { i32, i64 } undef, i32 3, 0
  %t299 = insertvalue { i32, i64 } %t297, i64 %t293, 1
  store { i32, i64 } %t299, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t301 = load i32, ptr %l11, !range !{i32 0, i32 116}
  %t302 = load i64, ptr %l10, !tbaa !24
  %t304 = insertvalue { i32, i64 } undef, i32 %t301, 0
  %t306 = insertvalue { i32, i64 } %t304, i64 %t302, 1
  store { i32, i64 } %t306, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eraw(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l94 = alloca { i64, ptr }
  %l101 = alloca i1
  %l109 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i64
  %l136 = alloca { i64, ptr }
  %l140 = alloca i1
  %l141 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l171 = alloca i1
  %l173 = alloca i1
  %l179 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = add i64 %t10, 3
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = add i64 %t14, 2
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l33, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i8, ptr %t26, i64 %t23
  %t28 = load i8, ptr %t27, !tbaa !32
  %t30 = icmp eq i8 %t28, 34
  br i1 %t30, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb10
bb4:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l38, !tbaa !27
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t33, 1
  %t37 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = icmp eq i8 %t40, 34
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l37, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l44, !tbaa !27
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 2
  %t50 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i8, ptr %t51, i64 %t48
  %t53 = load i8, ptr %t52, !tbaa !32
  %t55 = icmp eq i8 %t53, 34
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t57 = load i1, ptr %l43, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l32, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb14
bb14:
  br label %bb1
bb15:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = add i64 %t68, 2
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = icmp sge i64 %t70, %t71
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l1, !tbaa !24
  %t80 = add i64 %t78, 3
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t76, i32 20, i64 %t77, i64 %t80, i8 0)
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t85 = load i64, ptr %l3, !tbaa !24
  store i64 %t85, ptr %rv
  br label %ret
bb19:
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = add i64 %t87, 3
  store i64 %t89, ptr %l5, !tbaa !24
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = add i64 %t91, 3
  store i64 %t93, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  store i64 %t95, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l4, !tbaa !24
  store i64 %t97, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb20, label %bb21
bb20:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb25
bb22:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l76, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb24
bb24:
  %t125 = load i64, ptr %l76, !tbaa !24
  store i64 %t125, ptr %l73, !tbaa !24
  br label %bb25
bb25:
  %t126 = load i64, ptr %l73, !tbaa !24
  store i64 %t126, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb27, label %bb28
bb27:
  br label %bb80
bb28:
  br label %bb29
bb29:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l12, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t145, ptr %l94, !tbaa !27
  %t146 = load i64, ptr %l12, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i8, ptr %t149, i64 %t146
  %t151 = load i8, ptr %t150, !tbaa !32
  %t153 = icmp ne i8 %t151, 10
  br i1 %t153, label %bb30, label %bb31
bb30:
  br label %bb79
bb31:
  br label %bb32
bb32:
  %t155 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t156 = load i64, ptr %l6, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t161 = call i1 @compiler_2fscan_2eblankLine(ptr %v0, { i64, ptr } %t155, i64 %t156, i64 %t157)
  store i1 %t161, ptr %l101
  br label %bb33
bb33:
  %t162 = load i1, ptr %l101, !tbaa !21
  %t163 = xor i1 %t162, true
  br i1 %t163, label %bb34, label %bb35
bb34:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l6, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t165, i32 21, i64 %t166, i64 %t167, i8 0)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t172 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t173 = load i64, ptr %l4, !tbaa !24
  %t176 = call i64 @compiler_2fscan_2elastLineStart(ptr %v0, { i64, ptr } %t172, i64 %t173)
  store i64 %t176, ptr %l109
  br label %bb38
bb38:
  %t177 = load i64, ptr %l109, !tbaa !24
  store i64 %t177, ptr %l13, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  store i64 %t178, ptr %l14, !tbaa !24
  %t180 = load i64, ptr %l4, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t183 = load i64, ptr %l14, !tbaa !24
  %t186 = icmp sgt i64 %t182, %t183
  br i1 %t186, label %bb39, label %bb40
bb39:
  %t188 = load i64, ptr %l16, !tbaa !24
  %t190 = icmp sgt i64 %t188, 0
  br i1 %t190, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb44
bb41:
  %t192 = load i64, ptr %l15, !tbaa !24
  %t193 = load i64, ptr %l14, !tbaa !24
  %t196 = sub i64 %t192, %t193
  %t197 = load i64, ptr %l16, !tbaa !24
  %t200 = add i64 %t196, %t197
  %t202 = sub i64 %t200, 1
  %t203 = load i64, ptr %l16, !tbaa !24
  %t206 = sdiv i64 %t202, %t203
  store i64 %t206, ptr %l118, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb43
bb43:
  %t208 = load i64, ptr %l118, !tbaa !24
  store i64 %t208, ptr %l115, !tbaa !24
  br label %bb44
bb44:
  %t209 = load i64, ptr %l115, !tbaa !24
  store i64 %t209, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l17, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb46, label %bb47
bb46:
  br label %bb57
bb47:
  br label %bb48
bb48:
  %t218 = load i64, ptr %l14, !tbaa !24
  %t219 = load i64, ptr %l18, !tbaa !24
  %t220 = load i64, ptr %l16, !tbaa !24
  %t223 = mul i64 %t219, %t220
  %t226 = add i64 %t218, %t223
  store i64 %t226, ptr %l19, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t228, ptr %l136, !tbaa !27
  %t229 = load i64, ptr %l19, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i8, ptr %t232, i64 %t229
  %t234 = load i8, ptr %t233, !tbaa !32
  %t236 = icmp ne i8 %t234, 32
  br i1 %t236, label %bb49, label %bb50
bb49:
  %t238 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t238, ptr %l141, !tbaa !27
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i8, ptr %t242, i64 %t239
  %t244 = load i8, ptr %t243, !tbaa !32
  %t246 = icmp ne i8 %t244, 9
  store i1 %t246, ptr %l140, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb51
bb51:
  %t248 = load i1, ptr %l140, !tbaa !21
  br i1 %t248, label %bb52, label %bb53
bb52:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i64, ptr %l4, !tbaa !24
  %t251 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t249, i32 22, i64 %t250, i64 %t251, i8 0)
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t256 = load i64, ptr %l5, !tbaa !24
  store i64 %t256, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = add i64 %t258, 1
  store i64 %t261, ptr %l18, !tbaa !24
  br label %bb45
bb57:
  %t263 = load i64, ptr %l12, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l20, !tbaa !24
  br label %bb58
bb58:
  %t267 = load i64, ptr %l20, !tbaa !24
  %t268 = load i64, ptr %l13, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb59, label %bb60
bb59:
  br label %bb78
bb60:
  br label %bb61
bb61:
  %t275 = load i64, ptr %l20, !tbaa !24
  store i64 %t275, ptr %l21, !tbaa !24
  br label %bb62
bb62:
  %t277 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t277, ptr %l160, !tbaa !27
  %t278 = load i64, ptr %l21, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr i8, ptr %t281, i64 %t278
  %t283 = load i8, ptr %t282, !tbaa !32
  %t285 = icmp ne i8 %t283, 10
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = add i64 %t289, 1
  store i64 %t292, ptr %l21, !tbaa !24
  br label %bb66
bb66:
  br label %bb62
bb67:
  %t294 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t295 = load i64, ptr %l20, !tbaa !24
  %t296 = load i64, ptr %l21, !tbaa !24
  %t300 = call i1 @compiler_2fscan_2eblankLine(ptr %v0, { i64, ptr } %t294, i64 %t295, i64 %t296)
  store i1 %t300, ptr %l171
  br label %bb68
bb68:
  %t301 = load i1, ptr %l171, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb69, label %bb70
bb69:
  %t304 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t305 = load i64, ptr %l20, !tbaa !24
  %t306 = load i64, ptr %l21, !tbaa !24
  %t307 = load i64, ptr %l13, !tbaa !24
  %t308 = load i64, ptr %l4, !tbaa !24
  %t314 = call i1 @compiler_2fscan_2ehasPrefix(ptr %v0, { i64, ptr } %t304, i64 %t305, i64 %t306, i64 %t307, i64 %t308)
  store i1 %t314, ptr %l179
  br label %bb71
bb70:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb72
bb71:
  %t315 = load i1, ptr %l179, !tbaa !21
  %t316 = xor i1 %t315, true
  store i1 %t316, ptr %l173, !tbaa !21
  br label %bb72
bb72:
  %t318 = load i1, ptr %l173, !tbaa !21
  br i1 %t318, label %bb73, label %bb74
bb73:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i64, ptr %l20, !tbaa !24
  %t321 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t319, i32 23, i64 %t320, i64 %t321, i8 0)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  %t326 = load i64, ptr %l21, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l20, !tbaa !24
  br label %bb77
bb77:
  br label %bb58
bb78:
  %t330 = load i64, ptr %l5, !tbaa !24
  store i64 %t330, ptr %rv
  br label %ret
bb79:
  %t332 = load i64, ptr %l11, !tbaa !24
  %t335 = add i64 %t332, 1
  store i64 %t335, ptr %l11, !tbaa !24
  br label %bb26
bb80:
  %t337 = load i64, ptr %l5, !tbaa !24
  store i64 %t337, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i8
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca { i32, i64 }
  %l15 = alloca { i32, i64 }
  %l16 = alloca i64
  %l17 = alloca i8
  %l18 = alloca i1
  %l28 = alloca { i64, ptr }
  %l33 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l59 = alloca i64
  %l71 = alloca i64
  %l76 = alloca i1
  %l85 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca i1
  %l99 = alloca i64
  %l102 = alloca i32
  %l109 = alloca i32
  %l111 = alloca i1
  %l114 = alloca { i32, i64 }
  %l122 = alloca i64
  %l131 = alloca i64
  %l134 = alloca { i32, i64 }
  %l139 = alloca i1
  %l145 = alloca i64
  %l157 = alloca i1
  %l160 = alloca i64
  %l164 = alloca ptr
  %l170 = alloca %"compiler/token:Token"
  %l186 = alloca i1
  %l187 = alloca { i64, ptr }
  %l198 = alloca i1
  %l205 = alloca i1
  %l214 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l222 = alloca ptr
  %l228 = alloca %"compiler/token:Token"
  %l230 = alloca ptr
  %l237 = alloca %"compiler/token:Token"
  %l251 = alloca i1
  %l253 = alloca ptr
  %l259 = alloca %"compiler/token:Token"
  %l261 = alloca ptr
  %l268 = alloca %"compiler/token:Token"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  store i32 0, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb39
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l28, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l7, !tbaa !22
  %t27 = load i8, ptr %l7, !tbaa !22
  %t29 = icmp eq i8 %t27, 32
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i8, ptr %l7, !tbaa !22
  %t33 = icmp eq i8 %t31, 9
  store i1 %t33, ptr %l33, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l33, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb37
bb10:
  %t41 = load i8, ptr %l7, !tbaa !22
  %t43 = icmp eq i8 %t41, 10
  br i1 %t43, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l4, !tbaa !21
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t45, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb36
bb12:
  %t50 = load i8, ptr %l7, !tbaa !22
  %t52 = icmp eq i8 %t50, 35
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = icmp sge i64 %t56, %t57
  br i1 %t60, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb18
bb15:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb17
bb16:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t62, ptr %l52, !tbaa !27
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  %t67 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = icmp ne i8 %t70, 35
  store i1 %t72, ptr %l51, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l51, !tbaa !21
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t75 = load i1, ptr %l46, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t80 = call i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %t76, i64 %t77)
  store i64 %t80, ptr %l59
  br label %bb21
bb20:
  %t81 = load i8, ptr %l7, !tbaa !22
  %t83 = icmp eq i8 %t81, 35
  br i1 %t83, label %bb26, label %bb27
bb21:
  %t85 = load i64, ptr %l59, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eutf8(ptr %v0, ptr %t86, i64 %t87, i64 %t88)
  br label %bb22
bb22:
  %t92 = load i64, ptr %l8, !tbaa !24
  store i64 %t92, ptr %l3, !tbaa !24
  %t94 = load i64, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l2, !tbaa !24
  %t98 = icmp eq i64 %t94, %t95
  br i1 %t98, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb35
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eblockEnd(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l71
  br label %bb28
bb27:
  br label %bb39
bb28:
  %t105 = load i64, ptr %l71, !tbaa !24
  store i64 %t105, ptr %l9, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 2
  %t110 = load i64, ptr %l9, !tbaa !24
  %t114 = call i1 @compiler_2fscan_2ehasLineEnd(ptr %v0, { i64, ptr } %t106, i64 %t109, i64 %t110)
  store i1 %t114, ptr %l76
  br label %bb29
bb29:
  %t115 = load i1, ptr %l76, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l3, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eutf8(ptr %v0, ptr %t116, i64 %t117, i64 %t118)
  br label %bb33
bb33:
  %t122 = load i64, ptr %l9, !tbaa !24
  store i64 %t122, ptr %l3, !tbaa !24
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb2
bb39:
  %t124 = load i64, ptr %l3, !tbaa !24
  %t125 = load i64, ptr %l2, !tbaa !24
  %t128 = icmp sge i64 %t124, %t125
  br i1 %t128, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s1)
  br label %bb132
bb41:
  br label %bb42
bb42:
  %t130 = load i64, ptr %l3, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t132, ptr %l85, !tbaa !27
  %t133 = load i64, ptr %l3, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i8, ptr %t136, i64 %t133
  %t138 = load i8, ptr %t137, !tbaa !32
  store i8 %t138, ptr %l11, !tbaa !22
  store i32 0, ptr %l12
  %t141 = load i64, ptr %l3, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l13, !tbaa !24
  %t145 = load i8, ptr %l11, !tbaa !22
  %t147 = call i1 @compiler_2fscan_2eisLetter(i8 %t145)
  store i1 %t147, ptr %l92
  br label %bb43
bb43:
  %t148 = load i1, ptr %l92, !tbaa !21
  br i1 %t148, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb46
bb45:
  %t149 = load i8, ptr %l11, !tbaa !22
  %t151 = icmp eq i8 %t149, 95
  store i1 %t151, ptr %l93, !tbaa !21
  br label %bb46
bb46:
  %t153 = load i1, ptr %l93, !tbaa !21
  br i1 %t153, label %bb47, label %bb48
bb47:
  %t154 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t155 = load i64, ptr %l3, !tbaa !24
  %t157 = add i64 %t155, 1
  %t160 = call i64 @compiler_2fscan_2ewordEnd(ptr %v0, { i64, ptr } %t154, i64 %t157)
  store i64 %t160, ptr %l99
  br label %bb49
bb48:
  %t161 = load i8, ptr %l11, !tbaa !22
  %t163 = call i1 @compiler_2fscan_2eisDigit(i8 %t161)
  store i1 %t163, ptr %l111
  br label %bb54
bb49:
  %t164 = load i64, ptr %l99, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t167 = trunc i64 76 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb50, label %bb51
bb50:
  store i32 1, ptr %l102
  br label %bb53
bb51:
  %t171 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t172 = load i64, ptr %l3, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l3, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t181 = call i32 @compiler_2ftoken_2eTok_2eKeyword(ptr %v0, { i64, ptr } %t171, i64 %t172, i64 %t177)
  store i32 %t181, ptr %l109
  br label %bb52
bb52:
  %t182 = load i32, ptr %l109, !range !{i32 0, i32 116}
  store i32 %t182, ptr %l102
  br label %bb53
bb53:
  %t183 = load i32, ptr %l102, !range !{i32 0, i32 116}
  store i32 %t183, ptr %l12
  br label %bb89
bb54:
  %t184 = load i1, ptr %l111, !tbaa !21
  br i1 %t184, label %bb55, label %bb56
bb55:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l3, !tbaa !24
  %t189 = call { i32, i64 } @compiler_2fscan_2ecompiler_2fscan_3ascanner_2enumber(ptr %v0, ptr %t185, i64 %t186)
  store { i32, i64 } %t189, ptr %l114
  br label %bb57
bb56:
  %t190 = load i8, ptr %l11, !tbaa !22
  %t192 = icmp eq i8 %t190, 34
  br i1 %t192, label %bb58, label %bb59
bb57:
  %t194 = load { i32, i64 }, ptr %l114
  store { i32, i64 } %t194, ptr %l14
  %t195 = getelementptr { i32, i64 }, ptr %l14, i32 0, i32 0
  %t196 = load i32, ptr %t195, !range !{i32 0, i32 116}
  store i32 %t196, ptr %l12
  %t198 = getelementptr { i32, i64 }, ptr %l14, i32 0, i32 1
  %t199 = load i64, ptr %t198, !tbaa !24
  store i64 %t199, ptr %l13, !tbaa !24
  br label %bb88
bb58:
  store i32 5, ptr %l12
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l3, !tbaa !24
  %t206 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2estr(ptr %v0, ptr %t202, i64 %t203)
  store i64 %t206, ptr %l122
  br label %bb60
bb59:
  %t207 = load i8, ptr %l11, !tbaa !22
  %t209 = icmp eq i8 %t207, 39
  br i1 %t209, label %bb62, label %bb63
bb60:
  %t211 = load i64, ptr %l122, !tbaa !24
  store i64 %t211, ptr %l13, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l3, !tbaa !24
  %t214 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eutf8(ptr %v0, ptr %t212, i64 %t213, i64 %t214)
  br label %bb61
bb61:
  br label %bb87
bb62:
  store i32 4, ptr %l12
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i64, ptr %l3, !tbaa !24
  %t223 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2echar(ptr %v0, ptr %t219, i64 %t220)
  store i64 %t223, ptr %l131
  br label %bb64
bb63:
  %t224 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t225 = load i64, ptr %l3, !tbaa !24
  %t228 = call { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %t224, i64 %t225)
  store { i32, i64 } %t228, ptr %l134
  br label %bb65
bb64:
  %t229 = load i64, ptr %l131, !tbaa !24
  store i64 %t229, ptr %l13, !tbaa !24
  br label %bb86
bb65:
  %t230 = load { i32, i64 }, ptr %l134
  store { i32, i64 } %t230, ptr %l15
  %t231 = getelementptr { i32, i64 }, ptr %l15, i32 0, i32 0
  %t232 = load i32, ptr %t231, !range !{i32 0, i32 116}
  store i32 %t232, ptr %l12
  %t234 = getelementptr { i32, i64 }, ptr %l15, i32 0, i32 1
  %t235 = load i64, ptr %t234, !tbaa !24
  store i64 %t235, ptr %l13, !tbaa !24
  %t237 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t239 = trunc i64 0 to i32
  %t240 = icmp eq i32 %t237, %t239
  br i1 %t240, label %bb66, label %bb67
bb66:
  %t242 = load i8, ptr %l11, !tbaa !22
  %t244 = icmp ne i8 %t242, 59
  store i1 %t244, ptr %l139, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb68
bb68:
  %t246 = load i1, ptr %l139, !tbaa !21
  br i1 %t246, label %bb69, label %bb70
bb69:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i8, ptr %l11, !tbaa !22
  %t249 = load i64, ptr %l3, !tbaa !24
  %t253 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ejunk(ptr %v0, ptr %t247, i8 %t248, i64 %t249)
  store i64 %t253, ptr %l145
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t254 = load i64, ptr %l145, !tbaa !24
  store i64 %t254, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb131
bb72:
  %t255 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t257 = trunc i64 0 to i32
  %t258 = icmp eq i32 %t255, %t257
  br i1 %t258, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s23
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i64, ptr %l3, !tbaa !24
  %t262 = load i64, ptr %l3, !tbaa !24
  %t264 = add i64 %t262, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t260, i32 5, i64 %t261, i64 %t264, i8 0)
  br label %bb75
bb74:
  br label %bb85
bb75:
  %t269 = load i64, ptr %l3, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l3, !tbaa !24
  %t274 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t276 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t274)
  store i1 %t276, ptr %l157
  br label %bb76
bb76:
  %t277 = load i1, ptr %l157, !tbaa !21
  %t278 = xor i1 %t277, true
  br i1 %t278, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s1)
  br label %bb131
bb78:
  br label %bb79
bb79:
  %t280 = load i1, ptr %l4, !tbaa !21
  br i1 %t280, label %bb80, label %bb81
bb80:
  %t282 = load i64, ptr %l6, !tbaa !24
  store i64 %t282, ptr %l160, !tbaa !24
  br label %bb82
bb81:
  %t284 = load i64, ptr %l10, !tbaa !24
  store i64 %t284, ptr %l160, !tbaa !24
  br label %bb82
bb82:
  %t286 = load i64, ptr %l160, !tbaa !24
  store i64 %t286, ptr %l16, !tbaa !24
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/scan:scanner", ptr %t287, i32 0, i32 1
  store ptr %t289, ptr %l164, !tbaa !29
  %t290 = load i64, ptr %l16, !tbaa !24
  %t292 = trunc i64 %t290 to i32
  %t293 = load i64, ptr %l16, !tbaa !24
  %t295 = trunc i64 %t293 to i32
  %t299 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s23, i32 8, i8 0, i32 %t292, i32 %t295)
  store %"compiler/token:Token" %t299, ptr %l170
  br label %bb83
bb83:
  %t300 = load ptr, ptr %l164, !tbaa !29
  %t301 = load %"compiler/token:Token", ptr %l170
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t300, %"compiler/token:Token" %t301)
  br label %bb84
bb84:
  store i32 8, ptr %l5
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s1)
  br label %bb131
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  store i8 0, ptr %l17, !tbaa !22
  %t303 = load i1, ptr %l4, !tbaa !21
  br i1 %t303, label %bb90, label %bb91
bb90:
  %t305 = load i8, ptr %l17, !tbaa !22
  %t307 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t310 = or i8 %t305, %t307
  store i8 %t310, ptr %l17, !tbaa !22
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t312 = load i64, ptr %l10, !tbaa !24
  %t313 = load i64, ptr %l6, !tbaa !24
  %t316 = icmp sgt i64 %t312, %t313
  br i1 %t316, label %bb93, label %bb94
bb93:
  %t318 = load i8, ptr %l17, !tbaa !22
  %t320 = load i8, ptr @G_2ecompiler_2ftoken_2eSpace, !tbaa !22
  %t323 = or i8 %t318, %t320
  store i8 %t323, ptr %l17, !tbaa !22
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t325 = load i64, ptr %l10, !tbaa !24
  %t327 = icmp eq i64 %t325, 0
  br i1 %t327, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb98
bb97:
  %t329 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t329, ptr %l187, !tbaa !27
  %t330 = load i64, ptr %l10, !tbaa !24
  %t332 = sub i64 %t330, 1
  %t334 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i8, ptr %t335, i64 %t332
  %t337 = load i8, ptr %t336, !tbaa !32
  %t339 = icmp eq i8 %t337, 10
  store i1 %t339, ptr %l186, !tbaa !21
  br label %bb98
bb98:
  %t341 = load i1, ptr %l186, !tbaa !21
  store i1 %t341, ptr %l18, !tbaa !21
  %t342 = load i1, ptr %l18, !tbaa !21
  br i1 %t342, label %bb99, label %bb100
bb99:
  %t344 = load i8, ptr %l17, !tbaa !22
  %t346 = load i8, ptr @G_2ecompiler_2ftoken_2eLineStart, !tbaa !22
  %t349 = or i8 %t344, %t346
  store i8 %t349, ptr %l17, !tbaa !22
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t351 = load i1, ptr %l18, !tbaa !21
  br i1 %t351, label %bb102, label %bb103
bb102:
  %t353 = load i64, ptr %l10, !tbaa !24
  %t355 = icmp sgt i64 %t353, 0
  store i1 %t355, ptr %l198, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb104
bb104:
  %t357 = load i1, ptr %l198, !tbaa !21
  br i1 %t357, label %bb105, label %bb106
bb105:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t360 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ecloseBeforeDecl(ptr %v0, ptr %t358, i32 %t359, i64 %t360)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  %t364 = load i1, ptr %l4, !tbaa !21
  br i1 %t364, label %bb109, label %bb110
bb109:
  %t366 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t368 = trunc i64 75 to i32
  %t369 = icmp eq i32 %t366, %t368
  store i1 %t369, ptr %l205, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb111
bb111:
  %t371 = load i1, ptr %l205, !tbaa !21
  br i1 %t371, label %bb112, label %bb113
bb112:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i64, ptr %l6, !tbaa !24
  %t375 = sub i64 %t373, 1
  %t376 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t372, i32 6, i64 %t375, i64 %t376, i8 0)
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb115
bb115:
  %t381 = load i1, ptr %l4, !tbaa !21
  br i1 %t381, label %bb116, label %bb117
bb116:
  %t383 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t385 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t383)
  store i1 %t385, ptr %l216
  br label %bb118
bb117:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb119
bb118:
  %t386 = load i1, ptr %l216, !tbaa !21
  store i1 %t386, ptr %l214, !tbaa !21
  br label %bb119
bb119:
  %t387 = load i1, ptr %l214, !tbaa !21
  br i1 %t387, label %bb120, label %bb121
bb120:
  %t388 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t390 = trunc i64 12 to i32
  %t391 = icmp eq i32 %t388, %t390
  %t393 = xor i1 %t391, true
  store i1 %t393, ptr %l217, !tbaa !21
  br label %bb122
bb121:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb122
bb122:
  %t395 = load i1, ptr %l217, !tbaa !21
  br i1 %t395, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s30
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/scan:scanner", ptr %t396, i32 0, i32 1
  store ptr %t398, ptr %l222, !tbaa !29
  %t399 = load i64, ptr %l6, !tbaa !24
  %t401 = trunc i64 %t399 to i32
  %t402 = load i64, ptr %l6, !tbaa !24
  %t404 = trunc i64 %t402 to i32
  %t408 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s30, i32 8, i8 0, i32 %t401, i32 %t404)
  store %"compiler/token:Token" %t408, ptr %l228
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t409 = load ptr, ptr %l222, !tbaa !29
  %t410 = load %"compiler/token:Token", ptr %l228
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t409, %"compiler/token:Token" %t410)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s30)
  br label %bb127
bb127:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/scan:scanner", ptr %t411, i32 0, i32 1
  store ptr %t413, ptr %l230, !tbaa !29
  %t414 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t415 = load i8, ptr %l17, !tbaa !22
  %t416 = load i64, ptr %l10, !tbaa !24
  %t418 = trunc i64 %t416 to i32
  %t419 = load i64, ptr %l13, !tbaa !24
  %t421 = trunc i64 %t419 to i32
  %t426 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s1, i32 %t414, i8 %t415, i32 %t418, i32 %t421)
  store %"compiler/token:Token" %t426, ptr %l237
  br label %bb128
bb128:
  %t427 = load ptr, ptr %l230, !tbaa !29
  %t428 = load %"compiler/token:Token", ptr %l237
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t427, %"compiler/token:Token" %t428)
  br label %bb129
bb129:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l12, !range !{i32 0, i32 116}
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2etrack(ptr %v0, ptr %t429, i32 %t430)
  br label %bb130
bb130:
  %t433 = load i32, ptr %l12, !range !{i32 0, i32 116}
  store i32 %t433, ptr %l5
  %t435 = load i64, ptr %l13, !tbaa !24
  store i64 %t435, ptr %l6, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t437 = load i64, ptr %l13, !tbaa !24
  store i64 %t437, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb131
bb131:
  br label %bb1
bb132:
  %t439 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t441 = trunc i64 75 to i32
  %t442 = icmp eq i32 %t439, %t441
  br i1 %t442, label %bb133, label %bb134
bb133:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i64, ptr %l6, !tbaa !24
  %t447 = sub i64 %t445, 1
  %t448 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t444, i32 6, i64 %t447, i64 %t448, i8 0)
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t453 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t455 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %t453)
  store i1 %t455, ptr %l251
  br label %bb137
bb137:
  %t456 = load i1, ptr %l251, !tbaa !21
  br i1 %t456, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s32
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/scan:scanner", ptr %t457, i32 0, i32 1
  store ptr %t459, ptr %l253, !tbaa !29
  %t460 = load i64, ptr %l6, !tbaa !24
  %t462 = trunc i64 %t460 to i32
  %t463 = load i64, ptr %l6, !tbaa !24
  %t465 = trunc i64 %t463 to i32
  %t469 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s32, i32 8, i8 0, i32 %t462, i32 %t465)
  store %"compiler/token:Token" %t469, ptr %l259
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t470 = load ptr, ptr %l253, !tbaa !29
  %t471 = load %"compiler/token:Token", ptr %l259
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t470, %"compiler/token:Token" %t471)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s32)
  br label %bb142
bb142:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/scan:scanner", ptr %t472, i32 0, i32 1
  store ptr %t474, ptr %l261, !tbaa !29
  %t475 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t476 = load i64, ptr %l2, !tbaa !24
  %t478 = trunc i64 %t476 to i32
  %t479 = load i64, ptr %l2, !tbaa !24
  %t481 = trunc i64 %t479 to i32
  %t486 = call %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %s0, i32 0, i8 %t475, i32 %t478, i32 %t481)
  store %"compiler/token:Token" %t486, ptr %l268
  br label %bb143
bb143:
  %t487 = load ptr, ptr %l261, !tbaa !29
  %t488 = load %"compiler/token:Token", ptr %l268
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %t487, %"compiler/token:Token" %t488)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2estr(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l29 = alloca i64
  %l40 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l80 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = add i64 %t10, 2
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 %t21
  %t26 = load i8, ptr %t25, !tbaa !32
  %t28 = icmp eq i8 %t26, 34
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 2
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t34
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = icmp eq i8 %t39, 34
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eraw(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t48, ptr %l29
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = icmp sge i64 %t54, %t55
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t60, i32 8, i64 %t61, i64 %t62, i8 0)
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
bb15:
  %t69 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t69, ptr %l40, !tbaa !27
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t70
  %t75 = load i8, ptr %t74, !tbaa !32
  store i8 %t75, ptr %l5, !tbaa !22
  %t77 = load i8, ptr %l5, !tbaa !22
  %t79 = icmp eq i8 %t77, 34
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t85 = load i8, ptr %l5, !tbaa !22
  %t87 = icmp eq i8 %t85, 10
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  %t91 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t89, i32 9, i64 %t90, i64 %t91, i8 0)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t96 = load i64, ptr %l4, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
bb22:
  %t98 = load i8, ptr %l5, !tbaa !22
  %t100 = icmp eq i8 %t98, 92
  br i1 %t100, label %bb23, label %bb24
bb23:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t104 = add i64 %t102, 1
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = icmp sge i64 %t104, %t105
  br i1 %t108, label %bb25, label %bb26
bb24:
  %t110 = load i64, ptr %l4, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l4, !tbaa !24
  br label %bb34
bb25:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t115, i32 8, i64 %t116, i64 %t117, i8 0)
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t122 = load i64, ptr %l3, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
bb28:
  %t124 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  %t129 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  %t136 = icmp eq i8 %t132, 10
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l1, !tbaa !24
  %t140 = load i64, ptr %l4, !tbaa !24
  %t142 = add i64 %t140, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t138, i32 9, i64 %t139, i64 %t142, i8 0)
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t147 = load i64, ptr %l4, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %rv
  br label %ret
bb32:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l4, !tbaa !24
  %t155 = call i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eescape(ptr %v0, ptr %t151, i64 %t152, i8 34)
  store i64 %t155, ptr %l80
  br label %bb33
bb33:
  %t156 = load i64, ptr %l80, !tbaa !24
  store i64 %t156, ptr %l4, !tbaa !24
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb11
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2etrack(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i8
  %l17 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca i8
  %l33 = alloca i1
  %l38 = alloca i8
  %l49 = alloca i64
  %l52 = alloca i8
  %l55 = alloca i8
  %l56 = alloca i32
  %l59 = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t3 = trunc i64 110 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scan:scanner", ptr %t6, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t8, i8 40)
  br label %bb4
bb4:
  br label %bb56
bb5:
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t12 = trunc i64 112 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scan:scanner", ptr %t15, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t17, i8 91)
  br label %bb9
bb9:
  br label %bb56
bb10:
  %t19 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t21 = trunc i64 114 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scan:scanner", ptr %t24, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t26, i8 123)
  br label %bb14
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"compiler/scan:scanner", ptr %t29, i32 0, i32 4
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = add i64 %t31, 1
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = getelementptr %"compiler/scan:scanner", ptr %t36, i32 0, i32 4
  store i64 %t34, ptr %t37, !tbaa !24
  br label %bb56
bb15:
  %t38 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t40 = trunc i64 111 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t43 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t45 = trunc i64 113 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb33
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scan:scanner", ptr %t48, i32 0, i32 3
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eLen_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l27
  br label %bb21
bb21:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l2, !tbaa !24
  %t54 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t56 = trunc i64 111 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb22, label %bb23
bb22:
  store i8 40, ptr %l30, !tbaa !22
  br label %bb24
bb23:
  store i8 91, ptr %l30, !tbaa !22
  br label %bb24
bb24:
  %t59 = load i8, ptr %l30, !tbaa !22
  store i8 %t59, ptr %l3, !tbaa !22
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scan:scanner", ptr %t64, i32 0, i32 3
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = sub i64 %t67, 1
  %t72 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eAt_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t66, i64 %t69)
  store i8 %t72, ptr %l38
  br label %bb27
bb26:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb28
bb27:
  %t73 = load i8, ptr %l3, !tbaa !22
  %t74 = load i8, ptr %l38, !tbaa !22
  %t76 = icmp eq i8 %t74, %t73
  store i1 %t76, ptr %l33, !tbaa !21
  br label %bb28
bb28:
  %t78 = load i1, ptr %l33, !tbaa !21
  br i1 %t78, label %bb29, label %bb30
bb29:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scan:scanner", ptr %t79, i32 0, i32 3
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = sub i64 %t82, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eTrunc_Hdb40e008e45c3217ff19be25d205c76e(ptr %v0, ptr %t81, i64 %t84)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb56
bb33:
  %t87 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t89 = trunc i64 115 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb51
bb36:
  br label %bb37
bb37:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/scan:scanner", ptr %t92, i32 0, i32 3
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eLen_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l49
  br label %bb38
bb38:
  %t97 = load i64, ptr %l49, !tbaa !24
  %t98 = icmp sgt i64 %t97, 0
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb39, label %bb40
bb39:
  br label %bb50
bb40:
  br label %bb41
bb41:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/scan:scanner", ptr %t102, i32 0, i32 3
  %t106 = call { i32, i8 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePop_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %t104)
  %t107 = extractvalue { i32, i8 } %t106, 1
  %t108 = extractvalue { i32, i8 } %t106, 0
  store i32 %t108, ptr %l56
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb43, label %ok.110, !prof !99
ok.110:
  store i8 %t107, ptr %l55
  br label %bb42
bb42:
  %t111 = load i8, ptr %l55, !tbaa !22
  store i8 %t111, ptr %l52, !tbaa !22
  br label %bb45
bb43:
  br label %bb44
bb44:
  br label %bb50
bb45:
  %t112 = load i8, ptr %l52, !tbaa !22
  %t115 = icmp eq i8 %t112, 123
  br i1 %t115, label %bb46, label %bb47
bb46:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l59, !tbaa !29
  %t118 = load ptr, ptr %l59, !tbaa !29
  %t119 = getelementptr %"compiler/scan:scanner", ptr %t118, i32 0, i32 4
  %t120 = load i64, ptr %t119, !tbaa !24
  %t123 = sub i64 %t120, 1
  %t125 = load ptr, ptr %l59, !tbaa !29
  %t126 = getelementptr %"compiler/scan:scanner", ptr %t125, i32 0, i32 4
  store i64 %t123, ptr %t126, !tbaa !24
  br label %bb50
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb37
bb50:
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_639a87f47d38eeab_7a46798b70a2d59f)
  unreachable
bb56:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eutf8(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l13 = alloca { i64, ptr }
  %l23 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 %a1, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t8, %t9
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  %t24 = icmp ult i8 %t22, -128
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t37 = call i64 @compiler_2fscan_2eutf8Width(ptr %v0, { i64, ptr } %t31, i64 %t32, i64 %t33)
  store i64 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t43, i32 2, i64 %t44, i64 %t47, i8 0)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %ret
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t52, %t54
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ewideChar(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l67 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scan:scanner", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %t6, i64 %t7)
  store i64 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i64, ptr %l11, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t18 = call i64 @compiler_2fscan_2eutf8Width(ptr %v0, { i64, ptr } %t12, i64 %t13, i64 %t14)
  store i64 %t18, ptr %l15
  br label %bb2
bb2:
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = add i64 %t24, %t25
  store i64 %t28, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t39, i32 2, i64 %t40, i64 %t41, i8 0)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 %t53
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp eq i8 %t58, 39
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t69, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t67, i32 14, i64 %t68, i64 %t71, i8 0)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t86, ptr %l51, !tbaa !27
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i8, ptr %t90, i64 %t87
  %t92 = load i8, ptr %t91, !tbaa !32
  %t94 = icmp ne i8 %t92, 39
  store i1 %t94, ptr %l50, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l50, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t99, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb27
bb27:
  br label %bb20
bb28:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = icmp sge i64 %t104, %t105
  br i1 %t108, label %bb29, label %bb30
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l62, !tbaa !29
  %t111 = load i64, ptr %l4, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp eq i64 %t111, %t114
  br i1 %t117, label %bb31, label %bb32
bb30:
  br label %bb35
bb31:
  store i32 10, ptr %l67
  br label %bb33
bb32:
  store i32 11, ptr %l67
  br label %bb33
bb33:
  %t121 = load i64, ptr %l1, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load ptr, ptr %l62, !tbaa !29
  %t124 = load i32, ptr %l67, !range !{i32 0, i32 31}
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t123, i32 %t124, i64 %t121, i64 %t122, i8 0)
  br label %bb34
bb34:
  %t127 = load i64, ptr %l6, !tbaa !24
  store i64 %t127, ptr %rv
  br label %ret
bb35:
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb36, label %bb37
bb36:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  call void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %t133, i32 13, i64 %t134, i64 %t137, i8 0)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscan_2edigitOf(i8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i64
  %l5 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @compiler_2fscan_2eisHexDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 2
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load i8, ptr %l0, !tbaa !22
  %t15 = icmp eq i8 %t13, 48
  br i1 %t15, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb8:
  %t17 = load i8, ptr %l0, !tbaa !22
  %t19 = icmp eq i8 %t17, 49
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l10, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb10:
  %t22 = load i8, ptr %l0, !tbaa !22
  %t24 = call i1 @compiler_2fscan_2eisDigit(i8 %t22)
  store i1 %t24, ptr %l14
  br label %bb11
bb11:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eexponentDigits(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @compiler_2fscan_2eisDigit(i8 %t19)
  store i1 %t21, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, 95
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l15, !tbaa !21
  store i1 %t33, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l10, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t38
  %t43 = load i8, ptr %t42, !tbaa !32
  %t45 = call i1 @compiler_2fscan_2eisDigit(i8 %t43)
  store i1 %t45, ptr %l24
  br label %bb12
bb12:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2efractionAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp sge i64 %t1, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 46
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l6, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t29 = icmp slt i64 %t23, %t26
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 %t34
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = call i1 @compiler_2fscan_2eisLetter(i8 %t39)
  store i1 %t41, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb13
bb9:
  %t42 = load i1, ptr %l22, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t43, ptr %l24, !tbaa !27
  %t44 = load i64, ptr %l1, !tbaa !24
  %t46 = add i64 %t44, 1
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t46
  %t51 = load i8, ptr %t50, !tbaa !32
  %t53 = icmp eq i8 %t51, 95
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l23, !tbaa !21
  store i1 %t55, ptr %l17, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l17, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2ehasLineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l39 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 %a2, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t35, 2147483648
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  %t41 = and i1 %t36, %t38
  store i1 %t41, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store { i64, ptr } %a0, ptr %l39, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t58
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 10
  br i1 %t68, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l7, !tbaa !24
  br label %bb7
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2ehasPrefix(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %a2, %t2
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t10 = sub i64 %t6, %t7
  %t13 = icmp slt i64 %t5, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = sub i64 %t16, %t17
  store i64 %t20, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load i64, ptr %l7, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb9
bb6:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l28, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l25, !tbaa !24
  store i64 %t49, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = sub i64 %t50, 1
  store i64 %t51, ptr %l37, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t52, 2147483648
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  %t58 = and i1 %t53, %t55
  store i1 %t58, ptr %l40, !tbaa !21
  br label %bb10
bb10:
  %t59 = load i64, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l10, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l50, !tbaa !27
  %t78 = load i64, ptr %l1, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 %t82
  %t87 = load i8, ptr %t86, !tbaa !32
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t88, ptr %l55, !tbaa !27
  %t89 = load i64, ptr %l3, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t95 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 %t93
  %t98 = load i8, ptr %t97, !tbaa !32
  %t101 = icmp ne i8 %t87, %t98
  br i1 %t101, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb10
bb18:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscan_2eisHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @compiler_2fscan_2eisDigit(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb7
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp uge i8 %t5, 97
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load i8, ptr %l0, !tbaa !22
  %t11 = icmp ule i8 %t9, 102
  store i1 %t11, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t13 = load i1, ptr %l6, !tbaa !21
  store i1 %t13, ptr %l3, !tbaa !21
  br label %bb7
bb7:
  %t14 = load i1, ptr %l3, !tbaa !21
  br i1 %t14, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb9:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp uge i8 %t15, 65
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load i8, ptr %l0, !tbaa !22
  %t21 = icmp ule i8 %t19, 70
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t24 = load i1, ptr %l9, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscan_2ejunkEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp ne i8 %t19, 13
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i1 @compiler_2fscan_2ecanStart(ptr %v0, { i64, ptr } %t24, i64 %t25)
  store i1 %t28, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l15, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t35, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  br label %bb1
bb13:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fscan_2eoperator(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l7 = alloca { i64, ptr }
  %l14 = alloca i8
  %l15 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l197 = alloca i1
  %l198 = alloca { i64, ptr }
  %l229 = alloca i1
  %l230 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 %t6
  %t11 = load i8, ptr %t10, !tbaa !32
  store i8 %t11, ptr %l3, !tbaa !22
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = add i64 %t13, 1
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  store i8 %t29, ptr %l14, !tbaa !22
  br label %bb3
bb2:
  store i8 0, ptr %l14, !tbaa !22
  br label %bb3
bb3:
  %t31 = load i8, ptr %l14, !tbaa !22
  store i8 %t31, ptr %l4, !tbaa !22
  %t32 = load i8, ptr %l3, !tbaa !22
  %t34 = icmp eq i8 %t32, 43
  br i1 %t34, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t36 = load i8, ptr %l4, !tbaa !22
  %t38 = icmp eq i8 %t36, 43
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = add i64 %t40, 2
  %t44 = insertvalue { i32, i64 } undef, i32 93, 0
  %t46 = insertvalue { i32, i64 } %t44, i64 %t42, 1
  store { i32, i64 } %t46, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t48 = load i8, ptr %l4, !tbaa !22
  %t50 = icmp eq i8 %t48, 61
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load i64, ptr %l1, !tbaa !24
  %t54 = add i64 %t52, 2
  %t56 = insertvalue { i32, i64 } undef, i32 82, 0
  %t58 = insertvalue { i32, i64 } %t56, i64 %t54, 1
  store { i32, i64 } %t58, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = add i64 %t60, 1
  %t64 = insertvalue { i32, i64 } undef, i32 68, 0
  %t66 = insertvalue { i32, i64 } %t64, i64 %t62, 1
  store { i32, i64 } %t66, ptr %rv
  br label %ret
bb13:
  %t68 = load i8, ptr %l3, !tbaa !22
  %t70 = icmp eq i8 %t68, 45
  br i1 %t70, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t72 = load i8, ptr %l4, !tbaa !22
  %t74 = icmp eq i8 %t72, 45
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t76 = load i64, ptr %l1, !tbaa !24
  %t78 = add i64 %t76, 2
  %t80 = insertvalue { i32, i64 } undef, i32 94, 0
  %t82 = insertvalue { i32, i64 } %t80, i64 %t78, 1
  store { i32, i64 } %t82, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t84 = load i8, ptr %l4, !tbaa !22
  %t86 = icmp eq i8 %t84, 61
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t88 = load i64, ptr %l1, !tbaa !24
  %t90 = add i64 %t88, 2
  %t92 = insertvalue { i32, i64 } undef, i32 83, 0
  %t94 = insertvalue { i32, i64 } %t92, i64 %t90, 1
  store { i32, i64 } %t94, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = add i64 %t96, 1
  %t100 = insertvalue { i32, i64 } undef, i32 69, 0
  %t102 = insertvalue { i32, i64 } %t100, i64 %t98, 1
  store { i32, i64 } %t102, ptr %rv
  br label %ret
bb23:
  %t104 = load i8, ptr %l3, !tbaa !22
  %t106 = icmp eq i8 %t104, 42
  br i1 %t106, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb39
bb26:
  %t108 = load i8, ptr %l4, !tbaa !22
  %t110 = icmp eq i8 %t108, 61
  br i1 %t110, label %bb27, label %bb28
bb27:
  %t112 = load i64, ptr %l1, !tbaa !24
  %t114 = add i64 %t112, 2
  %t116 = insertvalue { i32, i64 } undef, i32 84, 0
  %t118 = insertvalue { i32, i64 } %t116, i64 %t114, 1
  store { i32, i64 } %t118, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t120 = load i8, ptr %l4, !tbaa !22
  %t122 = icmp ne i8 %t120, 42
  br i1 %t122, label %bb30, label %bb31
bb30:
  %t124 = load i64, ptr %l1, !tbaa !24
  %t126 = add i64 %t124, 1
  %t128 = insertvalue { i32, i64 } undef, i32 70, 0
  %t130 = insertvalue { i32, i64 } %t128, i64 %t126, 1
  store { i32, i64 } %t130, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t132 = load i64, ptr %l1, !tbaa !24
  %t134 = add i64 %t132, 2
  %t135 = load i64, ptr %l2, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  br i1 %t138, label %bb33, label %bb34
bb33:
  %t140 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t140, ptr %l74, !tbaa !27
  %t141 = load i64, ptr %l1, !tbaa !24
  %t143 = add i64 %t141, 2
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i8, ptr %t146, i64 %t143
  %t148 = load i8, ptr %t147, !tbaa !32
  %t150 = icmp eq i8 %t148, 61
  store i1 %t150, ptr %l73, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t152 = load i1, ptr %l73, !tbaa !21
  br i1 %t152, label %bb36, label %bb37
bb36:
  %t153 = load i64, ptr %l1, !tbaa !24
  %t155 = add i64 %t153, 3
  %t157 = insertvalue { i32, i64 } undef, i32 85, 0
  %t159 = insertvalue { i32, i64 } %t157, i64 %t155, 1
  store { i32, i64 } %t159, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t161 = load i64, ptr %l1, !tbaa !24
  %t163 = add i64 %t161, 2
  %t165 = insertvalue { i32, i64 } undef, i32 71, 0
  %t167 = insertvalue { i32, i64 } %t165, i64 %t163, 1
  store { i32, i64 } %t167, ptr %rv
  br label %ret
bb39:
  %t169 = load i8, ptr %l3, !tbaa !22
  %t171 = icmp eq i8 %t169, 47
  br i1 %t171, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t173 = load i8, ptr %l4, !tbaa !22
  %t175 = icmp eq i8 %t173, 61
  br i1 %t175, label %bb43, label %bb44
bb43:
  %t177 = load i64, ptr %l1, !tbaa !24
  %t179 = add i64 %t177, 2
  %t181 = insertvalue { i32, i64 } undef, i32 86, 0
  %t183 = insertvalue { i32, i64 } %t181, i64 %t179, 1
  store { i32, i64 } %t183, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t185 = load i64, ptr %l1, !tbaa !24
  %t187 = add i64 %t185, 1
  %t189 = insertvalue { i32, i64 } undef, i32 72, 0
  %t191 = insertvalue { i32, i64 } %t189, i64 %t187, 1
  store { i32, i64 } %t191, ptr %rv
  br label %ret
bb46:
  %t193 = load i8, ptr %l3, !tbaa !22
  %t195 = icmp eq i8 %t193, 37
  br i1 %t195, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb53
bb49:
  %t197 = load i8, ptr %l4, !tbaa !22
  %t199 = icmp eq i8 %t197, 61
  br i1 %t199, label %bb50, label %bb51
bb50:
  %t201 = load i64, ptr %l1, !tbaa !24
  %t203 = add i64 %t201, 2
  %t205 = insertvalue { i32, i64 } undef, i32 87, 0
  %t207 = insertvalue { i32, i64 } %t205, i64 %t203, 1
  store { i32, i64 } %t207, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t209 = load i64, ptr %l1, !tbaa !24
  %t211 = add i64 %t209, 1
  %t213 = insertvalue { i32, i64 } undef, i32 73, 0
  %t215 = insertvalue { i32, i64 } %t213, i64 %t211, 1
  store { i32, i64 } %t215, ptr %rv
  br label %ret
bb53:
  %t217 = load i8, ptr %l3, !tbaa !22
  %t219 = icmp eq i8 %t217, 38
  br i1 %t219, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t221 = load i8, ptr %l4, !tbaa !22
  %t223 = icmp eq i8 %t221, 61
  br i1 %t223, label %bb57, label %bb58
bb57:
  %t225 = load i64, ptr %l1, !tbaa !24
  %t227 = add i64 %t225, 2
  %t229 = insertvalue { i32, i64 } undef, i32 90, 0
  %t231 = insertvalue { i32, i64 } %t229, i64 %t227, 1
  store { i32, i64 } %t231, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t233 = load i64, ptr %l1, !tbaa !24
  %t235 = add i64 %t233, 1
  %t237 = insertvalue { i32, i64 } undef, i32 102, 0
  %t239 = insertvalue { i32, i64 } %t237, i64 %t235, 1
  store { i32, i64 } %t239, ptr %rv
  br label %ret
bb60:
  %t241 = load i8, ptr %l3, !tbaa !22
  %t243 = icmp eq i8 %t241, 124
  br i1 %t243, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t245 = load i8, ptr %l4, !tbaa !22
  %t247 = icmp eq i8 %t245, 61
  br i1 %t247, label %bb64, label %bb65
bb64:
  %t249 = load i64, ptr %l1, !tbaa !24
  %t251 = add i64 %t249, 2
  %t253 = insertvalue { i32, i64 } undef, i32 91, 0
  %t255 = insertvalue { i32, i64 } %t253, i64 %t251, 1
  store { i32, i64 } %t255, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  %t257 = load i64, ptr %l1, !tbaa !24
  %t259 = add i64 %t257, 1
  %t261 = insertvalue { i32, i64 } undef, i32 103, 0
  %t263 = insertvalue { i32, i64 } %t261, i64 %t259, 1
  store { i32, i64 } %t263, ptr %rv
  br label %ret
bb67:
  %t265 = load i8, ptr %l3, !tbaa !22
  %t267 = icmp eq i8 %t265, 94
  br i1 %t267, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t269 = load i8, ptr %l4, !tbaa !22
  %t271 = icmp eq i8 %t269, 61
  br i1 %t271, label %bb71, label %bb72
bb71:
  %t273 = load i64, ptr %l1, !tbaa !24
  %t275 = add i64 %t273, 2
  %t277 = insertvalue { i32, i64 } undef, i32 92, 0
  %t279 = insertvalue { i32, i64 } %t277, i64 %t275, 1
  store { i32, i64 } %t279, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  %t281 = load i64, ptr %l1, !tbaa !24
  %t283 = add i64 %t281, 1
  %t285 = insertvalue { i32, i64 } undef, i32 104, 0
  %t287 = insertvalue { i32, i64 } %t285, i64 %t283, 1
  store { i32, i64 } %t287, ptr %rv
  br label %ret
bb74:
  %t289 = load i8, ptr %l3, !tbaa !22
  %t291 = icmp eq i8 %t289, 58
  br i1 %t291, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb84
bb77:
  %t293 = load i8, ptr %l4, !tbaa !22
  %t295 = icmp eq i8 %t293, 61
  br i1 %t295, label %bb78, label %bb79
bb78:
  %t297 = load i64, ptr %l1, !tbaa !24
  %t299 = add i64 %t297, 2
  %t301 = insertvalue { i32, i64 } undef, i32 80, 0
  %t303 = insertvalue { i32, i64 } %t301, i64 %t299, 1
  store { i32, i64 } %t303, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  %t305 = load i8, ptr %l4, !tbaa !22
  %t307 = icmp eq i8 %t305, 126
  br i1 %t307, label %bb81, label %bb82
bb81:
  %t309 = load i64, ptr %l1, !tbaa !24
  %t311 = add i64 %t309, 2
  %t313 = insertvalue { i32, i64 } undef, i32 81, 0
  %t315 = insertvalue { i32, i64 } %t313, i64 %t311, 1
  store { i32, i64 } %t315, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t317 = load i64, ptr %l1, !tbaa !24
  %t319 = add i64 %t317, 1
  %t321 = insertvalue { i32, i64 } undef, i32 79, 0
  %t323 = insertvalue { i32, i64 } %t321, i64 %t319, 1
  store { i32, i64 } %t323, ptr %rv
  br label %ret
bb84:
  %t325 = load i8, ptr %l3, !tbaa !22
  %t327 = icmp eq i8 %t325, 61
  br i1 %t327, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t329 = load i8, ptr %l4, !tbaa !22
  %t331 = icmp eq i8 %t329, 61
  br i1 %t331, label %bb88, label %bb89
bb88:
  %t333 = load i64, ptr %l1, !tbaa !24
  %t335 = add i64 %t333, 2
  %t337 = insertvalue { i32, i64 } undef, i32 95, 0
  %t339 = insertvalue { i32, i64 } %t337, i64 %t335, 1
  store { i32, i64 } %t339, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t341 = load i64, ptr %l1, !tbaa !24
  %t343 = add i64 %t341, 1
  %t345 = insertvalue { i32, i64 } undef, i32 78, 0
  %t347 = insertvalue { i32, i64 } %t345, i64 %t343, 1
  store { i32, i64 } %t347, ptr %rv
  br label %ret
bb91:
  %t349 = load i8, ptr %l3, !tbaa !22
  %t351 = icmp eq i8 %t349, 33
  br i1 %t351, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb98
bb94:
  %t353 = load i8, ptr %l4, !tbaa !22
  %t355 = icmp eq i8 %t353, 61
  br i1 %t355, label %bb95, label %bb96
bb95:
  %t357 = load i64, ptr %l1, !tbaa !24
  %t359 = add i64 %t357, 2
  %t361 = insertvalue { i32, i64 } undef, i32 96, 0
  %t363 = insertvalue { i32, i64 } %t361, i64 %t359, 1
  store { i32, i64 } %t363, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  %t365 = load i64, ptr %l1, !tbaa !24
  %t367 = add i64 %t365, 1
  %t369 = insertvalue { i32, i64 } undef, i32 97, 0
  %t371 = insertvalue { i32, i64 } %t369, i64 %t367, 1
  store { i32, i64 } %t371, ptr %rv
  br label %ret
bb98:
  %t373 = load i8, ptr %l3, !tbaa !22
  %t375 = icmp eq i8 %t373, 60
  br i1 %t375, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb114
bb101:
  %t377 = load i8, ptr %l4, !tbaa !22
  %t379 = icmp eq i8 %t377, 60
  br i1 %t379, label %bb102, label %bb103
bb102:
  %t381 = load i64, ptr %l1, !tbaa !24
  %t383 = add i64 %t381, 2
  %t384 = load i64, ptr %l2, !tbaa !24
  %t387 = icmp slt i64 %t383, %t384
  br i1 %t387, label %bb104, label %bb105
bb103:
  br label %bb110
bb104:
  %t389 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t389, ptr %l198, !tbaa !27
  %t390 = load i64, ptr %l1, !tbaa !24
  %t392 = add i64 %t390, 2
  %t394 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr i8, ptr %t395, i64 %t392
  %t397 = load i8, ptr %t396, !tbaa !32
  %t399 = icmp eq i8 %t397, 61
  store i1 %t399, ptr %l197, !tbaa !21
  br label %bb106
bb105:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb106
bb106:
  %t401 = load i1, ptr %l197, !tbaa !21
  br i1 %t401, label %bb107, label %bb108
bb107:
  %t402 = load i64, ptr %l1, !tbaa !24
  %t404 = add i64 %t402, 3
  %t406 = insertvalue { i32, i64 } undef, i32 88, 0
  %t408 = insertvalue { i32, i64 } %t406, i64 %t404, 1
  store { i32, i64 } %t408, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t410 = load i64, ptr %l1, !tbaa !24
  %t412 = add i64 %t410, 2
  %t414 = insertvalue { i32, i64 } undef, i32 108, 0
  %t416 = insertvalue { i32, i64 } %t414, i64 %t412, 1
  store { i32, i64 } %t416, ptr %rv
  br label %ret
bb110:
  %t418 = load i8, ptr %l4, !tbaa !22
  %t420 = icmp eq i8 %t418, 61
  br i1 %t420, label %bb111, label %bb112
bb111:
  %t422 = load i64, ptr %l1, !tbaa !24
  %t424 = add i64 %t422, 2
  %t426 = insertvalue { i32, i64 } undef, i32 99, 0
  %t428 = insertvalue { i32, i64 } %t426, i64 %t424, 1
  store { i32, i64 } %t428, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  %t430 = load i64, ptr %l1, !tbaa !24
  %t432 = add i64 %t430, 1
  %t434 = insertvalue { i32, i64 } undef, i32 98, 0
  %t436 = insertvalue { i32, i64 } %t434, i64 %t432, 1
  store { i32, i64 } %t436, ptr %rv
  br label %ret
bb114:
  %t438 = load i8, ptr %l3, !tbaa !22
  %t440 = icmp eq i8 %t438, 62
  br i1 %t440, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb130
bb117:
  %t442 = load i8, ptr %l4, !tbaa !22
  %t444 = icmp eq i8 %t442, 62
  br i1 %t444, label %bb118, label %bb119
bb118:
  %t446 = load i64, ptr %l1, !tbaa !24
  %t448 = add i64 %t446, 2
  %t449 = load i64, ptr %l2, !tbaa !24
  %t452 = icmp slt i64 %t448, %t449
  br i1 %t452, label %bb120, label %bb121
bb119:
  br label %bb126
bb120:
  %t454 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t454, ptr %l230, !tbaa !27
  %t455 = load i64, ptr %l1, !tbaa !24
  %t457 = add i64 %t455, 2
  %t459 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !27
  %t461 = getelementptr i8, ptr %t460, i64 %t457
  %t462 = load i8, ptr %t461, !tbaa !32
  %t464 = icmp eq i8 %t462, 61
  store i1 %t464, ptr %l229, !tbaa !21
  br label %bb122
bb121:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb122
bb122:
  %t466 = load i1, ptr %l229, !tbaa !21
  br i1 %t466, label %bb123, label %bb124
bb123:
  %t467 = load i64, ptr %l1, !tbaa !24
  %t469 = add i64 %t467, 3
  %t471 = insertvalue { i32, i64 } undef, i32 89, 0
  %t473 = insertvalue { i32, i64 } %t471, i64 %t469, 1
  store { i32, i64 } %t473, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  %t475 = load i64, ptr %l1, !tbaa !24
  %t477 = add i64 %t475, 2
  %t479 = insertvalue { i32, i64 } undef, i32 109, 0
  %t481 = insertvalue { i32, i64 } %t479, i64 %t477, 1
  store { i32, i64 } %t481, ptr %rv
  br label %ret
bb126:
  %t483 = load i8, ptr %l4, !tbaa !22
  %t485 = icmp eq i8 %t483, 61
  br i1 %t485, label %bb127, label %bb128
bb127:
  %t487 = load i64, ptr %l1, !tbaa !24
  %t489 = add i64 %t487, 2
  %t491 = insertvalue { i32, i64 } undef, i32 101, 0
  %t493 = insertvalue { i32, i64 } %t491, i64 %t489, 1
  store { i32, i64 } %t493, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  %t495 = load i64, ptr %l1, !tbaa !24
  %t497 = add i64 %t495, 1
  %t499 = insertvalue { i32, i64 } undef, i32 100, 0
  %t501 = insertvalue { i32, i64 } %t499, i64 %t497, 1
  store { i32, i64 } %t501, ptr %rv
  br label %ret
bb130:
  %t503 = load i8, ptr %l3, !tbaa !22
  %t505 = icmp eq i8 %t503, 64
  br i1 %t505, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb134
bb133:
  %t507 = load i64, ptr %l1, !tbaa !24
  %t509 = add i64 %t507, 1
  %t511 = insertvalue { i32, i64 } undef, i32 74, 0
  %t513 = insertvalue { i32, i64 } %t511, i64 %t509, 1
  store { i32, i64 } %t513, ptr %rv
  br label %ret
bb134:
  %t515 = load i8, ptr %l3, !tbaa !22
  %t517 = icmp eq i8 %t515, 44
  br i1 %t517, label %bb135, label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb138
bb137:
  %t519 = load i64, ptr %l1, !tbaa !24
  %t521 = add i64 %t519, 1
  %t523 = insertvalue { i32, i64 } undef, i32 75, 0
  %t525 = insertvalue { i32, i64 } %t523, i64 %t521, 1
  store { i32, i64 } %t525, ptr %rv
  br label %ret
bb138:
  %t527 = load i8, ptr %l3, !tbaa !22
  %t529 = icmp eq i8 %t527, 46
  br i1 %t529, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  %t531 = load i64, ptr %l1, !tbaa !24
  %t533 = add i64 %t531, 1
  %t535 = insertvalue { i32, i64 } undef, i32 76, 0
  %t537 = insertvalue { i32, i64 } %t535, i64 %t533, 1
  store { i32, i64 } %t537, ptr %rv
  br label %ret
bb142:
  %t539 = load i8, ptr %l3, !tbaa !22
  %t541 = icmp eq i8 %t539, 63
  br i1 %t541, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb146
bb145:
  %t543 = load i64, ptr %l1, !tbaa !24
  %t545 = add i64 %t543, 1
  %t547 = insertvalue { i32, i64 } undef, i32 77, 0
  %t549 = insertvalue { i32, i64 } %t547, i64 %t545, 1
  store { i32, i64 } %t549, ptr %rv
  br label %ret
bb146:
  %t551 = load i8, ptr %l3, !tbaa !22
  %t553 = icmp eq i8 %t551, 126
  br i1 %t553, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb150
bb149:
  %t555 = load i64, ptr %l1, !tbaa !24
  %t557 = add i64 %t555, 1
  %t559 = insertvalue { i32, i64 } undef, i32 105, 0
  %t561 = insertvalue { i32, i64 } %t559, i64 %t557, 1
  store { i32, i64 } %t561, ptr %rv
  br label %ret
bb150:
  %t563 = load i8, ptr %l3, !tbaa !22
  %t565 = icmp eq i8 %t563, 36
  br i1 %t565, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb154
bb153:
  %t567 = load i64, ptr %l1, !tbaa !24
  %t569 = add i64 %t567, 1
  %t571 = insertvalue { i32, i64 } undef, i32 107, 0
  %t573 = insertvalue { i32, i64 } %t571, i64 %t569, 1
  store { i32, i64 } %t573, ptr %rv
  br label %ret
bb154:
  %t575 = load i8, ptr %l3, !tbaa !22
  %t577 = icmp eq i8 %t575, 40
  br i1 %t577, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb158
bb157:
  %t579 = load i64, ptr %l1, !tbaa !24
  %t581 = add i64 %t579, 1
  %t583 = insertvalue { i32, i64 } undef, i32 110, 0
  %t585 = insertvalue { i32, i64 } %t583, i64 %t581, 1
  store { i32, i64 } %t585, ptr %rv
  br label %ret
bb158:
  %t587 = load i8, ptr %l3, !tbaa !22
  %t589 = icmp eq i8 %t587, 41
  br i1 %t589, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb162
bb161:
  %t591 = load i64, ptr %l1, !tbaa !24
  %t593 = add i64 %t591, 1
  %t595 = insertvalue { i32, i64 } undef, i32 111, 0
  %t597 = insertvalue { i32, i64 } %t595, i64 %t593, 1
  store { i32, i64 } %t597, ptr %rv
  br label %ret
bb162:
  %t599 = load i8, ptr %l3, !tbaa !22
  %t601 = icmp eq i8 %t599, 91
  br i1 %t601, label %bb163, label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  %t603 = load i64, ptr %l1, !tbaa !24
  %t605 = add i64 %t603, 1
  %t607 = insertvalue { i32, i64 } undef, i32 112, 0
  %t609 = insertvalue { i32, i64 } %t607, i64 %t605, 1
  store { i32, i64 } %t609, ptr %rv
  br label %ret
bb166:
  %t611 = load i8, ptr %l3, !tbaa !22
  %t613 = icmp eq i8 %t611, 93
  br i1 %t613, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  %t615 = load i64, ptr %l1, !tbaa !24
  %t617 = add i64 %t615, 1
  %t619 = insertvalue { i32, i64 } undef, i32 113, 0
  %t621 = insertvalue { i32, i64 } %t619, i64 %t617, 1
  store { i32, i64 } %t621, ptr %rv
  br label %ret
bb170:
  %t623 = load i8, ptr %l3, !tbaa !22
  %t625 = icmp eq i8 %t623, 123
  br i1 %t625, label %bb171, label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb174
bb173:
  %t627 = load i64, ptr %l1, !tbaa !24
  %t629 = add i64 %t627, 1
  %t631 = insertvalue { i32, i64 } undef, i32 114, 0
  %t633 = insertvalue { i32, i64 } %t631, i64 %t629, 1
  store { i32, i64 } %t633, ptr %rv
  br label %ret
bb174:
  %t635 = load i8, ptr %l3, !tbaa !22
  %t637 = icmp eq i8 %t635, 125
  br i1 %t637, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  %t639 = load i64, ptr %l1, !tbaa !24
  %t641 = add i64 %t639, 1
  %t643 = insertvalue { i32, i64 } undef, i32 115, 0
  %t645 = insertvalue { i32, i64 } %t643, i64 %t641, 1
  store { i32, i64 } %t645, ptr %rv
  br label %ret
bb178:
  br i1 true, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb182
bb181:
  %t647 = load i64, ptr %l1, !tbaa !24
  %t649 = add i64 %t647, 1
  %t651 = insertvalue { i32, i64 } undef, i32 0, 0
  %t653 = insertvalue { i32, i64 } %t651, i64 %t649, 1
  store { i32, i64 } %t653, ptr %rv
  br label %ret
bb182:
  call void @__olang_check_failed(ptr @olang_loc_29c361661bd12d1c_bc00961d9e0a1b58)
  unreachable
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2fscan_2epushUtf8(ptr %v0, ptr noalias dereferenceable(32) align 8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 128
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = trunc i64 %t6 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t5, i8 %t8)
  br label %bb3
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = icmp slt i64 %t11, 2048
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = ashr i64 %t16, 6
  %t20 = or i64 192, %t18
  %t22 = trunc i64 %t20 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t15, i8 %t22)
  br label %bb6
bb5:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp slt i64 %t25, 65536
  br i1 %t27, label %bb8, label %bb9
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = and i64 %t30, 63
  %t34 = or i64 128, %t32
  %t36 = trunc i64 %t34 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t29, i8 %t36)
  br label %bb7
bb7:
  br label %bb18
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = ashr i64 %t40, 12
  %t44 = or i64 224, %t42
  %t46 = trunc i64 %t44 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t39, i8 %t46)
  br label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = ashr i64 %t50, 18
  %t54 = and i64 %t52, 7
  %t56 = or i64 240, %t54
  %t58 = trunc i64 %t56 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t49, i8 %t58)
  br label %bb13
bb10:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t64 = ashr i64 %t62, 6
  %t66 = and i64 %t64, 63
  %t68 = or i64 128, %t66
  %t70 = trunc i64 %t68 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t61, i8 %t70)
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t76 = and i64 %t74, 63
  %t78 = or i64 128, %t76
  %t80 = trunc i64 %t78 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t73, i8 %t80)
  br label %bb12
bb12:
  br label %bb17
bb13:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  %t86 = ashr i64 %t84, 12
  %t88 = and i64 %t86, 63
  %t90 = or i64 128, %t88
  %t92 = trunc i64 %t90 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t83, i8 %t92)
  br label %bb14
bb14:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = ashr i64 %t96, 6
  %t100 = and i64 %t98, 63
  %t102 = or i64 128, %t100
  %t104 = trunc i64 %t102 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t95, i8 %t104)
  br label %bb15
bb15:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l1, !tbaa !24
  %t110 = and i64 %t108, 63
  %t112 = or i64 128, %t110
  %t114 = trunc i64 %t112 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %t107, i8 %t114)
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscan_2ewordEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = call i1 @compiler_2fscan_2eisWordChar(i8 %t19)
  store i1 %t21, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l10, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"unexpected character '" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d2 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"non-ASCII character outside a comment or literal - names and code are ASCII" }>, align 8
@.d3 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"invalid UTF-8 - olang source is UTF-8 text" }>, align 8
@.d4 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"NUL byte in the source - is this a text file?" }>, align 8
@.d5 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"carriage return - save the file with LF line endings" }>, align 8
@.d6 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang has no ';'" }>, align 8
@.d7 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a comma never ends a line" }>, align 8
@.d8 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"unterminated block comment - '##' closes it" }>, align 8
@.d9 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"unterminated string literal" }>, align 8
@.d10 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"string literal not closed on its line - write \5Cn for a newline" }>, align 8
@.d11 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"unterminated character literal" }>, align 8
@.d12 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"character literal not closed on its line" }>, align 8
@.d13 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"empty character literal" }>, align 8
@.d14 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"character literal holds more than one character - text is written in \22\22" }>, align 8
@.d15 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"a character literal holds one byte, and this character is several in UTF-8" }>, align 8
@.d16 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unknown escape '\5C" }>, align 8
@.d17 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"' - the escapes are \5Cn \5Ct \5Cr \5C0 \5C\5C \5C' \5C\22 \5CxHH \5Cu{H}" }>, align 8
@.d18 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"'\5Cx' needs two hexadecimal digits, as \5Cx41" }>, align 8
@.d19 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"'\5Cu' needs one to six hexadecimal digits in braces, as \5Cu{1F600}" }>, align 8
@.d20 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"a Unicode code point is at most 10FFFF and no surrogate (D800-DFFF)" }>, align 8
@.d21 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"a character literal holds one byte, and \5Cu{...} there is below 80" }>, align 8
@.d22 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"unterminated raw text - '\22\22\22' closes it" }>, align 8
@.d23 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"raw text across lines begins on the line after its '\22\22\22' - move this to the next line" }>, align 8
@.d24 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"the closing '\22\22\22' of raw text across lines stands on a line of its own" }>, align 8
@.d25 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"a line of raw text begins with the indentation of its closing '\22\22\22'" }>, align 8
@.d26 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"'0x' needs hexadecimal digits" }>, align 8
@.d27 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"'0b' needs binary digits" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d29 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' is not a hexadecimal digit" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d31 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"' is not a binary digit" }>, align 8
@.d32 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"'_' in a number must stand between two digits" }>, align 8
@.d33 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a decimal point needs a digit after it" }>, align 8
@.d34 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a number has at most one decimal point" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L16" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"L1" }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"L3" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L18" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L18a" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L4a" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L14" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L13" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L15" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L13" }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"L13, L15" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L14a" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10a" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10c" }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"L10b" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"L12" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_e0eb014d323e7d9_3ee0f0ba74559745 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fscan_2elastLineStart(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @compiler_2fscan_2eblankLine(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fscan_2ehexDigit(i8 %a0)
declare { i32, { i64, i64 } } @compiler_2fscan_2eunicodeEscape(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @compiler_2fscan_2eisWordChar(i8 %a0)
@olang_loc_39af88013a73b478_a5c9d135875fcb24 = external constant [0 x i8]
@olang_loc_3aab5bd1ecbcb485_f7a3519a1de9c361 = external constant [0 x i8]
declare void @compiler_2fscan_2ecompiler_2fscan_3ascanner_2ediag(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i8 %a4)
declare i64 @compiler_2fscan_2ecompiler_2fscan_3ascanner_2eescape(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eLen_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscan_2eisLetter(i8 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eClear_Hee3cbaa7ef2d16f687a523c73aa64228(ptr %v0, ptr %a0)
declare i1 @compiler_2fscan_2eisDigit(i8 %a0)
declare i64 @compiler_2fscan_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i32 @compiler_2ftoken_2eTok_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eEndsStatement(i32 %a0)
declare %"compiler/token:Token" @compiler_2ftoken_3aToken_2ector(ptr %v0, i32 %a0, i8 %a1, i32 %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aToken_3e_2ePush_3ccompiler_2ftoken_3aToken_3e(ptr %v0, ptr %a0, %"compiler/token:Token" %a1)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
@G_2ecompiler_2ftoken_2eSpace = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\02" }>, align 8
@G_2ecompiler_2ftoken_2eLineStart = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\04" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePush_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %a0, i8 %a1)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eAt_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2eTrunc_Hdb40e008e45c3217ff19be25d205c76e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i8 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aChar_3e_2ePop_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %a0)
@olang_loc_639a87f47d38eeab_7a46798b70a2d59f = external constant [0 x i8]
declare i64 @compiler_2fscan_2eutf8Width(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_29c361661bd12d1c_bc00961d9e0a1b58 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
